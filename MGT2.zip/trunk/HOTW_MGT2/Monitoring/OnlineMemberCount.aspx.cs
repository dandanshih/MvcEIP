﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Monitoring
{
	public partial class OnlineMemberCount : GWeb.AppLibs.FormBase
	{
		#region private

		private void BindData()
		{
			lblTime.Text = DateTime.Now.ToString("yyyy/MM/dd tt hh:mm:ss");

			SqlParameter[] param = 
			{
				new SqlParameter("@LobbyCount", DbType.Int32)
			};

			param[0].Direction = ParameterDirection.Output;

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_OnlineMemberList",
														   param);

			gvOnlineMembers.DataSource = objDtr;
			gvOnlineMembers.DataBind();

			objDtr.Close();

			lblLobbyCountValue.Text = param[0].Value.ToString();
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindData();
				Timer1.Enabled = btnRefresh.Visible;
			}
		}

		protected void Timer1_Tick(object sender, EventArgs e)
		{
			BindData();
		}

		protected void btnRefresh_Click(object sender, EventArgs e)
		{
			BindData();
		}

		protected void gvOnlineMembers_RowDataBound(object sender, GridViewRowEventArgs e)
		{
            //if (gvOnlineMembers.Rows.Count > 0)
            //{
				if (e.Row.RowType == DataControlRowType.DataRow)
				{
					Label lblGameName = (Label)e.Row.Cells[0].FindControl("lblGameName");
					if (lblGameName.Text.Trim() == "小計" || lblGameName.Text.Trim() == "總計")
					{
						e.Row.BackColor = System.Drawing.Color.FromArgb(Convert.ToInt32("47", 16), Convert.ToInt32("4E", 16), Convert.ToInt32("54", 16));
						e.Row.ForeColor = System.Drawing.Color.White;
					}
					else
					{
						try
						{
							// 轉換語系
                            lblGameName.Text = Utility.GetGameENameMapping(lblGameName.Text).ToString();
						}
						catch
						{ 
						
						}
					}
				}
			}
        //}

		#endregion
	}
}