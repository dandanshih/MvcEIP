﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using System.Data.SqlClient;
using GS.Utilities;
using System.Data;
using GFC.Web.WebControls;

namespace GWeb.Monitoring
{
    public partial class B206 : FormBase
    {
        /// <summary>
        /// 起始日期。
        /// </summary>
        private string StartDate
        {
            get { return ViewState["StartDate"] == null ? DateTime.MinValue.ToString("yyyy-MM-dd HH-mm-dd") : ViewState["StartDate"].ToString(); }
            set { ViewState["StartDate"] = value; }
        }

        /// <summary>
        /// 讀取遊戲狀態資料。
        /// </summary>
        private void BindGameState()
        {
            SqlParameter[] param =
            {
                new SqlParameter("@GameID", "-1"),
                new SqlParameter("@GroupID", "-1"),
                new SqlParameter("@StartDate", StartDate)
            };

            DataSet objdS = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_G_RealTimeGameState_RealGame_GetByID",
                param
            );

            gvGameState.DataSource = objdS;
            gvGameState.DataBind();
        }

        /// <summary>
        /// 讀取遊戲狀態資料。
        /// </summary>
        private void BindBetState()
        {
            SqlParameter[] param =
            {
                new SqlParameter("@GameID", "-1"),
                new SqlParameter("@GroupID", "-1")
            };

            DataSet objDS = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_G_RealTimeBetState_RealGame_GetByID",
                param
            );

            gvBetState.DataSource = objDS;
            gvBetState.DataBind();
        }

        #region Protected Method
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                btnRefresh_Click(null, null);
            }
        }

        /// <summary>
        /// 即時更新按鈕。
        /// </summary>
        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            //檢查是否可查詢資料
            if (!Authority.CheckAuthority(EnumAuthority.LiveReNew))
            {
                Timer1.Enabled = false;
                return;
            }

            lblTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            // 紀錄屬性，以供查詢明細用
            StartDate = UCDateRange1.StartDate;

            BindGameState();
            BindBetState();
        }

        protected void gvGameState_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string gameState = "";

                switch (DataBinder.Eval(e.Row.DataItem, "GameState").ToString())
                {
                    case "0":
                        gameState = "準備中";
                        break;
                    case "1":
                        gameState = "洗牌中";
                        break;
                    case "2":
                        gameState = "下注時間";
                        break;
                    case "3":
                        gameState = "停止下注";
                        break;
                    case "4":
                        gameState = "發牌中";
                        break;
                    case "5":
                        gameState = "保險時間";
                        break;
                    case "6":
                        gameState = "結算中";
                        break;
                    case "7":
                        gameState = "遊戲維護中";
                        break;
                }

                (e.Row.FindControl("lblGameState_State") as Label).Text = gameState;
            }
        }

        /// <summary>
        /// 【真人即時遊戲狀態】計算總計事件。
        /// </summary>
        protected void gvGameState_DataBound(object sender, EventArgs e)
        {
            TBGridView table = (TBGridView)sender;

            if (table.FooterRow != null)
            {
                int betCount = 0;
                decimal bet = 0;

                foreach (GridViewRow row in table.Rows)
                {
                    betCount += int.Parse((row.FindControl("lblGameState_BetCount") as Label).Text);
                    bet += decimal.Parse((row.FindControl("lblGameState_BetAmount") as Label).Text);
                }

                table.FooterRow.Cells[6].Text = betCount.ToString();
                table.FooterRow.Cells[7].Text = bet.ToString("N2");
            }
        }
        #endregion
    }
}