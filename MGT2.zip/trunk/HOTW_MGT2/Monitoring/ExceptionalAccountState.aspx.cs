﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Monitoring
{
	public partial class ExceptionalAccountState : GWeb.AppLibs.FormBase
	{
		#region private

		/// <summary>
		/// 讀取異常帳號名單。
		/// </summary>
		private void LoadExceptionalAccountList()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@AlarmType", 1)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_AlarmAccountMoniter_List",
														   param);

			gvExceptionalAccountList.DataSource = objDtr;
			gvExceptionalAccountList.DataBind();

			objDtr.Close();
		}

		/// <summary>
		/// 讀取異常IP名單。
		/// </summary>
		private void LoadExceptionalIPList()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@AlarmType", 2)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_AlarmAccountMoniter_List",
														   param);

			gvExceptionalIPList.DataSource = objDtr;
			gvExceptionalIPList.DataBind();

			objDtr.Close();
		}

		private void BindData()
		{
			lblTime.Text = DateTime.Now.ToString();
			LoadExceptionalAccountList();
			LoadExceptionalIPList();
		}
		
		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindData();
			}
		}

		protected void gvExceptionalAccountList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 踢會員。
			if (e.CommandName == "KickMember")
			{
				//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(e.CommandArgument.ToString()),int.Parse(AUser.ExecAgentID));

                // 20110509 Phil: 改對前台發出登出命令
                GameCommandHandler.LogoutMember(int.Parse(e.CommandArgument.ToString()));
                ResponseScript(Page, "alert('踢出命令已送出.');", ResponseScriptPlace.NearFormEnd);
				BindData();
			}
		}

		protected void gvExceptionalIPList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 踢會員。
			if (e.CommandName == "KickMember")
			{
				//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(e.CommandArgument.ToString()),int.Parse(AUser.ExecAgentID));

                // 20110509 Phil: 改對前台發出登出命令
                GameCommandHandler.LogoutMember(int.Parse(e.CommandArgument.ToString()));

				BindData();
			}
		}

		protected void Timer1_Tick(object sender, EventArgs e)
		{
			BindData();
		}

		protected void btnRefresh_Click(object sender, EventArgs e)
		{
			BindData();
		}

		protected void gvExceptionalAccountList_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				// 轉換語系
				try
				{
                    ((Label)e.Row.FindControl("lblLastBetGame")).Text = Utility.GetGameENameMapping(((Label)e.Row.FindControl("lblLastBetGame")).Text).ToString();
				}
				catch
				{

				}
			}
		}

		protected void gvExceptionalIPList_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				// 轉換語系
				try
				{
                    ((Label)e.Row.FindControl("lblLastBetGame")).Text = Utility.GetGameENameMapping(((Label)e.Row.FindControl("lblLastBetGame")).Text).ToString();
				}
				catch
				{

				}
			}
		}

		#endregion
	}
}