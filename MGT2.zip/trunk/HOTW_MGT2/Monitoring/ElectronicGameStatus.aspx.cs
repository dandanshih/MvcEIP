﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web.UI.WebControls;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Monitoring
{
	public partial class ElectronicGameStatus : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if(!IsPostBack)
			{
				InitTree();
				Timer1.Enabled = btnRefresh.Visible;
			}
		}

		/// <summary>
		/// 樹狀列表點選
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void TreeView1_ItemClick(object sender, EO.Web.NavigationItemEventArgs e)
		{
			this.LoadData(1);
		}

		/// <summary>
		/// 即時更新按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnRefresh_Click(object sender, EventArgs e)
		{
            this.InitTree();
			this.LoadData(1);
		}
		/// <summary>
		/// 計時器
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Timer1_Tick(object sender, EventArgs e)
		{
			InitTree();
		}
		/// <summary>
		/// 設定LinkButton底線
		/// </summary>
		/// <param name="pageNo"></param>
		protected void SetLinkButtonUnderline(string pageNo)
		{
			if (pageNo.Equals("1"))
			{
				lbPage1.Attributes.Add("style", "text-decoration:none;color:blue;");
				lbPage2.Attributes.Add("style", "text-decoration:underline;color:blue;");
			}
			else
			{
				lbPage1.Attributes.Add("style", "text-decoration:underline;color:blue;");
				lbPage2.Attributes.Add("style", "text-decoration:none;color:blue;");
			}
		}
		/// <summary>
		/// 按下頁面按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lbPage_Click(object sender, EventArgs e)
		{
			LinkButton lb = sender as LinkButton;
			LoadData(int.Parse(lb.CommandArgument));

		}
		/// <summary>
		/// 建立TreeView
		/// </summary>
		private void InitTree()
		{
			TreeView1.Nodes.Clear();

			Int32 TotalMembers = 0;
			// 建立與設定【根結點】相關屬性內容
			EO.Web.TreeNode RootNode = new EO.Web.TreeNode();

			RootNode.Value = "0";
			RootNode.PopulateOnDemand = false;
			RootNode.Expanded = true;
			RootNode.PopulateOnDemand = true;
			//RootNode.RaisesServerEvent = EO.Web.NullableBool.False;
			TreeView1.Nodes.Add(RootNode);
			List<EO.Web.TreeNode> lstChilds = new List<EO.Web.TreeNode>();

			SqlParameter[] arParms =
			{
			    new SqlParameter("@GameTypeID",2)
			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GameMonitor_GameList", arParms);
			while (sdr.Read())
			{
				EO.Web.TreeNode childNode = new EO.Web.TreeNode();
                childNode.Text = string.Format("{0}(目前人數:{1})", Utility.GetGameENameMapping(sdr["GameEName"].ToString()).ToString(), sdr["PlayerNum"].ToString());
				childNode.Value = sdr["GameID"].ToString();

				TotalMembers += Int32.Parse(sdr["PlayerNum"].ToString());
				lstChilds.Add(childNode);
			}
			RootNode.Expanded = RootNode.ChildNodes.Count == 0 ? false : true;
			RootNode.PopulateOnDemand = RootNode.ChildNodes.Count == 0 ? false : true;
			//btnRefresh.Enabled = !(RootNode.ChildNodes.Count == 0);
			

			sdr.Close();

			RootNode.Text = "遊戲列表(目前總人數:" + TotalMembers.ToString() + ")";
			RootNode.ChildNodes.AddRange(lstChilds);
			

			Panel1.Visible = false;
		}

		/// <summary>
		/// 載入資料
		/// </summary>
		/// <param name="pageNo">顯示頁面</param>
		protected void LoadData(int pageNo)
		{

			if (TreeView1.SelectedNode == null)
			{
				return;
			}
			#region 表1
			SqlParameter[] arParms =
			{
				new SqlParameter("@IsShowTools",rblDisplayMode.SelectedValue),
				new SqlParameter("@GameID",TreeView1.SelectedNode.Value),
				new SqlParameter("@TableNo",SqlDbType.SmallInt),
				new SqlParameter("@InSeatNum",SqlDbType.Int),
				new SqlParameter("@EmptySeatNum",SqlDbType.Int),
				new SqlParameter("@3MinPlayedNum",SqlDbType.Int),
				new SqlParameter("@UsedReservedSeats",SqlDbType.Int)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 2].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 3].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 4].Direction = ParameterDirection.Output;

			arParms[arParms.Length - 5].Value = pageNo == 1 ? "1" : "3";
			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_EGameMoniter_TableData", arParms);
			gv1.DataSource = sdr;
			gv1.DataBind();
			sdr.Close();
			
			#endregion 表1

			#region 表2
			SqlParameter[] arParms2 =
			{
				new SqlParameter("@IsShowTools",rblDisplayMode.SelectedValue),
				new SqlParameter("@GameID",TreeView1.SelectedNode.Value),
				new SqlParameter("@TableNo",SqlDbType.SmallInt),
				new SqlParameter("@InSeatNum",SqlDbType.Int),
				new SqlParameter("@EmptySeatNum",SqlDbType.Int),
				new SqlParameter("@3MinPlayedNum",SqlDbType.Int),
				new SqlParameter("@UsedReservedSeats",SqlDbType.Int)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 2].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 3].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 4].Direction = ParameterDirection.Output;

			arParms2[arParms2.Length - 5].Value = pageNo == 1 ? "2" : "4";
			sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_EGameMoniter_TableData", arParms2);

			gv2.DataSource = sdr;
			gv2.DataBind();
			sdr.Close();

			#endregion 表2

			SetLinkButtonUnderline(pageNo.ToString());

			lblSeatCnt.Text = arParms[arParms.Length - 4].Value.ToString();
			lblEmptySeat.Text = arParms[arParms.Length - 3].Value.ToString();
			lblThreeMinutesCnt.Text = arParms[arParms.Length - 2].Value.ToString();
			lblReserveSeat.Text = arParms[arParms.Length - 1].Value.ToString();

			Panel1.Visible = true;


		}

		protected void GridView_DataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				DataRowView drv = e.Row.DataItem as DataRowView;
				if (drv["IsTools"].ToString().Equals("1"))
				{
					e.Row.BackColor = Color.Pink;
				}
			}
		}

        protected void gvRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                try
                {
                    e.Row.Cells[0].Text = GetGlobalResourceObject("MachineGroup", e.Row.Cells[0].Text).ToString();
                }
                catch (Exception)
                {
                    
                }
            }
        }
	}
}