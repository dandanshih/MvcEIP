﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;


namespace GWeb.Monitoring
{
	public partial class RealtimeMemberAudit : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				this.LoadData();
				Timer1.Enabled = btnRefresh.Visible;
			}
		}


        protected void gvRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                try
                {
                    e.Row.Cells[8].Text = Utility.GetGameENameMapping(e.Row.Cells[8].Text).ToString();
                    if (e.Row.Cells[13].Text == "1")
                    {
                        e.Row.Cells[13].Text = "是";
                        ((CheckBox)e.Row.Cells[e.Row.Cells.Count - 1].FindControl("cbSelect")).Checked = true;
                    }
                    else
                        e.Row.Cells[13].Text = "否";
                }
                catch (Exception)
                { }
            }
            e.Row.Cells[12].Visible = false;
        }

		protected void btnRefresh_Click(object sender, EventArgs e)
		{
			this.LoadData();
		}
		/// <summary>
		/// 計時器事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Timer1_Tick(object sender, EventArgs e)
		{
			LoadData();
		}


		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			SqlParameter[] param = 
			{
				new SqlParameter("@GameAreaType", ddlGameAreaType.SelectedItem.Value)
			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_RealTimeWinlose_Member", param);

			gvGameLog.DataSource = sdr;
			gvGameLog.DataBind();
			sdr.Close();

			lblTime.Text = DateTime.Now.ToString();
		}

		/// <summary>
		/// 勾起全選時
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void cbAllSelectChange(object sender, EventArgs e)
		{
			foreach (GridViewRow gvr in gvGameLog.Rows)
			{
				(gvr.Cells[gvr.Cells.Count-1].FindControl("cbSelect") as CheckBox).Checked = (sender as CheckBox).Checked;
			}
		}

		/// <summary>
		/// 按下確認紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnConfirmClick(object sender, EventArgs e)
		{
			Int32 effRows = 0;
			foreach (GridViewRow gvr in gvGameLog.Rows)
			{
				if ((gvr.Cells[gvr.Cells.Count - 1].FindControl("cbSelect") as CheckBox).Checked)
				{
					SqlParameter[] arParms =
					{
						new SqlParameter("@MemberID",gvGameLog.DataKeys[gvr.RowIndex].Value.ToString()),
						new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
					};

					try
					{
						SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_S_CustomizeMonitoredMember_New", arParms);
						effRows += 1;
					}
					catch (Exception ex)
					{
						GFC.Web.WebUtility.ResponseScript(Page, "alert('" + ex.Message + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					}
				}
			}
			this.LoadData();
			GFC.Web.WebUtility.ResponseScript(Page, "alert('" + string.Format("新增 {0} 會員自訂監控完成", effRows.ToString()) + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		/// <summary>
		/// 設定全選選項
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void gvDataBound(object sender, EventArgs e)
		{
			GridView gv = sender as GridView;
			if (gv.HeaderRow==null)
			{
				return;
			}
			(gv.HeaderRow.Cells[gv.Columns.Count - 1].FindControl("cbAllSelect") as CheckBox).Enabled = gv.Rows.Count != 0;
				
		}


	}
}