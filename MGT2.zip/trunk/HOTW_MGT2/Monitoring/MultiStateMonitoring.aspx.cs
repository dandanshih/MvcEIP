﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;
using GFC.Web.WebControls;
using System.Linq;

namespace GWeb.Monitoring
{
	public partial class MultiStateMonitoring : GWeb.AppLibs.FormBase
	{
		#region Property
		private DataTable SourceDataTable;

		private DataTable TopDataTable;

		private DataTable SecDataTable;

		private DataTable ThirdDataTable;
		#endregion

		#region private
		
		private void BindData(string GameID)
		{
			lblTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

			SqlParameter[] param =
			{
			    new SqlParameter("@GameID", GameID),
				new SqlParameter("@InSeatNum", DbType.Int32),
				new SqlParameter("@ToolsNum", DbType.Int32),
				new SqlParameter("@EmptySeatNum", DbType.Int32)
				//new SqlParameter("@ObserveNum", DbType.Int32)
			};

			param[1].Direction = ParameterDirection.Output;
			param[2].Direction = ParameterDirection.Output;
			param[3].Direction = ParameterDirection.Output;
			//param[4].Direction = ParameterDirection.Output;

			
			//lblViewCountValue.Text = param[4].Value.ToString();
			InitialDataTable(ref SourceDataTable);
			SourceDataTable = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_EGameMoniter_TableData",
				param
			).Tables[0];

			lblInSeatCountValue.Text = param[1].Value.ToString();
			lblTestToolValue.Text = param[2].Value.ToString();
			lblEmptySeatCountValue.Text = param[3].Value.ToString();

			// 建立欄位
			InitialDataTable(ref TopDataTable);

			IEnumerable<IGrouping<string, DataRow>> result = SourceDataTable.Rows.Cast<DataRow>().GroupBy<DataRow, string>(dr => dr["GroupID"].ToString());
			foreach (IGrouping<string, DataRow> group in result)
			{
				TopDataTable.Rows.Add(group.ElementAt(0).ItemArray);
				//TopDataTable.LoadDataRow(group.ElementAt(0).ItemArray, true);
			}
			rpt_Top.DataSource = TopDataTable;
			rpt_Top.DataBind();
		}

		private void InitialDataTable(ref DataTable dt)
		{
			// dt.Clear();
			dt = new DataTable();
			dt.Columns.Add("RowNo", typeof(int));
			dt.Columns.Add("MachineNo", typeof(int));
			dt.Columns.Add("MemberAccount", typeof(string));
			dt.Columns.Add("LastBet", typeof(decimal));
			dt.Columns.Add("Rounds", typeof(string));
			dt.Columns.Add("DayWinlose", typeof(decimal));
			dt.Columns.Add("WeekWinlose", typeof(decimal));
			dt.Columns.Add("MonthWinlose", typeof(decimal));
			dt.Columns.Add("IsTools", typeof(bool));
			dt.Columns.Add("AreaEName", typeof(string));
			dt.Columns.Add("TableID", typeof(int));
			dt.Columns.Add("NickName", typeof(string));
			dt.Columns.Add("GroupID", typeof(int));
			dt.Columns.Add("MemberID", typeof(int));
		}

		private DataTable BindSecData(int GroupID)
		{
			DataTable tmpdt = new DataTable();
			InitialDataTable(ref tmpdt);
			InitialDataTable(ref SecDataTable);
			string RowFilter = string.Format("GroupID={0}", GroupID);
			tmpdt = new DataView(SourceDataTable, RowFilter, "TableID", DataViewRowState.CurrentRows).ToTable();

			IEnumerable<IGrouping<string, DataRow>> result = tmpdt.Rows.Cast<DataRow>().GroupBy<DataRow, string>(dr => dr["TableID"].ToString());
			foreach (IGrouping<string, DataRow> group in result)
			{
				SecDataTable.LoadDataRow(group.ElementAt(0).ItemArray, true);
			}
			return SecDataTable;
		}

		private DataTable BindThirdData(int GroupID, int TableID)
		{
			InitialDataTable(ref ThirdDataTable);
			string RowFilter = string.Format("GroupID={0} AND TableID={1}", GroupID, TableID);
			ThirdDataTable = new DataView(SourceDataTable, RowFilter, "MachineNo", DataViewRowState.CurrentRows).ToTable();

			return ThirdDataTable;
		}

		/// <summary>
		/// 建立TreeViewm。
		/// </summary>
		private void InitTree()
		{
			TreeView1.Nodes.Clear();

			Int32 TotalMembers = 0;
			// 建立與設定【根結點】相關屬性內容
			EO.Web.TreeNode RootNode = new EO.Web.TreeNode();

			RootNode.Value = "0";
			RootNode.PopulateOnDemand = false;
			RootNode.Expanded = true;
			RootNode.PopulateOnDemand = true;
			TreeView1.Nodes.Add(RootNode);
			List<EO.Web.TreeNode> lstChilds = new List<EO.Web.TreeNode>();

			SqlParameter[] arParms =
			{
			    new SqlParameter("@GameTypeID", 3)
			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GameMonitor_GameList", arParms);
			while (sdr.Read())
			{
				EO.Web.TreeNode childNode = new EO.Web.TreeNode();
                try
                {
                    childNode.Text = string.Format("{0}(目前人數:{1})", Utility.GetGameENameMapping(sdr["GameEName"].ToString()).ToString(), sdr["PlayerNum"].ToString());

                }
                catch (Exception)
                {
                    childNode.Text = string.Format("{0}(目前人數:{1})", sdr["GameEName"].ToString(), sdr["PlayerNum"].ToString());
                }
                childNode.Value = sdr["GameID"].ToString();

				TotalMembers += Int32.Parse(sdr["PlayerNum"].ToString());
				lstChilds.Add(childNode);
			}
			RootNode.Expanded = RootNode.ChildNodes.Count == 0 ? false : true;
			RootNode.PopulateOnDemand = RootNode.ChildNodes.Count == 0 ? false : true;
			sdr.Close();

			//RootNode.Text = "遊戲列表(目前總人數:" + TotalMembers.ToString() + ")";
			RootNode.Text = "遊戲列表";
			RootNode.ChildNodes.AddRange(lstChilds);

            if (TreeView1.Nodes[0].ChildNodes.Count > 0)
            {
                //TreeView1.Nodes[0].ChildNodes[0].Selected = true;
                TreeView1.ExpandAll();
            }
		}

		#endregion

		#region protected

		protected void TreeView1_ItemClick(object sender, EO.Web.NavigationItemEventArgs e)
		{
			// 產生相對應的群組資料
            //InitTree();
			BindData(e.TreeNode.Value);
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				InitTree();
				//Timer1.Enabled = btnRefresh.Visible;
                if (TreeView1.Nodes[0].ChildNodes.Count != 0)
                {
                    //TreeView1.Nodes[0].ChildNodes[0].Selected = true;
                    TreeView1.ExpandAll();
                    this.BindData(TreeView1.Nodes[0].ChildNodes[0].Value);
                }
                else
                {
                    this.BindData("0");
                }
			}
		}

		protected void btnRefresh_Click(object sender, EventArgs e)
		{
			// 如果有選擇遊戲才產生 Tree
			if (TreeView1.SelectedNodes.Length > 0)
			{
				// 產生相對應的群組資料
				BindData(TreeView1.SelectedNode.Value);			
			}
		}

		protected void Timer1_Tick(object sender, EventArgs e)
		{
            this.InitTree();
            if (TreeView1.Nodes[0].ChildNodes.Count > 0 && TreeView1.SelectedNode !=null)
            {
                // 產生相對應的群組資料
                BindData(TreeView1.SelectedNode.Value);
            }
            else
            {
                BindData("0"); 
            }
		}

		protected void rpt_Top_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				Literal lit = (Literal)e.Item.FindControl("lit_TopGroupID");
				Repeater rpt = (Repeater)e.Item.FindControl("rpt_Sec");
				int GroupID = int.Parse(lit.Text);
				rpt.DataSource = BindSecData(GroupID);
				rpt.DataBind();
			}
		}

		protected void rpt_Sec_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				Literal lit_SecGroupID = (Literal)e.Item.FindControl("lit_SecGroupID");
				Literal lit_TableID = (Literal)e.Item.FindControl("lit_TableID");

				TBGridView gv = (TBGridView)e.Item.FindControl("gv_Third");
				int GroupID = int.Parse(lit_SecGroupID.Text);
				int TableID = int.Parse(lit_TableID.Text);
				gv.DataSource = BindThirdData(GroupID, TableID);
				gv.DataBind();
			}
		}

		protected void gv_Third_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				TBGridView gv = (TBGridView)sender;
				if (Convert.ToBoolean(gv.DataKeys[e.Row.DataItemIndex]["IsTools"]))
				{
					e.Row.BackColor = System.Drawing.Color.Red;
				}
			}
		}
		#endregion
	}
}