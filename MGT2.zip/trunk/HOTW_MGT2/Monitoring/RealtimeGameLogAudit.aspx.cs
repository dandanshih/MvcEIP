﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Monitoring
{
	public partial class RealtimeGameLogAudit : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				//DatePicker1.SelectedDate = DateTime.Now.
				//Timer1.Enabled = btnRefresh.Visible = false;
                Timer1.Enabled = false;
			}
		}
		protected void QueryClick(object sender, EventArgs e)
		{
			this.LoadData();
			this.LoadDataU();
		}
		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			#region 電子遊戲
			SqlParameter[] arParms =
			{
				new SqlParameter("@StartDate",UCDateRange1.StartDate),
				new SqlParameter("@GameAreaType","2"),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};


			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_RealTimeWinlose_Game", arParms);
			gvElectronicGameLog.DataSource = sdr;
			gvElectronicGameLog.DataBind();
			sdr.Close();
			#endregion 電子遊戲
			#region 對戰遊戲
			SqlParameter[] arParms2 =
			{
				new SqlParameter("@StartDate",UCDateRange1.StartDate),
				new SqlParameter("@GameAreaType","2"),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};


			SqlDataReader sdr2 = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_RealTimeWinlose_MultiPlayer", arParms2);
			gvMutilGameLog.DataSource = sdr2;
			gvMutilGameLog.DataBind();
			sdr2.Close();
			#endregion 對戰遊戲
			
			lblTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadDataU()
		{
			#region 電子遊戲
			SqlParameter[] arParms =
			{
				new SqlParameter("@StartDate",UCDateRange1.StartDate),
				new SqlParameter("@GameAreaType","1"),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};


			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_RealTimeWinlose_Game", arParms);
			gvElectronicGameLogU.DataSource = sdr;
			gvElectronicGameLogU.DataBind();
			sdr.Close();
			#endregion 電子遊戲
			#region 對戰遊戲
			SqlParameter[] arParms2 =
			{
				new SqlParameter("@StartDate",UCDateRange1.StartDate),
				new SqlParameter("@GameAreaType","1"),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};


			SqlDataReader sdr2 = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_RealTimeWinlose_MultiPlayer", arParms2);
			gvMutilGameLogU.DataSource = sdr2;
			gvMutilGameLogU.DataBind();
			sdr2.Close();
			#endregion 對戰遊戲

			lblTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
		}

		/// <summary>
		/// 計時器事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Timer1_Tick(object sender, EventArgs e)
		{
			LoadData();
			LoadDataU();
		}
		protected void btnRefresh_Click(object sender, EventArgs e)
		{
            Timer1.Enabled = true;
			this.LoadData();
			this.LoadDataU();
		}

		/// <summary>
		/// 電子遊戲加入標題
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ElectronicRowCreated(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.Header)
			{
				GridView oGridView = (GridView)sender;
				GridViewRow oGridViewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
				oGridViewRow.Style.Add(HtmlTextWriterStyle.Height, "6px");
				TableCell oTableCell;

				for (int i = 0; i < gvElectronicGameLog.Columns.Count; i++)
				{
					oTableCell = new TableCell();
					oTableCell.BorderWidth = Unit.Pixel(1);
					oTableCell.BorderStyle = BorderStyle.Inset;
					oTableCell.Text = Convert.ToChar(65 + i).ToString();
					oGridViewRow.Cells.Add(oTableCell);
				}
				oGridView.Controls[0].Controls.AddAt(0, oGridViewRow);
			}
		}

		/// <summary>
		/// 對戰遊戲加入標題
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void MutilRowCreated(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.Header)
			{
				GridView oGridView = (GridView)sender;
				GridViewRow oGridViewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
				oGridViewRow.Style.Add(HtmlTextWriterStyle.Height, "6px");
				TableCell oTableCell;

				for (int i = 0; i < oGridView.Columns.Count; i++)
				{
					oTableCell = new TableCell();
					oTableCell.BorderWidth = Unit.Pixel(1);
					oTableCell.BorderStyle = BorderStyle.Inset;
					oTableCell.Text = Convert.ToChar(65 + i).ToString();
					oGridViewRow.Cells.Add(oTableCell);
				}
				oGridView.Controls[0].Controls.AddAt(0, oGridViewRow);
			}
		}
		/// <summary>
		/// 電子遊戲總計
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ElectronicRowDataBound(object sender, EventArgs e)
		{

			// 統計每個欄位的加總值
			// 並且將其小數部份去掉
			GridView grdTmp = (GridView)sender;

			if (grdTmp.Rows.Count == 0)
			{
				return;
			}

			decimal[] Summary = new decimal[grdTmp.Columns.Count];
			int[] CalculateColumns = { 2, 3, 4, 5 };
			decimal dTmp = 0;

			foreach (GridViewRow Rows in grdTmp.Rows)
			{
				try
				{
                    Rows.Cells[0].Text = Utility.GetGameENameMapping(Rows.Cells[0].Text).ToString();
				}
				catch
				{
					Rows.Cells[0].Text = Rows.Cells[0].Text;
				}
				if (grdTmp.DataKeys[Rows.RowIndex].Value.ToString().Equals("1"))
				{
					Rows.BackColor = System.Drawing.Color.Pink;
				}
				if (Decimal.Parse(Rows.Cells[3].Text) < 0)
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Blue;
				}
				if (Decimal.Parse(Rows.Cells[5].Text) < 0)
				{
					Rows.Cells[5].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[5].ForeColor = System.Drawing.Color.Blue;
				}
				foreach (int iCells in CalculateColumns)
				{
					if (Decimal.TryParse(Rows.Cells[iCells].Text, out dTmp))
					{
						Rows.Cells[iCells].Text = dTmp.ToString("N0");
						Summary[iCells] += dTmp;
					}
				}
			}

			
			for (int i = 1; i < grdTmp.FooterRow.Cells.Count; i++)
			{
				grdTmp.FooterRow.Cells[i].Text = Summary[i].ToString("N0");
				if (Summary[i] < 0)
				{
					grdTmp.FooterRow.Cells[i].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					grdTmp.FooterRow.Cells[i].ForeColor = System.Drawing.Color.White;
				}
			}
		}
		/// <summary>
		/// 對戰遊戲總計
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void MutileRowDataBound(object sender, EventArgs e)
		{

			// 統計每個欄位的加總值
			// 並且將其小數部份去掉
			GridView grdTmp = (GridView)sender;

			if (grdTmp.Rows.Count <= 1)
			{
				return;
			}

			decimal[] Summary = new decimal[grdTmp.Columns.Count];
			int[] CalculateColumns = { 1, 2, 3, 4 };
			decimal dTmp = 0;

			foreach (GridViewRow Rows in grdTmp.Rows)
			{
				try
				{
                    Rows.Cells[0].Text = Utility.GetGameENameMapping(Rows.Cells[0].Text).ToString();
				}
				catch
				{
					Rows.Cells[0].Text = Rows.Cells[0].Text;
				}
				if (grdTmp.DataKeys[Rows.RowIndex].Value.ToString().Equals("1"))
				{
					Rows.BackColor = System.Drawing.Color.Pink;
				}
				if (Decimal.Parse(Rows.Cells[2].Text) < 0)
				{
					Rows.Cells[2].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[2].ForeColor = System.Drawing.Color.Blue;
				}
				if (Decimal.Parse(Rows.Cells[3].Text) < 0)
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Blue;
				}
				if (Decimal.Parse(Rows.Cells[4].Text) < 0)
				{
					Rows.Cells[4].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[4].ForeColor = System.Drawing.Color.Blue;
				}
				foreach (int iCells in CalculateColumns)
				{
					if (Decimal.TryParse(Rows.Cells[iCells].Text, out dTmp))
					{
						Rows.Cells[iCells].Text = dTmp.ToString("N0");
						Summary[iCells] += dTmp;
					}
					if (Summary[iCells] < 0)
					{
						grdTmp.FooterRow.Cells[iCells].ForeColor = System.Drawing.Color.Red;
					}
					else
					{
						grdTmp.FooterRow.Cells[iCells].ForeColor = System.Drawing.Color.White; // System.Drawing.Color.White;
					}
				}
			}

			
			for (int i = 1; i < grdTmp.FooterRow.Cells.Count; i++)
			{
				grdTmp.FooterRow.Cells[i].Text = Summary[i].ToString("N0");
			}
		}

		/// <summary>
		/// 電子遊戲加入標題
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ElectronicURowCreated(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.Header)
			{
				GridView oGridView = (GridView)sender;
				GridViewRow oGridViewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
				oGridViewRow.Style.Add(HtmlTextWriterStyle.Height, "6px");
				TableCell oTableCell;

				for (int i = 0; i < gvElectronicGameLog.Columns.Count; i++)
				{
					oTableCell = new TableCell();
					oTableCell.BorderWidth = Unit.Pixel(1);
					oTableCell.BorderStyle = BorderStyle.Inset;
					oTableCell.Text = Convert.ToChar(65 + i).ToString();
					oGridViewRow.Cells.Add(oTableCell);
				}
				oGridView.Controls[0].Controls.AddAt(0, oGridViewRow);
			}
		}

		/// <summary>
		/// 對戰遊戲加入標題
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void MutilURowCreated(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.Header)
			{
				GridView oGridView = (GridView)sender;
				GridViewRow oGridViewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
				oGridViewRow.Style.Add(HtmlTextWriterStyle.Height, "6px");
				TableCell oTableCell;

				for (int i = 0; i < oGridView.Columns.Count; i++)
				{
					oTableCell = new TableCell();
					oTableCell.BorderWidth = Unit.Pixel(1);
					oTableCell.BorderStyle = BorderStyle.Inset;
					oTableCell.Text = Convert.ToChar(65 + i).ToString();
					oGridViewRow.Cells.Add(oTableCell);
				}
				oGridView.Controls[0].Controls.AddAt(0, oGridViewRow);
			}
		}
		/// <summary>
		/// 電子遊戲總計
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ElectronicURowDataBound(object sender, EventArgs e)
		{

			// 統計每個欄位的加總值
			// 並且將其小數部份去掉
			GridView grdTmp = (GridView)sender;

			if (grdTmp.Rows.Count == 0)
			{
				return;
			}

			decimal[] Summary = new decimal[grdTmp.Columns.Count];
			int[] CalculateColumns = { 2, 3, 4, 5 };
			decimal dTmp = 0;

			foreach (GridViewRow Rows in grdTmp.Rows)
			{
				try
				{
					Rows.Cells[0].Text = Utility.GetGameENameMapping(Rows.Cells[0].Text).ToString();
				}
				catch
				{
					Rows.Cells[0].Text = Rows.Cells[0].Text;
				}
				if (grdTmp.DataKeys[Rows.RowIndex].Value.ToString().Equals("1"))
				{
					Rows.BackColor = System.Drawing.Color.Pink;
				}
				if (Decimal.Parse(Rows.Cells[3].Text) < 0)
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Blue;
				}
				if (Decimal.Parse(Rows.Cells[5].Text) < 0)
				{
					Rows.Cells[5].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[5].ForeColor = System.Drawing.Color.Blue;
				}
				foreach (int iCells in CalculateColumns)
				{
					if (Decimal.TryParse(Rows.Cells[iCells].Text, out dTmp))
					{
						Rows.Cells[iCells].Text = dTmp.ToString("N0");
						Summary[iCells] += dTmp;
					}
				}
			}


			for (int i = 1; i < grdTmp.FooterRow.Cells.Count; i++)
			{
				grdTmp.FooterRow.Cells[i].Text = Summary[i].ToString("N0");
				if (Summary[i] < 0)
				{
					grdTmp.FooterRow.Cells[i].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					grdTmp.FooterRow.Cells[i].ForeColor = System.Drawing.Color.White;
				}
			}
		}
		/// <summary>
		/// 對戰遊戲總計
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void MutileURowDataBound(object sender, EventArgs e)
		{

			// 統計每個欄位的加總值
			// 並且將其小數部份去掉
			GridView grdTmp = (GridView)sender;

			if (grdTmp.Rows.Count <= 1)
			{
				return;
			}

			decimal[] Summary = new decimal[grdTmp.Columns.Count];
			int[] CalculateColumns = { 1, 2, 3, 4 };
			decimal dTmp = 0;

			foreach (GridViewRow Rows in grdTmp.Rows)
			{
				try
				{
					Rows.Cells[0].Text = Utility.GetGameENameMapping(Rows.Cells[0].Text).ToString();
				}
				catch
				{
					Rows.Cells[0].Text = Rows.Cells[0].Text;
				}
				if (grdTmp.DataKeys[Rows.RowIndex].Value.ToString().Equals("1"))
				{
					Rows.BackColor = System.Drawing.Color.Pink;
				}
				if (Decimal.Parse(Rows.Cells[2].Text) < 0)
				{
					Rows.Cells[2].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[2].ForeColor = System.Drawing.Color.Blue;
				}
				if (Decimal.Parse(Rows.Cells[3].Text) < 0)
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[3].ForeColor = System.Drawing.Color.Blue;
				}
				if (Decimal.Parse(Rows.Cells[4].Text) < 0)
				{
					Rows.Cells[4].ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					Rows.Cells[4].ForeColor = System.Drawing.Color.Blue;
				}
				foreach (int iCells in CalculateColumns)
				{
					if (Decimal.TryParse(Rows.Cells[iCells].Text, out dTmp))
					{
						Rows.Cells[iCells].Text = dTmp.ToString("N0");
						Summary[iCells] += dTmp;
					}
					if (Summary[iCells] < 0)
					{
						grdTmp.FooterRow.Cells[iCells].ForeColor = System.Drawing.Color.Red;
					}
					else
					{
						grdTmp.FooterRow.Cells[iCells].ForeColor = System.Drawing.Color.White; // System.Drawing.Color.White;
					}
				}
			}


			for (int i = 1; i < grdTmp.FooterRow.Cells.Count; i++)
			{
				grdTmp.FooterRow.Cells[i].Text = Summary[i].ToString("N0");
			}
		}
	}
}