﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Monitoring
{
	public partial class ExceptionalState : GWeb.AppLibs.FormBase
	{
		#region private

		/// <summary>
		/// 讀取異常狀態。
		/// </summary>
		private void LoadExceptionalState()
		{
            if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
            {
                //UCDateRange1.StartDate = DateTime.Today.AddDays(-1).ToString("yyyy/MM/dd 12:00:00");
                WebUtility.ResponseScript(Page, "alert('只能查詢2個月內的記錄!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                return;
            }
            
            SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords", DbType.Int32),
                new SqlParameter("@Languages", System.Threading.Thread.CurrentThread.CurrentUICulture.Name.Replace("-", "").ToUpper())
                
			};

			param[4].Direction = ParameterDirection.Output;

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_UnusualStatusQry",
														   param);

			gvExceptionalState.DataSource = objDtr;
			gvExceptionalState.DataBind();

			objDtr.Close();

			UCPager1.RecordCount = int.Parse(param[4].Value.ToString());
			UCPager1.DataBind();
		}		

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
            //if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
            //{
            //    WebUtility.ResponseScript(Page, "alert('只能查詢2個月內的記錄!');", WebUtility.ResponseScriptPlace.NearFormEnd);
            //    return;
            //}
            //else
            //{
            //    LoadExceptionalState();
            //}
		}

		protected void UCDateRange1_Change(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
            //if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
            //    return;
			UCPager1.CurrentPageNumber = 1;
			LoadExceptionalState();
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
            if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
            {
                //UCDateRange1.StartDate = DateTime.Today.AddDays(-1).ToString("yyyy/MM/dd 12:00:00");
                WebUtility.ResponseScript(Page, "alert('只能查詢2個月內的記錄!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                return;
            }			
            UCPager1.CurrentPageNumber = 1;
			LoadExceptionalState();
		}

		protected void UCPager1_Change(object sender, GWeb.AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadExceptionalState();
		}

		#endregion
	}
}