﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Monitoring
{
	public partial class CustomizeMonitoring : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				#region 遊戲下拉選單
				SqlParameter[] param =
				{
					new SqlParameter("@ListType", "1"),
					new SqlParameter("@GameTypeID", "0"),
					new SqlParameter("@GameID", "0")
				};

				SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
																CommandType.StoredProcedure,
																"NSP_AgentWeb_G_GetGameList",
																param);

				ddlGame.DataTextField = "ListName";
				ddlGame.DataValueField = "ListID";
				ddlGame.DataSource = objDtr;
				ddlGame.DataBind();
				objDtr.Close();

				ddlGame.Items.Insert(0, new ListItem("全部", "0"));
				ddlGame.SelectedValue = "0";
				#endregion 遊戲下拉選單

				ddlOperator.Enabled = false;
				txtConditionalValue.Enabled = false;
				rblCondictionType.SelectedValue = "0";
				rfvConditionalValue.EnableClientScript = false;
				rfvConditionalValue.Enabled = false;
				btnCancelAllCustomizeMonitoring.Enabled = false;
			}
		}


		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@GameID",ddlGame.SelectedValue),
				new SqlParameter("@WinloseType",rblCondictionType.SelectedValue),
				new SqlParameter("@ConditionType",rblCondictionType.SelectedValue!="0"?ddlOperator.SelectedValue:"1"),
				new SqlParameter("@ConditionValue",rblCondictionType.SelectedValue!="0"?txtConditionalValue.Text:"0")
			};



			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_CustomizeGameMonitor", arParms);

			gvCustomizeMonitoring.DataSource = sdr;
			gvCustomizeMonitoring.DataBind();
			sdr.Close();


		}

		/// <summary>
		/// 按下查詢按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			//if (txtConditionalValue.Text.Trim().Length == 0 && rblCondictionType.SelectedValue!="0")
			//{
			//    return;
			//}
			this.LoadData();
		}

		/// <summary>
		/// 按下取消全部清除按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnCancelAllCustomizeMonitoring_click(object sender, EventArgs e)
		{

			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID","0"),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_S_CustomizeMonitoredMember_Delete", arParms);


			this.LoadData();
		}

		/// <summary>
		/// GridView上的按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void RowButtonClick(object sender, EventArgs e)
		{
			Button btn = sender as Button;

			switch (btn.CommandName)
			{
				case "KickMember":
					//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(btn.CommandArgument), int.Parse(AUser.ExecAgentID));
					//Utility.SendInfoToFrontServer(AUser.FrontServerIP, string.Format("267&95&{0}&0", btn.CommandArgument));

					// 20110509 Phil: 改對前台發出登出命令
					GameCommandHandler.LogoutMember(int.Parse(btn.CommandArgument));

					break;
				case "CancelCustomizeMonitoringResource":
					SqlParameter[] arParms2 =
					{
						new SqlParameter("@MemberID",btn.CommandArgument),
						new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
					};

					SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_S_CustomizeMonitoredMember_Delete", arParms2);
					break;
			}
			this.LoadData();
		}

		protected void rblCondictionTypeSelectChange(object sender, EventArgs e)
		{
			ddlOperator.Enabled = rblCondictionType.SelectedValue != "0";
			txtConditionalValue.Enabled = rblCondictionType.SelectedValue != "0";
			rfvConditionalValue.EnableClientScript = rblCondictionType.SelectedValue != "0";
			rfvConditionalValue.Enabled = rblCondictionType.SelectedValue != "0";
		}

		protected void gvRowDataBound(object sender, GridViewRowEventArgs e)
		{
			//遊戲名稱語系
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				try
				{
					e.Row.Cells[9].Text = Utility.GetGameENameMapping(e.Row.Cells[9].Text).ToString();
				}
				catch
				{ }
			}
		}

		protected void gvDataBound(object sender, EventArgs e)
		{
			btnCancelAllCustomizeMonitoring.Enabled = gvCustomizeMonitoring.Rows.Count != 0;
		}

		protected void onticker(object sender, EventArgs e)
		{
			this.LoadData();
		}
	}


}