﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC;

namespace GWeb.Monitoring
{
	public partial class UCMultiStateMonitoring : GWeb.AppLibs.UCBase
	{
		#region class

		private class UserDataInfo
		{
			/// <summary>
			/// 座位。
			/// </summary>
			public string Seat { get; set; }

			/// <summary>
			/// 帳號。
			/// </summary>
			public string MemberAccount { get; set; }

			/// <summary>
			/// 會員編號。
			/// </summary>
			public string MemberID { get; set; }

			/// <summary>
			/// 身分。
			/// </summary>
			public string MemberGroup { get; set; }

			/// <summary>
			/// 是否莊家。
			/// </summary>
			public string IsBanker { get; set; }

			/// <summary>
			/// 本日輸贏。
			/// </summary>
			public string Today { get; set; }

			/// <summary>
			/// 本周輸贏。
			/// </summary>
			public string ThisWeek { get; set; }

			/// <summary>
			/// 本月輸贏。
			/// </summary>
			public string ThisMonth { get; set; }

			/// <summary>
			/// 下局中獎。
			/// </summary>
			public string NextRoundPrize { get; set; }
		}
			
		#endregion

		#region property

		/// <summary>
		/// 群組編號。
		/// </summary>
		public string GroupID { get; set; }

		/// <summary>
		/// 桌號。
		/// </summary>
		public string TableID { get; set; }

		/// <summary>
		/// 最低押注。
		/// </summary>
		public string Smallest { get; set; }

		/// <summary>
		///  TableData。
		/// </summary>
		public string TableData { get; set; }

		/// <summary>
		///  UserData。
		/// </summary>
		public string UserData { get; set; }

		#endregion

		#region private

		/// <summary>
		/// 拆出最小押注。
		/// </summary>
		private void LoadTableData()
		{
			// 範例 TP203317176AA>|<200+_+200>|<0+_+30+_+1+_+0+_+2+_+0
			// =======================================================

			string[] tableData = TableData.Split(">|<");
            this.Smallest = tableData[1].Split("+_+")[0].ToString();
			lblSmallestValue.Text = tableData[1].Split("+_+")[0].ToString();
		}

		/// <summary>
		/// 拆出玩家資訊。
		/// </summary>
		private void LoadUserData()
		{
			// 範例 0+_+philrd01+_+27944+_+1+_+1+_+-100+_+-300+_+-300+_+-1>|<1+_+philrd02+_+27945+_+1+_+0+_+-100+_+-300+_+-300+_+-1
			// ====================================================================================================================
			// 玩家 = 0座位+_+1帳號+_+2會員編號+_+3身分+_+4是否莊家+_+5日輸贏+_+6周輸贏+_+7月輸贏+_+8下局中獎    


            // 正確版格式: 2011/05/24
            // 0座位+_+1帳號+_+2會員編號+_+3身分+_+4是否莊家+_+5目前期望值+_+6目標期望值+_+7日輸贏+_+8周輸贏+_+9月輸贏+_+10下局中獎

			lblGroupAndTable.Text = GroupID + " - " + TableID;
			lblSmallestValue.Text = Smallest;

			UserDataInfo udi;
			List<UserDataInfo> lUdi = new List<UserDataInfo>();

			string[] Users = UserData.Split(">|<");

			foreach (string user in Users)
			{
				string[] data = user.Split("+_+");

				udi = new UserDataInfo();
				udi.Seat = data[0];
				udi.MemberAccount = (data[1] == "1" ? "*" : "") + data[1];
				udi.MemberID = data[2];
				udi.MemberGroup = data[3];
				udi.IsBanker = data[4];
				//udi.Today = data[5];
                //udi.ThisWeek = data[6];
                //udi.ThisMonth = data[7];
                //udi.NextRoundPrize = data[8] == "" ? "-1" : data[8];
                udi.Today = data[7];
                udi.ThisWeek = data[8];
				udi.ThisMonth = data[9];
				udi.NextRoundPrize = data[10] == "" ? "-1" : data[8];
				lUdi.Add(udi);
			}

			gvUserData.DataSource = lUdi;
			gvUserData.DataBind();
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			// 最小押注
			LoadTableData();

			if (UserData != "")
			{
				try
				{
					// 玩家資訊
					LoadUserData();
				}
				catch
				{ 
				
				}				
			}
		}

		protected void gvUserData_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			//MemberGroup=0 -->一般玩家
            //MemberGroup=1 -->黑名單
            //MemberGroup=2 -->測試工具
            if (e.Row.RowType == DataControlRowType.DataRow)
			{
				if (DataBinder.Eval(e.Row.DataItem, "MemberGroup").ToString()=="2")
				{
					e.Row.BackColor = System.Drawing.Color.Red;
				}
			}
		}

		#endregion		
	}
}