﻿//-----------------------------------------------------------------------
// <copyright file="B302.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Monitoring
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;
    using GWeb.Models;

    /// <summary>
    /// 儲值記錄
    /// </summary>
    public partial class B302 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                this.UCDateRange1.EndDate = DateTime.Now.ToString();
                this.UCDateRange1.StartDate = DateTime.Now.AddDays(-1).ToString();
                this.BindData();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 計時器
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_WorthCard_Change(object sender, EventArgs e)
        {
            this.BindWorthCardData();
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_Transfer_Change(object sender, EventArgs e)
        {
            this.BindTransferData();
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_Winlose_Change(object sender, EventArgs e)
        {
            this.BindWinloseData();
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_Points_Change(object sender, EventArgs e)
        {
            this.BindPointsData();
        }

        /// <summary>
        /// 顯示文字顏色
        /// </summary>
        /// <param name="inputValue">判斷值</param>
        /// <returns>文字顏色</returns>
        protected System.Drawing.Color ShowForeColor(object inputValue)
        {
            return Convert.ToDecimal(inputValue) >= 0 ? System.Drawing.Color.Blue : System.Drawing.Color.Red;
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            this.BindWorthCardData();
            this.BindTransferData();
            this.BindWinloseData();
            this.BindPointsData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindWorthCardData()
        {
            int take = this.UCPager_WorthCard.PageSize;
            int skip = (this.UCPager_WorthCard.CurrentPageNumber - 1) * take;
            var data = this.GetWorthCardData().ToList();

            // 繫結UCPager_WorthCard
            this.UCPager_WorthCard.RecordCount = data.Count();
            this.UCPager_WorthCard.DataBind();

            // 繫結GV_WorthCard
            this.GV_WorthCard.DataSource = data
                .OrderBy(x => x.SID)
                .Skip(skip)
                .Take(take);
            this.GV_WorthCard.DataBind();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindTransferData()
        {
            int take = this.UCPager_Transfer.PageSize;
            int skip = (this.UCPager_Transfer.CurrentPageNumber - 1) * take;
            var data = this.GetTransferData().ToList();

            // 繫結UCPager_Transfer
            this.UCPager_Transfer.RecordCount = data.Count();
            this.UCPager_Transfer.DataBind();

            // 繫結GV_Transfer
            this.GV_Transfer.DataSource = data
                .OrderBy(x => x.SID)
                .Skip(skip)
                .Take(take);
            this.GV_Transfer.DataBind();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindWinloseData()
        {
            int take = this.UCPager_Winlose.PageSize;
            int skip = (this.UCPager_Winlose.CurrentPageNumber - 1) * take;
            var data = this.GetWinloseData().ToList();

            // 繫結UCPager_Winlose
            this.UCPager_Winlose.RecordCount = data.Count();
            this.UCPager_Winlose.DataBind();

            // 繫結GV_Winlose
            this.GV_Winlose.DataSource = data
                .OrderBy(x => x.SID)
                .Skip(skip)
                .Take(take);
            this.GV_Winlose.DataBind();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindPointsData()
        {
            int take = this.UCPager_Points.PageSize;
            int skip = (this.UCPager_Points.CurrentPageNumber - 1) * take;
            var data = this.GetPointsData().ToList();

            // 繫結UCPager_Points
            this.UCPager_Points.RecordCount = data.Count();
            this.UCPager_Points.DataBind();

            // 繫結GV_Points
            this.GV_Points.DataSource = data
                .OrderBy(x => x.SID)
                .Skip(skip)
                .Take(take);
            this.GV_Points.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_MonitorReport_WorthCard_Result> GetWorthCardData()
        {
            return this.game_branch.Database.SqlQuery<NSP_MonitorReport_WorthCard_Result>(
                "exec NSP_MonitorReport_WorthCard @StartDate, @EndDate",
                new SqlParameter("@StartDate", this.UCDateRange1.StartDate),
                new SqlParameter("@EndDate", this.UCDateRange1.EndDate));
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_MonitorReport_Transfer_Result> GetTransferData()
        {
            return this.game_branch.Database.SqlQuery<NSP_MonitorReport_Transfer_Result>(
                "exec NSP_MonitorReport_Transfer @StartDate, @EndDate",
                new SqlParameter("@StartDate", this.UCDateRange1.StartDate),
                new SqlParameter("@EndDate", this.UCDateRange1.EndDate));
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_MonitorReport_Winlose_Result> GetWinloseData()
        {
            return this.game_branch.Database.SqlQuery<NSP_MonitorReport_Winlose_Result>(
                "exec NSP_MonitorReport_Winlose @StartDate, @EndDate",
                new SqlParameter("@StartDate", this.UCDateRange1.StartDate),
                new SqlParameter("@EndDate", this.UCDateRange1.EndDate));
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_MonitorReport_Points_Result> GetPointsData()
        {
            return this.game_branch.Database.SqlQuery<NSP_MonitorReport_Points_Result>(
                "exec NSP_MonitorReport_Points @StartDate, @EndDate",
                new SqlParameter("@StartDate", this.UCDateRange1.StartDate),
                new SqlParameter("@EndDate", this.UCDateRange1.EndDate));
        }

        /// <summary>
        /// NSP_MonitorReport_WorthCard 回傳類別
        /// </summary>
        private class NSP_MonitorReport_WorthCard_Result
        {
            /// <summary>
            /// Gets or sets SID
            /// </summary>
            public long SID { get; set; }

            /// <summary>
            /// Gets or sets ModifedDate
            /// </summary>
            public string ModifedDate { get; set; }

            /// <summary>
            /// Gets or sets TotalValue
            /// </summary>
            public int TotalValue { get; set; }

            /// <summary>
            /// Gets or sets TotalCount
            /// </summary>
            public int TotalCount { get; set; }

            /// <summary>
            /// Gets or sets DiffValue
            /// </summary>
            public int DiffValue { get; set; }
        }

        /// <summary>
        /// NSP_MonitorReport_Transfer 回傳類別
        /// </summary>
        private class NSP_MonitorReport_Transfer_Result
        {
            /// <summary>
            /// Gets or sets SID
            /// </summary>
            public long SID { get; set; }

            /// <summary>
            /// Gets or sets LastActionDate
            /// </summary>
            public string LastActionDate { get; set; }

            /// <summary>
            /// Gets or sets TotalPoints
            /// </summary>
            public decimal TotalPoints { get; set; }

            /// <summary>
            /// Gets or sets TotalFrees
            /// </summary>
            public decimal TotalFrees { get; set; }

            /// <summary>
            /// Gets or sets TotalCount
            /// </summary>
            public int TotalCount { get; set; }

            /// <summary>
            /// Gets or sets DiffPoints
            /// </summary>
            public decimal DiffPoints { get; set; }
        }

        /// <summary>
        /// NSP_MonitorReport_Winlose 回傳類別
        /// </summary>
        private class NSP_MonitorReport_Winlose_Result
        {
            /// <summary>
            /// Gets or sets SID
            /// </summary>
            public long SID { get; set; }

            /// <summary>
            /// Gets or sets 遊戲時間
            /// </summary>
            public string CreateDate { get; set; }

            /// <summary>
            /// Gets or sets 總押注
            /// </summary>
            public decimal TotalBet { get; set; }

            /// <summary>
            /// Gets or sets 總輸贏
            /// </summary>
            public decimal TotalWinlose { get; set; }

            /// <summary>
            /// Gets or sets 總彩金
            /// </summary>
            public decimal TotalJPMoney { get; set; }

            /// <summary>
            /// Gets or sets LM總押注
            /// </summary>
            public decimal TotalBetLM { get; set; }

            /// <summary>
            /// Gets or sets LM總彩金
            /// </summary>
            public decimal TotalWinloseLM { get; set; }

            /// <summary>
            /// Gets or sets LM總輸贏
            /// </summary>
            public decimal TotalJPMoneyLM { get; set; }

            /// <summary>
            /// Gets or sets DiffWinlose
            /// </summary>
            public decimal DiffWinlose { get; set; }
        }

        /// <summary>
        /// NSP_MonitorReport_Points 回傳類別
        /// </summary>
        private class NSP_MonitorReport_Points_Result
        {
            /// <summary>
            /// Gets or sets SID
            /// </summary>
            public long SID { get; set; }

            /// <summary>
            /// Gets or sets CreateDate
            /// </summary>
            public DateTime CreateDate { get; set; }

            /// <summary>
            /// Gets or sets Points
            /// </summary>
            public decimal Points { get; set; }

            /// <summary>
            /// Gets or sets DiffPoints
            /// </summary>
            public decimal DiffPoints { get; set; }
        }
    }
}