﻿using System;

namespace GWeb
{
	public partial class Index : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}