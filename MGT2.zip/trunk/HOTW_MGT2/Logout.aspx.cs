﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb
{
	public partial class Logout : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (Session["AUser"] != null)
			{
                AUser auser=Session["AUser"] as AUser;
                try
                {

                    // 20110510 Phil: 清除踢帳號佇列
                    Utility.KickAgentQueue.Remove(int.Parse(auser.ExecAgentID));

                    SqlHelper.ExecuteNonQuery(
                        WebConfig.connectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_A_Logout",
                        new SqlParameter("@OnlineID", auser.OnlineID));
                    Session.Abandon();
                    Session.RemoveAll();
                }
                catch (Exception)
                { }

                
			}

			Response.Redirect("~/Login.aspx");
		}
	}
}