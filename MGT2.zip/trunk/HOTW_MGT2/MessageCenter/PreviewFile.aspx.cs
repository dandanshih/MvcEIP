﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.MessageCenter
{
	public partial class PreviewFile : System.Web.UI.Page
	{
		#region private

		/// <summary>
		/// 產生 Flash
		/// </summary>
		/// <param name="filePath">檔案路徑。</param>
		/// <returns></returns>
		private string CreateFlash(string filePath)
		{
			string strFlash = "";
			strFlash = @"<object id=""FlashID"" classid=""clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"">"
					 + @"<param name=""movie"" value="".." + filePath + @""" />"
					 + @"<param name=""quality"" value=""high"" />"
					 + @"<param name=""wmode"" value=""opaque"" />"
					 + @"<param name=""swfversion"" value=""6.0.65.0"" />"
					 + @"<param name=""expressinstall"" value=""../Scripts/expressInstall.swf"" />"
					 + @"<object type=""application/x-shockwave-flash"" data="".." + filePath + @""">"
					 + @"<param name=""quality"" value=""high"" />"
					 + @"<param name=""wmode"" value=""opaque"" />"
					 + @"<param name=""swfversion"" value=""6.0.65.0"" />"
					 + @"<param name=""expressinstall"" value=""../Scripts/expressInstall.swf"" />"
					 + @"<div>"
					 + @"<h4>"
					 + @"這個頁面上的內容需要較新版本的 Adobe Flash Player。</h4>"
					 + @"<p>"
					 + @"<a href=""http://www.adobe.com/go/getflashplayer"">"
					 + @"<img src=""http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif"" alt=""取得 Adobe Flash Player"" width=""112"" height=""33"" /></a></p>"
					 + @"</div>"
					 + @"</object>"
					 + @"</object>";

			return strFlash;
		}

		#endregion

		#region public

		protected void Page_Load(object sender, EventArgs e)
		{
			int fileID = 0;
			int.TryParse(Request.QueryString["fileid"].ToString(), out fileID);

			SqlParameter[] param =
			{
				new SqlParameter("@FileID", fileID)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.Text,
														   "SELECT * FROM B_File WHERE FileID = @FileID ORDER BY Seq ASC",
														   param);

			if (objDtr.Read())
			{
				// 記錄檔案路徑
				if (File.Exists(Server.MapPath("~" + objDtr["FilePath1"].ToString())))
				{
					switch (objDtr["FileTypeID"].ToString())
					{
						case "1":
						case "4":
							Literal ltlPreview = new Literal();
							ltlPreview.Text = CreateFlash(objDtr["FilePath1"].ToString());
							phPreview.Controls.Add(ltlPreview);
							break;
						case "2":
						case "3":
						case "5":
							Image imgPreview = new Image();
							imgPreview.ImageUrl = "~" + objDtr["FilePath1"].ToString();
							// imgPreview.Width = Unit.Percentage(100);
							phPreview.Controls.Add(imgPreview);
							break;
					}
				}
			}

			objDtr.Close();
		}

		#endregion
	}
}