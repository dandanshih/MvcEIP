﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.MessageCenter
{
	public partial class HistoryBulletin : GWeb.AppLibs.FormBase
	{
		private void LoadData()
		{
			SqlParameter[] param = 
			{
				new SqlParameter("@BType", "1"),
				new SqlParameter("@StartDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_HistoryBulletin_Get",
				param
			);

			grdGameHistoryBulletin.DataSource = ds;
			grdGameHistoryBulletin.DataBind();

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{

		}


		protected void QueryClick(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			LoadData();
		}
		protected void PagerChange(object sender, EventArgs e)
		{
			LoadData();
		}

		protected void grdGameHistoryBulletin_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				string sTmp = "";
				GridView grdTmp = (GridView)sender;
				GridViewRow Row = e.Row;

				sTmp = grdTmp.DataKeys[e.Row.RowIndex].Values[1].ToString();
				switch (sTmp)
				{
					case "SystemDefault":
						Row.Cells[0].Text = "系統預設<br>(無公告時自動顯示)";
						Row.Cells[0].ForeColor = System.Drawing.Color.Green;
						break;
					case "OverDue":
						Row.Cells[0].Text = "公告已過期";
						Row.Cells[0].ForeColor = System.Drawing.Color.Blue;
						break;
					case "Paused":
						Row.Cells[0].Text = "已被停用";
						Row.Cells[0].ForeColor = System.Drawing.Color.Red;
						break;
					default:
						Row.Cells[0].Text = "使用中";
						break;
				}

				sTmp = grdTmp.DataKeys[Row.RowIndex].Values["BType"].ToString();
				Label lblInfoType = (Label)e.Row.FindControl("lblInfoType");
				switch (sTmp)
				{
					case "3":
						lblInfoType.Text = "系統公告";
						lblInfoType.ForeColor = System.Drawing.Color.Red;
						break;
					case "4":
						lblInfoType.Text = "一般公告";
						lblInfoType.ForeColor = System.Drawing.Color.Green;
						break;
				}
			}
		}
	}
}