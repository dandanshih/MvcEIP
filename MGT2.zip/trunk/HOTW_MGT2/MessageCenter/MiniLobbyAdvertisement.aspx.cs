﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;
using System.Web.UI;
using System.IO;
using System.Web.UI.HtmlControls;

namespace GWeb.MessageCenter
{
    public partial class MiniLobbyAdvertisement : GWeb.AppLibs.FormBase
    {
        #region private
        // 存檔路徑
        private static readonly string strUpFilePath = @"~/Html/UploadFiles/Advertisement/";

        /// <summary>
        /// 清除上傳物件的狀態與暫存檔案。
        /// </summary>
        /// <param name="upload">上傳控制項</param>
        private void DeleteTempFile(EO.Web.AJAXUploader upload)
        {
            try
            {
                if (upload.PostedFiles.Length != 0)
                {
                    File.Delete(upload.PostedFiles[0].TempFileName);
                    File.Delete(Path.ChangeExtension(upload.PostedFiles[0].TempFileName, ".info"));
                    File.Delete(upload.PostedFiles[0].TempFileName
                        .Substring(0, upload.PostedFiles[0].TempFileName.Length - 7) + ".status");

                }
                upload.ClearPostedFiles();
            }
            catch (Exception)
            { }
        }

        /// <summary>
        /// 處理上傳檔案。
        /// </summary>
        /// <param name="upload">上傳控制項</param>
        /// <param name="OldUrlPath">舊檔案網址，新增則帶空值</param>
        /// <returns></returns>
        private string MoveTempFile(EO.Web.AJAXUploader upload, string OldUrlPath)
        {
			string newFileName = Guid.NewGuid().ToString();
			string strFileExtension = Path.GetExtension(upload.PostedFiles[0].ClientFileName).ToLower();
			string strPicPath = string.Format("{0}{1}", ResolveUrl(strUpFilePath), newFileName + strFileExtension);
			string FilePath = Server.MapPath(strPicPath);

			//string UrlPath = ResolveUrl(strUpFilePath) + upload.PostedFiles[0].ClientFileName;
			//string FilePath = Server.MapPath(strUpFilePath) + upload.PostedFiles[0].ClientFileName;

            string OldFileName = OldUrlPath.Substring(OldUrlPath.LastIndexOf("/") + 1);
            if (OldFileName != upload.PostedFiles[0].ClientFileName && File.Exists(FilePath))
            {
                // 檔案已存在回傳空值
                DeleteTempFile(upload);
                return "";
            }
            else
            {
                // 刪除舊檔案
                if (!string.IsNullOrEmpty(OldUrlPath))
                {
                    string tmpPath = OldUrlPath.Replace("http://", "");
                    tmpPath = tmpPath.Substring(tmpPath.IndexOf("/"));
                    File.Delete(Server.MapPath(tmpPath));
                }

                File.Move(upload.PostedFiles[0].TempFileName, FilePath);
                DeleteTempFile(upload);
				return strPicPath;
            }
        }

        /// <summary>
        /// 依廣告類型取得副檔名。
        /// </summary>
        /// <param name="AdType"></param>
        /// <returns></returns>
        private string AllowExtension(string AdType)
        {
            string ext = "";

            switch (AdType)
            {
                // 入廳廣告
                case "15":
                    ext = ".gif|.jpg|.png";
                    break;
                // 定時廣告
                case "16":
					ext = ".gif|.jpg|.png";
                    break;
                // 即時廣告
                case "17":
					ext = ".gif|.jpg|.png";
                    break;
                // 攜點廣告
                case "111":
                    ext = ".gif|.jpg|.png";
                    break;
                // 輪撥廣告
                case "112":
                    ext = ".gif|.jpg|.png";
                    break;
            }

            return ext;
        }

        /// <summary>
        /// 讀取初始廣告參數。
        /// </summary>
        private void LoadAdType()
        {
            DataTable objSource = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_S_GetDictList",
                new SqlParameter("@DictType", "")
            ).Tables[0];

            // 廣告類別
            DataView objDv = new DataView(objSource, "DictType='AdType'", "DictID", DataViewRowState.CurrentRows);
            for (int i = 0; i < objDv.Count; i++)
            {
                ListItem li = new ListItem();
                li.Text = objDv[i]["DictText"].ToString();
                li.Value = objDv[i]["DictID"].ToString();
                hidAdType.Value += objDv[i]["Flag"].ToString() + ",";
                ddlAdType.Items.Add(li);
            }
            hidAdType.Value = hidAdType.Value.TrimEnd(',');
            ddlAdType_SelectedIndexChanged(null, null);

            // 幣別類別
            ddlGameAreaType.DataSource = new DataView(objSource, "DictType='AdPointType'", "DictID", DataViewRowState.CurrentRows).ToTable();
            ddlGameAreaType.DataTextField = "DictText";
            ddlGameAreaType.DataValueField = "DictID";
            ddlGameAreaType.DataBind();

            // 版本類別
            ddlVersionType.DataSource = new DataView(objSource, "DictType='AdPlatform'", "DictID", DataViewRowState.CurrentRows); ;
            ddlVersionType.DataTextField = "DictText";
            ddlVersionType.DataValueField = "DictID";
            ddlVersionType.Attributes["aa"] = "Flag";
            ddlVersionType.DataBind();

			//for (int i = 0; i < 24; i++)
			//{
			//    ddlHour.Items.Add(i.ToString("d2"));
			//}

			//for (int i = 0; i < 60; i++)
			//{
			//    ddlMinute.Items.Add(i.ToString("d2"));
			//}

			for (int i = 1; i <= 30; i++)
			{
				ddlTime2.Items.Add(i.ToString("d2"));
			}

            for (int i = 1; i <= 60; i++)
            {
                ddlTime.Items.Add(i.ToString("d2"));
            }
        }

        /// <summary>
        /// 新增廣告。
        /// </summary>
        private void AddData()
        {
			int Minute;
			if (trDateRange.Visible && !int.TryParse(txt_Minute.Text, out Minute))
			{
				ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('時間區間錯誤！');", true);
				return;
			}

            if (AJAXUploader1.PostedFiles.Length == 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('請選擇上傳檔案！');", true);
                return;
            }

            string path = MoveTempFile(AJAXUploader1, "");
            if (string.IsNullOrEmpty(path))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('檔案名稱已存在，請重新命名後上傳！');", true);
                return;
            }
			string WeekDays = string.Empty;
			if (tr_WeekOpen.Visible)
			{
				foreach (ListItem li in cbl_Week.Items)
				{
					if (li.Selected)
					{
						if (!string.IsNullOrEmpty(WeekDays))
						{
							WeekDays += ",";
						}
						WeekDays += li.Value;
					}
				}
			}
			if (string.IsNullOrEmpty(WeekDays) && tr_WeekOpen.Visible)
			{
				ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('請選擇開放日！');", true);
				return;
			}
            SqlParameter[] param = 
            {
                // 開始時間
                new SqlParameter("@StartDate", trDateRange2.Visible ? drDateRange2.StartDate : drDateRange.StartDate),
                // 結束時間
                new SqlParameter("@EndDate", trDateRange2.Visible ? drDateRange2.EndDate : drDateRange.EndDate),
                // 廣告種類
                new SqlParameter("@AdType", ddlAdType.SelectedValue),
                // 撥放幣區
                new SqlParameter("@AdPointType", ddlGameAreaType.SelectedValue),
                // 撥放平台
                new SqlParameter("@AdPlatform", ddlVersionType.SelectedValue),
                // 廣告路徑
                new SqlParameter("@AdUrl", path),
                // 播放時間
                // new SqlParameter("@PlaybackHHMM", ddlHour.SelectedValue + ":" + ddlMinute.SelectedValue),
				new SqlParameter("@IntervalMinute", txt_Minute.Text),
                // 持續秒數
                new SqlParameter("@DurationSeconds", (ddlAdType.SelectedValue == "112" ? ddlTime2.SelectedValue : ddlTime.SelectedValue)),
                // 連結網址
                new SqlParameter("@ConnectionUrl", txtUrl.Text.TrimEnd()),
                // 輪播間隔
                new SqlParameter("@SortNo", txtSortNo.Text),
				// 遊戲類別
				new SqlParameter("@GameType", trGameType.Visible ? UCGameSelect1.GameTypeSeletedValue : "0"),
				// 遊戲編號
				new SqlParameter("@GameID", trGameType.Visible ? UCGameSelect1.GameSeletedValue : "0"),
				// 模式
				new SqlParameter("@AdMode", tr_Mode.Visible ? ddl_ADMode.SelectedValue : (object)System.DBNull.Value),
				// 位置
				new SqlParameter("@AdLocation", tr_Location.Visible ? ddl_Location.SelectedValue : (object)System.DBNull.Value),
				// 身分別
				new SqlParameter("@AdMemberType", tr_MemberType.Visible ? ddl_MemberType.SelectedValue : (object)System.DBNull.Value),
				// 開始播放時段
				new SqlParameter("@StartTime", tr_PlayTimeRange.Visible ? txt_PlayStartTime.Text : (object)System.DBNull.Value),
				// 結束播放時段
				new SqlParameter("@EndTime", tr_PlayTimeRange.Visible ? txt_PlayEndTime.Text : (object)System.DBNull.Value),
				// 開放日
				new SqlParameter("@WeekDays", tr_WeekOpen.Visible ? WeekDays : (object)System.DBNull.Value)
            };

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_B_Advertising_New",
                param
            );

            objDr.Read();

            if (objDr[0].ToString() == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('新增成功');", true);
                grdAdList.EditIndex = -1;
                grdAdList.DataBind();
            }
            else
            {
				if (File.Exists(Server.MapPath("~" + path)))
				{
					File.Delete(Server.MapPath("~" + path));
				}

                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('新增失敗');", true);
            }

            objDr.Close();
        }

        /// <summary>
        /// 暫停廣告。
        /// </summary>
        /// <param name="AdID"></param>
        private void PusedData(string AdID)
        {
			SqlParameter[] param =
			{
				new SqlParameter("@AdID", AdID),
				new SqlParameter("@IsEnabled", "0")
			};

			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_B_Advertising_Pause",
				param
			);

            objDr.Read();

            if (objDr[0].ToString() == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('停用成功');", true);
                grdAdList.EditIndex = -1;
                grdAdList.DataBind();
            }
            else
            {
				ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('停用失敗');", true);
            }

            objDr.Close();
        }

		/// <summary>
		/// 啟用廣告。
		/// </summary>
		/// <param name="AdID"></param>
		private void StartData(string AdID)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@AdID", AdID),
				new SqlParameter("@IsEnabled", "1")
			};

			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_B_Advertising_Pause",
				param
			);

			objDr.Read();

			if (objDr[0].ToString() == "0")
			{
				ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('啟用成功');", true);
				grdAdList.EditIndex = -1;
				grdAdList.DataBind();
			}
			else
			{
				ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('啟用失敗');", true);
			}

			objDr.Close();
		}

        /// <summary>
        /// 修改上傳檔案。
        /// </summary>
        /// <param name="AdID"></param>
        private bool EditData(string AdID)
        {
            // 判斷是否有上傳檔案
            EO.Web.AJAXUploader upload = (EO.Web.AJAXUploader)grdAdList.Rows[grdAdList.EditIndex].Cells[7].FindControl("AJAXUploader2");
            //if (upload.PostedFiles.Length == 0)
            //{
            //    ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('請選擇上傳檔案！');", true);
            //    return false;
            //}

            // 禁止上傳不同檔名的檔案
            HiddenField hidAdUrl = (HiddenField)grdAdList.Rows[grdAdList.EditIndex].Cells[8].FindControl("hidAdUrl");
			string path = hidAdUrl.Value;
			if (upload.PostedFiles.Length != 0)
			{
				//if (ResolveUrl(strUpFilePath) + upload.PostedFiles[0].ClientFileName != hidAdUrl.Value)
				//{
				//    ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('上傳檔案檔名不相同！');", true);
				//    DeleteTempFile(upload);
				//    return false;
				//}
				// 處理上傳檔案
				path = MoveTempFile(upload, hidAdUrl.Value);
			}
            if (string.IsNullOrEmpty(path))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('檔案名稱已存在，請重新命名後上傳！');", true);
                return false;
            }
            
            SqlParameter[] param =
            {
                new SqlParameter("@AdID", AdID),
				new SqlParameter("@StartDate", ((EO.Web.DatePicker)grdAdList.Rows[grdAdList.EditIndex].Cells[2].FindControl("dpStartDate")).SelectedDate),
				new SqlParameter("@EndDate", ((EO.Web.DatePicker)grdAdList.Rows[grdAdList.EditIndex].Cells[3].FindControl("dpEndDate")).SelectedDate),
				new SqlParameter("@DurationSeconds", ((TextBox)grdAdList.Rows[grdAdList.EditIndex].Cells[4].FindControl("txtDurationSeconds")).Text),
				new SqlParameter("@IntervalMinute", ((TextBox)grdAdList.Rows[grdAdList.EditIndex].Cells[5].FindControl("txtIntervalMinute")).Text),
				new SqlParameter("@AdUrl", path),
                // 連結網址
                new SqlParameter("@ConnectionUrl", ((TextBox)grdAdList.Rows[grdAdList.EditIndex].Cells[9].FindControl("txtConnectionUrl")).Text),
				new SqlParameter("@SortNo", ((TextBox)grdAdList.Rows[grdAdList.EditIndex].Cells[10].FindControl("txt_SortNo")).Text),
				new SqlParameter("@StartTime", ((TextBox)grdAdList.Rows[grdAdList.EditIndex].Cells[11].FindControl("txtStartTime")).Text),
				new SqlParameter("@EndTime", ((TextBox)grdAdList.Rows[grdAdList.EditIndex].Cells[12].FindControl("txtEndTime")).Text),
            };

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_B_Advertising_Edit",
                param
            );

            objDr.Read();

            string result = objDr[0].ToString();

            objDr.Close();

            if (result == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('修改成功');", true);
                return true;
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('修改失敗');", true);
                return false;
            }
        }

		/// <summary>
		/// 刪除選擇的廣告。
		/// </summary>
		/// <param name="AdID"></param>
		private void DeleteSelectedData()
		{
			DataTable dt = new DataTable(); ;
			CheckBox chkSelect;

			// 建立欄位
			dt.Columns.Add("Data1");
			dt.Columns.Add("Data2");
			dt.Columns.Add("Data3");
			dt.Columns.Add("Data4");
			dt.Columns.Add("Data5");

			for (int i = 0; i < grdAdList.Rows.Count; i++)
			{
				chkSelect = ((CheckBox)grdAdList.Rows[i].FindControl("chkSelect"));

				if (chkSelect.Checked)
				{
					DataRow dr;
					
					dr = dt.NewRow();
					dr["Data1"] = grdAdList.DataKeys[i]["AdID"].ToString();
					dr["Data2"] = grdAdList.DataKeys[i]["AdUrl"].ToString();
					dr["Data3"] = "";
					dr["Data4"] = "";
					dr["Data5"] = "";
					dt.Rows.Add(dr);
				}
			}

			if (dt.Rows.Count == 0)
			{
				ScriptManager.RegisterStartupScript(this.Page, GetType(), "msg", "alert('請勾選欲刪除的項目');", true);
				return;
			}
			
			SqlParameter[] param =
			{
				new SqlParameter("@AdID", dt),
				new SqlParameter("@IsReturn", "1")
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_B_Advertising_Delete",
				param
			);						

			if (ds.Tables[0].Rows[0]["Result"].ToString() == "0")
			{
				foreach (DataRow row in dt.Rows)
				{
					string url = Server.MapPath("~" + row["Data2"].ToString());
					if (File.Exists(url))
					{
						File.Delete(url);
					}
				}

				ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('刪除成功');", true);
				grdAdList.EditIndex = -1;
				grdAdList.DataBind();
			}
			else
			{
				ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('刪除失敗');", true);
			}
		}
        #endregion

        #region protected

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAdType(); 
            }
        }

		/// <summary>
		/// 勾起全選時
		/// </summary>
		protected void chkAllSelectChange(object sender, EventArgs e)
		{
			bool isChecked = (sender as CheckBox).Checked;
			foreach (GridViewRow gvr in grdAdList.Rows)
			{
				CheckBox chkSelect = gvr.Cells[0].FindControl("chkSelect") as CheckBox;
				chkSelect.Checked = isChecked;
			}
		}

        protected void ddlAdType_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeleteTempFile(AJAXUploader1);

            int Flag = int.TryParse(hidAdType.Value.Split(',')[ddlAdType.SelectedIndex], out Flag) ? Flag : 0;
			foreach (Control ctl in pnl.Controls)
			{
				if (ctl is HtmlControl)
				{
					HtmlControl hctl = ctl as HtmlControl;
					if (!string.IsNullOrEmpty(hctl.Attributes["Flag"]))
					{
						hctl.Visible = (Flag & int.Parse(hctl.Attributes["Flag"])) == 0 ? false : true;
					}
				}
			}
			//trGameAreaType.Visible = (Flag & int.Parse(trGameAreaType.Attributes["Flag"])) == 0 ? false : true;
			//trVersionType.Visible = (Flag & int.Parse(trVersionType.Attributes["Flag"])) == 0 ? false : true;
			//trTime.Visible = (Flag & int.Parse(trTime.Attributes["Flag"])) == 0 ? false : true;
			//trDateRange.Visible = (Flag & int.Parse(trDateRange.Attributes["Flag"])) == 0 ? false : true;
			//trDateRange2.Visible = (Flag & int.Parse(trDateRange2.Attributes["Flag"])) == 0 ? false : true;
			//trUrl.Visible = (Flag & int.Parse(trUrl.Attributes["Flag"])) == 0 ? false : true;
			//trSortNo.Visible = (Flag & int.Parse(trSortNo.Attributes["Flag"])) == 0 ? false : true;
			//trGameType.Visible = (Flag & int.Parse(trGameType.Attributes["Flag"])) == 0 ? false : true;
			//tr_Mode.Visible = (Flag & int.Parse(tr_Mode.Attributes["Flag"])) == 0 ? false : true;
			//tr_Location.Visible = (Flag & int.Parse(tr_Location.Attributes["Flag"])) == 0 ? false : true;
			//tr_MemberType.Visible = (Flag & int.Parse(tr_MemberType.Attributes["Flag"])) == 0 ? false : true;

            if (ddlAdType.SelectedValue == "112")
            {
                ddlTime.Visible = false;
                ddlTime2.Visible = true;
            }
            else
            {
                ddlTime.Visible = true;
                ddlTime2.Visible = false;
            }

            AJAXUploader1.AllowedExtension = AllowExtension(ddlAdType.SelectedValue);
            drDateRange.StartDate = drDateRange2.StartDate = DateTime.Now.ToString();
            drDateRange.EndDate = drDateRange2.EndDate = DateTime.Now.ToString();

			//ddlHour.SelectedIndex = 0;
			//ddlMinute.SelectedIndex = 0;
            txtSortNo.Text = "";
            txtUrl.Text = "";
            ddlTime.SelectedIndex = 0;
            ddlTime2.SelectedIndex = 0;
			txt_Minute.Text = "";
			txt_PlayStartTime.Text = "";
			txt_PlayEndTime.Text = "";

			if (ddlGameAreaType.Items.Count > 0)
			{
				ddlGameAreaType.SelectedIndex = 0;
			}
			
			UCGameSelect1.GameSeletedValue = "0";

			if (ddlVersionType.Items.Count > 0)
			{
				ddlVersionType.SelectedIndex = 0;
			}
			if (ddl_MemberType.Items.Count > 0)
			{
				ddl_MemberType.SelectedIndex = 0;
			}
			if (ddl_ADMode.Items.Count > 0)
			{
				ddl_ADMode.SelectedIndex = 0;
			}
			if (ddl_Location.Items.Count > 0)
			{
				ddl_Location.SelectedIndex = 0;
			}
			cbl_Week.ClearSelection();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            AddData();
        }

        protected void grdAdList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "UpdateData":
                    if (EditData(e.CommandArgument.ToString()))
                    {
                        grdAdList.EditIndex = -1;
                        grdAdList.DataBind();
                    }
                    break;
                case "Pused":
                    PusedData(e.CommandArgument.ToString());
					break;
				case "Start":
					StartData(e.CommandArgument.ToString());
					break;
				case "Modify":
					Response.Redirect("~/MessageCenter/MiniLobbyAdvertisementEdit.aspx?AdID=" + e.CommandArgument.ToString());
                    break;
				case "AllDel":
					DeleteSelectedData();
					break;
            }
        }

        protected void dsAdList_Selected(object sender, SqlDataSourceStatusEventArgs e)
        {
            UCPager1.RecordCount = Convert.ToInt32(e.Command.Parameters["@TotalRecords"].Value);
            UCPager1.DataBind();
        }

        protected void grdAdList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataRowView item = (DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (grdAdList.EditIndex != e.Row.RowIndex)
                {
                    HtmlGenericControl span = (HtmlGenericControl)e.Row.FindControl("spanPauseAccount");
					HtmlGenericControl spanStartAccount = (HtmlGenericControl)e.Row.FindControl("spanStartAccount");
                    // Label lbl = (Label)e.Row.FindControl("lblPauseAccount");

                    span.Visible = false;
					spanStartAccount.Visible = false;
                    // lbl.Visible = false;
                    if (item["Paused"].ToString() == "0")
                    {
                        span.Visible = true;
						spanStartAccount.Visible = false;
                        // lbl.Visible = false;
                    }
                    else
                    {
                        span.Visible = false;
						spanStartAccount.Visible = true;
                        // lbl.Visible = true;
                    }
                }
                else
                {
                    EO.Web.AJAXUploader upload = (EO.Web.AJAXUploader)e.Row.FindControl("AJAXUploader2");
                    upload.AllowedExtension = AllowExtension(item["AdType"].ToString());
                }

				string adUrl = DataBinder.Eval(e.Row.DataItem, "AdUrl").ToString();
				Literal ltlPreview = (Literal)e.Row.FindControl("ltlPreview");

				if (adUrl.ToLower().Contains(".swf"))
				{
					ltlPreview.Text = string.Format(
						 @"<object id=""FlashID"" classid=""clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"" width=""200"">"
						 + @"<param name=""movie"" value=""{0}"" />"
						 + @"<param name=""quality"" value=""high"" />"
						 + @"<param name=""wmode"" value=""opaque"" />"
						 + @"<param name=""swfversion"" value=""6.0.65.0"" />"
						 + @"<param name=""expressinstall"" value=""../Scripts/expressInstall.swf"" />"
						 + @"<object type=""application/x-shockwave-flash"" data=""{0}"">"
						 + @"<param name=""quality"" value=""high"" />"
						 + @"<param name=""wmode"" value=""opaque"" />"
						 + @"<param name=""swfversion"" value=""6.0.65.0"" />"
						 + @"<param name=""expressinstall"" value=""../Scripts/expressInstall.swf"" />"
						 + @"<div>"
						 + @"<h4>"
						 + @"這個頁面上的內容需要較新版本的 Adobe Flash Player。</h4>"
						 + @"<p>"
						 + @"<a href=""http://www.adobe.com/go/getflashplayer"">"
						 + @"<img src=""http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif"" alt=""取得 Adobe Flash Player"" width=""112"" height=""33"" /></a></p>"
						 + @"</div>"
						 + @"</object>"
						 + @"</object>"
						, adUrl
					);
				}
				else
				{
					ltlPreview.Text = string.Format("<img style='width:200px;' src='{0}' />", adUrl);
				}
            }
        }

        #endregion
    }
}