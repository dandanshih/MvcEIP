﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.MessageCenter
{
	public partial class AddFile : GWeb.AppLibs.FormBase
	{
		#region private

		/// <summary>
		/// 讀取檔案類別列表。
		/// </summary>
		private void LoadFileType()
		{
			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_B_PicInfoType_List");

			ddlFileType.DataTextField = "FileTypeName";
			ddlFileType.DataValueField = "FileTypeID";
			ddlFileType.DataSource = objDtr;
			ddlFileType.DataBind();

			int fileID = 0;

			if (Request.QueryString["fileid"] != null)
			{
				int.TryParse(Request.QueryString["fileid"], out fileID);
				ddlFileType.Items.FindByValue(fileID.ToString()).Selected = true;
			}
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadFileType();
			}

			switch (ddlFileType.SelectedItem.Value)
			{
				case "1":
				case "2":
				case "3":
				case "4":
				case "5":
					AJAXUploader1.AllowedExtension = ".jpg|.jpeg|.bmp|.gif|.png";
					ViewState["message"] = "只允許 jpg、jpeg、bmp、gif、png 附檔名的檔案。";
					lblTip.Text = "只允許 jpg、jpeg、bmp、gif、png 附檔名的檔案。";
					break;
				case "6":
					AJAXUploader1.AllowedExtension = ".rar|.zip|.xls|.xlsx|.doc|.docx";
					ViewState["message"] = "只允許 rar、zip、xls、xlsx、doc、docx 附檔名的檔案。";
					lblTip.Text = "只允許 rar、zip、xls、xlsx、doc、docx 附檔名的檔案。";
					break;
			}
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			string relativePath = "";
			string tempFileName = "";						
			string fileName = "";

			if (txtFileName.Text == "")
			{
				WebUtility.ResponseScript(Page, "alert('請輸入名稱。');", WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			else if (AJAXUploader1.PostedFiles.Length == 0)
			{
				WebUtility.ResponseScript(Page, "alert('請選擇要上傳的檔案。');", WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			else
			{
				tempFileName = AJAXUploader1.PostedFiles[0].TempFileName;
				// 設定檔案目錄
				fileName = AJAXUploader1.PostedFiles[0].ClientFileName;

				switch (ddlFileType.SelectedItem.Value)
				{ 
					case "1":
					case "2":
					case "3":
					case "4":
					case "5":
						if (Path.GetExtension(fileName) != ".jpg" && Path.GetExtension(fileName) != ".jpeg" && Path.GetExtension(fileName) != ".bmp" && Path.GetExtension(fileName) != ".gif" && Path.GetExtension(fileName) != ".png")
						{ 
							WebUtility.ResponseScript(Page, "alert('只允許 jpg、jpeg、bmp、gif、png 附檔名的檔案。')", WebUtility.ResponseScriptPlace.NearFormEnd);
							return;
						}
						break;
					case "6":
						if (Path.GetExtension(fileName) != ".rar" && Path.GetExtension(fileName) != ".zip" && Path.GetExtension(fileName) != ".xls" && Path.GetExtension(fileName) != ".xlsx" && Path.GetExtension(fileName) != ".doc" && Path.GetExtension(fileName) != ".docx")
						{
							WebUtility.ResponseScript(Page, "alert('只允許 rar、zip、xls、xlsx、doc、docx 附檔名的檔案。')", WebUtility.ResponseScriptPlace.NearFormEnd);
							return;
						}
						break;
				}
			}

			switch (ddlFileType.SelectedItem.Value)
			{
				case "1":
					relativePath = "/Html/UploadFiles/Activity/" + Guid.NewGuid().ToString() + Path.GetExtension(fileName);
					break;
				case "2":
					relativePath = "/Html/UploadFiles/Advertisement/" + Guid.NewGuid().ToString() + Path.GetExtension(fileName);
					break;
				case "3":
					relativePath = "/Html/UploadFiles/GameIntroduction/" + Guid.NewGuid().ToString() + Path.GetExtension(fileName);
					break;
				case "4":
					relativePath = "/Html/UploadFiles/OnlineTeaching/" + Guid.NewGuid().ToString() + Path.GetExtension(fileName);
					break;
				case "5":
					relativePath = "/Html/UploadFiles/Product/" + Guid.NewGuid().ToString() + Path.GetExtension(fileName);
					break;
				case "6":
					relativePath = "/Html/UploadFiles/Document/" + Guid.NewGuid().ToString() + Path.GetExtension(fileName);
					break;
			}

			// 設定檔案新路徑及檔名 
			string finalFileName = Server.MapPath("~" + relativePath);

			// 移動檔案並設定新檔名
			File.Move(tempFileName, finalFileName);

			// 刪除暫存檔
			File.Delete(Path.ChangeExtension(tempFileName, ".info"));
			File.Delete(tempFileName.Substring(0, tempFileName.Length - 7) + ".status");

			SqlParameter[] param =
				{
					new SqlParameter("@FileTypeID", ddlFileType.SelectedItem.Value),
					new SqlParameter("@FilePath1", relativePath),
					new SqlParameter("@FileName", txtFileName.Text),
					new SqlParameter("@FileUrl1", txtFileUrl1.Text),
					new SqlParameter("@Seq", "10"),
					new SqlParameter("@Enable", "true"),
					new SqlParameter("@CreateUser", User.Name)
				};

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString,
										CommandType.StoredProcedure,
										"NSP_AgentWeb_B_PicInfo_New",
										param);

			Response.Redirect("~/MessageCenter/UploadManage.aspx");			
		}		

		protected void btnCancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("~/MessageCenter/UploadManage.aspx");
		}

		#endregion
	}
}