﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;
using System.Web.UI;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace GWeb.MessageCenter
{
	public partial class MiniLobbyAdvertisementEdit : GWeb.AppLibs.FormBase
	{
		#region private
		/// <summary>
		/// 依廣告類型取得副檔名。
		/// </summary>
		/// <param name="AdType"></param>
		/// <returns></returns>
		private string AllowExtension(string AdType)
		{
			string ext = "";

			switch (AdType)
			{
				// 入廳廣告
				case "15":
					ext = ".gif|.jpg|.png";
					break;
				// 定時廣告
				case "16":
					ext = ".gif|.jpg|.png";
					break;
				// 即時廣告
				case "17":
					ext = ".gif|.jpg|.png";
					break;
				// 攜點廣告
				case "111":
					ext = ".gif|.jpg|.png";
					break;
				// 輪撥廣告
				case "112":
					ext = ".gif|.jpg|.png";
					break;
			}

			return ext;
		}

		/// <summary>
		/// 讀取初始廣告參數。
		/// </summary>
		private void LoadAdType()
		{
			DataTable objSource = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_S_GetDictList",
				new SqlParameter("@DictType", "")
			).Tables[0];

			// 廣告類別
			DataView objDv = new DataView(objSource, "DictType='AdType'", "DictID", DataViewRowState.CurrentRows);
			for (int i = 0; i < objDv.Count; i++)
			{
				ListItem li = new ListItem();
				li.Text = objDv[i]["DictText"].ToString();
				li.Value = objDv[i]["DictID"].ToString();
				hidAdType.Value += objDv[i]["Flag"].ToString() + ",";
				ddlAdType.Items.Add(li);
			}
			hidAdType.Value = hidAdType.Value.TrimEnd(',');
			ddlAdType_SelectedIndexChanged(null, null);

			// 幣別類別
			ddlGameAreaType.DataSource = new DataView(objSource, "DictType='AdPointType'", "DictID", DataViewRowState.CurrentRows).ToTable();
			ddlGameAreaType.DataTextField = "DictText";
			ddlGameAreaType.DataValueField = "DictID";
			ddlGameAreaType.DataBind();

			// 版本類別
			ddlVersionType.DataSource = new DataView(objSource, "DictType='AdPlatform'", "DictID", DataViewRowState.CurrentRows); ;
			ddlVersionType.DataTextField = "DictText";
			ddlVersionType.DataValueField = "DictID";
			ddlVersionType.Attributes["aa"] = "Flag";
			ddlVersionType.DataBind();

			//for (int i = 0; i < 24; i++)
			//{
			//    ddlHour.Items.Add(i.ToString("d2"));
			//}

			//for (int i = 0; i < 60; i++)
			//{
			//    ddlMinute.Items.Add(i.ToString("d2"));
			//}

			for (int i = 1; i <= 30; i++)
			{
				ddlTime2.Items.Add(i.ToString("d2"));
			}

			for (int i = 1; i <= 60; i++)
			{
				ddlTime.Items.Add(i.ToString("d2"));
			}
		}

		/// <summary>
		/// 修改上傳檔案。
		/// </summary>
		/// <param name="AdID"></param>
		private bool EditData(string AdID)
		{
			// 圖片真實路徑
			string strPicPath = string.Empty;
			// 檔名	- 暫存用
			string strNewFileName = string.Empty;
			// 檔案之副檔名 - 暫存用
			string strFileExtension = string.Empty;
			// 檔案目錄
			string strDirectory = "/Html/UploadFiles/Advertisement/";

			// 如果目錄不存在則建立目錄
			if (!Directory.Exists(Server.MapPath("~" + strDirectory)))
			{
				Directory.CreateDirectory(Server.MapPath("~" + strDirectory));
			}

			// 儲存圖片
			if (fuPicUrl.HasFile)
			{
				strFileExtension = Path.GetExtension(fuPicUrl.FileName).ToLower();
				strPicPath = string.Format("{0}{1}", strDirectory, new Guid().ToString() + strFileExtension);

				File.Delete("");
			}

			SqlParameter[] param =
			{
				new SqlParameter("@AdID", AdID),
                new SqlParameter("@AdUrl", strPicPath),
				new SqlParameter("@ConnectionUrl", ""),
				new SqlParameter("@SortNo", "")
			};

			param[param.Length - 1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_B_Advertising_Edit",
				param
			);

			string result = param[param.Length - 1].Value.ToString();

			// 儲存圖片
			if (fuPicUrl.HasFile)
			{
				fuPicUrl.SaveAs(Server.MapPath("~" + strPicPath));
			}

			return true;
		}

		#endregion

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadAdType();
			}
		}

		protected void ddlAdType_SelectedIndexChanged(object sender, EventArgs e)
		{
			int Flag = int.TryParse(hidAdType.Value.Split(',')[ddlAdType.SelectedIndex], out Flag) ? Flag : 0;
			foreach (Control ctl in pnl.Controls)
			{
				if (ctl is HtmlControl)
				{
					HtmlControl hctl = ctl as HtmlControl;
					if (!string.IsNullOrEmpty(hctl.Attributes["Flag"]))
					{
						hctl.Visible = (Flag & int.Parse(hctl.Attributes["Flag"])) == 0 ? false : true;
					}
				}
			}

			if (ddlAdType.SelectedValue == "112")
			{
				ddlTime.Visible = false;
				ddlTime2.Visible = true;
			}
			else
			{
				ddlTime.Visible = true;
				ddlTime2.Visible = false;
			}

			drDateRange.StartDate = drDateRange2.StartDate = DateTime.Now.ToString();
			drDateRange.EndDate = drDateRange2.EndDate = DateTime.Now.ToString();

			//ddlHour.SelectedIndex = 0;
			//ddlMinute.SelectedIndex = 0;
			txtSortNo.Text = "";
			txtUrl.Text = "";
			ddlTime.SelectedIndex = 0;
			ddlTime2.SelectedIndex = 0;
			txt_Minute.Text = "";
			txt_PlayStartTime.Text = "";
			txt_PlayEndTime.Text = "";

			if (ddlGameAreaType.Items.Count > 0)
			{
				ddlGameAreaType.SelectedIndex = 0;
			}

			UCGameSelect1.GameSeletedValue = "0";

			if (ddlVersionType.Items.Count > 0)
			{
				ddlVersionType.SelectedIndex = 0;
			}
			if (ddl_MemberType.Items.Count > 0)
			{
				ddl_MemberType.SelectedIndex = 0;
			}
			if (ddl_ADMode.Items.Count > 0)
			{
				ddl_ADMode.SelectedIndex = 0;
			}
			if (ddl_Location.Items.Count > 0)
			{
				ddl_Location.SelectedIndex = 0;
			}
			cbl_Week.ClearSelection();
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{

		}
	}
}