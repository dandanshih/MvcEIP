﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;
using System.Web.UI;

namespace GWeb.MessageCenter
{
	public partial class Bulletin : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
                for (int i = 0; i < 3; i++)
                {
                    cboGameSystemDay.Items.Add(i.ToString());
                }

				for (int i = 0; i < 60; i++)
				{
					cboGameSystemHour.Items.Add(i.ToString("d2"));
					cboGameSystemMin.Items.Add(i.ToString("d2"));
				}

				cboGameSystemHour.Items[0].Selected = true;
				cboGameSystemMin.Items[30].Selected = true;
			}
		}

        protected void btnSendGameSys_Click(object sender, EventArgs e)
		{
            int SleepSeconds = 0;
			if (!int.TryParse(ddlDurationMinutes.SelectedItem.Value, out SleepSeconds))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "error", "alert('間隔時間數值錯誤！');", true);
                return;
            }
            else if (SleepSeconds < 0 || SleepSeconds > 60)
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "error", "alert('間隔時間介於0~60之間！');", true);
                return;
            }
            else if (string.IsNullOrEmpty(txtGameSystemBulletin.Text.TrimEnd()))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "error", "alert('請輸入公告內容');", true);
                return;
            }

			int iTotalMin = Convert.ToInt32(cboGameSystemDay.SelectedValue) * 24 * 60 +
							Convert.ToInt32(cboGameSystemHour.SelectedValue) * 60 +
							Convert.ToInt32(cboGameSystemMin.SelectedValue);

            SqlParameter[] param = 
            {
                new SqlParameter("@StartDate", DateTime.Now.AddSeconds(-30).ToString("yyyy/MM/dd HH:mm:dd")),
                new SqlParameter("@EndDate", DateTime.Now.AddMinutes(iTotalMin).ToString("yyyy/MM/dd HH:mm:dd")),
                new SqlParameter("@BContent", txtGameSystemBulletin.Text),
                new SqlParameter("@BType", "game1"),
                new SqlParameter("@SleepSeconds", (SleepSeconds * 60).ToString())
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_B_Bulletin_New",
                param
            );

			//Utility.SendInfoToFrontServer(AUser.FrontServerIP, "270&95&3&" + iTotalMin.ToString());
            // 20110511 Phil: 改叫前台去更新公告
            GameCommandHandler.RefreshBulletin();

			txtGameSystemBulletin.Text = "";

			UCPager1.CurrentPageNumber = 1;
			grdGameHistoryBulletin.DataBind();
		}

		protected void btnGameSaveBulletin_Click(object sender, EventArgs e)
		{
            if (string.IsNullOrEmpty(txtGameNewBulletin.Text.TrimEnd()))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "error", "alert('請輸入公告內容');", true);
                return;
            }

            SqlParameter[] param = 
            {
                new SqlParameter("@StartDate", drGame.StartDate),
                new SqlParameter("@EndDate", drGame.EndDate),
                new SqlParameter("@BContent", txtGameNewBulletin.Text),
                new SqlParameter("@BType", "game2")
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_B_Bulletin_New",
                param
            );

			//Utility.SendInfoToFrontServer(AUser.FrontServerIP, "270&95&3&0");

            // 20110511 Phil: 改叫前台去更新公告
            GameCommandHandler.RefreshBulletin();

			txtGameNewBulletin.Text = "";

			UCPager1.CurrentPageNumber = 1;
			grdGameHistoryBulletin.DataBind();
		}

		protected void dsGame_Selected(object sender, SqlDataSourceStatusEventArgs e)
		{
			UCPager1.RecordCount = Convert.ToInt32(e.Command.Parameters["@TotalRecords"].Value);
			UCPager1.DataBind();
			
		}

		protected void grdGameHistoryBulletin_RowCommand(object sender, GridViewCommandEventArgs e)
		{

			if (e.CommandName == "Stop")
			{

				SqlParameter[] arParms =
				{
					new SqlParameter("@BulletinID",grdGameHistoryBulletin.DataKeys[Convert.ToInt32(e.CommandArgument)].Values[0].ToString())
				};

				SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_B_Bulletin_Pause", arParms);

                //string sCmd = "270&95&3&0";
                //Utility.SendInfoToFrontServer(AUser.FrontServerIP, sCmd);

                // 20110511 Phil: 改叫前台去更新公告
                GameCommandHandler.RefreshBulletin();

				UCPager1.CurrentPageNumber = 1;
				grdGameHistoryBulletin.DataBind();
			}

		}

		protected void Row_Editing(object sender, GridViewEditEventArgs e)
		{
			grdGameHistoryBulletin.EditIndex = e.NewEditIndex;
			grdGameHistoryBulletin.DataBind();
		}
		protected void Row_CancelEditing(object sender, GridViewCancelEditEventArgs e)
		{
			grdGameHistoryBulletin.EditIndex = -1;
			grdGameHistoryBulletin.DataBind();
		}

		protected void Row_Updating(object sender, GridViewUpdateEventArgs e)
		{
            int SleepSecond = 0;
            if (!int.TryParse(((TextBox)grdGameHistoryBulletin.Rows[e.RowIndex].Cells[4].FindControl("txtSleepSecond")).Text, out SleepSecond))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "error", "alert('間隔時間數值錯誤！');", true);
            }
            else if (SleepSecond < 0 || SleepSecond > 60)
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "error", "alert('間隔時間介於0~60之間！');", true);
            }
            else
            {
                string BContent = e.NewValues[0].ToString();
                SqlParameter[] arParms =
					{
						new SqlParameter("@BulletinID",e.Keys[0].ToString()),
						new SqlParameter("@BContent",e.NewValues[0].ToString()),
						new SqlParameter("@SleepSeconds",SleepSecond * 60)
					};

                SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_B_Bulletin_Edit", arParms);
            }

            grdGameHistoryBulletin.EditIndex = -1;

			e.Cancel = true;
		}

		protected void PagerChange(object sender, EventArgs e)
		{
			grdGameHistoryBulletin.DataBind();
		}

		protected void grdGameHistoryBulletin_RowCreated(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
			{
				string sTmp = "";
				GridView grdTmp = (GridView)sender;
				GridViewRow Row = e.Row;

				(Row.Cells[6].Controls[1].FindControl("btnEdit") as Button).Visible = false;

				sTmp = grdTmp.DataKeys[e.Row.RowIndex].Values["State"].ToString();
				switch (sTmp)
				{
					case "SystemDefault":
						Row.Cells[0].Text = "系統預設<br>(無公告時自動顯示)";
						Row.Cells[0].ForeColor = System.Drawing.Color.Green;
						break;
					case "OverDue":
						Row.Cells[0].Text = "公告已過期";
						Row.Cells[0].ForeColor = System.Drawing.Color.Blue;
						break;
					case "Paused":
						Row.Cells[0].Text = "已被停用";
						Row.Cells[0].ForeColor = System.Drawing.Color.Red;
						break;
					default:
                        ((Button)(Row.Cells[0].Controls[1])).Text = "(按我停用)";
                        ((Button)(Row.Cells[0].Controls[1])).CommandArgument = e.Row.RowIndex.ToString();
						(Row.Cells[6].Controls[1].FindControl("btnEdit") as Button).Visible = true;
						break;
				}

				sTmp = grdTmp.DataKeys[Row.RowIndex].Values["BType"].ToString();
				Label lblInfoType = (Label)e.Row.FindControl("lblInfoType");
				switch (sTmp)
				{
					case "3":
						lblInfoType.Text = "系統公告";
						lblInfoType.ForeColor = System.Drawing.Color.Red;
						break;
					case "4":
						lblInfoType.Text = "一般公告";
						lblInfoType.ForeColor = System.Drawing.Color.Green;
						break;
				}
			}
		}
	}
}