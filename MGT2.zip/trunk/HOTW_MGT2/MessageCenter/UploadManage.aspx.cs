﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.MessageCenter
{
	public partial class UploadManage : GWeb.AppLibs.FormBase
	{
		#region private

		private void BindData()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@FileTypeID", ddlFileType.SelectedItem.Value),
				new SqlParameter("@PageSize", gvUpdateManage.PageSize),
				new SqlParameter("@PageIndex", gvUpdateManage.CurrentPageIndex),
				new SqlParameter("@TotalRecord", gvUpdateManage.TotalRecords)
			};

			param[3].Direction = ParameterDirection.Output;

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_B_PicInfo_List",
														   param);
			
			gvUpdateManage.DataSource = objDtr;
			gvUpdateManage.DataBind();

			objDtr.Close();

			gvUpdateManage.TotalRecords = int.Parse(param[3].Value.ToString());
		}

		/// <summary>
		/// 讀取檔案類別列表。
		/// </summary>
		private void LoadFileType()
		{
			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_B_PicInfoType_List");

			ddlFileType.DataTextField = "FileTypeName";
			ddlFileType.DataValueField = "FileTypeID";
			ddlFileType.DataSource = objDtr;
			ddlFileType.DataBind();
		}
		
		#endregion

		#region public

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadFileType();
				BindData();
			}
		}

		protected void ddlFileType_SelectedIndexChanged(object sender, EventArgs e)
		{
			BindData();
		}

		protected void gvUpdateManage_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				if (ddlFileType.SelectedItem.Value != "6")
				{
					((Button)e.Row.FindControl("btnPriview")).OnClientClick = string.Format("myWindow = window.open('PreviewFile.aspx?fileid={0}', '預覽', 'width=600,height=400,scrollbars=yes,left=150,top=150,resizable=yes'); return false;", DataBinder.Eval(e.Row.DataItem, "FileID"));
				}
			}
		}

		protected void gvUpdateManage_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 預覽
			if (e.CommandName == "PreviewFile")
			{
				// 如果是表單則不預覽
				if (ddlFileType.SelectedItem.Value == "6")
				{
					Response.Redirect("~" + e.CommandArgument.ToString());
				}
			}
			// 編輯
			else if (e.CommandName == "EditFile")
			{
				Response.Redirect(string.Format("~/MessageCenter/EditFile.aspx?fileid={0}&filetypeid={1}", e.CommandArgument.ToString(), ddlFileType.SelectedItem.Value));
			}
			// 刪除
			else if (e.CommandName == "DeleteFile")
			{
				SqlParameter[] param =
				{
					new SqlParameter("@FileID", e.CommandArgument.ToString().Split(',')[0].ToString())
				};

				SqlHelper.ExecuteNonQuery(WebConfig.connectionString,
										  CommandType.StoredProcedure,
										  "NSP_AgentWeb_B_PicInfo_Delete",
										  param);

				if (System.IO.File.Exists(Server.MapPath("~" + e.CommandArgument.ToString().Split(',')[1].ToString())))
				{
					System.IO.File.Delete(Server.MapPath("~" + e.CommandArgument.ToString().Split(',')[1].ToString()));
				}

				BindData();
			}
		}

		protected void btnAdd_Click(object sender, EventArgs e)
		{
			if (ddlFileType.SelectedItem.Value == "2" && gvUpdateManage.Rows.Count >= 6)
			{
				WebUtility.ResponseScript(Page, "alert('廣告最多只能新增六筆')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else
			{
				Response.Redirect(string.Format("~/MessageCenter/AddFile.aspx?fileid={0}", ddlFileType.SelectedItem.Value));
			}
		}

		#endregion
	}
}