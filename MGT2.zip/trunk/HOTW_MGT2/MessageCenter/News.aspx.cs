﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.MessageCenter
{
	public partial class News : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				dsNewsList.SelectParameters["StartDate"].DefaultValue = DateRange1.StartDate;
				dsNewsList.SelectParameters["EndDate"].DefaultValue = DateRange1.EndDate;
				dsNewsList.Select(DataSourceSelectArguments.Empty);
			}
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{

			SqlParameter[] arParms =
			{
				new SqlParameter("@NewsTypeID",cboNewsType.SelectedValue),
				new SqlParameter("@NewsTitle",txtNewsTitle.Text),
				new SqlParameter("@NewsDesc",txtNewsDesc.Text),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID),
                new SqlParameter("@NewsPlatform", ddlType.SelectedValue)
			};

			if (SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_B_News_New", arParms).ToString().Equals("0"))
			{
				WebUtility.ResponseScript(Page, "alert('新增成功!');", WebUtility.ResponseScriptPlace.NearFormEnd);
				UCPager1.CurrentPageNumber = 1;
				grdNewsList.DataBind();
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('新增失敗!');", WebUtility.ResponseScriptPlace.NearFormEnd);
			}

		}

		protected void btnReset_Click(object sender, EventArgs e)
		{
			txtNewsDesc.Text = "";
			txtNewsTitle.Text = "";
			ddlType.SelectedIndex = 0;
			cboNewsType.SelectedIndex = 0;
		}

		protected void dsNewsList_Selected(object sender, SqlDataSourceStatusEventArgs e)
		{
			UCPager1.RecordCount = Convert.ToInt32(e.Command.Parameters["@TotalRecord"].Value);
			UCPager1.DataBind();
		}

		protected void dsNewsList_Updating(object sender, SqlDataSourceCommandEventArgs e)
		{
			e.Command.Parameters["@ExecAgentID"].Value = AUser.ExecAgentID;
		}

		protected void grdNewsList_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			// 下面這段的用意是讓畫面能夠正確的顯示斷行資料
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				Label lblGrdNewsTitle = (Label)e.Row.FindControl("lblGrdNewsTitle");
				if (lblGrdNewsTitle != null) lblGrdNewsTitle.Text = ReplaceBr(lblGrdNewsTitle.Text);
				Label lblGrdNewsDesc = (Label)e.Row.FindControl("lblGrdNewsDesc");
				if (lblGrdNewsDesc != null) lblGrdNewsDesc.Text = ReplaceBr(lblGrdNewsDesc.Text);
				TextBox txtGrdNewsTitle = (TextBox)e.Row.FindControl("txtGrdNewsTitle");
				if (txtGrdNewsTitle != null) txtGrdNewsTitle.Text = HttpUtility.HtmlDecode(txtGrdNewsTitle.Text);
				TextBox txtGrdNewsDesc = (TextBox)e.Row.FindControl("txtGrdNewsDesc");
				if (txtGrdNewsDesc != null) txtGrdNewsDesc.Text = HttpUtility.HtmlDecode(txtGrdNewsDesc.Text);
			}
		}

		protected void grdNewsList_RowUpdating(object sender, GridViewUpdateEventArgs e)
		{
			// 資料儲存前先轉成安全的格式後再存!
			// e.NewValues[1] = HttpUtility.HtmlEncode(e.NewValues[1].ToString());
			// e.NewValues[2] = HttpUtility.HtmlEncode(e.NewValues[2].ToString());
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			dsNewsList.SelectParameters["StartDate"].DefaultValue = DateRange1.StartDate;
			dsNewsList.SelectParameters["EndDate"].DefaultValue = DateRange1.EndDate;
			UCPager1.CurrentPageNumber = 1;
			grdNewsList.DataBind();
		}

		protected void DeleteClick(object sender, EventArgs e)
		{
			Button btn = sender as Button;
			SqlParameter[] arParms =
			{
				new SqlParameter("@NewsID",btn.CommandArgument),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};

			if (SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_B_News_Delete", arParms).ToString().Equals("0"))
			{
				WebUtility.ResponseScript(Page, "alert('刪除成功!');", WebUtility.ResponseScriptPlace.NearFormEnd);
				UCPager1.CurrentPageNumber = 1;
				grdNewsList.DataBind();
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('刪除失敗!');", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		protected void DateRangeChange(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;
			UCPager1.CurrentPageNumber = 1;
			grdNewsList.DataBind();
		}

		protected void PagerChange(object sender, EventArgs e)
		{
			grdNewsList.DataBind();
		}
	}
}