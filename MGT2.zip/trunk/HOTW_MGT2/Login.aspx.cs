﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb
{
	public partial class Login : System.Web.UI.Page
	{
		#region private

		/// <summary>
		/// 檢查帳號密碼, 成功會傳回True。
		/// </summary>
		/// <param name="userName">帳號。</param>
		/// <param name="userPassword">密碼。</param>
		private string CheckLogin(string userName, string userPassword)
		{
			// 登入前先清除 Session
			//Session.Abandon();
			//Session.RemoveAll();
			
			string sCheckLoginMsg = "";

			SqlParameter[] param = 
			{
				new SqlParameter("@Account", userName),
				new SqlParameter("@Password", userPassword),
				new SqlParameter("@IP", Request.UserHostAddress == "::1" ? "127.0.0.1" : Request.UserHostAddress),
				new SqlParameter("@SessionID", Session.SessionID),
				new SqlParameter("@Host", ""),
				new SqlParameter("@ErrorMsg", SqlDbType.VarChar, 50)
			};

			param[5].Direction = ParameterDirection.Output;

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
															CommandType.StoredProcedure,
															"NSP_AgentWeb_A_Login",
															param);

			if (objDtr.Read())
			{

				// 將管理者登入的資料存成 Session
				AUser AUser = new AUser();

				AUser.IsLogin = true;
				AUser.AgentID = objDtr["AgentID"].ToString();
				AUser.AgentAccount = objDtr["AgentAccount"].ToString();
				AUser.AgentNickName = objDtr["AgentNickName"].ToString();
				AUser.AgentGroupID = objDtr["AgentGroupID"].ToString();
				AUser.ExecAgentID = objDtr["ExecAgentID"].ToString();
				AUser.ExecAgentAccount = objDtr["ExecAgentAccount"].ToString();
				AUser.ExecAgentNickName = objDtr["ExecAgentNickName"].ToString();
				AUser.ExecAgentGroupID = objDtr["ExecAgentNickName"].ToString();
				AUser.OnlineID = objDtr["OnlineID"].ToString();
				AUser.DefaultWebPage = objDtr["DefaultWebPage"].ToString();
				AUser.FrontServerIP = objDtr["FrontServerIP"].ToString();
				AUser.GroupEName = objDtr["GroupEName"].ToString();
				AUser.IsWebAdmin = bool.Parse(objDtr["IsWebAdmin"].ToString());
				AUser.IsShadowAccount = int.Parse(objDtr["IsShadow"].ToString()) == 1 ? true : false;
				AUser.ReviewAuthority = objDtr["ReviewAuthority"].ToString();

				// 將 Class 放在 Session 供其他頁面使用
				Session["AUser"] = AUser;


                // 20110510 Phil: 清除可能遺留的踢帳號佇列
                Utility.KickAgentQueue.Remove(int.Parse(AUser.ExecAgentID));



			}
			else
			{	
				sCheckLoginMsg = param[5].Value.ToString();

				// 如果登入失敗就清除 Session
				//Session.Abandon();
				//Session.RemoveAll();				
			}

			objDtr.Close();

			return sCheckLoginMsg;
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			// 設定預設按鈕
			Page.Form.DefaultButton = ibtnLogin.UniqueID;

#if (Debug)
			string strJScript = "document.getElementById('txtPassword').value='123456';"
								+ "document.getElementById('txtAccount').value='rd';"
								+ "document.getElementById('txtVerifyCode').value='123456';";
			System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "rdlogin", strJScript, true);
			SqlConnection conn = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString);
			Page.Header.Title += " (Debug in " + conn.DataSource + ")";
			conn.Dispose();
			Page.SetFocus("txtPassword");
#endif

			// 已經有登入過了，而且 Server 尚未登出的情況下，就直接跳至 default 頁面
			if (Session["AUser"] != null)
			{
				Response.Redirect("~/Index.aspx", false);
				return;
			}

			// 如果有 QueryString 的話，要重新再讀取一次，讓 QueryString 消失
			if (Request.QueryString.Count != 0)
			{
				Response.Redirect("~/Login.aspx", false);
				return;
			}

            Page.SetFocus("txtAccount");
			//Page.Header.Title = GetGlobalResourceObject("Resources", "ManagerSystem").ToString();
		}

		/// <summary>
		/// 驗證使用者的帳號與密碼。
		/// </summary>
		protected void ibtnLogin_Click(object sender, ImageClickEventArgs e)
		{
			if (Session["gif"] == null)
			{
				Server.Transfer("~/Login.aspx");
				return;
			}

			string sCheckLoginMsg = "";

			// 開發模式直接給檢查碼
#if (Debug)   
                txtVerifyCode.Text = Session["gif"].ToString();
#endif

			// 確認驗證碼
			if (Session["gif"].ToString().ToUpper() != txtVerifyCode.Text.ToUpper())
			{
				Page.SetFocus("txtPassword");
				txtVerifyCode.Text = "";
				lblMessage.Text = "驗證碼錯誤。";
				lblMessage.Visible = true;
				return;
			}

			sCheckLoginMsg = CheckLogin(txtAccount.Text, txtPassword.Text);
			if (sCheckLoginMsg != "")
			{
				lblMessage.Text = "帳號或密碼錯誤。";
				lblMessage.Visible = true;
				txtVerifyCode.Text = "";
				Page.SetFocus("txtPassword");
				return;
			}

			Response.Redirect("~/Index.aspx");
		}

		#endregion
	}
}