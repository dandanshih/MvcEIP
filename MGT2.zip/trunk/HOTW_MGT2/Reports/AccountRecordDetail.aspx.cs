﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class AccountRecordDetail : System.Web.UI.Page
	{
		#region private

		/// <summary>
		/// 讀取指定類型的帳戶明細。
		/// </summary>
		private void LoadAccountLogDetailByItem()
		{
			DateTime dStartDate;
			DateTime.TryParse(Request.QueryString["startdate"].ToString(), out dStartDate);

			DateTime dEndDate;
			DateTime.TryParse(Request.QueryString["enddate"].ToString(), out dEndDate);

			string startDate = dStartDate.ToString("yyyy/MM/dd HH:mm:ss");
			string endDate = dEndDate.ToString("yyyy/MM/dd HH:mm:ss");
			string memberAccount = Request.QueryString["memberAccount"].ToString().ToSafeString();
			string nickName = Request.QueryString["nickName"].ToString().ToSafeString();
			string depositsItem = Request.QueryString["depositsItem"].ToString().ToSafeString();
			string gameAreaType = Request.QueryString["gameAreaType"].ToString().ToSafeString();
			string memberid = Request.QueryString["memberid"].ToString().ToSafeString();

			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", startDate),
				new SqlParameter("@EndDate", endDate),
				new SqlParameter("@MemberAccount", memberAccount),
				new SqlParameter("@nickName", nickName),
				new SqlParameter("@DepositsItem", depositsItem),
				new SqlParameter("@GameAreaType", gameAreaType),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", DbType.Int32),
				new SqlParameter("@MemberID", memberid)
			};

			param[param.Length - 2].Direction = ParameterDirection.Output;

			DataSet objDs = SqlHelper.ExecuteDataset(WebConfig.connectionString,
													 CommandType.StoredProcedure,
													 "NSP_AgentWeb_R_MemberAccountingLogDetailByItem",
													 param);

			gvAccountLogDetail.DataSource = objDs;
			gvAccountLogDetail.DataBind();

			UCPager1.RecordCount = Convert.ToInt32(int.Parse(param[param.Length - 2].Value.ToString()));
			UCPager1.DataBind();
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			LoadAccountLogDetailByItem();
		}

		protected void PagerChange(object sender, EventArgs e)
		{
			LoadAccountLogDetailByItem();
		}
		#endregion
	}
}