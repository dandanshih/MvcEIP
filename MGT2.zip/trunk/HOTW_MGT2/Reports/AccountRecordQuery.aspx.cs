﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class AccountRecordQuery : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region 查詢
        /// <summary>
        /// 查詢事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnQuery_Click(object sender, EventArgs e)
        {
            HPoints.Visible = false;
            UPoints.Visible = false;

            if (ddlGameAreaType.SelectedItem.Value == "0" || ddlGameAreaType.SelectedItem.Value == "1")
            {
                UCPager1U.CurrentPageNumber = 1;
                LoadAccountLogSummaryU();
                LoadAccountLogDetailU();

                UPoints.Visible = true;
            }

            if (ddlGameAreaType.SelectedItem.Value == "0" || ddlGameAreaType.SelectedItem.Value == "2")
            {
                UCPager1.CurrentPageNumber = 1;
                LoadAccountLogSummary();
                LoadAccountLogDetail();

                HPoints.Visible = true;
            }

            UCPagerRichGold1.CurrentPageNumber = 1;
            LoadRichGold();

            UCPagerMall.CurrentPageNumber = 1;
            BindMallLog();

            UCPagerStrategyDetail.CurrentPageNumber = 1;
            BindStrategyDetail();
        }

        /// <summary>
        /// 日期查詢事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UCDateRange1_Change(object sender, EventArgs e)
        {
            //檢查是否可查詢資料
            if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
                return;

            HPoints.Visible = false;
            UPoints.Visible = false;

            if (ddlGameAreaType.SelectedItem.Value == "0" || ddlGameAreaType.SelectedItem.Value == "1")
            {
                UCPager1U.CurrentPageNumber = 1;
                LoadAccountLogSummaryU();
                LoadAccountLogDetailU();

                UPoints.Visible = true;
            }

            if (ddlGameAreaType.SelectedItem.Value == "0" || ddlGameAreaType.SelectedItem.Value == "2")
            {
                UCPager1.CurrentPageNumber = 1;
                LoadAccountLogSummary();
                LoadAccountLogDetail();

                HPoints.Visible = true;
            }

            UCPagerRichGold1.CurrentPageNumber = 1;
            LoadRichGold();

            UCPagerMall.CurrentPageNumber = 1;
            BindMallLog();

            UCPagerStrategyDetail.CurrentPageNumber = 1;
            BindStrategyDetail();
        }
        #endregion

        #region 老幣帳戶總合帳
        /// <summary>
        /// 讀取【老幣帳戶總合帳】資料。
        /// </summary>
		private void LoadAccountLogSummary()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text.ToSafeString()),
				new SqlParameter("@GameAreaType", "2"),
				new SqlParameter("@NickName", txtNickName.Text.ToSafeString()),
				new SqlParameter("@MemberID", txtMemberID.Text.ToSafeString())
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_MemberAccountingLogSummary",
														   param);

			gvAccountLogSummary.DataSource = objDtr;
			gvAccountLogSummary.DataBind();
			objDtr.Close();
		}

        /// <summary>
        /// 【老幣帳戶總合帳】RowCommand 事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvAccountLogSummary_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Detail")
            {
				WebUtility.ResponseScript(Page, string.Format("myWindow=window.open('AccountRecordDetail.aspx?startDate={0}&endDate={1}&memberAccount={2}&nickName={3}&depositsItem={4}&gameAreaType={5}&memberid={6}','明細','width=760,height=600,scrollbars=yes,left=250,top=200');", UCDateRange1.StartDate, UCDateRange1.EndDate, txtMemberAccount.Text.ToSafeString(), txtNickName.Text.ToSafeString(), e.CommandArgument.ToString(), "2", txtMemberID.Text.ToSafeString()), WebUtility.ResponseScriptPlace.NearFormEnd);
            }
        }
        #endregion

        #region 老幣帳戶明細
        /// <summary>
        /// 讀取【老幣帳戶明細】。
		/// </summary>
		private void LoadAccountLogDetail()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text.ToSafeString()),
				new SqlParameter("@NickName", txtNickName.Text.ToSafeString()),
				new SqlParameter("@GameAreaType", "2"),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", DbType.Int32),
				new SqlParameter("@Result", DbType.Int32),
				new SqlParameter("@MemberID", txtMemberID.Text.ToSafeString())
			};

			param[7].Direction = ParameterDirection.Output;
			param[8].Direction = ParameterDirection.ReturnValue;

			DataSet objDs = SqlHelper.ExecuteDataset(WebConfig.connectionString,
													 CommandType.StoredProcedure,
													 "NSP_AgentWeb_R_MemberAccountingLogDetail",
													 param);

			if (int.Parse(param[8].Value.ToString()) == 0)
			{
				UCPager1.RecordCount = Convert.ToInt32(int.Parse(param[7].Value.ToString()));
				UCPager1.DataBind();

				gvAccountLogDetail.DataSource = objDs;				
			}

			gvAccountLogDetail.DataBind();	
		}

        /// <summary>
        /// 老幣兌換。
        /// </summary>
        private void Exchange(string accountingLogID)
        {
            int result = 0;

            SqlParameter[] param =
			{
				new SqlParameter("@AccountingLogID", accountingLogID),
				new SqlParameter("@AgentID", AUser.ExecAgentID),
				new SqlParameter("@GameAreaType", "2"),
				new SqlParameter("@ReturnValue", SqlDbType.Int)
			};

            param[param.Length - 1].Direction = ParameterDirection.ReturnValue;

            DataSet ds = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_MemberAccountExchangeGift",
                param
            );

            result = int.Parse(param[param.Length - 1].Value.ToString());

            if (result == 0)
            {
                WebUtility.ResponseScript(Page, "alert('兌換成功')", WebUtility.ResponseScriptPlace.NearFormEnd);
            }
            else if (result == 99)
            {
                long EventID = long.TryParse(ds.Tables[0].Rows[0]["EventID"].ToString(), out EventID) ? EventID : 0;
                int MemberIDTarget = int.TryParse(ds.Tables[0].Rows[0]["MemberID"].ToString(), out	MemberIDTarget) ? MemberIDTarget : 0;
                decimal Points = decimal.TryParse(ds.Tables[0].Rows[0]["ChangePoint"].ToString(), out Points) ? Points : 0;
                int PointType = int.TryParse(ds.Tables[0].Rows[0]["PointType"].ToString(), out PointType) ? PointType : 0;
                // 如果玩家在線上就呼叫 Front Server 洗分
                string fsResult = GS.ServerCommander.FSCommander.FS_AS_CREDIT_CHANGE(EventID, MemberIDTarget, Points, PointType);

                System.Threading.Thread.Sleep(1000);

                WebUtility.ResponseScript(Page, "alert('兌換成功')", WebUtility.ResponseScriptPlace.NearFormEnd);
            }
            else
            {
                WebUtility.ResponseScript(Page, "alert('兌換失敗')", WebUtility.ResponseScriptPlace.NearFormEnd);
            }
        }

        /// <summary>
        /// 【老幣帳戶明細】RowDataBound 事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvAccountLogDetail_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Button btnExchange = (Button)e.Row.FindControl("btnExchange");
                Label lblChangeMemo = (Label)e.Row.FindControl("lblChangeMemo");

                if (bool.Parse(DataBinder.Eval(e.Row.DataItem, "IsExchange").ToString()) == true)
                {
                    btnExchange.Visible = true;
                    lblChangeMemo.Visible = false;
                    btnExchange.OnClientClick = "return confirm('玩家欲兌換的是：" + DataBinder.Eval(e.Row.DataItem, "Gift") + "禮卷');";
                }
                else
                {
                    btnExchange.Visible = false;
                    lblChangeMemo.Visible = true;
                }
            }
        }

        /// <summary>
        /// 【老幣帳戶明細】RowCommand 事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvAccountLogDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Exchange")
            {
                Exchange(e.CommandArgument.ToString());
                LoadAccountLogDetail();
            }
        }

        /// <summary>
        /// 【老幣帳戶明細】換頁事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagerChange(object sender, EventArgs e)
        {
            LoadAccountLogSummary();
            LoadAccountLogDetail();
        }
        #endregion

        #region 爽幣帳戶總合帳

        /// <summary>
        /// 讀取【爽幣帳戶總合帳】資料。
		/// </summary>
		private void LoadAccountLogSummaryU()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text.ToSafeString()),
				new SqlParameter("@GameAreaType", "1"),
				new SqlParameter("@NickName", txtNickName.Text.ToSafeString()),
				new SqlParameter("@MemberID", txtMemberID.Text.ToSafeString())
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_MemberAccountingLogSummary",
														   param);

			gvAccountLogSummaryU.DataSource = objDtr;
			gvAccountLogSummaryU.DataBind();
			objDtr.Close();
		}

        /// <summary>
        /// 【爽幣帳戶總合帳】RowCommand 事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvAccountLogSummaryU_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Detail")
            {
				WebUtility.ResponseScript(Page, string.Format("myWindow=window.open('AccountRecordDetail.aspx?startDate={0}&endDate={1}&memberAccount={2}&nickName={3}&depositsItem={4}&gameAreaType={5}&memberid={6}','明細','width=760,height=600,scrollbars=yes,left=250,top=200');", UCDateRange1.StartDate, UCDateRange1.EndDate, txtMemberAccount.Text.ToSafeString(), txtNickName.Text.ToSafeString(), e.CommandArgument.ToString(), "1", txtMemberID.Text.ToSafeString()), WebUtility.ResponseScriptPlace.NearFormEnd);
            }
        }
        #endregion

        #region 爽幣帳戶明細
        /// <summary>
        /// 讀取【爽幣帳戶明細】資料。
		/// </summary>
		private void LoadAccountLogDetailU()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text.ToSafeString()),
				new SqlParameter("@NickName", txtNickName.Text.ToSafeString()),
				new SqlParameter("@GameAreaType", "1"),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", DbType.Int32),
				new SqlParameter("@Result", DbType.Int32),
				new SqlParameter("@MemberID", txtMemberID.Text.ToSafeString())
			};

			param[7].Direction = ParameterDirection.Output;
			param[8].Direction = ParameterDirection.ReturnValue;

			DataSet objDs = SqlHelper.ExecuteDataset(WebConfig.connectionString,
													 CommandType.StoredProcedure,
													 "NSP_AgentWeb_R_MemberAccountingLogDetail",
													 param);

			if (int.Parse(param[8].Value.ToString()) == 0)
			{
				UCPager1U.RecordCount = Convert.ToInt32(int.Parse(param[7].Value.ToString()));
				UCPager1U.DataBind();

				gvAccountLogDetailU.DataSource = objDs;
			}

			gvAccountLogDetailU.DataBind();
		}

		/// <summary>
		/// 爽幣兌換。
		/// </summary>
		private void ExchangeU(string accountingLogID)
		{
			int result = 0;

			SqlParameter[] param =
			{
				new SqlParameter("@AccountingLogID", accountingLogID),
				new SqlParameter("@AgentID", AUser.ExecAgentID),
				new SqlParameter("@GameAreaType", "1"),
				new SqlParameter("@ReturnValue", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.ReturnValue;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_MemberAccountExchangeGift",
				param
			);

			result = int.Parse(param[param.Length - 1].Value.ToString());

			if (result == 0)
			{
				WebUtility.ResponseScript(Page, "alert('兌換成功')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else if (result == 99)
			{
				long EventID = long.TryParse(ds.Tables[0].Rows[0]["EventID"].ToString(), out EventID) ? EventID : 0;
				int MemberIDTarget = int.TryParse(ds.Tables[0].Rows[0]["MemberID"].ToString(), out	MemberIDTarget) ? MemberIDTarget : 0;
				decimal Points = decimal.TryParse(ds.Tables[0].Rows[0]["Points"].ToString(), out Points) ? Points : 0;
				int PointType = int.TryParse(ds.Tables[0].Rows[0]["PointType"].ToString(), out PointType) ? PointType : 0;
				// 如果玩家在線上就呼叫 Front Server 洗分
				string fsResult = GS.ServerCommander.FSCommander.FS_AS_CREDIT_CHANGE(EventID, MemberIDTarget, Points, PointType);

				System.Threading.Thread.Sleep(1000);

				WebUtility.ResponseScript(Page, "alert('兌換成功')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('兌換失敗')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
        }

        /// <summary>
        /// 【爽幣帳戶明細】RowDataBound 事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvAccountLogDetailU_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Button btnExchange = (Button)e.Row.FindControl("btnExchange");
                Label lblChangeMemo = (Label)e.Row.FindControl("lblChangeMemo");

                if (bool.Parse(DataBinder.Eval(e.Row.DataItem, "IsExchange").ToString()) == true)
                {
                    btnExchange.Visible = true;
                    lblChangeMemo.Visible = false;
                    btnExchange.OnClientClick = "return confirm('玩家欲兌換的是：" + DataBinder.Eval(e.Row.DataItem, "Gift") + "禮卷');";
                }
                else
                {
                    btnExchange.Visible = false;
                    lblChangeMemo.Visible = true;
                }
            }
        }
        
        /// <summary>
        /// 【爽幣帳戶明細】RowCommand 事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvAccountLogDetailU_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Exchange")
            {
                ExchangeU(e.CommandArgument.ToString());
                LoadAccountLogDetailU();
            }
        }

        /// <summary>
        /// 【爽幣帳戶明細】換頁事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagerChangeU(object sender, EventArgs e)
        {
            LoadAccountLogSummaryU();
            LoadAccountLogDetailU();
        }
        #endregion

        #region 發財金明細
        /// <summary>
		/// 讀取【發財金明細】資料。
		/// </summary>
		private void LoadRichGold()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@StartDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text.ToSafeString()),
				new SqlParameter("@NickName", txtNickName.Text.ToSafeString()),				
				new SqlParameter("@PageIndex", UCPagerRichGold1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPagerRichGold1.PageSize),
				new SqlParameter("@TotalRecords", DbType.Int32),
				new SqlParameter("@Result", DbType.Int32),
				new SqlParameter("@MemberID", txtMemberID.Text.ToSafeString())
			};

			param[6].Direction = ParameterDirection.Output;
			param[7].Direction = ParameterDirection.ReturnValue;

			DataSet objDs = SqlHelper.ExecuteDataset(WebConfig.connectionString,
													 CommandType.StoredProcedure,
													 "NSP_AgentWeb_MemberLuckMoneyLog",
													 param);

			if (int.Parse(param[7].Value.ToString()) == 0)
			{
				UCPagerRichGold1.RecordCount = Convert.ToInt32(int.Parse(param[6].Value.ToString()));
				UCPagerRichGold1.DataBind();

				gvRichGold.DataSource = objDs;
			}

			gvRichGold.DataBind();
        }

        /// <summary>
        /// 【發財金明細】換頁事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UCPagerRichGold1_Change(object sender, EventArgs e)
        {
            LoadRichGold();
        }
		#endregion

        #region 購物額度帳戶明細
        /// <summary>
        /// 讀取【購物額度帳戶明細】資料。
        /// </summary>
        private void BindMallLog()
		{
			SqlParameter[] param = 
			{
				new SqlParameter("@TotalRecords", DbType.Int32),
				new SqlParameter("@StartDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text.ToSafeString()),
				new SqlParameter("@NickName", txtNickName.Text.ToSafeString()),				
				new SqlParameter("@PageIndex", UCPagerMall.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPagerMall.PageSize),
				new SqlParameter("@MemberID", txtMemberID.Text.ToSafeString())
			};
			param[0].Direction = ParameterDirection.Output;
			gv_MallLog.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_Mall_MemberMallFinanceLog",
				param
			).Tables[0];
			gv_MallLog.DataBind();

			UCPagerMall.RecordCount = Convert.ToInt32(int.Parse(param[0].Value.ToString()));
			UCPagerMall.DataBind();
		}

        /// <summary>
        /// 【購物額度帳戶明細】換頁事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UCPagerMall_Change(object sender, EventArgs e)
        {
            BindMallLog();
        }
		#endregion

        #region 策略明細
        /// <summary>
        /// 取得【策略明細】資料。
        /// </summary>
        private void BindStrategyDetail()
        {
            SqlParameter[] param =
			{
				new SqlParameter("@TotalRecords", DbType.Int32),
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text.ToSafeString()),
				new SqlParameter("@NickName", txtNickName.Text.ToSafeString()),				
				new SqlParameter("@PageIndex", UCPagerStrategyDetail.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPagerStrategyDetail.PageSize),
				new SqlParameter("@MemberID", txtMemberID.Text.ToSafeString())
			};

            param[0].Direction = ParameterDirection.Output;

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_Worth_MemberTacticList",
                param
            );

            gv_StrategyDetail.DataSource = objDr;
            gv_StrategyDetail.DataBind();

            objDr.Close();

            UCPagerStrategyDetail.RecordCount = int.Parse(param[0].Value.ToString());
            UCPagerStrategyDetail.DataBind();
        }

        /// <summary>
        /// 【策略明細】換頁事件。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UCPagerStrategyDetail_Change(object sender, EventArgs e)
        {
            BindStrategyDetail();
        }
        #endregion
    }
}