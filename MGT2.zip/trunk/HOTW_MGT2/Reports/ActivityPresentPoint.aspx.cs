﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class ActivityPresentPoint : GWeb.AppLibs.FormBase
	{
		#region private

		private void BindData()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@PageIndex", 1),
				new SqlParameter("@PageSize", SqlDbType.Int),
				new SqlParameter("@TotalRows", SqlDbType.BigInt)
			};
            try
            {
                SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
                                                               CommandType.StoredProcedure,
                                                               "",
                                                               param);


                gvActivityPresentPoint.DataSource = objDtr;
                gvActivityPresentPoint.DataBind();

                objDtr.Close();
            }
            catch (Exception)
            { }
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			BindData();
		}

		protected void UCDateRange1_Change(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;
			BindData();
		}

		protected void gvActivityPresentPoint_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 匯出

            try
            {
                if (e.CommandName == "Export")
                {
                    SqlParameter[] param =
				{
					new SqlParameter("@BeginDate", UCDateRange1.StartDate),
					new SqlParameter("@EndDate", UCDateRange1.EndDate),
					new SqlParameter("@PageIndex", 1),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@TotalRows", SqlDbType.BigInt)
				};

                    param[param.Length - 1].Direction = ParameterDirection.Output;
                    param[param.LongLength - 2].Value = 0;

                    DataTable dt = SqlHelper.ExecuteDataset(WebConfig.connectionString, CommandType.StoredProcedure, "", param).Tables[0];
                    MemoryStream ms = NPOIRender.RenderDataTableToExcel(dt);
                    string fileName = string.Format("ActivityPresent{0}.xls", DateTime.Now.ToString("yyyyMMddHHmmss"));

                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename=" + fileName));
                    Response.BinaryWrite(ms.ToArray());
                    Response.End();
                }
            }
            catch (Exception)
            { }
		}

		#endregion
	}
}