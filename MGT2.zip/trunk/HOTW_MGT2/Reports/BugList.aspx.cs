﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class BugList : GWeb.AppLibs.FormBase
	{
		private void LoadData()
		{
			dsBugList.SelectParameters["StartDate"].DefaultValue = DateRange1.StartDate;
			dsBugList.SelectParameters["EndDate"].DefaultValue = DateRange1.EndDate;
			grdBugList.DataBind();
			dsBugDetail.SelectParameters["BugID"].DefaultValue = "";
			dvBugDetail.Visible = false;
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				dsBugList.SelectParameters["BugStatus"].DefaultValue = cboBugType.SelectedValue;
				dsBugList.SelectParameters["StartDate"].DefaultValue = DateRange1.StartDate;
				dsBugList.SelectParameters["EndDate"].DefaultValue = DateRange1.EndDate;
				grdBugList.DataBind();
			}
		}

		protected void grdBugList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			dsBugDetail.SelectParameters["BugID"].DefaultValue = "";
			dvBugDetail.Visible = false;

			if (e.CommandName != "")
			{
				GridView grdTmp = grdBugList;

				int RowIndex = Convert.ToInt32(e.CommandArgument);
				string BugID = grdTmp.DataKeys[RowIndex]["BUGID"].ToString();
				string BugStatus = grdTmp.DataKeys[RowIndex]["BugStatus"].ToString();

				switch (e.CommandName)
				{

					// 回覆收到
					//case "BugReply":
					//    {

					//        string MailBody = "感謝您的 意見 回饋，我們將儘快處理!!";

					//        System.Net.Mail.MailMessage objMsg = new System.Net.Mail.MailMessage();
					//        objMsg.To.Add(grdBugList.DataKeys[RowIndex]["MsgMail"].ToString());
					//        objMsg.Subject = "客服中心 - 意見 回饋";
					//        objMsg.Body = MailBody;
					//        objMsg.IsBodyHtml = true;
					//        System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
					//        client.Send(objMsg);

					//        SqlParameter[] arParms =
					//        {
					//            new SqlParameter("@ExecAgentID",AUser.ExecAgentID),
					//            new SqlParameter("@BugID",BugID)
					//        };

					//        SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_Bug_Reply", arParms);


					//        grdBugList.DataBind();

					//        break;
					//    }

					// 發佈此 Bug
					case "BugReply":
					case "BugFinish":
						{
							hdn_Status.Value = e.CommandName;
							if (e.CommandName == "BugReply")
							{
								lbl.Text = "欲回覆內容：";
								btnBugReply1.Text = "回覆";
								btnBugReply2.Visible = false;
								txtWinPrize.Text = hdn_ReplyDefaultValue.Value;
							}
							else
							{
								lbl.Text = "敘獎原因 / 備註：";
								btnBugReply1.Text = "發佈";
								btnBugReply2.Visible = true;
								txtWinPrize.Text = HttpUtility.HtmlDecode(grdBugList.DataKeys[RowIndex]["BonusReason"].ToString());
							}
							hfBugID.Value = BugID;
							hfEmail.Value = grdBugList.DataKeys[RowIndex]["MsgMail"].ToString();
							lblRportDate.Text = grdBugList.Rows[RowIndex].Cells[4].Text;
							//lblMember.Text = grdBugList.Rows[RowIndex].Cells[2].Text;
							lblNickName.Text = grdBugList.Rows[RowIndex].Cells[3].Text;
							lblBugType.Text = grdBugList.Rows[RowIndex].Cells[5].Text;
							lblBug.Text = ReplaceBr(grdBugList.DataKeys[RowIndex]["BugDesc"].ToString());


							ModalPopupExtender.Show();
							string sScript = "setTimeout(\"$get('" + txtWinPrize.ClientID + "').focus(); \", 500);";
							ScriptManager.RegisterStartupScript(this, this.GetType(), "focus", sScript, true);
							break;
						}

					// 按下 Detail
					case "Detail":
						{
							foreach (GridViewRow Row in grdBugList.Rows)
							{
								Button btn = (Button)Row.FindControl("btnDetail");
								if (Row.RowIndex == Convert.ToInt32(e.CommandArgument))
									btn.ForeColor = System.Drawing.Color.Red;
								else
									btn.ForeColor = System.Drawing.Color.Empty;
							}

							dsBugDetail.SelectParameters["BugID"].DefaultValue = BugID;
							dvBugDetail.DataBind();
							dvBugDetail.Visible = true;
							break;
						}
				}
			}
		}

		/// <summary>
		/// Bug 發佈時，要處理敘獎內容
		/// </summary>
		protected void btnBugReply_Command(object sender, CommandEventArgs e)
		{
			string Status = hdn_Status.Value;
			if (Status == "BugReply")
			{
				string MailBody = txtWinPrize.Text;
				string BugID = hfBugID.Value;
				string Email = hfEmail.Value;

				System.Net.Mail.MailMessage objMsg = new System.Net.Mail.MailMessage();
				objMsg.To.Add(Email);
				objMsg.Subject = "[老子有錢] 客服中心 - 意見 回饋";
				objMsg.Body = base.ReplaceBr(MailBody);
				objMsg.IsBodyHtml = true;
				System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
				client.Send(objMsg);

				SqlParameter[] arParms =
			    {
			        new SqlParameter("@ExecAgentID",AUser.ExecAgentID),
			        new SqlParameter("@BugID",BugID),
					new SqlParameter("@ReplyMessage", HttpUtility.HtmlEncode(txtWinPrize.Text))
			    };

				SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_Bug_Reply", arParms);


				grdBugList.DataBind();
				ModalPopupExtender.Hide();
				//return;
			}
			else
			{
				GridView grdTmp = grdBugList;
				string BugID = hfBugID.Value;
				string Email = hfEmail.Value;

				string MailBody = "感謝您的 意見 回饋<br/><br/>" +
								  "您的問題：<br/>" +
								  lblBug.Text + "<br/><br/>" +
								  "回覆內容如下：<br/>" +
								  HttpUtility.HtmlEncode(txtWinPrize.Text);
				//base.SendMail(base.m_MailSender,
				//              Email,
				//              "客服中心 - Bug 回報",
				//              MailBody);

				System.Net.Mail.MailMessage objMsg = new System.Net.Mail.MailMessage();
				objMsg.To.Add(Email);
				objMsg.Subject = "[老子有錢] 客服中心 - 意見 回饋";
				objMsg.Body = base.ReplaceBr(MailBody);
				objMsg.IsBodyHtml = true;
				System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
				client.Send(objMsg);


				SqlParameter[] arParms =
				{
					new SqlParameter("@BugID",BugID),
					new SqlParameter("@BugStatus",e.CommandName.Equals("Publish")?2:3),
					new SqlParameter("@IsPublic",e.CommandName.Equals("Publish")?1:0),
					new SqlParameter("@ExecAgentID",AUser.ExecAgentID),
					new SqlParameter("@BonusReason",HttpUtility.HtmlEncode(txtWinPrize.Text))
				};

				SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_Bug_Edit", arParms);
				grdTmp.DataBind();



				ModalPopupExtender.Hide();
			}
		}

		protected void grdBugList_RowCreated(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				AuthorityInfo aiPage = new AuthorityInfo();
				// 為 Button 加上 RowIndex
				Button btnDetail = (Button)e.Row.FindControl("btnDetail");
				btnDetail.CommandArgument = e.Row.RowIndex.ToString();

				// 處理該加 Button 或是顯示狀態
				Panel pnlBugState = (Panel)e.Row.FindControl("pnlBugState");

				// ※※※ 下面這段先別急著改，等需求確定要這樣之後，再把共用程式碼提出 2009/09/24
				switch (grdBugList.DataKeys[e.Row.RowIndex]["BugStatus"].ToString())
				{

					// 未處理的狀態
					case "0":
						{
							Button btnCommand1 = new Button();
							btnCommand1.Text = "回覆收到";
							btnCommand1.CommandName = "BugReply";
							btnCommand1.CommandArgument = e.Row.RowIndex.ToString();
							btnCommand1.Visible = aiPage.IsEditable;
							pnlBugState.Controls.Add(btnCommand1);
							break;
						}

					// 目前為處理中的狀態，所以有兩個按鈕可按 【發佈】【不發佈】
					case "1":
						{
							Button btnCommand1 = new Button();
							btnCommand1.Text = "處理完成";
							btnCommand1.CommandName = "BugFinish";
							btnCommand1.CommandArgument = e.Row.RowIndex.ToString();
							btnCommand1.Visible = aiPage.IsEditable;
							pnlBugState.Controls.Add(btnCommand1);
							break;
						}

					// 已發佈
					case "2":
					case "3":
						{
							Button btnCommand1 = new Button();
							btnCommand1.Text = "編輯";
							btnCommand1.CommandName = "BugFinish";
							btnCommand1.CommandArgument = e.Row.RowIndex.ToString();
							btnCommand1.Visible = aiPage.IsEditable;
							pnlBugState.Controls.Add(btnCommand1);
							break;
						}
				}
			}
		}

		protected void dsBugList_Selected(object sender, SqlDataSourceStatusEventArgs e)
		{
			hdn_ReplyDefaultValue.Value = e.Command.Parameters["@ReplyMessage"].Value.ToString();
			UCPager1.RecordCount = Convert.ToInt32(e.Command.Parameters["@TotalRecords"].Value);
			UCPager1.DataBind();
		}

		protected void btnSearch_Click(object sender, EventArgs e)
		{
			dsBugList.SelectParameters["StartDate"].DefaultValue = DateRange1.StartDate;
			dsBugList.SelectParameters["EndDate"].DefaultValue = DateRange1.EndDate;
			UCPager1.CurrentPageNumber = 1;
			grdBugList.DataBind();
			dsBugDetail.SelectParameters["BugID"].DefaultValue = "";
			dvBugDetail.Visible = false;
		}

		protected void grdBugList_RowDataBound(object sender, GridViewRowEventArgs e)
		{


			//將帳號轉 帳號*****
			foreach (GridViewRow Rows in grdBugList.Rows)
			{
				Rows.Cells[2].Text = Utility.GetAccAccountTo(Rows.Cells[2].Text).ToString();
			}

			// 下面這段的用意是讓畫面能夠正確的顯示斷行資料
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				Label lblGrdBugTitle = (Label)e.Row.FindControl("lblGrdBugTitle");
				if (lblGrdBugTitle != null) lblGrdBugTitle.Text = ReplaceBr(lblGrdBugTitle.Text);
			}
		}

		protected void dvBugDetail_ItemCreated(object sender, EventArgs e)
		{
			if (dvBugDetail.DataKey.Values.Count > 0)
			{
				switch (dvBugDetail.DataKey["BugStatus"].ToString())
				{

					// 未處理的狀態
					case "0":
						{
							dvBugDetail.Rows[4].Cells[1].Text = "尚未處理";
							break;
						}

					// 目前為處理中的狀態
					case "1":
						{
							dvBugDetail.Rows[4].Cells[1].Text = "處理中";
							break;
						}

					// 已發佈
					case "2":
						{
							dvBugDetail.Rows[4].Cells[1].Text = "已發佈";
							break;
						}

					// 不發佈
					case "3":
						{
							dvBugDetail.Rows[4].Cells[1].Text = "不發佈";
							break;
						}
				}

				dvBugDetail.Rows[5].Cells[1].Text = base.ReplaceBr(dvBugDetail.DataKey["BugTitle"].ToString());
				dvBugDetail.Rows[6].Cells[1].Text = base.ReplaceBr(dvBugDetail.DataKey["ReplyMessage"].ToString());
				dvBugDetail.Rows[7].Cells[1].Text = base.ReplaceBr(dvBugDetail.DataKey["BugDesc"].ToString());
				dvBugDetail.Rows[12].Cells[1].Text = base.ReplaceBr(dvBugDetail.DataKey["BonusReason"].ToString());
			}
		}

		protected void DateRangeChange(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;
			UCPager1.CurrentPageNumber = 1;
			btnSearch_Click(null, null);
		}

		protected void PagerChange(object sender, EventArgs e)
		{
			LoadData();
		}
	}
}