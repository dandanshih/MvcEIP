﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class BonusPointQuery : GWeb.AppLibs.FormBase
	{
		#region private

		private void LoadBonusPoint()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@DateType", rdlDateUnit.SelectedItem.Value),
				new SqlParameter("@MemberAccount", txtMemberAccount.Text),
				new SqlParameter("@NickName", txtNickName.Text),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords", DbType.Int32)
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_CommonMoney",
														   param);

			gvBonusPointQuery.DataSource = objDtr;
			gvBonusPointQuery.DataBind();

			objDtr.Close();

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
			{
				WebUtility.ResponseScript(Page, "alert('只能查詢2個月內的記錄!');", WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			// 重新搜尋時設定第一頁
			UCPager1.CurrentPageNumber = 1;

			LoadBonusPoint();
		}

		protected void UCDateRange1_Change(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;
			
			// 重新搜尋時設定第一頁
			UCPager1.CurrentPageNumber = 1;

			LoadBonusPoint();
		}

		/// <summary>
		/// 分頁事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void UCPager1_Change(object sender, AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadBonusPoint();
		}

		protected void gvBonusPointQuery_RowCommand(object sender, GridViewCommandEventArgs e)
		{

		}

		protected void gvBonusPointQuery_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				((Button)e.Row.FindControl("btnDetail")).OnClientClick = string.Format("window.open('BonusPointDetail.aspx?startdate={0}&enddate={1}&memberaccount={2}&nickname={3}', '紅利積點明細', 'width=500px, height=500px'); return false;", DataBinder.Eval(e.Row.DataItem, "CreateDate").ToString().Split(" - ")[0], DataBinder.Eval(e.Row.DataItem, "CreateDate").ToString().Trim().Split(" - ")[1], Server.UrlEncode(txtMemberAccount.Text), Server.UrlEncode(txtNickName.Text));
			}
		}

		protected void gvBonusPointQuery_DataBound(object sender, EventArgs e)
		{
			decimal commonMoney = 0;
			decimal counts = 0;

			// 加總
			foreach (GridViewRow row in gvBonusPointQuery.Rows)
			{
				commonMoney += decimal.Parse(((Label)row.FindControl("lblCommonMoney")).Text);
				counts += decimal.Parse(((Label)row.FindControl("lblCounts")).Text);
			}

			if (gvBonusPointQuery.FooterRow != null)
			{
				((Label)gvBonusPointQuery.FooterRow.FindControl("lblCreateDateFooter")).Text = "總計";
				((Label)gvBonusPointQuery.FooterRow.FindControl("lblCommonMoneyAmount")).Text = commonMoney.ToString("N0");
				((Label)gvBonusPointQuery.FooterRow.FindControl("lblCountsAmount")).Text = counts.ToString("N0");
			}
		}

		#endregion
	}
}