﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Reports
{
    public partial class C105 : FormBase
    {
        #region Private Method
        /// <summary>
        /// 繫結資料。
        /// </summary>
        private void BindData()
        {
            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_ECO2013020015_R_RankList"
            );

            gvList1.DataSource = objDr;
            gvList1.DataBind();

            objDr.Close();
        }

        /// <summary>
        /// 取得總彩金。
        /// </summary>
        private void BindTotalJP()
        {
            txtCurrentJP.Text = SqlHelper.ExecuteScalar
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_ECO2013020015_AgentWeb_Special7ActivityCurrentJP_Get"
            ).ToString();
        }

        /// <summary>
        /// 編輯總彩金。
        /// </summary>
        private void UpdateTotalJP()
        {
            string message = "";
            int currentJP = 0;

            if (!int.TryParse(txtCurrentJP.Text.Trim(), out currentJP))
            {
                message = "請輸入正確格式！";
            }
            else
            {
                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.connectionString,
                    CommandType.StoredProcedure,
                    "NSP_ECO2013020015_AgentWeb_Special7ActivityCurrentJP_Edit",
                    new SqlParameter("@Special7ActivityCurrentJP", txtCurrentJP.Text)
                );

                message = "修改成功！";
            }

            ScriptManager.RegisterStartupScript(Page, GetType(), "msg", "alert('" + message + "');", true);
        }
        #endregion

        #region Protected Method
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 查詢事件。
        /// </summary>
        protected void btnQuery_Click(object sender, EventArgs e)
        {
            BindTotalJP();
            BindData();
        }

        /// <summary>
        /// 編輯事件。
        /// </summary>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            UpdateTotalJP();
        }
        #endregion
    }
}