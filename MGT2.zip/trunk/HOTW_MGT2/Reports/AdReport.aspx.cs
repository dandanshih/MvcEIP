﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web.WebControls;
using GWeb.AppLibs;

namespace GWeb.Reports
{
    public partial class AdReport : GWeb.AppLibs.FormBase
    {
        private void LoadPublisher()
        {
            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.CPAGatewayDB,
                CommandType.StoredProcedure,
                "NSP_GetPublisher"
            );

            if (objDr.HasRows)
            {
                ddlAdList.Items.Add(new ListItem("全部", "0"));
                while (objDr.Read())
                {
                    ddlAdList.Items.Add(new ListItem(objDr["PublisherName"].ToString(), objDr["PublisherId"].ToString()));
                }
            }

            objDr.Close();
        }

        private void LoadData()
        {
            SqlParameter[] param = 
            {
                new SqlParameter("PublisherId", ddlAdList.SelectedValue),
                new SqlParameter("StartDate", ucDataRange.StartDate),
                new SqlParameter("EndDate", ucDataRange.EndDate)
            };

            SqlDataReader sdr = SqlHelper.ExecuteReader
            (
                WebConfig.CPAGatewayDB,
                CommandType.StoredProcedure,
                "NSP_GetPublisherList",
                param
            );

            grdAdList.DataSource = sdr;
            grdAdList.DataBind();

            sdr.Close();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPublisher();
            } 
        }

        protected void btnQuery_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}