﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class BonusPointDetail : GWeb.AppLibs.FormBase
	{
		#region private

		private void LoadBonusPointDetail()
		{
			DateTime startDate = DateTime.Parse(Request.QueryString["startdate"].ToString());
			DateTime endDate = DateTime.Parse(Request.QueryString["enddate"].ToString());
			string memberAccount = Request.QueryString["memberaccount"].ToString();
			string nickName = Request.QueryString["nickname"].ToString();

			SqlParameter[] param =
			{
				new SqlParameter("@BeginDate", startDate.ToString("yyyy-MM-dd HH:mm:ss")),
				new SqlParameter("@EndDate", endDate.ToString("yyyy-MM-dd HH:mm:ss")),
				new SqlParameter("@MemberAccount", memberAccount),
				new SqlParameter("@NickName", nickName)
				//new SqlParameter("@PageSize", UCPager1.PageSize),
				//new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				//new SqlParameter("@TotalRecords", DbType.Int32)
			};

			//param[5].Direction = ParameterDirection.Output;

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_CommonMoneyDetail",
														   param);

			gvBonusPointDetail.DataSource = objDtr;
			gvBonusPointDetail.DataBind();

			objDtr.Close();

			////UCPager1.RecordCount = int.Parse(param[5].Value.ToString());
			////UCPager1.DataBind();
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			LoadBonusPointDetail();
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			// 重新搜尋時設定第一頁
			//UCPager1.CurrentPageNumber = 1;

			LoadBonusPointDetail();
		}

		protected void UCDateRange1_Change(object sender, EventArgs e)
		{
			// 重新搜尋時設定第一頁
			//UCPager1.CurrentPageNumber = 1;

			LoadBonusPointDetail();
		}

		/// <summary>
		/// 分頁事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void UCPager1_Change(object sender, AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadBonusPointDetail();
		}

		protected void gvBonusPointDetail_RowCommand(object sender, GridViewCommandEventArgs e)
		{

		}

		protected void gvBonusPointDetail_DataBound(object sender, EventArgs e)
		{
			decimal commonMoney = 0;

			// 加總
			foreach (GridViewRow row in gvBonusPointDetail.Rows)
			{
				commonMoney += decimal.Parse(((Label)row.FindControl("lblCommonMoney")).Text);
			}

			if (gvBonusPointDetail.FooterRow != null)
			{
                ((Label)gvBonusPointDetail.FooterRow.FindControl("lblMemberAccountAmount")).Text = "總計";
				((Label)gvBonusPointDetail.FooterRow.FindControl("lblCommonMoneyAmount")).Text = commonMoney.ToString();
			}
		}

		#endregion
	}
}