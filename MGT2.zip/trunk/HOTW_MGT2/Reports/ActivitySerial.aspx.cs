﻿using System;
using System.Web.UI;
using GFC;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class ActivitySerial : GWeb.AppLibs.FormBase
	{


		#region  Private方法

		/// <summary>
		/// 載入活動序號資料
		/// </summary>
		private void LoadData()
		{
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@PinCode", txtActivitySerial.Text),
				new SqlParameter("@MemberAccount",txtMemberAccount.Text),
				new SqlParameter("@NickName", txtNickName.Text),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};
			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_PinCodeSearch",
				param
			);

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();

			PnSerch.Visible = true;
			grdActivitySerial.DataSource = ds.Tables[0];
			grdActivitySerial.DataBind();
		}

		/// <summary>
		/// 明細查詢事件
		/// </summary>
		/// <param name="Pincode"></param>
		private void LoadDetail(string Pincode) 
		{
			
			SqlParameter[] param = new SqlParameter[]
					{
						new SqlParameter("@Pincode", Pincode)
					};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_PinCodeSearch_Detail",
				param
			);
			grdActivitySerialDetail.DataSource = ds.Tables[0];
			grdActivitySerialDetail.DataBind();	
		
		}

		#endregion

		#region Protected方法

		/// <summary>
		/// 查詢事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{

			UCPager1.CurrentPageNumber = 1;
			LoadData();
			PnDetail.Visible= false;
		}

		
		/// <summary>
		/// 明細RowCommand事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void grdActivitySerial_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			
	
			if (e.CommandName == "Detail") 
			{
				PnDetail.Visible = true;
				//int iRowIndex = Convert.ToInt32(e.CommandArgument);
				string Pincode = grdActivitySerial.DataKeys[Convert.ToInt32(e.CommandArgument)].Values["Pincode"].ToString();

				LoadDetail(Pincode);

			
			}

		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			LoadData();
		}

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		#endregion
	}
}