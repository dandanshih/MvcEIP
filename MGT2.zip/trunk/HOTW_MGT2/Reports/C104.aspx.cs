﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Reports
{
	public partial class C104 : FormBase
	{
		#region Private Method
		/// <summary>
		/// 繫結資料。
		/// </summary>
		private void BindData()
		{
			gvList1.Visible = false;
			gvList2.Visible = false;

			SqlParameter[] param =
            {
				new SqlParameter("@EventID", ddlEventID.SelectedValue),
                new SqlParameter("@RankType", ddlRankType.SelectedValue),
                new SqlParameter("@Top", ddlTop.SelectedValue)
            };

			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_RankList_NewYearActivity",
				param
			);

			switch (ddlRankType.SelectedValue)
			{
				case "1":
				case "3":
					gvList1.DataSource = objDr;
					gvList1.DataBind();
					gvList1.Visible = true;
					break;
				case "2":
					gvList2.DataSource = objDr;
					gvList2.DataBind();
					gvList2.Visible = true;
					break;
			}

			objDr.Close();
		}
		#endregion

		#region Protected Method
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack)
			{
				SqlParameter[] param1 =
            {
				new SqlParameter("@ResultCode", SqlDbType.SmallInt),
				new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
            };

				param1[0].Direction = ParameterDirection.Output;
				param1[1].Direction = ParameterDirection.Output;

				DataTable objDr1 = SqlHelper.ExecuteDataset
				(
					WebConfig.connectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_S_RankMasterType_NewYearActivity",
					param1
				).Tables[0];

				ddlRankType.Items.Clear();
				ddlRankType.DataTextField = "RankTypeDesc";
				ddlRankType.DataValueField = "RankType";
				ddlRankType.DataSource = objDr1;
				ddlRankType.DataBind();

				SqlParameter[] param2 =
            {
                new SqlParameter("@EventGroupID", DBNull.Value),
				new SqlParameter("@ResultEventID", SqlDbType.VarChar,20),
				new SqlParameter("@ResultCode", SqlDbType.SmallInt),
				new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
            };

				param2[1].Direction = ParameterDirection.Output;
				param2[2].Direction = ParameterDirection.Output;
				param2[3].Direction = ParameterDirection.Output;

				DataTable objDr2 = SqlHelper.ExecuteDataset
				(
					WebConfig.connectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_S_EventInfoList",
					param2
				).Tables[0];

				ddlEventID.Items.Clear();
				ddlEventID.DataTextField = "Memo";
				ddlEventID.DataValueField = "EventID";
				ddlEventID.DataSource = objDr2;
				ddlEventID.DataBind();
			}
		}

		/// <summary>
		/// 查詢事件。
		/// </summary>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			BindData();
		}
		#endregion
	}
}