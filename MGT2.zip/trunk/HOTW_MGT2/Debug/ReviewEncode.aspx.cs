﻿using System;
using GFC;

namespace GWeb.Debug
{
	public partial class ReviewEncode : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			string encode = "";

			GFC.Cryptography.EncryptData(txtRoundCode.Text.ToSafeString() + "," + txtAccount.Text.ToSafeString() + "," + txtAuth.Text.ToSafeString(), out encode, "veryhappy");

			txtResult.Text = "?id=" + encode;
		}
	}
}