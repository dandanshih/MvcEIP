﻿using System;
using System.Reflection;

namespace GWeb.Debug
{
	public partial class Version : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			Assembly objAsm = Assembly.GetExecutingAssembly();
			Response.Write(objAsm.GetName().Version.ToString());
		}
	}
}