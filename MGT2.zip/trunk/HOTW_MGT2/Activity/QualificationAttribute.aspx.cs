﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationAttribute : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();

        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                this.BindData();
            }
        }

        protected void UCPager_QualificationAttribute_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        private void BindData()
        {
            int take = this.UCPager_QualificationAttribute.PageSize;
            int skip = (this.UCPager_QualificationAttribute.CurrentPageNumber - 1) * take;
            var query = this.db.C_QualificationAttribute;

            // 繫結分頁
            this.UCPager_QualificationAttribute.RecordCount = query.Count();
            this.UCPager_QualificationAttribute.DataBind();

            // 繫結資料
            this.GV_QualificationAttribute.DataSource = query
                .OrderBy(x => x.QualificationAttributeID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_QualificationAttribute.DataBind();
        }
    }
}