﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationDetail_Add : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DDL_QualificationID.DataSource = this.game_activity.C_QualificationCategory.ToList();
                DDL_QualificationID.DataTextField = "QualificationName";
                DDL_QualificationID.DataValueField = "QualificationID";
                DDL_QualificationID.DataBind();

                DDL_QualificationAttributeID.DataSource = this.game_activity.C_QualificationAttribute.ToList();
                DDL_QualificationAttributeID.DataTextField = "QualificationAttributeName";
                DDL_QualificationAttributeID.DataValueField = "QualificationAttributeID";
                DDL_QualificationAttributeID.DataBind();
            }
        }

        protected void BTN_QualificationDetail_Add_Click(object sender, EventArgs e)
        {
            if ((IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int qualificationID = int.TryParse(DDL_QualificationID.SelectedValue, out qualificationID) ? qualificationID : 0;
                int aualificationAttributeID = int.TryParse(DDL_QualificationAttributeID.SelectedValue, out aualificationAttributeID) ? aualificationAttributeID : 0;
                int qualificationAttributeValue = int.TryParse(TBX_QualificationAttributeValue.Text, out qualificationAttributeValue) ? qualificationAttributeValue : 0;

                this.game_activity.C_QualificationDetail.Add(new C_QualificationDetail()
                    {
                        QualificationID = qualificationID,
                        QualificationAttributeID = aualificationAttributeID,
                        QualificationAttributeValue = qualificationAttributeValue
                    });
                this.game_activity.SaveChanges();
                Response.Redirect("QualificationDetail.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}