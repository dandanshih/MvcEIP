﻿//-----------------------------------------------------------------------
// <copyright file="MarqueeSetting.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Activity
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Entity;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using GS.Utilities;
    using GWeb.AppLibs;
    using GWeb.AppUserControls.Activity;
    using GWeb.Models;
    using System.IO;
    using Newtonsoft.Json;

    /// <summary>
    /// Mission Setting Class
    /// </summary>
    public partial class MarqueeSetting : GWeb.AppLibs.FormBase
    {
        #region Properties
        /// <summary>
        /// View State Name
        /// </summary>
        private const string ImportList = "__ImportList__";

        /// <summary>
        /// Activity DB 連線物件
        /// </summary>
        private Game_Activity_Context gameActivityContext = new Game_Activity_Context();

        /// <summary>
        /// Branch DB 連線物件
        /// </summary>
        private Game_Branch_Context gameBranchContext = new Game_Branch_Context();

        /// <summary>
        /// 目前選取的GameID
        /// </summary>
        private int GameID
        {
            get
            {
                return Convert.ToInt32(ddl_GameList.SelectedValue);
            }
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// 繫結訊息資料
        /// </summary>
        private void LoadData()
        {
            this.ViewState["MissionListSelectedRowIndex"] = null;
            int gameid = this.GameID;

            int take = this.UCPager_Mission.PageSize;
            int skip = (this.UCPager_Mission.CurrentPageNumber - 1) * take;
            var query = this.gameActivityContext.MissionMarquee
                .Where(x => x.GameID == gameid)
                .Select(obj => new
                {
                    MarqueeID = obj.MarqueeID,
                    MissionID = obj.MissionID,
                    GameID = obj.GameID,
                    TypeFlag = obj.TypeFlag,
                    TypeName = obj.TypeFlag == 1 ? "跑馬燈" : "FB 發布訊息",
                    Message_ZHTW = obj.Message_ZHTW,
                    Message_ENUS = obj.Message_ENUS
                });

            // 繫結分頁筆數
            this.UCPager_Mission.RecordCount = query.Count();
            this.UCPager_Mission.DataBind();

            // 繫結資料列表
            this.GV_Mission.DataSource = query
                .OrderBy(x => x.MissionID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_Mission.DataBind();
        }

        /// <summary>
        /// 轉制跑馬燈json 檔
        /// </summary>
        private void ImportMarquee()
        {
            // UploadFiles 與 DataInfo、前台共用
            const string FileFullPath = "~/Html/UploadFiles/MiscData/MarqueeFormat.json";
            // flag 1: 跑馬燈, flag 2: FB
            const int flag = 1;

            var query = this.gameActivityContext.MissionMarquee
                .Where(x => (x.TypeFlag & flag) == flag)
                .Select(obj => new { MissionID = obj.MissionID, Message_ZHTW = obj.Message_ZHTW });

            if (query.Count() == 0)
            {
                return;
            }
            Dictionary<string, string> dicResult = new Dictionary<string, string>();
            foreach (var obj in query)
            {
                dicResult.Add(obj.MissionID.ToString(), obj.Message_ZHTW);
            }
            string jsonData = JsonConvert.SerializeObject(dicResult);

            string saveFilePath = Server.MapPath(FileFullPath);

            string saveFolder = Path.GetDirectoryName(saveFilePath);
            if (!Directory.Exists(saveFolder))
            {
                Directory.CreateDirectory(saveFolder);
            }
            if (!File.Exists(saveFilePath))
            {
                var file = File.Create(saveFilePath);
                file.Close();
            }

            File.WriteAllText(saveFilePath, jsonData);
        }

        /// <summary>
        /// 轉制FB發布js 檔
        /// </summary>
        private void ImportFacebook()
        {
            // UploadFiles 與 DataInfo、前台共用
            const string FileFullPath = "~/Html/UploadFiles/MiscData/FacebookFeedMessage.js";
            // flag 1: 跑馬燈, flag 2: FB
            const int flag = 2;

            var query = this.gameActivityContext.MissionMarquee
                .Where(x => (x.TypeFlag & flag) == flag)
                .Select(obj => new { MissionID = obj.MissionID, Message_ZHTW = obj.Message_ZHTW });

            if (query.Count() == 0)
            {
                return;
            }
            Dictionary<string, string> dicResult = new Dictionary<string, string>();
            foreach (var obj in query)
            {
                dicResult.Add(obj.MissionID.ToString(), obj.Message_ZHTW);
            }
            string jsonData = string.Format
            (
                "var FacebookFeedMessage={0}",
                JsonConvert.SerializeObject(dicResult)
            );


            string saveFilePath = Server.MapPath(FileFullPath);

            string saveFolder = Path.GetDirectoryName(saveFilePath);
            if (!Directory.Exists(saveFolder))
            {
                Directory.CreateDirectory(saveFolder);
            }
            if (!File.Exists(saveFilePath))
            {
                var file = File.Create(saveFilePath);
                file.Close();
            }

            File.WriteAllText(saveFilePath, jsonData, System.Text.Encoding.UTF8);
        }
        #endregion

        #region Protected Methods
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var gameQuery = this.gameBranchContext.G_Game.Where(x => x.GameID > 1000).ToList();
                // 繫結遊戲列表
                this.ddl_GameList.DataSource = gameQuery.Select(obj => new { GameID = obj.GameID, GameName = string.Format("({0}) {1}", obj.GameID, obj.GameName) }).ToList();
                this.ddl_GameList.DataValueField = "GameID";
                this.ddl_GameList.DataTextField = "GameName";
                this.ddl_GameList.DataBind();

                // 繫結任務
                LoadData();
            }
        }

        /// <summary>
        /// 遊戲下拉選單選項變更事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddl_GameList_SelectedIndexChanged(object sender, EventArgs e)
        {
            UCPager_Mission.CurrentPageNumber = 1;
            // 繫結任務
            this.LoadData();
        }

        /// <summary>
        /// 任務資料分頁
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_Mission_Change(object sender, EventArgs e)
        {
            this.LoadData();
        }

        /// <summary>
        /// 新增任務
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Mission_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    int missionid = int.TryParse(this.TBX_Mission_MissionID.Text, out missionid) ? missionid : 0;
                    int gameid = this.GameID;
                    //bool isenable = bool.TryParse(this.DDL_Mission_IsEnable.SelectedValue, out isenable) ? isenable : false;
                    int typeflag = int.TryParse(this.DDL_Marquee_type.SelectedValue, out typeflag) ? typeflag : 0;
                    MissionMarquee model = new MissionMarquee()
                    {
                        MissionID = missionid,
                        GameID = gameid,
                        TypeFlag = typeflag,
                        Message_ZHTW = TBX_Message_ZHTW.Text,

                    };

                    this.gameActivityContext.MissionMarquee.Add(model);
                    this.gameActivityContext.SaveChanges();

                    // 重新繫結任務資料
                    this.LoadData();

                    TBX_Mission_MissionID.Text = string.Empty;

                    TBX_Message_ZHTW.Text = string.Empty;


                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 刪除任務
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_Mission_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                //int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
                //int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

                int id = int.TryParse(e.CommandArgument.ToString(), out id) ? id : 0;

                switch (e.CommandName)
                {

                    case "DelMission":
                        var item = this.gameActivityContext.MissionMarquee.Find(id);

                        if (item != null)
                        {

                            this.gameActivityContext.MissionMarquee.Remove(item);
                            this.gameActivityContext.SaveChanges();

                            // 重新繫結資料
                            this.LoadData();
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 檔案上傳
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Upload_Click(object sender, EventArgs e)
        {
            if (this.FU_File.HasFile)
            {
                // 原本讀取檔案資料的格式如下，因文件檔內都會有BOM 標頭，只用以下解法無法去除BOM 標頭
                // string data = System.Text.UTF8Encoding.UTF8.GetString(this.FU_File.FileBytes);
                string data = string.Empty;
                using (var mem_reader = new MemoryStream(this.FU_File.FileBytes))
                {
                    using (var reader = new StreamReader(mem_reader, true))
                    {
                        data = reader.ReadToEnd();
                    }
                }
                List<ViewModel> list = JsonConvert.DeserializeObject<List<ViewModel>>(data);
                this.ViewState[ImportList] = list;
                this.GV_Import.DataSource = list;
                this.GV_Import.DataBind();
                this.BTN_Import.Enabled = true;
            }
        }

        protected void btn_UploadFBPic_Click(object sender, EventArgs e)
        {
            string[] validExtension = new string[] { ".png" };
            const string filePath = "~/Html/UploadFiles/FBFeed/";
            if (this.fu_FBPic.HasFile)
            {
                var file = this.fu_FBPic.PostedFile;
                string extension = Path.GetExtension(file.FileName).ToLower();
                string filename = Path.GetFileNameWithoutExtension(file.FileName);
                int missionID = 0;
                if (!int.TryParse(filename, out missionID))
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertErr", "alert('檔名需為純數字的任務編號!');", true);
                    return;
                }
                if (!validExtension.Contains(extension))
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertErr", "alert('請上傳.png檔案格式!');", true);
                    return;
                }
                var data = this.gameActivityContext.MissionMarquee.Where(obj => obj.MissionID == missionID && obj.TypeFlag == 2).FirstOrDefault();
                if (data == null)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertErr", "alert('訊息不存在! 請先設定發布訊息');", true);
                    return;
                }
                string saveFilePath = Server.MapPath(filePath);

                string saveFolder = Path.GetDirectoryName(saveFilePath);
                if (!Directory.Exists(saveFolder))
                {
                    Directory.CreateDirectory(saveFolder);
                }
                if (File.Exists(saveFilePath + file.FileName))
                {
                    File.Delete(saveFilePath + file.FileName);
                }
                file.SaveAs(saveFilePath + file.FileName);
                ScriptManager.RegisterStartupScript(this, GetType(), "alertErr", "alert('上傳成功!');", true);
            }
        }

        /// <summary>
        /// 資料匯入
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Import_Click(object sender, EventArgs e)
        {
            if (this.ViewState[ImportList] != null)
            {
                List<ViewModel> list = ViewState[ImportList] as List<ViewModel>;
                foreach (ViewModel item in list)
                {
                    //var data = this.db.G_GameRule.FirstOrDefault(x => x.GameID == item.GameID && x.GroupID == item.GroupID);
                    var data = this.gameActivityContext.MissionMarquee.FirstOrDefault(x => x.MissionID == item.MissionID && x.GameID == item.GameID && x.TypeFlag == item.TypeFlag);
                    if (data == null)
                    {
                        // 資料不存在就新增
                        MissionMarquee Marquee = new MissionMarquee()
                        {
                            //MarqueeID=item.MarqueeID,
                            MissionID = item.MissionID,
                            GameID = item.GameID,
                            TypeFlag = item.TypeFlag,
                            Message_ZHTW = item.Message_ZHTW,
                            //Message_ENUS=item.Message_ENUS
                        };
                        this.gameActivityContext.MissionMarquee.Add(Marquee);
                    }
                    else
                    {
                        // 資料存在就更新
                        //data.MarqueeID=item.MarqueeID;
                        data.MissionID = item.MissionID;
                        data.GameID = item.GameID;
                        data.TypeFlag = item.TypeFlag;
                        data.Message_ZHTW = item.Message_ZHTW;
                        //data.Message_ENUS = item.Message_ENUS;

                    }

                    this.gameActivityContext.SaveChanges();
                }

                this.BTN_Import.Enabled = false;
            }
        }

        /// <summary>
        /// 將db 資料匯出json 檔
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_Export_Click(object sender, EventArgs e)
        {
            var query = this.gameActivityContext.MissionMarquee.Select(obj =>
                new ViewModel
                {
                    MissionID = obj.MissionID,
                    GameID = obj.GameID,
                    TypeFlag = obj.TypeFlag,
                    Message_ZHTW = obj.Message_ZHTW
                }).ToList();
            if (query.Count > 0)
            {
                string jsonString = JsonConvert.SerializeObject(query);
                string fileName = string.Format("MarqueeSetting-{0:yyyy-MM-dd-HH}.json", DateTime.Now);

                // 下載json格式
                Response.Clear();
                Response.ClearHeaders();
                Response.Buffer = false;
                Response.ContentType = "application/json";
                Response.AppendHeader("Content-Disposition", "attachment;filename=" + System.Web.HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8));

                // 字串長度有誤, 原因是跳脫字元"\"不會計算, 所以就不給長度了
                // HttpContext.Current.Response.AppendHeader("Content-Length", jsonString.Length.ToString());
                Response.Write(jsonString);
                Response.Flush();
                Response.End();
            }
        }

        /// <summary>
        /// 將db 資料匯入至前台 json 檔
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_ImportGameWeb_Click(object sender, EventArgs e)
        {
            try
            {
                ImportMarquee();
                ImportFacebook();
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('設定成功!');", true);
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('設定失敗!錯誤: " + ex.Message + "');", true);
            }
        }
        #endregion

        /// <summary>
        /// View Model
        /// </summary>
        [Serializable]
        private class ViewModel
        {
            public int MissionID { get; set; }
            public int GameID { get; set; }
            public int TypeFlag { get; set; }
            public string Message_ZHTW { get; set; }
        }
    }
}