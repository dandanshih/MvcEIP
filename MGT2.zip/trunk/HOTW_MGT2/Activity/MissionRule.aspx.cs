﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class MissionRule : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();

        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                this.BindData();
            }
        }

        protected void UCPager_MissionRule_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        private void BindData()
        {
            int take = this.UCPager_MissionRule.PageSize;
            int skip = (this.UCPager_MissionRule.CurrentPageNumber - 1) * take;
            var query = this.db.C_MissionRule;

            // 繫結分頁
            this.UCPager_MissionRule.RecordCount = query.Count();
            this.UCPager_MissionRule.DataBind();

            // 繫結資料
            this.GV_MissionRule.DataSource = query
                .OrderBy(x => x.MissionRuleID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_MissionRule.DataBind();
        }
    }
}