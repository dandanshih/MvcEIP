﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationAttribute_Edit : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.game_activity.C_QualificationAttribute.Find(id);
                if (item != null)
                {
                    TBX_QualificationAttributeName.Text = item.QualificationAttributeName;
                    TBX_QualificationAttributeKey.Text = item.QualificationAttributeKey;
                }
            }
        }

        protected void BTN_QualificationAttribute_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.game_activity.C_QualificationAttribute.Find(id);
                
                if (item != null)
                {
                    item.QualificationAttributeName = TBX_QualificationAttributeName.Text;
                    item.QualificationAttributeKey = TBX_QualificationAttributeKey.Text;
                }

                this.game_activity.SaveChanges();
                Response.Redirect("QualificationAttribute.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}