﻿//-----------------------------------------------------------------------
// <copyright file="ActivityExplanation.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Activity
{
	using System;
	using System.Data;
	using System.Data.Entity;
	using System.Linq;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using GS.Utilities;
	using GWeb.AppLibs;
	using GWeb.Models;
	using System.Data.SqlClient;
	using System.IO;

	/// <summary>
	/// 活動設定
	/// </summary>
	public partial class ActivityExplanation : GWeb.AppLibs.FormBase
	{
		private readonly string UploadFolderPath = "/Html/UploadFiles/ActivityExplanationImg/";

		/// <summary>
		/// Page Load
		/// </summary>
		/// <param name="sender">sender object</param>
		/// <param name="e">event args</param>
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.IsPostBack)
			{
				this.BindActivity();

			}
		}

		/// <summary>
		/// 繫結Activity資料
		/// </summary>
		protected void BindActivity()
		{
			SqlParameter[] param =
			{				
				new SqlParameter("@Platform", "Andriod"),
				new SqlParameter("@isEnable", 1)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_AD_MobileEvent_List",
														   param);
			this.GV_Activity.DataSource = objDtr;
			this.GV_Activity.DataBind();

			objDtr.Close();

		}

		#region buttion action
		//新增活動
		protected void AddNewActivity_Click(object sender, EventArgs e)
		{
			ClearData();
			this.divActivityEdit.Style["display"] = "";
			this.divActivityList.Style["display"] = "none";
		}
		//確認新增
		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			this.divActivityEdit.Style["display"] = "none";
			this.divActivityList.Style["display"] = "";
			if (this.hidAsID.Value == "")
			{
				InsertMobileEvent();
			}
			else
			{
			}
			this.BindActivity();
		}
		//取消新增
		protected void btnCancel_Click(object sender, EventArgs e)
		{
			ClearData();
			this.divActivityEdit.Style["display"] = "none";
			this.divActivityList.Style["display"] = "";
		}

		#endregion

		//新增活動至DB
		private void InsertMobileEvent()
		{
			// 檔名
			string fileName = DateTime.Now.ToString("yyyyMMddHHmmss") + this.TextBox1.Text;
			string uploadreturn = UploadPhoto(fileName, this.FileUpload1);
			//圖片上傳成功，再寫入DB
			if (uploadreturn == "success")
			{
				fileName = UploadFolderPath + fileName;
				SqlParameter[] param =
				{
				new SqlParameter("@EventName", this.txtActivityName.Text),
				new SqlParameter("@Platform", this.ddlPlatform.SelectedItem.Text),
				new SqlParameter("@StartDate", this.UCDateRange1.StartDate),
				new SqlParameter("@EndDate",  this.UCDateRange1.EndDate),
				new SqlParameter("@Content", this.txtActivityUrl.Text),
				new SqlParameter("@PicURL", fileName),	
				new SqlParameter("@isEnable", Convert.ToInt16(this.ddlEnable.SelectedValue)),
				new SqlParameter("@Description", "")
				};
				SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
															   CommandType.StoredProcedure,
															   "NSP_AgentWeb_AD_MobileEvent_Insert",
															   param);
			}
		}
		//更新活動至DB
		private void UpdateMobileEvent()
		{
			// 檔名
			string fileName = DateTime.Now.ToString("yyyyMMddHHmmss") + this.TextBox1.Text;
			string uploadreturn = UploadPhoto(fileName, this.FileUpload1);
			//圖片上傳成功，再寫入DB
			if (uploadreturn == "success")
			{
			}
		}

		//上傳圖片
		private string UploadPhoto(string fileName, FileUpload file)
		{
			string returnvalue = string.Empty;
			// 實體檔案路徑
			string filePath = Server.MapPath(UploadFolderPath) + fileName;

			if (File.Exists(filePath))
			{
				//message = "檔案已存在！請再次上傳。";
				returnvalue = "error";
			}
			else
			{
				try
				{
					file.SaveAs(filePath);
					returnvalue = "success";
				}
				catch
				{
					returnvalue = "error";
					ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('上傳失敗');", true);
					//message = "上傳失敗！";
				}
			}

			return returnvalue;
		}
		//清除資料
		private void ClearData()
		{
			this.hidAsID.Value = "";
			this.txtActivityName.Text = "";
		}

		protected void GV_Activity_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "Detail")
			{
				this.divActivityEdit.Style["display"] = "";
				this.divActivityList.Style["display"] = "none";
				this.hidAsID.Value = this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[0].Text.ToString();
				this.txtActivityName.Text = this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[1].Text.ToString();
				this.ddlPlatform.SelectedItem.Text = this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[2].Text.ToString();
				//this.FileUpload1..FileName = this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[3].Text.ToString();
				//this.FileUpload1.Attributes.Add("FileName", this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[3].Text.ToString());
				//this.UCDateRange1.StartDate = Convert.ToDateTime(this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[3].Text.ToString());
				//this.UCDateRange1.EndDate = Convert.ToDateTime(this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[4].Text.ToString());
				this.ddlEnable.SelectedValue = this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[5].Text.ToString();
				this.txtActivityUrl.Text = this.GV_Activity.Rows[Convert.ToInt32(e.CommandArgument)].Cells[8].Text.ToString();

			}
		}






	}
}