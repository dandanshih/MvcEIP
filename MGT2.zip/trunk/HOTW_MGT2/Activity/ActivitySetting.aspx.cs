﻿//-----------------------------------------------------------------------
// <copyright file="ActivitySetting.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Activity
{
    using System;
    using System.Data;
    using System.Data.Entity;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using GS.Utilities;
    using GWeb.AppLibs;
    using GWeb.Models;

    /// <summary>
    /// 活動設定
    /// </summary>
    public partial class ActivitySetting : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 資料存取物件
        /// </summary>
        private Game_Activity_Context ctx = new Game_Activity_Context();

        /// <summary>
        /// 釋放連線資源
        /// </summary>
        public override void Dispose()
        {
            this.ctx.Dispose();
            base.Dispose();
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindActivity();
                ddl_ActivityRecordID.DataSource = this.ctx.C_ActivityRecord.ToList();
                ddl_ActivityRecordID.DataValueField = "ActivityRecordID";
                ddl_ActivityRecordID.DataTextField = "ActivityRecordName";
                ddl_ActivityRecordID.DataBind();
            }
        }

        /// <summary>
        /// 活動排程明細
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_Activity_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "Detail":
                    DateTime scheduleDateTime = DateTime.Now.AddMinutes(10);
                    DP_ScheduleActivity_ScheduleDateTime.SelectedDate = scheduleDateTime;
                    Record_ScheduleDateTime.SelectedDate = scheduleDateTime;

                    int rowIndex = int.TryParse(e.CommandArgument.ToString(), out rowIndex) ? rowIndex : 0;
                    hdf_ActivityID.Value = ((GridView)sender).DataKeys[rowIndex].Value.ToString();
                    this.BindScheduleActivity();
                    this.BindScheduleActivityRecord();

                    if (this.ViewState["RowIndex"] != null)
                    {
                        ((GridView)sender).Rows[(int)this.ViewState["RowIndex"]].BackColor = System.Drawing.Color.Empty;
                    }

                    ((GridView)sender).Rows[rowIndex].BackColor = System.Drawing.Color.LightGreen;
                    this.ViewState["RowIndex"] = rowIndex;

                    break;
                default:
                    break;
            }
        }

        #region Activity
        /// <summary>
        /// Activity 分頁
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UCPager_Activity_Change(object sender, EventArgs e)
        {
            this.BindActivity();
        }

        /// <summary>
        /// 繫結Activity資料
        /// </summary>
        protected void BindActivity()
        {
            int take = this.UCPager_Activity.PageSize;
            int skip = (this.UCPager_Activity.CurrentPageNumber - 1) * take;
            var query = this.ctx.Activity;

            // 繫結分頁筆數
            this.UCPager_Activity.RecordCount = query.Count();
            this.UCPager_Activity.DataBind();

            // 繫結資料列表
            this.GV_Activity.DataSource = query
                .OrderByDescending(x => x.ActivityID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_Activity.DataBind();
        }

        /// <summary>
        /// 新增活動資料
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Activity_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    bool isenable = bool.TryParse(DDL_Activity_IsEnable.SelectedValue, out isenable) ? isenable : false;

                    Activity model = new Activity()
                    {
                        ActivityName = TBX_Activity_ActivityName.Text,
                        ProgName = TBX_Activity_ProgName.Text,
                        DLLName = TBX_Activity_DLLName.Text,
                        ActivityRule = TBX_Activity_ActivityRule.Text,
                        IsEnable = isenable
                    };

                    this.ctx.Activity.Add(model);
                    this.ctx.SaveChanges();
                    this.BindActivity();
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }
        #endregion

        #region ScheduleActivity
        /// <summary>
        /// Schedule Activity 分頁
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_ScheduleActivity_Change(object sender, EventArgs e)
        {
            this.BindScheduleActivity();
        }

        /// <summary>
        /// 繫結排程資料
        /// </summary>
        protected void BindScheduleActivity()
        {
            int id = int.TryParse(hdf_ActivityID.Value, out id) ? id : 0;
            int take = this.UCPager_ScheduleActivity.PageSize;
            int skip = (this.UCPager_ScheduleActivity.CurrentPageNumber - 1) * take;
            var query = this.ctx.ScheduleActivity
                .Where(x => x.ActivityID == id);

            this.phScheduleActivity.Visible = true;

            // 繫結分頁筆數
            this.UCPager_ScheduleActivity.RecordCount = query.Count();
            this.UCPager_ScheduleActivity.DataBind();

            // 繫結資料列表
            this.GV_ScheduleActivity.DataSource = query.Include(x => x.C_ScheduleState)
                .OrderByDescending(x => x.ScheduleActivityID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_ScheduleActivity.DataBind();
        }

        /// <summary>
        /// 排程記錄繫結
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleActivity_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ScheduleActivity row = e.Row.DataItem as ScheduleActivity;

                if (row.ScheduleStateID == 2 || row.ScheduleStateID >= 4)
                {
                    Button btn = e.Row.Cells[4].Controls[0] as Button;
                    if (btn != null)
                    {
                        btn.Visible = false;
                    }
                }
            }
        }

        /// <summary>
        /// 新增活動排程
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Btn_ScheduleActivity_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    int activityID = int.TryParse(hdf_ActivityID.Value, out activityID) ? activityID : 0;
                    bool isEnable = bool.TryParse(DDL_ScheduleActivity_IsEnable.SelectedValue, out isEnable) ? isEnable : false;
                    ScheduleActivity model = new ScheduleActivity()
                    {
                        ActivityID = activityID,
                        ScheduleDateTime = DP_ScheduleActivity_ScheduleDateTime.SelectedDate,
                        ActivityRule = TBX_ScheduleActivity_ActivityRule.Text,
                        IsEnable = isEnable,
                        ScheduleStateID = isEnable ? 1 : 3
                    };

                    this.ctx.ScheduleActivity.Add(model);
                    this.ctx.SaveChanges();

                    // 通知Activity Server
                    if (!HttpClientHelper.PostRequest("api/ActivityEntity/" + model.ScheduleActivityID))
                    {
                        WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                    }
                }

                // 重新繫結資料
                this.BindScheduleActivity();
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 刪除Schedule Activity資料
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleActivity_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "DeleteScheduleActivity":
                        int rowIndex = int.TryParse(e.CommandArgument.ToString(), out rowIndex) ? rowIndex : 0;
                        int idx = (int)((GridView)sender).DataKeys[rowIndex].Value;
                        var item = this.ctx.ScheduleActivity.Find(idx);

                        if (item != null)
                        {
                            item.ScheduleStateID = 5;
                            this.ctx.Entry(item).State = EntityState.Modified;
                            this.ctx.SaveChanges();

                            // 通知Activity Server
                            if (!HttpClientHelper.DeleteRequest("api/ActivityEntity/" + item.ScheduleActivityID))
                            {
                                WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                            }
                        }

                        break;
                    default:
                        break;
                }

                // 重新繫結資料
                this.BindScheduleActivity();
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }
        #endregion

        #region ScheduleActivityRecord
        /// <summary>
        /// Schedule Activity Record 分頁
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_ScheduleActivityRecord_Change(object sender, EventArgs e)
        {
            this.BindScheduleActivityRecord();
        }

        /// <summary>
        /// 繫結記錄排程資料
        /// </summary>
        protected void BindScheduleActivityRecord()
        {
            this.phScheduleActivityRecord.Visible = true;

            int id = int.TryParse(hdf_ActivityID.Value, out id) ? id : 0;
            int take = this.UCPager_ScheduleActivityRecord.PageSize;
            int skip = (this.UCPager_ScheduleActivityRecord.CurrentPageNumber - 1) * take;
            var query = this.ctx.ScheduleActivityRecord
                .Where(x => x.ActivityID == id);

            // 繫結分頁筆數
            this.UCPager_ScheduleActivityRecord.RecordCount = query.Count();
            this.UCPager_ScheduleActivityRecord.DataBind();
            
            // 繫結資料列表
            this.GV_ScheduleActivityRecord.DataSource = query
                .Where(x => x.ActivityID == id)
                .OrderByDescending(x => x.ScheduleActivityRecordID)
                .Skip(skip)
                .Take(take)
                .Include(x => x.C_ActivityRecord)
                .Include(x => x.C_ScheduleState)
                .ToList();
            this.GV_ScheduleActivityRecord.DataBind();
            
        }

        /// <summary>
        /// Activity Record 資料繫結
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleActivityRecord_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ScheduleActivityRecord row = e.Row.DataItem as ScheduleActivityRecord;

                if (row.ScheduleStateID == 2 || row.ScheduleStateID >= 4)
                {
                    Button btn = e.Row.Cells[3].Controls[0] as Button;
                    if (btn != null)
                    {
                        btn.Visible = false;
                    }
                }
            }
        }

        /// <summary>
        /// 新增記錄排程
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Btn_ScheduleActivityRecord_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    int activityID = int.TryParse(hdf_ActivityID.Value, out activityID) ? activityID : 0;
                    int ativityRecordID = int.TryParse(ddl_ActivityRecordID.SelectedValue, out ativityRecordID) ? ativityRecordID : 0;
                    ScheduleActivityRecord model = new ScheduleActivityRecord()
                    {
                        ActivityID = activityID,
                        ActivityRecordID = ativityRecordID,
                        ScheduleDateTime = Record_ScheduleDateTime.SelectedDate,
                        ScheduleStateID = 1
                    };

                    this.ctx.ScheduleActivityRecord.Add(model);
                    this.ctx.SaveChanges();

                    // 通知Activity Server
                    if (!HttpClientHelper.PostRequest("api/ActivityRecordReset/" + model.ScheduleActivityRecordID))
                    {
                        WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                    }
                }

                // 重新繫結資料
                this.BindScheduleActivityRecord();
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 刪除Schedule Activity Record
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleActivityRecord_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "DeleteScheduleActivityRecord":
                        int rowIndex = int.TryParse(e.CommandArgument.ToString(), out rowIndex) ? rowIndex : 0;
                        int idx = (int)((GridView)sender).DataKeys[rowIndex].Value;
                        var item = this.ctx.ScheduleActivityRecord.Find(idx);

                        if (item != null)
                        {
                            item.ScheduleStateID = 5;
                            this.ctx.Entry(item).State = EntityState.Modified;
                            this.ctx.SaveChanges();

                            // 通知Activity Server
                            if (!HttpClientHelper.DeleteRequest("api/ActivityRecordReset/" + item.ScheduleActivityRecordID))
                            {
                                WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                            }
                        }

                        break;
                    default:
                        break;
                }

                // 重新繫結資料
                this.BindScheduleActivityRecord();
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }
        #endregion
    }
}