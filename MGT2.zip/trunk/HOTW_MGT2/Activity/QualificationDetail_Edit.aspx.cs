﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationDetail_Edit : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                DDL_QualificationID.DataSource = this.game_activity.C_QualificationCategory.ToList();
                DDL_QualificationID.DataTextField = "QualificationName";
                DDL_QualificationID.DataValueField = "QualificationID";
                DDL_QualificationID.DataBind();

                DDL_QualificationAttributeID.DataSource = this.game_activity.C_QualificationAttribute.ToList();
                DDL_QualificationAttributeID.DataTextField = "QualificationAttributeName";
                DDL_QualificationAttributeID.DataValueField = "QualificationAttributeID";
                DDL_QualificationAttributeID.DataBind();

                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.game_activity.C_QualificationDetail.Find(id);
                if (item != null)
                {
                    TBX_QualificationAttributeValue.Text = item.QualificationAttributeValue.ToString();
                }
            }
        }

        protected void BTN_QualificationDetail_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.game_activity.C_QualificationDetail.Find(id);
                if (item != null)
                {
                    int qualificationID = int.TryParse(DDL_QualificationID.SelectedValue, out qualificationID) ? qualificationID : 0;
                    int aualificationAttributeID = int.TryParse(DDL_QualificationAttributeID.SelectedValue, out aualificationAttributeID) ? aualificationAttributeID : 0;
                    int qualificationAttributeValue = int.TryParse(TBX_QualificationAttributeValue.Text, out qualificationAttributeValue) ? qualificationAttributeValue : 0;

                    item.QualificationID = qualificationID;
                    item.QualificationAttributeID = aualificationAttributeID;
                    item.QualificationAttributeValue = qualificationAttributeValue;
                }

                this.game_activity.SaveChanges();
                Response.Redirect("QualificationDetail.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}