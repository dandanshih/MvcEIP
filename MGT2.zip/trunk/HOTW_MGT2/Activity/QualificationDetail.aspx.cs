﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationDetail : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();
        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                this.BindData();
            }
        }

        protected void UCPager_QualificationDetail_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        private void BindData()
        {
            int take = this.UCPager_QualificationDetail.PageSize;
            int skip = (this.UCPager_QualificationDetail.CurrentPageNumber - 1) * take;
            var query = this.db.C_QualificationDetail;

            // 繫結分頁
            this.UCPager_QualificationDetail.RecordCount = query.Count();
            this.UCPager_QualificationDetail.DataBind();

            // 繫結資料
            this.GV_QualificationDetail.DataSource = query
                .OrderBy(x => x.QualificationDetailID)
                .Skip(skip)
                .Take(take)
                .Include(x=>x.C_QualificationCategory)
                .Include(x=>x.C_QualificationAttribute)
                .ToList();
            this.GV_QualificationDetail.DataBind();
        }
    }
}