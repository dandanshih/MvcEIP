﻿//-----------------------------------------------------------------------
// <copyright file="ActivityRecord.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Activity
{
    using GWeb.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;

    using System.Web.UI.WebControls;
    public partial class ActivityRecord : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();

        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                this.BindData();
            }
        }

        /// <summary>
        /// 換頁重新繫結資料
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UCPager_ActivityRecord_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        private void BindData()
        {
            int take = this.UCPager_ActivityRecord.PageSize;
            int skip = (this.UCPager_ActivityRecord.CurrentPageNumber - 1) * take;
            var query = this.db.C_ActivityRecord;

            // 繫結分頁
            this.UCPager_ActivityRecord.RecordCount = query.Count();
            this.UCPager_ActivityRecord.DataBind();

            // 繫結資料
            this.GV_ActivityRecord.DataSource = query
                .OrderBy(x => x.ActivityRecordID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_ActivityRecord.DataBind();

        }
    }
}