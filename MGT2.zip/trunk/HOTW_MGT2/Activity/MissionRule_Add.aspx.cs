﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class MissionRule_Add : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();
        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BTN_MissionRule_Add_Click(object sender, EventArgs e)
        {
            if ((IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                this.db.C_MissionRule.Add(new C_MissionRule()
                {
                    MissionRuleName = TBX_MissionRuleName.Text,
                    Rule1 = TBX_Rule1.Text,
                    Rule2 = TBX_Rule2.Text,
                    Rule3 = TBX_Rule3.Text,
                    Rule4 = TBX_Rule4.Text
                });
                this.db.SaveChanges();
                Response.Redirect("J06.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}