﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationCategory_Add : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BTN_QualificationCategory_Add_Click(object sender, EventArgs e)
        {
            if ((IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                this.game_activity.C_QualificationCategory.Add(new Models.C_QualificationCategory()
                    {
                        QualificationName = TBX_QualificationName.Text
                    });
                this.game_activity.SaveChanges();
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}