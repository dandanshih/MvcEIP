﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationCategory : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();

        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                this.BindData();
            }
        }

        protected void UCPager_QualificationCategory_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        private void BindData()
        {
            int take = this.UCPager_QualificationCategory.PageSize;
            int skip = (this.UCPager_QualificationCategory.CurrentPageNumber - 1) * take;
            var query = this.db.C_QualificationCategory;

            // 繫結分頁
            this.UCPager_QualificationCategory.RecordCount = query.Count();
            this.UCPager_QualificationCategory.DataBind();

            // 繫結資料
            this.GV_QualificationCategory.DataSource = query
                .OrderBy(x => x.QualificationID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_QualificationCategory.DataBind();
        }
    }
}