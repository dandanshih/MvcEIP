﻿//-----------------------------------------------------------------------
// <copyright file="MissionSetting.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Activity
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Entity;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using GS.Utilities;
    using GWeb.AppLibs;
    using GWeb.AppUserControls.Activity;
    using GWeb.Models;

    /// <summary>
    /// Mission Setting Class
    /// </summary>
    public partial class MissionSetting : GWeb.AppLibs.FormBase, IActivityPage
    {
        private Game_Activity_Context gameActivityContext = new Game_Activity_Context();
        private Game_Serial_Context gameSerial = new Game_Serial_Context();
        private Game_Branch_Context gameBranchContext = new Game_Branch_Context();

        public override void Dispose()
        {
            this.gameActivityContext.Dispose();
            this.gameSerial.Dispose();
            this.gameBranchContext.Dispose();
            base.Dispose();
        }

        public Game_Activity_Context GameActivityContext
        {
            get
            {
                return this.gameActivityContext;
            }
        }

        /// <summary>
        /// Gets Activity ID
        /// </summary>
        public int ActivityID
        {
            get
            {
                int activityid = int.TryParse(DDL_ActivityID.SelectedValue, out activityid) ? activityid : 0;
                return activityid;
            }
        }

        /// <summary>
        /// Mission ID
        /// </summary>
        public int MissionID
        {
            get
            {
                if (ViewState["MissionID"] == null)
                {
                    ViewState["MissionID"] = 0;
                }

                return Convert.ToInt32(ViewState["MissionID"]);
            }
            private set
            {
                ViewState["MissionID"] = value;
            }
        }

        /// <summary>
        /// Gets TempScheduleMissionGift List
        /// </summary>
        public List<TempScheduleMissionGift> TempScheduleMissionGiftList
        {
            get
            {
                if (this.ViewState["ScheduleMissionGift"] == null)
                {
                    this.ViewState["ScheduleMissionGift"] = new List<TempScheduleMissionGift>();
                }

                return ViewState["ScheduleMissionGift"] as List<TempScheduleMissionGift>;
            }
        }

        private List<ItemList> itemList;
        /// <summary>
        /// Item List Collection
        /// </summary>
        public List<ItemList> ItemList
        {
            get
            {
                if (this.itemList == null)
                {
                    this.itemList = this.gameSerial.ItemList.ToList();
                }

                return this.itemList;
            }
        }

        private List<G_Game> gamelist;
        public List<G_Game> GameList
        {
            get
            {
                if (this.gamelist == null)
                {
                    this.gamelist = this.gameBranchContext.G_Game.Where(x => x.GameID > 1000).ToList();
                }
                return this.gamelist;
            }
        }

        private List<C_MissionRule> missionrulelist;
        public List<C_MissionRule> MissionRuleList
        {
            get
            {
                if (this.missionrulelist == null)
                {
                    this.missionrulelist = this.gameActivityContext.C_MissionRule.ToList();
                }
                return this.missionrulelist;
            }
        }
        
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                // 繫結活動資料
                this.DDL_ActivityID.DataSource = this.gameActivityContext.Activity.ToList();
                this.DDL_ActivityID.DataValueField = "ActivityID";
                this.DDL_ActivityID.DataTextField = "ActivityName";
                this.DDL_ActivityID.DataBind();

                // 繫結任務
                this.Mission1.LoadData();
            }
        }

        /// <summary>
        /// 選擇活動, 繫結相關任務
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void DDL_ActivityID_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 繫結任務
            this.Mission1.LoadData();
            this.MissionGift1.Visible = false;
            this.MissionGame1.Visible = false;
            this.MissionQualification1.Visible = false;
            this.ScheduleMission1.Visible = false;
            this.ScheduleMissionQualification1.Visible = false;
            this.ScheduleMissionRule1.Visible = false;
        }

        protected void Mission1_MissionGridViewClick(object sender, MissionEventArgs e)
        {
            this.TempScheduleMissionGiftList.Clear();
            this.MissionID = e.ID;
            this.MissionGift1.Visible = true;
            this.MissionGift1.LoadData();
            this.MissionGame1.Visible = true;
            this.MissionGame1.LoadData();
            this.MissionQualification1.Visible = true;
            this.MissionQualification1.LoadData();

            this.ScheduleMission1.Visible = true;
            this.ScheduleMission1.LoadData();

            this.ScheduleMissionQualification1.Visible = true;
            this.ScheduleMissionQualification1.LoadData();
            this.ScheduleMissionRule1.Visible = true;
            this.ScheduleMissionRule1.LoadData();
        }

        protected void MissionGame1_OnGridViewClick(object sender, MissionEventArgs e)
        {
            this.MissionGame1.LoadData();
            this.ScheduleMissionRule1.LoadData();
        }

        protected void MissionQualification1_OnGridViewClick(object sender, MissionEventArgs e)
        {
            this.MissionQualification1.LoadData();
            this.ScheduleMissionQualification1.LoadData();
        }

        public void CloseAllUserControl()
        {
            this.MissionGift1.Visible = false;
            this.MissionGame1.Visible = false;
            this.MissionQualification1.Visible = false;
            this.ScheduleMission1.Visible = false;
            this.ScheduleMissionRule1.Visible = false;
            this.ScheduleMissionQualification1.Visible = false;
        }
    }
}