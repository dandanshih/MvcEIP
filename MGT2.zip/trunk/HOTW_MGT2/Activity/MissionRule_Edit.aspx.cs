﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class MissionRule_Edit : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();
        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.db.C_MissionRule.Find(id);
                if (item != null)
                {
                    TBX_MissionRuleName.Text = item.MissionRuleName;
                    TBX_Rule1.Text = item.Rule1;
                    TBX_Rule2.Text = item.Rule2;
                    TBX_Rule3.Text = item.Rule3;
                    TBX_Rule4.Text = item.Rule4;
                }
            }
        }

        protected void BTN_MissionRule_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.db.C_MissionRule.Find(id);
                
                if (item != null)
                {
                    item.MissionRuleName = TBX_MissionRuleName.Text;
                    item.Rule1 = TBX_Rule1.Text;
                    item.Rule2 = TBX_Rule2.Text;
                    item.Rule3 = TBX_Rule3.Text;
                    item.Rule4 = TBX_Rule4.Text;
                    this.db.SaveChanges();
                }

                Response.Redirect("MissionRule.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}