﻿//-----------------------------------------------------------------------
// <copyright file="ActivityRecord_Add.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Activity
{

    using GWeb.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    public partial class ActivityRecord_Add : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();
        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void BTN_activityRecord_Add_Click(object sender, EventArgs e)
        {
            if ((IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                this.db.C_ActivityRecord.Add(new C_ActivityRecord()
                {
                    ActivityRecordName = TBX_ActivityRecordName.Text
                });
                this.db.SaveChanges();

                Response.Redirect("ActivityRecord.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}