﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Activity
{
    public partial class QualificationCategory_Edit : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.Page.IsPostBack)
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.game_activity.C_QualificationCategory.Find(id);
                if (item != null)
                {
                    TBX_QualificationName.Text = item.QualificationName;
                }
            }
        }

        protected void BTN_QualificationName_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.game_activity.C_QualificationCategory.Find(id);
                if (item != null)
                {
                    item.QualificationName = TBX_QualificationName.Text;
                }
                this.game_activity.SaveChanges();
                Response.Redirect("QualificationCategory.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}