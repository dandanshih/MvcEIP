﻿//-----------------------------------------------------------------------
// <copyright file="ActivityRecord_Edit.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Activity
{
    using GWeb.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    public partial class ActivityRecord_Edit : GWeb.AppLibs.FormBase
    {
        private Game_Activity_Context db = new Game_Activity_Context();
        
        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.db.C_ActivityRecord.Find(id);

                if (item != null)
                {
                    TBX_ActivityRecordName.Text = item.ActivityRecordName;
                }
            }
        }

        protected void BTN_ActivityRecord_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
                var item = this.db.C_ActivityRecord.Find(id);
                if (item != null)
                {
                    item.ActivityRecordName = TBX_ActivityRecordName.Text;
                    this.db.SaveChanges();
                    Response.Redirect("ActivityRecord.aspx");
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}