﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Marketing
{
	public partial class H102 : GWeb.AppLibs.FormBase
	{
		private void BindList()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@AgentID", AUser.ExecAgentID),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),	
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_Count",
				param
			);

			gvList.DataSource = ds;
			gvList.DataBind();

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				// BindList();
			}		
		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			BindList();
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			BindList();
		}
	}
}