﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Marketing
{
	public partial class H101 : GWeb.AppLibs.FormBase
	{
		private bool Add()
		{ 
			SqlParameter[] param = 
			{
				new SqlParameter("@AgentAccount", txtAccount.Text),
				new SqlParameter("@AgentPassword", txtPassword.Text),
				new SqlParameter("@AgentNickName", txtShopName.Text),
				new SqlParameter("@ContactWindow", txtName.Text),
				new SqlParameter("@ContactTEL", txtPhone.Text),
				new SqlParameter("@RegisterVIPMax", txtRegisterVIPLimit.Text),
				new SqlParameter("@ChangeGiftMax", txtExchangeSNLimit.Text),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_Add",
				param
			);

			int result = int.Parse(ds.Tables[0].Rows[0]["Result"].ToString());

			if (result == 0)
			{
				return true;
			}
			else if (result == 1)
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('帳號重複');", true);
				return false;
			}
			else if (result == 2)
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('店家名稱重複');", true);
				return false;
			}
			else
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), string.Format("alert('新增失敗({0})');", result), true);
				return false;
			}
		}

		private void EditEnable(string id, string enable)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@TypeID", "2"),
				new SqlParameter("@AgentID", id),
				new SqlParameter("@AgentAccount", ""),
				new SqlParameter("@AgentPassword", ""),
				new SqlParameter("@AgentNickName", ""),
				new SqlParameter("@ContactWindow", ""),
				new SqlParameter("@ContactTEL", ""),
				new SqlParameter("@RegisterVIPMax", ""),
				new SqlParameter("@ChangeGiftMax", ""),						
				new SqlParameter("@IsStop", enable),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};

			SqlHelper.ExecuteNonQuery
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_Edit",
				param
			);
		}

		private void BindList()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),	
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_List",
				param
			);

			gvList.DataSource = ds;
			gvList.DataBind();

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindList();
			}			
		}

		protected void gvList_RowEditing(object sender, GridViewEditEventArgs e)
		{
			gvList.EditIndex = e.NewEditIndex;
			BindList();
		}

		protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "Edit")
			{

			}
			else if (e.CommandName == "Enable")
			{
				EditEnable(e.CommandArgument.ToString(), "0");
				UCPager1.CurrentPageNumber = 1;
				gvList.EditIndex = -1;
				BindList();
			}
			else if (e.CommandName == "Disable")
			{
				EditEnable(e.CommandArgument.ToString(), "1");
				UCPager1.CurrentPageNumber = 1;
				gvList.EditIndex = -1;
				BindList();
			}
		}

		protected void gvList_RowUpdating(object sender, GridViewUpdateEventArgs e)
		{
			SqlParameter[] param = 
			{
				new SqlParameter("@TypeID", "1"),
				new SqlParameter("@AgentID", e.Keys["AgentID"]),
				new SqlParameter("@AgentAccount", e.NewValues["AgentAccount"]),
				new SqlParameter("@AgentPassword", e.NewValues["AgentPassword"]),
				new SqlParameter("@AgentNickName", e.NewValues["AgentNickName"]),
				new SqlParameter("@ContactWindow", e.NewValues["ContactWindow"]),
				new SqlParameter("@ContactTEL", e.NewValues["ContactTEL"]),
				new SqlParameter("@RegisterVIPMax", e.NewValues["RegisterVIPMax"]),
				new SqlParameter("@ChangeGiftMax", e.NewValues["ChangeGiftMax"]),
				new SqlParameter("@IsStop", e.NewValues["IsStop"]),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_Edit",
				param
			);

			int result = int.Parse(ds.Tables[0].Rows[0]["Result"].ToString());

			if (result == 0)
			{
				gvList.EditIndex = -1;
				BindList();
			}
			else if (result == 1)
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('帳號重複');", true);
			}
			else if (result == 2)
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('店家名稱重複');", true);
			}
			else
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), string.Format("alert('更新失敗({0})');", result), true);
			}			
		}

		protected void gvList_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
		{
			gvList.EditIndex = -1;
			BindList();
		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			gvList.EditIndex = -1;
			BindList();
		}

		protected void btnAdd_Click(object sender, EventArgs e)
		{
			phAdd.Visible = true;
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			if (!Page.IsValid)
			{
				return;
			}

			if (Add())
			{
				phAdd.Visible = false;
				BindList();
			}
		}		
	}
}