﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Marketing
{
	public partial class H105 : GWeb.AppLibs.FormBase
	{
		private void BindShopList()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_DropList",
				param
			);

			ddlShop.DataTextField = "AgentNickName";
			ddlShop.DataValueField = "AgentID";

			ddlShop.DataSource = ds;
			ddlShop.DataBind();

			ddlShop.Items.Insert(0, new ListItem("全部", "0"));
		}

		private void BindList()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@AgentID", ddlShop.SelectedItem.Value),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),	
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_SerialNo_List",
				param
			);

			gvList.DataSource = ds;
			gvList.DataBind();

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();

			lblTotalExchangeCount.Text = param[param.Length - 1].Value.ToString();
		}

		private void BindList2()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@SerialNo", rblType.SelectedItem.Value == "1" ? txtValue.Text : ""),
				new SqlParameter("@MemberAccount", rblType.SelectedItem.Value == "2" ? txtValue.Text : ""),
				new SqlParameter("@NickName", rblType.SelectedItem.Value == "3" ? txtValue.Text : ""),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};			

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_SerialNoSearch",
				param
			);

			gvList2.DataSource = ds;
			gvList2.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindShopList();
				// BindList();
			}
		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			BindList();
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			BindList();
		}

		protected void btnQuery2_Click(object sender, EventArgs e)
		{
			BindList2();
		}
	}
}