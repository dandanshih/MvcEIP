﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using System.Data.SqlClient;
using GS.Utilities;
using System.Data;
using System.IO;

namespace GWeb.Marketing
{
	public partial class M101 : FormBase
	{
		#region Properties
        private string QryAgentID
        {
            get { return hdn_AgentID.Value; }
            set { hdn_AgentID.Value = value; }
        }

        private string QryAgentNickName
        {
            get { return hdn_AgentNickName.Value; }
            set { hdn_AgentNickName.Value = value; }
        }
		#endregion

        #region Private Method
		/// <summary>
		/// 增加子節點。
		/// </summary>
		/// <param name="node">要增加子節點的節點。</param>
		/// <param name="isSecurityCheck">是否作權限相關檢查。</param>
		private void AddChildNode(TreeNode node)
		{
			// 避免子節點重 Load 的時候出現 error
			node.ChildNodes.Clear();
			node.PopulateOnDemand = false;

			SqlParameter[] param =
            {
                // 查詢代理商編號
                new SqlParameter("@AgentID", node.Value),
				new SqlParameter("@IsNext", "True")
            };

			SqlDataReader sdr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_BingoDynastyList",
				param
			);

			while (sdr.Read())
			{
				TreeNode ndChild = new TreeNode();
				ndChild.Text = sdr["AgentNickName"].ToString();
				ndChild.Value = sdr["AgentID"].ToString();
				ndChild.PopulateOnDemand = (sdr["AgentCount"].ToString() == "0") ? false : true;
				ndChild.Collapse();

				node.ChildNodes.Add(ndChild);
			}

			sdr.Close();
		}

		private void InitTree()
		{
			TreeView1.Nodes.Clear();
			// 建立根節點
			TreeNode node = new TreeNode();
			node.Text = AUser.AgentNickName;
			node.Value = AUser.AgentID;
			node.PopulateOnDemand = false;
			node.Collapse();
			node.Selected = true;
			TreeView1.Nodes.Add(node);

			// 根節點為預設查詢的代理商
			QryAgentID = node.Value;
			QryAgentNickName = node.Text;
			BindCodeList();
			// 增加子節點
			AddChildNode(node);
		}

		private void BindDataList()
		{
			pnl_Detail.Visible = false;
			pnl_AddMember.Visible = false;
			SqlParameter[] param =
            {
				new SqlParameter("@TotMemberCnt", SqlDbType.Int),
				new SqlParameter("@isShow", SqlDbType.Bit),
                // 查詢代理商編號
                new SqlParameter("@AgentID", ddl_CodeList.Visible ? ddl_CodeList.SelectedValue : QryAgentID),
				new SqlParameter("@StartDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@ExecAgentID", AUser.AgentID)
            };
            param[0].Direction = ParameterDirection.Output;
            param[1].Direction = ParameterDirection.Output;
			DataTable objTab = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_MemberSourceCountData",
				param
			).Tables[0];

			gv_DataList.DataSource = objTab;
			gv_DataList.DataBind();

			lbl_TotalCount.Text = string.Format
			(
				"總人數：{0}",
				param[0].Value
			);
		}

		private void BindCodeList()
		{
			SqlParameter[] param =
            {
                // 查詢代理商編號
                new SqlParameter("@AgentID", QryAgentID),
				new SqlParameter("@IsNext", "True"),
				new SqlParameter("@IsAll", "True")
            };

			DataTable objTab = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_BingoDynastyList",
				param
			).Tables[0];
			ddl_CodeList.DataSource = objTab;
			ddl_CodeList.DataBind();
		}

		private void CheckLevel(bool isFirst = false)
		{
			SqlDataReader objSdr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_BingoHierarchyLevel",
				new SqlParameter("@AgentID", string.IsNullOrEmpty(QryAgentID) ? AUser.AgentID : QryAgentID)
			);
			if (objSdr.Read())
			{
				int level = Convert.ToInt32(objSdr["BingoHierarchyLevel"]);
				bool TopLimit = Convert.ToBoolean(hdn_TopLimit.Value);
				if (level >= 2)
				{
					ddl_CodeList.Visible = false;
					if (TopLimit)
					{
						btn_Add.Visible = false;
					}
				}
				else
				{
					if (level == 1 && isFirst)
					{
						hdn_TopLimit.Value = false.ToString();
						btn_Add.Visible = false;
						ddl_CodeList.Visible = true;
					}
					else
					{
						ddl_CodeList.Visible = true;
						if (TopLimit)
						{
							btn_Add.Visible = true;
						}
					}
				}
			}
			objSdr.Close();
		}
		#endregion

		#region Protected Method
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				InitTree();
				CheckLevel(true);
				
				//BindDataList();
			}
		}

		/// <summary>
		/// TreeView ItemPopulate事件。
		/// 展開子節點無資料時觸發。
		/// </summary>
		protected void TreeView1_ItemPopulate(object sender, TreeNodeEventArgs e)
		{
			AddChildNode(e.Node);
		}

		/// <summary>
		/// TreeView 選擇事件。
		/// </summary>
		protected void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
		{
			//// 紀錄查詢的代理商編號
			QryAgentID = TreeView1.SelectedNode.Value;
			QryAgentNickName = TreeView1.SelectedNode.Text;
			// 先查詢現在等級
			CheckLevel();
			// 重新繫結下拉選單
			BindCodeList();
			BindDataList();
		}

		protected void gv_DataList_RowCreated(object sender, GridViewRowEventArgs e)
		{
			//因為設置了AutoGenerateColumns="true" 樣版:明細會排在第一個
			//所以在此更換欄位位置
			GridViewRow row = e.Row;
			List<TableCell> columns = new List<TableCell>();
			foreach (DataControlField column in gv_DataList.Columns)
			{
				TableCell cell = row.Cells[0];
				row.Cells.Remove(cell);
				columns.Add(cell);
			}

			row.Cells.AddRange(columns.ToArray());
		}

		protected void gv_DataList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "Detail")
			{
				pnl_Detail.Visible = true;
				SqlParameter[] param =
				{
				    new SqlParameter("@isShow", SqlDbType.Bit),
					// 查詢代理商編號
					new SqlParameter("@AgentID", ddl_CodeList.Visible ? ddl_CodeList.SelectedValue : QryAgentID),
					new SqlParameter("@Date", Convert.ToDateTime(e.CommandArgument).ToString("yyyy/MM/dd HH:mm:ss")),
					new SqlParameter("@ExecAgentID", AUser.AgentID)
				};
                param[0].Direction = ParameterDirection.Output;

				DataTable objTab = SqlHelper.ExecuteDataset
				(
					WebConfig.connectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_MemberSourceCountData_Details",
					param
				).Tables[0];
				gv_DataDetail.DataSource = objTab;
				gv_DataDetail.DataBind();
			}
		}

		protected void btn_Add_Click(object sender, EventArgs e)
		{
			pnl_AddMember.Visible = true;
			txt_Account.Text = "";
			txt_Password.Text = "";
			txt_NickName.Text = "";
		}

		protected void btn_Edit_Click(object sender, EventArgs e)
		{
			Response.Redirect("M101_Edit.aspx");
		}

		protected void btn_Query_Click(object sender, EventArgs e)
		{
			BindDataList();
		}

		protected void btn_Exchange_Click(object sender, EventArgs e)
		{
			SqlParameter[] param =
		    {
		        new SqlParameter("@AgentID", QryAgentID),
				new SqlParameter("@StartDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@ExecAgentID", AUser.AgentID)
		    };

			DataTable objTab = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_MemberSourceCountData_MemberList",
				param
			).Tables[0];

			objTab.TableName = "通路名單";
			objTab.Columns["CreateDate"].ColumnName = "時間";
			objTab.Columns["SNO"].ColumnName = "通路序號";
			//objTab.Columns["MemberAccount"].ColumnName = "會員帳號";
			objTab.Columns["NickName"].ColumnName = "會員暱稱";
			objTab.Columns.Remove("MemberAccount");

			NPOIRender.ExportDataTableToEXcel(objTab, Response);
			// 產生 Excel 資料流。
			//MemoryStream ms = NPOIRender.ExportMemberIPComparisonToEXcel(objDs) as MemoryStream;
			//// 設定強制下載標頭。
			//string fileName = "" + DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss") + ".xls";
			//Response.AddHeader("Content-Disposition", string.Format("attachment; filename=" + fileName));
			//// 輸出檔案。
			//Response.BinaryWrite(ms.ToArray());
			//Response.End();
			//ms.Close();
			//ms.Dispose();
		}

		protected void btn_AddAgent_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(txt_Account.Text) || string.IsNullOrEmpty(txt_Password.Text) || string.IsNullOrEmpty(txt_NickName.Text))
			{
				ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('序號、密碼或暱稱不可空白！');", true);
				return;
			}
			SqlParameter[] objParam = new SqlParameter[]
			{
				new SqlParameter("@AgentAccount", txt_Account.Text),
				new SqlParameter("@AgentPassword", txt_Password.Text),
				new SqlParameter("@AgentNickName", txt_NickName.Text),
				// Check What's AgentID
				new SqlParameter("@ExecuteAgentID", AUser.AgentID),
				new SqlParameter("@UpAgentID", QryAgentID)
			};
			SqlDataReader objSdr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_BingoSNo_Add",
				objParam
			);
			if (objSdr.Read())
			{
				if (objSdr["Result"].ToString() != "0")
				{
					string ErrorMsg = string.Empty;
					switch (objSdr["Result"].ToString())
					{
						case "1":
							ErrorMsg = "序號輸入有誤";
							break;
						case "2":
							ErrorMsg = "序號重複";
							break;
						case "3":
							ErrorMsg = "無此權限";
							break;
						case "4":
							ErrorMsg = "密碼格式錯誤";
							break;
						default:
							ErrorMsg = "執行失敗！";
							break;
					}
					//pnl_AddMember.Visible = false;
					ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('" + ErrorMsg + "');", true);
				}
				else
				{
					pnl_AddMember.Visible = false;
					InitTree();
					BindDataList();
				}
			}
			objSdr.Close();
		}
		#endregion
	}
}