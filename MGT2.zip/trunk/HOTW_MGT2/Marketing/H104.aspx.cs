﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Marketing
{
	public partial class H104 : GWeb.AppLibs.FormBase
	{
		private bool Add()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@SerialNo", txtSN.Text),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_SerialNo_Check",
				param
			);

			int result = int.Parse(ds.Tables[0].Rows[0]["Result"].ToString());
			string message = ds.Tables[0].Rows[0]["Msg"].ToString();

			ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), string.Format("alert('{0}');", message), true);

			if (result == 1)
			{			
				return true;
			}
			else if (result == 2)
			{			
				return false;
			}
			else if (result == 3)
			{			
				return false;
			}
			else if (result == 4)
			{			
				return false;
			}
			else if (result == 5)
			{			
				return false;
			}
			else if (result == 6)
			{				
				return false;
			}
			else
			{				
				return false;
			}			
		}

		private void BindShopList()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_DropList",
				param
			);

			ddlShop.DataTextField = "AgentNickName";
			ddlShop.DataValueField = "AgentID";

			ddlShop.DataSource = ds;
			ddlShop.DataBind();

			ddlShop.Items.Insert(0, new ListItem("全部", "0"));
		}

		private void BindList()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@AgentID", ddlShop.SelectedItem.Value),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),	
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Partner_SerialNo_List",
				param
			);

			gvList.DataSource = ds;
			gvList.DataBind();

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();

			lblTotalExchangeCount.Text = param[param.Length - 1].Value.ToString();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindShopList();
				// BindList();
			}
		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			BindList();
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			BindList();
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			if (txtSN.Text.Trim().Length == 0)
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('請輸入序號');", true);
				return;
			}

			if (Add())
			{
				UCPager1.CurrentPageNumber = 1;
				BindList();
			}
		}
	}
}