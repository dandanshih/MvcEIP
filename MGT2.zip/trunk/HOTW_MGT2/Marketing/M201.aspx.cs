﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using System.Data.SqlClient;
using System.Data;
using GFC.Utilities;
using System.IO;

namespace GWeb.Marketing
{
    public partial class M201 : FormBase
    {
        private readonly string UploadFolderPath = "/Html/UploadFiles/ActionCallFor/";

        #region Property
        /// <summary>
        /// 起始日期。
        /// </summary>
        private string StartDate
        {
            get { return ViewState["StartDate"] == null ? "2010/01/01 00:00:00" : ViewState["StartDate"].ToString(); }
            set { ViewState["StartDate"] = value; }
        }

        /// <summary>
        /// 結束日期。
        /// </summary>
        private string EndDate
        {
            get { return ViewState["EndDate"] == null ? "2099/12/31 23:59:59" : ViewState["EndDate"].ToString(); }
            set { ViewState["EndDate"] = value; }
        }

        /// <summary>
        /// 查詢類型。
        /// </summary>
        private int QueryType
        {
            get { return ViewState["QueryType"] == null ? 1 : int.Parse(ViewState["QueryType"].ToString()); }
            set { ViewState["QueryType"] = value; }
        }

        /// <summary>
        /// 查詢資料。
        /// </summary>
        private string QueryData
        {
            get { return ViewState["QueryData"] == null ? "" : ViewState["QueryData"].ToString(); }
            set { ViewState["QueryData"] = value; }
        }

        /// <summary>
        /// 查詢狀態類型。
        /// </summary>
        private int LogStatus
        {
            get { return ViewState["LogStatus"] == null ? 1 : int.Parse(ViewState["LogStatus"].ToString()); }
            set { ViewState["LogStatus"] = value; }
        }
        #endregion

        #region Private Method
        /// <summary>
        /// 繫結資料表。
        /// </summary>
        private void BindReport(int editIndex)
        {
            SqlParameter[] param =
            {
                new SqlParameter("@TotalRecords", SqlDbType.Int),
                new SqlParameter("@BeginDate", StartDate),
                new SqlParameter("@EndDate", EndDate),
                new SqlParameter("@MemberAccount", QueryType == 1 ? QueryData : ""),
                new SqlParameter("@NickName", QueryType == 2 ? QueryData : ""),
                new SqlParameter("@LogStatus", LogStatus),
                new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
                new SqlParameter("@PageSize", UCPager1.PageSize)
            };

            param[0].Direction = ParameterDirection.Output;

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_E_AppLogMemberList",
                param
            );

            gvReport.EditIndex = editIndex;
            gvReport.DataSource = objDr;
            gvReport.DataBind();

            objDr.Close();

            UCPager1.RecordCount = int.Parse(param[0].Value.ToString());
            UCPager1.DataBind();
        }

        /// <summary>
        /// 會員通過審核。
        /// </summary>
        /// <param name="memberID"></param>
        private void AllowPass(string memberID)
        {
            SqlParameter[] param =
            {
                new SqlParameter("@MemberID", memberID),
                new SqlParameter("@AgentID", AUser.AgentID.ToString())
            };

            string result = "";
            string message = "";

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_E_AppLogMemberCheck",
                param
            );

            objDr.Read();

            result = objDr["Result"].ToString();
            message = objDr["ErrorMsg"].ToString();

            objDr.Close();

            ScriptManager.RegisterStartupScript(Page, GetType(), "msg", "alert('" + message + "');", true);
        }

        /// <summary>
        /// 會員通過審核。
        /// </summary>
        /// <param name="memberID"></param>
        /// <param name="file"></param>
        private bool UploadPhoto(string memberID, FileUpload file)
        {
            // 檔名
            string fileName = string.Format("{0}_{1:yyyyMMddHHmmssffff}{2}", memberID, DateTime.Now, Path.GetExtension(file.FileName));
            // 實體檔案路徑
            string filePath = Server.MapPath(UploadFolderPath) + fileName;

            bool isSuccess = false;
            string message = "";

            if (File.Exists(filePath))
            {
                message = "檔案已存在！請再次上傳。";
            }
            else
            {
                try
                {
                    file.SaveAs(filePath);

                    SqlParameter[] param =
                    {
                        new SqlParameter("@MemberID", memberID),
                        new SqlParameter("@PicUrl", UploadFolderPath + fileName)
                    };

                    string result = SqlHelper.ExecuteScalar
                    (
                        WebConfig.connectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_E_AppLogMemberUpPicUrl",
                        param
                    ).ToString();

                    switch (result)
                    {
                        case "0":
                            message = "上傳成功！";
                            isSuccess = true;
                            break;
                        case "1":
                            message = "已審核完畢，請勿再次上傳！";
                            break;
                        case "99":
                        default:
                            message = "上傳失敗！";
                            break;
                    }
                }
                catch
                {
                    message = "上傳失敗！";
                }
            }

            ScriptManager.RegisterStartupScript(Page, GetType(), "msg", "alert('" + message + "');", true);

            return isSuccess;
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnQuery_Click(object sender, EventArgs e)
        {
            bool isUseDate = bool.Parse(rblIsUseDate.SelectedValue);

            StartDate = isUseDate ? UCDateRange1.StartDate : null;
            EndDate = isUseDate ? UCDateRange1.EndDate : null;
            QueryType = int.Parse(rblQueryType.SelectedValue);
            QueryData = txtQueryData.Text.Trim();
            LogStatus = int.Parse(rblLogStatus.SelectedValue);

            UCPager1.CurrentPageNumber = 1;
            BindReport(-1);
        }

        protected void UCPager1_Change(object sender, AppUserControls.Pager.UCPager.PagerEventArgs e)
        {
            BindReport(-1);
        }

        protected void gvReport_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int rowIndex = int.Parse(e.CommandArgument.ToString());

            string memberID = gvReport.DataKeys[rowIndex]["MemberID"].ToString();

            switch (e.CommandName)
            {
                case "Pass":
                    AllowPass(memberID);
                    BindReport(-1);
                    break;
                case "Upload":
                    FileUpload file = gvReport.Rows[rowIndex].FindControl("fuAdd") as FileUpload;
                    if (UploadPhoto(memberID, file))
                    {
                        BindReport(-1);
                    }
                    break;
            }
        }
    }
}