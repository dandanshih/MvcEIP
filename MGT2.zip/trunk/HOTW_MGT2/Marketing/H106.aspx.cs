﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Marketing
{
	public partial class H106 : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				Panel1.Visible = false;

				ViewState["ActID"] = "";
			}
		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			LoadList();
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;

			if (txtAccount.Text.Trim().Length == 0 || txtMobile.Text.Trim().Length == 0)
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('請輸入領獎者帳號和領獎者手機！');", true);
				return;
			}
			else
			{
				LoadList();
			}
		}

		protected void btnInsert_Click(object sender, EventArgs e)
		{
			if (txtHonoree.Text.Trim().Length == 0 || txtInternetCafeName.Text.Trim().Length == 0 || txtInternetStaff.Text.Trim().Length == 0)
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('請輸入領獎者帳號、網咖店網和員工姓名！');", true);
				return;
			}
			else
			{
				string[] strActID = { "", "" };

				if (ViewState["ActID"].ToString() != "" && ViewState["ActID"] != null)
				{
					strActID = ViewState["ActID"].ToString().Split(',');
				}

				SqlParameter[] param = 
			{	
				new SqlParameter("@ActID", strActID[0]),
				new SqlParameter("@MemberID", strActID[1]),
				new SqlParameter("@InternetCafeName", txtInternetCafeName.Text),
				new SqlParameter("@InternetCafeStaff", txtInternetStaff.Text),
				new SqlParameter("@Honoree", txtHonoree.Text),
				new SqlParameter("@LoginIP", Request.ServerVariables["REMOTE_ADDR"].ToString()),
				new SqlParameter("@intResult",SqlDbType.Int),
				new SqlParameter("@strOutstring", SqlDbType.NVarChar,255)
			};

				param[6].Direction = ParameterDirection.Output;
				param[7].Direction = ParameterDirection.Output;

				SqlHelper.ExecuteNonQuery
				(
					WebConfig.connectionString,
					CommandType.StoredProcedure,
					"Game_Activity.dbo.NSP_GameWeb_E20130627_InternetCafeAward_Insert",
					param
				);

				if (param[6].Value.ToString() != "1")
				{
					ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('" + param[7].Value.ToString() + "');", true);
					return;
				}
				else
				{
					Panel1.Visible = false;
					LoadList();
				}
			}
		}

		protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "Send")
			{
				ViewState["ActID"] = e.CommandArgument.ToString();

				Panel1.Visible = true;

				txtHonoree.Text = txtInternetCafeName.Text = txtInternetStaff.Text = "";
			}
			else
			{
				Panel1.Visible = false;
			}
		}

		private void LoadList()
		{
			SqlParameter[] param = 
			{	
				new SqlParameter("@MemberAccount", txtAccount.Text),
				new SqlParameter("@Mobile", txtMobile.Text),
				new SqlParameter("@intResult",SqlDbType.Int),
				new SqlParameter("@strOutstring", SqlDbType.NVarChar,255)
			};

			param[2].Direction = ParameterDirection.Output;
			param[3].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"Game_Activity.dbo.NSP_GameWeb_E20130627_InternetCafeAward_Get",
				param
			);

			gvList.DataSource = ds;
			gvList.DataBind();

			if (param[2].Value.ToString() != "1")
			{
				ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('" + param[3].Value.ToString() + "');", true);
				return;
			}

			Panel1.Visible = false;
		}
	}
}