﻿using System.Web;
using System.Web.SessionState;
using GWeb.AppLibs;

namespace GWeb
{
	/// <summary>
	/// 進行後台登入者保持連線的處理. 使用 KeepMethod 來指定處理方式. "1" 代表從 WEB 檢查, "2" 代表從 DB 檢查
    /// 檢查結果的回傳值. "1" 代表正常, 不需做任何處理; "0" 代表異常, 收到該回傳值時需將該用戶登出
	/// </summary>
	public class KeepOnline : IHttpHandler, IRequiresSessionState
	{
		protected AUser AUser;

		public void ProcessRequest(HttpContext context)
		{
			context.Response.ContentType = "text/plain";

			AUser = (AUser)context.Session["AUser"];
            if (AUser == null) {
                context.Response.Write("0");
                return;
            }
                

            
            string sKeepMethod = context.Request["KeepMethod"];
            // 沒有指定 KeepOnline 的方法就回覆失敗
            if (sKeepMethod == null) {
                context.Response.Write("0");
                return;
            }

            // 20110510 Phil: 原本是到 DB 處理 KeepOnline, 為時效以及避免 DB Loading 過重, 所以分為兩種. 
            // 在後台指定踢除帳號時, 會新增一筆資料在後台 WEB 記憶體 Queue 中，如果此人有被指定，就進行登出.
            // 因開發時間不足, 無法完全取代 DB 的 KeepOnline(需多設計 AppKeepOnline 機制才算是完整的 Web KeepOnline 機制)
            // 所以 DB KeepOnline 機制仍需保留。


            switch (sKeepMethod) {
                case "1":
                    
                    if (Utility.KickAgentQueue.Exists(int.Parse(AUser.ExecAgentID))) {
                        // 在 WEB 檢查到要求踢出
                        context.Response.Write("0");
                        return;
                    }

                    break;
                case "2":
                    
                    if (!WebConfig.KeepOnline(AUser.OnlineID)) {
                        // 在 DB 檢查到要求踢出
                        context.Response.Write("0");
                        return;
                    }
                    break;
            }

            // KeepOnline 正常
            context.Response.Write("1");
            return;

		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}