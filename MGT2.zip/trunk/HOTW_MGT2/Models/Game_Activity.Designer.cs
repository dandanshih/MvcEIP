﻿// 已停用模型 'D:\WorkDir\095_HOTW\MGT2\branches\MobileAPP\HOTW_MGT2\Models\Game_Activity.edmx' 的預設程式碼產生。
// 若要啟用預設程式碼產生，請將 [程式碼產生策略] 設計工具屬性的值
//變更為其他值。當模型在設計工具中開啟時，這個屬性便可
//以在 [屬性] 視窗中使用。