﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using GWeb.AppLibs;

namespace GWeb.AppAjaxs
{
	/// <summary>
	///ShutDown 的摘要描述
	/// </summary>
	public class ShutDown : IHttpHandler, IRequiresSessionState
	{

		public void ProcessRequest(HttpContext context)
		{
			context.Response.ContentType = "text/plain";

			int isMaintain = 0;
			DateTime shutDownTime;
			double surplusTime = 0;

			if (TimeChecker.isShutDown)
			{
				// 維護公告 (0:無公告 1:維護公告)
				isMaintain = 1;
			}
			else
			{
				isMaintain = 0;
			}

			if (context.Application["shutDownTime"] != null)
			{
				shutDownTime = DateTime.Parse(context.Application["shutDownTime"].ToString());
				surplusTime = Math.Ceiling(shutDownTime.Subtract(DateTime.Now).TotalSeconds);
			}

			if (surplusTime < 0)
			{
				surplusTime = 0;
			}

			context.Response.Write(isMaintain.ToString() + " " + surplusTime.ToString());
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}