﻿//-----------------------------------------------------------------------
// <copyright file="OP27.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;
    using GWeb.Models;

    /// <summary>
    /// 廣告商點擊次數統計表
    /// </summary>
    public partial class OP27 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.Tables[0];
            this.GV1.DataBind();
            this.GV2.DataSource = data.Tables[1];
            this.GV2.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataSetToExcel(data, "OP27_廣告商點擊次數統計表.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private DataSet GetData()
        {
            DataSet objDS = new DataSet();

            using (SqlCommand objCmd = this.db_analysis_temp.Database.Connection.CreateCommand() as SqlCommand)
            {
                objCmd.CommandText = "NSP_DBTool_CPAGatewayData";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate });
                objCmd.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
                SqlDataAdapter objAdpt = new SqlDataAdapter(objCmd);
                objAdpt.Fill(objDS);
                objDS.Tables[0].TableName = "點擊次數統計表";
                objDS.Tables[1].TableName = "註冊成功會員名單";
            }

            return objDS;
        }
    }
}