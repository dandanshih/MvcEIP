﻿//-----------------------------------------------------------------------
// <copyright file="OP26.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;
    using GWeb.Models;
    using System.Data;

    /// <summary>
    /// 填EMAIL名單
    /// </summary>
    public partial class OP26 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 資料匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP26_填EMAIL名單.xls");
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * take;
            var data = this.GetData().ToList();

            // 繫結UCPager1
            this.UCPager1.RecordCount = data.Count();
            this.UCPager1.DataBind();

            // 繫結GV1
            this.GV1.DataSource = data
                .OrderBy(x => x.MemberID)
                .Skip(skip)
                .Take(take);
            this.GV1.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>回傳資料</returns>
        private IEnumerable<NSP_Req_GM0112_Result> GetData()
        {
            int coinType = int.TryParse(this.DDL_GameAreaType.SelectedValue, out coinType) ? coinType : -1;
            return this.db_analysis_temp.Database.SqlQuery<NSP_Req_GM0112_Result>(
                "exec NSP_Req_GM0112 @StartDate, @EndDate, @PointType",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType });
        }

        /// <summary>
        /// NSP_Req_GM0112 回傳類別
        /// </summary>
        private class NSP_Req_GM0112_Result
        {
            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets 玩家帳號
            /// </summary>
            public string 玩家帳號 { get; set; }

            /// <summary>
            /// Gets or sets 玩家暱稱
            /// </summary>
            public string 玩家暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 會員卡別
            /// </summary>
            public int 會員卡別 { get; set; }

            /// <summary>
            /// Gets or sets 卡別
            /// </summary>
            public string 卡別 { get; set; }

            /// <summary>
            /// Gets or sets Email
            /// </summary>
            public string Email { get; set; }

            /// <summary>
            /// Gets or sets 活動期間儲值金額
            /// </summary>
            public decimal 活動期間儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 活動期間押注
            /// </summary>
            public decimal 活動期間押注 { get; set; }

            /// <summary>
            /// Gets or sets 活動期間BetLM
            /// </summary>
            public decimal 活動期間BetLM { get; set; }

            /// <summary>
            /// Gets or sets 註冊時間
            /// </summary>
            public string 註冊時間 { get; set; }
        }
    }
}