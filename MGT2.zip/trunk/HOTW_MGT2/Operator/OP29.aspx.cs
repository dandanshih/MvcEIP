﻿//-----------------------------------------------------------------------
// <copyright file="OP29.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;

    /// <summary>
    /// 玩家金幣數量統計
    /// </summary>
    public partial class OP29 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Btn_Query_Click(object sender, EventArgs e)
        {
            this.pnlDetail.Visible = false;
            var data = this.GetMaster();
            this.GV_Master.DataSource = data.ToList();
            this.GV_Master.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Btn_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetMaster();
            DataTable dt = data.ListToDataTable();
            dt.Columns["MemberID"].ColumnName = "MemberID";
            dt.Columns["MemberAccount"].ColumnName = "帳號";
            dt.Columns["NickName"].ColumnName = "暱稱";
            dt.Columns["Goldcount"].ColumnName = "金幣數量";
            dt.Columns["GoldCodeCount"].ColumnName = "金幣碼數量";
            dt.Columns.Remove("MemberID");
            NPOIRender.ExportDataTableToEXcel(dt, "OP29_玩家金幣數量統計.xls");
        }

        /// <summary>
        /// 明細、匯出事件
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_Master_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int rowIndex = int.Parse(e.CommandArgument.ToString());
            string memberId = this.GV_Master.DataKeys[rowIndex].Values["MemberID"].ToString();
            var data = this.GetDetail(memberId);
            switch (e.CommandName)
            {
                case "Detail":
                    this.pnlDetail.Visible = true;
                    this.GV_Detail.DataSource = data.ToList();
                    this.GV_Detail.DataBind();
                    this.pnlDetail.Style["margin-top"] = (30 + (30 * rowIndex)) + "px";
                    break;
                case "Export":
                    NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP29_facebook大秘寶資料查詢明細.xls");
                    break;
            }
        }

        /// <summary>
        /// 取得主資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_R_GoldActivity_Count_Result> GetMaster()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_R_GoldActivity_Count_Result>(
                "exec NSP_DBTool_R_GoldActivity_Count @StartDate, @EndDate, @MemberAccount, @NickName",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@MemberAccount", SqlDbType.NVarChar, 20) { Value = this.rblQueryType.SelectedValue == "1" ? this.txtMemberData.Text : string.Empty },
                new SqlParameter("@NickName", SqlDbType.NVarChar, 20) { Value = this.rblQueryType.SelectedValue == "2" ? this.txtMemberData.Text : string.Empty });
        }

        /// <summary>
        /// 取得明細資料
        /// </summary>
        /// <param name="memberId">會員編號</param>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_R_GoldActivity_CountDetail_Result> GetDetail(string memberId)
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_R_GoldActivity_CountDetail_Result>(
                "exec NSP_DBTool_R_GoldActivity_CountDetail @StartDate, @EndDate, @MemberID",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@MemberID", SqlDbType.Int) { Value = memberId });
        }

        /// <summary>
        /// NSP_DBTool_R_GoldActivity_Count 回傳類別
        /// </summary>
        private class NSP_DBTool_R_GoldActivity_Count_Result
        {
            /// <summary>
            /// Gets or sets RowNO
            /// </summary>
            public int RowNO { get; set; }

            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets NickName
            /// </summary>
            public string NickName { get; set; }

            /// <summary>
            /// Gets or sets MemberAccount
            /// </summary>
            public string MemberAccount { get; set; }

            /// <summary>
            /// Gets or sets Goldcount
            /// </summary>
            public int Goldcount { get; set; }

            /// <summary>
            /// Gets or sets GoldCodeCount
            /// </summary>
            public int GoldCodeCount { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_R_GoldActivity_CountDetail 回傳類別
        /// </summary>
        private class NSP_DBTool_R_GoldActivity_CountDetail_Result
        {
            /// <summary>
            /// Gets or sets 獲得時間
            /// </summary>
            public DateTime 獲得時間 { get; set; }

            /// <summary>
            /// Gets or sets 獲得來源
            /// </summary>
            public string 獲得來源 { get; set; }

            /// <summary>
            /// Gets or sets 會員編號
            /// </summary>
            public int 會員編號 { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 會員暱稱
            /// </summary>
            public string 會員暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 金幣數量
            /// </summary>
            public int 金幣數量 { get; set; }
        }
    }
}