﻿//-----------------------------------------------------------------------
// <copyright file="OP35.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;
    using GWeb.Models;

    /// <summary>
    /// 老子分彩活動查詢
    /// </summary>
    public partial class OP35 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 資料庫連線物件
        /// </summary>
        private DB_Analysis_Temp_Context db = new DB_Analysis_Temp_Context();

        /// <summary>
        /// 釋放資源
        /// </summary>
        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@ListType", "2"),
                    new SqlParameter("@GameID", "0"),
                    new SqlParameter("@IsShowFreeGame", 1)
                };

                var data = this.db.Database.SqlQuery<NSP_ALL_G_GetGameList_Result>("exec NSP_ALL_G_GetGameList @ListType, @GameID, @IsShowFreeGame", param);
                this.ddlGame.DataTextField = "ListName";
                this.ddlGame.DataValueField = "ListID";
                this.ddlGame.DataSource = data.ToList();
                this.ddlGame.DataBind();
                this.ddlGame.Items.Insert(0, new ListItem("全部", "0"));
            }
        }

        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 資料匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ToList().ListToDataTable(), "OP35_老子分彩活動查詢.xls");
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * this.UCPager1.PageSize;
            var query = this.GetData().ToList();

            // 繫結分頁
            this.UCPager1.RecordCount = query.Count();
            this.UCPager1.DataBind();

            // 繫結資料
            this.GV1.DataSource = query
                .OrderBy(x => x.時間)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料</returns>
        private IEnumerable<NSP_DBTool_R_MemberWinLose_CountingQry_Result> GetData()
        {
            var query = this.db.Database.SqlQuery<NSP_DBTool_R_MemberWinLose_CountingQry_Result>(
                "exec NSP_DBTool_R_MemberWinLose_CountingQry @StartDate, @EndDate, @GameID, @PointType",
                new SqlParameter("@StartDate", this.UCDateRange1.StartDate),
                new SqlParameter("@EndDate", this.UCDateRange1.EndDate),
                new SqlParameter("@GameID", this.ddlGame.SelectedValue),
                new SqlParameter("@PointType", 2));
            return query;
        }

        /// <summary>
        /// NSP_ALL_G_GetGameList 回傳類別
        /// </summary>
        private class NSP_ALL_G_GetGameList_Result
        {
            /// <summary>
            /// Gets or sets ListID
            /// </summary>
            public int ListID { get; set; }

            /// <summary>
            /// Gets or sets ListName
            /// </summary>
            public string ListName { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_R_MemberWinLose_CountingQry 回傳類別
        /// </summary>
        private class NSP_DBTool_R_MemberWinLose_CountingQry_Result
        {
            /// <summary>
            /// Gets or sets 時間
            /// </summary>
            public string 時間 { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 卡別
            /// </summary>
            public string 卡別 { get; set; }

            /// <summary>
            /// Gets or sets 遊戲名稱
            /// </summary>
            public string 遊戲名稱 { get; set; }

            /// <summary>
            /// Gets or sets 局數
            /// </summary>
            public int 局數 { get; set; }

            /// <summary>
            /// Gets or sets 押注量
            /// </summary>
            public decimal 押注量 { get; set; }
        }
    }
}