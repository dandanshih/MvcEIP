﻿//-----------------------------------------------------------------------
// <copyright file="NSP_DBTool_Temp_Req_exec_procedure_Result.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    /// <summary>
    /// NSP_DBTool_Temp_Req_exec_procedure 回傳類別
    /// </summary>
    public class NSP_DBTool_Temp_Req_exec_procedure_Result
    {
        /// <summary>
        /// Gets or sets
        /// </summary>
        public string SQL_memo { get; set; }

        /// <summary>
        /// Gets or sets Procedure_name
        /// </summary>
        public string Procedure_name { get; set; }
    }
}