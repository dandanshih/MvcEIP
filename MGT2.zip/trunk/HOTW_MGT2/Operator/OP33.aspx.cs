﻿//-----------------------------------------------------------------------
// <copyright file="OP33.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using GWeb.AppLibs;

    /// <summary>
    /// 儲值序號使用狀態查詢
    /// </summary>
    public partial class OP33 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Btn_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.gvMaster.DataSource = data.ToList();
            this.gvMaster.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP33_儲值序號使用狀態查詢.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetMemberOrderSerialNO_List_Result> GetData()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("SerialNO", typeof(string));

            string[] serialCollection = this.txtSNCollection.Text.Trim().Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0, count = serialCollection.Length; i < count; i++)
            {
                string sn = serialCollection[i].Trim();

                if (Regex.IsMatch(sn, @"^\w{1,20}$"))
                {
                    dt.Rows.Add(sn);
                }
            }

            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetMemberOrderSerialNO_List_Result>(
                "exec NSP_DBTool_GetMemberOrderSerialNO_List @SerialNOData",
                new SqlParameter("@SerialNOData", SqlDbType.Structured) { Value = dt, TypeName = "UDT_SerialNOData" });
        }

        /// <summary>
        /// NSP_DBTool_GetMemberOrderSerialNO_List 回傳類別
        /// </summary>
        private class NSP_DBTool_GetMemberOrderSerialNO_List_Result
        {
            /// <summary>
            /// Gets or sets 儲值卡序號
            /// </summary>
            public string 儲值卡序號 { get; set; }

            /// <summary>
            /// Gets or sets 儲值卡面額
            /// </summary>
            public int 儲值卡面額 { get; set; }

            /// <summary>
            /// Gets or sets 使用日期
            /// </summary>
            public string 使用日期 { get; set; }

            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public string MemberID { get; set; }

            /// <summary>
            /// Gets or sets 使用MemberID帳號創立日期
            /// </summary>
            public string 使用MemberID帳號創立日期 { get; set; }
        }
    }
}