﻿//-----------------------------------------------------------------------
// <copyright file="OP15.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using GWeb.AppLibs;

    /// <summary>
    /// 遊戲駐留人數分析
    /// </summary>
    public partial class OP15 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender objet</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_ALL_G_GetGameList_Result>(
                    "exec NSP_ALL_G_GetGameList @ListType, @GameTypeID, @GameID, @IsShowFreeGame",
                    new SqlParameter("@ListType", SqlDbType.Int) { Value = 2 },
                    new SqlParameter("@GameTypeID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@GameID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@IsShowFreeGame", SqlDbType.Int) { Value = 1 });

                this.DDL_Game.DataTextField = "ListName";
                this.DDL_Game.DataValueField = "ListID";
                this.DDL_Game.DataSource = data.ToList();
                this.DDL_Game.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP15_遊戲駐留人數分析.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_Req_GM0105_Result> GetData()
        {
            // 分老幣\爽幣
            int coinType = int.TryParse(this.ddlGameAreaType.SelectedValue, out coinType) ? coinType : -1;
            return this.db_analysis_temp.Database.SqlQuery<NSP_Req_GM0105_Result>(
                "exec NSP_Req_GM0105 @GameID, @StartDate, @EndDate, @StartDate2, @EndDate2, @Cnt, @PointType",
                new SqlParameter("@GameID", SqlDbType.Int) { Value = this.DDL_Game.SelectedValue },
                new SqlParameter("@StartDate", SqlDbType.Date) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.Date) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@StartDate2", SqlDbType.Date) { Value = this.UCDateRange2.StartDate },
                new SqlParameter("@EndDate2", SqlDbType.Date) { Value = this.UCDateRange2.EndDate },
                new SqlParameter("@Cnt", SqlDbType.NVarChar, 1000) { Direction = ParameterDirection.Output },
                new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType });
        }

        /// <summary>
        /// NSP_Req_GM0105 回傳類別
        /// </summary>
        private class NSP_Req_GM0105_Result
        {
            /// <summary>
            /// Gets or sets 比對時間類型
            /// </summary>
            public string 比對時間類型 { get; set; }

            /// <summary>
            /// Gets or sets 遊戲名稱
            /// </summary>
            public string 遊戲名稱 { get; set; }

            /// <summary>
            /// Gets or sets 遊戲代碼
            /// </summary>
            public int 遊戲代碼 { get; set; }

            /// <summary>
            /// Gets or sets 人數
            /// </summary>
            public int 人數 { get; set; }
        }
    }
}