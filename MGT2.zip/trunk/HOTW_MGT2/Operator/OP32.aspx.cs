﻿//-----------------------------------------------------------------------
// <copyright file="OP32.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;

    /// <summary>
    /// 贏春拉金幣金幣數統計
    /// </summary>
    public partial class OP32 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_R_ECO2013010037_DropDownList_Result>("exec NSP_DBTool_R_ECO2013010037_DropDownList");
                this.DDL_SourceType.DataSource = data.ToList();
                this.DDL_SourceType.DataTextField = "SourceName";
                this.DDL_SourceType.DataValueField = "SourceID";
                this.DDL_SourceType.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.Tables[0];
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataSetToExcel(data, "OP32_贏春拉金幣金幣數統計.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集</returns>
        private DataSet GetData()
        {
            DataSet objDs = new DataSet();

            using (SqlCommand objCmd = this.db_analysis_temp.Database.Connection.CreateCommand() as SqlCommand)
            {
                objCmd.CommandText = "NSP_DBTool_R_ECO2013010037";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate });
                objCmd.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
                objCmd.Parameters.Add(new SqlParameter("@SourceID", SqlDbType.Int) { Value = this.DDL_SourceType.SelectedValue });

                SqlDataAdapter objAdpt = new SqlDataAdapter(objCmd);
                objAdpt.Fill(objDs);
                this.db_analysis_temp.Database.Connection.Close();
            }

            return objDs;
        }

        /// <summary>
        /// NSP_DBTool_R_ECO2013010037_DropDownList 回傳類別
        /// </summary>
        private class NSP_DBTool_R_ECO2013010037_DropDownList_Result
        {
            /// <summary>
            /// Gets or sets SourceID
            /// </summary>
            public int SourceID { get; set; }

            /// <summary>
            /// Gets or sets SourceName
            /// </summary>
            public string SourceName { get; set; }
        }
    }
}