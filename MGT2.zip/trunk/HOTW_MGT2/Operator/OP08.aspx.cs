﻿//-----------------------------------------------------------------------
// <copyright file="OP08.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using GWeb.AppLibs;

    /// <summary>
    /// 新註冊會員分析
    /// </summary>
    public partial class OP08 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_ALL_G_GetGameList_Result>(
                    "exec Game_Branch.dbo.NSP_GameWeb_G_GetGameList @ListType, @GameTypeID, @GameID, @IsShowFreeGame, @ExcludeGameTypeID",
                    new SqlParameter("@ListType", SqlDbType.Int) { Value = 2 },
                    new SqlParameter("@GameTypeID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@GameID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@IsShowFreeGame", SqlDbType.Bit) { Value = 0 },
                    new SqlParameter("@ExcludeGameTypeID", SqlDbType.Int) { Value = 0 });

                this.DDL_Game.DataTextField = "ListName";
                this.DDL_Game.DataValueField = "ListID";
                this.DDL_Game.DataSource = data.ToList();
                this.DDL_Game.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP08_老子分彩活動查詢.xls");
        }

        /// <summary>
        /// 分頁事件
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * take;
            var data = this.GetData().ToList();

            // 繫結UCPage1
            this.UCPager1.RecordCount = data.Count();
            this.UCPager1.DataBind();

            // 繫結GV1
            this.GV1.DataSource = data
                .OrderBy(x => x.MemberID)
                .Skip(skip)
                .Take(take);
            this.GV1.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetMemberWinlose_List_2_Result> GetData()
        {
            // 分老幣\爽幣
            int coinType = int.TryParse(this.DDL_GameAreaType.SelectedItem.Value, out coinType) ? coinType : -1;

            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetMemberWinlose_List_2_Result>(
                "exec NSP_DBTool_GetMemberWinlose_List_2 @StartDate, @EndDate, @PointType, @GameID",
                new SqlParameter("@StartDate", this.UCDateRange1.StartDate),
                new SqlParameter("@EndDate", this.UCDateRange1.EndDate),
                new SqlParameter("@PointType", coinType),
                new SqlParameter("@GameID", this.DDL_Game.SelectedValue.ToString()));
        }

        /// <summary>
        /// NSP_DBTool_GetMemberWinlose_List_2 回傳類別
        /// </summary>
        private class NSP_DBTool_GetMemberWinlose_List_2_Result
        {
            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets MemberAccount
            /// </summary>
            public string MemberAccount { get; set; }

            /// <summary>
            /// Gets or sets NickName
            /// </summary>
            public string NickName { get; set; }

            /// <summary>
            /// Gets or sets 註冊時間
            /// </summary>
            public string 註冊時間 { get; set; }

            /// <summary>
            /// Gets or sets 註冊當日儲值金額
            /// </summary>
            public decimal 註冊當日儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 註冊至今儲值金額
            /// </summary>
            public decimal 註冊至今儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 註冊當日押分量
            /// </summary>
            public decimal 註冊當日押分量 { get; set; }

            /// <summary>
            /// Gets or sets 註冊當日押分量LM
            /// </summary>
            public decimal 註冊當日押分量LM { get; set; }

            /// <summary>
            /// Gets or sets 註冊至今押分量
            /// </summary>
            public decimal 註冊至今押分量 { get; set; }

            /// <summary>
            /// Gets or sets 註冊至今押分量LM
            /// </summary>
            public decimal 註冊至今押分量LM { get; set; }

            /// <summary>
            /// Gets or sets 遊戲局數
            /// </summary>
            public int 遊戲局數 { get; set; }

            /// <summary>
            /// Gets or sets 贏分
            /// </summary>
            public decimal 贏分 { get; set; }

            /// <summary>
            /// Gets or sets 輸分
            /// </summary>
            public decimal 輸分 { get; set; }

            /// <summary>
            /// Gets or sets 贏局數
            /// </summary>
            public int 贏局數 { get; set; }

            /// <summary>
            /// Gets or sets 輸局數
            /// </summary>
            public int 輸局數 { get; set; }

            /// <summary>
            /// Gets or sets 總輸贏
            /// </summary>
            public decimal 總輸贏 { get; set; }

            /// <summary>
            /// Gets or sets 總輸贏LM
            /// </summary>
            public decimal 總輸贏LM { get; set; }

            /// <summary>
            /// Gets or sets 目前身上剩餘老幣
            /// </summary>
            public decimal 目前身上剩餘老幣 { get; set; }

            /// <summary>
            /// Gets or sets 通路名稱
            /// </summary>
            public string 通路名稱 { get; set; }

            /// <summary>
            /// Gets or sets 註當日儲值產包
            /// </summary>
            public string 註當日儲值產包 { get; set; }
        }
    }
}