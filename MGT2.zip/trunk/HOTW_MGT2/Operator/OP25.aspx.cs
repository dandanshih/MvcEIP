﻿//-----------------------------------------------------------------------
// <copyright file="OP25.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using GWeb.AppLibs;

    /// <summary>
    /// 營運每日報表
    /// </summary>
    public partial class OP25 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var list = this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_Temp_Req_exec_procedure_Result>("NSP_DBTool_Temp_Req_exec_procedure");
                this.DDL_Proc.DataTextField = "SQL_memo";
                this.DDL_Proc.DataValueField = "Procedure_name";
                this.DDL_Proc.DataSource = list.ToList();
                this.DDL_Proc.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data, "OP25_營運每日報表.xls");
        }

        /// <summary>
        /// DDL_Proc SelectedIndexChanged
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void DDL_Proc_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.UCPager1.RecordCount = 0;
            this.UCPager1.DataBind();
            this.UCPager1.Visible = false;

            this.GV1.DataSource = null;
            this.GV1.DataBind();
            this.GV1.Visible = false;

            string[] arrProc = this.DDL_Proc.SelectedValue.ToString().Split(',');
            string procName = this.DDL_Proc.SelectedItem.Text.Trim();
            if (arrProc.Length > 1)
            {
                if (arrProc[1] == "DEFAULT")
                {
                    this.UCDateRange1.Visible = false;
                }
                else
                {
                    this.UCDateRange1.Visible = true;
                }
            }
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private DataTable GetData()
        {
            string[] arrProc = this.DDL_Proc.SelectedValue.ToString().Split(',');
            DataSet objDS = new DataSet();

            using (SqlCommand objCmd = this.db_analysis_temp.Database.Connection.CreateCommand() as SqlCommand)
            {
                objCmd.CommandText = arrProc[0];
                objCmd.CommandType = CommandType.StoredProcedure;
                if (arrProc[1] != "DEFAULT")
                {
                    objCmd.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate });
                    objCmd.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
                }
                SqlDataAdapter objAdpt = new SqlDataAdapter(objCmd);
                objAdpt.Fill(objDS);
                return objDS.Tables[0];
            }
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * take;
            DataTable tab1 = this.GetData();
            int totalCount = tab1.Rows.Count;
            int num = totalCount - skip - take < 0 ? totalCount : skip + take;

            // 繫結UCPager1
            this.UCPager1.RecordCount = totalCount;
            this.UCPager1.DataBind();
            this.UCPager1.Visible = true;

            DataTable tab2 = tab1.Clone();
            for (int i = skip; i < num; i++)
            {
                tab2.ImportRow(tab1.Rows[i]);
            }
            // 繫結GV1
            this.GV1.DataSource = tab2;
            this.GV1.DataBind();
            this.GV1.Visible = true;
        }
    }
}