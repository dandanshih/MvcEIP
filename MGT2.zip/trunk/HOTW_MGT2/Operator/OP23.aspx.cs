﻿//-----------------------------------------------------------------------
// <copyright file="OP23.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;

    /// <summary>
    /// 通路入口會員資料
    /// </summary>
    public partial class OP23 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var list = this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_D_BingoSNList_Result>(
                    "exec NSP_DBTool_D_BingoSNList");
                this.DDL_SourceName.DataTextField = "SourceName";
                this.DDL_SourceName.DataValueField = "SNO";
                this.DDL_SourceName.DataSource = list.ToList();
                this.DDL_SourceName.DataBind();
                this.DDL_SourceName.Items.Insert(0, new ListItem("全部", "****"));
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP23_通路入口會員資料.xls");
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * take;
            var data = this.GetData().ToList();

            // 繫結UCPager1
            this.UCPager1.RecordCount = data.Count();
            this.UCPager1.DataBind();

            // 繫結GV1
            this.GV1.DataSource = data
                .OrderBy(x => x.會員ID)
                .Skip(skip)
                .Take(take);
            this.GV1.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetBingoSNOMemberData_Result> GetData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetBingoSNOMemberData_Result>(
                "exec NSP_DBTool_GetBingoSNOMemberData @SNO, @StartDate, @EndDate",
                new SqlParameter("@SNO", SqlDbType.VarChar, 20) { Value = this.DDL_SourceName.SelectedValue },
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
        }

        /// <summary>
        /// NSP_DBTool_D_BingoSNList 回傳類別
        /// </summary>
        private class NSP_DBTool_D_BingoSNList_Result
        {
            /// <summary>
            /// Gets or sets SourceName
            /// </summary>
            public string SourceName { get; set; }

            /// <summary>
            /// Gets or sets SNO
            /// </summary>
            public string SNO { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_GetBingoSNOMemberData 回傳類別
        /// </summary>
        private class NSP_DBTool_GetBingoSNOMemberData_Result
        {
            /// <summary>
            /// Gets or sets 會員ID
            /// </summary>
            public int 會員ID { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 暱稱
            /// </summary>
            public string 暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 手機
            /// </summary>
            public string 手機 { get; set; }

            /// <summary>
            /// Gets or sets 註冊時間
            /// </summary>
            public string 註冊時間 { get; set; }

            /// <summary>
            /// Gets or sets 最後登入日期
            /// </summary>
            public string 最後登入日期 { get; set; }

            /// <summary>
            /// Gets or sets 最後登入IP
            /// </summary>
            public string 最後登入IP { get; set; }

            /// <summary>
            /// Gets or sets 身份別
            /// </summary>
            public string 身份別 { get; set; }

            /// <summary>
            /// Gets or sets 卡別
            /// </summary>
            public string 卡別 { get; set; }

            /// <summary>
            /// Gets or sets 累計儲值金額
            /// </summary>
            public decimal 累計儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 儲值筆數
            /// </summary>
            public int 儲值筆數 { get; set; }

            /// <summary>
            /// Gets or sets 登入次數
            /// </summary>
            public int 登入次數 { get; set; }

            /// <summary>
            /// Gets or sets 登入天數
            /// </summary>
            public decimal 登入天數 { get; set; }

            /// <summary>
            /// Gets or sets 剩餘老幣
            /// </summary>
            public decimal 剩餘老幣 { get; set; }

            /// <summary>
            /// Gets or sets 剩餘發財金
            /// </summary>
            public decimal 剩餘發財金 { get; set; }

            /// <summary>
            /// Gets or sets 通路商
            /// </summary>
            public string 通路商 { get; set; }

            /// <summary>
            /// Gets or sets 通路商序號
            /// </summary>
            public string 通路商序號 { get; set; }
        }
    }
}