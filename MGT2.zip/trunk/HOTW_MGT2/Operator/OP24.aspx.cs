﻿//-----------------------------------------------------------------------
// <copyright file="OP24.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;

    /// <summary>
    /// 大秘寶的黑名單
    /// </summary>
    public partial class OP24 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP24_大秘寶的黑名單.xls");
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * take;
            var data = this.GetData().ToList();

            // 繫結UCPager1
            this.UCPager1.RecordCount = data.Count();
            this.UCPager1.DataBind();

            // 繫結GV1
            this.GV1.DataSource = data
                .OrderBy(x => x.會員ID)
                .Skip(skip)
                .Take(take);
            this.GV1.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_Req_GM0111_Result> GetData()
        {
            if (this.DropDownList.SelectedValue == "1")
            {
                return this.db_analysis_temp.Database.SqlQuery<NSP_Req_GM0111_Result>("exec NSP_Req_GM0111");
            }
            else
            {
                return this.db_analysis_temp.Database.SqlQuery<NSP_Req_GM0111_Result>(
                    "exec NSP_Req_GM0111 @StartDate, @EndDate",
                    new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                    new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
            }
        }

        /// <summary>
        /// NSP_Req_GM0111 回傳類別
        /// </summary>
        private class NSP_Req_GM0111_Result
        {
            /// <summary>
            /// Gets or sets 會員ID
            /// </summary>
            public int 會員ID { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 暱稱
            /// </summary>
            public string 暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 註冊日期
            /// </summary>
            public string 註冊日期 { get; set; }

            /// <summary>
            /// Gets or sets 廣告來源
            /// </summary>
            public string 廣告來源 { get; set; }

            /// <summary>
            /// Gets or sets 廣告商
            /// </summary>
            public string 廣告商 { get; set; }

            /// <summary>
            /// Gets or sets 姓名
            /// </summary>
            public string 姓名 { get; set; }

            /// <summary>
            /// Gets or sets 地址
            /// </summary>
            public string 地址 { get; set; }

            /// <summary>
            /// Gets or sets 獎品
            /// </summary>
            public string 獎品 { get; set; }

            /// <summary>
            /// Gets or sets 姓名重複的次數
            /// </summary>
            public int 姓名重複的次數 { get; set; }

            /// <summary>
            /// Gets or sets 地址重複的次數
            /// </summary>
            public int 地址重複的次數 { get; set; }
        }
    }
}