﻿//-----------------------------------------------------------------------
// <copyright file="OP31.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;

    /// <summary>
    /// 揪咖活動統計
    /// </summary>
    public partial class OP31 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetMasterData();
            this.GV_DataMaster.DataSource = data.ToList();
            this.GV_DataMaster.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetMasterData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP31_揪咖活動統計.xls");
        }

        /// <summary>
        /// GridView Row Command
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_DataMaster_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int i = int.TryParse(e.CommandArgument.ToString(), out i) ? i : -1;
            var data = this.GetDetailData(i);
            switch (e.CommandName)
            {
                case "Detail":
                    this.GV_DataDetail.DataSource = data.ToList();
                    this.GV_DataDetail.DataBind();
                    break;
                case "Export":
                    NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP31_揪咖金幣統計明細.xls");
                    break;
            }
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_ECO2013010041_Master_Result> GetMasterData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_ECO2013010041_Master_Result>(
                "exec NSP_DBTool_ECO2013010041_Master @StartDate, @EndDate, @MemberAccount, @NickName",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@MemberAccount", SqlDbType.NVarChar, 100) { Value = this.txtMemberAccount.Text },
                new SqlParameter("@NickName", SqlDbType.NVarChar, 100) { Value = this.txtNickName.Text });
        }

        /// <summary>
        /// 取得明細資料
        /// </summary>
        /// <param name="cmdArg">command args</param>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_ECO2013010041_Details_Result> GetDetailData(int cmdArg)
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_ECO2013010041_Details_Result>(
                "exec NSP_DBTool_ECO2013010041_Details @StartDate, @EndDate, @MemberID",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@MemberID", SqlDbType.Int) { Value = cmdArg });
        }

        /// <summary>
        /// NSP_DBTool_ECO2013010041_Master 回傳資料
        /// </summary>
        private class NSP_DBTool_ECO2013010041_Master_Result
        {
            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets 推薦人暱稱
            /// </summary>
            public string 推薦人暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 推薦人帳號
            /// </summary>
            public string 推薦人帳號 { get; set; }

            /// <summary>
            /// Gets or sets 推薦人儲值金額
            /// </summary>
            public decimal 推薦人儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 註冊時間
            /// </summary>
            public DateTime 註冊時間 { get; set; }

            /// <summary>
            /// Gets or sets 下線人數
            /// </summary>
            public int 下線人數 { get; set; }

            /// <summary>
            /// Gets or sets 下線活動儲值人數
            /// </summary>
            public int 下線活動儲值人數 { get; set; }

            /// <summary>
            /// Gets or sets 下線活動儲值金額
            /// </summary>
            public decimal 下線活動儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 下線活動儲值達1000元人數
            /// </summary>
            public int 下線活動儲值達1000元人數 { get; set; }

            /// <summary>
            /// Gets or sets 下線儲值人數
            /// </summary>
            public int 下線儲值人數 { get; set; }

            /// <summary>
            /// Gets or sets 下線儲值金額
            /// </summary>
            public decimal 下線儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 領取福袋
            /// </summary>
            public int 領取福袋 { get; set; }

            /// <summary>
            /// Gets or sets 金幣X10枚
            /// </summary>
            public int 金幣X10枚 { get; set; }

            /// <summary>
            /// Gets or sets 老幣10000
            /// </summary>
            public int 老幣10000 { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_ECO2013010041_Details 回傳資料
        /// </summary>
        private class NSP_DBTool_ECO2013010041_Details_Result
        {
            /// <summary>
            /// Gets or sets 會員ID
            /// </summary>
            public int 會員ID { get; set; }

            /// <summary>
            /// Gets or sets 會員暱稱
            /// </summary>
            public string 會員暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 註冊時間
            /// </summary>
            public DateTime 註冊時間 { get; set; }

            /// <summary>
            /// Gets or sets 活動儲值金額
            /// </summary>
            public decimal 活動儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 儲值金額
            /// </summary>
            public decimal 儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 是否更換介紹人
            /// </summary>
            public string 是否更換介紹人 { get; set; }

            /// <summary>
            /// Gets or sets 更換介紹人時間
            /// </summary>
            public string 更換介紹人時間 { get; set; }
        }
    }
}