﻿//-----------------------------------------------------------------------
// <copyright file="OP37.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;
    using GWeb.Models;

    /// <summary>
    /// 回流流失交叉比對(遊戲時間)
    /// </summary>
    public partial class OP37 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 資料庫連線物件
        /// </summary>
        private DB_Analysis_Temp_Context db = new DB_Analysis_Temp_Context();

        /// <summary>
        /// 釋放資源
        /// </summary>
        public override void Dispose()
        {
            this.db.Dispose();
            base.Dispose();
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var query = this.db.Database.SqlQuery<NSP_DBTool_MemberLoginSourceList_Result>(
                    "exec NSP_DBTool_MemberLoginSourceList");
                this.cbl_Platform.DataSource = query.ToList();
                this.cbl_Platform.DataTextField = "MemberSourceName";
                this.cbl_Platform.DataValueField = "MemberSource";
                this.cbl_Platform.DataBind();
            }
        }

        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            int vipLevel = 0;
            int loginFlagZone1 = 0;
            int payFlagZone1 = 0;
            int loginFlagZone2 = 0;
            int payFlagZone2 = 0;
            int loginFlagZone3 = 0;
            int payFlagZone3 = 0;
            string memberSourceList = string.Empty;

            for (int i = 0; i < this.chklCard.Items.Count; i++)
            {
                if (this.chklCard.Items[i].Selected)
                {
                    vipLevel += int.Parse(this.chklCard.Items[i].Value);
                }
            }

            foreach (ListItem li in this.cbl_Platform.Items)
            {
                if (li.Selected)
                {
                    if (string.IsNullOrEmpty(memberSourceList))
                    {
                        memberSourceList = li.Value;
                    }
                    else
                    {
                        memberSourceList += "," + li.Value;
                    }
                }
            }

            loginFlagZone1 = this.CheckBoxList1.Items[0].Selected ? 1 : 0;

            for (int i = 0; i < this.CheckBoxList3.Items.Count; i++)
            {
                if (this.CheckBoxList3.Items[i].Selected)
                {
                    loginFlagZone2 += int.Parse(this.CheckBoxList3.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList5.Items.Count; i++)
            {
                if (this.CheckBoxList5.Items[i].Selected)
                {
                    loginFlagZone3 += int.Parse(this.CheckBoxList5.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList2.Items.Count; i++)
            {
                if (this.CheckBoxList2.Items[i].Selected)
                {
                    payFlagZone1 += int.Parse(this.CheckBoxList2.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList4.Items.Count; i++)
            {
                if (this.CheckBoxList4.Items[i].Selected)
                {
                    payFlagZone2 += int.Parse(this.CheckBoxList4.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList6.Items.Count; i++)
            {
                if (this.CheckBoxList6.Items[i].Selected)
                {
                    payFlagZone3 += int.Parse(this.CheckBoxList6.Items[i].Value);
                }
            }

            this.hdnCheckCreateTime.Value = this.chkOpenAcct.Checked ? "1" : "0";
            this.hdnCreateBeginDate.Value = this.UCDateRange1.StartDate;
            this.hdnCreateEndDate.Value = this.UCDateRange1.EndDate;
            this.hdnVipLevelFlag.Value = vipLevel.ToString();
            this.hdnBeginDateZone1.Value = this.UCDateRange2.StartDate;
            this.hdnEndDateZone1.Value = this.UCDateRange2.EndDate;
            this.hdnLoginFlagZone1.Value = loginFlagZone1.ToString();
            this.hdnPayFlagZone1.Value = payFlagZone1.ToString();
            this.hdnBeginDateZone2.Value = this.UCDateRange3.StartDate;
            this.hdnEndDateZone2.Value = this.UCDateRange3.EndDate;
            this.hdnLoginFlagZone2.Value = loginFlagZone2.ToString();
            this.hdnPayFlagZone2.Value = payFlagZone2.ToString();
            this.hdnBeginDateZone3.Value = this.UCDateRange4.StartDate;
            this.hdnEndDateZone3.Value = this.UCDateRange4.EndDate;
            this.hdnLoginFlagZone3.Value = loginFlagZone3.ToString();
            this.hdnPayFlagZone3.Value = payFlagZone3.ToString();

            var query = this.db.Database.SqlQuery<NSP_DBTool_MemberLoginPayCrossAnalysis_PlayTime_Result>(
                "exec NSP_DBTool_MemberLoginPayCrossAnalysis_PlayTime @CheckCreateTime, @CreateBeginDate, @CreateEndDate, @VipLevelFlag, @BeginDateZone1, @EndDateZone1, @LoginFlagZone1, @PayFlagZone1, @BeginDateZone2, @EndDateZone2, @LoginFlagZone2, @PayFlagZone2, @BeginDateZone3, @EndDateZone3, @LoginFlagZone3, @PayFlagZone3, @MemberSourceList",
                new SqlParameter("@CheckCreateTime", this.chkOpenAcct.Checked ? 1 : 0),
                new SqlParameter("@CreateBeginDate", this.UCDateRange1.StartDate),
                new SqlParameter("@CreateEndDate", this.UCDateRange1.EndDate),
                new SqlParameter("@VipLevelFlag", vipLevel),
                new SqlParameter("@BeginDateZone1", this.UCDateRange2.StartDate),
                new SqlParameter("@EndDateZone1", this.UCDateRange2.EndDate),
                new SqlParameter("@LoginFlagZone1", loginFlagZone1),
                new SqlParameter("@PayFlagZone1", payFlagZone1),
                new SqlParameter("@BeginDateZone2", this.UCDateRange3.StartDate),
                new SqlParameter("@EndDateZone2", this.UCDateRange3.EndDate),
                new SqlParameter("@LoginFlagZone2", loginFlagZone2),
                new SqlParameter("@PayFlagZone2", payFlagZone2),
                new SqlParameter("@BeginDateZone3", this.UCDateRange4.StartDate),
                new SqlParameter("@EndDateZone3", this.UCDateRange4.EndDate),
                new SqlParameter("@LoginFlagZone3", loginFlagZone3),
                new SqlParameter("@PayFlagZone3", payFlagZone3),
                new SqlParameter("@MemberSourceList", memberSourceList));

            this.GV1.DataSource = query.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// GV1 命令
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            this.LabelMessage.Text = string.Empty;
            if (e.CommandName == "Export")
            {
                try
                {
                    string memberSourceList = string.Empty;
                    foreach (ListItem li in this.cbl_Platform.Items)
                    {
                        if (li.Selected)
                        {
                            if (string.IsNullOrEmpty(memberSourceList))
                            {
                                memberSourceList = li.Value;
                            }
                            else
                            {
                                memberSourceList += "," + li.Value;
                            }
                        }
                    }

                    using (var cmd = this.db_analysis_temp.Database.Connection.CreateCommand())
                    {
                        cmd.CommandText = "NSP_DBTool_MemberLoginPayCrossAnalysisMemberList_PlayTime";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(
                            new SqlParameter[]
                            {
                                new SqlParameter("@CheckCreateTime", int.Parse(this.hdnCheckCreateTime.Value)),
                                new SqlParameter("@CreateBeginDate", this.hdnCreateBeginDate.Value),
                                new SqlParameter("@CreateEndDate", this.hdnCreateEndDate.Value),
                                new SqlParameter("@VipLevelFlag", int.Parse(this.hdnVipLevelFlag.Value)),
                                new SqlParameter("@BeginDateZone1", this.hdnBeginDateZone1.Value),
                                new SqlParameter("@EndDateZone1", this.hdnEndDateZone1.Value),
                                new SqlParameter("@LoginFlagZone1", int.Parse(this.hdnLoginFlagZone1.Value)),
                                new SqlParameter("@PayFlagZone1", int.Parse(this.hdnPayFlagZone1.Value)),
                                new SqlParameter("@BeginDateZone2", this.hdnBeginDateZone2.Value),
                                new SqlParameter("@EndDateZone2", this.hdnEndDateZone2.Value),
                                new SqlParameter("@LoginFlagZone2", int.Parse(this.hdnLoginFlagZone2.Value)),
                                new SqlParameter("@PayFlagZone2", int.Parse(this.hdnPayFlagZone2.Value)),
                                new SqlParameter("@BeginDateZone3", this.hdnBeginDateZone3.Value),
                                new SqlParameter("@EndDateZone3", this.hdnEndDateZone3.Value),
                                new SqlParameter("@LoginFlagZone3", int.Parse(this.hdnLoginFlagZone3.Value)),
                                new SqlParameter("@PayFlagZone3", int.Parse(this.hdnPayFlagZone3.Value)),
                                new SqlParameter("@DataColumn", int.Parse(e.CommandArgument.ToString())),
                                new SqlParameter("@MemberSourceList", memberSourceList)
                            });

                        SqlDataAdapter objAdpt = new SqlDataAdapter((SqlCommand)cmd);
                        DataSet objDS = new DataSet();
                        objAdpt.Fill(objDS);
                        NPOIRender.ExportDataSetToExcel(objDS, "OP37_回流流失交叉比對(遊戲時間).xls");
                    }
                }
                catch (Exception ex)
                {
                    this.GV1.DataSource = null;
                    this.GV1.DataBind();
                    this.LabelMessage.Text = "異常:" + ex.ToString();
                }
            }
        }

        /// <summary>
        /// NSP_DBTool_MemberLoginSourceList 回傳物件
        /// </summary>
        private class NSP_DBTool_MemberLoginSourceList_Result
        {
            /// <summary>
            /// Gets or sets MemberSource
            /// </summary>
            public int MemberSource { get; set; }

            /// <summary>
            /// Gets or sets MemberSourceName
            /// </summary>
            public string MemberSourceName { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_MemberLoginPayCrossAnalysis_PlayTime 回傳類別
        /// </summary>
        private class NSP_DBTool_MemberLoginPayCrossAnalysis_PlayTime_Result
        {
            /// <summary>
            /// Gets or sets Zone1Login
            /// </summary>
            public int Zone1Login { get; set; }

            /// <summary>
            /// Gets or sets Zone1Order
            /// </summary>
            public int Zone1Order { get; set; }

            /// <summary>
            /// Gets or sets Zone1NoOrder
            /// </summary>
            public int Zone1NoOrder { get; set; }

            /// <summary>
            /// Gets or sets Zone2NoLogin
            /// </summary>
            public int Zone2NoLogin { get; set; }

            /// <summary>
            /// Gets or sets Zone2Login
            /// </summary>
            public int Zone2Login { get; set; }

            /// <summary>
            /// Gets or sets Zone2Order
            /// </summary>
            public int Zone2Order { get; set; }

            /// <summary>
            /// Gets or sets Zone2NoOrder
            /// </summary>
            public int Zone2NoOrder { get; set; }

            /// <summary>
            /// Gets or sets Zone3NoLogin
            /// </summary>
            public int Zone3NoLogin { get; set; }

            /// <summary>
            /// Gets or sets Zone3Login
            /// </summary>
            public int Zone3Login { get; set; }

            /// <summary>
            /// Gets or sets Zone3Order
            /// </summary>
            public int Zone3Order { get; set; }

            /// <summary>
            /// Gets or sets Zone3NoOrder
            /// </summary>
            public int Zone3NoOrder { get; set; }
        }
    }
}