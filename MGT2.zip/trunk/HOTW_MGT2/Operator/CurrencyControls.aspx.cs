﻿using GS.Utilities;
using GWeb.AppLibs;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.UI;

namespace GWeb.Operator
{
	public partial class CurrencyControls : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (IsPostBack)
			{

			}
			else
			{
				UCDateRange1.StartDate = new DateTime(2013, 11, 7, 11, 0, 0).ToString();

				if (DateTime.Now < new DateTime(2013, 11, 7, 11, 0, 0))
				{
					UCDateRange1.EndDate = new DateTime(2013, 11, 7, 23, 59, 59).ToString();
				}
				else
				{
					UCDateRange1.EndDate = DateTime.Now.ToString();
				}

				GV1.DataSource = string.Empty;
				GV1.DataBind();

				//GV2.DataSource = string.Empty;
				//GV2.DataBind();
			}
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;

			//UCPager2.CurrentPageNumber = 1;

			Load_GV1();

			//Load_GV2();
		}

		protected void Pager_Change1(object sender, EventArgs e)
		{
			Load_GV1();
		}

		//protected void Pager_Change2(object sender, EventArgs e)
		//{
		//	Load_GV2();
		//}

		private void Load_GV1()
		{
			SqlParameter[] parms =
			{
				new SqlParameter("@StartDate", Convert.ToDateTime(UCDateRange1.StartDate)),
				new SqlParameter("@EndDate", Convert.ToDateTime(UCDateRange1.EndDate)),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			parms[4].Direction = ParameterDirection.Output;

			DataTable dt = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"Game_Agent.dbo.NSP_AgentWeb_R_PointMonitor_Report",
				parms
			).Tables[0];

			UCPager1.RecordCount = int.Parse(parms[4].Value.ToString());
			UCPager1.DataBind();

			GV1.DataSource = dt;
			GV1.DataBind();
		}

		//private void Load_GV2()
		//{
		//	SqlParameter[] parms =
		//	{
		//		new SqlParameter("@StartDate", Convert.ToDateTime(UCDateRange1.StartDate)),
		//		new SqlParameter("@EndDate", Convert.ToDateTime(UCDateRange1.EndDate)),
		//		new SqlParameter("@PageSize", UCPager2.PageSize),
		//		new SqlParameter("@PageIndex", UCPager2.CurrentPageNumber),
		//		new SqlParameter("@TotalRecords", SqlDbType.Int)
		//	};

		//	parms[4].Direction = ParameterDirection.Output;

		//	DataTable dt = SqlHelper.ExecuteDataset
		//	(
		//		WebConfig.connectionString,
		//		CommandType.StoredProcedure,
		//		"Game_Agent.dbo.NSP_AgentWeb_R_PointMonitor_P2_Report",
		//		parms
		//	).Tables[0];

		//	UCPager2.RecordCount = int.Parse(parms[4].Value.ToString());
		//	UCPager2.DataBind();

		//	GV2.DataSource = dt;
		//	GV2.DataBind();
		//}

		protected void PopMsg(string msg)
		{
			ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('" + msg + "');", true);
		}

		protected void btnExport_Click(object sender, EventArgs e)
		{
			SqlParameter[] parms =
			{
				new SqlParameter("@StartDate", Convert.ToDateTime(UCDateRange1.StartDate)),
				new SqlParameter("@EndDate", Convert.ToDateTime(UCDateRange1.EndDate)),
				new SqlParameter("@PageSize", int.MaxValue),
				new SqlParameter("@PageIndex", 1),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			parms[4].Direction = ParameterDirection.Output;

			DataTable dt1 = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"Game_Agent.dbo.NSP_AgentWeb_R_PointMonitor_Report",
				parms
			).Tables[0];

			//DataTable dt2 = SqlHelper.ExecuteDataset
			//(
			//	WebConfig.connectionString,
			//	CommandType.StoredProcedure,
			//	"Game_Agent.dbo.NSP_AgentWeb_R_PointMonitor_P2_Report",
			//	parms
			//).Tables[0];

			DataSet ds = new DataSet();

			if (dt1.Rows.Count > 0)
			{
				dt1.TableName = "Part1";

				ds.Tables.Add(dt1.Copy());
			}

			//if (dt2.Rows.Count > 0)
			//{
			//	dt2.TableName = "Part2";

			//	ds.Tables.Add(dt2.Copy());
			//}

			if (ds.Tables.Count > 0)
			{
				this.ExportDataSetToExcel(ds);
			}
			else
			{
				PopMsg("沒有資料，匯出失敗");
			}
		}

		private void ExportDataTableToEXcel(DataTable dt, HttpResponse rp)
		{
			dt.TableName = "幣值監控報表";

			MemoryStream ms = new MemoryStream();
			HSSFWorkbook wbk = new HSSFWorkbook();
			Sheet sht = wbk.CreateSheet(dt.TableName);
			Row row;

			row = sht.CreateRow(0);

			row.CreateCell(0).SetCellValue("報表查詢區間:");
			row.CreateCell(1).SetCellValue(UCDateRange1.StartDate + " ~ " + UCDateRange1.EndDate);

			row = sht.CreateRow(2);

			for (int i = 2; i < dt.Columns.Count; i++)
			{
				decimal sum = 0;

				for (int j = 0; j < dt.Rows.Count; j++)
				{
					sum += Convert.ToDecimal(dt.Rows[j][i]);
				}

				row.CreateCell(i).SetCellValue("小計:" + sum);
			}

			#region 欄位名稱
			row = sht.CreateRow(4);
			foreach (DataColumn dc in dt.Columns)
			{
				row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
			}
			#endregion 欄位名稱

			#region 資料
			Int32 cntRow = 1;
			foreach (DataRow dr in dt.Rows)
			{
				row = sht.CreateRow(sht.LastRowNum + 1);
				foreach (DataColumn dc in dt.Columns)
				{
					row.CreateCell(dc.Ordinal).SetCellValue(dr[dc].ToString());
				}

				//如果資料筆數超過EXCEL的限制，就新開一分頁
				if (cntRow == 65530)
				{
					wbk.Write(ms);
					ms.Flush();
					ms.Position = 0;

					sht = null;
					sht = wbk.CreateSheet(string.Format("{0}-分頁{1}", dt.TableName, wbk.NumberOfSheets + 1));
					row = sht.CreateRow(0);

					foreach (DataColumn dc in dt.Columns)
					{
						row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
					}

					cntRow = 1;
					continue;
				}

				cntRow++;
			}
			#endregion 資料

			wbk.Write(ms);
			ms.Flush();
			ms.Position = 0;

			wbk = null;
			sht = null;

			// 設定強制下載標頭。
			//string fileName = "ExportEXCELData" + DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss") + ".xls";
			string fileName = "CurrencyControls.xls";
			rp.AddHeader("Content-Disposition", string.Format("attachment; filename=" + fileName));
			// 輸出檔案。
			rp.BinaryWrite(ms.ToArray());
			rp.End();
			ms.Close();
			ms.Dispose();
		}

		private void ExportDataSetToExcel(DataSet objDS, string fileName = "CurrencyControls.xls")
		{
			MemoryStream ms = new MemoryStream();
			HSSFWorkbook wbk = new HSSFWorkbook();

			int index = 1;

			foreach (DataTable dt in objDS.Tables)
			{
				dt.TableName = "幣值監控報表" + index;

				Sheet sht = wbk.CreateSheet(dt.TableName);
				Row row;

				// 欄位
				row = sht.CreateRow(0);

				row.CreateCell(0).SetCellValue("報表查詢區間:");
				row.CreateCell(1).SetCellValue(UCDateRange1.StartDate + " ~ " + UCDateRange1.EndDate);

				row = sht.CreateRow(2);

				for (int i = 2; i < dt.Columns.Count; i++)
				{
					decimal sum = 0;

					for (int j = 0; j < dt.Rows.Count; j++)
					{
						sum += Convert.ToDecimal(dt.Rows[j][i]);
					}

					row.CreateCell(i).SetCellValue("小計:" + sum);
				}

				row = sht.CreateRow(4);

				foreach (DataColumn dc in dt.Columns)
				{
					row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
				}

				// 資料
				Int32 cntRow = 1;
				foreach (DataRow dr in dt.Rows)
				{
					row = sht.CreateRow(sht.LastRowNum + 1);
					foreach (DataColumn dc in dt.Columns)
					{
						row.CreateCell(dc.Ordinal).SetCellValue(dr[dc].ToString());
					}

					// 如果資料筆數超過EXCEL的限制，就新開一分頁
					if (cntRow == 65530)
					{
						wbk.Write(ms);
						ms.Flush();
						ms.Position = 0;

						sht = null;
						sht = wbk.CreateSheet(string.Format("{0}-分頁{1}", dt.TableName, wbk.NumberOfSheets + 1));
						row = sht.CreateRow(0);

						foreach (DataColumn dc in dt.Columns)
						{
							row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
						}

						cntRow = 1;
						continue;
					}

					cntRow++;
				}

				wbk.Write(ms);
				ms.Flush();
				ms.Position = 0;
				sht = null;

				index++;
			}
			wbk = null;

			if (HttpContext.Current.Request.Browser.Browser == "IE")
			{
				fileName = HttpContext.Current.Server.UrlPathEncode(fileName);
			}

			// 下載Excel
			HttpContext.Current.Response.Clear();
			HttpContext.Current.Response.ClearHeaders();
			HttpContext.Current.Response.Buffer = false;
			HttpContext.Current.Response.ContentType = "application/xls";
			HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=" + fileName);
			HttpContext.Current.Response.AppendHeader("Content-Length", ms.Length.ToString());
			HttpContext.Current.Response.BinaryWrite(ms.ToArray());
			HttpContext.Current.Response.Flush();
			HttpContext.Current.Response.End();
			ms.Close();
			ms.Dispose();
		}
	}
}