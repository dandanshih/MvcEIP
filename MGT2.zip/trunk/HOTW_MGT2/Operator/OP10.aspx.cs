﻿//-----------------------------------------------------------------------
// <copyright file="OP10.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using GWeb.AppLibs;

    /// <summary>
    /// 客戶對帳單
    /// </summary>
    public partial class OP10 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_GameWeb_S_GetDictList_Result>(
                    "exec NSP_GameWeb_S_GetDictList @DictType, @Flag",
                    new SqlParameter("@DictType", "MemberSource"),
                    new SqlParameter("@Flag", "4"));
                this.DDL_MemberSource.DataTextField = "Memo";
                this.DDL_MemberSource.DataValueField = "DictValue";
                this.DDL_MemberSource.DataSource = data.ToList();
                this.DDL_MemberSource.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            DataSet objDS = this.GetData();
            this.GV1.DataSource = objDS.Tables[0];
            this.GV1.DataBind();

            if (objDS.Tables.Count > 1)
            {
                this.GV2.DataSource = objDS.Tables[1];
                this.GV2.DataBind();
                this.GV3.DataSource = objDS.Tables[2];
                this.GV3.DataBind();
            }
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataSetToExcel(data, "OP10_客戶對帳單.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private DataSet GetData()
        {
            DataSet objDS = new DataSet();

            using (SqlCommand objCmd = this.db_analysis_temp.Database.Connection.CreateCommand() as SqlCommand)
            {
                objCmd.CommandText = "NSP_Req_GM0074";
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate });
                objCmd.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
                objCmd.Parameters.Add(new SqlParameter("@MemberSource", this.DDL_MemberSource.SelectedValue));
                SqlDataAdapter objAdpt = new SqlDataAdapter(objCmd);
                objAdpt.Fill(objDS);
                this.db_analysis_temp.Database.Connection.Close();
            }

            objDS.Tables[0].TableName = "註冊人數統計";
            if (objDS.Tables.Count > 1)
            {
                objDS.Tables[1].TableName = "註冊會員明細";
                objDS.Tables[2].TableName = "儲值明細";
            }

            return objDS;
        }

        /// <summary>
        /// NSP_GameWeb_S_GetDictList 回傳類別
        /// </summary>
        private class NSP_GameWeb_S_GetDictList_Result
        {
            /// <summary>
            /// Gets or sets DictValue
            /// </summary>
            public string DictValue { get; set; }

            /// <summary>
            /// Gets or sets Memo
            /// </summary>
            public string Memo { get; set; }
        }
    }
}