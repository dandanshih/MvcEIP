﻿//-----------------------------------------------------------------------
// <copyright file="OP22.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using GWeb.AppLibs;
    using GWeb.Models;

    /// <summary>
    /// 會員儲值輸贏統計資料
    /// </summary>
    public partial class OP22 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 資料匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataSetToExcel(data, "OP22_會員儲值輸贏統計資料.xls");
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private DataSet GetData()
        {
            // 將會員編號塞進 DataTable 再丟給 DB
            Regex regSplit = new System.Text.RegularExpressions.Regex("\\D\\s{0,}", RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
            this.TextBoxMemberIDList.Text = this.TextBoxMemberIDList.Text.Replace(Environment.NewLine, " ").Replace("\t", " ");
            var aryMemberIDList = regSplit.Split(this.TextBoxMemberIDList.Text);
            DataTable memberIdListTable = new DataTable("MemberIDList");
            DateTime startDate = DateTime.Parse(this.UCDateRange1.StartDate);
            DateTime endDate = DateTime.Parse(this.UCDateRange1.EndDate);
            memberIdListTable.Columns.Add("MemberID", typeof(int));

            foreach (string mid in aryMemberIDList)
            {
                int memberID = 0;

                if (string.IsNullOrEmpty(mid))
                {
                    break;
                }

                if (!int.TryParse(mid, out memberID))
                {
                    break;
                }

                memberIdListTable.Rows.Add(memberID);
            }

            using (var cmd = this.db_analysis_temp.Database.Connection.CreateCommand())
            {
                cmd.CommandText = "NSP_DBTool_GetMemberData";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter udtParam = new SqlParameter("@MemberIDData", SqlDbType.Structured);
                udtParam.Value = memberIdListTable;
                udtParam.TypeName = "UDT_MemberIDData";

                cmd.Parameters.Add(udtParam);
                cmd.Parameters.Add(new SqlParameter("@StartDate", startDate));
                cmd.Parameters.Add(new SqlParameter("@EndDate", endDate));

                SqlDataAdapter objAdpt = new SqlDataAdapter((SqlCommand)cmd);
                DataSet objDS = new DataSet();
                objAdpt.Fill(objDS);
                return objDS;
            }
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * this.UCPager1.PageSize;
            var query = this.GetData();

            // 繫結分頁
            this.UCPager1.RecordCount = query.Tables[0].Rows.Count;
            this.UCPager1.DataBind();

            // 繫結資料
            this.GV1.DataSource = query.Tables[0].DataTableToList<NSP_Req_GM0110_Result>()
                .AsEnumerable()
                .OrderBy(x => x.MemberID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// NSP_Req_GM0110 回傳類別
        /// </summary>
        private class NSP_Req_GM0110_Result
        {
            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets MemberAccount
            /// </summary>
            public string MemberAccount { get; set; }

            /// <summary>
            /// Gets or sets NickName
            /// </summary>
            public string NickName { get; set; }

            /// <summary>
            /// Gets or sets Mobile
            /// </summary>
            public string Mobile { get; set; }

            /// <summary>
            /// Gets or sets 身份別
            /// </summary>
            public string 身份別 { get; set; }

            /// <summary>
            /// Gets or sets 最後登入時間
            /// </summary>
            public string 最後登入時間 { get; set; }

            /// <summary>
            /// Gets or sets 註冊時間
            /// </summary>
            public string 註冊時間 { get; set; }

            /// <summary>
            /// Gets or sets 儲值金額
            /// </summary>
            public decimal 儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 儲值次數
            /// </summary>
            public int 儲值次數 { get; set; }

            /// <summary>
            /// Gets or sets 卡別
            /// </summary>
            public string 卡別 { get; set; }

            /// <summary>
            /// Gets or sets 剩餘老幣
            /// </summary>
            public decimal 剩餘老幣 { get; set; }
        }
    }
}