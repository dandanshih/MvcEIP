﻿//-----------------------------------------------------------------------
// <copyright file="OP38.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using GWeb.AppLibs;

    /// <summary>
    /// 活動序號使用狀態查詢
    /// </summary>
    public partial class OP38 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP38_活動序號使用狀態查詢.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_PincodeListSearch_Result_Bak> GetData()
        {
            // 將會員編號塞進 DataTable 再丟給 DB
            Regex regSplit = new System.Text.RegularExpressions.Regex("\\s", RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
            this.TBX_PincodeList.Text = this.TBX_PincodeList.Text.Replace(Environment.NewLine, " ").Replace("\t", " ");
            string[] arymidlist = regSplit.Split(this.TBX_PincodeList.Text);
            DataTable pincodeDataTable = new DataTable("PincodeList");
            pincodeDataTable.Columns.Add("Pincode");

            foreach (string mid in arymidlist)
            {
                string pincode = string.Empty;
                if (string.IsNullOrEmpty(mid))
                {
                    break;
                }

                pincode = mid;
                pincodeDataTable.Rows.Add(pincode);
            }

            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_PincodeListSearch_Result_Bak>(
                "exec NSP_DBTool_PincodeListSearch @PincodeData",
                new SqlParameter("@PincodeData", SqlDbType.Structured)
                {
                    TypeName = "UDT_SerialNOData",
                    Value = pincodeDataTable
                });
        }

        /// <summary>
        /// NSP_DBTool_PincodeListSearch 回傳類別
        /// </summary>
        private class NSP_DBTool_PincodeListSearch_Result_Bak
        {
            /// <summary>
            /// Gets or sets 活動序號_儲值卡序號
            /// </summary>
            public string 活動序號_儲值卡序號 { get; set; }

            /// <summary>
            /// Gets or sets 儲值卡面額
            /// </summary>
            public string 儲值卡面額 { get; set; }

            /// <summary>
            /// Gets or sets 使用日期
            /// </summary>
            public string 使用日期 { get; set; }

            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public string MemberID { get; set; }

            /// <summary>
            /// Gets or sets 使用MemberID帳號創立日期
            /// </summary>
            public string 使用MemberID帳號創立日期 { get; set; }
        }
    }
}