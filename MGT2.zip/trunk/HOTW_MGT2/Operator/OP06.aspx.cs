﻿//-----------------------------------------------------------------------
// <copyright file="OP06.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using GWeb.AppLibs;

    /// <summary>
    /// 實體獎項中獎統計
    /// </summary>
    public partial class OP06 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_Function_DropDownList_Result>(
                    "exec NSP_Function_DropDownList @PageName",
                    new SqlParameter("@PageName", "NSP_DBTool_GetBingoGift_List"));

                this.DDL_GameID.DataTextField = "ListData";
                this.DDL_GameID.DataValueField = "ListValue";
                this.DDL_GameID.DataSource = data.ToList();
                this.DDL_GameID.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP06_實體獎項中獎統計.xls");
        }

        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <returns>資料集</returns>
        private IEnumerable<NSP_DBTool_GetBingoGift_List_Result> GetData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetBingoGift_List_Result>(
                "exec NSP_DBTool_GetBingoGift_List @StartDate, @EndDate, @Type, @GameID",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@Type", SqlDbType.Int) { Value = this.DDL_Type.SelectedValue },
                new SqlParameter("@GameID", SqlDbType.Int) { Value = this.DDL_GameID.SelectedValue });
        }

        /// <summary>
        /// NSP_Function_DropDownList 回傳類別
        /// </summary>
        private class NSP_Function_DropDownList_Result
        {
            /// <summary>
            /// Gets or sets ListData
            /// </summary>
            public string ListData { get; set; }

            /// <summary>
            /// Gets or sets ListValue
            /// </summary>
            public string ListValue { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_GetBingoGift_List 回傳類別
        /// </summary>
        private class NSP_DBTool_GetBingoGift_List_Result
        {
            /// <summary>
            /// Gets or sets CalculateTime
            /// </summary>
            public string CalculateTime { get; set; }

            /// <summary>
            /// Gets or sets TotalBet
            /// </summary>
            public decimal TotalBet { get; set; }

            /// <summary>
            /// Gets or sets TotalBetLM
            /// </summary>
            public decimal TotalBetLM { get; set; }

            /// <summary>
            /// Gets or sets MemberCnt
            /// </summary>
            public int MemberCnt { get; set; }

            /// <summary>
            /// Gets or sets Rounds
            /// </summary>
            public int Rounds { get; set; }

            /// <summary>
            /// Gets or sets 獲得張數
            /// </summary>
            public int 獲得張數 { get; set; }

            /// <summary>
            /// Gets or sets 現金10000元
            /// </summary>
            public int 現金10000元 { get; set; }

            /// <summary>
            /// Gets or sets 現金5000元
            /// </summary>
            public int 現金5000元 { get; set; }

            /// <summary>
            /// Gets or sets 現金2000元
            /// </summary>
            public int 現金2000元 { get; set; }

            /// <summary>
            /// Gets or sets 現金1000元
            /// </summary>
            public int 現金1000元 { get; set; }

            /// <summary>
            /// Gets or sets 老幣100000點
            /// </summary>
            public int 老幣100000點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣50000點
            /// </summary>
            public int 老幣50000點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣20000點
            /// </summary>
            public int 老幣20000點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣10000點
            /// </summary>
            public int 老幣10000點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣5000點
            /// </summary>
            public int 老幣5000點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣1000點
            /// </summary>
            public int 老幣1000點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣500點
            /// </summary>
            public int 老幣500點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣100點
            /// </summary>
            public int 老幣100點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣50點
            /// </summary>
            public int 老幣50點 { get; set; }

            /// <summary>
            /// Gets or sets 老幣10點
            /// </summary>
            public int 老幣10點 { get; set; }

            /// <summary>
            /// Gets or sets 大樂透5張
            /// </summary>
            public int 大樂透5張 { get; set; }

            /// <summary>
            /// Gets or sets 小瑪莉送燈卡1比1
            /// </summary>
            public int 小瑪莉送燈卡1比1 { get; set; }

            /// <summary>
            /// Gets or sets 再接再厲
            /// </summary>
            public int 再接再厲 { get; set; }
        }
    }
}