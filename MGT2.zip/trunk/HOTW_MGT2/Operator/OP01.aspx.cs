﻿//-----------------------------------------------------------------------
// <copyright file="OP01.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;

    /// <summary>
    /// 回流人數查詢
    /// </summary>
    public partial class OP01 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), string.Format("OP01_回流人數查詢_{0}.xls", this.DDL_SourceCategory.SelectedItem.Text));
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetReturnMemberListData_Result> GetData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetReturnMemberListData_Result>(
                "exec NSP_DBTool_GetReturnMemberListData @StartDate, @EndDate"
                    + ", @LoginStartDate, @LoginEndDate, @StoreStartDate, @StoreEndDate, @TypeID, @TypeID2",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@LoginStartDate", SqlDbType.DateTime) { Value = this.UCDateRange2.StartDate },
                new SqlParameter("@LoginEndDate", SqlDbType.DateTime) { Value = this.UCDateRange2.EndDate },
                new SqlParameter("@StoreStartDate", SqlDbType.DateTime) { Value = this.UCDateRange3.StartDate },
                new SqlParameter("@StoreEndDate", SqlDbType.DateTime) { Value = this.UCDateRange3.EndDate },
                new SqlParameter("@TypeID", SqlDbType.Int) { Value = this.DDL_SourceCategory.SelectedValue },
                new SqlParameter("@TypeID2", SqlDbType.Int) { Value = this.DropDownList2.SelectedValue });
        }

        /// <summary>
        /// NSP_DBTool_GetReturnMemberListData 回傳類別
        /// </summary>
        private class NSP_DBTool_GetReturnMemberListData_Result
        {
            /// <summary>
            /// Gets or sets 來源類別
            /// </summary>
            public string 來源類別 { get; set; }

            /// <summary>
            /// Gets or sets 帳號類別
            /// </summary>
            public string 帳號類別 { get; set; }

            /// <summary>
            /// Gets or sets VIP會員人數
            /// </summary>
            public int VIP會員人數 { get; set; }

            /// <summary>
            /// Gets or sets 有效人數
            /// </summary>
            public int 有效人數 { get; set; }

            /// <summary>
            /// Gets or sets VIP登入回流人數
            /// </summary>
            public int VIP登入回流人數 { get; set; }

            /// <summary>
            /// Gets or sets VIP回流率
            /// </summary>
            public decimal VIP回流率 { get; set; }

            /// <summary>
            /// Gets or sets 會員人數
            /// </summary>
            public int 會員人數 { get; set; }

            /// <summary>
            /// Gets or sets 登入回流人數
            /// </summary>
            public int 登入回流人數 { get; set; }

            /// <summary>
            /// Gets or sets 回流率
            /// </summary>
            public decimal 回流率 { get; set; }

            /// <summary>
            /// Gets or sets 儲值人數
            /// </summary>
            public int 儲值人數 { get; set; }

            /// <summary>
            /// Gets or sets 儲值金額
            /// </summary>
            public decimal 儲值金額 { get; set; }

            /// <summary>
            /// Gets or sets 玩賓果人數
            /// </summary>
            public int 玩賓果人數 { get; set; }
        }
    }
}