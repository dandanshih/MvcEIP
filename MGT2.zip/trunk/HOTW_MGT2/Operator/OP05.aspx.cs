﻿//-----------------------------------------------------------------------
// <copyright file="OP05.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Web.UI;
    using GWeb.AppLibs;

    /// <summary>
    /// 遊戲輸贏統計
    /// </summary>
    public partial class OP05 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_ALL_G_GetGameList_Result>(
                    "exec NSP_ALL_G_GetGameList @ListType, @GameTypeID, @GameID, @IsShowFreeGame",
                    new SqlParameter("@ListType", SqlDbType.Int) { Value = 2 },
                    new SqlParameter("@GameTypeID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@GameID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@IsShowFreeGame", SqlDbType.Int) { Value = 1 });
                this.DDL_Game.DataSource = data.ToList();
                this.DDL_Game.DataTextField = "ListName";
                this.DDL_Game.DataValueField = "ListID";
                this.DDL_Game.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP05_遊戲輸贏統計.xls");
        }

        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetMemberWinlose_List_Result> GetData()
        {
            // 將會員編號塞進 DataTable 再丟給 DB
            Regex regSplit = new System.Text.RegularExpressions.Regex("\\D\\s{0,}", RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
            this.TextBoxMemberIDList.Text = this.TextBoxMemberIDList.Text.Replace(Environment.NewLine, " ").Replace("\t", " ");
            string[] aryMemberID = regSplit.Split(this.TextBoxMemberIDList.Text);
            DataTable memberIdTable = new DataTable("MemberIDList");
            memberIdTable.Columns.Add("MemberID", typeof(int));

            foreach (string mid in aryMemberID)
            {
                int memberid = 0;

                // 錯誤處理
                if (string.IsNullOrEmpty(mid) || !int.TryParse(mid, out memberid))
                {
                    break;
                }

                memberIdTable.Rows.Add(memberid);
            }

            // 分老幣\爽幣
            int coinType = int.TryParse(this.DDL_GameAreaType.SelectedItem.Value, out coinType) ? coinType : -1;
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetMemberWinlose_List_Result>(
                "exec NSP_DBTool_GetMemberWinlose_List @MemberIDData, @PointType, @GameID",
                new SqlParameter("@MemberIDData", SqlDbType.Structured) { Value = memberIdTable, TypeName = "UDT_MemberIDData" },
                new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType },
                new SqlParameter("@GameID", SqlDbType.Int) { Value = this.DDL_Game.SelectedValue });
        }

        /// <summary>
        /// NSP_DBTool_GetMemberWinlose_List 回傳類別
        /// </summary>
        private class NSP_DBTool_GetMemberWinlose_List_Result
        {
            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets GameName
            /// </summary>
            public string GameName { get; set; }

            /// <summary>
            /// Gets or sets 近1天_TotalBat_WinLose
            /// </summary>
            public decimal 近1天_TotalBat_WinLose { get; set; }

            /// <summary>
            /// Gets or sets 近1天_TotalWin
            /// </summary>
            public decimal 近1天_TotalWin { get; set; }

            /// <summary>
            /// Gets or sets 近1天_TotalLose
            /// </summary>
            public decimal 近1天_TotalLose { get; set; }

            /// <summary>
            /// Gets or sets 近1天_TotalWinLose
            /// </summary>
            public decimal 近1天_TotalWinLose { get; set; }

            /// <summary>
            /// Gets or sets 近1天_TotalLoseLM
            /// </summary>
            public decimal 近1天_TotalLoseLM { get; set; }

            /// <summary>
            /// Gets or sets 近3天_TotalBat_WinLose
            /// </summary>
            public decimal 近3天_TotalBat_WinLose { get; set; }

            /// <summary>
            /// Gets or sets 近3天_TotalWin
            /// </summary>
            public decimal 近3天_TotalWin { get; set; }

            /// <summary>
            /// Gets or sets 近3天_TotalLose
            /// </summary>
            public decimal 近3天_TotalLose { get; set; }

            /// <summary>
            /// Gets or sets 近3天_TotalWinLose
            /// </summary>
            public decimal 近3天_TotalWinLose { get; set; }

            /// <summary>
            /// Gets or sets 近3天_TotalLoseLM
            /// </summary>
            public decimal 近3天_TotalLoseLM { get; set; }

            /// <summary>
            /// Gets or sets 近7天_TotalBat_WinLose
            /// </summary>
            public decimal 近7天_TotalBat_WinLose { get; set; }

            /// <summary>
            /// Gets or sets 近7天_TotalWin
            /// </summary>
            public decimal 近7天_TotalWin { get; set; }

            /// <summary>
            /// Gets or sets 近7天_TotalLose
            /// </summary>
            public decimal 近7天_TotalLose { get; set; }

            /// <summary>
            /// Gets or sets 近7天_TotalWinLose
            /// </summary>
            public decimal 近7天_TotalWinLose { get; set; }

            /// <summary>
            /// Gets or sets 近7天_TotalLoseLM
            /// </summary>
            public decimal 近7天_TotalLoseLM { get; set; }

            /// <summary>
            /// Gets or sets 近14天_TotalBat_WinLose
            /// </summary>
            public decimal 近14天_TotalBat_WinLose { get; set; }

            /// <summary>
            /// Gets or sets 近14天_TotalWin
            /// </summary>
            public decimal 近14天_TotalWin { get; set; }

            /// <summary>
            /// Gets or sets 近14天_TotalLose
            /// </summary>
            public decimal 近14天_TotalLose { get; set; }

            /// <summary>
            /// Gets or sets 近14天_TotalWinLose
            /// </summary>
            public decimal 近14天_TotalWinLose { get; set; }

            /// <summary>
            /// Gets or sets 近14天_TotalLoseLM
            /// </summary>
            public decimal 近14天_TotalLoseLM { get; set; }
        }
    }
}