﻿//-----------------------------------------------------------------------
// <copyright file="OP19.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;

    /// <summary>
    /// 首儲統計
    /// </summary>
    public partial class OP19 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// GV1按鈕事件處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            this.GV2.Visible = true;
            var data = this.db_analysis_temp.Database.SqlQuery<NSP_Req_GM0109_2_Result>(
                "exec NSP_Req_GM0109_2 @StartDate, @EndDate, @StoreStartDate, @StoreEndDate, @Type, @VLAUES",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@STOREStartDate", SqlDbType.DateTime) { Value = this.UCDateRange2.StartDate },
                new SqlParameter("@STOREEndDate", SqlDbType.DateTime) { Value = this.UCDateRange2.EndDate },
                new SqlParameter("@Type", SqlDbType.Int) { Value = this.DropDownList1.SelectedValue },
                new SqlParameter("@VLAUES", SqlDbType.Decimal) { Value = e.CommandArgument, Precision = 18, Scale = 2 });

            switch (e.CommandName)
            {
                case "Detail":
                    this.GV2.DataSource = data.ToList();
                    this.GV2.DataBind();
                    this.LabelMessage.Text = string.Empty;
                    break;
                case "Export":
                    NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP19_首儲統計.xls");
                    break;
            }
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_Req_GM0109_1_Result> GetData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_Req_GM0109_1_Result>(
                "exec NSP_Req_GM0109_1 @StartDate, @EndDate, @StoreStartDate, @StoreEndDate, @Type",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@StoreStartDate", SqlDbType.DateTime) { Value = this.UCDateRange2.StartDate },
                new SqlParameter("@StoreEndDate", SqlDbType.DateTime) { Value = this.UCDateRange2.EndDate },
                new SqlParameter("@Type", SqlDbType.Int) { Value = this.DropDownList1.SelectedValue });
        }

        /// <summary>
        /// NSP_Req_GM0109_1 回傳類別
        /// </summary>
        private class NSP_Req_GM0109_1_Result
        {
            /// <summary>
            /// Gets or sets Vlaues
            /// </summary>
            public decimal Vlaues { get; set; }

            /// <summary>
            /// Gets or sets MemberCnt
            /// </summary>
            public int MemberCnt { get; set; }
        }

        /// <summary>
        /// NSP_Req_GM0109_2_Result 回傳類別
        /// </summary>
        private class NSP_Req_GM0109_2_Result
        {
            /// <summary>
            /// Gets or sets 會員ID
            /// </summary>
            public int 會員ID { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 暱稱
            /// </summary>
            public string 暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 手機
            /// </summary>
            public string 手機 { get; set; }

            /// <summary>
            /// Gets or sets 首儲日期
            /// </summary>
            public string 首儲日期 { get; set; }

            /// <summary>
            /// Gets or sets 註冊日期
            /// </summary>
            public string 註冊日期 { get; set; }

            /// <summary>
            /// Gets or sets 手機驗證日期
            /// </summary>
            public string 手機驗證日期 { get; set; }
        }
    }
}