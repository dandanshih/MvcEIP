﻿//-----------------------------------------------------------------------
// <copyright file="OP03.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;

    /// <summary>
    /// 儲值統計
    /// </summary>
    public partial class OP03 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.ShowKeyList.DataSource = data.ToList();
            this.ShowKeyList.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), string.Format("OP03_儲值統計_{0}.xls", this.DDL_SourceType.SelectedItem.Text));
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetMemberStoreValuesList_Result> GetData()
        {
            if (this.DropDownList1.SelectedValue == "1")
            {
                return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetMemberStoreValuesList_Result>(
                    "exec NSP_DBTool_GetMemberStoreValuesList @StartDate, @EndDate, @StoreStartDate, @StoreEndDate, @Type",
                    new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                    new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                    new SqlParameter("@StoreStartDate", SqlDbType.DateTime) { Value = this.UCDateRange2.StartDate },
                    new SqlParameter("@StoreEndDate", SqlDbType.DateTime) { Value = this.UCDateRange2.EndDate },
                    new SqlParameter("@Type", SqlDbType.Int) { Value = this.DDL_SourceType.SelectedValue });
            }
            else
            {
                return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetMemberStoreValuesList_Result>(
                    "exec NSP_DBTool_GetMemberStoreValuesList @StartDate, @EndDate, @StoreStartDate, @StoreEndDate, @Type",
                    new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = DBNull.Value },
                    new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = DBNull.Value },
                    new SqlParameter("@StoreStartDate", SqlDbType.DateTime) { Value = this.UCDateRange2.StartDate },
                    new SqlParameter("@StoreEndDate", SqlDbType.DateTime) { Value = this.UCDateRange2.EndDate },
                    new SqlParameter("@Type", SqlDbType.Int) { Value = this.DDL_SourceType.SelectedValue });
            }
        }

        /// <summary>
        /// NSP_DBTool_GetMemberStoreValuesList 回傳類別
        /// </summary>
        private class NSP_DBTool_GetMemberStoreValuesList_Result
        {
            /// <summary>
            /// Gets or sets 日期區間
            /// </summary>
            public string 日期區間 { get; set; }

            /// <summary>
            /// Gets or sets 當月卡別
            /// </summary>
            public string 當月卡別 { get; set; }

            /// <summary>
            /// Gets or sets 儲值筆數
            /// </summary>
            public int 儲值筆數 { get; set; }

            /// <summary>
            /// Gets or sets 儲值人數
            /// </summary>
            public int 儲值人數 { get; set; }

            /// <summary>
            /// Gets or sets 儲值金額
            /// </summary>
            public decimal 儲值金額 { get; set; }
        }
    }
}