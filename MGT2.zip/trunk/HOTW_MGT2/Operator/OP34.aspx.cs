﻿//-----------------------------------------------------------------------
// <copyright file="OP34.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;

    /// <summary>
    /// 會員遊戲局數押注量分析查詢
    /// </summary>
    public partial class OP34 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var list = this.db_analysis_temp.Database.SqlQuery<NSP_ALL_G_GetGameList_Result>(
                    "exec NSP_ALL_G_GetGameList @ListType, @GameTypeID, @GameID, @IsShowFreeGame",
                    new SqlParameter("@ListType", SqlDbType.Int) { Value = 2 },
                    new SqlParameter("@GameTypeID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@GameID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@IsShowFreeGame", SqlDbType.Int) { Value = 1 });

                this.DDL_Game.DataTextField = "ListName";
                this.DDL_Game.DataValueField = "ListID";
                this.DDL_Game.DataSource = list.ToList();
                this.DDL_Game.DataBind();
                this.DDL_Game.Items.Insert(0, new ListItem("全部", "0"));
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Btn_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Btn_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP34_會員遊戲局數押注量分析查詢.xls");
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * take;
            var data = this.GetData().ToList();

            // 繫結UCPager1
            this.UCPager1.RecordCount = data.Count();
            this.UCPager1.DataBind();

            // 繫結GV1
            this.GV1.DataSource = data
                .OrderBy(x => x.時間)
                .ThenBy(x => x.會員帳號)
                .Skip(skip)
                .Take(take);
            this.GV1.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_R_MemberWinLose_CountingQry_Result> GetData()
        {
            // 分老幣\爽幣
            int coinType = int.TryParse(this.DDL_GameAreaType.SelectedValue, out coinType) ? coinType : -1;
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_R_MemberWinLose_CountingQry_Result>(
                "exec NSP_DBTool_R_MemberWinLose_CountingQry @StartDate, @EndDate, @GameID, @PointType",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@GameID", SqlDbType.Int) { Value = this.DDL_Game.SelectedValue },
                new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType });
        }

        /// <summary>
        /// NSP_DBTool_R_MemberWinLose_CountingQry 回傳類別
        /// </summary>
        private class NSP_DBTool_R_MemberWinLose_CountingQry_Result
        {
            /// <summary>
            /// Gets or sets 時間
            /// </summary>
            public string 時間 { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 卡別
            /// </summary>
            public string 卡別 { get; set; }

            /// <summary>
            /// Gets or sets 遊戲名稱
            /// </summary>
            public string 遊戲名稱 { get; set; }

            /// <summary>
            /// Gets or sets 局數
            /// </summary>
            public int 局數 { get; set; }

            /// <summary>
            /// Gets or sets 押注量
            /// </summary>
            public decimal 押注量 { get; set; }
        }
    }
}