﻿using GFC.Utilities;
using GWeb.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Operator
{
    public partial class OP41 : FormBase
    {
        public string ADSourceID
        {
            get
            {
                return ViewState["ADSourceID"].ToString();
            }
            set
            {
                ViewState["ADSourceID"] = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {

            }
            else
            {
                ADSourceID = "";
            }
        }

        private void Load_GV1()
        {
            //if (string.IsNullOrEmpty(txtADName.Text) || string.IsNullOrWhiteSpace(txtADName.Text))
            //{
            //    ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告商名稱');", true);

            //    return;
            //}

            //if (string.IsNullOrEmpty(txtADLinkName.Text) || string.IsNullOrWhiteSpace(txtADLinkName.Text))
            //{
            //    ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告商連結名稱');", true);

            //    return;
            //}

            SqlParameter[] parms =
            {
                new SqlParameter("@ADName", txtADName.Text),
                new SqlParameter("@ADLinkName", txtADLinkName.Text),
                new SqlParameter("@StartDate", UCDateRange1.StartDate),
                new SqlParameter("@EndDate", UCDateRange1.EndDate)
            };

            DataSet ds = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_AD_LoginCount",
                parms
            );

            UCPager1.RecordCount = 0;
            UCPager1.DataBind();

            GV1.DataSource = ds.Tables[0];
            GV1.DataBind();

            UCPager2.RecordCount = 0;
            UCPager2.DataBind();

            GV2.DataSource = string.Empty;
            GV2.DataBind();

            if (ds.Tables[0].Rows.Count <= 0)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('查無資料');", true);

                return;
            }
        }

        private void Load_GV2()
        {
            if (string.IsNullOrEmpty(ADSourceID) || string.IsNullOrWhiteSpace(ADSourceID))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請先選擇廣告商');", true);

                return;
            }

            SqlParameter[] parms =
            {
                new SqlParameter("@ADSourceID", ADSourceID),
                new SqlParameter("@StartDate", UCDateRange1.StartDate),
                new SqlParameter("@EndDate", UCDateRange1.EndDate)
            };

            DataSet ds = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_AD_LoginCount_Detail",
                parms
            );

            UCPager2.RecordCount = 0;
            UCPager2.DataBind();

            GV2.DataSource = ds.Tables[0];
            GV2.DataBind();
        }

        protected void Pager_Change1(object sender, EventArgs e)
        {
            Load_GV1();
        }

        protected void GV1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "btnDetail")
            {
                ADSourceID = e.CommandArgument.ToString();

                UCPager2.CurrentPageNumber = 1;

                Load_GV2();
            }
            else if (e.CommandName == "btnExport")
            {
                ADSourceID = e.CommandArgument.ToString();

                if (string.IsNullOrEmpty(ADSourceID) || string.IsNullOrWhiteSpace(ADSourceID))
                {
                    ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請先選擇廣告商');", true);

                    return;
                }

                SqlParameter[] parms =
                {
                    new SqlParameter("@ADSourceID", ADSourceID),
                    new SqlParameter("@StartDate", UCDateRange1.StartDate),
                    new SqlParameter("@EndDate", UCDateRange1.EndDate)
                };

                DataSet ds = SqlHelper.ExecuteDataset
                (
                    WebConfig.connectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_AD_LoginCount_Detail",
                    parms
                );

                if (ds.Tables[0].Rows.Count <= 0)
                {
                    ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('沒有資料可匯出');", true);

                    return;
                }

                ds.Tables[0].TableName = "廣告會員登入次數統計";

                ds.Tables[0].Columns["MemberAccount"].ColumnName = "會員帳號";
                ds.Tables[0].Columns["NickName"].ColumnName = "會員暱稱";
                ds.Tables[0].Columns["LoginCount"].ColumnName = "登入次數";
                ds.Tables[0].Columns["VLAUES"].ColumnName = "儲值金額";
                ds.Tables[0].Columns["Points"].ColumnName = "剩餘老幣";
                ds.Tables[0].Columns["Mobile"].ColumnName = "手機";
                ds.Tables[0].Columns["CreateDate"].ColumnName = "註冊日期";
                ds.Tables[0].Columns["LastLoginIP"].ColumnName = "最後登入IP";

                NPOIRender.ExportDataTableToEXcel(ds.Tables[0], Response);
            }
        }

        protected void btnQuery_Click(object sender, EventArgs e)
        {
            UCPager1.CurrentPageNumber = 1;

            Load_GV1();
        }

        protected void Pager_Change2(object sender, EventArgs e)
        {
            Load_GV2();
        }
    }
}