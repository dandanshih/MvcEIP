﻿//-----------------------------------------------------------------------
// <copyright file="OP11.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using GWeb.AppLibs;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    /// <summary>
    /// 廠商儲值金額統計
    /// </summary>
    public partial class OP11 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP11_廠商儲值金額統計.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_SVC_WorthCard_List_Result> GetData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_SVC_WorthCard_List_Result>(
                "exec NSP_DBTool_SVC_WorthCard_List @StartDate, @EndDate",
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
        }

        /// <summary>
        /// NSP_DBTool_SVC_WorthCard_List 回傳類別
        /// </summary>
        private class NSP_DBTool_SVC_WorthCard_List_Result
        {
            public string 類別 { get; set; }
            public string 廠商名稱 { get; set; }
            public decimal 儲值金額 { get; set; }
            public int 儲值次數 { get; set; }
            public int 儲值人數 { get; set; }
        }
    }
}