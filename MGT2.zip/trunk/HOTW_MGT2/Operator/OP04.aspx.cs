﻿//-----------------------------------------------------------------------
// <copyright file="OP04.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;

    /// <summary>
    /// 會員每日輸贏統計
    /// </summary>
    public partial class OP04 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_ALL_G_GetGameList_Result>(
                    "exec NSP_ALL_G_GetGameList @ListType, @GameTypeID, @GameID, @IsShowFreeGame",
                    new SqlParameter("@ListType", SqlDbType.Int) { Value = 2 },
                    new SqlParameter("@GameTypeID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@GameID", SqlDbType.Int) { Value = 0 },
                    new SqlParameter("@IsShowFreeGame", SqlDbType.Int) { Value = 1 });

                this.ddlGame.DataSource = data.ToList();
                this.ddlGame.DataTextField = "ListName";
                this.ddlGame.DataValueField = "ListID";
                this.ddlGame.DataBind();
                this.ddlGame.Items.Insert(0, new ListItem("全部", "0"));
            }
        }

        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 資料匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP04_會員每日輸贏統計.xls");
        }

        /// <summary>
        /// 分頁事件
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * this.UCPager1.PageSize;
            var data = this.GetData().ToList();

            // 繫結UCPage1
            this.UCPager1.RecordCount = data.Count();
            this.UCPager1.DataBind();

            // 繫結GV1
            this.GV1.DataSource = data
                .OrderBy(x => x.MemberID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetMemberWinlose_Day_List_Result> GetData()
        {
            DateTime startDate = DateTime.Parse(this.UCDateRange1.StartDate);
            DateTime endDate = DateTime.Parse(this.UCDateRange1.EndDate);
            int pointType = 2;
            int gameID = int.TryParse(this.ddlGame.SelectedValue, out gameID) ? gameID : 0;
            int rounds = int.TryParse(this.TextBoxRounds.Text, out rounds) ? rounds : 0;
            int type = int.TryParse(this.DropDownList1.SelectedValue, out type) ? type : 0;
            double totalWinLoseTotalBat = double.TryParse(this.TextBoxTotalWinLoseTotalBat.Text, out totalWinLoseTotalBat) ? totalWinLoseTotalBat : 0.0;
            totalWinLoseTotalBat = (type == 0) ? 0 : totalWinLoseTotalBat;
            bool isDaily = bool.TryParse(this.RadioButtonListIsDaily.SelectedValue, out isDaily) ? isDaily : false;
            bool isCount = bool.TryParse(this.RadioButtonListIsCount.SelectedValue, out isCount) ? isCount : false;

            // 將會員編號塞進 DataTable 再丟給 DB
            Regex regSplit = new System.Text.RegularExpressions.Regex("\\D\\s{0,}", RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
            this.TextBoxMemberIDList.Text = this.TextBoxMemberIDList.Text.Replace(Environment.NewLine, " ").Replace("\t", " ");
            string[] aryMemberID = regSplit.Split(this.TextBoxMemberIDList.Text);

            // 將字串拆解成DataTable
            DataTable memberIDList = new DataTable("MemberIDList");
            memberIDList.Columns.Add("MemberID", typeof(int));
            foreach (string mid in aryMemberID)
            {
                int memberID = 0;

                if (string.IsNullOrEmpty(mid) || !int.TryParse(mid, out memberID))
                {
                    break;
                }

                memberIDList.Rows.Add(memberID);
            }

            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetMemberWinlose_Day_List_Result>(
                "exec NSP_DBTool_GetMemberWinlose_Day_List @MemberIDData, @StartDate, @EndDate" +
                ", @PointType, @GameID, @Rounds, @Type, @TotalWinLoseTotalBat, @IsDaily, @IsCount",
                new SqlParameter("@MemberIDData", SqlDbType.Structured) { Value = memberIDList, TypeName = "UDT_MemberIDData" },
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = startDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = endDate },
                new SqlParameter("@PointType", SqlDbType.Int) { Value = pointType },
                new SqlParameter("@GameID", SqlDbType.Int) { Value = gameID },
                new SqlParameter("@Rounds", SqlDbType.Int) { Value = rounds },
                new SqlParameter("@Type", SqlDbType.Int) { Value = type },
                new SqlParameter("@TotalWinLoseTotalBat", SqlDbType.Decimal, 10) { Value = totalWinLoseTotalBat, Precision = 10, Scale = 2 },
                new SqlParameter("@IsDaily", SqlDbType.Bit) { Value = isDaily },
                new SqlParameter("@IsCount", SqlDbType.Bit) { Value = isCount });
        }

        /// <summary>
        /// NSP_DBTool_GetMemberWinlose_Day_List 回傳類別
        /// </summary>
        private class NSP_DBTool_GetMemberWinlose_Day_List_Result
        {
            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets 帳號
            /// </summary>
            public string 帳號 { get; set; }

            /// <summary>
            /// Gets or sets 暱稱
            /// </summary>
            public string 暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 遊戲名稱
            /// </summary>
            public string 遊戲名稱 { get; set; }

            /// <summary>
            /// Gets or sets 老幣總押注額
            /// </summary>
            public decimal 老幣總押注額 { get; set; }

            /// <summary>
            /// Gets or sets 發財金_幸運金總押注額
            /// </summary>
            public decimal 發財金_幸運金總押注額 { get; set; }

            /// <summary>
            /// Gets or sets Totalbat_Winlose
            /// </summary>
            public decimal Totalbat_Winlose { get; set; }

            /// <summary>
            /// Gets or sets 遊戲局數
            /// </summary>
            public int 遊戲局數 { get; set; }

            /// <summary>
            /// Gets or sets 總贏分
            /// </summary>
            public decimal 總贏分 { get; set; }

            /// <summary>
            /// Gets or sets 總輸分
            /// </summary>
            public decimal 總輸分 { get; set; }

            /// <summary>
            /// Gets or sets 老幣總輸贏分
            /// </summary>
            public decimal 老幣總輸贏分 { get; set; }

            /// <summary>
            /// Gets or sets 發財金_幸運金總輸贏分
            /// </summary>
            public decimal 發財金_幸運金總輸贏分 { get; set; }

            /// <summary>
            /// Gets or sets 贏局數
            /// </summary>
            public int 贏局數 { get; set; }

            /// <summary>
            /// Gets or sets 輸局數
            /// </summary>
            public int 輸局數 { get; set; }

            /// <summary>
            /// Gets or sets 最後登入時間
            /// </summary>
            public string 最後登入時間 { get; set; }

            /// <summary>
            /// Gets or sets 平台來源
            /// </summary>
            public string 平台來源 { get; set; }

            /// <summary>
            /// Gets or sets 註冊時間
            /// </summary>
            public string 註冊時間 { get; set; }

            /// <summary>
            /// Gets or sets 當下卡別
            /// </summary>
            public string 當下卡別 { get; set; }
        }
    }
}