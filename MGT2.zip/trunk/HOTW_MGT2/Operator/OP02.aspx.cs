﻿//-----------------------------------------------------------------------
// <copyright file="OP02.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;

    /// <summary>
    /// 點數異動查詢
    /// </summary>
    public partial class OP02 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP02_點數異動查詢.xls");
        }

        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_GetMemberChangePointList_Result> GetData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_GetMemberChangePointList_Result>(
                "exec NSP_DBTool_GetMemberChangePointList @InquiryData, @Type, @AgentID, @StartDate, @EndDate",
                new SqlParameter("@InquiryData", SqlDbType.NVarChar, 100) { Value = this.TextBoxNickName.Text },
                new SqlParameter("@Type", SqlDbType.Int) { Value = 1 },
                new SqlParameter("@AgentID", SqlDbType.Int) { Value = AUser.AgentID },
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
        }

        /// <summary>
        /// NSP_DBTool_GetMemberChangePointList 回傳類別
        /// </summary>
        public class NSP_DBTool_GetMemberChangePointList_Result
        {
            /// <summary>
            /// Gets or sets 科目
            /// </summary>
            public string 科目 { get; set; }

            /// <summary>
            /// Gets or sets 說明
            /// </summary>
            public string 說明 { get; set; }

            /// <summary>
            /// Gets or sets 點數
            /// </summary>
            public decimal 點數 { get; set; }

            /// <summary>
            /// Gets or sets 日期
            /// </summary>
            public string 日期 { get; set; }

            /// <summary>
            /// Gets or sets 時間
            /// </summary>
            public string 時間 { get; set; }
        }
    }
}