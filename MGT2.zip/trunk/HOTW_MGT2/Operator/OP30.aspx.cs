﻿//-----------------------------------------------------------------------
// <copyright file="OP30.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;

    /// <summary>
    /// 揪咖金幣統計
    /// </summary>
    public partial class OP30 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP30_揪咖金幣統計.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_ECO2013010041_Result> GetData()
        {
            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_ECO2013010041_Result>(
                "exec NSP_DBTool_ECO2013010041 @EventType, @StartDate, @EndDate",
                new SqlParameter("@EventType", SqlDbType.Int) { Value = 54 },
                new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate });
        }

        /// <summary>
        /// NSP_DBTool_ECO2013010041 回傳類別
        /// </summary>
        private class NSP_DBTool_ECO2013010041_Result
        {
            /// <summary>
            /// Gets or sets 日期
            /// </summary>
            public string 日期 { get; set; }

            /// <summary>
            /// Gets or sets 禮物
            /// </summary>
            public string 禮物 { get; set; }

            /// <summary>
            /// Gets or sets 發送數量
            /// </summary>
            public int 發送數量 { get; set; }
        }
    }
}