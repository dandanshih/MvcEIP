﻿//-----------------------------------------------------------------------
// <copyright file="OP07.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Text.RegularExpressions;
    using GWeb.AppLibs;
    using GWeb.Models;

    /// <summary>
    /// 活動贈禮中獎名單
    /// </summary>
    public partial class OP07 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    var data = this.db_analysis_temp.Database.SqlQuery<NSP_Function_DropDownList_Result>(
                        "exec NSP_Function_DropDownList @PageName",
                        new SqlParameter("@PageName", "NSP_DBTool_GetBingoMemberList"));

                    this.DropDownList1.DataTextField = "ListData";
                    this.DropDownList1.DataValueField = "ListValue";
                    this.DropDownList1.DataSource = data.ToList();
                    this.DropDownList1.DataBind();
                }
                catch
                {
                    this.DropDownList1.Items.Clear();
                }
            }
        }

        /// <summary>
        /// 資料查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 資料匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            DataSet objDS = this.GetData();

            if (objDS.Tables.Count > 1)
            {
                this.GV2.Visible = true;
                this.Label4.Visible = true;
                objDS.Tables[1].TableName = "抽獎劵名單";
            }
            else
            {
                this.Label4.Visible = false;
                this.GV2.Visible = false;
            }

            NPOIRender.ExportDataSetToExcel(objDS, "OP07_活動贈禮中獎名單.xls");
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 分頁處理
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager2_Change(object sender, EventArgs e)
        {
            this.BindData();
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>DataSet</returns>
        private DataSet GetData()
        {
            DataTable memberIDTable = new DataTable("MemberIDList");
            var qryData = string.Empty;
            memberIDTable.Columns.Add("MemberID", typeof(int));
            if (this.DDL_QryType.SelectedValue.ToString() == "3")
            {
                // 將會員編號塞進 DataTable 再丟給 DB
                Regex regSplit = new System.Text.RegularExpressions.Regex("\\D\\s{0,}", RegexOptions.Singleline | RegexOptions.Compiled | RegexOptions.IgnoreCase);
                this.TBX_QryData.Text = this.TBX_QryData.Text.Replace(Environment.NewLine, " ").Replace("\t", " ");
                string[] aryMemberID = regSplit.Split(this.TBX_QryData.Text);

                foreach (string mid in aryMemberID)
                {
                    int memberid = 0;
                    if (string.IsNullOrEmpty(mid) || !int.TryParse(mid, out memberid))
                    {
                        break;
                    }

                    memberIDTable.Rows.Add(memberid);
                }
            }
            else
            {
                qryData = this.TBX_QryData.Text.Trim();
            }

            DataSet objDS = new DataSet();
            using (var cmd = this.db_analysis_temp.Database.Connection.CreateCommand())
            {
                this.db_analysis_temp.Database.Connection.Open();
                cmd.CommandText = "NSP_DBTool_GetBingoMemberList";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@TypeID", this.DropDownList1.SelectedValue));
                cmd.Parameters.Add(new SqlParameter("@StartDate", this.UCDateRange1.StartDate));
                cmd.Parameters.Add(new SqlParameter("@EndDate", this.UCDateRange1.EndDate));
                cmd.Parameters.Add(new SqlParameter("@QryType", this.DDL_QryType.SelectedValue));
                cmd.Parameters.Add(new SqlParameter("@QryData", qryData));
                SqlParameter udtParam = new SqlParameter("@UDT_MemberIDData", SqlDbType.Structured);
                udtParam.Value = memberIDTable;
                udtParam.TypeName = "UDT_MemberIDData";
                cmd.Parameters.Add(udtParam);

                SqlDataAdapter objAdpt = new SqlDataAdapter((SqlCommand)cmd);
                objAdpt.Fill(objDS);
                this.db_analysis_temp.Database.Connection.Close();
            }

            return objDS;
        }

        /// <summary>
        /// 繫結資料
        /// </summary>
        private void BindData()
        {
            DataSet objDS = this.GetData();
            int take = this.UCPager1.PageSize;
            int skip = (this.UCPager1.CurrentPageNumber - 1) * this.UCPager1.PageSize;

            // 繫結UCPage1
            this.UCPager1.RecordCount = objDS.Tables[0].Rows.Count;
            this.UCPager1.DataBind();

            // 繫結GV1
            this.GV1.DataSource = objDS.Tables[0]
                .DataTableToList<NSP_DBTool_GetBingoMemberList_Result1>()
                .AsEnumerable()
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV1.DataBind();

            if (objDS.Tables.Count > 1)
            {
                this.GV2.Visible = true;
                this.Label4.Visible = true;
                this.GV2.DataSource = objDS.Tables[1];
                this.GV2.DataBind();

                take = this.UCPager2.PageSize;
                skip = (this.UCPager2.CurrentPageNumber - 1) * this.UCPager2.PageSize;

                // 繫結UCPage2
                this.UCPager2.RecordCount = objDS.Tables[1].Rows.Count;
                this.UCPager2.DataBind();

                // 繫結GV2
                this.GV2.DataSource = objDS.Tables[1]
                    .DataTableToList<NSP_DBTool_GetBingoMemberList_Result2>()
                    .AsEnumerable()
                    .Skip(skip)
                    .Take(take)
                    .ToList();
                this.GV2.DataBind();
            }
            else
            {
                this.Label4.Visible = false;
                this.GV2.Visible = false;
                this.GV2.DataSource = null;
                this.GV2.DataBind();
            }
        }

        /// <summary>
        /// NSP_Function_DropDownList_Result
        /// </summary>
        private class NSP_Function_DropDownList_Result
        {
            /// <summary>
            /// Gets or sets ListData
            /// </summary>
            public string ListData { get; set; }

            /// <summary>
            /// Gets or sets ListValue
            /// </summary>
            public string ListValue { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_GetBingoMemberList 回傳資料集1
        /// </summary>
        private class NSP_DBTool_GetBingoMemberList_Result1
        {
            /// <summary>
            /// Gets or sets 獎項
            /// </summary>
            public string 獎項 { get; set; }

            /// <summary>
            /// Gets or sets 會員ID
            /// </summary>
            public int 會員ID { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string 會員帳號 { get; set; }

            /// <summary>
            /// Gets or sets 暱稱
            /// </summary>
            public string 暱稱 { get; set; }

            /// <summary>
            /// Gets or sets 手機號碼
            /// </summary>
            public string 手機號碼 { get; set; }

            /// <summary>
            /// Gets or sets 獲得日期
            /// </summary>
            public string 獲得日期 { get; set; }

            /// <summary>
            /// Gets or sets 是否為機械人
            /// </summary>
            public long 是否為機械人 { get; set; }

            /// <summary>
            /// Gets or sets 領取日期
            /// </summary>
            public string 領取日期 { get; set; }

            /// <summary>
            /// Gets or sets 是否領取
            /// </summary>
            public int 是否領取 { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_GetBingoMemberList 回傳資料集2
        /// </summary>
        private class NSP_DBTool_GetBingoMemberList_Result2
        {
            /// <summary>
            /// Gets or sets MemberID
            /// </summary>
            public int MemberID { get; set; }

            /// <summary>
            /// Gets or sets 會員帳號
            /// </summary>
            public string MemberAccount { get; set; }

            /// <summary>
            /// Gets or sets 暱稱
            /// </summary>
            public string NickName { get; set; }

            /// <summary>
            /// Gets or sets 手機號碼
            /// </summary>
            public string 手機 { get; set; }

            /// <summary>
            /// Gets or sets 是否為機械人
            /// </summary>
            public long 是否為機械人 { get; set; }

            /// <summary>
            /// Gets or sets 領取張數
            /// </summary>
            public long 領取張數 { get; set; }

            /// <summary>
            /// Gets or sets 已兌換張數
            /// </summary>
            public long 已兌換張數 { get; set; }

            /// <summary>
            /// Gets or sets 未兌換張數
            /// </summary>
            public long 未兌換張數 { get; set; }
        }
    }
}