﻿using GFC.Utilities;
using GWeb.AppLibs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.Operator
{
    public partial class OP40 : FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {

            }
            else
            {
                GV1.DataSource = new List<NSP_AgentWeb_AD_SourceID_List_Struct>();
                GV1.DataBind();

                btnExport.Visible = false;

                divModify.Visible = false;
                divMaster.Visible = true;

                ViewState["list"] = new List<NSP_AgentWeb_AD_SourceID_List_Struct>();
            }
        }

        private void Load_GV1()
        {
            List<NSP_AgentWeb_AD_SourceID_List_Struct> list = new List<NSP_AgentWeb_AD_SourceID_List_Struct>();

            SqlParameter[] parms =
            {
                new SqlParameter("@ADSourceID", ""),
                new SqlParameter("@ADName", txtADName.Text),
                new SqlParameter("@ADLinkName", txtADLinkName.Text),
                new SqlParameter("@StartDate", UCDateRange1.StartDate),
                new SqlParameter("@EndDate", UCDateRange1.EndDate),
                new SqlParameter("@PageSize", UCPager1.PageSize),
                new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
                new SqlParameter("@TotalRecords", SqlDbType.Int)
            };

            parms[parms.Length - 1].Direction = ParameterDirection.Output;

            DataSet ds = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_AD_SourceID_List",
                parms
            );

            UCPager1.RecordCount = Convert.ToInt32(parms[parms.Length - 1].Value.ToString());
            UCPager1.DataBind();

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                NSP_AgentWeb_AD_SourceID_List_Struct o = new NSP_AgentWeb_AD_SourceID_List_Struct();

                o.ADSourceID = dr["ADSourceID"].ToString();
                o.ADName = dr["ADName"].ToString();
                o.ADLinkName = dr["ADLinkName"].ToString();
                o.TGLink = dr["TGLink"].ToString();
                o.StartDate = dr["StartDate"].ToString();
                o.EndDate = dr["EndDate"].ToString();
                o.AD_Day = dr["AD_Day"].ToString();
                o.CreateDate = dr["CreateDate"].ToString();

                //o.ProduceURL = "http://" + ConfigurationManager.AppSettings["GameWebDomain"].ToString() + "/Mvc/Home/ad_link?" + "s=" + dr["ADSourceID"].ToString() + "&" + "i=" + DateTime.Now.ToString("yyyyMMddHHmmssfff");
                o.ProduceURL = "http://" + ConfigurationManager.AppSettings["GameWebDomain"].ToString() + "/Mvc/Home/ad_link?" + "s=" + dr["ADSourceID"].ToString();

                list.Add(o);
            }

            ViewState["list"] = list;

            GV1.DataSource = list;
            GV1.DataBind();

            if (list.Count <= 0)
            {
                btnExport.Visible = false;

                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('查無資料');", true);
            }
            else
            {
                btnExport.Visible = true;
            }

            divModify.Visible = false;
            divMaster.Visible = true;
        }

        protected void Pager_Change1(object sender, EventArgs e)
        {
            Load_GV1();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            SqlParameter[] parms =
            {
                new SqlParameter("@ADSourceID", ""),
                new SqlParameter("@ADName", txtADName.Text),
                new SqlParameter("@ADLinkName", txtADLinkName.Text),
                new SqlParameter("@StartDate", UCDateRange1.StartDate),
                new SqlParameter("@EndDate", UCDateRange1.EndDate),
                new SqlParameter("@PageSize", int.MaxValue),
                new SqlParameter("@PageIndex", 1),
                new SqlParameter("@TotalRecords", SqlDbType.Int)
            };

            DataSet ds = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_AD_SourceID_List",
                parms
            );

            if (ds.Tables[0].Rows.Count <= 0)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('沒有資料可匯出');", true);

                return;
            }

            ds.Tables[0].TableName = "廣告商連結管理";

            ds.Tables[0].Columns["ADSourceID"].ColumnName = "廣告商編號";
            ds.Tables[0].Columns["ADName"].ColumnName = "廣告商名稱";
            ds.Tables[0].Columns["ADLinkName"].ColumnName = "廣告商連結名稱";
            ds.Tables[0].Columns["TGLink"].ColumnName = "廣告放置URL";
            ds.Tables[0].Columns["StartDate"].ColumnName = "廣告起始日期";
            ds.Tables[0].Columns["EndDate"].ColumnName = "廣告結束日期";
            ds.Tables[0].Columns["AD_Day"].ColumnName = "廣告天數";
            ds.Tables[0].Columns["CreateDate"].ColumnName = "建檔日期";

            NPOIRender.ExportDataTableToEXcel(ds.Tables[0], Response);
        }

        protected void btnProduce_Click(object sender, EventArgs e)
        {
            if (DateTime.Now > Convert.ToDateTime(UCDateRange1.EndDate))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('廣告設定時間錯誤');", true);

                return;
            }

            if (string.IsNullOrEmpty(txtADName.Text) || string.IsNullOrWhiteSpace(txtADName.Text))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告商名稱');", true);

                return;
            }

            if (string.IsNullOrEmpty(txtADLinkName.Text) || string.IsNullOrWhiteSpace(txtADLinkName.Text))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告商連結名稱');", true);

                return;
            }

            if (string.IsNullOrEmpty(txtTGLink.Text) || string.IsNullOrWhiteSpace(txtTGLink.Text))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告放置URL');", true);

                return;
            }

            if (string.IsNullOrEmpty(txtDataCnt.Text) || string.IsNullOrWhiteSpace(txtDataCnt.Text))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入產出數量');", true);

                return;
            }
            else
            {
                int _DataCnt = 0;

                if (!int.TryParse(txtDataCnt.Text, out _DataCnt))
                {
                    ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('產出數量只限輸入數字');", true);

                    return;
                }
            }

            SqlParameter[] parms =
            {
                new SqlParameter("@ADName", txtADName.Text),
                new SqlParameter("@ADLinkName", txtADLinkName.Text),
                new SqlParameter("@TGLink", txtTGLink.Text),
                new SqlParameter("@StartDate", UCDateRange1.StartDate),
                new SqlParameter("@EndDate", UCDateRange1.EndDate),
                new SqlParameter("@DataCnt", Convert.ToInt32(txtDataCnt.Text))
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_AD_SourceID_Add",
                parms
            );

            UCPager1.CurrentPageNumber = 1;

            Load_GV1();
        }

        protected void btnQuery_Click(object sender, EventArgs e)
        {
            UCPager1.CurrentPageNumber = 1;

            Load_GV1();
        }

        protected void GV1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "btnSet")
            {
                List<NSP_AgentWeb_AD_SourceID_List_Struct> list = (List<NSP_AgentWeb_AD_SourceID_List_Struct>)ViewState["list"];

                NSP_AgentWeb_AD_SourceID_List_Struct o = new NSP_AgentWeb_AD_SourceID_List_Struct();

                if (list.Count > 0)
                {
                    o = list.Where(a => a.ADSourceID == e.CommandArgument.ToString()).FirstOrDefault();

                    lblModifyADSourceID.Text = o.ADSourceID;
                    txtModifyADName.Text = o.ADName;
                    txtModifyADLinkName.Text = o.ADLinkName;
                    txtModifyTGLink.Text = o.TGLink;
                    UCDateRange2.StartDate = o.StartDate;
                    UCDateRange2.EndDate = o.EndDate;

                    divModify.Visible = true;
                    divMaster.Visible = false;
                }
                else
                {
                    divModify.Visible = false;
                    divMaster.Visible = true;

                    ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('查無此筆資料，不能修改');", true);

                    return;
                }
            }
        }

        protected void btnTrue_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtModifyADName.Text) || string.IsNullOrWhiteSpace(txtModifyADName.Text))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告商名稱');", true);

                return;
            }

            if (string.IsNullOrEmpty(txtModifyADLinkName.Text) || string.IsNullOrWhiteSpace(txtModifyADLinkName.Text))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告商連結名稱');", true);

                return;
            }

            if (string.IsNullOrEmpty(txtModifyTGLink.Text) || string.IsNullOrWhiteSpace(txtModifyTGLink.Text))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('請輸入廣告放置URL');", true);

                return;
            }

            SqlParameter[] parms =
            { 
                new SqlParameter("@ADSourceID", lblModifyADSourceID.Text),
                new SqlParameter("@ADName", txtModifyADName.Text),
                new SqlParameter("@ADLinkName", txtModifyADLinkName.Text),
                new SqlParameter("@TGLink", txtModifyTGLink.Text),
                new SqlParameter("@StartDate", UCDateRange2.StartDate),
                new SqlParameter("@EndDate", UCDateRange2.EndDate),
                new SqlParameter("@Result", SqlDbType.Int)
            };

            parms[parms.Length - 1].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_AD_SourceID_Update",
                parms
            );

            if (parms[6].Value.ToString().Equals("1"))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('修改成功');", true);

                Load_GV1();
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "ErrMsg", "alert('修改失敗');", true);
            }
        }

        protected void btnFalse_Click(object sender, EventArgs e)
        {
            divModify.Visible = false;
            divMaster.Visible = true;
        }
    }

    [Serializable]
    public class NSP_AgentWeb_AD_SourceID_List_Struct : IDisposable
    {
        public string ADSourceID { get; set; }
        public string ADName { get; set; }
        public string ADLinkName { get; set; }
        public string TGLink { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string AD_Day { get; set; }
        public string CreateDate { get; set; }
        public string ProduceURL { get; set; }

        void IDisposable.Dispose()
        {

        }
    }
}