﻿//-----------------------------------------------------------------------
// <copyright file="OP36.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using GWeb.AppLibs;

    /// <summary>
    /// 回流流失交叉比對
    /// </summary>
    public partial class OP36 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var data = this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_MemberLoginSourceList_Result>(
                    "exec NSP_DBTool_MemberLoginSourceList");
                this.CBL_Platform.DataSource = data.ToList();
                this.CBL_Platform.DataTextField = "MemberSourceName";
                this.CBL_Platform.DataValueField = "MemberSource";
                this.CBL_Platform.DataBind();
            }
        }

        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetMaster();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 下載
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Export")
            {
                int i = int.TryParse(e.CommandArgument.ToString(), out i) ? i : -1;
                var data = this.GetDetail(i);
                NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP36_回流流失交叉比對.xls");
            }
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_MemberLoginPayCrossAnalysis_Result> GetMaster()
        {
            // 分老幣\爽幣
            int coinType = int.TryParse(this.ddlGameAreaType.SelectedValue, out coinType) ? coinType : -1;
            int vipLevel = 0;
            int loginFlagZone1 = 0;
            int payFlagZone1 = 0;
            int loginFlagZone2 = 0;
            int payFlagZone2 = 0;
            int loginFlagZone3 = 0;
            int payFlagZone3 = 0;
            string memberSourceList = string.Empty;

            for (int i = 0; i < this.chklCard.Items.Count; i++)
            {
                if (this.chklCard.Items[i].Selected)
                {
                    vipLevel += int.Parse(this.chklCard.Items[i].Value);
                }
            }

            foreach (ListItem li in this.CBL_Platform.Items)
            {
                if (li.Selected)
                {
                    if (string.IsNullOrEmpty(memberSourceList))
                    {
                        memberSourceList = li.Value;
                    }
                    else
                    {
                        memberSourceList += "," + li.Value;
                    }
                }
            }

            loginFlagZone1 = this.CheckBoxList1.Items[0].Selected ? 1 : 0;

            for (int i = 0; i < this.CheckBoxList3.Items.Count; i++)
            {
                if (this.CheckBoxList3.Items[i].Selected)
                {
                    loginFlagZone2 += int.Parse(this.CheckBoxList3.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList5.Items.Count; i++)
            {
                if (this.CheckBoxList5.Items[i].Selected)
                {
                    loginFlagZone3 += int.Parse(this.CheckBoxList5.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList2.Items.Count; i++)
            {
                if (this.CheckBoxList2.Items[i].Selected)
                {
                    payFlagZone1 += int.Parse(this.CheckBoxList2.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList4.Items.Count; i++)
            {
                if (this.CheckBoxList4.Items[i].Selected)
                {
                    payFlagZone2 += int.Parse(this.CheckBoxList4.Items[i].Value);
                }
            }

            for (int i = 0; i < this.CheckBoxList6.Items.Count; i++)
            {
                if (this.CheckBoxList6.Items[i].Selected)
                {
                    payFlagZone3 += int.Parse(this.CheckBoxList6.Items[i].Value);
                }
            }

            this.hdnCheckCreateTime.Value = this.chkOpenAcct.Checked ? "1" : "0";
            this.hdnCreateBeginDate.Value = this.UCDateRange1.StartDate;
            this.hdnCreateEndDate.Value = this.UCDateRange1.EndDate;
            this.hdnVipLevelFlag.Value = vipLevel.ToString();

            this.hdnBeginDateZone1.Value = this.UCDateRange2.StartDate;
            this.hdnEndDateZone1.Value = this.UCDateRange2.EndDate;
            this.hdnLoginFlagZone1.Value = loginFlagZone1.ToString();
            this.hdnPayFlagZone1.Value = payFlagZone1.ToString();

            this.hdnBeginDateZone2.Value = this.UCDateRange3.StartDate;
            this.hdnEndDateZone2.Value = this.UCDateRange3.EndDate;
            this.hdnLoginFlagZone2.Value = loginFlagZone2.ToString();
            this.hdnPayFlagZone2.Value = payFlagZone2.ToString();

            this.hdnBeginDateZone3.Value = this.UCDateRange4.StartDate;
            this.hdnEndDateZone3.Value = this.UCDateRange4.EndDate;
            this.hdnLoginFlagZone3.Value = loginFlagZone3.ToString();
            this.hdnPayFlagZone3.Value = payFlagZone3.ToString();

            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_MemberLoginPayCrossAnalysis_Result>(
                "exec NSP_DBTool_MemberLoginPayCrossAnalysis " +
                " @CheckCreateTime, @CreateBeginDate, @CreateEndDate, @VipLevelFlag" +
                ", @BeginDateZone1, @EndDateZone1, @LoginFlagZone1, @PayFlagZone1" +
                ", @BeginDateZone2, @EndDateZone2, @LoginFlagZone2, @PayFlagZone2" +
                ", @BeginDateZone3, @EndDateZone3, @LoginFlagZone3, @PayFlagZone3" +
                ", @MemberSourceList",
                new SqlParameter("@CheckCreateTime", SqlDbType.Bit) { Value = this.chkOpenAcct.Checked ? 1 : 0 },
                new SqlParameter("@CreateBeginDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                new SqlParameter("@CreateEndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                new SqlParameter("@VipLevelFlag", SqlDbType.Int) { Value = vipLevel },
                new SqlParameter("@BeginDateZone1", SqlDbType.DateTime) { Value = this.UCDateRange2.StartDate },
                new SqlParameter("@EndDateZone1", SqlDbType.DateTime) { Value = this.UCDateRange2.EndDate },
                new SqlParameter("@LoginFlagZone1", SqlDbType.Int) { Value = loginFlagZone1 },
                new SqlParameter("@PayFlagZone1", SqlDbType.Int) { Value = payFlagZone1 },
                new SqlParameter("@BeginDateZone2", SqlDbType.DateTime) { Value = this.UCDateRange3.StartDate },
                new SqlParameter("@EndDateZone2", SqlDbType.DateTime) { Value = this.UCDateRange3.EndDate },
                new SqlParameter("@LoginFlagZone2", SqlDbType.Int) { Value = loginFlagZone2 },
                new SqlParameter("@PayFlagZone2", SqlDbType.Int) { Value = payFlagZone2 },
                new SqlParameter("@BeginDateZone3", SqlDbType.DateTime) { Value = this.UCDateRange4.StartDate },
                new SqlParameter("@EndDateZone3", SqlDbType.DateTime) { Value = this.UCDateRange4.EndDate },
                new SqlParameter("@LoginFlagZone3", SqlDbType.Int) { Value = loginFlagZone3 },
                new SqlParameter("@PayFlagZone3", SqlDbType.Int) { Value = payFlagZone3 },
                new SqlParameter("@MemberSourceList", SqlDbType.NVarChar, 1000) { Value = memberSourceList },
                new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType });
        }

        /// <summary>
        /// 取得明細資料
        /// </summary>
        /// <param name="cmdArgs">data column</param>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_MemberLoginPayCrossAnalysisMemberList_Result> GetDetail(int cmdArgs)
        {
            // 分老幣\爽幣
            int coinType = int.TryParse(this.ddlGameAreaType.SelectedValue, out coinType) ? coinType : -1;
            string memberSourceList = string.Empty;

            foreach (ListItem li in this.CBL_Platform.Items)
            {
                if (li.Selected)
                {
                    if (string.IsNullOrEmpty(memberSourceList))
                    {
                        memberSourceList = li.Value;
                    }
                    else
                    {
                        memberSourceList += "," + li.Value;
                    }
                }
            }

            return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_MemberLoginPayCrossAnalysisMemberList_Result>(
                "exec NSP_DBTool_MemberLoginPayCrossAnalysisMemberList " +
                " @CheckCreateTime, @CreateBeginDate, @CreateEndDate, @VipLevelFlag" +
                ", @BeginDateZone1, @EndDateZone1, @LoginFlagZone1, @PayFlagZone1" +
                ", @BeginDateZone2, @EndDateZone2, @LoginFlagZone2, @PayFlagZone2" +
                ", @BeginDateZone3, @EndDateZone3, @LoginFlagZone3, @PayFlagZone3" +
                ", @DataColumn, @MemberSourceList, @PointType",
                new SqlParameter("@CheckCreateTime", SqlDbType.Bit) { Value = int.Parse(this.hdnCheckCreateTime.Value) },
                new SqlParameter("@CreateBeginDate", SqlDbType.DateTime) { Value = this.hdnCreateBeginDate.Value },
                new SqlParameter("@CreateEndDate", SqlDbType.DateTime) { Value = this.hdnCreateEndDate.Value },
                new SqlParameter("@VipLevelFlag", SqlDbType.Int) { Value = int.Parse(this.hdnVipLevelFlag.Value) },
                new SqlParameter("@BeginDateZone1", SqlDbType.DateTime) { Value = this.hdnBeginDateZone1.Value },
                new SqlParameter("@EndDateZone1", SqlDbType.DateTime) { Value = this.hdnEndDateZone1.Value },
                new SqlParameter("@LoginFlagZone1", SqlDbType.Int) { Value = int.Parse(this.hdnLoginFlagZone1.Value) },
                new SqlParameter("@PayFlagZone1", SqlDbType.Int) { Value = int.Parse(this.hdnPayFlagZone1.Value) },
                new SqlParameter("@BeginDateZone2", SqlDbType.DateTime) { Value = this.hdnBeginDateZone2.Value },
                new SqlParameter("@EndDateZone2", SqlDbType.DateTime) { Value = this.hdnEndDateZone2.Value },
                new SqlParameter("@LoginFlagZone2", SqlDbType.Int) { Value = int.Parse(this.hdnLoginFlagZone2.Value) },
                new SqlParameter("@PayFlagZone2", SqlDbType.Int) { Value = int.Parse(this.hdnPayFlagZone2.Value) },
                new SqlParameter("@BeginDateZone3", SqlDbType.DateTime) { Value = this.hdnBeginDateZone3.Value },
                new SqlParameter("@EndDateZone3", SqlDbType.DateTime) { Value = this.hdnEndDateZone3.Value },
                new SqlParameter("@LoginFlagZone3", SqlDbType.Int) { Value = int.Parse(this.hdnLoginFlagZone3.Value) },
                new SqlParameter("@PayFlagZone3", SqlDbType.Int) { Value = int.Parse(this.hdnPayFlagZone3.Value) },
                new SqlParameter("@DataColumn", SqlDbType.Int) { Value = cmdArgs },
                new SqlParameter("@MemberSourceList", SqlDbType.NVarChar, 1000) { Value = memberSourceList },
                new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType });
        }

        /// <summary>
        /// NSP_DBTool_MemberLoginSourceList 回傳類別
        /// </summary>
        private class NSP_DBTool_MemberLoginSourceList_Result
        {
            /// <summary>
            /// Gets or sets MemberSource
            /// </summary>
            public int MemberSource { get; set; }

            /// <summary>
            /// Gets or sets MemberSourceName
            /// </summary>
            public string MemberSourceName { get; set; }
        }

        /// <summary>
        /// NSP_DBTool_MemberLoginPayCrossAnalysis 回傳類別
        /// </summary>
        private class NSP_DBTool_MemberLoginPayCrossAnalysis_Result
        {
            /// <summary>
            /// Gets or sets Zone1Login
            /// </summary>
            public int Zone1Login { get; set; }

            /// <summary>
            /// Gets or sets Zone1Order
            /// </summary>
            public int Zone1Order { get; set; }

            /// <summary>
            /// Gets or sets Zone1NoOrder
            /// </summary>
            public int Zone1NoOrder { get; set; }

            /// <summary>
            /// Gets or sets Zone2NoLogin
            /// </summary>
            public int Zone2NoLogin { get; set; }

            /// <summary>
            /// Gets or sets Zone2Login
            /// </summary>
            public int Zone2Login { get; set; }

            /// <summary>
            /// Gets or sets Zone2Order
            /// </summary>
            public int Zone2Order { get; set; }

            /// <summary>
            /// Gets or sets Zone2NoOrder
            /// </summary>
            public int Zone2NoOrder { get; set; }

            /// <summary>
            /// Gets or sets Zone3NoLogin
            /// </summary>
            public int Zone3NoLogin { get; set; }

            /// <summary>
            /// Gets or sets Zone3Login
            /// </summary>
            public int Zone3Login { get; set; }

            /// <summary>
            /// Gets or sets Zone3Order
            /// </summary>
            public int Zone3Order { get; set; }

            /// <summary>
            /// Gets or sets Zone3NoOrder
            /// </summary>
            public int Zone3NoOrder { get; set; }
        }

        /// <summary>
        /// Gets or sets NSP_DBTool_MemberLoginPayCrossAnalysisMemberList 回傳類別
        /// </summary>
        private class NSP_DBTool_MemberLoginPayCrossAnalysisMemberList_Result
        {
            /// <summary>
            /// Gets or sets Data1
            /// </summary>
            public string Data1 { get; set; }

            /// <summary>
            /// Gets or sets Data2
            /// </summary>
            public string Data2 { get; set; }

            /// <summary>
            /// Gets or sets Data3
            /// </summary>
            public string Data3 { get; set; }

            /// <summary>
            /// Gets or sets Data4
            /// </summary>
            public string Data4 { get; set; }

            /// <summary>
            /// Gets or sets Data5
            /// </summary>
            public string Data5 { get; set; }

            /// <summary>
            /// Gets or sets Data6
            /// </summary>
            public string Data6 { get; set; }

            /// <summary>
            /// Gets or sets Data7
            /// </summary>
            public string Data7 { get; set; }
        }
    }
}