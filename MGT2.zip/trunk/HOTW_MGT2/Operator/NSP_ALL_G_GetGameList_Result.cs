﻿//-----------------------------------------------------------------------
// <copyright file="NSP_ALL_G_GetGameList_Result.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    /// <summary>
    /// NSP_ALL_G_GetGameList 回傳類別
    /// </summary>
    public class NSP_ALL_G_GetGameList_Result
    {
        /// <summary>
        /// Gets or sets ListID
        /// </summary>
        public int ListID { get; set; }

        /// <summary>
        /// Gets or sets ListEName
        /// </summary>
        public string ListEName { get; set; }

        /// <summary>
        /// Gets or sets ListName
        /// </summary>
        public string ListName { get; set; }

        /// <summary>
        /// Gets or sets ListGroupID
        /// </summary>
        public int ListGroupID { get; set; }
    }
}