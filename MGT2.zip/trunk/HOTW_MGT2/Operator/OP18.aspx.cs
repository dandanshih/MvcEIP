﻿//-----------------------------------------------------------------------
// <copyright file="OP18.aspx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.Operator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using GWeb.AppLibs;

    /// <summary>
    /// 各大通路入口數量
    /// </summary>
    public partial class OP18 : GWeb.AppLibs.FormBase
    {
        /// <summary>
        /// 查詢
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Query_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            this.GV1.DataSource = data.ToList();
            this.GV1.DataBind();
        }

        /// <summary>
        /// 匯出
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Export_Click(object sender, EventArgs e)
        {
            var data = this.GetData();
            NPOIRender.ExportDataTableToEXcel(data.ListToDataTable(), "OP18_各大通路入口數量.xls");
        }

        /// <summary>
        /// 取得資料
        /// </summary>
        /// <returns>資料集合</returns>
        private IEnumerable<NSP_DBTool_BingoMemberSourceCountList_Result> GetData()
        {
            // 分老幣\爽幣
            int coinType = int.TryParse(this.ddlGameAreaType.SelectedValue, out coinType) ? coinType : -1;

            if (this.DropDownList1.SelectedValue == "1")
            {
                return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_BingoMemberSourceCountList_Result>(
                    "exec NSP_DBTool_BingoMemberSourceCountList @PointType",
                    new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType });
            }
            else
            {
                return this.db_analysis_temp.Database.SqlQuery<NSP_DBTool_BingoMemberSourceCountList_Result>(
                    "exec NSP_DBTool_BingoMemberSourceCountList @StartDate, @EndDate, @PointType",
                    new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = this.UCDateRange1.StartDate },
                    new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = this.UCDateRange1.EndDate },
                    new SqlParameter("@PointType", SqlDbType.Int) { Value = coinType });
            }
        }

        /// <summary>
        /// NSP_DBTool_BingoMemberSourceCountList 回傳類別
        /// </summary>
        private class NSP_DBTool_BingoMemberSourceCountList_Result
        {
            /// <summary>
            /// Gets or sets 通路序號
            /// </summary>
            public string 通路序號 { get; set; }

            /// <summary>
            /// Gets or sets 通路名稱
            /// </summary>
            public string 通路名稱 { get; set; }

            /// <summary>
            /// Gets or sets 通路註冊新增人數
            /// </summary>
            public int 通路註冊新增人數 { get; set; }

            /// <summary>
            /// Gets or sets 累積儲值額
            /// </summary>
            public decimal 累積儲值額 { get; set; }

            /// <summary>
            /// Gets or sets 不重複儲值人數
            /// </summary>
            public int 不重複儲值人數 { get; set; }

            /// <summary>
            /// Gets or sets 累積押分數_不含發財金
            /// </summary>
            public decimal 累積押分數_不含發財金 { get; set; }

            /// <summary>
            /// Gets or sets 總遊戲局數
            /// </summary>
            public int 總遊戲局數 { get; set; }

            /// <summary>
            /// Gets or sets 總中賓果局數
            /// </summary>
            public int 總中賓果局數 { get; set; }
        }
    }
}