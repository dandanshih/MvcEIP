﻿using GFC.Utilities;
using GWeb.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb
{
    public partial class EditPwd : FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lit_AgentAccount.Text = AUser.AgentAccount;
            }
        }

        protected void btn_Submit_Click(object sender, EventArgs e)
        {
            if (txt_NewPassword.Text.Trim() != txt_ConfirmPassword.Text.Trim())
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('兩次密碼輸入錯誤！');", true);
                return;
            }
            string Pwd = txt_NewPassword.Text.Trim();

            using (SqlDataReader objSdr = SqlHelper.ExecuteReader
                (
                    WebConfig.connectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_AgentPassword_Edit",
                    new SqlParameter("@AgentID", AUser.AgentID),
                    new SqlParameter("@NewAgentPassword", Pwd)
                ))
            {
                if (objSdr.Read())
                {
                    if (objSdr["Result"].ToString() != "0")
                    {
                        ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('修改失敗！');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('修改成功！');", true);
                    }
                }
                objSdr.Close();
            }
        }
    }
}