﻿using System;

namespace GWeb.AppLibs
{
	public class MPBase : GFC.Web.MasterPageBase
	{
		protected AUser AUser;

		protected override void OnLoad(EventArgs e)
		{
			AUser = (AUser)Session["AUser"];

			base.OnLoad(e);
		}
	}
}