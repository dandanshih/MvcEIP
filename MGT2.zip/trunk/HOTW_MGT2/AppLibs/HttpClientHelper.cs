﻿//-----------------------------------------------------------------------
// <copyright file="HttpClientHelper.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.AppLibs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Web;

    /// <summary>
    /// Http Client Helper Class
    /// </summary>
    public static class HttpClientHelper
    {
        /// <summary>
        /// Post Request
        /// </summary>
        /// <param name="reqString">request string</param>
        /// <returns>true / false</returns>
        public static bool PostRequest(string reqString)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(WebConfig.ActivityServerHostUri);
                var response = client.PostAsync(reqString, null).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Delete Request
        /// </summary>
        /// <param name="reqString">request string</param>
        /// <returns>true / false</returns>
        public static bool DeleteRequest(string reqString)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(WebConfig.ActivityServerHostUri);
                var response = client.DeleteAsync(reqString).Result;
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}