﻿using System.Collections;

namespace GWeb.AppLibs {

    /// <summary>
    /// 此類別用來處理踢後台帳號的佇列. 
    /// </summary>
    public class KickAgentQueue {


        /// <summary>
        /// 取得或設定 KickAgentQueue 實體
        /// </summary>
        private readonly static KickAgentQueue _Instance = new KickAgentQueue();

        /// <summary>
        /// 取得 KickAgentQueue 實體
        /// </summary>
        public static KickAgentQueue Instance {
            get { return _Instance; }
        }

        /// <summary>
        /// 存放代理商編號的佇列
        /// </summary>
        private ArrayList _KickAgentIDList;


        /// <summary>
        /// 初始化
        /// </summary>
        private KickAgentQueue() {
           
            _KickAgentIDList = new ArrayList();

        }

        /// <summary>
        /// 新增一個踢帳號要求
        /// </summary>
        /// <param name="agentID">代理商編號</param>
        public void Add(int agentID) {
            lock (_KickAgentIDList.SyncRoot) {
                _KickAgentIDList.Add(agentID);
            }
        }

        /// <summary>
        /// 刪除一個踢帳號要求
        /// </summary>
        /// <param name="agentID">代理商編號</param>
        public void Remove(int agentID) {
            lock (_KickAgentIDList.SyncRoot) {
                _KickAgentIDList.Remove(agentID);
            }
        }

        /// <summary>
        /// 查詢帳號是否有被指定要踢除
        /// </summary>
        /// <param name="agentID">代理商編號</param>
        /// <returns></returns>
        public bool Exists(int agentID) {
            return (_KickAgentIDList.IndexOf(agentID, 0) > -1);
        }



        

    }
}