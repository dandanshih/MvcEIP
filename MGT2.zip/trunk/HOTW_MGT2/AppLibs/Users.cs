﻿using System;

namespace GWeb
{
	/// <summary>
	/// 網站中 MUser 的 Info 
	/// </summary>
	[Serializable]
	public class AUser : IDisposable
	{
		#region property

		/// <summary>
		/// 是否登入。
		/// </summary>
		public bool IsLogin { get; set; }
		/// <summary>
		/// // 網站編號。
		/// </summary>
		public string SHID { get; set; }
		/// <summary>
		/// 上線的主帳號 ID。
		/// </summary>
		public string AgentID { get; set; }
		/// <summary>
		/// 上線的主帳號。
		/// </summary>
		public string AgentAccount { get; set; }
		/// <summary>
		/// 上線的主帳號暱稱。
		/// </summary>
		public string AgentNickName { get; set; }
		/// <summary>
		/// 上線的主帳號群組 ID。
		/// </summary>
		public string AgentGroupID { get; set; }
		/// <summary>
		/// 上線的實際帳號 ID。
		/// </summary>
		public string ExecAgentID { get; set; }
		/// <summary>
		/// 上線的實際帳號。
		/// </summary>
		public string ExecAgentAccount { get; set; }
		/// <summary>
		/// 上線的實際帳號暱稱。
		/// </summary>
		public string ExecAgentNickName { get; set; }
		/// <summary>
		/// 上線的實際帳號群組 ID。
		/// </summary>
		public string ExecAgentGroupID { get; set; }
		/// <summary>
		/// 上線的 ID。
		/// </summary>
		public string OnlineID { get; set; }
		/// <summary>
		/// 預設開啟的首頁。
		/// </summary>
		public string DefaultWebPage { get; set; }
		/// <summary>
		/// FrontServerIP
		/// </summary>
		public string FrontServerIP { get; set; }
		/// <summary>
		/// 階層群組英文名稱。
		/// </summary>
		public string GroupEName { get; set; }
		/// <summary>
		/// 是否為網站管理者。
		/// </summary>
		public bool IsWebAdmin { get; set; }
		/// <summary>
		/// 是否為子帳號。
		/// </summary>
		public bool IsShadowAccount { get; set; }
		/// <summary>
		/// 調閱室權限(SGTRDLimit:RD SGTCSLimit:客服 Player:玩家)。
		/// </summary>
		public string ReviewAuthority { get; set; }
		/// <summary>
		/// 來源頁面名稱(給SiteMap記住轉頁後的路徑)
		/// </summary>
		public string SourcePage { get; set; }
		

		#endregion

		#region public

		public AUser()
		{
			
		}

		public void Dispose()
		{
			// 解構前將自己登出
			//Logout(UserOnlineID);
		}

		/// <summary>
		/// 檢查帳號密碼, 成功會傳回True
		/// </summary>
		/// <param name="UserName">帳號</param>
		/// <param name="UserPassword">密碼</param>
		/// <param name="Session">目前的 Session</param>
		//public static string CheckLogin(string UserName, string UserPassword, HttpSessionState Session)
		//{

			//string sCheckLoginMsg = "";

			
			//using (SqlConnection conn = new SqlConnection(_DBConnString))
			//{
			//    using (SqlCommand cmd = new SqlCommand("uSP_WebMgt_Authorize_01_Login", conn))
			//    {
			//        cmd.CommandType = CommandType.StoredProcedure;
			//        cmd.Parameters.Add("@sAccount", SqlDbType.VarChar, 30).Value = UserName;

			//        cmd.Parameters.Add("@sPassword", SqlDbType.VarChar, 30).Value = UserPassword;

			//        cmd.Parameters.Add("@sIP", SqlDbType.VarChar, 30).Value = HttpContext.Current.Request.UserHostAddress;
			//        cmd.Parameters.Add("@sSessionID", SqlDbType.VarChar, 50).Value = Session.SessionID;
			//        cmd.Parameters.Add("@sHost", SqlDbType.VarChar, 50).Value = "www.yes888.com.tw";

			//        cmd.Parameters.Add("@sErrorMsg", SqlDbType.VarChar, 50).Value = "";
			//        cmd.Parameters["@sErrorMsg"].Direction = ParameterDirection.InputOutput;

			//        //執行 Stored procedure
			//        using (SqlDataReader dr = cmd.ExecuteReader())
			//        {
			//            if (dr.Read())
			//            {
			//                // 將管理者登入的 Cookie 設定成 Session Cookie
			//                // 將自己 new 起來
			//                AUser U = new AUser();
			//                U.AgentID = dr["AgentID"].ToString();				// 上線的主帳號 ID
			//                U.AgentName = dr["AgentAccount"].ToString();		// 上線的主帳號名稱
			//                U.AgentNickName = dr["AgentNickName"].ToString();		// 上線的主帳號暱稱
			//                U.AgentGroupID = dr["AgentGroupID"].ToString();        // 上線的主帳號群組 ID
			//                U.ExecAgentID = dr["ExecAgentID"].ToString();			// 上線的實際帳號 ID
			//                U.ExecAgentName = dr["ExecAgentAccount"].ToString();	// 上線的實際帳號名稱
			//                U.ExecAgentNickName = dr["ExecAgentNickName"].ToString();	// 上線的實際帳號暱稱
			//                U.ExecAgentGroupID = dr["ExecAgentGroupID"].ToString();	// 上線的實際帳號群組 ID
			//                U.SHAgentID = dr["SHAgentID"].ToString();			// 登入網站的 SHAgentID
			//                U.UserOnlineID = dr["OnlineID"].ToString();			// 上線的 ID
			//                U.IsWebAdmin = Convert.ToBoolean(dr["IsWebAdmin"]);	// 是否為網站管理者
			//                U.DefaultWebPage = dr["DefaultWebPage"].ToString();		// 預設開啟的首頁
			//                U.IsPartner = Convert.ToBoolean(dr["IsPartner"]);	// 是否為經營者
			//                U.IsStoredAgent = Convert.ToBoolean(dr["IsStoredAgent"]);		// 是否為儲值代理
			//                U.IsCustomerService = Convert.ToBoolean(dr["IsCustomerService"]);	// 是否為客服
			//                U.IsShadowAccount = Convert.ToBoolean(dr["IsShadow"]);	// 是否為子帳號
			//                U.FrontServerIP = dr["FrontServerIP"].ToString();		// FrontServerIP

			//                Session.Add("AUser", U);
			//            }
			//            else
			//            {
			//                sCheckLoginMsg = cmd.Parameters["@sErrorMsg"].Value.ToString();
			//            }
			//        }
			//    }
			//}

			//return sCheckLoginMsg;
		//}

		/// <summary>
		/// 登出使用者
		/// </summary>
		//public static void Logout(string sUserOnlineID)
		//{
		//    using (SqlConnection conn = new SqlConnection(_DBConnString))
		//    {
		//        using (SqlCommand cmd = new SqlCommand("uSP_WebMgt_Authorize_03_Logout", conn))
		//        {
		//            cmd.CommandType = CommandType.StoredProcedure;
		//            cmd.Parameters.Add("@iOnlineID", SqlDbType.Int).Value = sUserOnlineID;
		//            cmd.ExecuteNonQuery();
		//        }
		//    }
		//}

		/// <summary>
		/// 讓 AUser 能持續保持在線上
		/// </summary>
		//public bool KeepOnline()
		//{
		//    using (SqlConnection conn = new SqlConnection(_DBConnString))
		//    {
		//        using (SqlCommand cmd = new SqlCommand("uSP_WebMgt_Authorize_02_KeepOnline", conn))
		//        {
		//            cmd.CommandType = CommandType.StoredProcedure;
		//            cmd.Parameters.Add("@iOnlineID", SqlDbType.Int).Value = this.UserOnlineID;
		//            cmd.Parameters.Add("@Return_Value", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
		//            cmd.ExecuteNonQuery();

		//            // 當回傳為 0 表示太久沒有送回 KeepOnline 的訊息或是被強制退出了
		//            if (Convert.ToInt32(cmd.Parameters["@Return_Value"].Value) == 0)
		//            {
		//                Logout(this.UserOnlineID);
		//                return false;
		//            }
		//        }
		//    }
		//    return true;
		//}

		/// <summary>
		/// 讀取 AUser 的使用權限
		/// </summary>
		//public void ReadPagePermit()
		//{
		//    using (SqlConnection conn = new SqlConnection(_DBConnString))
		//    {
		//        using (SqlCommand cmd = new SqlCommand("uSP_WebMgt_Authorize_06_ReadPagePermit", conn))
		//        {

		//        }
		//    }
		//}

		//public string Dump()
		//{
		//    return "AgentID：" + AgentID + m_SplitLine +
		//            "AgentName：" + AgentName + m_SplitLine +
		//            "AgentNickName：" + AgentNickName + m_SplitLine +
		//            "AgentGroupID：" + AgentGroupID + m_SplitLine +
		//            "ExecAgentID：" + ExecAgentID + m_SplitLine +
		//            "ExecAgentName：" + ExecAgentName + m_SplitLine +
		//            "ExecAgentNickName：" + ExecAgentNickName + m_SplitLine +
		//            "ExecAgentGroupID：" + ExecAgentGroupID + m_SplitLine +
		//            "SHAgentID：" + SHAgentID + m_SplitLine +
		//            "UserOnlineID：" + UserOnlineID + m_SplitLine +
		//            "DefaultWebPage：" + DefaultWebPage + m_SplitLine +
		//            "FrontServerIP：" + FrontServerIP + m_SplitLine +
		//            "IsWebAdmin：" + IsWebAdmin + m_SplitLine +
		//            "IsPartner：" + IsPartner + m_SplitLine +
		//            "IsStoredAgent：" + IsStoredAgent + m_SplitLine +
		//            "IsCustomerService：" + IsCustomerService + m_SplitLine +
		//            "IsShadowAccount：" + IsShadowAccount;
		//}

		#endregion
	}
}
