﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;


namespace GWeb.AppLibs
{
	/// <summary>
	///取得縮圖
	///<para>QueryString：</para>
	///<para>自己看</para>
	/// </summary>
	public class GetThumbnJpg : IHttpHandler
	{

		public void ProcessRequest(HttpContext context)
		{

			//取得圖片路徑(轉換為實際路徑)
			string imagePath = context.Server.MapPath(context.Request["Path"]);
            Image imgSource;
			//判斷檔案是否存在
            if (File.Exists(imagePath))
            {
                //若存在取得原始圖片
                imgSource = Image.FromFile(imagePath);
            }
            else
            {
                //若不存在則改成無圖片顯示替代圖
                imgSource = Image.FromFile(context.Server.MapPath(@"~/Images/nopic.jpg"));
            }
				//取得原始寬、高
				int sourceWidth = imgSource.Width;
				int sourceHeight = imgSource.Height;
				//宣告新的圖片
				Image newImg;
				//宣告新的原始寬、高
				int newWidth = int.Parse(context.Request["w"]);
				int newHeight = int.Parse(context.Request["h"]);
				//判斷是否縮放
				if (newWidth == sourceWidth && newHeight == sourceHeight)
					newImg = imgSource;
				else
				{
					//縮放圖片(聽說縮兩次會比較清楚...)
					Image newImg0 = imgSource.GetThumbnailImage(newWidth, newHeight, null, (IntPtr)0);
					newImg = imgSource.GetThumbnailImage(newWidth, newHeight, null, (IntPtr)0);
				}
				//使用記憶體資料流
				using (MemoryStream ms = new MemoryStream())
				{
					//將圖片寫入記憶體資料流
					newImg.Save(ms, ImageFormat.Jpeg);
					//將資料輸出
					foreach (byte b in ms.ToArray())
						context.Response.OutputStream.WriteByte(b);
				}
			
            
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}