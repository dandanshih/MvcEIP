﻿using GWeb.Models;
using System;
using System.Web.UI.WebControls;

namespace GWeb.AppLibs
{
	public class FormBase : GFC.Web.PageBase
	{
        protected Game_Activity_Context game_activity = new Game_Activity_Context();
        protected DB_Analysis_Temp_Context db_analysis_temp = new DB_Analysis_Temp_Context();
        protected Game_Branch_Context game_branch = new Game_Branch_Context();

        public override void Dispose()
        {
            this.game_activity.Dispose();
            this.db_analysis_temp.Dispose();
            this.game_branch.Dispose();
            base.Dispose();
        }

		#region Member
		protected AUser AUser;
		// Email 
		private System.Net.Mail.SmtpClient _MailSender = null;
		protected string m_MailSender = "cs@gonline.com.tw";	// 客服 Mail 的寄件者
		private AuthorityInfo m_Authority = null;
		#endregion

		#region Properties
		/// <summary>
		/// 取得資料庫中定義的資源檔
		/// </summary>
		public CommonResource Resource
		{
			get { return (CommonResource)Application["CommonResource"]; }
		}

		// 權限資訊
		public AuthorityInfo Authority
		{
			get
			{
				if (this.m_Authority == null)
				{
					this.m_Authority = new AuthorityInfo();
				}
				return this.m_Authority;
			}
		}
		#endregion

		protected override void OnLoad(EventArgs e)
		{


			if (Session["AUser"] == null)
			{
				Response.Redirect("~/Login.aspx");
			}
			else
			{
				AUser = (AUser)Session["AUser"];
			}
			
			// 不要讓按鈕 Disable
			IsButtonAutoDisableOnPostBack = false;

			base.OnLoad(e);			
		}

		/// <summary>
		/// 將 TextBox 的斷行換成網頁可正常顯示的斷行符號
		/// </summary>
		public string ReplaceBr(string Value)
		{
			return Value.Replace("\r\n", "<br/>").Replace("\n", "<br/>");
		}

		/// <summary>
		/// 將 Label 的斷行符號 <br/> 換成 \r\n 的資料
		/// </summary>
		public string ReplaceBrBack(string Value)
		{
			return Value.Replace("<br/>", "\r\n");
		}

		/// <summary>
        /// 寄送 Email
        /// </summary>
		public void SendMail(string from, string to, string subject, string body)
		{
			if (from.Trim() == "" || to.Trim() == "") return;

			System.Net.Mail.MailMessage mm = new System.Net.Mail.MailMessage(from, to);
			mm.Body = body;
			mm.Subject = subject;
			mm.IsBodyHtml = true;

			try
			{
				MailSender.Send(mm);
			}
			catch { };
		}

		/// <summary>
		/// 取得客戶通知專用的發信用戶端物件
		/// </summary>
		public System.Net.Mail.SmtpClient MailSender
		{
			get
			{
				// 如果 _SMTP 尚未初始化, 就從設定中取出參數並初始化 SmtpClient 物件
				if (_MailSender == null)
				{
					_MailSender = new System.Net.Mail.SmtpClient();

					_MailSender.Credentials = new System.Net.NetworkCredential("callme", "yes777");
					_MailSender.Host = "mail.yes777.com.tw";
				}
				return _MailSender;
			}
		}


		protected int GetSortColumnIndex(string colName, GridView CustomersGridView)
		{

			foreach (DataControlField field in CustomersGridView.Columns)
			{
				if (field.SortExpression == colName)
				{
					return CustomersGridView.Columns.IndexOf(field);
				}
			}

			return -1;
		}


	}
}