﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GWeb.AppLibs
{
	public class TimeChecker
	{
		public static bool isShutDown = false;

		/// <summary>
		/// 關機。
		/// </summary>
		public static void ShutdownCallback(object obj)
		{
			GS.ServerCommander.FSCommander.FS_AS_SET_SYS_SHUTDOWN();

			// 恢復可關機狀態
			// isShutDown = false;
			// log4net.LogHelper.Info("對FS發送訊息");
			
			GWeb.SystemConfig.ShutDown.stateTimer.Dispose();
		}
	}
}