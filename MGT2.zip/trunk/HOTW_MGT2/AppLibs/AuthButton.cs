﻿
namespace GWeb.AppLibs
{
	public class AuthButton : System.Web.UI.WebControls.Button
	{
		// 要判斷的權限種類
		private EnumAuthority m_AuthorityType = EnumAuthority.None;
		public EnumAuthority AuthorityType
		{
			get
			{
				return this.m_AuthorityType;
			}
			set
			{
				this.m_AuthorityType = value;
			}
		}

		// 是否可見
		public override bool Visible
		{
			get
			{
				if (this.Page is FormBase && base.Visible)
				{
					return ((FormBase)this.Page).Authority.CheckAuthority(AuthorityType);
				}
				else
				{
					return base.Visible;
				}
			}
			set
			{
				base.Visible = value;
			}
		}
	}
}