﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Web;

namespace GWeb.AppLibs
{
    /// <summary>
    /// 事件委派定義 -- 當帳戶控制項有按下 Command 時送出
    /// </summary>
    public delegate void AccountEventHandler(object sender, AccountArgs e);

    /// <summary>
    /// AccountControlBase 的摘要描述
    /// </summary>
    public partial class AccountControlBase : UserControlBase {
        public event AccountEventHandler AccountCommandEvent;

        public enum DataState { dsAdd, dsEdit };
        private HiddenField hfmyUpAgentID;
        private HiddenField hfmyID;
        private HiddenField hfDataState;
		protected AUser AUser;

        #region 屬性
        public string myUpAgentID {
            get { return hfmyUpAgentID.Value; }
            set { hfmyUpAgentID.Value = value; }
        }

        public string myID {
            get { return hfmyID.Value; }
            set { hfmyID.Value = value; }
        }

        public DataState myDataState {
            get { return (DataState)Enum.Parse(typeof(DataState), hfDataState.Value); }
            set { hfDataState.Value = value.ToString(); }
        }
        #endregion

		protected override void OnLoad(EventArgs e)
		{
			AUser = (AUser)Session["AUser"];

			base.OnLoad(e);
		}
        public void Page_Init(object sender, EventArgs e) {
            hfmyUpAgentID = new HiddenField();
            hfmyID = new HiddenField();
            hfDataState = new HiddenField();

            Controls.Add(hfmyUpAgentID);
            Controls.Add(hfmyID);
            Controls.Add(hfDataState);
        }

        protected virtual void OnCommand(object sender, string CommandName, string CommandArgument) {
            if (AccountCommandEvent != null) {
                AccountCommandEvent(sender, new AccountArgs(CommandName, CommandArgument));
            }
        }

        protected void ReadUpAgentInfo(string sUpAgentID, out Double CurrentPoints, out Double CurrentContributeRate) {
            CurrentPoints = 0;
            CurrentContributeRate = 0;

            using (SqlConnection conn = new SqlConnection(WebConfig.connectionString)) {

                // 讀取上階目前的金額與分成比，當成目前要設定的最大上限值
                using (SqlCommand cmd = new SqlCommand("uSP_WebMgt_Account_01_05_ReadAgentInfo", conn)) {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@iAgentID", SqlDbType.Int).Value = sUpAgentID;

                    using (SqlDataReader dr = cmd.ExecuteReader()) {
                        if (dr.Read()) {
                            CurrentPoints = Convert.ToDouble(dr["Points"]);
                            CurrentContributeRate = Convert.ToDouble(dr["ContributeRate"]);
                        }
                    }
                }
            }
        }

        protected bool PauseAccount(string sAgentID, string LockType) {
            bool bResult = false;

            //取得Web.config中設定的資料庫連線字串
            using (SqlConnection conn = new SqlConnection(WebConfig.connectionString)) {
                using (SqlCommand cmd = conn.CreateCommand()) {
                    cmd.CommandType = CommandType.StoredProcedure;

                    AUser m_User = (AUser)Session["AUser"];
                    cmd.CommandText = "uSP_WebMgt_Authorize_04_PauseAccount";
                    cmd.Parameters.Add("@iActionAgentID", SqlDbType.Int).Value = Convert.ToInt32(sAgentID);
                    cmd.Parameters.Add("@iExecAgentID", SqlDbType.Int).Value = m_User.ExecAgentID;
                    cmd.Parameters.Add("@sLockType", SqlDbType.VarChar, 20).Value = LockType;

                    //執行stored procedure
                    using (SqlDataReader dr = cmd.ExecuteReader()) {
                        if (dr.Read()) {
                            string sExecResult = dr["Msg"].ToString();

                            switch (sExecResult) {
                                case "LockByMasterAccount":
                                case "NotEnoughPermit":
                                case "Occupation":
                                case "StoreLock": {
                                        // 通知 Client 說他的權限不足，所以無法調整該權限的異動
                                        string sAlert = GetGlobalResourceObject("Resources", sExecResult).ToString();
                                        Utility.ClientAlert(this.Page, sAlert);
                                        break;
                                    }
                                case "Lock": // 目前的動作是鎖定，所以啟動背景程式去踢 Server 上的玩家
                                case "Unlock": {// 目前的動作是連鎖解除,所以啟動背景程式去踢 Server 上的玩家
                                        if (dr.NextResult()) {
                                            while (dr.Read()) {
                                                //string sCmd = "267&" + AUser.SHID + "&" + dr["MemberID"].ToString() + "&0";
                                                //Utility.SendInfoToFrontServer(m_User.FrontServerIP, sCmd);

                                                // 20110509 Phil: 改對前台發出登出命令
                                                GameCommandHandler.LogoutMember(int.Parse(dr["MemberID"].ToString()));
                                            }
                                        }
                                        bResult = true;
                                        break;
                                    }
                                default:  //這是傳出空白字串，所以不做任何動作
                                    bResult = true;
                                    break;
                            }
                        }
                    }
                }
            }

            return bResult;
        }
    }

    /// <summary>
    /// 宣告一個傳遞用的參數物件
    /// </summary>
    public partial class AccountArgs : EventArgs {
        private string m_CommandName;
        private string m_CommandArgument;

        public AccountArgs(string CommandName, string CommandArgument) {
            m_CommandName = CommandName;
            m_CommandArgument = CommandArgument;
        }

        public AccountArgs(string CommandName) {
            m_CommandName = CommandName;
        }

        public string CommandName {
            get { return m_CommandName; }
            set { m_CommandName = value; }
        }

        public string CommandArgument {
            get { return m_CommandArgument; }
            set { m_CommandArgument = value; }
        }
    }
}