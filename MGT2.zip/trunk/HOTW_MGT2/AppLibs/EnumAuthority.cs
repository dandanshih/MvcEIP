﻿using System;

namespace GWeb.AppLibs
{
	[Flags]
	public enum EnumAuthority
	{
		None = 0,	// 無權限
		Run = 1,	// 執行
		Add = 2,	// 新增
		Edit = 4,	// 修改
		Del = 8,	// 刪除
		PauseAccount = 16,	// 停權或黑名單
		Ext2 = 32,	// 擴充2
		Ext3 = 64,	// 擴充3
		Permission=4096,	//權限按鈕
		Query=8192,	//查詢按鈕
		KeyIn=16384,	//存入
		KeyOut=32768,	//提出
		LiveReNew=65536,	//即時更新
		KickOut=131072,	//踢出線上使用者
		//全部
		All = Run | Add | Edit | Del | PauseAccount | Ext2 | Ext3 | Permission | Query | KeyIn | KeyOut | LiveReNew | KickOut
	}
}