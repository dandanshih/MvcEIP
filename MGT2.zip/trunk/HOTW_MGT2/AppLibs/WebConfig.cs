﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using System.Net;
using System.Net.Sockets;

namespace GWeb.AppLibs
{
	public class WebConfig
	{
		public static string SHID = ConfigurationManager.AppSettings["SHID"].ToString();
        public static string connectionString = GFC.Utility.ConfigurationManager.Sections.GetConfig().Global.MasterDBConnString;
		public static string CSEmail = ConfigurationManager.AppSettings["CSEmail"].ToString();	
		public static string SMSDB = ConfigurationManager.ConnectionStrings["SMSDB"].ToString();
        public static string WinLoseConnectionString = ConfigurationManager.ConnectionStrings["WinLoseConnectionString"].ToString();
		public static string GameWebDomain = ConfigurationManager.AppSettings["GameWebDomain"].ToString();
		public static string domain = ConfigurationManager.AppSettings["Domain"].ToString();
        public static string gameReviewUrl = ConfigurationManager.AppSettings["GameReviewUrl"].ToString();
		public static string DataInfoUrl = ConfigurationManager.AppSettings["DataInfoUrl"].ToString();
		public static string LogWebDomain = ConfigurationManager.AppSettings["LogWebDomain"].ToString();
		public static string PaymentGatewayHost = ConfigurationManager.AppSettings["Payment_PaymentGatewayHost"].ToString();
		public static string PaymentStoreID = ConfigurationManager.AppSettings["Payment_StoreID"].ToString();
		public static string PaymentEncryptKey = ConfigurationManager.AppSettings["Payment_EncryptKey"].ToString();
        public static string CPAGatewayDB = ConfigurationManager.ConnectionStrings["CPAGatewayDB"].ToString();
        public static string ActivityServerHostUri = ConfigurationManager.AppSettings["ActivityServerHostUri"].ToString();

		/// <summary>
		/// 踢代理商。
		/// </summary>
		/// <param name="agentID">指定要踢的代理商編號。</param>
		/// <param name="execAgentID">執行動作的代理商編號。</param>
		public static void KickAgent(int agentID, int execAgentID)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@AgentID", agentID),
				new SqlParameter("@ExecAgentID", execAgentID),
			};

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString,
									  CommandType.StoredProcedure,
									  "NSP_AgentWeb_A_KickAgent",
									  param);
		}

		/// <summary>
		/// 設定黑名單。
		/// </summary>
		/// <param name="memberAccount">指定加入黑名單的會員帳號。</param>
		/// <param name="execAgentID">執行動作的代理商編號。</param>
		/// <param name="alarmType">黑名單動作。(0:解除 1:在遊戲中設定黑名單 2:在網頁中設定黑名單)</param>
		/// <returns>回傳整數。(0: 設定成功 -1:此帳號不存在 -2:此帳號已經被列為黑名單了 -3: 此帳號不是黑名單帳號)</returns>
		public static int SetBlackList(string memberAccount, string execAgent, int alarmType)
		{
			int result = 0;

			SqlParameter[] param =
			{
				new SqlParameter("@MemberAccount", memberAccount),
                new SqlParameter("@NickName", ""),
				new SqlParameter("@ExecAccount", execAgent),
				new SqlParameter("@AlarmType", alarmType),
                new SqlParameter("@Result", SqlDbType.Int)
			};

			param[param.Length -1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, 
									  CommandType.StoredProcedure, 
									  "NSP_A_SetMemberAccountAlarmed", 
									  param);

            result = int.Parse(param[param.Length - 1].Value.ToString());

			return result;
		}

		/// <summary>
		/// 保持在線狀態，如 90 秒未執行則回傳 false。
		/// </summary>
		/// <param name="onlineID">OnlineID。</param>
		/// <returns></returns>
		public static bool KeepOnline(string onlineID)
		{
			bool isOnline = false;

			SqlParameter[] param = 
			{
				new SqlParameter("@OnlineID", onlineID)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_A_KeepUserOnline",
														   param);

			if (objDtr.Read())
			{
				// 如果回傳 1 或 4 則進行登出動作
				if (objDtr[0].ToString() == "1" || objDtr[0].ToString() == "4")
				{
					isOnline = false;
				}
				else
				{
					isOnline = true;
				}
			}

			objDtr.Close();

			return isOnline;
		}
	}
}