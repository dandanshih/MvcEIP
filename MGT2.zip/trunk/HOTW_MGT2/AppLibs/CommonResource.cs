﻿using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Threading;
using System.Linq;

namespace GWeb
{
    public class CommonResource
    {
        private DataTable _TextResourceTable = null;

        private object _Locker = new object();

        private bool _IsWriting = false;
        /// <summary>
        /// 初始化
        /// </summary>
        public CommonResource()
        {

        }

        public void LoadData()
        {
            _IsWriting = true;
            lock (_Locker)
            {

                string strSHID = WebConfigurationManager.AppSettings["SHID"];

                SqlConnection sqlConn = new SqlConnection(GFC.Utility.ConfigurationManager.Sections.GetConfig().Global.MasterDBConnString);
                SqlDataAdapter sqlAdapter = new SqlDataAdapter("SELECT * FROM dbo.FN_S_GetTextResource(" + strSHID + ")", sqlConn);
                _TextResourceTable = new DataTable("TextResource");
                sqlAdapter.Fill(_TextResourceTable);
            }
            _IsWriting = false;
        }

        /// <summary>
        /// 取得資源
        /// </summary>
        /// <param name="type">資源種類</param>
        /// <param name="key">資源鍵</param>
        /// <returns></returns>
        public string GetTextResx(string type, object key)
        {
            if (key == null)
                return "";
            return GetTextResx(type, key.ToString());
        }

        /// <summary>
        /// 取得特定 ResxType 的列表。
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public EnumerableRowCollection GetTextResxRow(string type)
        {
            // 目前語系
            string currentLanguage = Thread.CurrentThread.CurrentUICulture.Name.ToString().Replace("-", "").ToUpper();
            // 允許語系
            string[] allowLanguage = { "ZHTW" };
            // 預設語系欄位
            string defaultField = "Value_Default";
            // 根據目前的語系指定資源值的欄位名稱
            string valueField = allowLanguage.Contains(currentLanguage) ? "Value_" + currentLanguage : defaultField;

            // 如果資料表正在寫入中就等候寫入完畢
            while (_IsWriting)
            {
                System.Threading.Thread.Sleep(1000);
            }

            var result = from i in _TextResourceTable.AsEnumerable()
                         where i["ResxType"].ToString() == type
                         select new
                         {
                             Key = i["ResxKey"],
                             Value = (i[valueField] == null || i[valueField].ToString() == "") ? i[defaultField] : i[valueField]
                         };

            // 傳回資源值
            return result;
        }

        /// <summary>
        /// 取得資源
        /// </summary>
        /// <param name="type">資源種類</param>
        /// <param name="key">資源鍵</param>
        /// <returns></returns>
        public string GetTextResx(string type, string key, params string[] textParams)
        {
            string currentLanguage = Thread.CurrentThread.CurrentUICulture.Name.ToString();

            // 根據目前的語系指定資源值的欄位名稱
            string valueField = "Value_" + currentLanguage.Replace("-", "").ToUpper();

            string result = "";

            // 如果資料表正在寫入中就等候寫入完畢

            while (_IsWriting)
            {
                System.Threading.Thread.Sleep(1000);
            }

            DataRow[] drs = _TextResourceTable.Select("ResxType='" + type + "' and ResxKey='" + key + "'");

            // 如果沒有該資源項目, 或是該資源項目為空白, 就直接傳回資源項目文字
            if (drs.Length == 0)
            {
                result = key;
            }
            else if (drs[0].Table.Columns.Contains(valueField) &&    // 20100302 Phil: 增加判斷是否有該語系欄位
                drs[0][valueField].ToString().Trim().Length != 0)
            {
                result = drs[0][valueField].ToString().Trim();
            }
            else if (drs[0]["Value_Default"].ToString().Trim().Length != 0)
            {
                result = drs[0]["Value_Default"].ToString().Trim();
            }

            // 如果帶有參數, 就置換其參數文字
            if (textParams != null)
            {
                for (int i = 0; i < textParams.Length; i++)
                {
                    if (result.IndexOf("%" + (i + 1).ToString()) > -1)
                    {
                        result = result.Replace("%" + (i + 1).ToString(), textParams[0]);
                    }
                }
            }

            // 傳回資源值
            return result;
        }
    }
}
