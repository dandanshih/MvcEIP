﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GWeb.AppLibs
{
	public enum IIS_Server_Protocol
	{
		// 發送回覆
		IM_QA_Send_Mail		= 256
	}
}