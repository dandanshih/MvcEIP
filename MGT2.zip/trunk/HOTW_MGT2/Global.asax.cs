﻿using System;
using PaymentGateway.StoreAPI;
using GWeb.AppLibs;
using System.Data;

namespace GWeb
{
	public class Global : System.Web.HttpApplication
	{
		public const string SeparatorLevel1 = "#@$";
		public const string SeparatorLevel2 = "$#%";
		public const string SeparatorLevel3 = "%$^";
		public const string SeparatorLevel4 = "^%&";

		protected void Application_Start(object sender, EventArgs e)
		{
			EO.Web.Runtime.AddLicense(
				"CrWfWZekzRfonNzyBBDInbW2xtu0cqq6xuSvdabw+g7kp+rp2g+9RoGkscuf" +
				"dePt9BDtrNzpz+eupeDn9hnyntzCnrWfWZekzQzrpeb7z7iJWZekscufWZfA" +
				"8g/jWev9ARC8W8Tp/yChWe3pAx7oqOXBs+KtaZmkwOmMQ5ekscufWZekzQzj" +
				"nZf4ChvkdpnX/RTjnsTp/yChWe3pAx7oqOXBs+KtaZmkwOmMQ5ekscufWZek" +
				"zQzjnZf4ChvkdpnY8g3SrentAc2fr9z2BBTup7SmyNmvW5ezz7iJWZekscuf" +
				"WZfA8g/jWev9ARC8W8v29hDVotz7s8v1nun3+hrtdpm7v9uhWabCnrWfWZek" +
				"scufWbPl9Q+frfD09uihhuzwBRTPmt7ps8v1nun3+hrtdpm7v9uhWabCnrWf" +
				"WZekscufWbPl9Q+frfD09uihfNjw9hnjmummsSHkq+rtABm8W66ywc2faLWR" +
				"m8ufWZekscufddjo9cvzsufpzs3CmuPw8wzipJmkBxDxrODz/+ihcKW0s8uu" +
				"d4SOscufWZekscu7mtvosR/4qdzBs+zJes/ZARfumtvpA82fr9z2BBTup7Sm" +
				"yNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8W7vt8hfuoJmkBxDxrODz/+ih" +
				"cKW0s8uud4SOscufWZekscu7mtvosR/4qdzBs/7vpeD4BRDxW5f69h3youby" +
				"zs22Z6emsdq9RoGkscufWZeksefgndukBSTvnrSm3gzypNzo1g/orZmkBxDx" +
				"rODz/+ihcKW0s8uud4SOscufWZekscu7mtvosR/4qdzBs/LxotumsSHkq+rt" +
				"ABm8W66ywc2faLWRm8ufWZekscufddjo9cvzsufpzs3CqOPzA/vonOLpA82f" +
				"r9z2BBTup7SmyNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8W8r09hfrfN/p" +
				"9Bbkq5mkBxDxrODz/+ihcKW0s8uud4SOscufWZekscu7mtvosR/4qdzBs/Dj" +
				"ouvzA82fr9z2BBTup7SmyNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8W8Dx" +
				"8hLkk+bz/s2fr9z2BBTup7SmyNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8" +
				"W7vzCBnrqNjo9h2hWe3pAx7oqOXBs+KtaZmkwOmMQ5ekscufWZekzQzjnZf4" +
				"ChvkdpnK/Rrgrdz2s8v1nun3+hrtdpm7v9uhWabCnrWfWZekzdrgpePzCOmM" +
				"Q5ekscu7rODr/wzzrunpzxXXrNv81wHPqs7NygPWsMXYASHtasjBzueurODr" +
				"/wzzrunpz7iJdabw+g7kp+rpz7iJdePt9BDtrNzCng==");
             
            // 從資料庫載入資源檔
            Utility.TextResource.LoadData();
            
                

		}

		protected void Session_Start(object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{

		}

		protected void Application_End(object sender, EventArgs e)
		{

		}


        public override void Init() {
            base.Init();

            Application.Lock();
            if (Utility.KickAgentQueue == null) {
                Utility.KickAgentQueue = GWeb.AppLibs.KickAgentQueue.Instance;
            }
            Application.UnLock();
        }

	}
}