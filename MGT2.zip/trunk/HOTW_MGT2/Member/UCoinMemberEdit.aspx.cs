﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class UCoinMemberEdit : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				//if (Request["mid"] == null)
				//{
				//    //WebUtility.ResponseScript(Page, "alert('" + "資料載入失敗\r\n將返回管理頁面" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormBegin);
				//    pnlError.Visible = true;
				//    pnlEdit.Visible = false;
				//    //Response.Redirect("MemberQuery.aspx");
				//}
				//else
				//{
				//    pnlError.Visible = false;
				//    pnlEdit.Visible = true;
				//    LoadData();
				//}
				LoadData();
			}
		}

		protected void lbReturn_Click(object sender, EventArgs e)
		{
			Response.Redirect("MemberQuery.aspx", true);
		}

		/// <summary>
		/// 讀取會員資料
		/// </summary>
		protected void LoadData()
		{

			// 檢查參數
			int MemberID = int.TryParse(Request.QueryString["mid"], out MemberID) ? MemberID : 0;
			if (MemberID == 0)
			{
				WebUtility.ResponseScript(Page, "alert('" + @"查無此會員資料\n將返回管理頁面" + "');location.href='MemberQuery.aspx'", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			SqlDataReader objDtr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Member_DetailData",
				new SqlParameter("@MemberID", MemberID)
			);

			if (objDtr.Read())
			{
				tbxLoginID.Text = objDtr["MemberAccount"].ToString();
				tbxNickName.Text = objDtr["NickName"].ToString();
				tbxTelMobile.Text = objDtr["Mobile"].ToString();
				tbxEMail.Text = objDtr["Email"].ToString();
				txtBirth.Text = DateTime.Parse(objDtr["Birthday"].ToString()).ToString("yyyy/MM/dd");
				rblUserSex.SelectedValue = objDtr["Gender"].ToString().Equals("True") ? "先生" : "小姐";
				ddlCity.SelectedValue = objDtr["City"].ToString();
				tbxAddr.Text = objDtr["Address"].ToString();
				cbxIsJoinAdv.Checked = objDtr["NewsYN"].ToString() == "0" ? false : true;
				txtIntroducer.Text = objDtr["Introducer"].ToString();
			}

			objDtr.Close();
		}

		protected void btnClose_Click(object sender, EventArgs e)
		{
			//Response.Redirect("MemberQuery.aspx");
			WebUtility.ResponseScript(Page, "location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			//欄位驗證不過就離開
			string ResultValidForm = string.Empty;
			if (!ValidMemberForm(out ResultValidForm))
			{
				WebUtility.ResponseScript(Page, "alert('" + ResultValidForm + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}



			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount",tbxLoginID.Text),
				new SqlParameter("@MemberPassword",tbxLoginPassword.Text.Trim()),
				new SqlParameter("@RealName",tbxCustName.Text),
				new SqlParameter("@NickName",tbxNickName.Text),
				new SqlParameter("@Email",tbxEMail.Text),
				new SqlParameter("@Birthday",txtBirth.Text),
				new SqlParameter("@Mobile",tbxTelMobile.Text),
				//new SqlParameter("@IdPassport",tbxCustPID.Text),
				new SqlParameter("@Gender",(rblUserSex.Items[0].Selected) ? 1 : 0),
				new SqlParameter("@OnlineIP",Request.ServerVariables["REMOTE_ADDR"].ToString()),
				new SqlParameter("@City",ddlCity.SelectedValue),
				new SqlParameter("@Address",tbxAddr.Text),
				new SqlParameter("@NewsYN",cbxIsJoinAdv.Checked?1:0),
				//new SqlParameter("@Invoice_Type",int.Parse(rbl_InVoice_Type.SelectedValue)),
				//new SqlParameter("@Invoice_City",ddl_InVoice_City.SelectedValue),
				//new SqlParameter("@Invoice_Address",txt_Invoice_Address.Text),
				//new SqlParameter("@Invoice_Recipient",txt_Invoice_Recipient.Text),
				new SqlParameter("@Introducer",txtIntroducer.Text),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};

			string resultCode = string.Empty;
			string strMessage = string.Empty;
			try
			{
				resultCode = SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_Edit", arParms).ToString();
			}
			catch (Exception ex)
			{
				resultCode = ex.Message;
			}
			finally
			{
				switch (resultCode)
				{
					case "0":
						strMessage = "修改成功";
						break;
					case "1":
						strMessage = "帳號已存在";
						break;
					case "2":
						strMessage = "此手機已申請過";
						break;
					case "3":
						strMessage = "介紹人不存在";
						break;
					case "4":
						strMessage = "介紹人不可填自己";
						break;
					default:
						strMessage = resultCode;
						break;
				}

				WebUtility.ResponseScript(Page, "alert('" + strMessage + "');location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}

		}

		/// <summary>
		/// 驗證基本資料頁表單
		/// </summary>
		private bool ValidMemberForm(out string errorMessage)
		{

			errorMessage = "";

			string tmp = "";
			int iTmp = 0;

			// 將送出按鈕還原為可點選狀態

			tbxCustName.Text = tbxCustName.Text.Trim();
			tbxLoginID.Text = tbxLoginID.Text.Trim().Replace(" ", "");
			tbxLoginPassword.Text = tbxLoginPassword.Text.Trim().Replace(" ", "");
			tbxEMail.Text = tbxEMail.Text.Trim().Replace(" ", "");
			tbxTelMobile.Text = tbxTelMobile.Text.Trim().Replace(" ", "");
			tbxNickName.Text = tbxNickName.Text.Trim();

			tmp = tbxLoginID.Text;
			if (tmp.Trim() == "")
			{

				errorMessage = "登入帳號不可空白";
				return false;
			}
			else if (tmp.Length < 6 || tmp.Length > 12
				|| !System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9a-zA-Z]*$"))
			{

				errorMessage = "登入帳號必須是 6 ~ 12 碼的英文數字組合";
				return false;
			}
			else if (int.TryParse(tmp, out iTmp))
			{

				errorMessage = "帳號至少須包含一個英文字母";
				return false;
			}
			else if (tbxTelMobile.Text.Length > 0 && tbxLoginID.Text.IndexOf(tbxTelMobile.Text) > -1)
			{

				errorMessage = "帳號中不可包含您的手機號碼";
				return false;
			}
			else if (tbxEMail.Text.IsEMail() && tbxLoginID.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1)
			{

				errorMessage = "帳號中不可包含您的EMail";
				return false;
			}



			if (tbxLoginPassword.Text.Trim().Length == 0)
			{

				//errorMessage = "密碼不可空白";
				//return false;
			}
			else if (!IsValidRegular_MemberPassword(tbxLoginPassword.Text.ToUpper(), out errorMessage))
			{

				return false;
			}
			else if ((tbxLoginID.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxLoginID.Text) > -1)
				|| (tbxTelMobile.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxTelMobile.Text) > -1)
				|| (tbxNickName.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxNickName.Text) > -1)
				|| (tbxEMail.Text.IsEMail() && tbxLoginPassword.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1))
			{

				errorMessage = "密碼中不可包含帳號、手機號碼、暱稱或EMail";
				return false;
			}
			if (tbxLoginPassword.Text.Trim().Length != 0)
			{
				if (tbxConfirmPassword.Text.Trim() == "")
				{

					errorMessage = "確認密碼不可空白";
					return false;
				}
				else if (tbxConfirmPassword.Text != tbxLoginPassword.Text)
				{

					errorMessage = "與上面的密碼不相同";
					return false;

				}
				ViewState["tbxLoginPassword"] = tbxLoginPassword.Text.ToSafeString();
				ViewState["tbxConfirmPassword"] = tbxConfirmPassword.Text.ToSafeString();
			}


			if (tbxEMail.Text.Trim().Length > 0 && !tbxEMail.Text.IsEMail())
			{

				errorMessage = "E-Mail格式錯誤";
				return false;
			}



			if (tbxCustName.Text == "")
			{

				errorMessage = "姓名不可空白";
				return false;
			}
			if (tbxNickName.Text == "")
			{

				errorMessage = "暱稱不可空白";
				return false;
			}
			else if ((tbxLoginID.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxLoginID.Text) > -1)
					|| (tbxTelMobile.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxTelMobile.Text) > -1))
			{

				errorMessage = "暱稱中不可包含帳號或手機號碼";
				return false;
			}

			// 暱稱中不可包含逗點
			if (!System.Text.RegularExpressions.Regex.IsMatch(tbxNickName.Text, "^[A-Za-z0-9\u4E00-\u9FA5\uF900-\uFA2D]+$"))
			{
				errorMessage = "玩家暱稱不能包含特殊符號";
				return false;
			}

			// 暱稱字數檢查
			int intNickNameLength = 0;
			foreach (char c in tbxNickName.Text)
			{
				if (c >= 0x3000 && c <= 0x9fff)
				{
					intNickNameLength += 2;
				}
				else
				{
					intNickNameLength += 1;
				}
			}
			if (intNickNameLength > 12)
			{

				errorMessage = "暱稱請輸入6個中文字或12個英文字";
				return false;
			}

			//if (!(ddlBirthYear.Text + "/" + ddlBirthMonth.Text + "/" + ddlBirthDay.Text).IsDate())
			//{

			//    errorMessage = "日期錯誤";
			//    return false;
			//}

			//if (tbxCustPID.Text.Trim().Length == 0)
			//{

			//    errorMessage = "身分證末四碼不可空白";
			//    return false;
			//}

			//if (tbxCustPID.Text.Trim().Length != 4)
			//{

			//    errorMessage = "請填寫末四碼";
			//    return false;
			//}

			//if (tbxTelHome.Text.Trim() != "")
			//{
			//    tmp = tbxTelHome.Text.Trim();
			//    if (!(tmp.IsNumeric() && tmp.Length > 8 && tmp.Length < 11 && tmp.Substring(0, 1) == "0"))
			//    {

			//        errorMessage = "電話不正確";
			//        return false;
			//    }
			//}

			// 選擇索取發票
			//if (rbl_InVoice_Type.SelectedValue == "2")
			//{
			//    // 檢查發票地址
			//    if (string.IsNullOrEmpty(txt_Invoice_Address.Text))
			//    {

			//        errorMessage = "請輸入發票地址";
			//        return false;
			//    }

			//    // 檢查發票收件人
			//    if (string.IsNullOrEmpty(txt_Invoice_Recipient.Text))
			//    {

			//        errorMessage = "請輸入發票收件人";
			//        return false;
			//    }
			//}


			tmp = tbxTelMobile.Text.Trim();
			if (tmp.Length == 0)
			{

				errorMessage = "手機不可空白";
				return false;
			}
			if (!(tmp.IsNumeric() && tmp.Length == 10 && tmp.Substring(0, 2) == "09"))
			{

				errorMessage = "手機格式錯誤";
				return false;
			}

			return true;
		}


		/// <summary>
		/// 檢查密碼的格式是否正確
		/// </summary>
		/// <param name="passWord">要檢查的密碼字串</param>
		/// <param name="invalidText">要傳回的錯誤訊息</param>
		/// <returns></returns>
		protected bool IsValidRegular_MemberPassword(string passWord, out string invalidText)
		{
			passWord = passWord.Trim().Replace(" ", "");
			invalidText = "";

			int iTmp = 0;
			string sTmp = "";
			if (int.TryParse(passWord, out iTmp))
			{
				invalidText = "密碼至少須包含一個英文字母";
				return false;
			}

			if (passWord.Length < 6 || passWord.Length > 12)
			{
				invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
				return false;
			}
			iTmp = 0;
			for (int i = 0; i < passWord.Length; i++)
			{
				int code = passWord[i];
				if (sTmp.IndexOf(passWord[i]) == -1)
				{ // 把不同的文字加進暫存變數, 等下要判斷有幾種字元
					sTmp += passWord[i].ToString();
				}
				if (!((code >= 48 && code <= 57) || (code >= 65 && code <= 90) || (code >= 97 && code <= 122)))
				{
					invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
					return false;
				}

				// 如果往後的 3 個字元都是連續字元(例如 123、abc、321、cba、..), 就傳出錯誤
				//if (passWord.Length - i > 2 &&
				//        (
				//        passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
				//                                    + Convert.ToChar(code + 1).ToString()
				//                                    + Convert.ToChar(code + 2).ToString())
				//            ||
				//         passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
				//                                    + Convert.ToChar(code - 1).ToString()
				//                                    + Convert.ToChar(code - 2).ToString())
				//        ))
				//{
				//    invalidText = "密碼不可包含 3 個連續數字或 3 個連續字母";
				//    return false;
				//}
			}
			if (sTmp.Length < 4)
			{
				invalidText = "密碼必須包含 4 種字元以上";
				return false;
			}

			return true;

		}
	}
}