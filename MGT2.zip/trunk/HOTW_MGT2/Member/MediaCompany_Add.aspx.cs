﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;
using System.Data;
using GFC;

namespace GWeb.Member
{
    public partial class MediaCompany_Add : GWeb.AppLibs.FormBase
    {
        private bool ValidMemberForm(out string errorMessage)
        {
            errorMessage = "";

            if (string.IsNullOrEmpty(txtAccount.Text.Trim()))
            {
                errorMessage = "登入代號不可空白";
                return false;
            }

            if (string.IsNullOrEmpty(txtPwd.Text.Trim()))
            {
                errorMessage = "登入密碼不可空白";
                return false;
            }

            if (string.IsNullOrEmpty(txtPwdConfirm.Text.Trim()))
            {
                errorMessage = "登入密碼確認不可空白";
                return false;
            }
            else if (txtPwdConfirm.Text != txtPwd.Text)
            {
                errorMessage = "兩次輸入密碼不相同";
                return false;
            }

            if (string.IsNullOrEmpty(txtCompanyName.Text.Trim()))
            {
                errorMessage = "公司名稱不可空白";
                return false;
            }

            if (string.IsNullOrEmpty(txtContact.Text.Trim()))
            {
                errorMessage = "聯絡人不可空白";
                return false;
            }

            if (string.IsNullOrEmpty(txtMobile.Text.Trim()))
            {
                errorMessage = "聯絡電話不可空白";
                return false;
            }
            else if (!txtMobile.Text.IsNumeric())
            {
                errorMessage = "聯絡電話格式錯誤";
                return false;
            }

            return true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string ErrorMsg = "";
            if (!ValidMemberForm(out ErrorMsg))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", string.Format("alert('{0}');", ErrorMsg), true);
                return;
            }

            SqlParameter[] param =
            {
                new SqlParameter("@Account", txtAccount.Text),
			    new SqlParameter("@PWD",txtPwd.Text),
			    new SqlParameter("@CompanyName", txtCompanyName.Text),
			    new SqlParameter("@Contact", txtContact.Text),
			    new SqlParameter("@Mobile", txtMobile.Text)
            };

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_MediaCompanyAdd",
                param
            );

            objDr.Read();

            switch (objDr["Result"].ToString())
            {
                case "0":
                    break;
                case "-1":
                    ErrorMsg = "新增失敗！";
                    break;
                case "-2":
                    ErrorMsg = "帳號重複！";
                    break;
                case "-3":
                    ErrorMsg = "公司名稱重複！";
                    break;
            }

            objDr.Close();

            if (!string.IsNullOrEmpty(ErrorMsg))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", string.Format("alert('{0}');", ErrorMsg), true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('新增成功！');location.href='/Member/MediaCompany.aspx';", true);
            }
        }
    }
}