﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;
using System.Web.UI;

namespace GWeb.Member
{
	public partial class MemberKeyInOut : GWeb.AppLibs.FormBase
    {
        #region private

        /// <summary>
        /// 取得會員編號。
        /// </summary>
        private int GetMemberID(int QueryType, string QueryAccount, string QueryNickName)
        {
            int MemberID = -1;

            SqlParameter[] param = new SqlParameter[]
            {
                // 搜尋項目 0:帳號 1:編號 2:暱稱 3:手機 4:信箱
                new SqlParameter("@QueryType", QueryType),
                // 會員帳號
	            new SqlParameter("@MemberAccount", QueryAccount),
                // 暱稱
	            new SqlParameter("@NickName", QueryNickName),
                new SqlParameter("@TotalRecords",DbType.Int16)
            };

            SqlDataReader ObjDtr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_List",
                param
            );

            if (ObjDtr.Read())
            {
                MemberID = int.Parse(ObjDtr["MemberID"].ToString());
            }
            else
            {
                WebUtility.ResponseScript(Page, "alert('查無此會員');", WebUtility.ResponseScriptPlace.NearFormEnd);
            }

            ObjDtr.Close();

            return MemberID; 
        }

        /// <summary>
        /// 載入查詢。
        /// </summary>
        private void LoadData()
        {
            SqlParameter[] arParms =
			{
				new SqlParameter("@AgentID",AUser.AgentID),
				new SqlParameter("@StartDate",UCDateRange1.StartDate),
				new SqlParameter("@EndDate",UCDateRange1.EndDate),
				new SqlParameter("@GameAreaType", ddlGameAreaType.SelectedItem.Value),
				new SqlParameter("@PageSize",UCPager1.PageSize),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

            arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

            SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Agent_QryMemberBalanceList", arParms);

            grdMemberKeyInOut.DataSource = sdr;
            grdMemberKeyInOut.DataBind();
            sdr.Close();

            UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
            UCPager1.DataBind();
        }

        #endregion

        #region protected

        protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void odsMemberKeyInOut_Selected(object sender, ObjectDataSourceStatusEventArgs e)
		{
			UCPager1.TotalPages = (Int32)e.OutputParameters["TotalPages"];
		}

		protected void UCPage1_Change(object sender, GWeb.AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadData();
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			LoadData();
		}

		/// <summary>
		/// 提出
		/// </summary>
		protected void btnKeyOut_Click(object sender, EventArgs e)
		{
			if (!IsValid)
			{
				return;
			}

            int QueryType = int.Parse(rblMember.SelectedValue);
            string QueryAccount = (QueryType == 0) ? txtMember.Text.Replace("%", "").Replace("_", "") : "";
            string QueryNickName = (QueryType == 2) ? txtMember.Text.Replace("%", "").Replace("_", "") : "";

            int MemberID = GetMemberID(QueryType, QueryAccount, QueryNickName);
            if (MemberID == -1)
            {
				ScriptManager.RegisterStartupScript(Page, GetType(), "alertMsg", "alert('查無此會員');", true);
                // WebUtility.ResponseScript(Page, "alert('查無此會員');", WebUtility.ResponseScriptPlace.NearFormEnd);
                return;
            }
			
            SqlParameter[] arParms =
			{
				new SqlParameter("@AgentID",AUser.AgentID),
                new SqlParameter("@GameAreaType", ddlGameAreaType.SelectedItem.Value),
				new SqlParameter("@MemberAccount", QueryAccount),
				new SqlParameter("@CellPhone",txtMobile.Text),
				new SqlParameter("@ChangePoints",0-decimal.Parse(txtPoints.Text)),
				new SqlParameter("@Reason",txtReason.Text),
				new SqlParameter("@NickName", QueryNickName)
			};

			string strResult = SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_BalancePoints", arParms).ToString();
            string strMessage = string.Empty;
			switch (strResult)
			{
 				case "0":
					strMessage = "提出成功";
					txtMember.Text = "";
					txtMobile.Text = "";
					txtPoints.Text = "";
					txtReason.Text = "";
					break;
				case "1":
					strMessage = "無此玩家";
					break;
				case "2":
					strMessage = "手機不正確";
					break;
				case "3":
					strMessage = "目前玩家正在遊戲中，請玩家離開遊戲";
					break;
				case "4":
					strMessage = "會員點數不足";
					break;
				case "5":
					strMessage = "此會員不可使用此幣別";
					break;
				default:
					strMessage = "資料處理錯誤";
					break;
			}
			ScriptManager.RegisterStartupScript(Page, GetType(), "alertMsg", "alert('" + strMessage + "');", true);
            // WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", WebUtility.ResponseScriptPlace.NearFormEnd);
            GameCommandHandler.LogoutMember(MemberID);
            this.LoadData();
        }

		/// <summary>
		/// 存入
		/// </summary>
		protected void btnKeyIn_Click(object sender, EventArgs e)
		{
			if (!IsValid)
			{
				return;
			}

            int QueryType = int.Parse(rblMember.SelectedValue);
            string QueryAccount = (QueryType == 0) ? txtMember.Text.Replace("%", "").Replace("_", "") : "";
            string QueryNickName = (QueryType == 2) ? txtMember.Text.Replace("%", "").Replace("_", "") : "";

            int MemberID = GetMemberID(QueryType, QueryAccount, QueryNickName);
            if (MemberID == -1)
            {
                WebUtility.ResponseScript(Page, "alert('查無此會員');", WebUtility.ResponseScriptPlace.NearFormEnd);
                return;
            }

			SqlParameter[] arParms =
			{
				new SqlParameter("@AgentID",AUser.AgentID),
                new SqlParameter("@GameAreaType", ddlGameAreaType.SelectedItem.Value),
				new SqlParameter("@MemberAccount",QueryAccount),
				new SqlParameter("@CellPhone",txtMobile.Text),
				new SqlParameter("@ChangePoints",decimal.Parse(txtPoints.Text)),
				new SqlParameter("@Reason",txtReason.Text),
				new SqlParameter("@NickName",QueryNickName)
			};
			
			string strResult = SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_BalancePoints", arParms).ToString();
			string strMessage = string.Empty;
			switch (strResult)
			{
				case "0":
					strMessage = "存入成功";
					txtMember.Text = "";
					txtMobile.Text = "";
					txtPoints.Text = "";
					txtReason.Text = "";	
					break;
				case "1":
					strMessage = "無此玩家";
					break;
				case "2":
					strMessage = "手機不正確";
					break;
				case "3":
					strMessage = "目前玩家正在遊戲中，請玩家離開遊戲";
					break;
				case "4":
					strMessage = "會員點數不足";
					break;
				case "5":
					strMessage = "此會員不可使用此幣別";
					break;
				default:
					strMessage = "資料處理錯誤";
					break;
			}
			
            WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", WebUtility.ResponseScriptPlace.NearFormEnd);
            GameCommandHandler.LogoutMember(MemberID);
            this.LoadData();
		}

		protected void grdMemberKeyInOut_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				switch (e.Row.Cells[5].Text)
				{
 					case "Deposit":
						e.Row.Cells[5].Text = GetGlobalResourceObject("Resources", "DepositResource").ToString();
						break;
					case "WithDraw":
						e.Row.Cells[5].Text = GetGlobalResourceObject("Resources", "WithDrawResource").ToString();
						break;
					
				}
			}
        }

        #endregion
    }
}