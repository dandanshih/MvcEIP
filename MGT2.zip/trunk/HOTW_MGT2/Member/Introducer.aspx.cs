﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class Introducer : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				//第一次進入時，disable所有欄位，並清除選取條件		
				foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
				{
					if (ctrlChild is TextBox)
					{
						TextBox textctrl = ctrlChild as TextBox;
						textctrl.Enabled = false;

					}
					if (ctrlChild is RadioButton)
					{
						RadioButton radioctrl = ctrlChild as RadioButton;
						radioctrl.Checked = false;
					}
				}
			}
		}

		/// <summary>
		/// 按下查詢按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQueryClick(object sender, EventArgs e)
		{
			if (txtAccount.Text.Contains("%"))
			{
				UCPager1.CurrentPageNumber = 1;
				LoadAccountData();
			}
			else
			{
				LoadIntroducerData(txtAccount.Text, txtNickName.Text);
			}
		}

		/// <summary>
		/// 按下模糊查詢中的帳號按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lkbListClick(object sender, EventArgs e)
		{
			this.LoadIntroducerData((sender as LinkButton).CommandArgument, string.Empty);
		}

		/// <summary>
		/// 載入帳號模糊查詢資料
		/// </summary>
		protected void LoadAccountData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@SearchStr",txtAccount.Text),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",UCPager1.PageSize),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};
			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			//arParms[arParms.Length - 2].Value = 25;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_SearchMemberAccount", arParms);

			gvFuzzySearch.DataSource = sdr;
			gvFuzzySearch.DataBind();
			sdr.Close();

			UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			UCPager1.DataBind();

			pnlFuzzy.Visible = true;
			pnlIntroducer.Visible = false;
			pnlDetail.Visible = false;
		}

		/// <summary>
		/// 以帳號載入上下三階介紹人資料
		/// </summary>
		protected void LoadIntroducerData(string strAccount, string strNickName)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount", strAccount),
				new SqlParameter("@NickName", strNickName)
			};


			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_IntroducerDynastyData", arParms);

			gv.DataSource = sdr;
			gv.DataBind();
			sdr.Close();

			
			pnlIntroducer.Visible = true;
			pnlDetail.Visible = false;
		}

		/// <summary>
		/// 載入指定階層的介紹人資料
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lkbDetailClick(object sender, EventArgs e)
		{
			LinkButton btn = sender as LinkButton;
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount",txtAccount.Text),
				new SqlParameter("@NickName", txtNickName.Text),
				new SqlParameter("@LV",btn.CommandArgument)
			};


			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_IntroducerDynastyDataDetail", arParms);

			gvDetail.DataSource = sdr;
			gvDetail.DataBind();
			sdr.Close();
			pnlDetail.Visible = true;
		}


		protected void gvRowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.DataItem == null)
				return;


			if(e.Row.Cells[1].Text.Equals("&nbsp;"))
			{
				e.Row.Cells[1].Text = "無";
			}
		}

		protected void PagerChange(object sender, EventArgs e)
		{
			this.LoadAccountData();
		}

		/// <summary>
		/// 選取條件時的動作
		/// <para>顯現相關的欄位，disable不相干的欄位，並清除欄位</para>
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void rb_CheckedChanged(object sender, EventArgs e)
		{
			RadioButton rb = sender as RadioButton;

			foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
			{
				if (ctrlChild is TextBox)
				{
					TextBox textctrl = ctrlChild as TextBox;
					textctrl.Text = string.Empty;
					textctrl.Enabled = textctrl.ID.Contains(rb.ID.Substring(2)) ? true : false;

				}
			}

		}
	}
}