﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
    public partial class KingCoolMember : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void gv_KingCoolCardList_DataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.DataItem == null)
            {
                return;
            }

            DataRowView item = (DataRowView)e.Row.DataItem;

            // 停用/啟用Button
            Button btn1 = (Button)e.Row.FindControl("btn_SetPause");
            btn1.Text = (item["PauseAccount"].ToString() == "1") ? "啟用" : "停用";
            btn1.CommandArgument = item["AgentAccount"].ToString();
            btn1.Attributes.Add("PauseAccount", item["PauseAccount"].ToString());

            // 修改Button
            Button btn2 = (Button)e.Row.FindControl("btn_Edit");
            btn2.CommandArgument = item["AgentAccount"].ToString();
        }

        protected void btn_SetPause_Command(object sender, CommandEventArgs e)
        {
            Button btn = (Button)sender;

            // 金庫序號
            string Account = e.CommandArgument.ToString();
            // 帳號是否停用
            string PauseAccount = btn.Attributes["PauseAccount"];

            SqlParameter[] param =
			{
                // 執行結果
				new SqlParameter("@Result",SqlDbType.SmallInt),
                // 金庫卡序號
				new SqlParameter("@Account", Account),
                // 目前登入帳號
				new SqlParameter("@ExecAccount", AUser.ExecAgentAccount),
                // 是否停用帳號
				new SqlParameter("@PauseAccount",(PauseAccount == "1") ? 0 : 1)
			};

            param[0].Direction = ParameterDirection.ReturnValue;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AgentAccountDisable",
                param
            );

            string Msg = string.Empty;
            switch (param[0].Value.ToString())
            {
                case "0":
                    gv_KingCoolCardList.DataBind();
                    break;
                case "1":
                    Msg = "帳號不存在";
                    break;
                case "2":
                    Msg = "該帳號已經被停權";
                    break;
            }
            
            if (!string.IsNullOrEmpty(Msg))
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "Message", string.Format("alert('{0}');", Msg), true);
            }
            else
            {
                // 如果帳號是由「啟用」轉「停用」, 則將帳號踢掉
                if (PauseAccount == "0")
                {
                    // 取得 AgentID
                    DataTable ObjDt = SqlHelper.ExecuteDataset
                    (
                        WebConfig.connectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_R_KingCoolCardGetOne",
                        new SqlParameter("@KingCoolCardNo", e.CommandArgument)
                    ).Tables[0];

                    if (ObjDt != null && ObjDt.Rows.Count != 0)
                    {
                        string AgentID = ObjDt.Rows[0]["AgentID"].ToString();

                        // 踢掉該帳號
                        Utility.KickAgentQueue.Add(int.Parse(AgentID));
                    }
                }
            }
        }

        protected void btn_Edit_Command(object sender, CommandEventArgs e)
        {
            Response.Redirect("~/Member/KingCoolMember_Edit.aspx?agentacc=" + e.CommandArgument);
        }

        protected void btn_Add_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Member/KingCoolMember_Add.aspx");
        }
    }
}