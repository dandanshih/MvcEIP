﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;
using System.Web.UI;

namespace GWeb.Member
{
	public partial class MemberBlackListHistory : GWeb.AppLibs.FormBase
	{
		private void SetBlackList(string memberAccount, int alarmType)
		{
			string strMessage = string.Empty;

			SqlParameter[] arParms2 =
			{
				new SqlParameter("@ExecAccount", AUser.AgentAccount),
				new SqlParameter("@MemberAccount", memberAccount),
				new SqlParameter("@AlarmType",alarmType),
				new SqlParameter("@RetrnValue", SqlDbType.SmallInt)
			};

			arParms2[arParms2.Length - 1].Direction = ParameterDirection.ReturnValue;

			try
			{
				SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_A_SetMemberAccountAlarmed", arParms2).ToString();
				if (arParms2[arParms2.Length - 1].Value.ToString().Equals("0"))
				{
					strMessage = "設定成功";
					LoadData();
				}
				else
				{
					strMessage = "設定失敗";
				}

			}
			catch (Exception ex)
			{
				strMessage = ex.Message;
			}

			GFC.Web.WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount",txtMemberAccount.Text),
				new SqlParameter("@NickName",txtNickName.Text),
                //new SqlParameter("@", ddl.SelectedValue),
				new SqlParameter("@StartDate",DateRange1.StartDate),
				new SqlParameter("@EndDate",DateRange1.EndDate),
				new SqlParameter("@PageSize",UCPager1.PageSize),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_MemberAlarmedHistory", arParms);

			gvBlacklist.DataSource = sdr;
			gvBlacklist.DataBind();
			sdr.Close();

			UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			UCPager1.DataBind();
		}

		protected void UCPage1_Change(object sender, GWeb.AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadData();
		}

		/// <summary>
		///  按下查詢紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			LoadData();
		}

		protected void gvBlacklist_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "SetBlacklist")
			{
				string memberAccount = e.CommandArgument.ToString().Split(',')[0];
				string alarmType = e.CommandArgument.ToString().Split(',')[1];

				if (alarmType != "0")
				{
					SetBlackList(memberAccount, 0);
				}
				else if (alarmType != "2")
				{
					SetBlackList(memberAccount, 2);
				}
			}
		}

		protected void RowDataBounded(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				AuthButton btnSetBlacklist = (AuthButton)e.Row.FindControl("btnSetBlacklist");

				if (DataBinder.Eval(e.Row.DataItem, "MemberAlarmType").ToString() != "0")
				{
					btnSetBlacklist.Text = "取消";
					btnSetBlacklist.OnClientClick = "return confirm('確定要取消黑名單');";
				}
				else if (DataBinder.Eval(e.Row.DataItem, "MemberAlarmType").ToString() != "2")
				{
					btnSetBlacklist.Text = "生效";
					btnSetBlacklist.OnClientClick = "return confirm('確定要加入黑名單');";
				}

				try
				{
					string[] sGameName = e.Row.Cells[10].Text.Replace(" ", "").Split(',');
					e.Row.Cells[10].Text = Utility.GetGameENameMapping(sGameName[0]).ToString();
					for (int i = 1; i < sGameName.Length; i++)
					{
						e.Row.Cells[10].Text += "," + Utility.GetGameENameMapping(sGameName[i]).ToString();
					}
				}
				catch { }
			}
		}
	}

}