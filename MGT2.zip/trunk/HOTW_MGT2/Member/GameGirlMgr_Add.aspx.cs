﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using System.Data.SqlClient;
using System.Data;
using GFC.Utilities;

namespace GWeb.Member
{
	public partial class GameGirlMgr_Add : FormBase
	{
		/// <summary>
		/// 取得比賽週期區間字串
		/// </summary>
		private string GetDurationTime(string DurationStartTime, string DurationMinutes)
		{
			int iDurationStartHour = int.Parse(DurationStartTime);
			int iDurationMinutes = int.Parse(DurationMinutes);
			DateTime dDurationStartTime = DateTime.Parse("9999/1/1 " + iDurationStartHour.ToString() + ":00:00");
			DateTime dDurationEndTime = dDurationStartTime.AddMinutes(iDurationMinutes);

			if (dDurationStartTime.Hour > dDurationEndTime.Hour || iDurationMinutes / 60 == 24)
			{
				return "(" + dDurationStartTime.ToString("HH:mm:ss") + " ～ 隔日" + dDurationEndTime.ToString("HH:mm:ss") + ")";
			}
			else
			{
				return "(" + dDurationStartTime.ToString("HH:mm:ss") + " ～ " + dDurationEndTime.ToString("HH:mm:ss") + ")";
			}
		}

		/// <summary>
		/// 顯示比賽週期區間在頁面上
		/// </summary>
		private void ShowDurationTime()
		{
			if (ddlDurationHours.SelectedValue == "24")
			{
				ddlDurationMinutes.SelectedIndex = 0;
				ddlDurationMinutes.Enabled = false;
			}
			else
			{
				ddlDurationMinutes.Enabled = true;
			}
			lblDurationTimeTip.Text = GetDurationTime(ddlDurationStartTime.SelectedValue, (int.Parse(ddlDurationHours.SelectedValue) * 60 + int.Parse(ddlDurationMinutes.SelectedValue)).ToString());
		}

		/// <summary>
		/// 驗證表單輸入資料
		/// </summary>
		private bool CheckFormData()
		{
			string ErrorMessage = string.Empty;
			DateTime DateStart = dpStaticDateStart.SelectedDate;
			DateTime DateEnd = dpStaticDateEnd.SelectedDate;
			int DurationTime = int.TryParse(ddlDurationStartTime.SelectedValue, out DurationTime) ? DurationTime : -1;
			int DurationHours = int.TryParse(ddlDurationHours.SelectedValue, out DurationHours) ? DurationHours : -1;

			// 比賽日期驗證
			if (DateStart.Year < 2009 || DateEnd.Year < 2009)
			{
				ErrorMessage = "比賽日期錯誤!";
			}
			else if (DateEnd.Subtract(DateStart).Days < 0)
			{
				ErrorMessage = "開始日期不得大於結束日期!";
			}
			// 開始時間驗證
			else if (DurationTime == -1 || DurationTime > 23 || DurationTime < 0)
			{
				ErrorMessage = "開始時間錯誤!";
			}
			// 持續時間驗證
			else if (DurationHours == -1)
			{
				ErrorMessage = "持續時間錯誤!";
			}
			// 循環週期驗證
			else if (cblWeekDays.SelectedItem == null)
			{
				ErrorMessage = "請勾選星期!";
			}

			if (!string.IsNullOrEmpty(ErrorMessage))
			{
				ScriptManager.RegisterStartupScript(Page, GetType(), "Error", string.Format("alert('{0}');", ErrorMessage), true);
				return false;
			}

			return true;
		}

		/// <summary>
		/// 新增比賽
		/// </summary>
		private bool AddGameGirlScheduling()
		{

			// 取得循環週期
			string WeekItem = string.Empty;
			foreach (ListItem li in cblWeekDays.Items)
			{
				if (li.Selected)
				{
					WeekItem += li.Value;
				}
			}

			SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@Result", SqlDbType.Int),
				new SqlParameter("@GameGirlID", Request.QueryString["pgid"]),
                new SqlParameter("@StaticDateStart", dpStaticDateStart.SelectedDate.ToString("yyyy/MM/dd")),
                new SqlParameter("@StaticDateEnd", dpStaticDateEnd.SelectedDate.ToString("yyyy/MM/dd")),
                new SqlParameter("@WeekDays", WeekItem),
                new SqlParameter("@DurationStartTime", string.Format("{0}:00:00",ddlDurationStartTime.SelectedValue)),
                new SqlParameter("@DurationMinute", int.Parse(ddlDurationHours.SelectedValue) * 60 + int.Parse(ddlDurationMinutes.SelectedValue)),
                new SqlParameter("@Executor", AUser.AgentID)
            };
			param[0].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_GameGirlScheduling_Add",
				param
			);

			int result = Convert.ToInt32(param[0].Value);
			string Msg = string.Empty;
			bool IsSuccess = false;

			switch (result)
			{
				case 0:
					Msg = "新增成功";
					IsSuccess = true;
					break;
				case 1:
					Msg = "該時段已經有相同的排班表了";
					break;
				case 2:
					Msg = "排班時間不可小於目前時間";
					break;
				case 3:
					Msg = "排班結束日時不可小於起始日時";
					break;
				case 4:
					Msg = "排班重複";
					break;
				default:
					Msg = "新增失敗";
					break;
			}

			ScriptManager.RegisterStartupScript(Page, GetType(), "Message", string.Format("alert('{0}');", Msg), true);
			return IsSuccess;
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if(string.IsNullOrEmpty(Request.QueryString["pgid"]))
			{
				Response.Redirect("GameGirlMgr.aspx");
			}
			if (!IsPostBack)
			{
				dpStaticDateStart.VisibleDate = DateTime.Now;
				dpStaticDateEnd.VisibleDate = DateTime.Now;

				for (int i = 0; i < 60; i++)
				{
					ddlDurationMinutes.Items.Add(i.ToString("d2"));
				}

				ShowDurationTime();
			}
		}

		protected void btn_Add_Click(object sender, EventArgs e)
		{
			// 驗證表單輸入資料的正確性
			if (!CheckFormData())
			{
				return;
			}

			// 新增比賽成功就重新 Bind 資料
			if (AddGameGirlScheduling())
			{
				Response.Redirect("GameGirlMgr.aspx");
			}
		}

		protected void ddlDurationStartTime_SelectedIndexChanged(object sender, EventArgs e)
		{
			ShowDurationTime();
		}

		protected void ddlDurationHours_SelectedIndexChanged(object sender, EventArgs e)
		{
			ShowDurationTime();
		}

	}
}