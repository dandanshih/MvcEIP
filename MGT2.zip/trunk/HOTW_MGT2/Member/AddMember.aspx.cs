﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;


namespace GWeb.Member
{
	public partial class AddMember : GWeb.AppLibs.FormBase
	{
		#region 頁面初始設定

		/// <summary>
		/// 設置表單控制項
		/// </summary>
		private void SetForm()
		{
			#region 密碼欄位的設置
			if (Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxLoginPassword.Text).Length > 0)
			{
				tbxLoginPassword.Attributes.Add("value", Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxLoginPassword.Text));
			}
			else
			{
				tbxLoginPassword.Attributes.Add("value", "");
			}

			if (Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxConfirmPassword.Text).Length > 0)
			{
				tbxConfirmPassword.Attributes.Add("value", Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxConfirmPassword.Text));
			}
			else
			{
				tbxConfirmPassword.Attributes.Add("value", "");
			}
			#endregion 密碼欄位的設置

			#region 生日下拉選單設置
			// 如果生日選單沒資料就產生下拉選單
			if (ddlBirthYear.Items.Count == 0)
			{
				// 產生生日下拉選單 
				for (int i = DateTime.Now.Year - 100; i < DateTime.Now.Year - 7; i++)
				{
					ListItem li = new ListItem(i.ToString(), i.ToString());
					// 預設在 30 歲
					if (DateTime.Now.Year - i == 30)
						li.Selected = true;

					ddlBirthYear.Items.Add(li);
				}
				for (int i = 1; i <= 12; i++)
				{
					ddlBirthMonth.Items.Add(new ListItem(i.ToString(), i.ToString()));
				}
				for (int i = 1; i <= 31; i++)
				{
					ddlBirthDay.Items.Add(new ListItem(i.ToString(), i.ToString()));
				}
			}
			#endregion 生日下拉選單設置

			// 紅利回饋人 2011/09/07 後才出現
			//if (DateTime.Now < DateTime.Parse("2011-09-07 00:00:00"))
			//{
			//    trIntroducer.Visible = false;
			//}
		}

		#endregion

		#region 單一項目驗證

		/// <summary>
		/// 檢查密碼的格式是否正確
		/// </summary>
		/// <param name="passWord">要檢查的密碼字串</param>
		/// <param name="invalidText">要傳回的錯誤訊息</param>
		protected bool IsValidRegular_MemberPassword(string passWord, out string invalidText)
		{
			passWord = passWord.Trim().Replace(" ", "");
			invalidText = "";

			int iTmp = 0;
			string sTmp = "";
			if (rblMemberIdentity.SelectedValue != "99")
			{
				if (int.TryParse(passWord, out iTmp))
				{
					invalidText = "密碼至少須包含一個英文字母";
					return false;
				}

				if (passWord.Length < 6 || passWord.Length > 12)
				{
					invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
					return false;
				}

				iTmp = 0;
				for (int i = 0; i < passWord.Length; i++)
				{
					int code = passWord[i];
					if (sTmp.IndexOf(passWord[i]) == -1)
					{ // 把不同的文字加進暫存變數, 等下要判斷有幾種字元
						sTmp += passWord[i].ToString();
					}
					if (!((code >= 48 && code <= 57) || (code >= 65 && code <= 90) || (code >= 97 && code <= 122)))
					{
						invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
						return false;
					}

					// 如果往後的 3 個字元都是連續字元(例如 123、abc、321、cba、..), 就傳出錯誤
					if (passWord.Length - i > 2 &&
							(
							passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
														+ Convert.ToChar(code + 1).ToString()
														+ Convert.ToChar(code + 2).ToString())
								||
							 passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
														+ Convert.ToChar(code - 1).ToString()
														+ Convert.ToChar(code - 2).ToString())
							))
					{
						invalidText = "密碼不可包含 3 個連續數字或 3 個連續字母";
						return false;
					}
				}
				if (sTmp.Length < 4)
				{
					invalidText = "密碼必須包含 4 種字元以上";
					return false;
				}
			}
			return true;

		}

		/// <summary>
		/// 驗證暱稱是否重複。
		/// </summary>
		private string ValidateDoubleNickName()
		{
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@CheckType", 2),
                new SqlParameter("@CheckData",tbxNickName.Text.ToSafeString())
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_A_Member_CheckDuplicateAccount",
														   param);

			string message = "";
			int result = 0;

			if (objDtr.Read())
			{
				result = int.Parse(objDtr["Result"].ToString());
			}

			objDtr.Close();

			switch (result)
			{
				case 0:
					message = string.Empty;
					break;
				case 11:
				case 12:
					message = "此暱稱已有人使用，請改用其他暱稱;";
					break;
				case 13:
					message = "此暱稱正在等待驗證中，目前無法使用此暱稱!";
					break;
				default:
					message = "此暱稱無法使用!";
					break;
			}

			return message;
		}

		/// <summary>
		/// 驗證資料是否重複。
		/// </summary>
		/// <param name="CheckType">驗證類別</param>
		/// <param name="CheckDate">要驗證的資料</param>
		private bool ValidateData(string CheckType, string CheckDate)
		{
			/* @CheckType
			 *		1: 帳號
			 *		2: 暱稱
			 *		3. 手機
			 *		4. 介紹人暱稱
			 */
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@CheckType", CheckType)
				, new SqlParameter("@CheckData", CheckDate),
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_CheckDuplicateAccount",
				param
			);

			int result = 0;

			if (objDtr.Read())
			{
				result = int.Parse(objDtr["Result"].ToString());
			}

			objDtr.Close();

			if (result == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		#endregion

		#region 總驗證

		/// <summary>
		/// 驗證基本資料頁表單
		/// </summary>
		private bool ValidMemberForm(out string errorMessage)
		{
			errorMessage = "";
			string tmp = "";

			// 將送出按鈕還原為可點選狀態
			btnView2_ToView3.Enabled = true;
			tbxCustName.Text = tbxCustName.Text.Trim();
			tbxLoginID.Text = tbxLoginID.Text.Trim().Replace(" ", "");
			tbxLoginPassword.Text = tbxLoginPassword.Text.Trim().Replace(" ", "");
			tbxEMail.Text = tbxEMail.Text.Trim().Replace(" ", "");
			tbxTelMobile.Text = tbxTelMobile.Text.Trim().Replace(" ", "");
			tbxNickName.Text = tbxNickName.Text.Trim();

			if (rblMemberIdentity.SelectedIndex == -1)
			{
				errorMessage = "請選擇會員別";
				return false;
			}

			#region 登入帳號
			tmp = tbxLoginID.Text;
			if (tmp.Trim() == "")
			{
				errorMessage = "帳號不可空白";
				return false;
			}
			else if (tmp.Length < 6 || tmp.Length > 12
				|| !System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9a-zA-Z]*$"))
			{

				errorMessage = "必須是 6 ~ 12 碼的英文數字組合";
				return false;
			}
			//else if (int.TryParse(tmp, out iTmp))
			//{

			//    errorMessage = "帳號至少須包含一個英文字母";
			//    return false;
			//}
			else if (System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9]*$"))
			{
				errorMessage = "帳號至少須包含一個英文字母";
				return false;
			}
			else if (tbxTelMobile.Text.Length > 0 && tbxLoginID.Text.IndexOf(tbxTelMobile.Text) > -1)
			{

				errorMessage = "帳號中不可包含您的手機號碼";
				return false;
			}
            //else if (tbxEMail.Text.IsEMail() && tbxLoginID.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1)
            //{
            //    errorMessage = "帳號中不可包含您的EMail";
            //    return false;
            //}
			#endregion

			#region 設定密碼
			if (tbxLoginPassword.Text == "")
			{
				errorMessage = "密碼不可空白";
				return false;
			}
			else if (!IsValidRegular_MemberPassword(tbxLoginPassword.Text.ToUpper(), out errorMessage))
			{
				return false;
			}
			else if ((tbxLoginID.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxLoginID.Text) > -1)
				|| (tbxTelMobile.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxTelMobile.Text) > -1)
				|| (tbxNickName.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxNickName.Text) > -1)
				|| (tbxEMail.Text.IsEMail() && tbxLoginPassword.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1))
			{
				if (rblMemberIdentity.SelectedValue != "99")
				{
					errorMessage = "密碼中不可包含帳號、手機號碼、暱稱或EMail";
					return false;
				}
			}
			#endregion

			#region 確認密碼
			if (tbxConfirmPassword.Text.Trim() == "")
			{
				errorMessage = "確認密碼不可空白";
				return false;
			}
			else if (tbxConfirmPassword.Text != tbxLoginPassword.Text)
			{
				errorMessage = "與上面的密碼不相同";
				return false;
			}
			#endregion
			ViewState["tbxLoginPassword"] = tbxLoginPassword.Text.ToSafeString();
			ViewState["tbxConfirmPassword"] = tbxConfirmPassword.Text.ToSafeString();

			#region 訂閱訊息&信箱 (非必填)

			if (cbxIsJoinAdv.Checked && tbxEMail.Text == "")
			{
				errorMessage = "您選擇了接收最新活動消息，請填寫E-Mail以利寄送";
				return false;
			}

			if (tbxEMail.Text.Trim().Length > 0 && !tbxEMail.Text.IsEMail())
			{
				errorMessage = "E-Mail格式錯誤";
				return false;
			}

			#endregion

			#region 姓名 (已取消)
			//if (tbxCustName.Text == "")
			//{
			//    errorMessage = "姓名不可空白";
			//    return false;
			//}
			#endregion

			#region 暱稱

			if (tbxNickName.Text.Trim().Length == 0)
			{
				errorMessage = "請輸入暱稱";
				return false;
			}
			//else if (tbxNickName.Text.Contains(",") || tbxNickName.Text.Contains("&") || tbxNickName.Text.Contains("|") || tbxNickName.Text.Contains("^") || tbxNickName.Text.Contains(" ")) {
			//    errorMessage = "暱稱不能包含特殊符號!";
			//    return false;
			//}
			//if (!ValidateData("2", tbxNickName.Text)) {
			//    errorMessage = "暱稱重複!";
			//    return false;
			//}
			//if (tbxNickName.Text == "")
			//{				
			//    errorMessage = "暱稱不可空白";
			//    return false;
			//}
			if ((tbxLoginID.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxLoginID.Text) > -1)
					|| (tbxTelMobile.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxTelMobile.Text) > -1))
			{
				errorMessage = "暱稱中不可包含帳號或手機號碼";
				return false;
			}

			// 暱稱中不可包含逗點
			if (!System.Text.RegularExpressions.Regex.IsMatch(tbxNickName.Text, "^[A-Za-z0-9\u4E00-\u9FA5\uF900-\uFA2D]+$"))
			{
				errorMessage = "玩家暱稱不能包含特殊符號";
				return false;
			}

			// 暱稱字數檢查
			if (tbxNickName.Text.Trim().Length > 10)
			{
				errorMessage = "暱稱請輸入10個中英文或數字";
				return false;
			}
			//int intNickNameLength = 0;
			//foreach (char c in tbxNickName.Text)
			//{
			//    if (c >= 0x3000 && c <= 0x9fff)
			//    {
			//        intNickNameLength += 2;
			//    }
			//    else
			//    {
			//        intNickNameLength += 1;
			//    }
			//}
			//if (intNickNameLength > 10)
			//{
			//    errorMessage = "暱稱請輸入10個中英文或數字";
			//    return false;
			//}
			//檢查暱稱是否被使用
			errorMessage = ValidateDoubleNickName();
			if (errorMessage.Length != 0)
			{
				return false;
			}
			#endregion

			#region 出生年月日

			if (!(ddlBirthYear.Text + "/" + ddlBirthMonth.Text + "/" + ddlBirthDay.Text).IsDate())
			{
				errorMessage = "出生日期錯誤";
				return false;
			}

			#endregion

			#region 身份證或護照後四碼 (取消)

			//if (tbxCustPID.Text.Trim().Length == 0)
			//{
			//    errorMessage = "身分證末四碼不可空白";
			//    return false;
			//}

			//if (tbxCustPID.Text.Trim().Length != 4)
			//{
			//    errorMessage = "請填寫末四碼";
			//    return false;
			//}

			#endregion

			#region 聯絡電話 (非必填)

			if (tbxTelHome.Text.Trim() != "")
			{
				tmp = tbxTelHome.Text.Trim();
				if (!(tmp.IsNumeric() && tmp.Length > 8 && tmp.Length < 11 && tmp.Substring(0, 1) == "0"))
				{
					errorMessage = "聯絡電話不正確";
					return false;
				}
			}

			#endregion

			#region 手機

			tmp = tbxTelMobile.Text.Trim();
			//if (tmp.Length == 0)
			//{
			//    errorMessage = "手機不可空白";
			//    return false;
			//}
			if ((rblMemberIdentity.SelectedValue == "2" || rblMemberIdentity.SelectedValue == "99") && string.IsNullOrEmpty(tmp))
			{
				errorMessage = "選取的會員類型手機為必填欄位";
				return false;
			}

			if (tmp.Length > 0)
			{
				if (!(tmp.IsNumeric() && tmp.Length == 10 && tmp.Substring(0, 2) == "09"))
				{
					errorMessage = "手機格式錯誤";
					return false;
				}
			}

			#endregion

			#region 發票

			// 選擇索取發票
			if (rbl_InVoice_Type.SelectedValue == "2")
			{
				// 檢查發票地址
				if (string.IsNullOrEmpty(UCAddress2.Address))
				{
					errorMessage = "請輸入發票地址";
					return false;
				}

				// 檢查發票收件人
				if (string.IsNullOrEmpty(txt_Invoice_Recipient.Text))
				{
					errorMessage = "請輸入發票收件人";
					return false;
				}
			}
			else if (rbl_InVoice_Type.SelectedValue == "1")
			{
				// 檢查Email
				if (string.IsNullOrEmpty(tbxEMail.Text))
				{
					errorMessage = "請輸入Email";
					return false;
				}

				// 檢查姓名
				if (string.IsNullOrEmpty(tbxCustName.Text))
				{
					errorMessage = "請輸入姓名";
					return false;
				}
			}

			#endregion

			return true;
		}

		#endregion

		#region 控制項事件

		protected void Page_Load(object sender, EventArgs e)
		{
			SetForm();
			#region 測試用
			if (!IsPostBack)
			{
#if Debug
                tbxLoginID.Text = "2147483647";
                tbxLoginPassword.Text = "1qaz2wsx";
                tbxEMail.Text = "bbb56789@hotmail.com";
                tbxCustName.Text = "我是姓名";
                tbxNickName.Text = "我是暱稱";
                ddlBirthYear.Text = "1980";
                ddlBirthMonth.Text = "9";
                ddlBirthDay.Text = "1";
                //tbxCustPID.Text = "1234";
                rblUserSex.Items[1].Selected = true;
                tbxTelHome.Text = "0958777456";
                tbxTelMobile.Text = "0987444587";
				UCAddress1.CityID = 0;
				// UCAddress1.ZoneID = "0";
				UCAddress1.Address = "我是地址";
                rbl_InVoice_Type.SelectedValue = "小姐";
				UCAddress2.CityID = 0;
				// UCAddress2.ZoneID = "0";
				UCAddress2.Address = "我是地址";
                txt_Invoice_Recipient.Text = "我是發票收件人";
                rbl_InVoice_Type.SelectedValue = "2";
                // txtIntroducer.Text = "aaa123";
#endif
			}
			#endregion 測試用
		}

		/// <summary>
		/// 檢查帳號是否重複
		/// </summary>
		protected void btnCheckDupeAccount_Click(object sender, EventArgs e)
		{
			tbxLoginID.Text = tbxLoginID.Text.Trim();
			string tmp = tbxLoginID.Text;
			if (tmp.Trim() == "")
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('帳號錯誤: 不可空白!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			else if (tmp.Length < 6 || tmp.Length > 12
				|| !System.Text.RegularExpressions.Regex.IsMatch(tbxLoginID.Text, "^[0-9a-zA-Z]*$"))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('帳號字元範圍[0-9, A-Z, a-z]，並至少輸入6個以上的字元!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			object ReturnValue = SqlHelper.ExecuteScalar
			(
				WebConfig.connectionString, 
				CommandType.StoredProcedure, 
				"NSP_AgentWeb_A_Member_CheckDuplicateAccount", 
				new SqlParameter("@CheckType", "1"),
				new SqlParameter("@CheckData",tbxLoginID.Text)
			);

			int chkResult = 99;
			if (ReturnValue != null)
			{
				chkResult = int.TryParse(ReturnValue.ToString(), out chkResult) ? chkResult : -1;
			}

			switch (chkResult)
			{
				case 0:
					GFC.Web.WebUtility.ResponseScript(Page, "alert('此帳號可以使用!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					break;
				case 1:
					//case 12:
					GFC.Web.WebUtility.ResponseScript(Page, "alert('此帳號已有人使用，請改用其他帳號!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					break;
				//case 13:
				//    WebUtility.ResponseScript(Page,"alert('此帳號正在等待驗證中，目前無法使用此帳號!');", WebUtility.ResponseScriptPlace.NearFormEnd);
				//    break;
				default:
					GFC.Web.WebUtility.ResponseScript(Page, "alert('此帳號無法使用!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					break;
			}

		}

		/// <summary>
		/// 檢查暱稱是否重複
		/// </summary>
		protected void btnNickName_Click(object sender, EventArgs e)
		{
			//if (tbxNickName.Text.Trim().Length == 0)
			//{
			//    WebUtility.ResponseScript(Page, "alert('請輸入暱稱!');", WebUtility.ResponseScriptPlace.NearFormEnd);
			//    return;
			//}

			if (tbxNickName.Text.Contains(",") || tbxNickName.Text.Contains("&") || tbxNickName.Text.Contains("|") || tbxNickName.Text.Contains("^") || tbxNickName.Text.Contains(" "))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('暱稱不能包含特殊符號!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			if (!ValidateData("2", tbxNickName.Text))
			{
				//WebUtility.ResponseScript(Page, "alert('此暱稱已有人使用')", WebUtility.ResponseScriptPlace.NearFormEnd);
				GFC.Web.WebUtility.ResponseScript(Page, "alert('暱稱重複!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertUse", "alert('暱稱重複');", true);
				return;
			}
			else
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('暱稱未重複')", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
		}

		/// <summary>
		/// 檢查手機是否正確
		/// </summary>
		protected void btnCheckTel_Click(object sender, EventArgs e)
		{
			string tmp = tbxTelMobile.Text.Trim();
			if (tmp.Length == 0)
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('請輸入手機號碼!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertLength", "alert('請輸入手機號碼');", true);
				return;
			}
			if (!(tmp.IsNumeric() && tmp.Length == 10 && tmp.Substring(0, 2) == "09"))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('手機格式錯誤!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('手機格式錯誤');", true);
				return;
			}
			if (!ValidateData("3", tbxTelMobile.Text))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('此號碼已使用過!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertN", "alert('此號碼已使用超過6次');", true);
				return;
			}
			else
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('此號碼可以使用!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertY", "alert('此號碼可以使用');", true);
				return;
			}
		}

		/// <summary>
		/// 檢查推薦人是否存在
		/// </summary>
		protected void btnCheckReferee_Click(object sender, EventArgs e)
		{
			if (txtIntroducer.Text.Trim().Length == 0)
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('請輸入推薦人暱稱!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertLength", "alert('請輸入推薦人暱稱');", true);
				return;
			}
			if (!ValidateData("4", txtIntroducer.Text))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('無此會員!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertNoUser", "alert('無此會員');", true);
				return;
			}
			else
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('有此會員!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				//ScriptManager.RegisterStartupScript(Page, GetType(), "alertUser", "alert('有此會員');", true);
				return;
			}
		}

		/// <summary>
		/// 新增會員。
		/// </summary>
		private int AddNewMember()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@MemberAccount", tbxLoginID.Text.ToSafeString().Trim()),
				new SqlParameter("@MemberPassword", tbxLoginPassword.Text.ToSafeString().Trim()),
				new SqlParameter("@RealName", tbxCustName.Text.ToSafeString().Trim()),
				new SqlParameter("@NickName", tbxNickName.Text.ToSafeString().Trim()),
				new SqlParameter("@Email", tbxEMail.Text.ToSafeString().Trim()),
				new SqlParameter("@Birthday", DateTime.Parse(ddlBirthYear.Text + "-" + ddlBirthMonth.Text + "-" + ddlBirthDay.Text)),
				new SqlParameter("@Phone", tbxTelHome.Text.ToSafeString().Trim()),
				new SqlParameter("@Mobile", tbxTelMobile.Text.ToSafeString().Trim()),
				new SqlParameter("@IdPassport", ""),
				new SqlParameter("@Gender", (rblUserSex.Items[0].Selected) ? 1 : 0),
				new SqlParameter("@ZoneID", UCAddress1.ZoneID),
				new SqlParameter("@Address", UCAddress1.Address.ToSafeString()),
				new SqlParameter("@NewsYN", cbxIsJoinAdv.Checked ? 1 : 0),
				new SqlParameter("@Invoice_Type", int.Parse(rbl_InVoice_Type.SelectedValue)),
				new SqlParameter("@Invoice_ZoneID", UCAddress2.ZoneID),
				new SqlParameter("@Invoice_Address", UCAddress2.Address.ToSafeString()),
				new SqlParameter("@Invoice_Recipient", txt_Invoice_Recipient.Text),
				new SqlParameter("@IntroducerNickName", txtIntroducer.Text),
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID),
				new SqlParameter("@MemberIdentity", rblMemberIdentity.SelectedItem.Value)
			};
			

			int resultCode = 0;

			try
			{
				resultCode = Convert.ToInt16(SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_New", param));
			}
			catch (Exception ex)
			{
				throw ex;
			}

			return resultCode;
		}

		/// <summary>
		/// 儲存會員基本資料表單
		/// </summary>
		protected void btnSaveMemberForm_Click(object sender, EventArgs e)
		{
			//欄位驗證不過就離開
			string ResultValidForm = string.Empty;
			if (!ValidMemberForm(out ResultValidForm))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('" + ResultValidForm + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			string strResult = string.Empty;

			int resultCode = AddNewMember();

			switch (resultCode)
			{
				case 0:
					strResult = "帳號建立成功";
					break;
				case 1:
					strResult = "帳號已存在";
					break;
				case 2:
					strResult = "此手機已申請過無法再使用";
					break;
				case 3:
                    strResult = "推薦人不存在";
					break;
				case 4:
                    strResult = "推薦人不可填自己";
					break;
				case 5:
					strResult = "系統錯誤";
					break;
				case 6:
					strResult = "暱稱重複";
					break;
				case 7:
					strResult = "推薦人不為老幣會員或未完成認證";
					break;
				case 8:
					strResult = "推薦人停權中";
					break;
				default:
					strResult = "帳號建立時發生錯誤，請稍候再執行一次，或請洽客服中心";
					break;
			}
			strResult = "alert('" + strResult + "');";
			if (resultCode == 0)
			{
				strResult += "location.href='MemberQuery.aspx';";

			}

			GFC.Web.WebUtility.ResponseScript(Page, strResult, GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);

			#region 舊程式碼
			// 發送驗證碼簡訊
			//string strSMSMsg = "歡迎加入" + this.Config.Global.ProjectDescription + "會員.您的驗證碼為" + strSMSValidationCode + "請立即啟用!";
			//SendSMS(tbxTelMobile.Text, strSMSMsg, SMSRequestTypes.NewMemberAuth, intMemberID.ToString());



			// 先將帳號碼存至 Session, 因為稍候要轉到帳號啟用頁時, 需要用此帳號來一起驗證簡訊驗證碼
			//this.AUser.LoginID = tbxLoginID.Text;
			//this.AUser.LoginPassword = ViewState["tbxLoginPassword"].ToString().ToSafeString();

			// 20090917#B03# Phil: 封測配合使用Gamebase通行碼. 活動結束可刪除
			//UpdateGamebasePassword(intMemberID, tbxLoginID.Text.ToSafeString());
			// 20090917#B03# End

			// 轉址到帳號啟用頁
			//ResponseScript("self.location='MobileAuth.aspx';", ResponseScriptPlace.NearFormEnd);
			//Response.Redirect("MobileAuth.aspx", true);



			#endregion 舊程式碼
		}

		/// <summary>
		/// 關閉紐
		/// </summary>
		protected void btnClose_Click(object sender, EventArgs e)
		{
			Response.Redirect("MemberQuery.aspx");
		}

		protected void rblMemberIdentity_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (rblMemberIdentity.SelectedValue == "99")
			{
				txtIntroducer.Text = "";
				trIntroducer.Visible = false;
			}
			else
			{
				trIntroducer.Visible = true;
			}
		}

		#endregion

		#region old data
		///// <summary>
		///// 重設基本資料表單
		///// </summary>
		//protected void btnMemberFormReset_Click(object sender, EventArgs e)
		//{

		//    tbxLoginID.Text = "";
		//    tbxLoginPassword.Text = "";
		//    tbxConfirmPassword.Text = "";
		//    tbxEMail.Text = "";
		//    tbxCustName.Text = "";
		//    tbxNickName.Text = "";
		//    tbxCustPID.Text = "";
		//    tbxTelHome.Text = "";
		//    tbxTelMobile.Text = "";
		//    tbxAddr.Text = "";
		//    txtIntroducer.Text = string.Empty;

		//    ddlBirthDay.ClearSelection();
		//    ddlBirthMonth.ClearSelection();
		//    ddlBirthYear.ClearSelection();
		//    ddlCity.ClearSelection();
		//    ddlBirthYear.SelectedValue = (DateTime.Now.Year - 30).ToString();

		//    tbxLoginPassword.Attributes["value"] = "";
		//    tbxConfirmPassword.Attributes["value"] = "";
		//    cbxIsJoinAdv.Checked = true;
		//}
		#endregion
	}
}