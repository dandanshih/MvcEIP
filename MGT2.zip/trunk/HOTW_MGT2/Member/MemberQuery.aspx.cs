﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;
using GFC;

namespace GWeb.Member
{
	public partial class MemberQuery : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{

				//第一次進入時，disable所有欄位，並清除選取條件		
				foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
				{
					if (ctrlChild is TextBox)
					{
						TextBox textctrl = ctrlChild as TextBox;
						textctrl.Enabled = false;

					}
					if (ctrlChild is RadioButton)
					{
						RadioButton radioctrl = ctrlChild as RadioButton;
						radioctrl.Checked = false;
					}
				}

				pnlDetail.Visible = false;
				Form.DefaultButton = btnQuery.UniqueID;
			}



			//btnQuery.Focus();
		}

		#region 搜尋條件區的控制
		/// <summary>
		/// 選取條件時的動作
		/// <para>顯現相關的欄位，disable不相干的欄位，並清除欄位</para>
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void rb_CheckedChanged(object sender, EventArgs e)
		{
			RadioButton rb = sender as RadioButton;

			foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
			{
				if (ctrlChild is TextBox)
				{
					TextBox textctrl = ctrlChild as TextBox;
					textctrl.Text = string.Empty;
					textctrl.Enabled = textctrl.ID.Contains(rb.ID.Substring(2)) ? true : false;

				}
			}

		}
		/// <summary>
		/// 檢查是否有填寫搜尋條件
		/// </summary>
		/// <returns></returns>
		protected bool chkIsHaveColumn()
		{
			bool yn = false;
			foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
			{

				if (ctrlChild is TextBox)
				{
					TextBox textctrl = ctrlChild as TextBox;

					if (textctrl.Text.Trim().Replace("%", "").Length < 2 && textctrl.Text.Contains("%"))
					{
						yn = false;
						WebUtility.ResponseScript(Page, "alert('" + "請至少輸入2個字元" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					}
					else if (textctrl.Text.Trim().Length != 0)
					{
						yn = true;
					}
				}
			}

			if (!yn)
			{
				WebUtility.ResponseScript(Page, "alert('" + "請選擇填寫一項搜尋條件" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}

			return yn;
		}
		/// <summary>
		/// 按下會員查詢紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			pnlDetail.Visible = false;
			pnlMobileGroupList.Visible = false;
			pnlTransAcct.Visible = false;
			if (!chkIsHaveColumn())
			{
				return;
			}
			if (!IsValid)
			{
				return;
			}
			UCPager1.CurrentPageNumber = 1;
			UCPager1.CurrentPageNumber = 1;


			UCPager2.CurrentPageNumber = 1;

			LoadData();
		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{

			int Condiction = 0;
			string strParamterName = string.Empty;
			string strParamterValue = string.Empty;

			foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
			{

				if (ctrlChild is RadioButton)
				{
					RadioButton radioctrl = ctrlChild as RadioButton;

					if (!radioctrl.Checked)
						continue;

					switch (radioctrl.ID)
					{
						case "rbMemberAccount":
							Condiction = 0;
							strParamterName = "@MemberAccount";
							strParamterValue = txtMemberAccount.Text;
							break;
						case "rbMemberID":
							Condiction = 1;
							strParamterName = "@MemberID";
							strParamterValue = txtMemberID.Text;
							break;
						case "rbNickName":
							Condiction = 2;
							strParamterName = "@NickName";
							strParamterValue = txtNickName.Text;
							break;
						case "rbMobile":
							Condiction = 3;
							strParamterName = "@Mobile";
							strParamterValue = txtMobile.Text;
							break;
						case "rbEMail":
							Condiction = 4;
							strParamterName = "@EMail";
							strParamterValue = txtEMail.Text;
							break;
					}
				}
			}

			SqlParameter[] arParms =
			{
				new SqlParameter("@QueryType", Condiction),
				new SqlParameter(strParamterName,strParamterValue),
				new SqlParameter("@Result",SqlDbType.TinyInt),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",SqlDbType.Int),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			arParms[arParms.Length - 2].Value = UCPager1.PageSize;
			arParms[arParms.Length - 4].Direction = ParameterDirection.Output;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_List", arParms);

			grdMemberList.DataSource = sdr;
			grdMemberList.DataBind();
			sdr.Close();

			UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			UCPager1.DataBind();

			pnlDetail.Visible = false;


		}

		protected void Pager_Change(object sender, EventArgs e)
		{
			pnlMobileGroupList.Visible = false;
			this.LoadData();
		}

		#endregion 搜尋條件區的控制


		/// <summary>
		/// 按下搜尋結果中的會員帳號
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		//protected void lbMemberAccount_Click(object sender, EventArgs e)
		//{
		//    LinkButton lbk = sender as LinkButton;
		//    MemberQueryDetail d = new MemberDAO().GetMemberDetail(Int32.Parse(lbk.CommandArgument));

		//    SetMemberDetailDataLoad(d);

		//    pnlDetail.Visible = true;
		//}

		/// <summary>
		/// 按下搜尋結果中的會員帳號
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void grdMemberList_RowCommand(object sender, GridViewCommandEventArgs e)
		{

			if (e.CommandName.ToString() == "GetDetails")
			{
				// MemberQueryDetail d = new MemberDAO().GetMemberDetail(Int32.Parse(e.CommandArgument.ToString()));
				SetMemberDetailDataLoad(int.Parse(e.CommandArgument.ToString()));
				pnlDetail.Visible = true;
				pnlMobileGroupList.Visible = false;
			}
			else if (e.CommandName.ToString() == "TransAcct")
			{
				int m_Index = int.Parse(e.CommandArgument.ToString());
				string m_MemberID = grdMemberList.DataKeys[m_Index].Values["MemberID"].ToString().Trim();
				lblTransMemberNickName.Text = grdMemberList.DataKeys[m_Index].Values["NickName"].ToString().Trim();
				ViewState["A101_TransMemberID"] = m_MemberID;
				pnlTransAcct.Visible = true;
				pnlMobileGroupList.Visible = false;
			}
			else if (e.CommandName.ToString() == "MobileGroupLockedAcct")
			{

				int m_Index = int.Parse(e.CommandArgument.ToString());
				string m_MemberID = grdMemberList.DataKeys[m_Index].Values["MemberID"].ToString().Trim();
				//取得MobileGroupLocked的值
				string m_MobileGroupLocked = ((HiddenField)grdMemberList.Rows[m_Index].FindControl("MobileGroupLockedValue")).Value.Trim();

				int res = MobileGroupLockAcct(m_MemberID, m_MobileGroupLocked);

				//Result 0成功，1失敗
				if (res == 0)
				{
					//回傳成功後，列表要刷新一次
					LoadData();
				}


			}
			else if (e.CommandName.ToString() == "GetMobileGroup")//取得關聯帳號
			{
				string m_MemberID = e.CommandArgument.ToString();

				hfMemberID.Value = m_MemberID;

				LoadMemberMobileGroupList(int.Parse(e.CommandArgument.ToString()));

				pnlDetail.Visible = false;

				pnlMobileGroupList.Visible = true;
			}
		}

		#region 會員詳細資料顯示區控制
		/// <summary>
		/// 設定會員詳細資料顯示
		/// </summary>
		/// <param name="d"></param>
		protected void SetMemberDetailDataLoad(int memberID)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID", memberID)
			};

			DataSet ds = SqlHelper.ExecuteDataset(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_DetailData", arParms);

			lblMemberAccountData.Text = ds.Tables[0].Rows[0]["MemberAccount"].ToString();
			lblMemberIDData.Text = ds.Tables[0].Rows[0]["MemberID"].ToString();
			lblNickNameData.Text = ds.Tables[0].Rows[0]["NickName"].ToString();
			lblMobileData.Text = ds.Tables[0].Rows[0]["Mobile"].ToString();
			lblEMailData.Text = ds.Tables[0].Rows[0]["Email"].ToString();
			lblPointsData.Text = ds.Tables[0].Rows[0]["Points"].ToString();
			lblUPointsData.Text = ds.Tables[0].Rows[0]["UPoints"].ToString();
			lblEGameLMyData.Text = ds.Tables[0].Rows[0]["EGameLM"].ToString();
			lblMGameLMData.Text = ds.Tables[0].Rows[0]["MGameLM"].ToString();
			lbl_Next_VIP_LevelNameData.Text = ds.Tables[0].Rows[0]["Next_VIP_LevelName"].ToString();
			lbl_NickNameEditDate.Text = ds.Tables[0].Rows[0]["NickNameEditDate"].ToString();
			lblPauseAccountData.Text =
				ds.Tables[0].Rows[0]["PauseAccount"].ToString().Equals("AccountStop") ? GetGlobalResourceObject("Resources", "AccountActive").ToString() : GetGlobalResourceObject("Resources", "AccountStop").ToString();
			lblCreateDateData.Text = ds.Tables[0].Rows[0]["CreateDate"].ToString(); ;
			lblLastOnlineIPData.Text = ds.Tables[0].Rows[0]["LastOnlineIP"].ToString(); ;
			lblLastLoginDateData.Text = ds.Tables[0].Rows[0]["LastLoginDate"].ToString(); ;
			lblISDangerIDData.Text =
				ds.Tables[0].Rows[0]["ISDangerIP"].ToString() == "0" ? GetGlobalResourceObject("Resources", "No").ToString() : GetGlobalResourceObject("Resources", "Yes").ToString();

			lbl_SerinalNoData.Text = ds.Tables[0].Rows[0]["BossSerialNo"].ToString();
			lbl_Introducer.Text = ds.Tables[0].Rows[0]["Introducer"].ToString();

			btnPauseAccount.CommandArgument = ds.Tables[0].Rows[0]["MemberID"].ToString();
			btnPauseAccount.CommandName = ds.Tables[0].Rows[0]["PauseAccount"].ToString();
			btnDelete.CommandArgument = ds.Tables[0].Rows[0]["MemberID"].ToString();
			btnEdit.CommandArgument = ds.Tables[0].Rows[0]["MemberID"].ToString();
			#region 停用、啟用、未認證啟用

			txtPauseInfo.ForeColor = System.Drawing.Color.Black;
			switch (ds.Tables[0].Rows[0]["PauseAccount"].ToString())
			{
				case "AccountActive":
				case "AccountActive2":
					ddlLockDays.Visible = false;
					ddlLockDays.SelectedValue = ddlLockDays.SelectedValue;
					//txtPauseInfo.Enabled = false;
					txtPauseInfo.ReadOnly = true;
					txtPauseInfo.ForeColor = System.Drawing.Color.Red;
					txtPauseInfo.Text = ds.Tables[0].Rows[0]["MemberState"].ToString() + " － " + ds.Tables[0].Rows[0]["MemberStateDesc"].ToString();

					ddl_VipLevelList.Visible = true;

					if (ds.Tables[0].Rows[0]["PauseAccount"].ToString().Equals("AccountActive"))
					{
						btnPauseAccount.Text = GetGlobalResourceObject("Resources", "AccountActive").ToString();
						btnPauseAccount.OnClientClick = "return confirm(\"確定啟用此帳號?\");";
					}
					else
					{
						btnPauseAccount.OnClientClick = "return confirm(\"確定通過此帳號的手機認證，成為正式帳號?\");";
					}
					break;
				//啟用狀態
				case "AccountStop":
					ddlLockDays.Visible = true;
					//txtPauseInfo.Visible = true;
					txtPauseInfo.ReadOnly = false;
					ddl_VipLevelList.Visible = false;
					txtPauseInfo.Enabled = true;
					txtPauseInfo.Text = string.Empty;
					btnPauseAccount.Text = GetGlobalResourceObject("Resources", "btnAccountStop").ToString();
					btnPauseAccount.OnClientClick = "return confirm(\"確定停用此帳號?\");";
					break;
			}
			#endregion 停用、啟用、未認證啟用
			img_PhotoPath.ImageUrl = ds.Tables[0].Rows[0]["ImgPath"].ToString();
			//是否為黑名單
			lblMemberAlarmTypeYN.Text =
				ds.Tables[0].Rows[0]["MemberAlarmType"].ToString() == "0" ? GetGlobalResourceObject("Resources", "No").ToString() : GetGlobalResourceObject("Resources", "Yes").ToString();

			lblMemberIdentityData.Text = ds.Tables[0].Rows[0]["MemberIdentity"].ToString();
			lblMemberEntranceData.Text = ds.Tables[0].Rows[0]["MemberSource"].ToString();
			lbl_MobileState.Text = ds.Tables[0].Rows[0]["MobileState"].ToString();
			lbl_OldPlatform.Text = ds.Tables[0].Rows[0]["OldMemberSource"].ToString();
			lbl_TransDate.Text = (ds.Tables[0].Rows[0]["MemberSourceDate"] == null) ? "" : ds.Tables[0].Rows[0]["MemberSourceDate"].ToString();

            lbl_RegIP.Text = ds.Tables[0].Rows[0]["RegIP"].ToString();
			ViewState["IdPassport"] = ds.Tables[0].Rows[0]["IdPassport"].ToString();

			if (ds.Tables[0].Rows[0]["RaiseDate"].ToString().Length == 0)
			{
				trRanseDate.Visible = false;
			}
			else
			{
				btnRanseDate.CommandArgument = ds.Tables[0].Rows[0]["MemberID"].ToString();
				lblRaiseDate.Text = ds.Tables[0].Rows[0]["RaiseDate"].ToString();
				trRanseDate.Visible = true;
			}

			// 2013/09/26 新增
			lblLockStartDate.Text = ds.Tables[0].Rows[0]["LockStartDate"].ToString();
			lblLockEndDate.Text = ds.Tables[0].Rows[0]["LockEndDate"].ToString();
		}
		/// <summary>
		/// 按下停用/啟用紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnPauseAccount_Click(object sender, EventArgs e)
		{

			if (!IsValid)
			{
				return;
			}
			Button btn = sender as Button;

			//如果是未認證
			int parLockDays = 0;	//停用天數
			string parLockReason = string.Empty;	//停用原因
			int parLockType = 0;
			if (btn.CommandName.Equals("AccountStop"))
			{
				parLockReason = txtPauseInfo.Text;
				parLockDays = int.Parse(ddlLockDays.SelectedValue);
				if (parLockDays == 999)
				{
					parLockDays = 0;
					parLockType = 2;
				}
				else
				{
					parLockType = 1;
				}
			}
			else
			{
				parLockType = 0;
			}

			bool isMemberPauseAccount = false;

			try
			{
				object ReturnValue = SqlHelper.ExecuteScalar
				(
					WebConfig.connectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_Member_PauseAccount",
					new SqlParameter("@MemberID", btn.CommandArgument),
					new SqlParameter("@LockDays", parLockDays),
					new SqlParameter("@LockReason", parLockReason),
					new SqlParameter("@LockType", parLockType),
					new SqlParameter("@ExecAgentID", AUser.ExecAgentID),
					new SqlParameter("@NewVIP_Level", ddl_VipLevelList.Visible ? ddl_VipLevelList.SelectedValue : "-1")
				);

				if (ReturnValue != null)
				{
					isMemberPauseAccount = ReturnValue.ToString().Equals("0") ? true : false;
				}
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(MemberQuery)).Error("MemberQuery::btnPauseAccount_Click", ex);
			}

			if (isMemberPauseAccount)
			{
				// 20110509 Phil: 改對前台發出登出命令
				GameCommandHandler.LogoutMember(Int32.Parse(btn.CommandArgument));

				//SetMemberDetailDataLoad(new MemberDAO().GetMemberDetail(Int32.Parse(btn.CommandArgument)));
				WebUtility.ResponseScript(Page, "alert('" + "設定成功" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('" + "設定失敗" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			string strTemp = btn.CommandArgument;
			LoadData();
			pnlDetail.Visible = true;
			SetMemberDetailDataLoad(int.Parse(strTemp));
		}
		protected void btnRanseDate_Click(object sender, EventArgs e)
		{
			SqlParameter[] param = 
			{
				new SqlParameter("@MemberID", btnRanseDate.CommandArgument.ToString()),
				new SqlParameter("@AgentAccount", AUser.ExecAgentAccount),
				new SqlParameter("@ReturnValue", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_BanProsecuteCheatRaise",
				param
			);

			string result = param[param.Length - 1].Value.ToString();

			if (result == "0")
			{
				WebUtility.ResponseScript(Page, "alert('" + "設定成功" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('" + "設定失敗" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			string strTemp = btnRanseDate.CommandArgument;
			LoadData();
			pnlDetail.Visible = true;
			SetMemberDetailDataLoad(int.Parse(strTemp));
		}
		/// <summary>
		/// 按下編輯紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnEdit_Click(object sender, EventArgs e)
		{
			Button btn = sender as Button;
			Response.Redirect("EditMember.aspx?mid=" + btn.CommandArgument, true);

		}
		/// <summary>
		/// 按下刪除紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnDelete_Click(object sender, EventArgs e)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID",Int32.Parse((sender as Button).CommandArgument)),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};

			string strResult = string.Empty;
			string strMessage = string.Empty;
			try
			{
				strResult = SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_DELETE", arParms).ToString();

			}
			catch (Exception ex)
			{
				strResult = ex.Message;
			}
			finally
			{
				switch (strResult)
				{
					case "0":
						//string sCmd = "267&" + AUser.SHID + "&" + (sender as Button).CommandArgument + "&0";
						//Utility.SendInfoToFrontServer(AUser.FrontServerIP, sCmd);

						// 20110509 Phil: 改對前台發出登出命令
						GameCommandHandler.LogoutMember(Int32.Parse((sender as Button).CommandArgument));


						strMessage = "刪除成功";
						break;
					case "1":
						strMessage = "已刪除過";
						break;
					case "2":
						strMessage = "會員還在線上";
						break;
					default:
						strMessage = "資料發生錯誤";
						break;
				}
				if (strResult.Equals("0"))
				{
					pnlDetail.Visible = false;
					LoadData();
				}
				WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		#endregion 會員詳細資料顯示區控制


		/// <summary>
		/// 按下新增會員紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnNewMember_Click(object sender, EventArgs e)
		{
			Response.Redirect("AddMember.aspx", true);
		}

		/// <summary>
		/// 按下設為預設圖片按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSetDefaultImageClick(object sender, EventArgs e)
		{
			Button btn = sender as Button;

			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID", lblMemberIDData.Text),
				new SqlParameter("@Result",SqlDbType.TinyInt)
			};

			arParms[1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_SetMemberPicToDefault", arParms);

			if (arParms[1].Value.ToString().Equals("0"))
			{
				SetMemberDetailDataLoad(int.Parse(lblMemberIDData.Text));
				WebUtility.ResponseScript(Page, "alert('修改成功');", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('修改失敗');", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		/// <summary>
		/// 按下寄送簡訊。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSendSMS_Click(object sender, EventArgs e)
		{
			string newPassword = Cryptography.GetRandomString(6, Cryptography.RandomStringTypes.Full, true).ToUpper();

			SqlParameter[] param = 
		    {
		        new SqlParameter("@MemberAccount", lblMemberAccountData.Text.ToSafeString()),
		        new SqlParameter("@Mobile", lblMobileData.Text.ToSafeString()),
		        new SqlParameter("@IdPassport", ViewState["IdPassport"].ToString().ToSafeString()),
		        new SqlParameter("@NewPassword", newPassword),
		        new SqlParameter("@OnlineIP", Request.ServerVariables["REMOTE_ADDR"].ToString()),
		    };

			SqlDataReader objDtr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Member_ResetPassword",
				param
			);

			string passwordMessage = string.Format("老子有錢客服中心您好 : 您的新密碼為{0}. 請到官網重新登入後,可更新密碼.", newPassword);

			try
			{
				Utility.SendSMS(lblMobileData.Text, passwordMessage, Utility.SMSRequestTypes.ForgetPassword, lblMemberIDData.Text);
				WebUtility.ResponseScript(Page, "alert('送出成功');", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			catch (Exception)
			{
				WebUtility.ResponseScript(Page, "alert('送出失敗');", WebUtility.ResponseScriptPlace.NearFormEnd);
				throw;
			}


		}

		/// <summary>
		/// 檢查密碼的格式是否正確
		/// </summary>
		/// <param name="passWord">要檢查的密碼字串</param>
		/// <param name="invalidText">要傳回的錯誤訊息</param>
		protected bool IsValidRegular_MemberPassword(string passWord, out string invalidText)
		{
			passWord = passWord.Trim().Replace(" ", "");
			invalidText = "";

			int iTmp = 0;
			string sTmp = "";

			if (int.TryParse(passWord, out iTmp))
			{
				invalidText = "密碼至少須包含一個英文字母";
				return false;
			}

			if (passWord.Length < 6 || passWord.Length > 12)
			{
				invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
				return false;
			}


			iTmp = 0;
			for (int i = 0; i < passWord.Length; i++)
			{
				int code = passWord[i];
				if (sTmp.IndexOf(passWord[i]) == -1)
				{ // 把不同的文字加進暫存變數, 等下要判斷有幾種字元
					sTmp += passWord[i].ToString();
				}
				if (!((code >= 48 && code <= 57) || (code >= 65 && code <= 90) || (code >= 97 && code <= 122)))
				{
					invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
					return false;
				}

				// 如果往後的 3 個字元都是連續字元(例如 123、abc、321、cba、..), 就傳出錯誤
				if (passWord.Length - i > 2 &&
						(
						passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
													+ Convert.ToChar(code + 1).ToString()
													+ Convert.ToChar(code + 2).ToString())
							||
							passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
													+ Convert.ToChar(code - 1).ToString()
													+ Convert.ToChar(code - 2).ToString())
						))
				{
					invalidText = "密碼不可包含 3 個連續數字或 3 個連續字母";
					return false;
				}
			}
			if (sTmp.Length < 4)
			{
				invalidText = "密碼必須包含 4 種字元以上";
				return false;
			}
			return true;

		}

		#region 驗證

		/// <summary>
		/// 驗證基本資料頁表單
		/// </summary>
		private bool ValidMemberForm(out string errorMessage)
		{
			errorMessage = "";
			string tmp = "";

			#region 登入帳號
			tmp = txtTransMemberAcct.Text.Trim();
			if (tmp.Trim() == "")
			{
				errorMessage = "帳號不可空白";
				return false;
			}
			else if (tmp.Length < 6 || tmp.Length > 12
				|| !System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9a-zA-Z]*$"))
			{

				errorMessage = "帳號必須是 6 ~ 12 碼的英文數字組合";
				return false;
			}
			else if (System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9]*$"))
			{
				errorMessage = "帳號至少須包含一個英文字母";
				return false;
			}
			#endregion

			#region 設定密碼
			if (txtTransMemberPwd.Text.Trim() == "")
			{
				errorMessage = "密碼不可空白";
				return false;
			}
			else if (!IsValidRegular_MemberPassword(txtTransMemberPwd.Text.Trim().ToUpper(), out errorMessage))
			{
				return false;
			}
			else if ((txtTransMemberAcct.Text.Trim().Length > 0 && txtTransMemberPwd.Text.IndexOf(txtTransMemberAcct.Text.Trim()) > -1))
			{
				errorMessage = "密碼中不可包含帳號";
				return false;
			}
			#endregion

			#region 確認密碼
			if (txtTransMemberConfirmPwd.Text.Trim() == "")
			{
				errorMessage = "確認密碼不可空白";
				return false;
			}
			else if (txtTransMemberConfirmPwd.Text.Trim() != txtTransMemberPwd.Text.Trim())
			{
				errorMessage = "與上面的密碼不相同";
				return false;
			}
			#endregion

			if (errorMessage.Length != 0)
			{
				return false;
			}
			return true;
		}
		#endregion

		#region 轉換帳號
		protected void btnTransAcctSubmit_Click(object sender, EventArgs e)
		{
			//欄位驗證不過就離開
			string ResultValidForm = string.Empty;
			if (!ValidMemberForm(out ResultValidForm))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('" + ResultValidForm + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			string strResult = string.Empty;

			int resultCode = TransformAcct();
			switch (resultCode)
			{
				case 0:
					strResult = "轉換帳號成功";
					pnlTransAcct.Visible = false;
					break;
				case 1:
					strResult = "轉換帳號重複";
					pnlTransAcct.Visible = true;
					break;
				default:
					strResult = "轉換帳號重複";
					pnlTransAcct.Visible = true;
					break;
			}
			strResult = "alert('" + strResult + "');";
			if (resultCode == 0)
			{
				strResult += "location.href='MemberQuery.aspx';";
			}
			GFC.Web.WebUtility.ResponseScript(Page, strResult, GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}
		#endregion


		#region 執行SP 轉換帳號
		/// <summary>
		/// 新增會員。
		/// </summary>
		private int TransformAcct()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@MemberAccount", txtTransMemberAcct.Text.ToSafeString().Trim()),
				new SqlParameter("@MemberPassword", txtTransMemberConfirmPwd.Text.ToSafeString().Trim()),
				new SqlParameter("@MemberID", int.Parse(ViewState["A101_TransMemberID"].ToString().ToSafeString().Trim()))
			};

			DataSet ds = new DataSet();
			try
			{
				ds = SqlHelper.ExecuteDataset
					(
						WebConfig.connectionString,
						CommandType.StoredProcedure,
						"NSP_GameAgent_A_MemberSourceUpdate",
						param
					);
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return int.Parse(ds.Tables[0].Rows[0][0].ToString());
		}
		#endregion

		/// <summary>
		/// 判斷是否要顯示轉換帳號Button
		/// </summary>
		/// <param name="CanChange"> 1:可修改帳號 2:不可改帳號</param>
		/// <returns></returns>
		public bool TransButton(string CanChange)
		{
			if (CanChange.Trim() == "1")
				return true;
			else
				return false;
		}


		#region "顯示關連帳號"

		/// <summary>
		/// 讀取關連帳號清單
		/// </summary>
		/// <param name="memberID"></param>
		protected void LoadMemberMobileGroupList(int memberID)
		{

			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID", memberID),
				new SqlParameter("@Result",SqlDbType.TinyInt),
                new SqlParameter("@PageIndex","1"),
				new SqlParameter("@PageSize",SqlDbType.Int),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};


			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			arParms[arParms.Length - 2].Value = 255;
			arParms[arParms.Length - 4].Direction = ParameterDirection.Output;


			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_MobileGroupList", arParms);

			grdMemberMobileGroupList.DataSource = sdr;
			grdMemberMobileGroupList.DataBind();
			sdr.Close();

		}

		/// <summary>
		/// 關連帳號頁數改變
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void MemberMobileGroupList_Pager_Change(object sender, EventArgs e)
		{
			int m_memberID = Int32.Parse(hfMemberID.Value);
			this.LoadMemberMobileGroupList(m_memberID);
		}

		/// <summary>
		/// 將主帳號加上(主)
		/// </summary>
		/// <param name="memberAccount"></param>
		/// <param name="isPrimaryAccount"></param>
		/// <returns></returns>
		public string PrimaryAccount(string memberAccount, string isPrimaryAccount)
		{
			return memberAccount + (isPrimaryAccount == "1" ? "(主)" : "");
		}

		/// <summary>
		/// 隱藏數量為0
		/// </summary>
		/// <param name="mobileGroupNumber"></param>
		/// <returns></returns>
		public bool MobileGroupShow(string mobileGroupNumber)
		{
			if (mobileGroupNumber.Trim() == "0")
				return false;
			else
				return true;
		}


		#endregion



		#region 關連帳號解鎖

		/// <summary>
		/// 執行帳號解鎖
		/// </summary>
		/// <param name="memberID"></param>
		/// <param name="mobileGroupLocked">設定狀態。0：啟用，1：停用，-1：反向</param>
		/// <returns>Result 0-成功   1-失敗</returns>
		private int MobileGroupLockAcct(string memberID, string mobileGroupLocked)
		{
			string lockValue = "-1";// mobileGroupLocked.ToSafeString().Trim() == "1" ? "1" : "0";

			SqlParameter[] param =
			{
                new SqlParameter("@MemberID_Primary", memberID.ToSafeString().Trim()),
                new SqlParameter("@IsMergeLocked", lockValue.ToSafeString().Trim()),
                new SqlParameter("@Result",SqlDbType.SmallInt),
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = new DataSet();
			try
			{

				SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_MobileGroupSet", param);

			}
			catch (Exception ex)
			{
				throw ex;
			}

			return Int32.Parse(param[param.Length - 1].Value.ToString());

		}

		/// <summary>
		/// 判斷關連帳號解鎖按鈕是否顯示
		/// </summary>
		/// <param name="CanChange"> 0：顯示文字「無此功能」，1：顯示按鈕「停用」，2：顯示按鈕「啟用」</param>
		/// <returns></returns>
		public bool MobileGroupLockEnagleButton(string CanEnagleGroupLock)
		{
			if (CanEnagleGroupLock.Trim() == "0")
				return false;
			else
				return true;
		}

		/// <summary>
		/// 關連帳號解鎖按鈕顯示文字
		/// </summary>
		/// <param name="CanChange"> 0：顯示文字「無此功能」，1：顯示按鈕「停用」，2：顯示按鈕「啟用」</param>
		/// <returns></returns>
		public string MobileGroupLockEnagleText(string CanEnagleGroupLock)
		{
			if (CanEnagleGroupLock.Trim() == "1")
				return "停用";
			else if (CanEnagleGroupLock.Trim() == "2")
				return "啟用";
			else return "";
		}
		#endregion

	}
}