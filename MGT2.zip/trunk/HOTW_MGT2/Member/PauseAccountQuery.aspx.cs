﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class PauseAccountQuery : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		/// <summary>
		/// 按下帳號啟用紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnUnLock_Click(object sender, EventArgs e)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID",(sender as Button).CommandArgument),
				new SqlParameter("@LockDays","0"),
				new SqlParameter("@LockType","0"),
				new SqlParameter("@LockReason", string.Empty),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};

			string strResult = string.Empty;
			string strMessage = string.Empty;
			try
			{
				strResult = SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_PauseAccount", arParms).ToString();

				switch (strResult)
				{
					case "0":
						strMessage = "啟用成功";
						break;
					default:
						strMessage = "啟用失敗";
						break;
				}
			}
			catch (Exception ex)
			{
				strMessage = ex.Message;
			}



			//啟用成功後，才重新載入資料
			if (strResult.Equals("0"))
			{
				LoadData();
			}

			WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", WebUtility.ResponseScriptPlace.NearFormEnd);
		}



		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{


			SqlParameter[] arParms =
			{
				new SqlParameter("@PauseType",rblPauseAccount.SelectedValue),
				new SqlParameter("@PageSize",Pager1.PageSize),
				new SqlParameter("@PageIndex",Pager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_Member_PauseAccount_List", arParms);

			gvPauseAccount.DataSource = sdr;
			gvPauseAccount.DataBind();
			sdr.Close();

			Pager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			Pager1.DataBind();
		}


		protected void Page1_Change(object sender, GWeb.AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadData();
		}

		/// <summary>
		///  按下查詢紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			Pager1.CurrentPageNumber = 1;
			LoadData();
		}
	}
}