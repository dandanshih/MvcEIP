﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class EditCustomerService : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				SqlDataReader sdr = null;
				SqlParameter[] arParms =
				{
					new SqlParameter("@Account",Request["mid"]==null?"":Request["mid"].ToString())
				};
				try
				{
					sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GetTechnicalCSByAccount", arParms);
					if (!sdr.HasRows)
					{
						GFC.Web.WebUtility.ResponseScript(Page, "alert('無此帳號');location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					}
					else
					{
						sdr.Read();
						txtAgentAccount.Text = sdr["AgentAccount"].ToString();
						txtAgentNickName.Text = sdr["AgentNickName"].ToString();
						switch (sdr["AgentFlagID"].ToString())
						{
 							case "1024":
								rdlChatType.SelectedValue = "1";
								break;
							case "2048":
								rdlChatType.SelectedValue = "0";
								break;
							default:
								rdlChatType.SelectedValue = "0";
								break;
						}
					}
				}
				finally
				{
					sdr.Close();
				}


			}
		}

		/// <summary>
		/// 按下提交按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSubmitClick(object sender, EventArgs e)
		{
			if (!IsValid)
			{
				return;
			}
			if ((txtLoginPassword.Text.Trim().Length != 0 || txtLoginPasswordConfirm.Text.Trim().Length != 0) && (txtLoginPassword.Text != txtLoginPasswordConfirm.Text))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('登入密碼與確認密碼不一致');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			SqlParameter[] arParms =
			{
				new SqlParameter("@Account",txtAgentAccount.Text),
				new SqlParameter("@Password",txtLoginPassword.Text),
				new SqlParameter("@NickName",txtAgentNickName.Text),
				new SqlParameter("@ChatCSType",rdlChatType.SelectedValue),
				new SqlParameter("@ExecuteAgentID",AUser.ExecAgentID),
				new SqlParameter("@Result",SqlDbType.SmallInt)
			};
			arParms[arParms.Length - 1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_UpdateCSByAccount", arParms);
			string strResult = arParms[arParms.Length - 1].Value.ToString();
			string strMessage = string.Empty;
			switch (strResult)
			{
				case "0":
					strMessage = "修改成功";
					break;
				case "-3":
					strMessage = "權限不足";
					break;
				default:
					strMessage = "資料操作錯誤";
					break;
			}
			string strSource = strResult.Equals("0") ? string.Format("alert('{0}');location.href=document.referrer;", strMessage) : string.Format("alert('{0}');", strMessage);
			GFC.Web.WebUtility.ResponseScript(Page, strSource, GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void btnCloseClick(object sender, EventArgs e)
		{
			Response.Redirect("CustomerService.aspx");
		}
	}
}