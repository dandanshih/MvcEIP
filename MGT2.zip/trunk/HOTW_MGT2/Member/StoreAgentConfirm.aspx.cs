﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web.UI.WebControls;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class StoreAgentConfirm : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@Account",txtAccount.Text),
				new SqlParameter("@IdPassport",txtIDPassport.Text)

			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_AgnetConfirm", arParms);

			gv.DataSource = sdr;
			gv.DataBind();
			sdr.Close();


		}
		/// <summary>
		/// 按下查詢按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQueryClick(object sender, EventArgs e)
		{
			this.LoadData();
		}

		/// <summary>
		/// 欄位格式調整
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void gvRowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				e.Row.Cells[2].Text = e.Row.Cells[2].Text + "%";
				e.Row.Cells[6].Text = e.Row.Cells[6].Text.Contains("1900") ? string.Empty : e.Row.Cells[6].Text = e.Row.Cells[6].Text;
				e.Row.Cells[7].ForeColor = e.Row.Cells[7].Text.Equals("正常") ? Color.Green : Color.Red;
			}
		}
	}
}