﻿using GWeb.AppLibs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;

namespace GWeb.Member
{
    public partial class A111 : FormBase
    {
        private void BindData()
        {
            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@TotalRecords", SqlDbType.Int),
                new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
                new SqlParameter("@PageSize", UCPager1.PageSize),
                new SqlParameter("@StartDate", UCDateRange1.StartDate),
                new SqlParameter("@EndDate", UCDateRange1.EndDate),
                new SqlParameter("@IsBlock", ddl_StatusList.SelectedValue)
            };
            objParam[0].Direction = ParameterDirection.Output;

            DataTable objTab = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_SendSMS_BlockList_Get",
                objParam
            ).Tables[0];
            var query = from item in objTab.AsEnumerable()
                        join obj in ddl_StatusList.Items.Cast<ListItem>() on item["IsBlock"].ToString() equals obj.Value
                        select new
                        {
                            Mobile = item["Mobile"],
                            BlockDay = item["BlockDay"],
                            IsBlock = item["IsBlock"],
                            BlockStatus = obj.Text,
                            AgentUser = item["AgentUser"],
                            CreateDate = item["CreateDate"],
                            Memo = item["Memo"]
                        };
            gv_DataList.DataSource = query;
            gv_DataList.DataBind();
            UCPager1.RecordCount = int.Parse(objParam[0].Value.ToString());
            UCPager1.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            UCPager1.CurrentPageNumber = 1;
            BindData();
        }

        protected void UCPager_Change(object sender, EventArgs e)
        {
            BindData();
        }

        protected void btn_Add_Click(object sender, EventArgs e)
        {
            Response.Redirect("A111_Add.aspx");
        }

        protected void btn_Del_Click(object sender, EventArgs e)
        {
            Response.Redirect("A111_Del.aspx");
        }
    }
}