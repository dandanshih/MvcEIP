﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class CustomerService : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

			if (!IsPostBack)
			{
				InitTree();
			}

		}

		/// <summary>
		/// 按下節點
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ItemClick(object sender, EO.Web.NavigationItemEventArgs e)
		{

			this.LoadData(e.TreeNode);

		}

		/// <summary>
		/// 產生客服樹狀選單
		/// </summary>
		protected void InitTree()
		{
			TreeView1.Nodes.Clear();
			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.Text, "EXEC NSP_AgentWeb_R_GetTechnicalCSGroups @Groups = '10,40,41'");
			while (sdr.Read())
			{
				EO.Web.TreeNode node = new EO.Web.TreeNode();
				node.Text = sdr["AgentGroupName"].ToString();
				node.Value = sdr["AgentGroupID"].ToString();


				SqlParameter[] arParms =
				{
					new SqlParameter("@AgentGroupID",node.Value)
				};
				DataTable dtChild = SqlHelper.ExecuteDataset(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GetTechnicalCSListByAgentGroupID", arParms).Tables[0];
				if (dtChild.Rows.Count != 0)
				{
					node.PopulateOnDemand = true;
					foreach (DataRow dr in dtChild.Rows)
					{
						EO.Web.TreeNode ndChild = new EO.Web.TreeNode();
						ndChild.PopulateOnDemand = false;
						ndChild.Text = string.Format("{0}({1})", dr["AgentAccount"].ToString(), dr["AgentNickName"].ToString());
						ndChild.Value = node.Value;
						ndChild.RaisesServerEvent = EO.Web.NullableBool.False;
						node.ChildNodes.Add(ndChild);

					}
				}
				else
				{
					node.PopulateOnDemand = false;
				}
				TreeView1.Nodes.Add(node);
			}
		}

		/// <summary>
		/// 載入資料
		/// </summary>
		/// <param name="node">觸發的節點</param>
		protected void LoadData(EO.Web.TreeNode node)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@AgentGroupID",node.Value)
			};

			//SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GetTechnicalCSListByAgentGroupID", arParms);
            DataSet ds = SqlHelper.ExecuteDataset
                (
                    WebConfig.connectionString, 
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_R_GetTechnicalCSListByAgentGroupID", 
                    arParms
                );

            gv.DataSource = ds.Tables[0];
			gv.DataBind();
			//sdr.Close();


		}

		/// <summary>
		/// 設定帳號停用/啟用按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
                GridViewRow gvRow = (GridViewRow)e.Row;             // Bind to HTML Form
                DataRowView dvRow = (DataRowView)e.Row.DataItem;    // Bind to Database


				Button btn = e.Row.Cells[4].FindControl("btnSetPause") as Button;
				btn.CommandName = e.Row.Cells[3].Text.Equals("正常") ? "PauseAccount" : "ActiveAccount";
				btn.Text = e.Row.Cells[3].Text.Equals("正常") ? "停用" : "啟用";
				e.Row.Cells[3].ForeColor = e.Row.Cells[3].Text.Equals("正常") ? System.Drawing.Color.Green : System.Drawing.Color.Red;
                btn.Attributes.Add("AgentID", dvRow["AgentID"].ToString());

                btn = gvRow.FindControl("btnDelete") as Button;
                btn.Attributes.Add("AgentID", dvRow["AgentID"].ToString());
                
			}
		}

		/// <summary>
		/// 資料列的操作按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void gvRowCommand(object sender, GridViewCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "PauseAccount":
					SqlParameter[] arParms1 =
					{
						new SqlParameter("@Account",e.CommandArgument.ToString()),
						new SqlParameter("@ExecAccount",AUser.ExecAgentAccount),
						new SqlParameter("@PauseAccount","1"),
						new SqlParameter("@Result",SqlDbType.SmallInt)
					};
					arParms1[arParms1.Length - 1].Direction = ParameterDirection.ReturnValue;
					SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AgentAccountDisable", arParms1);
					this.LoadData(TreeView1.SelectedNode);

                    // 20110510 Phil: 踢掉該帳號
                    Utility.KickAgentQueue.Add(int.Parse(((Button)e.CommandSource).Attributes["AgentID"]));
                    

					break;
				case "ActiveAccount":
					SqlParameter[] arParms2 =
					{
						new SqlParameter("@Account",e.CommandArgument.ToString()),
						new SqlParameter("@ExecAccount",AUser.ExecAgentAccount),
						new SqlParameter("@PauseAccount","0"),
						new SqlParameter("@Result",SqlDbType.SmallInt)
					};
					arParms2[arParms2.Length - 1].Direction = ParameterDirection.ReturnValue;
					SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AgentAccountDisable", arParms2);
					this.LoadData(TreeView1.SelectedNode);
					break;
				case "EditAccount":
					Response.Redirect(string.Format("EditCustomerService.aspx?mid={0}", e.CommandArgument.ToString()), true);
					break;
				case "Permissions":
					break;
				case "DeleteAccount":
					EO.Web.TreeNode nd = TreeView1.SelectedNode;
					SqlParameter[] arParms3 =
					{
						new SqlParameter("@AgentAccount",e.CommandArgument.ToString()),
                        new SqlParameter("@ExecAccount",AUser.AgentAccount),
						new SqlParameter("@Result",SqlDbType.SmallInt)
					};
					arParms3[arParms3.Length - 1].Direction = ParameterDirection.ReturnValue;
					SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_DeleteTechnicalCSByAccount", arParms3);
					string strMessage = string.Empty;

					switch (arParms3[arParms3.Length - 1].Value.ToString())
					{
						case "0":
							strMessage = "刪除成功";
							break;
						case "-1":
							strMessage = "帳號不存在";
							break;						
						case "-2":
							strMessage = "此帳號已被刪除";
							break;
						case "-3":
							strMessage = "權限不足";
							break;
					}
					string strCurrentPath = TreeView1.SelectedNode.Path;
					InitTree();
					TreeView1.SelectedNode = TreeView1.FindItem(strCurrentPath) as EO.Web.TreeNode;
					this.LoadData(nd);

                    // 20110510 Phil: 踢掉該帳號
                    Utility.KickAgentQueue.Add(int.Parse(((Button)e.CommandSource).Attributes["AgentID"]));

					GFC.Web.WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);

					break;

			}
		}

		/// <summary>
		/// 設定標題帳號類別
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void gvDataBound(object sender, EventArgs e)
		{
			if (gv.Rows.Count == 0)
			{
				return;
			}
			gv.HeaderRow.Cells[0].Text = TreeView1.SelectedNode.Text + "帳號";


		}

		/// <summary>
		/// 按下新增按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnAddClick(object sender, EventArgs e)
		{
			Response.Redirect("AddCustomerService.aspx", true);
		}
	}
}