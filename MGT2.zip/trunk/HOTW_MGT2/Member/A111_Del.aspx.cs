﻿using GS.Utilities;
using GWeb.AppLibs;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI;

namespace GWeb.Member
{
    public partial class A111_Del : FormBase
    {
        private const int MaxInputCount = 100;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Del_Click(object sender, EventArgs e)
        {
            string[] mobiles = txt_MobileList.Text.Split(new string[] { ",", " ", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            if (mobiles.Length > MaxInputCount)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('筆數不可超過" + MaxInputCount + "筆！');", true);
                return;
            }
            var errorList = mobiles.Where((item) => item.Trim() != "" && !Regex.IsMatch(item.Trim(), @"^09[\d]{8}$"));
            // 有非手機格式 的手機號碼列表
            if (errorList.Count() > 0)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('資料填寫錯誤！\\r\\n" + string.Join(", ", errorList) + "');", true);
                return;
            }
            var query = from item in mobiles
                        where item.Trim() != "" && Regex.IsMatch(item.Trim(), @"^09[\d]{8}$")
                        select new
                        {
                            Mobile = item
                        };
            DataTable objTab = new DataTable();
            objTab.Columns.Add("Mobile", typeof(string));
            foreach (var obj in query)
            {
                objTab.LoadDataRow(new object[] { obj.Mobile }, true);
            }

            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@MobileListData", SqlDbType.Structured),
                new SqlParameter("@Result", SqlDbType.TinyInt),
                new SqlParameter("@Memo", ""),
                new SqlParameter("@AgentUser", AUser.AgentAccount)
            };
            objParam[0].Value = objTab;
            objParam[1].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_SendSMS_BlockList_Del",
                objParam
            );
            int result = Convert.ToInt32(objParam[1].Value);
            if (result == 1)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertOK", "alert('刪除成功！');location.href='A111.aspx';", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('刪除失敗！');", true);
            }
        }
    }
}