﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;
using System.Web.UI;

namespace GWeb.Member
{
	public partial class MemberBlacklist : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		/// <summary>
		/// 按下設為黑名單鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSetBlacklist_Click(object sender, EventArgs e)
		{
			Button btn = sender as Button;
			string strMessage = string.Empty;
			switch (btn.CommandName)
			{
				case "EnableBlacklist":
					if (!rdoAccount.Checked && !rdoNickName.Checked)
					{
						ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('請輸入會員帳號或暱稱');", true);
						return;
					}
					if (txtMemberAccount.Text.Trim().Length == 0 && rdoAccount.Checked)
					{
						ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('請輸入會員帳號');", true);
						return;
					}
					if (txtNickName.Text.Trim().Length == 0 && rdoNickName.Checked)
					{
						ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('請輸入會員暱稱');", true);
						return;
					}
					SqlParameter[] arParms =
					{
						new SqlParameter("@ExecAccount",AUser.ExecAgentAccount),
						new SqlParameter("@MemberAccount",txtMemberAccount.Text),
						new SqlParameter("@NickName",txtNickName.Text),
						new SqlParameter("@AlarmType","2"),
						new SqlParameter("@ReturnValue",SqlDbType.Int)
					};

					arParms[arParms.Length - 1].Direction = ParameterDirection.ReturnValue;
					try
					{
						SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_A_SetMemberAccountAlarmed", arParms).ToString();
						switch (arParms[arParms.Length - 1].Value.ToString())
						{
							case "0":
								strMessage = "設定成功";
								LoadData();
								break;
							case "-1":
								strMessage = "輸入的會員帳號不存在";
								break;
							case "-2":
								strMessage = "此帳號已經被列為黑名單了";
								break;
						}
					}
					catch (Exception ex)
					{
						strMessage = ex.Message;
					}
					break;
				case "RemoveBlacklist":
					SqlParameter[] arParms2 =
					{
						new SqlParameter("@ExecAccount",AUser.AgentAccount),
						new SqlParameter("@MemberAccount",btn.CommandArgument),
						new SqlParameter("@AlarmType","0"),
						new SqlParameter("@ReturnValue",SqlDbType.Int)
					};

					arParms2[arParms2.Length - 1].Direction = ParameterDirection.ReturnValue;
					try
					{
						SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_A_SetMemberAccountAlarmed", arParms2).ToString();
						switch (arParms2[arParms2.Length - 1].Value.ToString())
						{
							case "0":
								strMessage = "設定成功";
								LoadData();
								break;
							case "-1":
								strMessage = "輸入的會員帳號不存在";
								break;
							case "-2":
								strMessage = "此帳號已經被列為黑名單了";
								break;

						}

					}
					catch (Exception ex)
					{
						strMessage = ex.Message;
					}
					break;
			}
			ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('" + strMessage + "');", true);

		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@NickName",txtNickName.Text),
				new SqlParameter("@StartDate",DateRange1.StartDate),
				new SqlParameter("@EndDate",DateRange1.EndDate),
				new SqlParameter("@PageSize",UCPager1.PageSize),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_MemberAlarmedList", arParms);

			gvBlacklist.DataSource = sdr;
			gvBlacklist.DataBind();
			sdr.Close();

			UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			UCPager1.DataBind();
		}


		protected void UCPage1_Change(object sender, GWeb.AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadData();
		}

		/// <summary>
		///  按下查詢紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			LoadData();
		}

		protected void gvRowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				e.Row.Cells[7].Text = e.Row.Cells[7].Text.Contains("1900/01/01") ? string.Empty : e.Row.Cells[7].Text;
				try
				{
					string[] sGameName = e.Row.Cells[10].Text.Replace(" ", "").Split(',');
					e.Row.Cells[10].Text = Utility.GetGameENameMapping(sGameName[0]).ToString();
					for (int i = 1; i < sGameName.Length; i++)
					{
						e.Row.Cells[10].Text += "," + Utility.GetGameENameMapping(sGameName[i]).ToString();
					}

				}
				catch { }
			}
		}

		protected void DateRangeChange(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;
			UCPager1.CurrentPageNumber = 1;
			this.LoadData();
		}
	}
}