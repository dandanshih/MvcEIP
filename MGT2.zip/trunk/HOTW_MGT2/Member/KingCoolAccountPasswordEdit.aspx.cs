﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
    public partial class KingCoolAccountPasswordEdit : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            // 取得使用者原始資訊
            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@KingCoolCardNo", AUser.AgentAccount)
            };

            DataTable ObjDt = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_KingCoolCardGetOne",
                param
            ).Tables[0];

            string AgentID =  ObjDt.Rows[0]["AgentID"].ToString();
            string AgentNickName = ObjDt.Rows[0]["AgentNickName"].ToString();
            string AgentOldPassword = ObjDt.Rows[0]["AgentPassword"].ToString();
            string Msg = string.Empty;

            // 確認密碼輸入正確
            if (AgentOldPassword == txt_AgentOldPassword.Text)
            {
                param = new SqlParameter[]
                {
                    new SqlParameter("@Result", SqlDbType.TinyInt),
                    new SqlParameter("@TargetID", AgentID),
                    new SqlParameter("@NickName", AgentNickName),
                    new SqlParameter("@Password", txt_AgentNewPassword.Text),
                    new SqlParameter("@ContributeRate", 0),
                    new SqlParameter("@ExecAgentID", AUser.ExecAgentID)
                };

                param[0].Direction = ParameterDirection.ReturnValue;

                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.connectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_EditAgent",
                    param
                );

                switch (param[0].Value.ToString())
                {
                    case "0":
                        Msg = "修改成功";
                        break;
                    case "-1":
                        Msg = "暱稱重複";
                        break;
                    case "-2":
                        Msg = "暱稱空白";
                        break;
                    default:
                        Msg = "修改失敗";
                        break;
                }
            }
            else
            {
                Msg = "密碼錯誤";
            }

            ScriptManager.RegisterStartupScript(Page, GetType(), "Message", string.Format("alert('{0}');", Msg), true);
        }
    }
}