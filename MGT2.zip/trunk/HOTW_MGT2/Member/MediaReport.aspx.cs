﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GFC.Web.WebControls;

namespace GWeb.Member
{
	public partial class MediaReport : FormBase
	{
		#region Property
		private DataTable SourceDataTable;

		private DataTable TopDataTable;

		private DataTable SecDataTable;

		private DataTable ThirdDataTable;
		#endregion

		#region Private Method
		private void InitialDataTable(ref DataTable dt)
		{
			// dt.Clear();
			dt = new DataTable();
			dt.Columns.Add("MediaCompany", typeof(string));
			dt.Columns.Add("CreateDate", typeof(DateTime));
			dt.Columns.Add("AgentAccount", typeof(string));
			dt.Columns.Add("NetCafeId", typeof(int));
			dt.Columns.Add("BossSerialNo", typeof(string));
			dt.Columns.Add("Total", typeof(string));
			dt.Columns.Add("PauseAccount", typeof(int));
		}

		private void BindTopData()
		{
			InitialDataTable(ref SourceDataTable);

			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@StartDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate),
				new SqlParameter("@Total", SqlDbType.Int)
			};
			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_MediaCompanyRegQry",
				param
			);
			SourceDataTable = ds.Tables[0];
			lit_SumCounter.Text = param[param.Length - 1].Value.ToString();

			// 建立欄位
			InitialDataTable(ref TopDataTable);

			IEnumerable<IGrouping<string, DataRow>> result = SourceDataTable.Rows.Cast<DataRow>().GroupBy<DataRow, string>(dr => dr["AgentAccount"].ToString());
			foreach (IGrouping<string, DataRow> group in result)
			{
				TopDataTable.Rows.Add(group.ElementAt(0).ItemArray);
				//TopDataTable.LoadDataRow(group.ElementAt(0).ItemArray, true);
			}
			lit_SumCounterHeader.Visible = true;
			rpt_Top.DataSource = TopDataTable;
			rpt_Top.DataBind();
		}

		private DataTable BindSecData(string AgentAccount)
		{
			DataTable tmpdt = new DataTable();
			InitialDataTable(ref tmpdt);
			InitialDataTable(ref SecDataTable);
			string RowFilter = string.Format("AgentAccount='{0}'", AgentAccount);
			tmpdt = new DataView(SourceDataTable, RowFilter, "NetCafeId", DataViewRowState.CurrentRows).ToTable();

			IEnumerable<IGrouping<string, DataRow>> result = tmpdt.Rows.Cast<DataRow>().GroupBy<DataRow, string>(dr => dr["NetCafeId"].ToString());
			foreach (IGrouping<string, DataRow> group in result)
			{
				SecDataTable.LoadDataRow(group.ElementAt(0).ItemArray, true);
			}
			return SecDataTable;
		}

		private DataTable BindThirdData(string AgentAccount, string NetCafeID)
		{
			InitialDataTable(ref ThirdDataTable);
			string RowFilter = string.Format("AgentAccount='{0}' AND NetCafeID={1}", AgentAccount, NetCafeID);
			ThirdDataTable = new DataView(SourceDataTable, RowFilter, "BossSerialNo", DataViewRowState.CurrentRows).ToTable();

			return ThirdDataTable;
		}
		#endregion

		#region Protected Method
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btn_Query_Click(object sender, EventArgs e)
		{
			BindTopData();
		}

		protected void rpt_Top_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				HiddenField hdn = (HiddenField)e.Item.FindControl("hdn_AgentAccount");
				Repeater rpt = (Repeater)e.Item.FindControl("rpt_Sec");
				rpt.DataSource = BindSecData(hdn.Value);
				rpt.DataBind();
			}
		}

		protected void rpt_Sec_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				HiddenField hdn = (HiddenField)e.Item.FindControl("hdn_NetCafeID");
				HiddenField hdnAccount = (HiddenField)e.Item.FindControl("hdn_SecAgentAccount");
				TBGridView gv = (TBGridView)e.Item.FindControl("gv_Third");
				gv.DataSource = BindThirdData(hdnAccount.Value, hdn.Value);
				gv.DataBind();
			}
		}

		protected void gv_Third_DataBound(object sender, EventArgs e)
		{
			GridView gv = (GridView)sender;
			if (gv.Rows.Count == 0)
			{
				return;
			}
			int SumTotal = 0;
			foreach (GridViewRow gr in gv.Rows)
			{
				int count = int.TryParse(gr.Cells[1].Text, out count) ? count : 0;
				SumTotal += count;
			}
			//Literal lit = (Literal)gv.FooterRow.FindControl("lit_FooterTotal");
			//lit.Text = SumTotal.ToString();
			gv.FooterRow.Cells[0].Text = "總計";
			gv.FooterRow.Cells[1].Text = SumTotal.ToString();

		}

		protected void UCDateRange1_Change(object sender, EventArgs e)
		{
			BindTopData();
		}
		#endregion
	}
}