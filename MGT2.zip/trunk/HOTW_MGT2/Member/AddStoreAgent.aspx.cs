﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class AddStoreAgent : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{

				if (Request["mid"] == null)
				{
					GFC.Web.WebUtility.ResponseScript(Page, "alert('讀取上層資訊失敗');location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				}
				else
				{
					string[] aryAgentInfo = GetAgentInfo().Split(new char[] { '#' });
					lblCurrentPoints.Text = aryAgentInfo[0];
					lblCurrentRate.Text = aryAgentInfo[1];
					txtPoints.Text = "0";
					txtContributeRate.Text = "0";

				}

			}
		}

		/// <summary>
		/// 按下提交按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSubmitClick(object sender, EventArgs e)
		{
			if (!IsValid)
			{
				return;
			}
			if ((decimal.Parse(txtPoints.Text) > decimal.Parse(lblCurrentPoints.Text))&&txtPoints.Text.Trim().Length!=0)
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('不可超出上層持有點數');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			if (int.Parse(txtContributeRate.Text) > int.Parse(lblCurrentRate.Text))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('不可超出上層持有百分比');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}


			SqlParameter[] arParms =
			{
				new SqlParameter("@UpAgentID",Request["mid"].ToString()),
				new SqlParameter("@AgentAccount",txtAgentAccount.Text),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID),
				new SqlParameter("@AgentPassword",txtLoginPassword.Text),
				new SqlParameter("@AgentNickName",txtAgentNickName.Text),
				new SqlParameter("@Points",txtPoints.Text.Trim().Length==0?"0":txtPoints.Text),
				new SqlParameter("@ContributeRate",txtContributeRate.Text),
				new SqlParameter("@IdPassport",txtIdPassport.Text),
				new SqlParameter("@IsCreateTopAgent",Request["mid"].ToString().Equals("1")?"1":"0"),
				new SqlParameter("@Result",SqlDbType.TinyInt)
			};
			arParms[arParms.Length - 1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AddAgent", arParms);
			string strResult = arParms[arParms.Length - 1].Value.ToString();
			string strMessage = string.Empty;
			switch (strResult)
			{
				case "0":
					strMessage = "帳號新增成功";
					break;
				case "-1":
					strMessage = "帳號已存在";
					break;
				case "-2":
					strMessage = "暱稱已存在";
					break;
				default:
					strMessage = "餘額不足";
					break;
			}
			string strSource = strResult.Equals("0") ? string.Format("alert('{0}');location.href=document.referrer;", strMessage) : string.Format("alert('{0}');", strMessage);
			GFC.Web.WebUtility.ResponseScript(Page, strSource, GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void btnCloseClick(object sender, EventArgs e)
		{
			Response.Redirect("StoreAgent.aspx");
		}

		/// <summary>
		/// 取得上層代理的持有點數語與百分比
		/// </summary>
		/// <returns>
		/// 以'#'隔開的值
		/// <para>第一個值=點數</para>
		/// <para>第二個值=持有百分比</para>
		/// </returns>
		protected string GetAgentInfo()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@ID",Request["mid"].ToString()),
				new SqlParameter("@Points",SqlDbType.BigInt),
				new SqlParameter("@ContributeRate",SqlDbType.Int)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 2].Direction = ParameterDirection.Output;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GetAgentInfo", arParms);

			string aryInfo = string.Empty;
			aryInfo =
				(arParms[arParms.Length - 2].Value.ToString().Trim().Length == 0 ? "0" : arParms[arParms.Length - 2].Value.ToString())
					+ "#" +
					(arParms[arParms.Length - 1].Value.ToString().Trim().Length == 0 ? "0" : arParms[arParms.Length - 1].Value.ToString());
			return aryInfo;
		}
	}
}