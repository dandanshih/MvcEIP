﻿using GS.Utilities;
using GWeb.AppLibs;
using System;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;

namespace GWeb.Member
{
    public partial class A112 : FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_NickName.Text.Trim()))
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "alertError", "alert('請輸入暱稱!');", true);
                return;
            }
            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@NickName", txt_NickName.Text),
                new SqlParameter("@CalDate", ddl_DayList.SelectedValue),
                new SqlParameter("@MemberAccount", "")
            };
            gv_DataList.DataSource = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_GetCreditReturnList_Get",
                objParam
            );
            gv_DataList.DataBind();
        }
    }
}