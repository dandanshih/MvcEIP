﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;


namespace GWeb.Account
{
	public partial class MemberList_CS : AccountControlBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		public void btnQuery_Click(object sender, EventArgs e)
		{
			lblErrorMsg.Text = "";
			grdMember.Visible = false;
			grdMemberList.Visible = false;

			int iNoDataCount = 0;
			if (txtBirthday.Text.Trim() == "") iNoDataCount++;
			if (txtCellPhone.Text.Trim() == "") iNoDataCount++;
			if (txtIdentity.Text.Trim() == "") iNoDataCount++;

			if (iNoDataCount >= 3) return;

			if (txtAccount.Text.Trim().Length == 0 && txtNickName.Text.Trim().Length == 0) { return; }

			SqlParameter[] arParms =
			{
				new SqlParameter("@Account",txtAccount.Text),
				new SqlParameter("@NickName",txtNickName.Text),
				new SqlParameter("@Birthday",txtBirthday.Text),
				new SqlParameter("@Identity",txtIdentity.Text),
				new SqlParameter("@CellPhone",txtCellPhone.Text)
			};
			SqlDataReader sdr = null;
            try
            {
                sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_ConfirmMember", arParms);
                grdMember.DataSource = sdr;
                grdMember.DataBind();

                grdMember.Visible = true;


				//載入grdMemberList資料
				SqlParameter[] arParms1 =
			{
				new SqlParameter("@MemberID", grdMember.DataKeys[0].Value.ToString() )
			};

				DataSet ds = SqlHelper.ExecuteDataset(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_DetailData", arParms1);

				grdMemberList.DataSource = ds;
				grdMemberList.DataBind();
				grdMemberList.Visible = true;

            }
            catch (Exception ex)
            {
                WebErrorHandler eh = new WebErrorHandler((GWeb.AppLibs.FormBase)this.Page);
                eh.Process(ex, "", "");

                switch (sdr["Result"].ToString())
                {
                    case "1":
                        lblErrorMsg.Text = "查無此會員!!";
                        lblErrorMsg.Visible = true;
                        grdMember.Visible = false;
                        break;
                    case "2":
                        lblErrorMsg.Text = "資料錯誤，請跟會員重新確認!!";
                        lblErrorMsg.Visible = true;
                        grdMember.Visible = false;
                        break;
                }
            }

            finally
            {
                sdr.Close();
            }

				
		}

		protected void grdMember_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			int iRowIndex = Convert.ToInt32(e.CommandArgument);
			string MemberID = grdMember.DataKeys[iRowIndex]["MemberID"].ToString();

			switch (e.CommandName)
			{
				case "AccountStop":
					string LockDays = ((DropDownList)grdMember.Rows[iRowIndex].FindControl("cboPauseType")).SelectedValue;
					string LockReason = ((TextBox)grdMember.Rows[iRowIndex].FindControl("txtPauseInfo")).Text;
					int LockType;
					if (LockDays == "999")
					{
						LockType = 2;
					}
					else
					{
						LockType = 1;
					}
					PauseAccount(MemberID, e.CommandName, LockReason, LockDays, LockType);
					btnQuery_Click(null, null);
					break;
				case "AccountActive":
					PauseAccount(MemberID, e.CommandName, "", "0", 0);
					btnQuery_Click(null, null);
					break;
				case "ShowTel":
					Utility.ClientAlert(this, "客戶電話：" + grdMember.DataKeys[iRowIndex]["Mobile"].ToString());
					break;
				default:
					base.OnCommand(sender, e.CommandName, e.CommandArgument.ToString());
					break;
			}
		}

		protected void grdMember_DataBound(object sender, EventArgs e)
		{
			foreach (GridViewRow Row in grdMember.Rows)
			{
				string sTmp = grdMember.DataKeys[Row.RowIndex]["PauseAccount"].ToString();

				// 設定帳號的狀態
				Panel pnlAccount = (Panel)Row.FindControl("pnlAccount");
				Label lblPauseAccountStatus = (Label)Row.FindControl("lblPauseAccountStatus");
				Label lblLockInfo = (Label)Row.FindControl("lblLockInfo");
				lblLockInfo.Text = "";

				switch (sTmp)
				{

					// 啟用按鈕
					case "AccountActive":
						{
							lblPauseAccountStatus.Text = "異常";
							lblPauseAccountStatus.ForeColor = System.Drawing.Color.Red;

							// 隱藏相關元件
							DropDownList cboPauseType = (DropDownList)pnlAccount.FindControl("cboPauseType");
							cboPauseType.Visible = false;
							TextBox txtPauseInfo = (TextBox)pnlAccount.FindControl("txtPauseInfo");
							txtPauseInfo.Visible = false;
							RequiredFieldValidator RequiredFieldValidator1 = (RequiredFieldValidator)pnlAccount.FindControl("RequiredFieldValidator1");
							RequiredFieldValidator1.Visible = false;

							// 顯示停權原因
							lblLockInfo.Text = grdMember.DataKeys[Row.RowIndex]["MemberState"].ToString() +
											   (grdMember.DataKeys[Row.RowIndex]["MemberStateDesc"].ToString() == "" ? "" : "–" + grdMember.DataKeys[Row.RowIndex]["MemberStateDesc"].ToString());

							// 按鈕設定
							Button btnPauseAccount = (Button)pnlAccount.FindControl("btnPauseAccount");
							btnPauseAccount.Text = GetGlobalResourceObject("Resources", sTmp).ToString();
							if (sTmp == "AccountActive")
								btnPauseAccount.OnClientClick = "return confirm(\"確定啟用此帳號?\");";
							else
								btnPauseAccount.OnClientClick = "return confirm(\"確定通過此帳號的手機認證，成為正式帳號?\");";

							break;
						}

					// 停用相關的按鈕
					case "AccountStop":
						{
							lblPauseAccountStatus.Text = "正常";
							lblPauseAccountStatus.ForeColor = System.Drawing.Color.Green;
							Button btnPauseAccount = (Button)pnlAccount.FindControl("btnPauseAccount");
							btnPauseAccount.Text = GetGlobalResourceObject("Resources", sTmp).ToString();
							break;
						}
				}
			}
		}

		protected void grdMember_RowCreated(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				// 欄位【停用/啟用】內的 Control 設定
				foreach (System.Web.UI.Control ctl in e.Row.FindControl("pnlAccount").Controls)
				{
					switch (ctl.GetType().Name)
					{
						case "Button":
							((Button)ctl).ValidationGroup = "PauseAccount" + e.Row.RowIndex.ToString();
							((Button)ctl).CommandArgument = e.Row.RowIndex.ToString();
							break;
						case "TextBox":
							((TextBox)ctl).ValidationGroup = "PauseAccount" + e.Row.RowIndex.ToString();
							break;
						case "RequiredFieldValidator":
							((RequiredFieldValidator)ctl).ValidationGroup = "PauseAccount" + e.Row.RowIndex.ToString();
							break;
					}
				}
			}
		}

		protected bool PauseAccount(string sMemberID, string ActionType, string LockReason, string LockDays, int LockType)
		{
			bool bResult = false;


			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID",sMemberID),
				new SqlParameter("@LockDays",LockDays),
				new SqlParameter("@LockReason", LockReason),
				new SqlParameter("@LockType",LockType),
				new SqlParameter("@ExecAgentID",Int32.Parse(AUser.ExecAgentID))
			};

			try
			{
				SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_PauseAccount", arParms);
				switch (ActionType)
				{
					case "AccountStop": // 目前的動作是鎖定，所以啟動背景程式去踢 Server 上的玩家
                        //string sCmd = "267&" + AUser.SHID + "&" + sMemberID + "&0";
                        //Utility.SendInfoToFrontServer(AUser.FrontServerIP, sCmd);
                        
                        // 20110509 Phil: 改對前台發出登出命令
                        GameCommandHandler.LogoutMember(int.Parse(sMemberID));
						bResult = true;
						break;
					default:  //這是傳出空白字串，所以不做任何動作
						bResult = true;
						break;
				}
			}
			catch
			{
				bResult = false;
			}


			return bResult;
		}

        protected string GetMaskID(object ID)
        {
            string Str = Convert.ToString(ID);
            return Str.Length >= 4 ? Str.Substring(0, Str.Length - 4) + "****" : string.Empty.PadLeft(Str.Length, '*');
        }

		protected void grdMemberList_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			foreach (GridViewRow Rows in grdMemberList.Rows)
			{
				String st = Rows.Cells[2].Text;
				if (st == "0")
				{
					Rows.Cells[2].Text = GetGlobalResourceObject("Resources", "No").ToString();

				}
				else
				{
					Rows.Cells[2].Text = GetGlobalResourceObject("Resources", "Yes").ToString();
				}
			}
		}

	
	}
}