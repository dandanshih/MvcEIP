﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class StoreAgentChangePoints : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (Request["upid"] == null || Request["targetid"] == null || Request["changetype"] == null)
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('初始化失敗');location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else
			{
				switch (Request["changetype"].ToString())
				{
					case "0":
						lblAccountKind.Text = "代理商";
                        //lblAccount.Text = SqlHelper.ExecuteScalar
                        //    (WebConfig.connectionString, CommandType.Text, "SELECT AgentAccount FROM A_AGENT WHERE AgentID='" + Request["upid"].ToString() + "'").ToString();
                        SetAgentAccount(Request["upid"].ToString());
                        lblCurrentPoints.Text = GetAgentInfo(Request["upid"].ToString()).Split(new char[] { '#' })[0];

						lblChangePointsTip.Text = "存入點數";
						//lblChangePoints.Text = GetAgentInfo(Request["targetid"].ToString()).Split(new char[] { '#' })[0];
                        lblChangePoints.Text = GetAgentInfo(Request["upid"].ToString()).Split(new char[] { '#' })[0];
						break;
					case "1":
						lblAccountKind.Text = "會員";
                        //lblAccount.Text = SqlHelper.ExecuteScalar
                        //    (WebConfig.connectionString, CommandType.Text, "SELECT AgentAccount FROM A_AGENT WHERE AgentID='" + Request["targetid"].ToString() + "'").ToString();
                        SetAgentAccount(Request["targetid"].ToString());
                        lblCurrentPoints.Text = GetAgentInfo(Request["targetid"].ToString()).Split(new char[] { '#' })[0];

						lblChangePointsTip.Text = "提出點數";
                        //lblChangePoints.Text = GetAgentInfo(Request["upid"].ToString()).Split(new char[] { '#' })[0];
                        lblChangePoints.Text = GetAgentInfo(Request["targetid"].ToString()).Split(new char[] { '#' })[0];
						break;
				}
			}
		}

        /// <summary>
        /// 設定AgentAccount
        /// </summary>
        /// <param name="_AgentID"></param>
        private void SetAgentAccount(string _AgentID)
        {
            SqlParameter[] param =
			{
				new SqlParameter("@AgentID", _AgentID)
            };

            DataSet ds = SqlHelper.ExecuteDataset
                (
                    WebConfig.connectionString
                    , CommandType.StoredProcedure
                    , "NSP_AgentWeb_A_Agent_List"
                    , param
                );
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblAccount.Text = ds.Tables[0].Rows[0]["AgentAccount"].ToString();
            }
        }

		/// <summary>
		/// 取得上層代理的持有點數語與百分比
		/// </summary>
		/// <returns>
		/// 以'#'隔開的值
		/// <para>第一個值=點數</para>
		/// <para>第二個值=持有百分比</para>
		/// </returns>
		protected string GetAgentInfo(string id)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@ID",id),
				new SqlParameter("@Points",SqlDbType.BigInt),
				new SqlParameter("@ContributeRate",SqlDbType.Int)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 2].Direction = ParameterDirection.Output;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GetAgentInfo", arParms);

			string aryInfo = string.Empty;
			aryInfo =
				(arParms[arParms.Length - 2].Value.ToString().Trim().Length == 0 ? "0" : arParms[arParms.Length - 2].Value.ToString())
					+ "#" +
					(arParms[arParms.Length - 1].Value.ToString().Trim().Length == 0 ? "0" : arParms[arParms.Length - 1].Value.ToString());
			return aryInfo;
		}

		/// <summary>
		/// 開洗分操作
		/// </summary>
		protected void KeyInOut(object sender,EventArgs e)
		{
			SqlParameter[] arParms =
		    {
		        new SqlParameter("@UpAgentID",Request["upid"].ToString()),
		        new SqlParameter("@TragetAgentID",Request["targetid"].ToString()),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID),
				new SqlParameter("@ChangeType",Request["changetype"].ToString()),
				new SqlParameter("@ChangePoints",txtChangePoints.Text),
				new SqlParameter("@Result",SqlDbType.TinyInt)
		    };

			arParms[arParms.Length - 1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AgentChangePoints", arParms);
			
			string strResult=arParms[arParms.Length - 1].Value.ToString();
			string strMessage = string.Empty;
			switch (strResult)
			{
 				case "0":
					strMessage = Request["changetype"].ToString().Equals("0") ? "存入成功" : "提出成功";
					break;
				case "-1":
					strMessage = "超過現有額度";
					break;
				case "-2":
					strMessage = "存入點數為0";
					break;
			}
			if (strResult.Equals("0"))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('" + strMessage + "');location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			else
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		protected void btnCloseClick(object sender, EventArgs e)
		{
			Response.Redirect("StoreAgent.aspx", true);
		}
	}
}