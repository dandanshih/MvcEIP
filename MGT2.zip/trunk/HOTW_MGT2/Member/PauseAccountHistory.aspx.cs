﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;
using System.Web.UI;

namespace GWeb.Member
{
	public partial class PauseAccountHistory : GWeb.AppLibs.FormBase
	{
		private void SetLock(string memberID, int lockType)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID", memberID),
				new SqlParameter("@LockDays", "0"),
				new SqlParameter("@LockType", lockType),
				new SqlParameter("@LockReason", string.Empty),
				new SqlParameter("@ExecAgentID", AUser.ExecAgentID)
			};

			string strResult = string.Empty;
			string strMessage = string.Empty;
			try
			{
				strResult = SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_PauseAccount", arParms).ToString();

				switch (strResult)
				{
					case "0":
						strMessage = "設定成功";
						break;
					default:
						strMessage = "設定失敗";
						break;
				}
			}
			catch (Exception ex)
			{
				strMessage = ex.Message;
			}

			//啟用成功後，才重新載入資料
			if (strResult.Equals("0"))
			{
				LoadData();
			}

			GFC.Web.WebUtility.ResponseScript(Page, "alert('" + strMessage + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			//SqlParameter[] arParms =
			//{
			//	new SqlParameter("@MemberAccount",txtMemberAccount.Text),
			//	new SqlParameter("@NickName",txtNickName.Text),
			//	new SqlParameter("@StartDate",DateRange1.StartDate),
			//	new SqlParameter("@EndDate",DateRange1.EndDate),
			//	new SqlParameter("@PageSize",Pager1.PageSize),
			//	new SqlParameter("@PageIndex",Pager1.CurrentPageNumber),
			//	new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			//};

			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount",txtMemberAccount.Text),
				new SqlParameter("@NickName",txtNickName.Text),
			    new SqlParameter("@PageSize",Pager1.PageSize),
				new SqlParameter("@PageIndex",Pager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_Member_PauseAccount_History", arParms);

			gvPauseAccount.DataSource = sdr;
			gvPauseAccount.DataBind();
			sdr.Close();

			Pager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			Pager1.DataBind();
		}


		protected void Page1_Change(object sender, GWeb.AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			LoadData();
		}

		/// <summary>
		///  按下查詢紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			Pager1.CurrentPageNumber = 1;
			LoadData();
		}

		protected void gvPauseAccount_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "SetLock")
			{
				string memberID = e.CommandArgument.ToString().Split(',')[0];
				string alarmType = e.CommandArgument.ToString().Split(',')[1];

				if (alarmType != "0")
				{
					SetLock(memberID, 0);
				}
				else if (alarmType != "2")
				{
					SetLock(memberID, 2);
				}
			}
		}

		protected void GridViewRow_DataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				AuthButton btnSetBlacklist = (AuthButton)e.Row.FindControl("btnSetLock");

				if (DataBinder.Eval(e.Row.DataItem, "IsShowBtn").ToString() == "0")
				{
					btnSetBlacklist.Text = "停用";
					btnSetBlacklist.OnClientClick = "return confirm('確定停用此帳號');";
				}
				else if (DataBinder.Eval(e.Row.DataItem, "IsShowBtn").ToString() != "0")
				{
					btnSetBlacklist.Text = "啟用";
					btnSetBlacklist.OnClientClick = "return confirm('確定啟用此帳號');";
				}
			}
		}
	}
}