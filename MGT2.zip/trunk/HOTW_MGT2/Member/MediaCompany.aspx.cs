﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using GFC.Utilities;
using GWeb.AppLibs;
using System.Reflection;

namespace GWeb.Member
{
    public partial class MediaCompany : GWeb.AppLibs.FormBase
    {
        #region private

        /// <summary>
        /// 載入資料列表
        /// </summary>
        private void LoadData()
        {
			string MemberAccount = ddl_MediaCompanyList.SelectedValue;

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_MediaCompanySelect",
                new SqlParameter("@Account", MemberAccount)
            );

            if (objDr.Read())
            {
                lblMediaCompary.Text = objDr["MediaCompany"].ToString();
                lblCreateDate.Text = objDr["CreateDate"].ToString();
                lblAgentAccount.Text = objDr["AgentAccount"].ToString();
                if (int.Parse(objDr["PauseAccount"].ToString()) > 0)
                {
                    btnPauseGroup.CommandArgument = "0";
                    btnPauseGroup.Text = "公司啟用";
                }
                else
                {
                    btnPauseGroup.CommandArgument = "1";
                    btnPauseGroup.Text = "公司停用";
                }
            }

            objDr.Close();



            DataTable objDt = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_MediaCompanySerialNoSelect",
                new SqlParameter("@Account", MemberAccount)
            ).Tables[0];

            dlSerialNoDetail.DataSource = objDt;
            dlSerialNoDetail.DataBind();
        }

        /// <summary>
        /// 重設密碼
        /// </summary>
        /// <param name="GroupID"></param>
        private void ResetPassword()
        {
            SqlParameter[] param =
            {
                new SqlParameter("@Account", lblAgentAccount.Text)
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_MediaCompanyResetPW",
                param
            );

            ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('密碼已重設');", true);
        }

        /// <summary>
        /// 公司啟用/停用
        /// </summary>
        /// <param name="GroupID"></param>
        private void PauseCompany(string IsPause)
        {
            SqlParameter[] param =
            {
                new SqlParameter("@AgentAccount", lblAgentAccount.Text),
                new SqlParameter("@ExecuteAgentAccount", AUser.ExecAgentAccount),
                new SqlParameter("@PauseAccount", IsPause)       
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_MediaCompanyPause",
                param
            );

            ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", string.Format("alert('{0}');", IsPause == "0" ? "公司已啟用" : "公司已停用"), true);
        }

        /// <summary>
        /// 新增序號
        /// </summary>
        /// <param name="SerialNo"></param>
        private bool InsertSerialNo(string SerialNo)
        {
            if (string.IsNullOrEmpty(SerialNo))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('請輸入序號');", true);
                return false;
            }

            SqlParameter[] param =
            {
                new SqlParameter("@Account", lblAgentAccount.Text),
                new SqlParameter("@SerialNo", SerialNo)
                
            };

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_MediaCompanyMountSerialNo",
                param
            );

            objDr.Read();

            string ErrorMsg = "";
            switch (objDr[0].ToString())
            {
                case "0":
                    break;
                case "-1":
                    ErrorMsg = "序號不存在";
                    break;
                case "-2":
                    ErrorMsg = "此序號已附屬於別的公司";
                    break;
                case "-3":
                    ErrorMsg = "公司帳號已停權";
                    break;
                case "-4":
                    ErrorMsg = "非GameGirl序號";
                    break;
                default:
                    ErrorMsg = "新增序號失敗";
                    break;
            }

            objDr.Close();

            if (string.IsNullOrEmpty(ErrorMsg))
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('序號已新增');", true);
                return true;
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", string.Format("alert('{0}');", ErrorMsg), true);
                return false;
            }
        }

        #endregion

        #region protected

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // LoadData();
            } 
        }

        /// <summary>
        /// 密碼重設/公司啟用(停用)/新增金庫序號
        /// </summary>
        protected void btn_Command(object source, CommandEventArgs e)
        {
            switch (e.CommandName)
            {
                // 重設密碼
                case "ResetPassword":
                    ResetPassword();
                    LoadData();
                    break;
                // 公司停用
                case "PauseGroup":
                    PauseCompany(e.CommandArgument.ToString());
                    LoadData();
                    break;
                // 新增金庫序號
                case "AddSerialNo":
                    if (InsertSerialNo(txtSerialNo.Text))
                    {
                        LoadData();
                    }
                    break;
            }
        }

        protected void dlSerialNoDetail_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            Button btn = (Button)e.Item.FindControl("btnSerialNo");
            DataRowView Item = (DataRowView)e.Item.DataItem;
            if (bool.Parse(Item["IsEnable"].ToString()))
            {
                btn.Text = "序號停用";
                btn.CommandArgument = "0";
            }
            else
            {
                btn.Text = "序號啟用";
                btn.CommandArgument = "1";
            }
        }

        /// <summary>
        /// 序號啟用/停用
        /// </summary>
        protected void dlSerialNoDetail_ItemCommand(object sender, DataListCommandEventArgs e)
        {
            string SerialNo = e.CommandArgument.ToString();
            
            SqlParameter[] param =
            {
                new SqlParameter("@SerialNo", e.CommandName),
                new SqlParameter("@IsEnable", e.CommandArgument.ToString()),
				new SqlParameter("@MediaCompany", ddl_MediaCompanyList.Text)
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_MediaCompanyPauseSerialNo",
                param
            );

            LoadData();

            ScriptManager.RegisterStartupScript
            (
                this.Page, 
                GetType(), 
                "alert", 
                string.Format("alert('{0}');", e.CommandArgument.ToString() == "0" ? "序號已停用" : "序號已啟用"), 
                true
            );
        }

		protected void btn_ResetPW_Click(object sender, EventArgs e)
		{
			AuthButton btn = (AuthButton)sender;
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@SerialNo", btn.CommandArgument.ToString()),
				new SqlParameter("@MediaCompany", ddl_MediaCompanyList.Text)
			};
			SqlHelper.ExecuteNonQuery
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_MediaCompanyRemoveSerialNo",
				param
			);
			LoadData();
		}

		protected void ddl_MediaCompanyList_SelectedIndexChanged(object sender, EventArgs e)
		{
			LoadData();
		}
        #endregion
    }
}