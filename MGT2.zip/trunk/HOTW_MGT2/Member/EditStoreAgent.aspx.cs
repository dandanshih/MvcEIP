﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class EditStoreAgent : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{

				if (Request["upid"] == null||Request["agentacc"]==null)
				{
					GFC.Web.WebUtility.ResponseScript(Page, "alert('讀取上層資訊失敗');location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				}
				else
				{
					GetAgentData();
					lblCurrentRate.Text = GetAgentInfo().Split(new char[] { '#' })[1];
				}

			}
		}

		/// <summary>
		/// 按下提交按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSubmitClick(object sender, EventArgs e)
		{
			if (!IsValid)
			{
				return;
			}

			if ((txtLoginPassword.Text.Trim().Length != 0 || txtLoginPasswordConfirm.Text.Trim().Length != 0) && (txtLoginPassword.Text != txtLoginPasswordConfirm.Text))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('登入密碼與確認密碼不一致');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			if (int.Parse(txtContributeRate.Text) > int.Parse(lblCurrentRate.Text))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('不可超出上層持有百分比');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}


			SqlParameter[] arParms =
			{
				new SqlParameter("@TargetID",btnSubmit.CommandArgument),
				new SqlParameter("@NickName",txtAgentNickName.Text),
				new SqlParameter("@Password",txtLoginPassword.Text),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID),
				new SqlParameter("@ContributeRate",txtContributeRate.Text),
				new SqlParameter("@Result",SqlDbType.TinyInt)
			};
			arParms[arParms.Length - 1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_EditAgent", arParms);
			string strResult = arParms[arParms.Length - 1].Value.ToString();
			string strMessage = string.Empty;
			switch (strResult)
			{
				case "0":
					strMessage = "帳號修改成功";
					break;
				case "-1":
					strMessage = "暱稱重複";
					break;
				case "-2":
					strMessage = "暱稱空白";
					break;
				default:
					strMessage = "持有百分比 【大於上階】 或 【小於下階】";
					break;
			}
			string strSource = strResult.Equals("0") ? string.Format("alert('{0}');location.href=document.referrer;", strMessage) : string.Format("alert('{0}');", strMessage);
			GFC.Web.WebUtility.ResponseScript(Page, strSource, GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void btnCloseClick(object sender, EventArgs e)
		{
			Response.Redirect("StoreAgent.aspx");
		}

		/// <summary>
		/// 取得上層代理的持有點數語與百分比
		/// </summary>
		/// <returns>
		/// 以'#'隔開的值
		/// <para>第一個值=點數</para>
		/// <para>第二個值=持有百分比</para>
		/// </returns>
		protected string GetAgentInfo()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@ID",Request["upid"].ToString()),
				new SqlParameter("@Points",SqlDbType.BigInt),
				new SqlParameter("@ContributeRate",SqlDbType.Int)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
			arParms[arParms.Length - 2].Direction = ParameterDirection.Output;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GetAgentInfo", arParms);

			string aryInfo = string.Empty;
			aryInfo =
				(arParms[arParms.Length - 2].Value.ToString().Trim().Length == 0 ? "0" : arParms[arParms.Length - 2].Value.ToString())
					+ "#" +
					(arParms[arParms.Length - 1].Value.ToString().Trim().Length == 0 ? "0" : arParms[arParms.Length - 1].Value.ToString());
			return aryInfo;
		}

		/// <summary>
		/// 載入欲修改帳號資料
		/// </summary>
		protected void GetAgentData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@Account",Request["agentacc"].ToString())
			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_GetTechnicalCSByAccount", arParms);
			if (sdr.Read())
			{
				txtAgentAccount.Text = sdr["AgentAccount"].ToString();
				txtAgentNickName.Text = sdr["AgentNickName"].ToString();
				txtIdPassport.Text = sdr["IDPassport"].ToString();
				txtContributeRate.Text = Math.Truncate(decimal.Parse(sdr["ContributeRate"].ToString())).ToString();
				btnSubmit.CommandArgument = sdr["AgentID"].ToString();
			}
			sdr.Close();
		}
	}
}