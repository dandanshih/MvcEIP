﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class EditMember : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadData();
			}

			// 紅利回饋人 2011/09/07 後才出現
			//if (DateTime.Now < DateTime.Parse("2011-09-07 00:00:00"))
			//{
			//    trIntroducer.Visible = false;
			//}
		}

		protected void lbReturn_Click(object sender, EventArgs e)
		{
			Response.Redirect("MemberQuery.aspx", true);
		}

		/// <summary>
		/// 讀取會員資料
		/// </summary>
		protected void LoadData()
		{

			if (Request["mid"] == null)
			{
				WebUtility.ResponseScript(Page, "alert('" + @"查無此會員資料\n將返回管理頁面" + "');location.href='MemberQuery.aspx'", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);

				//Response.Redirect("MemberQuery.aspx");
			}

			SqlParameter[] param =
			{
				new SqlParameter("@MemberID", Int32.Parse(Request["mid"].ToString()))
			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_DetailData", param);

			if (sdr.Read())
			{
				tbxLoginID.Text = sdr["MemberAccount"].ToString();
				tbxCustName.Text = sdr["RealName"].ToString();
				txtMemberID.Text = sdr["MemberID"].ToString();
				tbxNickName.Text = sdr["NickName"].ToString();
				tbxTelMobile.Text = sdr["Mobile"].ToString();
				tbxEMail.Text = sdr["Email"].ToString();
				tbxCustPID.Text = sdr["IdPassport"].ToString().Replace(" ", "");
				txtBirth.Text = !string.IsNullOrEmpty(sdr["Birthday"].ToString()) ? DateTime.Parse(sdr["Birthday"].ToString()).ToString("yyyy/MM/dd") : "";
				rblUserSex.SelectedValue = sdr["Gender"].ToString().Equals("True") ? "先生" : "小姐";
				UCAddress1.CityID = Convert.ToInt32(sdr["CityID"]);
				UCAddress1.ZoneID = sdr["ZoneID"].ToString();
				UCAddress1.Address = sdr["Address"].ToString();
				cbxIsJoinAdv.Checked = sdr["NewsYN"].ToString() == "0" ? false : true;
				rbl_InVoice_Type.SelectedValue = sdr["Invoice_Type"].ToString();
				UCAddress2.CityID = Convert.ToInt32(sdr["Invoice_CityID"]);
				UCAddress2.ZoneID = sdr["Invoice_ZoneID"].ToString();
				UCAddress2.Address = sdr["Invoice_Address"].ToString();
				txt_Invoice_Recipient.Text = sdr["Invoice_Recipient"].ToString();
				txtIntroducer.Text = sdr["Introducer"].ToString();
				ViewState["MemberIdentity"] = sdr["MemberIdentity"].ToString();
				ViewState["MemberType"] = sdr["MemberType"].ToString();
				rblMemberIdentity.SelectedValue = ViewState["MemberIdentity"].ToString().Contains("一般") ? "1" : "2";
			}
			sdr.Close();

			if (ViewState["MemberType"].ToString().Contains("1"))
			{
				tbxLoginPassword.Enabled = false;
				tbxConfirmPassword.Enabled = false;

				tbxCustName.Enabled = false;
				txtMemberID.Enabled = false;
				tbxNickName.Enabled = false;

				//if (tbxTelMobile.Text.Length > 0)
				//{
				//    tbxTelMobile.Enabled = false;
				//}
				//else
				//{
				//    tbxTelMobile.Enabled = true;
				//}

				//if (txtIntroducer.Text.Length > 0)
				//{
				//    txtIntroducer.Enabled = false;
				//}
				//else
				//{
				//    txtIntroducer.Enabled = true;
				//}
			}
			else
			{
				tbxLoginPassword.Enabled = true;
				tbxConfirmPassword.Enabled = true;

				tbxCustName.Enabled = true;
				txtMemberID.Enabled = false;
				tbxNickName.Enabled = false;
				//tbxTelMobile.Enabled = false;
				//txtIntroducer.Enabled = false;

				//if (tbxTelMobile.Text.Length > 0)
				//{
				//    tbxTelMobile.Enabled = false;
				//}
				//else
				//{
				//    tbxTelMobile.Enabled = true;
				//}

				//if (txtIntroducer.Text.Length > 0)
				//{
				//    txtIntroducer.Enabled = false;
				//}
				//else
				//{
				//    txtIntroducer.Enabled = true;
				//}
			}
		}

		protected void btnClose_Click(object sender, EventArgs e)
		{
			//Response.Redirect("MemberQuery.aspx");
			WebUtility.ResponseScript(Page, "location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			//欄位驗證不過就離開
			string ResultValidForm = string.Empty;
			if (!ValidMemberForm(out ResultValidForm))
			{
				WebUtility.ResponseScript(Page, "alert('" + ResultValidForm + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount",tbxLoginID.Text),
				new SqlParameter("@MemberPassword",tbxLoginPassword.Text.Trim()),
				new SqlParameter("@RealName",tbxCustName.Text),
				new SqlParameter("@NickName",tbxNickName.Text),
				new SqlParameter("@Email",tbxEMail.Text),
				new SqlParameter("@Birthday", string.IsNullOrEmpty(txtBirth.Text.Trim()) ? (object)System.DBNull.Value : txtBirth.Text),
				new SqlParameter("@Mobile",tbxTelMobile.Text),
				new SqlParameter("@IdPassport",tbxCustPID.Text),
				new SqlParameter("@Gender",(rblUserSex.Items[0].Selected) ? 1 : 0),
				new SqlParameter("@OnlineIP",Request.ServerVariables["REMOTE_ADDR"].ToString()),
				new SqlParameter("@ZoneID", UCAddress1.ZoneID),
				new SqlParameter("@Address", UCAddress1.Address.ToSafeString()),
				new SqlParameter("@NewsYN",cbxIsJoinAdv.Checked?1:0),
				new SqlParameter("@Invoice_Type",int.Parse(rbl_InVoice_Type.SelectedValue)),
				new SqlParameter("@Invoice_ZoneID", UCAddress2.ZoneID),
				new SqlParameter("@Invoice_Address", UCAddress2.Address.ToSafeString()),
				new SqlParameter("@Invoice_Recipient",txt_Invoice_Recipient.Text),
				new SqlParameter("@IntroducerNickName",txtIntroducer.Text),
				new SqlParameter("@ExecAgentID",AUser.ExecAgentID)
			};

			string resultCode = string.Empty;
			string strResult = string.Empty;
			try
			{
				resultCode = SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_Edit", arParms).ToString();
			}
			catch (Exception ex)
			{
				resultCode = ex.Message;
				log4net.LogManager.GetLogger(typeof(EditMember)).DebugFormat("修改資料失敗，錯誤訊息: {0}", ex.Message);
			}
			finally
			{
				switch (resultCode)
				{
					case "0":
						strResult = "帳號修改成功";
						WebUtility.ResponseScript(Page, "alert('" + strResult + "');location.href=document.referrer;", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
						break;
					case "1":
						strResult = "系統錯誤";
						break;
					case "2":
						strResult = "此手機已申請過無法再使用";
						break;
					case "3":
						strResult = "推薦人不存在";
						break;
					case "4":
						strResult = "推薦人不可填自己";
						break;
					case "5":
						strResult = "推薦人不為老幣會員或未完成認證";
						break;
					case "6":
						strResult = "推薦人停權中";
						break;
					case "7":
						strResult = "未手機驗證不能修改手機";
						break;
					case "11":
						strResult = "主帳號未手機驗證";
						break;
					case "12":
						strResult = "帳號停用中，不能合併";
						break;
					case "13":
						strResult = "可加入帳號額度已滿";
						break;
					case "14":
						strResult = "非官網帳號";
						break;
					case "15":
						strResult = "該帳號目前在線上，無法併入";
						break;
					case "16":
						strResult = "全站新增/合併帳號功能被停用";
						break;
					case "17":
						strResult = "限普卡以上";
						break;
					case "18":
						strResult = "主帳號未通過手機驗證";
						break;
					case "19":
						strResult = "此帳號已被合併，無法修改手機號碼";
						break;
					case "20":
						strResult = "主帳號不符合資格";
						break;
                    case "21":
                        strResult = "該帳號手機綁定群組有部分會員在線上，無法併入";
                        break;
					default:
						strResult = "帳號建立時發生錯誤，請稍候再執行一次，或請洽客服中心";
						break;
				}

				WebUtility.ResponseScript(Page, "alert('" + resultCode + "：" + strResult + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}

		}
		/// <summary>
		/// 驗證暱稱是否重複。
		/// </summary>
		/// <returns></returns>
		private string ValidateDoubleNickName()
		{
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@CheckType", 2),
                new SqlParameter("@CheckData",tbxNickName.Text.ToSafeString())
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_A_Member_CheckDuplicateAccount",
														   param);

			string message = "";
			int result = 0;

			if (objDtr.Read())
			{
				result = int.Parse(objDtr["Result"].ToString());
			}

			objDtr.Close();

			switch (result)
			{
				case 0:
					message = string.Empty;
					break;
				case 11:
				case 12:
					message = "此暱稱已有人使用，請改用其他暱稱;";
					break;
				case 13:
					message = "此暱稱正在等待驗證中，目前無法使用此暱稱!";
					break;
				default:
					message = "此暱稱無法使用!";
					break;
			}

			//WebUtility.ResponseScript(Page, message, WebUtility.ResponseScriptPlace.NearFormEnd);

			return message;
		}
		/// <summary>
		/// 驗證基本資料頁表單
		/// </summary>
		private bool ValidMemberForm(out string errorMessage)
		{
			// string memberVIP = "VIP會員";

			errorMessage = "";

			string tmp = "";
			int iTmp = 0;

			// 將送出按鈕還原為可點選狀態

			tbxCustName.Text = tbxCustName.Text.Trim();
			tbxLoginID.Text = tbxLoginID.Text.Trim().Replace(" ", "");
			tbxLoginPassword.Text = tbxLoginPassword.Text.Trim().Replace(" ", "");
			tbxEMail.Text = tbxEMail.Text.Trim().Replace(" ", "");
			tbxTelMobile.Text = tbxTelMobile.Text.Trim().Replace(" ", "");
			tbxNickName.Text = tbxNickName.Text.Trim();

			tmp = tbxLoginID.Text;
			if (tmp.Trim() == "")
			{

				errorMessage = "登入帳號不可空白";
				return false;
			}
			//else if (tmp.Length < 6 || tmp.Length > 12
			//    || !System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9a-zA-Z]*$"))
			//{

			//    errorMessage = "登入帳號必須是 6 ~ 12 碼的英文數字組合";
			//    return false;
			//}
			else if (int.TryParse(tmp, out iTmp))
			{

				errorMessage = "帳號至少須包含一個英文字母";
				return false;
			}
			//else if (tbxTelMobile.Text.Length > 0 && tbxLoginID.Text.IndexOf(tbxTelMobile.Text) > -1)
			//{

			//	errorMessage = "帳號中不可包含您的手機號碼";
			//	return false;
			//}
			//else if (tbxEMail.Text.IsEMail() && tbxLoginID.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1)
			//{

			//    errorMessage = "帳號中不可包含您的EMail";
			//    return false;
			//}



			if (tbxLoginPassword.Text.Trim().Length == 0)
			{

				//errorMessage = "密碼不可空白";
				//return false;
			}
			else if (!IsValidRegular_MemberPassword(tbxLoginPassword.Text.ToUpper(), out errorMessage))
			{

				return false;
			}
			else if ((tbxLoginID.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxLoginID.Text) > -1)
				|| (tbxTelMobile.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxTelMobile.Text) > -1)
				|| (tbxNickName.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxNickName.Text) > -1)
				|| (tbxEMail.Text.IsEMail() && tbxLoginPassword.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1))
			{

				errorMessage = "密碼中不可包含帳號、手機號碼、暱稱或EMail";
				return false;
			}
			if (tbxLoginPassword.Text.Trim().Length != 0)
			{
				if (tbxConfirmPassword.Text.Trim() == "")
				{

					errorMessage = "確認密碼不可空白";
					return false;
				}
				else if (tbxConfirmPassword.Text != tbxLoginPassword.Text)
				{

					errorMessage = "與上面的密碼不相同";
					return false;

				}
				ViewState["tbxLoginPassword"] = tbxLoginPassword.Text.ToSafeString();
				ViewState["tbxConfirmPassword"] = tbxConfirmPassword.Text.ToSafeString();
			}


			if (tbxEMail.Text.Trim().Length > 0 && !tbxEMail.Text.IsEMail())
			{

				errorMessage = "E-Mail格式錯誤";
				return false;
			}



			//if (tbxCustName.Text == "")
			//{

			//    errorMessage = "姓名不可空白";
			//    return false;
			//}
			if (tbxNickName.Text == "")
			{
				errorMessage = "暱稱不可空白";
				return false;
			}
			//else if ((tbxLoginID.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxLoginID.Text) > -1)
			//		|| (tbxTelMobile.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxTelMobile.Text) > -1))
			//{

			//	errorMessage = "暱稱中不可包含帳號或手機號碼";
			//	return false;
			//}

			// 暱稱中不可包含逗點
			if (!System.Text.RegularExpressions.Regex.IsMatch(tbxNickName.Text, "^[A-Za-z0-9\u4E00-\u9FA5\uF900-\uFA2D]+$"))
			{
				errorMessage = "玩家暱稱不能包含特殊符號";
				return false;
			}

			// 暱稱字數檢查
			if (tbxNickName.Text.Trim().Length > 10)
			{
				errorMessage = "暱稱請輸入10個中英文或數字";
				return false;
			}
			//int intNickNameLength = 0;
			//foreach (char c in tbxNickName.Text)
			//{
			//    if (c >= 0x3000 && c <= 0x9fff)
			//    {
			//        intNickNameLength += 2;
			//    }
			//    else
			//    {
			//        intNickNameLength += 1;
			//    }
			//}
			//if (intNickNameLength > 10)
			//{

			//    errorMessage = "暱稱請輸入10個中英文或數字";
			//    return false;
			//}
			//檢查暱稱是否可使用
			//errorMessage = ValidateDoubleNickName();
			//if (errorMessage.Length != 0)
			//{
			//    return false;
			//}
			//if (!(ddlBirthYear.Text + "/" + ddlBirthMonth.Text + "/" + ddlBirthDay.Text).IsDate())
			//{

			//    errorMessage = "日期錯誤";
			//    return false;
			//}

			if (tbxCustPID.Text.Trim().Length > 0)
			{
				if (!tbxCustPID.Text.IsNumeric())
				{
					errorMessage = "身份證或護照後四碼只能有數字";
					return false;
				}
				else if (tbxCustPID.Text.Length < 4)
				{
					errorMessage = "身份證或護照後四碼不能小於4位數";
					return false;
				}
			}

			//if (tbxCustPID.Text.Trim().Length == 0 && ViewState["MemberIdentity"].ToString().ToUpper().Contains("VIP"))
			//{

			//    errorMessage = "身分證末四碼不可空白";
			//    return false;
			//}

			//if (tbxCustPID.Text.Trim().Length != 4 && ViewState["MemberIdentity"].ToString().ToUpper().Contains("VIP"))
			//{

			//    errorMessage = "請填寫末四碼";
			//    return false;
			//}

			//if (tbxTelHome.Text.Trim() != "")
			//{
			//    tmp = tbxTelHome.Text.Trim();
			//    if (!(tmp.IsNumeric() && tmp.Length > 8 && tmp.Length < 11 && tmp.Substring(0, 1) == "0"))
			//    {

			//        errorMessage = "電話不正確";
			//        return false;
			//    }
			//}

			// 選擇索取發票
			if (rbl_InVoice_Type.SelectedValue == "2")
			{
				// 檢查發票地址
				if (string.IsNullOrEmpty(UCAddress2.Address))
				{

					errorMessage = "請輸入發票地址";
					return false;
				}

				// 檢查發票收件人
				if (string.IsNullOrEmpty(txt_Invoice_Recipient.Text))
				{

					errorMessage = "請輸入發票收件人";
					return false;
				}
			}
			else if (rbl_InVoice_Type.SelectedValue == "1")
			{
				// 檢查Email
				//if (string.IsNullOrEmpty(tbxEMail.Text))
				//{
				//    errorMessage = "請輸入Email";
				//    return false;
				//}

				// 檢查姓名
				if (string.IsNullOrEmpty(tbxCustName.Text))
				{
					errorMessage = "請輸入姓名";
					return false;
				}
			}


			tmp = tbxTelMobile.Text.Trim();
			//if (tmp.Length == 0 && ViewState["MemberIdentity"].ToString().ToUpper().Contains("VIP"))
			//{

			//    errorMessage = "手機不可空白";
			//    return false;
			//}
			if (!(tmp.IsNumeric() && tmp.Length == 10 && tmp.Substring(0, 2) == "09") && ViewState["MemberIdentity"].ToString().ToUpper().Contains("VIP"))
			{

				errorMessage = "手機格式錯誤";
				return false;
			}

			return true;
		}


		/// <summary>
		/// 檢查密碼的格式是否正確
		/// </summary>
		/// <param name="passWord">要檢查的密碼字串</param>
		/// <param name="invalidText">要傳回的錯誤訊息</param>
		/// <returns></returns>
		protected bool IsValidRegular_MemberPassword(string passWord, out string invalidText)
		{
			passWord = passWord.Trim().Replace(" ", "");
			invalidText = "";

			int iTmp = 0;
			string sTmp = "";
			if (int.TryParse(passWord, out iTmp))
			{
				invalidText = "密碼至少須包含一個英文字母";
				return false;
			}

			if (passWord.Length < 6 || passWord.Length > 12)
			{
				invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
				return false;
			}
			iTmp = 0;
			for (int i = 0; i < passWord.Length; i++)
			{
				int code = passWord[i];
				if (sTmp.IndexOf(passWord[i]) == -1)
				{ // 把不同的文字加進暫存變數, 等下要判斷有幾種字元
					sTmp += passWord[i].ToString();
				}
				if (!((code >= 48 && code <= 57) || (code >= 65 && code <= 90) || (code >= 97 && code <= 122)))
				{
					invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
					return false;
				}

				// 如果往後的 3 個字元都是連續字元(例如 123、abc、321、cba、..), 就傳出錯誤
				//if (passWord.Length - i > 2 &&
				//        (
				//        passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
				//                                    + Convert.ToChar(code + 1).ToString()
				//                                    + Convert.ToChar(code + 2).ToString())
				//            ||
				//         passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
				//                                    + Convert.ToChar(code - 1).ToString()
				//                                    + Convert.ToChar(code - 2).ToString())
				//        ))
				//{
				//    invalidText = "密碼不可包含 3 個連續數字或 3 個連續字母";
				//    return false;
				//}
			}
			if (sTmp.Length < 4)
			{
				invalidText = "密碼必須包含 4 種字元以上";
				return false;
			}

			return true;

		}
	}
}