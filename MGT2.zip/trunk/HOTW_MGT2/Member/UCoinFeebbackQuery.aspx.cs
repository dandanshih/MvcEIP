﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class UCoinFeebbackQuery : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount",txtAccount.Text),
				new SqlParameter("@BeginDate",DateRange1.StartDate),
				new SqlParameter("@EndDate",DateRange1.EndDate),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",UCPager1.PageSize),
				new SqlParameter("@TotalRow",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_XXX", arParms);

			gv.DataSource = sdr;
			gv.DataBind();
			sdr.Close();

			UCPager1.FirstText = GetGlobalResourceObject("Pager", "FirstText").ToString();
			UCPager1.PreviousText = GetGlobalResourceObject("Pager", "PreviousText").ToString();
			UCPager1.NextText = GetGlobalResourceObject("Pager", "NextText").ToString();
			UCPager1.LastText = GetGlobalResourceObject("Pager", "LastText").ToString();
			UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());

			UCPager1.DataBind();
		}
		/// <summary>
		/// 按下查詢按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQueryClick(object sender, EventArgs e)
		{
			if (txtAccount.Text.Trim().Length == 0)
			{
				WebUtility.ResponseScript(Page, "alert('請輸入查詢帳號');", WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			this.LoadData();
		}
		/// <summary>
		/// 查詢時間區間改變時
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void DateRangeChange(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			this.LoadData();
		}
		/// <summary>
		/// 分頁頁碼改變時
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void UCPage1_Change(object sender, EventArgs e)
		{
			this.LoadData();
		}

	}
}