﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class CustomerServiceTransactionLog : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		/// <summary>
		/// 按下查詢按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQueryClick(object sender, EventArgs e)
		{
			if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('只能查詢2個月內的記錄!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			UCPager1.CurrentPageNumber = 1;
			LoadData();
		}
		/// <summary>
		/// 按下日期按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void DateRangChange(object sender, EventArgs e)
		{
			UCPager1.CurrentPageNumber = 1;
			this.LoadData();
		}
		/// <summary>
		/// 分頁改變時
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void PagerChange(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;
			this.LoadData();
		}
		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@ReadType","1"),
				new SqlParameter("@AgentID",AUser.ExecAgentID),
				new SqlParameter("@InputAccount",txtAccount.Text),
				new SqlParameter("@Result",SqlDbType.TinyInt),
				new SqlParameter("@BeginDate",UCDateRange1.StartDate),
				new SqlParameter("@EndDate",UCDateRange1.EndDate),
				new SqlParameter("@PageType","2"),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",UCPager1.PageSize),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
			arParms[3].Direction = ParameterDirection.ReturnValue;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_DataChaneLog", arParms);

			gv.DataSource = sdr;
			gv.DataBind();
			sdr.Close();

			UCPager1.RecordCount = (Int32.Parse(arParms[3].Value.ToString()) != 0) ? 0 : Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			UCPager1.DataBind();
		}
	}
}