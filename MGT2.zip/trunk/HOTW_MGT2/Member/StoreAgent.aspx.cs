﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class StoreAgent : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				InitTree();
				TreeView1.Nodes[0].Selected = true;
				this.LoadData(TreeView1.SelectedNode);
			}
		}

		/// <summary>
		/// 產生儲值代理樹狀選單
		/// </summary>
		protected void InitTree()
		{
			TreeView1.Nodes.Clear();

			EO.Web.TreeNode tnRoot = new EO.Web.TreeNode();
			tnRoot.Text = "總儲值代理";
			tnRoot.Value = "1";
			tnRoot.RaisesServerEvent = EO.Web.NullableBool.True;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.Text, "EXEC NSP_AgentWeb_R_GetTechnicalCSListByAgentGroupID @AgentGroupID = '20'");
			while (sdr.Read())
			{
				EO.Web.TreeNode node = new EO.Web.TreeNode();
				node.Text = string.Format("{0}({1})", sdr["AgentAccount"].ToString(), sdr["AgentNickName"].ToString());
				node.Value = sdr["AgentID"].ToString();


				SqlParameter[] arParms =
				{
					new SqlParameter("@IsGetTopAgent","0"),
					new SqlParameter("@UpAgentID",node.Value)
				};
				DataTable dtChild = SqlHelper.ExecuteDataset(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_AgentList", arParms).Tables[0];
				if (dtChild.Rows.Count != 0)
				{
					node.PopulateOnDemand = true;
					foreach (DataRow dr in dtChild.Rows)
					{
						EO.Web.TreeNode ndChild = new EO.Web.TreeNode();
						ndChild.PopulateOnDemand = false;
						ndChild.Text = string.Format("{0}({1})", dr["AgentAccount"].ToString(), dr["AgentNickName"].ToString());
						ndChild.Value = node.Value;
						ndChild.RaisesServerEvent = EO.Web.NullableBool.False;
						node.ChildNodes.Add(ndChild);

					}
				}
				else
				{
					node.PopulateOnDemand = false;
				}

				tnRoot.ChildNodes.Add(node);

				
			}
			TreeView1.Nodes.Add(tnRoot);
			if (TreeView1.Nodes.Count == 1)
			{
				btnAddAgent.Text = "新增總儲值代理";
				btnAddAgent.CommandArgument = "1";
			}
		}

		/// <summary>
		/// 載入資料
		/// </summary>
		/// <param name="node">觸發的節點</param>
		protected void LoadData(EO.Web.TreeNode node)
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@IsGetTopAgent",TreeView1.SelectedNode.IsTopLevel?"1":"0"),
				new SqlParameter("@UpAgentID",node.Value)
			};

			//SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_AgentList", arParms);
            DataSet ds = SqlHelper.ExecuteDataset(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_AgentList", arParms);

            gv.DataSource = ds.Tables[0];
			gv.DataBind();
			//sdr.Close();

			btnAddAgent.Text = TreeView1.SelectedNode.IsTopLevel ? "新增總儲值代理" : "新增儲值代理";
		}

		/// <summary>
		/// 設定標題帳號類別
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void gvDataBound(object sender, EventArgs e)
		{
			if (gv.Rows.Count == 0)
			{
				return;
			}
			gv.HeaderRow.Cells[0].Text = TreeView1.SelectedNode.IsTopLevel ? "儲值總代理" : "儲值代理";
			
			
		}
		/// <summary>
		/// 設定帳號停用/啟用按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{

                GridViewRow gvRow = (GridViewRow)e.Row;             // Bind to HTML Form
                DataRowView dvRow = (DataRowView)e.Row.DataItem;    // Bind to Database


                //Button btn = e.Row.Cells[8].FindControl("btnSetPause") as Button;
                //Button btnAll = e.Row.Cells[8].FindControl("btnEnableAll") as Button;
                //btn.CommandName = e.Row.Cells[7].Text.Equals("AccountStop") ? "PauseAccount" : "ActiveAccount";
                //btn.Text = e.Row.Cells[7].Text.Equals("AccountStop") ? "停用" : "啟用";
                //e.Row.Cells[7].Text = e.Row.Cells[7].Text.Equals("AccountStop") ? "正常" : "停用";
                //e.Row.Cells[7].ForeColor = e.Row.Cells[7].Text.Equals("正常") ? System.Drawing.Color.Green : System.Drawing.Color.Red;

                //if (TreeView1.SelectedNode.IsTopLevel && e.Row.Cells[7].Text.Equals("停用"))
                //{
					
                //    btnAll.Visible = true;
                //    btn.Text = "單啓";
                //}
                //else
                //{
                //    btnAll.Visible = false;
                //}
                
                //btn.Attributes.Add("AgentID", dvRow["AgentID"].ToString());

                string sPauseAccountStatus = dvRow["PauseAccount"].ToString();
                Button btn = gvRow.FindControl("btnSetPause") as Button;
                Button btnAll = gvRow.FindControl("btnEnableAll") as Button;
				btn.CommandName = dvRow["PauseAccount"].ToString().Equals("AccountStop") ? "ActiveAccount" : "PauseAccount";
				btn.Text = sPauseAccountStatus.Equals("AccountStop") ? "啟用" : "停用";
				e.Row.Cells[7].Text = sPauseAccountStatus.Equals("AccountStop") ? "停用" : "正常";
				e.Row.Cells[7].ForeColor = sPauseAccountStatus.Equals("AccountStop") ? System.Drawing.Color.Red : System.Drawing.Color.Green;

                if (TreeView1.SelectedNode.IsTopLevel && e.Row.Cells[7].Text.Equals("停用")) {

                    btnAll.Visible = true;
                    btn.Text = "單啓";
                }
                else {
                    btnAll.Visible = false;
                }

                btn.Attributes.Add("AgentID", dvRow["AgentID"].ToString());


                
			}
		}

		/// <summary>
		/// 資料列的操作按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void gvRowCommand(object sender, GridViewCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "PauseAccount":
					SqlParameter[] arParms1 =
					{
						new SqlParameter("@Account",e.CommandArgument.ToString()),
						new SqlParameter("@ExecAccount",AUser.ExecAgentAccount),
						new SqlParameter("@PauseAccount","1"),
						new SqlParameter("@IsChained",TreeView1.SelectedNode.IsTopLevel?"1":"0"),
						new SqlParameter("@Result",SqlDbType.SmallInt)
					};
					arParms1[arParms1.Length - 1].Direction = ParameterDirection.ReturnValue;
					SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AgentAccountDisable", arParms1);
					this.LoadData(TreeView1.SelectedNode);

                    // 20110510 Phil: 踢掉該帳號
                    Utility.KickAgentQueue.Add(int.Parse(((Button)e.CommandSource).Attributes["AgentID"]));
                    

					break;
				case "ActiveAccount":
					SqlParameter[] arParms2 =
					{
						new SqlParameter("@Account",e.CommandArgument.ToString()),
						new SqlParameter("@ExecAccount",AUser.ExecAgentAccount),
						new SqlParameter("@PauseAccount","0"),
						new SqlParameter("@IsChained","0"),
						new SqlParameter("@Result",SqlDbType.SmallInt)
					};
					arParms2[arParms2.Length - 1].Direction = ParameterDirection.ReturnValue;
					SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AgentAccountDisable", arParms2);
					this.LoadData(TreeView1.SelectedNode);
					break;
				case "EnableAll":
					SqlParameter[] arParms3 =
					{
						new SqlParameter("@Account",e.CommandArgument.ToString()),
						new SqlParameter("@ExecAccount",AUser.ExecAgentAccount),
						new SqlParameter("@PauseAccount","0"),
						new SqlParameter("@IsChained","1"),
						new SqlParameter("@Result",SqlDbType.SmallInt)
					};
					arParms3[arParms3.Length - 1].Direction = ParameterDirection.ReturnValue;
					SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AgentAccountDisable", arParms3);
					this.LoadData(TreeView1.SelectedNode);
					break;
				case "EditAccount":
					Response.Redirect(string.Format("EditStoreAgent.aspx?upid={0}&agentacc={1}"
						, TreeView1.SelectedNode.IsTopLevel ? "1" : TreeView1.SelectedNode.Value
						, e.CommandArgument.ToString()), true);
					break;
				case "KeyOut":
					Response.Redirect(string.Format("StoreAgentChangePoints.aspx?upid={0}&targetid={1}&changetype={2}"
						,TreeView1.SelectedNode.Value
						,e.CommandArgument.ToString()
						,"1"));
					break;
				case "KeyIn":
					Response.Redirect(string.Format("StoreAgentChangePoints.aspx?upid={0}&targetid={1}&changetype={2}"
						, TreeView1.SelectedNode.Value
						, e.CommandArgument.ToString()
						, "0"));
					break;

			}
		}

		/// <summary>
		/// 按下新增按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnAddClick(object sender, EventArgs e)
		{
			Response.Redirect(string.Format("AddStoreAgent.aspx?mid={0}",
				TreeView1.SelectedNode.IsTopLevel ? "1" : TreeView1.SelectedNode.Value), true);
		}

		/// <summary>
		/// 按下節點
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ItemClick(object sender, EO.Web.NavigationItemEventArgs e)
		{

			this.LoadData(e.TreeNode);

		}


	}
}