﻿using System;
using System.Web.UI.WebControls;
using GFC;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace GWeb.Member
{
	public partial class UCoinMemberAdd : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			SetForm();
			#region 測試用
			if (!IsPostBack)
			{
				//tbxLoginID.Text = "2147483647";
				//tbxLoginPassword.Text = "1qaz2wsx";
				//tbxEMail.Text = "bbb56789@hotmail.com";
				//tbxCustName.Text = "我是姓名";
				//tbxNickName.Text = "我是暱稱";
				//ddlBirthYear.Text = "1980";
				//ddlBirthMonth.Text = "9";
				//ddlBirthDay.Text = "1";
				//tbxCustPID.Text = "1234";
				//rblUserSex.Items[1].Selected = true;
				//tbxTelHome.Text = "0958777456";
				//tbxTelMobile.Text = "0987444587";
				//ddlCity.Text = "台中市";
				//tbxAddr.Text = "我是地址";
				//rbl_InVoice_Type.SelectedValue = "小姐";
				//txt_Invoice_Address.Text = "我是發票地址";
				//ddl_InVoice_City.Text = "台中市";
				//txt_Invoice_Recipient.Text = "我是發票收件人";
				//rbl_InVoice_Type.SelectedValue = "2";
				//txtIntroducer.Text = "aaa123";

			}
			#endregion 測試用
		}

		/// <summary>
		/// 設置表單控制項
		/// </summary>
		protected void SetForm()
		{
			#region 密碼欄位的設置
			if (Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxLoginPassword.Text).Length > 0)
			{
				tbxLoginPassword.Attributes.Add("value", Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxLoginPassword.Text));
			}
			else
			{
				tbxLoginPassword.Attributes.Add("value", "");
			}

			if (Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxConfirmPassword.Text).Length > 0)
			{
				tbxConfirmPassword.Attributes.Add("value", Microsoft.Security.Application.AntiXss.GetSafeHtmlFragment(tbxConfirmPassword.Text));
			}
			else
			{
				tbxConfirmPassword.Attributes.Add("value", "");
			}
			#endregion 密碼欄位的設置

			#region 生日下拉選單設置
			// 如果生日選單沒資料就產生下拉選單
			if (ddlBirthYear.Items.Count == 0)
			{
				// 產生生日下拉選單 
				for (int i = DateTime.Now.Year - 100; i < DateTime.Now.Year - 7; i++)
				{
					ListItem li = new ListItem(i.ToString(), i.ToString());
					// 預設在 30 歲
					if (DateTime.Now.Year - i == 30)
						li.Selected = true;

					ddlBirthYear.Items.Add(li);
				}
				for (int i = 1; i <= 12; i++)
				{
					ddlBirthMonth.Items.Add(new ListItem(i.ToString(), i.ToString()));
				}
				for (int i = 1; i <= 31; i++)
				{
					ddlBirthDay.Items.Add(new ListItem(i.ToString(), i.ToString()));
				}
			}
			#endregion 生日下拉選單設置
		}



		/// <summary>
		/// 檢查帳號是否重複
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnCheckDupeAccount_Click(object sender, EventArgs e)
		{
			tbxLoginID.Text = tbxLoginID.Text.Trim();
			string tmp = tbxLoginID.Text;
			if (tmp.Trim() == "")
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('帳號錯誤: 不可空白!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			else if (tmp.Length < 6 || tmp.Length > 12
				|| !System.Text.RegularExpressions.Regex.IsMatch(tbxLoginID.Text, "^[0-9a-zA-Z]*$"))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('帳號字元範圍[0-9, A-Z, a-z]，並至少輸入6個以上的字元!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			int chkResult = 99;
			object ReturnValue = SqlHelper.ExecuteScalar
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Member_CheckDuplicateAccount",
				new SqlParameter("@CheckType", "1"),
				new SqlParameter("@CheckData", tbxLoginID.Text)
			);

			if (ReturnValue != null)
			{
				chkResult = Convert.ToInt32(ReturnValue);
			}

			switch (chkResult)
			{
				case 0:
					GFC.Web.WebUtility.ResponseScript(Page, "alert('此帳號可以使用!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					break;
				case 1:
				case 12:
					GFC.Web.WebUtility.ResponseScript(Page, "alert('此帳號已有人使用，請改用其他帳號!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					break;
				case 13:
					GFC.Web.WebUtility.ResponseScript(Page, "alert('此帳號正在等待驗證中，目前無法使用此帳號!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					break;
				default:
					GFC.Web.WebUtility.ResponseScript(Page, "alert('此帳號無法使用!');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					break;
			}

		}



		/// <summary>
		/// 驗證基本資料頁表單
		/// </summary>
		private bool ValidMemberForm(out string errorMessage)
		{
			errorMessage = "";

			string tmp = "";
			//int iTmp = 0;

			// 將送出按鈕還原為可點選狀態
			btnView2_ToView3.Enabled = true;
			tbxCustName.Text = tbxCustName.Text.Trim();
			tbxLoginID.Text = tbxLoginID.Text.Trim().Replace(" ", "");
			tbxLoginPassword.Text = tbxLoginPassword.Text.Trim().Replace(" ", "");
			tbxEMail.Text = tbxEMail.Text.Trim().Replace(" ", "");
			tbxTelMobile.Text = tbxTelMobile.Text.Trim().Replace(" ", "");
			tbxNickName.Text = tbxNickName.Text.Trim();

			tmp = tbxLoginID.Text;
			if (tmp.Trim() == "")
			{

				errorMessage = "帳號不可空白";
				return false;
			}
			else if (tmp.Length < 6 || tmp.Length > 12
				|| !System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9a-zA-Z]*$"))
			{

				errorMessage = "必須是 6 ~ 12 碼的英文數字組合";
				return false;
			}
			//else if (int.TryParse(tmp, out iTmp))
			//{

			//    errorMessage = "帳號至少須包含一個英文字母";
			//    return false;
			//}
			else if (System.Text.RegularExpressions.Regex.IsMatch(tmp, "^[0-9]*$"))
			{
				errorMessage = "帳號至少須包含一個英文字母";
				return false;
			}
			else if (tbxTelMobile.Text.Length > 0 && tbxLoginID.Text.IndexOf(tbxTelMobile.Text) > -1)
			{

				errorMessage = "帳號中不可包含您的手機號碼";
				return false;
			}
			else if (tbxEMail.Text.IsEMail() && tbxLoginID.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1)
			{

				errorMessage = "帳號中不可包含您的EMail";
				return false;
			}

			if (tbxLoginPassword.Text == "")
			{

				errorMessage = "密碼不可空白";
				return false;
			}
			else if (!IsValidRegular_MemberPassword(tbxLoginPassword.Text.ToUpper(), out errorMessage))
			{

				return false;
			}
			else if ((tbxLoginID.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxLoginID.Text) > -1)
				|| (tbxTelMobile.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxTelMobile.Text) > -1)
				|| (tbxNickName.Text.Length > 0 && tbxLoginPassword.Text.IndexOf(tbxNickName.Text) > -1)
				|| (tbxEMail.Text.IsEMail() && tbxLoginPassword.Text.IndexOf(tbxEMail.Text.Left(tbxEMail.Text.IndexOf("@"))) > -1))
			{
				errorMessage = "密碼中不可包含帳號、手機號碼、暱稱或EMail";
				return false;
			}

			if (tbxConfirmPassword.Text.Trim() == "")
			{
				errorMessage = "確認密碼不可空白";
				return false;
			}
			else if (tbxConfirmPassword.Text != tbxLoginPassword.Text)
			{
				errorMessage = "與上面的密碼不相同";
				return false;
			}
			ViewState["tbxLoginPassword"] = tbxLoginPassword.Text.ToSafeString();
			ViewState["tbxConfirmPassword"] = tbxConfirmPassword.Text.ToSafeString();

			if (cbxIsJoinAdv.Checked && tbxEMail.Text == "")
			{
				errorMessage = "您選擇了接收最新活動消息，請填寫E-Mail以利寄送";
				return false;
			}

			if (tbxEMail.Text.Trim().Length > 0 && !tbxEMail.Text.IsEMail())
			{
				errorMessage = "E-Mail格式錯誤";
				return false;
			}

			if (tbxCustName.Text == "")
			{
				errorMessage = "姓名不可空白";
				return false;
			}
			if (tbxNickName.Text == "")
			{
				errorMessage = "暱稱不可空白";
				return false;
			}
			else if ((tbxLoginID.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxLoginID.Text) > -1)
					|| (tbxTelMobile.Text.Length > 0 && tbxNickName.Text.IndexOf(tbxTelMobile.Text) > -1))
			{
				errorMessage = "暱稱中不可包含帳號或手機號碼";
				return false;
			}

			// 暱稱中不可包含逗點
			if (!System.Text.RegularExpressions.Regex.IsMatch(tbxNickName.Text, "^[A-Za-z0-9\u4E00-\u9FA5\uF900-\uFA2D]+$"))
			{
				errorMessage = "玩家暱稱不能包含特殊符號";
				return false;
			}

			// 暱稱字數檢查
			int intNickNameLength = 0;
			foreach (char c in tbxNickName.Text)
			{
				if (c >= 0x3000 && c <= 0x9fff)
				{
					intNickNameLength += 2;
				}
				else
				{
					intNickNameLength += 1;
				}
			}
			if (intNickNameLength > 12)
			{
				errorMessage = "暱稱請輸入6個中文字或12個英文字";
				return false;
			}

			if (!(ddlBirthYear.Text + "/" + ddlBirthMonth.Text + "/" + ddlBirthDay.Text).IsDate())
			{
				errorMessage = "日期錯誤";
				return false;
			}

			//if (tbxCustPID.Text.Trim().Length == 0)
			//{
			//    errorMessage = "身分證末四碼不可空白";
			//    return false;
			//}

			//if (tbxCustPID.Text.Trim().Length != 4)
			//{
			//    errorMessage = "請填寫末四碼";
			//    return false;
			//}

			if (tbxTelHome.Text.Trim() != "")
			{
				tmp = tbxTelHome.Text.Trim();
				if (!(tmp.IsNumeric() && tmp.Length > 8 && tmp.Length < 11 && tmp.Substring(0, 1) == "0"))
				{
					errorMessage = "電話不正確";
					return false;
				}
			}

			// 選擇索取發票
			//if (rbl_InVoice_Type.SelectedValue == "2")
			//{
			//    // 檢查發票地址
			//    if (string.IsNullOrEmpty(txt_Invoice_Address.Text))
			//    {
			//        errorMessage = "請輸入發票地址";
			//        return false;
			//    }

			//    // 檢查發票收件人
			//    if (string.IsNullOrEmpty(txt_Invoice_Recipient.Text))
			//    {
			//        errorMessage = "請輸入發票收件人";
			//        return false;
			//    }
			//}


			tmp = tbxTelMobile.Text.Trim();
			if (tmp.Length == 0)
			{
				errorMessage = "手機不可空白";
				return false;
			}
			if (!(tmp.IsNumeric() && tmp.Length == 10 && tmp.Substring(0, 2) == "09"))
			{
				errorMessage = "手機格式錯誤";
				return false;
			}

			return true;
		}

		/// <summary>
		/// 檢查密碼的格式是否正確
		/// </summary>
		/// <param name="passWord">要檢查的密碼字串</param>
		/// <param name="invalidText">要傳回的錯誤訊息</param>
		/// <returns></returns>
		protected bool IsValidRegular_MemberPassword(string passWord, out string invalidText)
		{
			passWord = passWord.Trim().Replace(" ", "");
			invalidText = "";

			int iTmp = 0;
			string sTmp = "";
			if (int.TryParse(passWord, out iTmp))
			{
				invalidText = "密碼至少須包含一個英文字母";
				return false;
			}

			if (passWord.Length < 6 || passWord.Length > 12)
			{
				invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
				return false;
			}
			iTmp = 0;
			for (int i = 0; i < passWord.Length; i++)
			{
				int code = passWord[i];
				if (sTmp.IndexOf(passWord[i]) == -1)
				{ // 把不同的文字加進暫存變數, 等下要判斷有幾種字元
					sTmp += passWord[i].ToString();
				}
				if (!((code >= 48 && code <= 57) || (code >= 65 && code <= 90) || (code >= 97 && code <= 122)))
				{
					invalidText = "密碼必須是 6~12 碼數字或英文字母的組合";
					return false;
				}

				// 如果往後的 3 個字元都是連續字元(例如 123、abc、321、cba、..), 就傳出錯誤
				if (passWord.Length - i > 2 &&
						(
						passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
													+ Convert.ToChar(code + 1).ToString()
													+ Convert.ToChar(code + 2).ToString())
							||
						 passWord.Substring(i, 3) == (Convert.ToChar(code).ToString()
													+ Convert.ToChar(code - 1).ToString()
													+ Convert.ToChar(code - 2).ToString())
						))
				{
					invalidText = "密碼不可包含 3 個連續數字或 3 個連續字母";
					return false;
				}
			}
			if (sTmp.Length < 4)
			{
				invalidText = "密碼必須包含 4 種字元以上";
				return false;
			}

			return true;

		}

		/// <summary>
		/// 儲存會員基本資料表單
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSaveMemberForm_Click(object sender, EventArgs e)
		{
			//欄位驗證不過就離開
			string ResultValidForm = string.Empty;
			if (!ValidMemberForm(out ResultValidForm))
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('" + ResultValidForm + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}

			SqlParameter[] param = new SqlParameter[]
			{
				// 帳號
				new SqlParameter("@MemberAccount", tbxLoginID.Text.ToSafeString().Trim()),
				// 密碼
				new SqlParameter("@MemberPassword", tbxLoginPassword.Text.ToSafeString().Trim()),
				// 姓名
				new SqlParameter("@RealName", tbxCustName.Text.ToSafeString().Trim()),
				// 暱稱
				new SqlParameter("@NickName", tbxNickName.Text.ToSafeString().Trim()),
				// 電子郵件
				new SqlParameter("@Email", tbxEMail.Text.ToSafeString().Trim()),
				// 生日
				new SqlParameter("@Birthday", DateTime.Parse(ddlBirthYear.Text + "-" + ddlBirthMonth.Text + "-" + ddlBirthDay.Text)),
				// 電話
				new SqlParameter("@Phone", tbxTelHome.Text.ToSafeString().Trim()),
				// 手機
				new SqlParameter("@Mobile", tbxTelMobile.Text.ToSafeString().Trim()),
				// 身份證末四碼
				new SqlParameter("@IdPassport", ""),
				// 性別
				new SqlParameter("@Gender", (rblUserSex.Items[0].Selected) ? 1 : 0),
				// 城市
				new SqlParameter("@City", ddlCity.Text.ToSafeString().Trim()),
				// 地址
				new SqlParameter("@Address", tbxAddr.Text.ToSafeString().Trim()),
				// 最新消息
				new SqlParameter("@NewsYN", cbxIsJoinAdv.Checked ? 1 : 0),
				// 發票形式 0 :創世基金會 1:電子發票 2:紙本發票
				new SqlParameter("@Invoice_Type", 0),
				// 發票城市
				new SqlParameter("@Invoice_City", ""),
				// 發票地址
				new SqlParameter("@Invoice_Address", ""),
				// 發票收件人
				new SqlParameter("@Invoice_Recipient", txt_Invoice_Recipient.Text),
				// 介紹人暱稱
				new SqlParameter("@IntroducerNickName", txtIntroducer.Text),
				// 後台使用者編號
				new SqlParameter("@ExecuteAgentID", AUser.ExecAgentID)
			};

			object ReturnValue = SqlHelper.ExecuteScalar
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Member_New",
				param
			);

			string strResult = string.Empty;
			int resultCode = 99;

			if (ReturnValue != null)
			{
				resultCode = int.TryParse(ReturnValue.ToString(), out resultCode) ? resultCode : -1;
			}

			switch (resultCode)
			{
				case 0:
					strResult = "帳號建立成功";
					break;
				case 1:
					strResult = "帳號已存在";
					break;
				case 2:
					strResult = "單一號碼最多只能申請6個帳號";
					break;
				case 3:
					strResult = "介紹人不存在";
					break;
				case 4:
					strResult = "介紹人不可填自己";
					break;
				default:
					strResult = "帳號建立時發生錯誤，請稍候再執行一次，或請洽客服中心";
					break;
			}
			strResult = "alert('" + strResult + "');";
			if (resultCode == 0)
			{
				strResult += "location.href='MemberQuery.aspx';";

			}


			GFC.Web.WebUtility.ResponseScript(Page, strResult, GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);





			#region 舊程式碼
			// 發送驗證碼簡訊
			//string strSMSMsg = "歡迎加入" + this.Config.Global.ProjectDescription + "會員.您的驗證碼為" + strSMSValidationCode + "請立即啟用!";
			//SendSMS(tbxTelMobile.Text, strSMSMsg, SMSRequestTypes.NewMemberAuth, intMemberID.ToString());



			// 先將帳號碼存至 Session, 因為稍候要轉到帳號啟用頁時, 需要用此帳號來一起驗證簡訊驗證碼
			//this.AUser.LoginID = tbxLoginID.Text;
			//this.AUser.LoginPassword = ViewState["tbxLoginPassword"].ToString().ToSafeString();

			// 20090917#B03# Phil: 封測配合使用Gamebase通行碼. 活動結束可刪除
			//UpdateGamebasePassword(intMemberID, tbxLoginID.Text.ToSafeString());
			// 20090917#B03# End

			// 轉址到帳號啟用頁
			//ResponseScript("self.location='MobileAuth.aspx';", ResponseScriptPlace.NearFormEnd);
			//Response.Redirect("MobileAuth.aspx", true);



			#endregion 舊程式碼
		}



		/// <summary>
		/// 關閉紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnClose_Click(object sender, EventArgs e)
		{
			Response.Redirect("UcoinMember.aspx");
		}

		///// <summary>
		///// 重設基本資料表單
		///// </summary>
		///// <param name="sender"></param>
		///// <param name="e"></param>
		//protected void btnMemberFormReset_Click(object sender, EventArgs e)
		//{

		//    tbxLoginID.Text = "";
		//    tbxLoginPassword.Text = "";
		//    tbxConfirmPassword.Text = "";
		//    tbxEMail.Text = "";
		//    tbxCustName.Text = "";
		//    tbxNickName.Text = "";
		//    tbxCustPID.Text = "";
		//    tbxTelHome.Text = "";
		//    tbxTelMobile.Text = "";
		//    tbxAddr.Text = "";
		//    txtIntroducer.Text = string.Empty;

		//    ddlBirthDay.ClearSelection();
		//    ddlBirthMonth.ClearSelection();
		//    ddlBirthYear.ClearSelection();
		//    ddlCity.ClearSelection();
		//    ddlBirthYear.SelectedValue = (DateTime.Now.Year - 30).ToString();

		//    tbxLoginPassword.Attributes["value"] = "";
		//    tbxConfirmPassword.Attributes["value"] = "";
		//    cbxIsJoinAdv.Checked = true;

		//}
	}
}