﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Utility;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class UcoinMember : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{

				//第一次進入時，disable所有欄位，並清除選取條件		
				foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
				{
					if (ctrlChild is TextBox)
					{
						TextBox textctrl = ctrlChild as TextBox;
						textctrl.Enabled = false;

					}
					if (ctrlChild is RadioButton)
					{
						RadioButton radioctrl = ctrlChild as RadioButton;
						radioctrl.Checked = false;
					}
				}

				pnlDetail.Visible = false;
				Form.DefaultButton = btnQuery.UniqueID;
			}
		}

		/// <summary>
		/// 按下新增會員按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lbMemberAccount_Click(object sender, EventArgs e)
		{
 
		}

		#region 搜尋條件區的控制
		/// <summary>
		/// 按下新增會員按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnNewMember_Click(object sender, EventArgs e)
		{
			Response.Redirect("UCoinMemberAdd.aspx");
		}

		/// <summary>
		/// 選取條件時的動作
		/// <para>顯現相關的欄位，disable不相干的欄位，並清除欄位</para>
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void rb_CheckedChanged(object sender, EventArgs e)
		{
			RadioButton rb = sender as RadioButton;

			foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
			{
				if (ctrlChild is TextBox)
				{
					TextBox textctrl = ctrlChild as TextBox;
					textctrl.Text = string.Empty;
					textctrl.Enabled = textctrl.ID.Contains(rb.ID.Substring(2)) ? true : false;

				}
			}

		}
		/// <summary>
		/// 檢查是否有填寫搜尋條件
		/// </summary>
		/// <returns></returns>
		protected bool chkIsHaveColumn()
		{
			bool yn = false;
			foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
			{

				if (ctrlChild is TextBox)
				{
					TextBox textctrl = ctrlChild as TextBox;

					if (textctrl.Text.Trim().Replace("%", "").Length < 2 && textctrl.Text.Contains("%"))
					{
						yn = false;
						WebUtility.ResponseScript(Page, "alert('" + "請至少輸入2個字元" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
					}
					else if (textctrl.Text.Trim().Length != 0)
					{
						yn = true;
					}
				}
			}

			if (!yn)
			{
				WebUtility.ResponseScript(Page, "alert('" + "請選擇填寫一項搜尋條件" + "');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}

			return yn;
		}
		/// <summary>
		/// 按下會員查詢紐
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			pnlDetail.Visible = false;
			if (!chkIsHaveColumn())
			{
				return;
			}
			if (!IsValid)
			{
				return;
			}
			UCPager1.CurrentPageNumber = 1;

			LoadData();
		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{
			int Condiction = 0;
			string strParamterName = string.Empty;
			string strParamterValue = string.Empty;

			foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
			{

				if (ctrlChild is RadioButton)
				{
					RadioButton radioctrl = ctrlChild as RadioButton;

					if (!radioctrl.Checked)
						continue;

					//switch (radioctrl.ID)
					//{
					//    case "rbMemberAccount":
					//        Condiction = 0;
					//        strParamterName = "@MemberAccount";
					//        strParamterValue = txtMemberAccount.Text;
					//        break;
					//    case "rbMemberID":
					//        Condiction = 1;
					//        strParamterName = "@MemberID";
					//        strParamterValue = txtMemberID.Text;
					//        break;
					//    case "rbNickName":
					//        Condiction = 2;
					//        strParamterName = "@NickName";
					//        strParamterValue = txtNickName.Text;
					//        break;
					//    case "rbRealName":
					//        Condiction = 3;
					//        strParamterName = "@RealName";
					//        strParamterValue = txtMobile.Text;
					//        break;
					//    case "rbEMail":
					//        Condiction = 4;
					//        strParamterName = "@EMail";
					//        strParamterValue = txtEMail.Text;
					//        break;
					//}
				}
			}

			SqlParameter[] arParms =
			{
				new SqlParameter("@QueryType", Condiction),
				new SqlParameter(strParamterName,strParamterValue),
				new SqlParameter("@Result",SqlDbType.TinyInt),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",SqlDbType.Int),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			arParms[arParms.Length - 2].Value = UCPager1.PageSize;
			arParms[arParms.Length - 4].Direction = ParameterDirection.Output;



			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_Member_List", arParms);

			grdMemberList.DataSource = sdr;
			grdMemberList.DataBind();
			sdr.Close();

			UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			UCPager1.DataBind();

			pnlDetail.Visible = false;
		}

		/// <summary>
		/// 分頁頁碼改變事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Pager_Change(object sender, EventArgs e)
		{
			this.LoadData();
		}

		#endregion 搜尋條件區的控制

		#region 會員詳細資料區的控制
		/// <summary>
		/// 按下預設圖片按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSetDefaultImageClick(object sender, EventArgs e)
		{

		}
		protected void rpItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				Image img = e.Item.FindControl("imgMember") as Image;
				img.ImageUrl = string.Format(@"~/AppLibs/GetThumbnJpg.ashx?Path=~/ImgFolder/{0}&w={1}&h={2}", img.ImageUrl, 100, 130);
			}
		}
		/// <summary>
		/// 按下編輯按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnEditClick(object sender, EventArgs e)
		{
			Response.Redirect("UcoinMemberEdit.aspx");
		}
		/// <summary>
		/// 按下刪除按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnDeleteClick(object sender, EventArgs e)
		{

		}



		#endregion

		#region 驗證事件
		/// <summary>
		/// 驗證會員帳號
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void cvMemberAccount_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			CustomValidator cv = sender as CustomValidator;

			if (e.Value.Length < 6)
			{
				e.IsValid = false;
				cv.ErrorMessage = GetGlobalResourceObject("Resources", "cvMemberErrorMessage").ToString();
				return;
			}
			else
			{
				if (!Regex.IsMatch(e.Value,RegularExp.NUMERIC_OR_LETTER))
				{
					e.IsValid=false;
					cv.ErrorMessage = GetGlobalResourceObject("Resources", "cvMemberErrorMessage").ToString();
					return;
				}
			}
		}
		/// <summary>
		/// 驗證會員編號
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void cvMemberID_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			CustomValidator cv = sender as CustomValidator;

			if (!Regex.IsMatch(e.Value, RegularExp.NUMERIC))
			{
				e.IsValid = false;
				cv.ErrorMessage = GetGlobalResourceObject("Resources", "cvMemberIDErrorMessage").ToString();
				return;
			}
		}
		/// <summary>
		/// 驗證姓名
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void cvRealName_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			CustomValidator cv = sender as CustomValidator;

			//if(!re
		}
		/// <summary>
		/// 驗證電子郵件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void cvEMail_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			CustomValidator cv = sender as CustomValidator;

			if (!Regex.IsMatch(e.Value, RegularExp.EMAIL))
			{
				e.IsValid = false;
				cv.ErrorMessage = GetGlobalResourceObject("Resources", "cvEMailErrorMessage").ToString();
				return;
			}
		}
		/// <summary>
		/// 驗證生日
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void cvBirthday_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			CustomValidator cv = sender as CustomValidator;

			if (!Regex.IsMatch(e.Value, @"^((?:19|20)\d\d)[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])$"))
			{
				e.IsValid = false;
				cv.ErrorMessage = GetGlobalResourceObject("Resources", "cvDateErrorMessage").ToString();
				return;
			}
		}
		#endregion
	}
}