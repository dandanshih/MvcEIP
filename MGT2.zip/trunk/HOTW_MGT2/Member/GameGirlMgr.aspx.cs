﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using System.IO;

namespace GWeb.Member
{
	public partial class GameGirlMgr : FormBase
	{
		private string GetDurationTime(string DurationStartTime, string DurationMinutes)
		{
			int iDurationStartHour = int.Parse(DurationStartTime);
			int iDurationMinutes = int.Parse(DurationMinutes);
			DateTime dDurationStartTime = DateTime.Parse("9999/1/1 " + iDurationStartHour.ToString() + ":00:00");
			DateTime dDurationEndTime = dDurationStartTime.AddMinutes(iDurationMinutes);

			if (dDurationStartTime.Hour > dDurationEndTime.Hour || iDurationMinutes / 60 == 24)
			{
				return "(" + dDurationStartTime.ToString("HH:mm:ss") + " ～ 隔日" + dDurationEndTime.ToString("HH:mm:ss") + ")";
			}
			else
			{
				return "(" + dDurationStartTime.ToString("HH:mm:ss") + " ～ " + dDurationEndTime.ToString("HH:mm:ss") + ")";
			}
		}

		private void BindData()
		{
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@GameGirlID", hdn_GameGirlID.Value)
			};
			SqlDataReader sdr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_GameGirlData",
				new SqlParameter("@GameGirlID", hdn_GameGirlID.Value)
			);
			if (sdr.Read())
			{
				lit_GameGirlAccount.Text = sdr["GameGirlAccount"].ToString();
				lit_Password.Text = sdr["GameGirlPassword"].ToString();
				lit_RegisterCount.Text = sdr["MemberCnt"].ToString();
				lit_Status.Text = Convert.ToBoolean(sdr["IsWork"]) ? "上班" : "下班";
				lit_StoreValue.Text = sdr["RechargeCnt"].ToString();
				txt_StoreValue.Text = sdr["RechargeCnt"].ToString();
				// hidOldFile.Value = sdr["Url"].ToString();
				img_Photo.ImageUrl = sdr["Url"].ToString();
				lit_GameGirlName.Text = sdr["GameGirlName"].ToString();
				txt_GameGirlName.Text = sdr["GameGirlName"].ToString();
				cb_IsEnable.Checked = Convert.ToBoolean(sdr["IsEnable"]);
			}
			sdr.Close();

			// 預設儲值筆數開關
			lit_StoreValue.Visible = true;
			btn_EditStoreValue.Visible = true;
			txt_StoreValue.Visible = false;
			btn_ConfirmEdit.Visible = false;
			btn_CancelEdit.Visible = false;

			// 預設GameGirl暱稱開關
			lit_GameGirlName.Visible = true;
			btn_EditName.Visible = true;
			txt_GameGirlName.Visible = false;
			btn_ConfirmEditName.Visible = false;
			btn_CancelEditName.Visible = false;

			// 預設啟用鈕開關
			cb_IsEnable.Enabled = false;
			btn_EditIsEnable.Visible = true;
			btn_ConfirmEditIsEnable.Visible = false;
			btn_CancelEditIsEnable.Visible = false;

			BindSchedulingList();
		}

		private void BindSchedulingList()
		{
			SqlParameter[] param = new SqlParameter[]
			{
				// 0:全部, 1:有效的排程, 2:到期的排程
				new SqlParameter("@ListType", "0"),
				new SqlParameter("@GameGirlID", hdn_GameGirlID.Value),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};
			param[param.Length - 1].Direction = ParameterDirection.Output;
			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_GameGirlSchedulingList",
				param
			);
			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();
			gv_SchedulingList.DataSource = ds.Tables[0];
			gv_SchedulingList.DataBind();
		}

		private bool EditGameGirlData(SqlParameter[] param)
		{
			bool ReturnBool = false;
			SqlDataReader sdr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_GameGirlDataEdit",
				param
			);
			if (sdr.Read())
			{
				if (sdr["Result"].ToString() == "0")
				{
					ReturnBool = true;
				}
				else
				{
					ReturnBool = false;
					ScriptManager.RegisterStartupScript(Page, GetType(), "alertError", "alert('" + sdr["ErrorMessage"].ToString() + "');", true);
				}
			}
			sdr.Close();
			return ReturnBool;
		}

		/// <summary>
		/// 清除上傳物件的狀態。
		/// </summary>
		private void DeleteTempFile(EO.Web.AJAXUploader upload)
		{
			try
			{
				if (upload.PostedFiles.Length != 0)
				{
					File.Delete(upload.PostedFiles[0].TempFileName);
					File.Delete(Path.ChangeExtension(upload.PostedFiles[0].TempFileName, ".info"));
					File.Delete(upload.PostedFiles[0].TempFileName
						.Substring(0, upload.PostedFiles[0].TempFileName.Length - 7) + ".status");

				}
				upload.ClearPostedFiles();
			}
			catch (Exception)
			{ }
		}

		/// <summary>
		/// 處理上傳檔案。
		/// </summary>
		/// <param name="upload"></param>
		/// <param name="OldUrlPath">舊檔案網址</param>
		/// <returns></returns>
		private string MoveTempFile(EO.Web.AJAXUploader upload, string strUpFilePath, string OldUrlPath)
		{
			string UrlPath = ResolveUrl(strUpFilePath) + upload.PostedFiles[0].ClientFileName;
			string FilePath = Server.MapPath(strUpFilePath) + upload.PostedFiles[0].ClientFileName;
            string DirectoryPath = Server.MapPath(strUpFilePath);


			string OldFileName = OldUrlPath.Substring(OldUrlPath.LastIndexOf("/") + 1);
			if (OldFileName != upload.PostedFiles[0].ClientFileName && File.Exists(FilePath))
			{
				// 檔案已存在回傳空值
				DeleteTempFile(upload);
				return UrlPath;
			}
			else
			{
				// 刪除舊檔案
				if (!string.IsNullOrEmpty(OldUrlPath))
				{
					string tmpPath = OldUrlPath.Replace("http://", "");
					tmpPath = tmpPath.Substring(tmpPath.IndexOf("/"));
					if (File.Exists(tmpPath))
					{
						File.Delete(Server.MapPath(tmpPath));
					}
				}

                if (!Directory.Exists(DirectoryPath))
				{
                    Directory.CreateDirectory(DirectoryPath);
				}
				if (File.Exists(FilePath))
				{
					File.Delete(FilePath);
				}
				File.Move(upload.PostedFiles[0].TempFileName, FilePath);
				DeleteTempFile(upload);
				return UrlPath;
			}
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			
		}

		protected void btn_Query_Click(object sender, EventArgs e)
		{
			pnl_Content.Visible = true;
			UCPager1.CurrentPageNumber = 1;
			hdn_GameGirlID.Value = ddl_GameGirlList.SelectedValue;
			BindData();
		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			BindSchedulingList();
		}

		protected void btn_EditGameGirlData_Command(object sender, CommandEventArgs e)
		{
			SqlParameter[] param;
			switch (e.CommandName)
			{
				#region 變更儲值筆數
				case "EditStoreValue":
					lit_StoreValue.Visible = false;
					btn_EditStoreValue.Visible = false;
					txt_StoreValue.Visible = true;
					btn_ConfirmEdit.Visible = true;
					btn_CancelEdit.Visible = true;
					break;
				case "ConfirmEdit":
					decimal StoreValue = 0;
					if (!decimal.TryParse(txt_StoreValue.Text, out StoreValue))
					{
						ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('請輸入數字');", true);
						return;
					}
					param = new SqlParameter[]
					{
						new SqlParameter("@GameGirlID", hdn_GameGirlID.Value),
						new SqlParameter("@AgentID", AUser.AgentID),
						new SqlParameter("@RechargeCnt", txt_StoreValue.Text)
					};
					if (EditGameGirlData(param))
					{
						BindData();
					}
					break;
				case "CancelEdit":
					lit_StoreValue.Visible = true;
					btn_EditStoreValue.Visible = true;
					txt_StoreValue.Visible = false;
					btn_ConfirmEdit.Visible = false;
					btn_CancelEdit.Visible = false;
					break;
				#endregion
				#region 變更密碼
				case "ChangePassword":
					param = new SqlParameter[]
					{
						new SqlParameter("@GameGirlID", hdn_GameGirlID.Value),
						new SqlParameter("@AgentID", AUser.AgentID),
						new SqlParameter("@GameGirlPassword", "1")
					};
					if (EditGameGirlData(param))
					{
						BindData();
					}
					break;
				#endregion
				#region 變更頭像圖片
				case "EditPhoto":
					if(AJAXUploader1.PostedFiles.Length == 0)
					{
						ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('請選擇圖片！');", true);
						return;
					}
					param = new SqlParameter[]
					{
						new SqlParameter("@GameGirlID", hdn_GameGirlID.Value),
						new SqlParameter("@AgentID", AUser.AgentID),
						new SqlParameter("@Url", MoveTempFile(AJAXUploader1, @"~/Html/UploadFiles/GameGirl/", img_Photo.ImageUrl))
					};
					if (EditGameGirlData(param))
					{
						BindData();
					}
					break;
				#endregion
				#region 變更PG名稱
				case "EditName":
					lit_GameGirlName.Visible = false;
					btn_EditName.Visible = false;
					txt_GameGirlName.Visible = true;
					btn_ConfirmEditName.Visible = true;
					btn_CancelEditName.Visible = true;
					break;
				case "ConfirmEditName":
					param = new SqlParameter[]
					{
						new SqlParameter("@GameGirlID", hdn_GameGirlID.Value),
						new SqlParameter("@AgentID", AUser.AgentID),
						new SqlParameter("@GameGirlName", txt_GameGirlName.Text)
					};
					if (EditGameGirlData(param))
					{
						BindData();
					}
					break;
				case "CancelEditName":
					lit_GameGirlName.Visible = true;
					btn_EditName.Visible = true;
					txt_GameGirlName.Visible = false;
					btn_ConfirmEditName.Visible = false;
					btn_CancelEditName.Visible = false;
					break;
				#endregion
				#region 變更啟用狀態
				case "EditIsEnable":
					cb_IsEnable.Enabled = true;
					btn_EditIsEnable.Visible = false;
					btn_ConfirmEditIsEnable.Visible = true;
					btn_CancelEditIsEnable.Visible = true;
					break;
				case "ConfirmEditIsEnable":
					param = new SqlParameter[]
					{
						new SqlParameter("@GameGirlID", hdn_GameGirlID.Value),
						new SqlParameter("@AgentID", AUser.AgentID),
						new SqlParameter("@IsEnable", cb_IsEnable.Checked ? "1" : "0")
					};
					if (EditGameGirlData(param))
					{
						BindData();
					}
					break;
				case "CancelEditIsEnable":
					cb_IsEnable.Enabled = false;
					btn_EditIsEnable.Visible = true;
					btn_ConfirmEditIsEnable.Visible = false;
					btn_CancelEditIsEnable.Visible = false;
					break;
				#endregion
			}
		}

		protected void btn_Add_Click(object sender, EventArgs e)
		{
			Response.Redirect("GameGirlMgr_Add.aspx?pgid=" + hdn_GameGirlID.Value);
		}

		protected void gv_SchedulingList_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.DataItem == null)
			{
				return;
			}

			DataRowView Item = (DataRowView)e.Row.DataItem;

			// 循環週期
			((Label)e.Row.FindControl("lblWeekDays")).Text = Item["WeekDays"].ToString().Replace("1", "/星期一").Replace("2", "/星期二").Replace("3", "/星期三").Replace("4", "/星期四").Replace("5", "/星期五").Replace("6", "/星期六").Replace("7", "/星期日").TrimStart('/');

			// 比賽時間
			((Label)e.Row.FindControl("lblGameTime")).Text = GetDurationTime(Item["DurationStartTime"].ToString().Substring(0, 2), Item["DurationMinute"].ToString());
		}

		protected void gv_SchedulingList_RowCommand(object sender, CommandEventArgs e)
		{
			if (e.CommandName == "Pause")
			{
				SqlParameter[] param = new SqlParameter[]
				{
					new SqlParameter("@GameSchedule_SID", e.CommandArgument.ToString()),
					new SqlParameter("@IsPaused", "1"),
					new SqlParameter("@AgnetID", AUser.AgentID)
				};
				SqlHelper.ExecuteNonQuery
				(
					WebConfig.connectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_GameGirlSchedulingSetPause",
					param
				);
				BindSchedulingList();
			}
		}

		protected void sds_GameGirlList_Selected(object sender, SqlDataSourceStatusEventArgs e)
		{
			lit_TotalCount.Text = e.Command.Parameters["@MemberCnt"].Value.ToString();
		}
	}
}