﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
    public partial class KingCoolMember_Add : GWeb.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Add_Click(object sender, EventArgs e)
        {
            SqlParameter[] param = new SqlParameter[]
            {
                // 金庫卡序號
                new SqlParameter("@KingCoolCardNo", txt_AgentAccount.Text),
                // 暱稱
                new SqlParameter("@NickName", txt_AgentNickName.Text.TrimEnd()),
                // 密碼
                new SqlParameter("@pwd", txt_AgentPassword.Text),
                // 是否記帳, 50=記帳; 60=不記帳
                new SqlParameter("@AgentGroupID", (chk_IsCharge.Checked) ? 50 : 60)
            };

            DataTable ObjDt = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KingCoolCardAdd",
                param
            ).Tables[0];

            // 取得新增結果
            string Msg = "";
            bool IsSuccess = false;
            if (ObjDt != null && ObjDt.Rows.Count != 0)
            {
                switch (ObjDt.Rows[0]["RESULT"].ToString())
                {
                    case "0":
                        Msg = "新增成功";
                        IsSuccess = true;
                        break;
                    case "-1":
                        Msg = "失敗";
                        break;
                    case "-2":
                        Msg = "金庫卡號重複";
                        break;
                }
            }

            if (IsSuccess)
            {
                Msg = string.Format("alert('{0}');location.href='{1}';", Msg, "KingCoolMember.aspx");
            }
            else
            {
                Msg = string.Format("alert('{0}');", Msg);
            }

            ScriptManager.RegisterStartupScript(Page, GetType(), "Message", Msg, true);
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Member/KingCoolMember.aspx");
        }
    }
}