﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;
using GFC.Web;

namespace GWeb.Member
{
	public partial class MemberCard : GWeb.AppLibs.FormBase
	{
		/// <summary>
		/// 取得人數。
		/// </summary>
		private void LoadCountData()
		{
			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_MemberCradCount"
			);

			lblAuthCount.Text = ds.Tables[0].Rows[0]["OpenCount"].ToString();
			lblLoginCount.Text = ds.Tables[0].Rows[0]["NormalCount"].ToString();
		}

		/// <summary>
		/// 取得列表。
		/// </summary>
		private void LoadData()
		{
			string searchText = string.Empty;
			string searchType = string.Empty;

			if (rdoDefaultAccount.Checked)
			{
				searchText = txtDefaultAccount.Text;
				searchType = "1";
			}
			else if (rdoMobile.Checked)
			{
				searchText = txtMobile.Text;
				searchType = "2";
			}
			else
			{
				searchText = string.Empty;
				searchType = "1";
			}

			SqlParameter[] param =
			{
				new SqlParameter("@InquiryData", searchText),
				new SqlParameter("@InquiryType", searchType),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", SqlDbType.Int)
			};

			param[param.Length - 1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_MemberCradList"
				,param
			);

			rptMemberCard.DataSource = ds;
			rptMemberCard.DataBind();

			UCPager1.RecordCount = int.Parse(param[param.Length - 1].Value.ToString());
			UCPager1.DataBind();

			if (UCPager1.RecordCount == 0)
			{
				pnlEmpty.Visible = true;
			}
			else
			{
				pnlEmpty.Visible = false;
			}
		}

		/// <summary>
		/// 新增。
		/// </summary>
		private bool Add()
		{
			string result = string.Empty;

			SqlParameter[] param =
			{
				new SqlParameter("@Code", txtCode.Text),
				new SqlParameter("@StartNo", txtSNStart.Text),
				new SqlParameter("@EndNo", txtSNEnd.Text)
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AddMemberCrad"
				, param
			);

			result = ds.Tables[0].Rows[0]["Result"].ToString();			

			return result == "0" ? true : false;
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			LoadCountData();
		}
		
		protected void btnAdd_Click(object sender, EventArgs e)
		{
			txtCode.Text = "";
			txtSNStart.Text = "";
			txtSNEnd.Text = "";
			pnlMemberCardAdd.Visible = true;
		}

		protected void btnSubmit_Click(object sender, EventArgs e)
		{
			if (Page.IsValid)
			{
				int SNStart = int.Parse(txtSNStart.Text);
				int SNEnd = int.Parse(txtSNEnd.Text);
				int limit = 1000;

				if ((SNEnd - SNStart + 1) > limit)
				{
					WebUtility.ResponseScript(Page, "alert('超過新增筆數限制。')", WebUtility.ResponseScriptPlace.NearFormEnd);
				}
				else if (Add())
				{
					pnlMemberCardAdd.Visible = false;
					WebUtility.ResponseScript(Page, "alert('新增成功。')", WebUtility.ResponseScriptPlace.NearFormEnd);
				}
				else
				{
					WebUtility.ResponseScript(Page, "alert('新增失敗。')", WebUtility.ResponseScriptPlace.NearFormEnd);
				}
			}
		}

		protected void btnClose_Click(object sender, EventArgs e)
		{
			pnlMemberCardAdd.Visible = false;
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			if (rdoDefaultAccount.Checked)
			{
				if (txtDefaultAccount.Text.Trim().Replace("%", "").Length < 2 && txtDefaultAccount.Text.Contains("%"))
				{					
					WebUtility.ResponseScript(Page, "alert('" + "請至少輸入2個字元" + "');", WebUtility.ResponseScriptPlace.NearFormEnd);
					return;
				}
			}			

			pnlMemberCardAdd.Visible = false;
			UCPager1.CurrentPageNumber = 1;
			LoadData();
		}

		protected void UCPager1_Change(object sender, EventArgs e)
		{
			LoadData();
		}
	}
}