﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Web;
using System.Data.SqlClient;
using System.Data;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
    public partial class MobileDelete : GWeb.AppLibs.FormBase
    {
        #region Private Method

        /// <summary>
        /// 驗證查詢條件。
        /// </summary>
        /// <returns></returns>
        private bool chkIsHaveColumn()
        {
            bool yn = false;
            foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
            {
                if (ctrlChild is TextBox && (ctrlChild as TextBox).Text.Trim() != "")
                {
                    yn = true;
                }
            }

            if (!yn)
            {
                WebUtility.ResponseScript(Page, "alert('請選擇填寫一項搜尋條件');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
            }

            return yn;
        }

        /// <summary>
        /// 查詢資料。
        /// </summary>
        private void LoadData()
        {
            int Condiction = 0;
            string strParamterName = string.Empty;
            string strParamterValue = string.Empty;

            foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
            {

                if (ctrlChild is RadioButton)
                {
                    RadioButton radioctrl = ctrlChild as RadioButton;

                    if (!radioctrl.Checked)
                        continue;

                    switch (radioctrl.ID)
                    {
                        case "rbMemberAccount":
                            Condiction = 0;
                            strParamterName = "@MemberAccount";
                            strParamterValue = txtMemberAccount.Text;
                            break;
                        case "rbNickName":
                            Condiction = 2;
                            strParamterName = "@NickName";
                            strParamterValue = txtNickName.Text;
                            break;
                        case "rbMobile":
                            Condiction = 3;
                            strParamterName = "@Mobile";
                            strParamterValue = txtMobile.Text;
                            break;
                    }
                }
            }

            SqlParameter[] arParms =
			{
				new SqlParameter("@QueryType", Condiction),
				new SqlParameter(strParamterName,strParamterValue)
			};

            SqlDataReader sdr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString, 
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_MobileSearch", 
                arParms
            );

            grdMemberList.DataSource = sdr;
            grdMemberList.DataBind();

            sdr.Close();
        }

        /// <summary>
        /// 刪除會員手機。
        /// </summary>
        /// <param name="memberId">要刪除的會員編號。</param>
        private void DeleteMobile(int memberId)
        {
            SqlParameter[] arParms =
            {
                new SqlParameter("@MemberID", memberId.ToString()),
                new SqlParameter("@AgentAccount", AUser.AgentAccount)
            };

            SqlDataReader sdr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_DeleteMobile",
                arParms
            );

            sdr.Read();

            ScriptManager.RegisterStartupScript(Page, GetType(), "message", "alert('" + sdr["ResultMsg"].ToString() + "');", true);

            sdr.Close();
        }

        /// <summary>
        /// 查詢歷史紀錄列表。
        /// </summary>
        private void LoadHistoryData()
        {
            SqlParameter[] arParms =
			{
				new SqlParameter("@StartDate", DateRange1.StartDate),
				new SqlParameter("@EndDate", DateRange1.EndDate)
			};

            SqlDataReader sdr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_DeleteMobileLog",
                arParms
            );

            grdHistory.DataSource = sdr;
            grdHistory.DataBind();

            sdr.Close();
        }

        #endregion

        #region Protected Method

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //第一次進入時，disable所有欄位，並清除選取條件		
                foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
                {
                    if (ctrlChild is TextBox)
                    {
                        TextBox textctrl = ctrlChild as TextBox;
                        textctrl.Enabled = false;

                    }
                    if (ctrlChild is RadioButton)
                    {
                        RadioButton radioctrl = ctrlChild as RadioButton;
                        radioctrl.Checked = false;
                    }
                }

                Form.DefaultButton = btnQuery.UniqueID;
            }
        }

        /// <summary>
        /// 選取條件時的動作，顯現相關的欄位，disable不相干的欄位，並清除欄位
        /// </summary>
        protected void rb_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;

            foreach (object ctrlChild in UpdatePanel1.ContentTemplateContainer.Controls)
            {
                if (ctrlChild is TextBox)
                {
                    TextBox textctrl = ctrlChild as TextBox;
                    textctrl.Text = string.Empty;
                    textctrl.Enabled = textctrl.ID.Contains(rb.ID.Substring(2)) ? true : false;
                }
            }
        }

        /// <summary>
        /// 按下會員查詢事件
        /// </summary>
        protected void btnQuery_Click(object sender, EventArgs e)
        {
            if (!chkIsHaveColumn())
            {
                return;
            }

            if (!IsValid)
            {
                return;
            }

            LoadData();
        }

        /// <summary>
        /// 按下搜尋結果中的會員帳號
        /// </summary>
        protected void grdMemberList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int editIndex = int.Parse(e.CommandArgument.ToString());
            int memberId = int.Parse(grdMemberList.DataKeys[editIndex].Values["MemberID"].ToString());

            switch (e.CommandName)
            {
                case "DelMobile":
                    DeleteMobile(memberId);
                    LoadData();
                    break;
            }
        }

        /// <summary>
        /// 歷史紀錄查詢事件。
        /// </summary>
        protected void btnHistoryQuery_Click(object sender, EventArgs e)
        {
            //檢查是否可查詢資料
            if (!Authority.CheckAuthority(EnumAuthority.Query))
            {
                return;
            }

            LoadHistoryData();
        }
        #endregion
    }
}