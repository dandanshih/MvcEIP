﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
    public partial class KingCoolMember_Edit : GWeb.AppLibs.FormBase
    {
        #region private
        /// <summary>
        /// 取得更新的金庫卡資訊
        /// </summary>
        private void GetInfo(string AgentAccount)
        {
            SqlParameter[] param = new SqlParameter[]
            {
                // 金庫卡序號
                new SqlParameter("@KingCoolCardNo", AgentAccount)
            };

            DataTable ObjDt = SqlHelper.ExecuteDataset
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_KingCoolCardGetOne",
                param
            ).Tables[0];

            if (ObjDt == null || ObjDt.Rows.Count == 0)
            {
                Response.Redirect("~/Member/KingCoolMember.aspx");
                return;
            }

            txt_AgentAccount.Text = ObjDt.Rows[0]["AgentAccount"].ToString();
            txt_AgentNickName.Text = ObjDt.Rows[0]["AgentNickName"].ToString();
            chk_IsCharge.Checked = (ObjDt.Rows[0]["AgentGroupID"].ToString() == "50") ? true : false;
            ViewState["id"] = ObjDt.Rows[0]["AgentID"].ToString();
        }
        #endregion

        #region protected
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // 取得代理商帳號
                string agentacc = (Request.QueryString["agentacc"] != null) ? Request.QueryString["agentacc"] : string.Empty;
                if (string.IsNullOrEmpty(agentacc))
                {
                    Response.Redirect("~/Member/KingCoolMember.aspx");
                    return;
                }

                // 將資料繫結至頁面上
                GetInfo(agentacc);
            }
        }

        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if (ViewState["id"] == null)
            {
                Response.Redirect("~/Member/KingCoolMember.aspx");
                return;
            }

            string id = ViewState["id"].ToString();
            SqlParameter[] param = new SqlParameter[]
            {
                // 回覆訊息
                new SqlParameter("@Result", SqlDbType.TinyInt),
                // 要修改的AgentID
                new SqlParameter("@TargetID", id),
                // 暱稱
                new SqlParameter("@NickName", txt_AgentNickName.Text),
                // 密碼
                new SqlParameter("@Password", txt_AgentPassword.Text.TrimEnd()),
                new SqlParameter("@ContributeRate", 0),
                new SqlParameter("@ExecAgentID", AUser.ExecAgentID)
            };

            param[0].Direction = ParameterDirection.ReturnValue;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_EditAgent",
                param
            );

            string Msg = string.Empty;
            bool IsSuccess = false;
            switch (param[0].Value.ToString())
            {
                case "0":
                    Msg = "修改成功";
                    IsSuccess = true;
                    break;
                case "-1":
                    Msg = "暱稱重複";
                    break;
                case "-2":
                    Msg = "暱稱空白";
                    break;
                default:
                    Msg = "修改失敗";
                    break;
            }

            if (IsSuccess)
            {
                // 更新「是否記帳」
                param = new SqlParameter[]
                {
                    new SqlParameter("@AgentID",id),
                    new SqlParameter("@IsAccounting",(chk_IsCharge.Checked) ? 1 : 0)
                };

                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.connectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_KingCoolAgentChangeGroup",
                    param
                );

                Msg = string.Format("alert('{0}');location.href='{1}';", Msg, "KingCoolMember.aspx");
            }
            else
            {
                Msg = string.Format("alert('{0}');", Msg);
            }

            ScriptManager.RegisterStartupScript(Page, GetType(), "Message", Msg, true);
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Member/KingCoolMember.aspx");
        }
        #endregion
    }
}