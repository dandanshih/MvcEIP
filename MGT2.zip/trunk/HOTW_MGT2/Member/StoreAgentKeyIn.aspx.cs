﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;
using ClickOnceButton;

namespace GWeb.Member
{
	public partial class StoreAgentKeyIn : GWeb.AppLibs.FormBase
	{
		private TimeSpan LastActionTime = new TimeSpan(0);

		public string BaseURL
		{
			get
			{
				return string.Format("http://{0}{1}",
					 HttpContext.Current.Request.ServerVariables["HTTP_HOST"],
					 (HttpContext.Current.Request.ApplicationPath.Equals("/")) ? string.Empty : HttpContext.Current.Request.ApplicationPath);
			}
		}

		protected void Page_Load(object sender, EventArgs e)
		{			
			if (!IsPostBack)
			{
				LastActionTime = new TimeSpan(0);
				ReadData();				
			}
		}

		protected void ReadData()
		{
			SqlParameter[] arParms =
			{
				new SqlParameter("@AgentID",AUser.AgentID)
			};


			// 資料讀取
            long Points = Convert.ToInt64(SqlHelper.ExecuteScalar(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_GetAgentAccountPoint", arParms));
			txtPoints.Text = "0";
			lblLimit.Text = "/" + Points.ToString();
			if (Points > 0)
			{
				rvPoints.ErrorMessage = "請輸入介於 1~" + Points.ToString() + " 之間的數字!!";
				rvPoints.MaximumValue = Points.ToString();
				rvPoints.Visible = true;
			}
			else
			{
				string errorMessage = "您的餘額不足，請洽經營者!!";
				WebUtility.ResponseScript(Page, "alert('" + errorMessage + "');", WebUtility.ResponseScriptPlace.NearFormEnd);
				rvPoints.MinimumValue = "0";
				rvPoints.MaximumValue = "0";
				rvPoints.Visible = false;
			}

		}

		protected void btnSubmit_Command(object sender, CommandEventArgs e)
		{
			TimeSpan tsNow = new TimeSpan(DateTime.Now.Ticks);
			if (tsNow.Subtract(LastActionTime).Duration().Seconds <= 5)
				return;

			LastActionTime = tsNow;			
			Decimal dTmp = 0;
            int iMemberID = -1;
			string errorMessage = "";

			if (Decimal.TryParse(txtPoints.Text, out dTmp))
			{
				if (dTmp > 0)
				{
					using (SqlConnection conn = DBConn)
					{
						using (SqlCommand cmd = new SqlCommand("NSP_AgentWeb_A_Member_ChangePoints", conn))
						{
							cmd.CommandType = CommandType.StoredProcedure;
														
							cmd.Parameters.Add("@AgentID", SqlDbType.Int).Value = int.Parse(AUser.ExecAgentID);
							cmd.Parameters.Add("@MemberAccount", SqlDbType.VarChar).Value = txtMember.Text;
							cmd.Parameters.Add("@CellPhone", SqlDbType.VarChar).Value = txtCellPhone.Text;
							cmd.Parameters.Add("@ChangePoints", SqlDbType.Decimal).Value = dTmp;
                            cmd.Parameters.Add(new SqlParameter("@MemberID",  SqlDbType.Int)).Direction = ParameterDirection.Output;
							string sResult = string.Empty;
							long EventID = 0;
							int MemberIDTarget = 0;
							decimal Points = 0;
							int pointType = 0;

							try
							{
								SqlDataReader sdr = cmd.ExecuteReader();
								sdr.Read();
								sResult = sdr["Result"].ToString();
								EventID = long.TryParse(sdr["EventID"].ToString(), out EventID) ? EventID : 0;
								MemberIDTarget = int.TryParse(sdr["Target_MemberID"].ToString(), out MemberIDTarget) ? MemberIDTarget : 0;
								Points = decimal.TryParse(sdr["ChangePoints"].ToString(), out Points) ? Points : 0;
                                iMemberID = Convert.ToInt32(cmd.Parameters["MemberID"].Value);
								pointType = int.TryParse(sdr["PointType"].ToString(), out pointType) ? pointType : 0;
								sdr.Close();								
							}
							catch (Exception ex)
							{
								errorMessage = ex.Message;
							}
							
							switch (sResult)
							{
								case "0":
									errorMessage = string.Empty;
                                    break;
                                case "1":
									{
										errorMessage = "查無此玩家帳號!!";
										break;
									}
								case "2":
									{
										errorMessage = "手機輸入錯誤!!";
										break;
									}
								case "3":
									{
										if (EventID > 0)
										{
											string fsResult = GS.ServerCommander.FSCommander.FS_AS_CREDIT_CHANGE(EventID, MemberIDTarget, Points, pointType);

											switch (fsResult.Split('&')[1])
											{
												case "0":
													errorMessage = string.Empty;
													break;
												default:
													errorMessage = fsResult.Split('&')[2];
													break;
											}
											errorMessage = "玩家還在線上，請玩家先行離線!!";
										}
										break;
									}
								case "4":
									{
										errorMessage = "您的額度已超過，無法開分!!";
										ReadData();
										break;
									}
								case "5":
									{
										errorMessage = "執行代理身分不是儲值代理";
										ReadData();
										break;
									}
								default:
									{
										errorMessage = "資料操作錯誤";
										break;
									}
							}
						}
					}
				}
				else
				{
					errorMessage = "您的餘額不足，請洽經營者!!";
				}
			}
			else
			{
				errorMessage = "金額輸入錯誤!!";
			}

			// 當執行完成時就跳回
			if (errorMessage == "")
			{
				try
				{
					//string sCmd = @"264&95&" + iMemberID.ToString() + "&" + txtPoints.Text.Trim();
					//Utility.SendInfoToFrontServer(AUser.FrontServerIP, sCmd);

					WebUtility.ResponseScript(Page, "alert('" + "儲值成功" + "');", WebUtility.ResponseScriptPlace.NearFormEnd);	
				}
				catch (Exception)
				{
					WebUtility.ResponseScript(Page, "alert('" + "儲值失敗" + "');", WebUtility.ResponseScriptPlace.NearFormEnd);
					throw;
				}							
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('" + errorMessage + "');", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		protected void btnQuery_OnClick(object sender, EventArgs e)
		{
			pgKeyInLog.CurrentPageNumber = 1;
			BindData();
		}
		protected void BindData()
		{

			SqlParameter[] arParms =
			{
				new SqlParameter("@AgentID",AUser.ExecAgentID),
				new SqlParameter("@StartDate",UCDateRange1.StartDate),
				new SqlParameter("@EndDate",UCDateRange1.EndDate),
				new SqlParameter("@PageSize",pgKeyInLog.PageSize),
				new SqlParameter("@PageIndex",pgKeyInLog.CurrentPageNumber),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_StoreAgent_QryMemberStoreList", arParms);

			gvKeyInLog.DataSource = sdr;
			gvKeyInLog.DataBind();
			sdr.Close();

			pgKeyInLog.TotalPages = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
			pgKeyInLog.DataBind();
		}

		protected void Pager_OnChanger(object sender, GWeb.AppUserControls.Pager.UCPager.PagerEventArgs e)
		{
			DataBind();
		}
	}
}