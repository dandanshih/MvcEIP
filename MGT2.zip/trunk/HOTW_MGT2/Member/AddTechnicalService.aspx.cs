﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;


namespace GWeb.Member
{
	public partial class AddTechnicalService : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.Text, "EXEC NSP_AgentWeb_R_GetTechnicalCSGroups @Groups = '1,30,31'");
				while (sdr.Read())
				{
					ListItem li = new ListItem(sdr["AgentGroupName"].ToString(), sdr["AgentGroupID"].ToString());
					ddlAgentGroup.Items.Add(li);
				}
			}
		}

		/// <summary>
		/// 按下提交按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnSubmitClick(object sender, EventArgs e)
		{
			if (!IsValid)
			{
				return;
			}

			SqlParameter[] arParms =
			{
				new SqlParameter("@GroupID",ddlAgentGroup.SelectedValue),
				new SqlParameter("@Account",txtAgentAccount.Text),
				new SqlParameter("@Password",txtLoginPassword.Text),
				new SqlParameter("@NickName",txtAgentNickName.Text),
				new SqlParameter("@ExecuteAgentID",AUser.ExecAgentID),
				new SqlParameter("@Result",SqlDbType.SmallInt)
			};
			arParms[arParms.Length - 1].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AddTechnicalCSAccount", arParms);
			string strResult = arParms[arParms.Length - 1].Value.ToString();
			string strMessage = string.Empty;
			switch (strResult)
			{
 				case "0":
					strMessage = "帳號新增成功";
					break;
				case "-1":
					strMessage = "帳號已被使用";
					break;
				case "-2":
					strMessage = "資料不齊全";
					break;
				case "-3":
					strMessage = "權限不足";
					break;
				default:
					strMessage = "資料操作錯誤";
					break;
			}
			string strSource = strResult.Equals("0") ? string.Format("alert('{0}');location.href=document.referrer;", strMessage) : string.Format("alert('{0}');", strMessage);
			GFC.Web.WebUtility.ResponseScript(Page, strSource, GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void btnCloseClick(object sender, EventArgs e)
		{
			Response.Redirect("TechnicalService.aspx");
		}
	}
}