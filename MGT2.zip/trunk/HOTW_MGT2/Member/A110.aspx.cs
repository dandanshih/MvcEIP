﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GWeb.AppLibs;
using GS.ServerCommander;

namespace GWeb.Member
{
	public partial class A110 : AppLibs.FormBase
	{
		private void BindData()
		{ 
			SqlParameter[] param =
			{
				new SqlParameter("@MemberAccount", rbl_Type.Items[0].Selected ? txtMember.Text : ""),
				new SqlParameter("@NickName", rbl_Type.Items[1].Selected ? txtMember.Text : ""),
				new SqlParameter("@BeginDate", UCDateRange1.StartDate),
				new SqlParameter("@EndDate", UCDateRange1.EndDate)				
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_MemberPointEditLogList",
				param
			);

			gv_List.DataSource = ds;
			gv_List.DataBind();
		}

		private void ChangeData(int keyType)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@MemberAccount", rbl_Type.Items[0].Selected ? txtMember.Text : ""),
				new SqlParameter("@NickName", rbl_Type.Items[1].Selected ? txtMember.Text : ""),
				new SqlParameter("@EditType", rbl_DataType.SelectedItem.Value),
				new SqlParameter("@ChangePoint", int.Parse(txtPoints.Text) * keyType),		
				new SqlParameter("@Memo", txt_Reason.Text),
				new SqlParameter("@AgentAccount", AUser.ExecAgentAccount),
			};

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_MemberPointEdit",
				param
			);

			int memberID = Convert.ToInt32(ds.Tables[0].Rows[0]["MemberID"]);
			string result = ds.Tables[0].Rows[0]["Result"].ToString();
			string errMsg = ds.Tables[0].Rows[0]["ErrMsg"].ToString();
			string isOnline = ds.Tables[0].Rows[0]["IsOnline"].ToString();

			if (result == "0")
			{
				BindData();

				ScriptManager.RegisterStartupScript(Page, GetType(), "message", "alert('" + "執行成功" + "')", true);
			}
			else
			{
				ScriptManager.RegisterStartupScript(Page, GetType(), "message", "alert('" + errMsg + "')", true);
			}
		}

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btn_Key_Command(object sender, CommandEventArgs e)
		{
			if (!Page.IsValid)
			{
				return;
			}

			if (e.CommandName == "KeyIn")
			{
				ChangeData(1);
			}
			else if (e.CommandName == "KeyOut")
			{
				ChangeData(-1);
			}			
		}

		protected void btn_Query_Click(object sender, EventArgs e)
		{
			BindData();
		}
	}
}