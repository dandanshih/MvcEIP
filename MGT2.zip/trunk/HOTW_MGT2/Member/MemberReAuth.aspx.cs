﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class MemberReAuth : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			
		}

		//查詢
		protected void btn_Query_Click(object sender, EventArgs e)
		{
			//至少輸入一個搜尋條件
			if (string.IsNullOrEmpty(txt_IP.Text) && string.IsNullOrEmpty(txt_MemberAccount.Text) && string.IsNullOrEmpty(txt_Points.Text))
			{
				lbl_Query_Info.Visible = true;
				grd_Member.Visible = false;
				return;
			}

			lbl_Query_Info.Visible = false;
			grd_Member.Visible = true;
			grd_Member.CurrentPageIndex = 1;
		}

		//重新認證
		protected void btn_ReAuth_Click(object sender, EventArgs e)
		{
			int intCounter = 0;
			AUser m_User = (AUser)Session["AUser"];
			string MemberID_PointYN = string.Empty;
			for (int i = 0; i < grd_Member.Rows.Count; i++)
			{
				RadioButton objRbo_ReAuthNoPoints = (RadioButton)grd_Member.Rows[i].FindControl("rdo_ReAuthNoPoints");
				RadioButton objRbo_ReAuthWithPoints = (RadioButton)grd_Member.Rows[i].FindControl("rdo_ReAuthWithPoints");

				if (objRbo_ReAuthNoPoints.Checked && objRbo_ReAuthNoPoints.Enabled)
				{
					// 不贈點重新驗證
					intCounter += 1;
					string strMemberID = grd_Member.DataKeys[i]["MemberID"].ToString();
					//sds_Member.InsertParameters["MemberID"].DefaultValue = strMemberID;
					//sds_Member.InsertParameters["IPAddr"].DefaultValue = Request.UserHostAddress;
					//sds_Member.InsertParameters["ExecAgentID"].DefaultValue = ((AUser)Session["AUser"]).ExecAgentID;
					//sds_Member.InsertParameters["ReAuthType"].DefaultValue = "Member_IsReAuthNoPoints";

					////會員重新認證
					//sds_Member.Insert();
					MemberID_PointYN += string.Format("{0},{1}|", strMemberID, "0");
					//踢玩家
					//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(strMemberID), int.Parse(AUser.ExecAgentID));

                    // 20110509 Phil: 改對前台發出登出命令
                    GameCommandHandler.LogoutMember(int.Parse(strMemberID));
				}
				else if (objRbo_ReAuthWithPoints.Checked && objRbo_ReAuthWithPoints.Enabled)
				{
					// 贈點重新驗證
					intCounter += 1;
					string strMemberID = grd_Member.DataKeys[i]["MemberID"].ToString();
					//sds_Member.InsertParameters["MemberID"].DefaultValue = strMemberID;
					//sds_Member.InsertParameters["IPAddr"].DefaultValue = Request.UserHostAddress;
					//sds_Member.InsertParameters["ExecAgentID"].DefaultValue = ((AUser)Session["AUser"]).ExecAgentID;
					//sds_Member.InsertParameters["ReAuthType"].DefaultValue = "Member_IsReAuthWithPoints";

					////會員重新認證
					//sds_Member.Insert();
					MemberID_PointYN += string.Format("{0},{1}|", strMemberID, "1");
					////踢玩家
					//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(strMemberID), int.Parse(AUser.ExecAgentID));

                    // 20110509 Phil: 改對前台發出登出命令
                    GameCommandHandler.LogoutMember(int.Parse(strMemberID));
				}
			}
			try
			{
				sds_Member.InsertParameters["IP"].DefaultValue = Request.UserHostAddress;
				sds_Member.InsertParameters["ExecAgentID"].DefaultValue = AUser.ExecAgentID;
				sds_Member.InsertParameters["ReAuthList"].DefaultValue = MemberID_PointYN;
				sds_Member.Insert();
				//顯示訊息
				ScriptManager.RegisterStartupScript(Page, GetType(), "alert", "alert('更新" + intCounter.ToString() + "筆資料');", true);
				grd_Member.DataBind();
			}
			catch (Exception ex)
			{
				ScriptManager.RegisterStartupScript(Page, GetType(), "alert", "alert('" + ex.Message + "');", true);
			}
		}

		//停用/啟用
		protected void grd_Member_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			string MemberID = e.CommandArgument.ToString();
			string LockDays = "";
			string LockType = "";
			string LockReason = "";

			switch (e.CommandName)
			{
				case "Activity":
					//啟用帳號
					LockDays = "0";
					// LockType = "解除停權";
					LockType = "0";
					break;
				case "PauseAccount":
					//停用帳號
					int iRowIndex = ((GridViewRow)((Button)e.CommandSource).NamingContainer).RowIndex;
					LockDays = ((DropDownList)grd_Member.Rows[iRowIndex].FindControl("ddl_Pause_Days")).SelectedValue;
					LockReason = ((TextBox)grd_Member.Rows[iRowIndex].FindControl("txt_Pause_Reason")).Text;
					if (LockDays == "999")
					{
						LockType = "2";
						LockDays = "0";
					}
					else
					{
						LockType = "1";
					}
					//踢玩家
					//AUser m_User = (AUser)Session["AUser"];
					//string sCmd = "267&" + m_User.AgentID + "&" + MemberID + "&0";
					//Utility.SendInfoToFrontServer(m_User.FrontServerIP, sCmd);
					//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(MemberID), int.Parse(AUser.ExecAgentID));

                    // 20110509 Phil: 改對前台發出登出命令
                    GameCommandHandler.LogoutMember(int.Parse(MemberID));

					break;
				default:
					break;
			}

			//Debug
			//txt_IP.Text = e.CommandName.ToString() + e.CommandArgument.ToString() + "-" + LockDays + ":" + LockType;

			//更新
			sds_Member.UpdateParameters["MemberID"].DefaultValue = MemberID;
			sds_Member.UpdateParameters["LockDays"].DefaultValue = LockDays;
			sds_Member.UpdateParameters["LockReason"].DefaultValue = LockReason;
			sds_Member.UpdateParameters["LockType"].DefaultValue = LockType;
			sds_Member.UpdateParameters["ExecAgentID"].DefaultValue = ((AUser)Session["AUser"]).ExecAgentID;
			sds_Member.Update();

			grd_Member.DataBind();
		}

		//取出總筆數
		protected void sds_Member_Selected(object sender, SqlDataSourceStatusEventArgs e)
		{
			this.grd_Member.TotalRecords = Convert.ToInt32(e.Command.Parameters["@TotalRecords"].Value);
		}
	}
}