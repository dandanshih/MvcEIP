﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Web;
using GS.Utilities;
using GWeb.AppLibs;

namespace GWeb.Member
{
	public partial class TradeCardQuery : GWeb.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btnQueryClick(object sender, EventArgs e)
		{
			if (txtAccount.Text.Trim().Length == 0)
			{
				GFC.Web.WebUtility.ResponseScript(Page, "alert('請輸入查詢帳號');", GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}


			
		}

		/// <summary>
		/// 載入資料
		/// </summary>
		protected void LoadData()
		{

			SqlDataReader sdr;

			#region 貼紙數量
			SqlParameter[] arParms0 =
			{
				new SqlParameter("@MemberAccount",txtAccount.Text),
				new SqlParameter("@BeginDate",DateRange1.StartDate),
				new SqlParameter("@EndDate",DateRange1.EndDate)
			};

			arParms0[arParms0.Length - 1].Direction = ParameterDirection.Output;

			arParms0[arParms0.Length - 2].Value = 25;
			sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_XXX", arParms0);

			gvCardStatic.DataSource = sdr;
			gvCardStatic.DataBind();
			sdr.Close();
			#endregion

			#region 貼紙交易資料
			
			
			SqlParameter[] arParms =
			{
				new SqlParameter("@MemberAccount",txtAccount.Text),
				new SqlParameter("@BeginDate",DateRange1.StartDate),
				new SqlParameter("@EndDate",DateRange1.EndDate),
				new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",SqlDbType.Int),
				new SqlParameter("@TotalRow",SqlDbType.BigInt)
			};

			arParms[arParms.Length - 1].Direction = ParameterDirection.Output;

			arParms[arParms.Length - 2].Value = 25;
			sdr = SqlHelper.ExecuteReader(WebConfig.connectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_MemberBirthdayQry", arParms);

			gv.DataSource = sdr;
			gv.DataBind();
			sdr.Close();

			gv.Caption = string.Format("{0}～{1}", DateRange1.StartDate, DateRange1.EndDate);

			UCPager1.FirstText = GetGlobalResourceObject("Pager", "FirstText").ToString();
			UCPager1.PreviousText = GetGlobalResourceObject("Pager", "PreviousText").ToString();
			UCPager1.NextText = GetGlobalResourceObject("Pager", "NextText").ToString();
			UCPager1.LastText = GetGlobalResourceObject("Pager", "LastText").ToString();
			UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());

			UCPager1.DataBind();

			#endregion
		}

		/// <summary>
		/// 按下取消待交換按鈕
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void btnCancelWaitTradeClick(object sender, EventArgs e)
		{ }
	}
}