﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;

namespace GWeb.Abnormal
{
	public partial class SingleGameWinlose : GWeb.AppLibs.FormBase
	{
		#region private

		private void BindData()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@StartDate", DateTime.Parse(UCDateRange1.StartDate)),
				new SqlParameter("@EndDate", DateTime.Parse(UCDateRange1.EndDate)),
				new SqlParameter("@GameTypeID", UCGameSelect1.GameTypeSeletedValue),
				new SqlParameter("@GameAreaType", ddlGameAreaType.SelectedItem.Value),
				new SqlParameter("@GameID", UCGameSelect1.GameSeletedValue),
				new SqlParameter("@WinValue", ddlTotalWinlose.SelectedItem.Value)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_SingleGameWinlose",
														   param);

			gvSingleGameWinlose.DataSource = objDtr;
			gvSingleGameWinlose.DataBind();

			objDtr.Close();
		}

		private void UpdateMemberState(string memberAccount, int state)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@ExecAccount", AUser.ExecAgentAccount),
				new SqlParameter("@MemberAccount", memberAccount.ToSafeString()),
				new SqlParameter("@AlarmType", state),
				new SqlParameter("@ReturnValue", SqlDbType.Int)
			};

			param[3].Direction = ParameterDirection.ReturnValue;

			SqlHelper.ExecuteNonQuery(WebConfig.connectionString, 
									  CommandType.StoredProcedure, 
									  "NSP_A_SetMemberAccountAlarmed", 
									  param);

			BindData();
		}

		#endregion

		#region protected

		protected void Page_LoadComplete(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				UCGameSelect1.DDLGameType.Items.RemoveAt(0);
				UCGameSelect1.BindData();
			}
		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
			{
				WebUtility.ResponseScript(Page, "alert('只能查詢2個月內的記錄!');", WebUtility.ResponseScriptPlace.NearFormEnd);
				return;
			}
			BindData();
		}

		protected void UCDateRange1_Change(object sender, EventArgs e)
		{
			//檢查是否可查詢資料
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;
			BindData();
		}

		protected void gvSingleGameWinlose_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			string memberAlarmType = e.CommandArgument.ToString().Split(',')[1];

			// 生效
			if (memberAlarmType == "0")
			{
				UpdateMemberState(e.CommandArgument.ToString().Split(',')[0], 2);
			}
			// 取消
			else if (memberAlarmType == "2")
			{
				UpdateMemberState(e.CommandArgument.ToString().Split(',')[0], 0);
			}
		}

		protected void gvSingleGameWinlose_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				// 轉換語系
				try
				{
                    ((Label)e.Row.FindControl("lblCurrentGame")).Text = Utility.GetGameENameMapping(((Label)e.Row.FindControl("lblCurrentGame")).Text).ToString();
				}
				catch
				{ 
				
				}

				AuthButton btnSetBlacklist = e.Row.FindControl("btnSetBlacklist") as AuthButton;
				// 如果是黑名單如何顯示取消按鈕並將字體改為紅色
				if (int.Parse(DataBinder.Eval(e.Row.DataItem, "MemberAlarmType").ToString()) > 0)
				{
					btnSetBlacklist.Text = "取消";
					btnSetBlacklist.ForeColor = System.Drawing.Color.Red;
				}
				else
				{
					btnSetBlacklist.Text = "生效";
					btnSetBlacklist.ForeColor = System.Drawing.Color.Black;
				}
			}
		}

		#endregion
	}
}