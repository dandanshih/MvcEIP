﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Abnormal
{
	public partial class MemberUseProductList : GWeb.AppLibs.FormBase
	{
		private void LoadData()
		{
			SqlParameter[] param =
			{
				new SqlParameter("@TotalRecords",SqlDbType.Int),
                new SqlParameter("@StartDate",DateRange1.StartDate),
                new SqlParameter("@EndDate",DateRange1.EndDate),
                new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
                new SqlParameter("@PageSize", UCPager1.PageSize)
			};

			param[0].Direction = ParameterDirection.Output;

			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_M_MemberUseProductList",
				param
			);

			gvProductList.DataSource = objDr;
			gvProductList.DataBind();

			UCPager1.RecordCount = int.Parse(param[0].Value.ToString());
			UCPager1.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
			if (!new AuthorityInfo().CheckAuthority(EnumAuthority.Query))
				return;

			UCPager1.CurrentPageNumber = 1;
			LoadData();
		}

		protected void Pager_Change(object sender, EventArgs e)
		{
			LoadData();
		}
	}
}