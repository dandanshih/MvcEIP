﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.Abnormal
{
    public partial class VersionMessage : GWeb.AppLibs.FormBase
    {
        protected void LoadData()
        {
            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@TotalRecords", SqlDbType.Int),
                new SqlParameter("@BType", "5"),
                new SqlParameter("@PageSize", UCPager1.PageSize),
                new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber)
                //new SqlParameter("@StartDate", dpStaticDateStart.SelectedDate.ToString("yyyy/MM/dd")),
                //new SqlParameter("@EndDate", dpStaticDateEnd.SelectedDate.ToString("yyyy/MM/dd"))
            };

            param[0].Direction = ParameterDirection.Output;

            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_HistoryBulletin_Get",
                param
            );

            grdMessageList.DataSource = objDr;
            grdMessageList.DataBind();

            UCPager1.RecordCount = int.Parse(param[0].Value.ToString());
            UCPager1.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dpStaticDateStart.SelectedDate = DateTime.Now;
                dpStaticDateEnd.SelectedDate = DateTime.Now;
                UCPager1.CurrentPageNumber = 1;
                LoadData();
            }
        }

        protected void Pager_Change(object sender, EventArgs e)
        {
            LoadData(); 
        }

        protected void grdMessageList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string State = "";
                switch(DataBinder.Eval(e.Row.DataItem, "State").ToString())
                {
                    case "SystemDefault":
                        State = "停用";
                        break;
                    case "Paused":
                        State = "停用";
                        break;
                    case "Using":
                        State = "播放中";
                        e.Row.Cells[4].FindControl("btnEdit").Visible = true;
                        break;
                    case "OverDue":
                        State = "停用";
                        break;
                }
                e.Row.Cells[0].Text = State;
                e.Row.Cells[2].Text = DataBinder.Eval(e.Row.DataItem, "StartDate").ToString() + " - <br />"
                                        + DataBinder.Eval(e.Row.DataItem, "EndDate").ToString();

                e.Row.Cells[3].Text = DataBinder.Eval(e.Row.DataItem, "Bcontent").ToString();
            }
        }

        protected void grdMessageList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@BulletinID", e.CommandArgument.ToString())
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_B_Bulletin_Pause",
                param
            );

            LoadData();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
			//if (Editor1.Content.Length > 3000)
			//{
			//    ScriptManager.RegisterStartupScript(this.Page, GetType(), "alert", "alert('內容文字過長！" + Editor1.Content.Length + "');", true);
			//    return;
			//}

            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@StartDate", dpStaticDateStart.SelectedDate.ToString("yyyy/MM/dd HH:mm:ss")),
                new SqlParameter("@EndDate", dpStaticDateEnd.SelectedDate.ToString("yyyy/MM/dd HH:mm:ss")),
                new SqlParameter("@BType", "Version"),
                new SqlParameter("@BContent", Editor1.Content),
				new SqlParameter("@Flag", ddl_PlatformType.SelectedValue)
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.connectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_B_Bulletin_New",
                param
            );

            LoadData();
        }
    }
}