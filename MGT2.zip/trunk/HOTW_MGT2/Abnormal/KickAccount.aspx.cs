﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GFC.Web;
using GWeb.AppLibs;
using System.Web.UI;

namespace GWeb.Abnormal
{
	public partial class KickAccount : GWeb.AppLibs.FormBase
	{
		#region private

		/// <summary>
		/// 驗證萬用字元如果包含 %，須判斷字元長度是不是大於等於 2。
		/// </summary>
		private bool ValidateText(string keyword)
		{
			if (keyword.Contains("%") && keyword.Replace("%", "").Length < 2)
			{
				return false;
			}

			return true;
		}

		/// <summary>
		/// 讀取資料。
		/// </summary>
		/// <param name="account">要搜尋的帳號。</param>
		/// <param name="accountType">帳號類別。 (1：會員 2：客服 3：儲值代理 4：暱稱)</param>
		private void BindData(string account, int accountType)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@Account", account),
				new SqlParameter("@AccountType", accountType),
				new SqlParameter("@ExecAgentID", int.Parse(AUser.ExecAgentID)),
				new SqlParameter("@NickName", txtNickName.Text)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														   CommandType.StoredProcedure,
														   "NSP_AgentWeb_R_KickOnline_List",
														   param);
            

			if (objDtr.HasRows)
			{
				switch (accountType)
				{
					case 1:
						gvMemberAccount.DataSource = objDtr;
						divMemberAccount.Visible = true;
						divCSAccount.Visible = false;
						divStoreAgentAccount.Visible = false;
						divNickName.Visible = false;
						gvMemberAccount.DataBind();
						break;
					case 2:
						gvCSAccount.DataSource = objDtr;
						divMemberAccount.Visible = false;
						divCSAccount.Visible = true;
						divStoreAgentAccount.Visible = false;
						divNickName.Visible = false;
						gvCSAccount.DataBind();
						break;
					case 3:
						gvStoreAgentAccount.DataSource = objDtr;
						divMemberAccount.Visible = false;
						divCSAccount.Visible = false;
						divStoreAgentAccount.Visible = true;
						divNickName.Visible = false;
						gvStoreAgentAccount.DataBind();
						break;
					case 4:
						gvNickName.DataSource = objDtr;
						divMemberAccount.Visible = false;						
						divCSAccount.Visible = false;
						divStoreAgentAccount.Visible = false;
						divNickName.Visible = true;
						gvNickName.DataBind();
						break;
				}				
			}
			else
			{
				divMemberAccount.Visible = false;
				divCSAccount.Visible = false;
				divStoreAgentAccount.Visible = false;
				divNickName.Visible = false;

				WebUtility.ResponseScript(Page, "alert('目前沒有任何資料')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
			
			objDtr.Close();
		}

		/// <summary>
		/// 踢代理商。
		/// </summary>
		/// <param name="agentID">指定要踢的代理商編號。</param>
		/// <param name="execAgentID">執行動作的代理商編號。</param>
		private void KickAgent(int agentID, int execAgentID)
		{

            // 20110510 Phil: 加入一筆踢帳號佇列
            Utility.KickAgentQueue.Add(agentID);

			WebConfig.KickAgent(agentID, execAgentID);
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btnMemberAccountQuery_Click(object sender, EventArgs e)
		{
			if (ValidateText(txtMemberAccount.Text))
			{
				BindData(txtMemberAccount.Text, 1);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('目前沒有任何資料')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		protected void btnNickNameQuery_Click(object sender, EventArgs e)
		{
			if (ValidateText(txtNickName.Text))
			{
				BindData(txtNickName.Text, 4);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('目前沒有任何資料')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		protected void btnCSAccountQuery_Click(object sender, EventArgs e)
		{
			if (ValidateText(txtCSAccount.Text))
			{
				BindData(txtCSAccount.Text, 2);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('目前沒有任何資料')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		protected void btnStoreAgentAccountQuery_Click(object sender, EventArgs e)
		{
			if (ValidateText(txtStoreAgentAccount.Text))
			{
				BindData(txtStoreAgentAccount.Text, 3);
			}
			else
			{
				WebUtility.ResponseScript(Page, "alert('目前沒有任何資料')", WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		protected void btnCompelKick_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(txtMemberID.Text))
			{
				return;
			}

			GS.ServerCommander.FSCommander.FS_AS_WEB_KICK_USER(txtMemberID.Text);

			WebUtility.ResponseScript(Page, "alert('已執行踢除動作')", WebUtility.ResponseScriptPlace.NearFormEnd);
		}

		protected void gvMemberAccount_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				try
				{
					e.Row.Cells[3].Text = "";

					// 轉換語系
					if (DataBinder.Eval(e.Row.DataItem, "PlayingGameEName").ToString().TrimEnd().Length > 0)
					{
						e.Row.Cells[3].Text += "◎老幣區：" + Utility.GetGameENameMapping(DataBinder.Eval(e.Row.DataItem, "PlayingGameEName").ToString());
					}

					if (DataBinder.Eval(e.Row.DataItem, "UPlayingGameEName").ToString().TrimEnd().Length > 0)
					{	
						e.Row.Cells[3].Text += "◎爽幣區：" + Utility.GetGameENameMapping(DataBinder.Eval(e.Row.DataItem, "UPlayingGameEName").ToString());
					}					 
				}
				catch
				{ 
				
				}
			}
		}

		protected void gvNickName_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				e.Row.Cells[3].Text = "";

				try
				{
					// 轉換語系
					if (DataBinder.Eval(e.Row.DataItem, "PlayingGameEName").ToString().TrimEnd().Length > 0)
					{
						e.Row.Cells[3].Text += "◎老幣區：" + Utility.GetGameENameMapping(DataBinder.Eval(e.Row.DataItem, "PlayingGameEName").ToString());
					}

					if (DataBinder.Eval(e.Row.DataItem, "UPlayingGameEName").ToString().TrimEnd().Length > 0)
					{
						e.Row.Cells[3].Text += "◎爽幣區：" + Utility.GetGameENameMapping(DataBinder.Eval(e.Row.DataItem, "UPlayingGameEName").ToString());
					}
				}
				catch
				{

				}
			}
		}

		// 踢會員
		protected void gvMemberAccount_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "Kick")
			{
				GS.ServerCommander.FSCommander.FS_AS_WEB_KICK_USER(e.CommandArgument.ToString());
				//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(e.CommandArgument.ToString()),int.Parse(AUser.ExecAgentID));

                // 20110509 Phil: 改對前台發出登出命令
                GameCommandHandler.LogoutMember(int.Parse(e.CommandArgument.ToString()));
				System.Threading.Thread.Sleep(1000);

                btnMemberAccountQuery_Click(null, null);
			}
		}

		// 踢會員
		protected void gvNickName_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "Kick")
			{
				GS.ServerCommander.FSCommander.FS_AS_WEB_KICK_USER(e.CommandArgument.ToString());
				//WebConfig.KickMember(AUser.FrontServerIP, int.Parse(e.CommandArgument.ToString()),int.Parse(AUser.ExecAgentID));

				// 20110509 Phil: 改對前台發出登出命令
				GameCommandHandler.LogoutMember(int.Parse(e.CommandArgument.ToString()));
				System.Threading.Thread.Sleep(1000);

				btnNickNameQuery_Click(null, null);
			}
		}

		protected void gvCSAccount_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 踢客服
			if (e.CommandName == "Kick")
			{
				KickAgent(int.Parse(e.CommandArgument.ToString()), int.Parse(AUser.ExecAgentID));
				gvCSAccount.DataBind();
			}
		}

		protected void gvStoreAgentAccount_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 踢儲值代理
			if (e.CommandName == "Kick")
			{
				KickAgent(int.Parse(e.CommandArgument.ToString()), int.Parse(AUser.ExecAgentID));
				gvStoreAgentAccount.DataBind();
			}
		}

		#endregion
	}
}