﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.AppUserControls.SiteMap
{
	public partial class UCSiteMap : UCBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadPageLocation();
			}
		}

		/// <summary>
		/// 讀取本頁的路徑位置，和頁面抬頭
		/// </summary>
		private void LoadPageLocation()
		{
			SqlParameter[] param = 
			{
				new SqlParameter("@NowUrl", Request.AppRelativeCurrentExecutionFilePath)
			};
			
			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
															CommandType.StoredProcedure,
															"NSP_AgentWeb_R_ReadPath",
															param);

			string sPagePath = "", sTmp = "", sHighLight = "";

			while (objDtr.Read())
			{
				try
				{
					//sTmp = GetLocalResourceObject("Func_" + objDtr["FunctionEName"].ToString()).ToString();
					sTmp = objDtr["FunctionName"].ToString();
				}
				catch
				{
					//sTmp = objDtr["FunctionEName"].ToString() + "-- 未設定語系!!";
					sTmp = objDtr["FunctionName"].ToString();
				}

				if (objDtr["FunctionURL"].ToString() == Request.AppRelativeCurrentExecutionFilePath)
					sHighLight = "<b><font color=red>{0}</font></b>";
				else
					sHighLight = "<span class=\"txtGray12\">{0}</span>";

				if (sPagePath == "")
					sPagePath = String.Format(sHighLight, sTmp);
				else
					sPagePath = sPagePath + " > " + String.Format(sHighLight, sTmp);

				//為了要解決轉頁時，SiteMap路徑不見的問題
				AUser.SourcePage = sPagePath;
			}

			
			//為了要解決轉頁時，SiteMap路徑不見的問題
			if (sPagePath.Trim().Length != 0)
			{

				ltlText.Text = sPagePath;
			}
			else
			{

				ltlText.Text = AUser.SourcePage;
			}

			//寫Log至資料庫
			SqlParameter[] param2 = new SqlParameter[]
				{
					new SqlParameter("@AgentID",AUser.AgentID),
					new SqlParameter("@ReportName",sTmp),
					new SqlParameter("@LoginIP",Request.UserHostAddress),
					new SqlParameter("@SessionID",Session.SessionID),
					new SqlParameter("@Path",Request.Url.ToString())

				};
			SqlHelper.ExecuteNonQuery
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_AgentUsedRecord",
				param2
			);

			objDtr.Close();

		}

	}
}