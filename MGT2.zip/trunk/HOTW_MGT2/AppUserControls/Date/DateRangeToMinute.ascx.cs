﻿using System;
using GFC.Web;

namespace GWeb {
    public partial class DateRangeToMinute : UserControlBase {
        #region Property
        public string StartDate {
            //get { return dpStartDate.SelectedDate.ToString("yyyy/MM/dd ") + cboStartHour.SelectedValue + ":" + cboStartMinute.SelectedValue + ":00"; }
			get { return dpStartDate.SelectedDate.ToString("yyyy/MM/dd HH:mm:00"); }
        }

        public string EndDate {
			//get { return dpEndDate.SelectedDate.ToString("yyyy/MM/dd ") + cboEndHour.SelectedValue + ":" + cboEndMinute.SelectedValue + ":59"; }
			get { return dpEndDate.SelectedDate.ToString("yyyy/MM/dd HH:mm:59"); }
        }
		public bool Desc {
			set 
			{
				if (value == false)
				{
					tdSpace.Style.Add("display", "none");
					tdDesc.Style.Add("display", "none");					
				}			
			}
		}
        #endregion

        protected void Page_Init(object sender, EventArgs e) {
            if (!IsPostBack) {
                dpStartDate.SelectedDate = DateTime.Now;
                dpEndDate.SelectedDate = DateTime.Now;
				//cboStartHour.SelectedValue = DateTime.Now.Hour.ToString();
				//cboEndHour.SelectedValue = DateTime.Now.Hour.ToString();
				//cboStartMinute.SelectedValue = DateTime.Now.Minute.ToString();
				//cboEndMinute.SelectedValue = DateTime.Now.Minute.ToString();
            }
        }

        protected void Page_Load(object sender, EventArgs e) {

        }
    }
}