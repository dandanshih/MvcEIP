﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.AppUserControls.Date
{
    public partial class UCDateRange : System.Web.UI.UserControl
    {
        #region Member

        private int m_TimePeriod = 10;
        private string m_DefaultStartTime = null;
        private string m_DefaultEndTime = null;
        private bool m_IsLockHour = false;
        private bool m_IsLockMinute = true;
        private bool m_IsLockSecond = true;

        #endregion

        #region Property

        /// <summary>
        /// 取得或設定按鈕命令名稱。
        /// </summary>
        public string CommandName
        {
            get;
            set;
        }
        /// <summary>
        /// 取得或設定預設起始時間
        /// </summary>
        public string DefaultStartTime
        {
            get { return this.m_DefaultStartTime; }
            set { this.m_DefaultStartTime = value; }
        }
        /// <summary>
        /// 取得或設定預設結束時間
        /// </summary>
        public string DefaultEndTime
        {
            get { return this.m_DefaultEndTime; }
            set { this.m_DefaultEndTime = value; }
        }

        /// <summary>
        /// 取得或設定日期格式。
        /// </summary>
        public string DateFormat
        {
            get;
            set;
        }

        /// <summary>
        /// 取得或設定驗證群組。
        /// </summary>
        public string ValidationGroup
        {
            get { return valcMessage.ValidationGroup; }
            set
            {
                valcMessage.ValidationGroup = value;
                ibtnToday.ValidationGroup = value;
                ibtnYesterday.ValidationGroup = value;
                ibtnThisWeek.ValidationGroup = value;
                ibtnLastWeek.ValidationGroup = value;
                ibtnThisMonth.ValidationGroup = value;
                ibtnLastMonth.ValidationGroup = value;
            }
        }

        /// <summary>
        /// 設定控制項是否啟用。
        /// </summary>
        public bool Enable
        {
            set
            {
                dpStartDate.Enabled = value;
                dpEndDate.Enabled = value;
            }
        }

        /// <summary>
        /// 設定控制項寬度。
        /// </summary>
        public string Width
        {
            set { divDataRange.Style.Add("width", value); }
        }

        /// <summary>
        /// 取得或設定標頭文字。
        /// </summary>
        public string Title
        {
            get { return lblTitleDateRange.Text; }
            set { lblTitleDateRange.Text = value; }
        }

        /// <summary>
        /// 是否顯示標頭文字。
        /// </summary>
        public bool TitleVisible
        {
            get { return divTitle.Visible; }
            set { divTitle.Visible = value; }
        }

        /// <summary>
        /// 設定記帳啟算時間。 (如果是 12 點就填 12 ，如果是凌晨 0 點，就填 0 ，如果是 6 點就填 6)
        /// </summary>
        public int TimePeriod
        {
            get { return m_TimePeriod; }
            set { m_TimePeriod = value; }
        }

        /// <summary>
        /// 是否鎖定時不能修改。
        /// </summary>
        public bool IsLockHour
        {
            get { return m_IsLockHour; }
            set { m_IsLockHour = value; }
        }

        /// <summary>
        /// 是否鎖定分不能修改。
        /// </summary>
        public bool IsLockMinute
        {
            get { return m_IsLockMinute; }
            set { m_IsLockMinute = value; }
        }

        /// <summary>
        /// 是否鎖定秒不能修改。
        /// </summary>
        public bool IsLockSecond
        {
            get { return m_IsLockSecond; }
            set { m_IsLockSecond = value; }
        }

        /// <summary>
        /// 是否只顯示單一日期。
        /// </summary>
        public bool IsSingleDate
        {
            set
            {
                divDash.Visible = !value;
                divEndDate.Visible = !value;
                valcMessage.ValidationGroup = "";
                valcMessage.Enabled = !value;
            }
        }

        /// <summary>
        /// 是否顯示日期按鈕。
        /// </summary>
        public bool DateRangeButtonVisible
        {
            get { return DateRangeButton.Visible; }
            set { DateRangeButton.Visible = value; }
        }

        /// <summary>
        /// 是否顯示今天按鈕。
        /// </summary>
        public bool TodayButtonVisible
        {
            get { return ibtnToday.Visible; }
            set { ibtnToday.Visible = value; }
        }

        /// <summary>
        /// 是否顯示昨天按鈕。
        /// </summary>
        public bool YesterdayButtonVisible
        {
            get { return ibtnYesterday.Visible; }
            set { ibtnYesterday.Visible = value; }
        }

        /// <summary>
        /// 是否顯示本周按鈕。
        /// </summary>
        public bool ThisWeekButtonVisible
        {
            get { return ibtnThisWeek.Visible; }
            set { ibtnThisWeek.Visible = value; }
        }

        /// <summary>
        /// 是否顯示上周按鈕。
        /// </summary>
        public bool LastWeekButtonVisible
        {
            get { return ibtnLastWeek.Visible; }
            set { ibtnLastWeek.Visible = value; }
        }

        /// <summary>
        /// 是否顯示本月按鈕。
        /// </summary>
        public bool ThisMonthButtonVisible
        {
            get { return ibtnThisMonth.Visible; }
            set { ibtnThisMonth.Visible = value; }
        }

        /// <summary>
        /// 是否顯示上周按鈕。
        /// </summary>
        public bool LastMonthButtonVisible
        {
            get { return ibtnLastMonth.Visible; }
            set { ibtnLastMonth.Visible = value; }
        }

        /// <summary>
        /// 起始時間。
        /// </summary>
        public string StartDate
        {
            get
            {
				// 判斷時間選擇是否錯誤
				DateTime ErrorDate = DateTime.Parse("0001/1/1 12:00:00");
				if (dpStartDate.SelectedDate == ErrorDate)
				{
					ScriptManager.RegisterStartupScript(Page, GetType(), "ErrorDate", "alert('開始時間設定錯誤');", true);
					dpStartDate.SelectedDate = DateTime.Now;
					return DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
				}
                // 防止 Render 之後取得 SelectedDate 屬性時會發生例外.
                try
                {
                    return dpStartDate.SelectedDate.ToString("yyyy/MM/dd HH:mm:ss");
                }
                catch
                {
                    return "";
                }
            }
            set
            {
                dpStartDate.SelectedDate = DateTime.Parse(value);
            }
        }

        /// <summary>
        /// 結束時間
        /// </summary>
        public string EndDate
        {
            get
            {
				// 判斷時間選擇是否錯誤
				DateTime ErrorDate = DateTime.Parse("0001/1/1 12:00:00");
				if (dpEndDate.SelectedDate == ErrorDate)
				{
					ScriptManager.RegisterStartupScript(Page, GetType(), "ErrorDate", "alert('結束時間設定錯誤');", true);
					dpEndDate.SelectedDate = DateTime.Now;
					return DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
				}
                // 防止 Render 之後取得 SelectedDate 屬性時會發生例外.
                try
                {
                    return dpEndDate.SelectedDate.ToString("yyyy/MM/dd HH:mm:ss");
                }
                catch
                {
                    return "";
                }
            }
            set
            {
                dpEndDate.SelectedDate = DateTime.Parse(value);
            }
        }

        public bool CancelValidator
        {
            get { return valcMessage.Visible; }
            set { valcMessage.Visible = value; }
        }

        #endregion

        #region Protected Method

        protected void Page_Init(object sender, EventArgs e)
        {
            // 預設今天
            if (!IsPostBack)
            {
                //try
                //{
                //    dpStartDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DefaultStartTime);
                //    dpEndDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DefaultEndTime);
                //}
                //catch (Exception)
                //{
                DateTime StartTimeDatumLine = Convert.ToDateTime(DateTime.Now.AddHours(0 - m_TimePeriod).ToShortDateString() + " " + m_TimePeriod.ToString("d2") + ":00:00");
                dpStartDate.SelectedDate = StartTimeDatumLine;
                dpEndDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
                //}
            }

            // 不可修改秒的欄位
            if (!m_IsLockHour && !m_IsLockMinute && m_IsLockSecond)
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd HH:mm:" + dpStartDate.SelectedDate.ToString("ss");
                dpEndDate.PickerFormat = "yyyy/MM/dd HH:mm:" + dpEndDate.SelectedDate.ToString("ss");
            }
            // 不可修改分的欄位
            else if (!m_IsLockHour && m_IsLockMinute && !m_IsLockSecond)
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd HH:" + dpStartDate.SelectedDate.ToString("mm") + ":ss";
                dpEndDate.PickerFormat = "yyyy/MM/dd HH:" + dpEndDate.SelectedDate.ToString("mm") + ":ss";
            }
            // 不可修改時的欄位
            else if (m_IsLockHour && !m_IsLockMinute && !m_IsLockSecond)
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd " + dpStartDate.SelectedDate.ToString("HH") + ":mm:ss";
                dpEndDate.PickerFormat = "yyyy/MM/dd " + dpEndDate.SelectedDate.ToString("HH") + ":mm:ss";
            }
            // 不可修改分秒的欄位
            else if (!m_IsLockHour && m_IsLockMinute && m_IsLockSecond)
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd HH:" + dpStartDate.SelectedDate.ToString("mm:ss");
                dpEndDate.PickerFormat = "yyyy/MM/dd HH:" + dpEndDate.SelectedDate.ToString("mm:ss");
            }
            // 不可修改時分的欄位
            else if (m_IsLockHour && m_IsLockMinute && !m_IsLockSecond)
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd " + dpStartDate.SelectedDate.ToString("HH:mm") + ":ss";
                dpEndDate.PickerFormat = "yyyy/MM/dd " + dpEndDate.SelectedDate.ToString("HH:mm") + ":ss";
            }
            // 不可修改時秒的欄位
            else if (m_IsLockHour && !m_IsLockMinute && m_IsLockSecond)
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd " + dpStartDate.SelectedDate.ToString("HH") + ":mm:" + dpStartDate.SelectedDate.ToString("ss");
                dpEndDate.PickerFormat = "yyyy/MM/dd " + dpEndDate.SelectedDate.ToString("HH") + ":mm:" + dpEndDate.SelectedDate.ToString("ss");
            }
            // 不可修改時分秒的欄位
            else if (m_IsLockHour && m_IsLockMinute && m_IsLockSecond)
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd " + dpStartDate.SelectedDate.ToString("HH:mm:ss");
                dpEndDate.PickerFormat = "yyyy/MM/dd " + dpEndDate.SelectedDate.ToString("HH:mm:ss");
            }
            else
            {
                dpStartDate.PickerFormat = "yyyy/MM/dd HH:mm:ss";
                dpEndDate.PickerFormat = "yyyy/MM/dd HH:mm:ss";
            }

            if (!string.IsNullOrEmpty(DateFormat))
            {
                dpStartDate.PickerFormat = DateFormat;
                dpEndDate.PickerFormat = DateFormat;
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // 預設今天
                //DateTime StartTimeDatumLine = Convert.ToDateTime(DateTime.Now.AddHours(0 - m_TimePeriod).ToShortDateString() + " " + m_TimePeriod.ToString("d2") + ":00:00");
                //dpStartDate.SelectedDate = StartTimeDatumLine;
                //dpEndDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
                //ChangeDateRange("Today", e);
                // 設定日期格式

            }

        }

        protected void btnDateRange_Click(object sender, ImageClickEventArgs e)
        {
            CommandName = ((ImageButton)sender).CommandName.ToString();
            ChangeDateRange(((ImageButton)sender).CommandName.ToString(), e);
        }

        #endregion

        #region Public Method

        /// <summary>
        /// 改變日期元件的時間。
        /// </summary>
        /// <param name="CommandName">命令類別。</param>
        /// <param name="e"></param>
        public void ChangeDateRange(string CommandName, EventArgs e)
        {
            // 時間計算的基準線  (預設為本日的開始)
            DateTime StartTimeDatumLine = Convert.ToDateTime(DateTime.Now.AddHours(0 - m_TimePeriod).ToShortDateString() + " " + m_TimePeriod.ToString("d2") + ":00:00");

            switch (CommandName)
            {
                case "Today":
                    {
                        dpStartDate.SelectedDate = StartTimeDatumLine;
                        dpEndDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
                        break;
                    }
                case "Yesterday":
                    {
                        dpStartDate.SelectedDate = StartTimeDatumLine.AddDays(-1);
                        dpEndDate.SelectedDate = Convert.ToDateTime(dpStartDate.SelectedDate.AddDays(1).AddMinutes(-1).ToString("yyyy/MM/dd ") + ((24 + (m_TimePeriod - 1)) % 24).ToString("d2") + ":59:59");
                        break;
                    }
                case "ThisWeek":
                    {
						// 預設週四為第一天
						int iTodayOfWeek = (Convert.ToInt32(StartTimeDatumLine.DayOfWeek) + 3) % 7;
                        // 預設週一為第一天
                        // int iTodayOfWeek = (Convert.ToInt32(StartTimeDatumLine.DayOfWeek) + 6) % 7;
                        dpStartDate.SelectedDate = StartTimeDatumLine.AddDays(-iTodayOfWeek);
                        dpEndDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
                        break;
                    }
                case "LastWeek":
                    {
						// 預設週四為第一天
						int iTodayOfWeek = (Convert.ToInt32(StartTimeDatumLine.DayOfWeek) + 3) % 7;
                        // 預設週一為第一天
                        // int iTodayOfWeek = (Convert.ToInt32(StartTimeDatumLine.DayOfWeek) + 6) % 7;
                        dpStartDate.SelectedDate = StartTimeDatumLine.AddDays(-iTodayOfWeek - 7);
                        dpEndDate.SelectedDate = Convert.ToDateTime(dpStartDate.SelectedDate.AddDays(7).AddMinutes(-1).ToString("yyyy/MM/dd ") + ((24 + (m_TimePeriod - 1)) % 24).ToString("d2") + ":59:59");
                        break;
                    }
                case "ThisMonth":
                    {
                        int iDays = StartTimeDatumLine.Day - 1;
                        dpStartDate.SelectedDate = StartTimeDatumLine.AddDays(-iDays);
                        dpEndDate.SelectedDate = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
                        break;
                    }
                case "LastMonth":
                    {
                        int iDays = StartTimeDatumLine.Day - 1;
                        dpStartDate.SelectedDate = StartTimeDatumLine.AddDays(-iDays).AddMonths(-1);
                        dpEndDate.SelectedDate = Convert.ToDateTime(dpStartDate.SelectedDate.AddMonths(1).AddMinutes(-1).ToString("yyyy/MM/dd ") + ((24 + (m_TimePeriod - 1)) % 24).ToString("d2") + ":59:59");
                        break;
                    }
            }

            if (Change != null)
            {
                Change(this, e);
            }
        }

        #endregion

        #region Event

        /// <summary>
        /// 建立事件。
        /// </summary>
        public event EventHandler<EventArgs> Change;

        #endregion
    }
}