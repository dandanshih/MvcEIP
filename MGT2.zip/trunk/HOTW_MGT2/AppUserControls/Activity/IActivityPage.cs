﻿//-----------------------------------------------------------------------
// <copyright file="IActivityPage.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using GWeb.Models;
using System.Collections.Generic;
namespace GWeb.AppUserControls.Activity
{
    /// <summary>
    /// Activity Page Interface
    /// </summary>
    public interface IActivityPage
    {
        /// <summary>
        /// Gets Game Activity Context
        /// </summary>
        Game_Activity_Context GameActivityContext { get; }

        /// <summary>
        /// Gets Activity ID
        /// </summary>
        int ActivityID { get; }

        /// <summary>
        /// Gets Mission ID
        /// </summary>
        int MissionID { get; }

        /// <summary>
        /// Gets TempScheduleMissionGift List
        /// </summary>
        List<TempScheduleMissionGift> TempScheduleMissionGiftList { get; }

        /// <summary>
        /// Gets Item List Collection
        /// </summary>
        List<ItemList> ItemList { get; }

        /// <summary>
        /// Gets Game List Collection
        /// </summary>
        List<G_Game> GameList { get; }

        /// <summary>
        /// Gets MissionRule List Collection
        /// </summary>
        List<C_MissionRule> MissionRuleList { get; }

        /// <summary>
        /// 關閉所有User Control
        /// </summary>
        void CloseAllUserControl();
    }
}