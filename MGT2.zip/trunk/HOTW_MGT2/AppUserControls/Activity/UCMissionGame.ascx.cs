﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.AppUserControls.Activity
{
    public partial class UCMissionGame : System.Web.UI.UserControl
    {
        public event EventHandler<MissionEventArgs> OnGridViewClick;

        public string GetGameName(object gameid)
        {
            int id = int.TryParse(gameid.ToString(), out id) ? id : 0;
            var item = ((IActivityPage)this.Page).GameList.Find(x => x.GameID == id);
            return item == null ? string.Empty : item.GameName;
        }

        /// <summary>
        /// 資料分頁
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_MissionGame_Change(object sender, EventArgs e)
        {
            this.LoadData();
        }

        /// <summary>
        /// 繫結遊戲對應
        /// </summary>
        public void LoadData()
        {
            int take = this.UCPager_MissionGame.PageSize;
            int skip = (this.UCPager_MissionGame.CurrentPageNumber - 1) * take;
            var query = ((IActivityPage)this.Page).GameActivityContext.MissionGame
                .Where(x => x.MissionID == ((IActivityPage)this.Page).MissionID);

            // 繫結分頁筆數
            this.UCPager_MissionGame.RecordCount = query.Count();
            this.UCPager_MissionGame.DataBind();

            var missionGameList = query.ToList();
            var aryGroup = new[] { 0, 1, 2, 3, 4, 5, 6};
            var GameList = from a in
                               from x in ((IActivityPage)this.Page).GameList
                               from y in aryGroup
                               select new { GameID = x.GameID + "_" + y, GameName = x.GameID + "_" + x.GameName + "_" + y }
                           where !(
                            from z in
                                from c in missionGameList
                                select new { GameID = c.GameID + "_" + c.GroupID }
                            select z.GameID).Contains(a.GameID)
                           select a;

            this.DDL_MissionGame_MissionRuleID.DataSource = ((IActivityPage)this.Page).MissionRuleList;
            this.DDL_MissionGame_MissionRuleID.DataValueField = "MissionRuleID";
            this.DDL_MissionGame_MissionRuleID.DataTextField = "MissionRuleName";
            this.DDL_MissionGame_MissionRuleID.DataBind();

            // 繫結遊戲資料
            this.DDL_MissionGame_GameGroupID.DataSource = GameList;
            this.DDL_MissionGame_GameGroupID.DataValueField = "GameID";
            this.DDL_MissionGame_GameGroupID.DataTextField = "GameName";
            this.DDL_MissionGame_GameGroupID.DataBind();

            this.GV_MissionGame.DataSource = query
                .Include(x => x.C_MissionRule)
                .OrderBy(x => x.MissionGameID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_MissionGame.DataBind();
        }

        /// <summary>
        /// 新增遊戲對應
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_MissionGame_Add_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int missionid = ((IActivityPage)this.Page).MissionID;
                string[] aryGameGroup = DDL_MissionGame_GameGroupID.SelectedValue.Split(new string[] { "_" }, StringSplitOptions.RemoveEmptyEntries);
                int gameid = int.TryParse(aryGameGroup[0], out gameid) ? gameid : 0;
                int groupid = int.TryParse(aryGameGroup[1], out groupid) ? groupid : 0;
                int missionRuleID = int.TryParse(DDL_MissionGame_MissionRuleID.SelectedValue, out missionRuleID) ? missionRuleID : 0;
                bool isenable = bool.TryParse(DDL_MissionGame_IsEnable.SelectedValue, out isenable) ? isenable : false;

                MissionGame model = new MissionGame()
                {
                    MissionID = missionid,
                    GameID = gameid,
                    GroupID = groupid,
                    MissionRuleID = missionRuleID,
                    IsEnable = isenable
                };

                ((IActivityPage)this.Page).GameActivityContext.MissionGame.Add(model);
                ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                if (this.OnGridViewClick != null)
                {
                    this.OnGridViewClick(this, null);
                }
            }
        }

        /// <summary>
        /// 刪除遊戲對應
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_MissionGame_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
            int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

            switch (e.CommandName)
            {
                case "DelMissionGame":
                    var item = ((IActivityPage)this.Page).GameActivityContext.MissionGame.Find(id);

                    if (item != null)
                    {
                        ((IActivityPage)this.Page).GameActivityContext.MissionGame.Remove(item);
                        ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                        if (this.OnGridViewClick != null)
                        {
                            this.OnGridViewClick(this, null);
                        }
                    }

                    break;
                default:
                    break;
            }
        }
    }
}