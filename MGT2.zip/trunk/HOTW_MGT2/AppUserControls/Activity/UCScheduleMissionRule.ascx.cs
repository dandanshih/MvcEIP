﻿using GS.Utilities;
using GWeb.AppLibs;
using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.AppUserControls.Activity
{
    public partial class UCScheduleMissionRule : System.Web.UI.UserControl
    {
        public string GetGameName(object gameid)
        {
            int id = int.TryParse(gameid.ToString(), out id) ? id : 0;
            var item = ((IActivityPage)this.Page).GameList.Find(x => x.GameID == id);
            return item == null ? string.Empty : item.GameName;
        }

        /// <summary>
        /// 跳頁重新繫結資料
        /// </summary>
        protected void UCPager_ScheduleMissionRule_Change(object sender, EventArgs e)
        {
            this.LoadData();
        }

        /// <summary>
        /// 繫結遊戲對應排程
        /// </summary>
        public void LoadData()
        {
            this.DP_ScheduleMissionRule_ScheduleDateTime.SelectedDate = DateTime.Now.AddMinutes(10);

            int take = this.UCPager_ScheduleMissionRule.PageSize;
            int skip = (this.UCPager_ScheduleMissionRule.CurrentPageNumber - 1) * take;
            var query = ((IActivityPage)this.Page).GameActivityContext.ScheduleMissionRule
                    .Where(x => x.MissionID == ((IActivityPage)this.Page).MissionID);

            // 繫結分頁筆數
            this.UCPager_ScheduleMissionRule.RecordCount = query.Count();
            this.UCPager_ScheduleMissionRule.DataBind();

            // 取出初始設定資料
            var missionGameList = ((IActivityPage)this.Page).GameActivityContext.MissionGame
                .Where(x => x.MissionID == ((IActivityPage)this.Page).MissionID)
                .ToList();

            if (missionGameList.Count > 0)
            {
                this.Visible = true;

                // 遊戲群組
                var aryGroup = new[] { 0, 1, 2, 3, 4, 5, 6 };

                // 用初始設定資料選擇出遊戲列表
                var gameidList = from c in
                                     from x in ((IActivityPage)this.Page).GameList
                                     from y in aryGroup
                                     select new { GameID = x.GameID + "_" + y, GameName = x.GameID + "_" + x.GameName + "_" + y }
                                 where (
                                    from z in
                                        from o in missionGameList
                                        select new { GameID = o.GameID + "_" + o.GroupID }
                                    select z.GameID).Contains(c.GameID)
                                 select c;

                // 繫結遊戲資料
                this.DDL_ScheduleMissionRule_GameGroupID.DataSource = gameidList;
                this.DDL_ScheduleMissionRule_GameGroupID.DataValueField = "GameID";
                this.DDL_ScheduleMissionRule_GameGroupID.DataTextField = "GameName";
                this.DDL_ScheduleMissionRule_GameGroupID.DataBind();

                // 繫結排程資料
                this.GV_ScheduleMissionRule.DataSource = query
                    .OrderByDescending(x => x.SID)
                    .Skip(skip)
                    .Take(take)
                    .Include(x => x.C_ScheduleState)
                    .ToList();
                this.GV_ScheduleMissionRule.DataBind();
            }
            else
            {
                this.Visible = false;
            }
        }

        /// <summary>
        /// 新增遊戲對應排程
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_ScheduleMissionRule_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    int missionid = ((IActivityPage)this.Page).MissionID;
                    string[] aryGameGroup = DDL_ScheduleMissionRule_GameGroupID.SelectedValue.Split('_');
                    int gameid = int.TryParse(aryGameGroup[0], out gameid) ? gameid : 0;
                    int groupid = int.TryParse(aryGameGroup[1], out groupid) ? groupid : 0;
                    bool isenable = bool.TryParse(DDL_ScheduleMissionRule_IsEnable.SelectedValue, out isenable) ? isenable : false;

                    ScheduleMissionRule model = new ScheduleMissionRule()
                    {
                        MissionID = missionid,
                        GameID = gameid,
                        GroupID = groupid,
                        ScheduleDateTime = DP_ScheduleMissionRule_ScheduleDateTime.SelectedDate,
                        IsEnable = isenable,
                        IsChangeRule = chk_ScheduleMissionRule_IsChangeRule.Checked,
                        Rule1 = this.TBX_ScheduleMissionRule_Rule1.Text,
                        Rule2 = this.TBX_ScheduleMissionRule_Rule2.Text,
                        Rule3 = this.TBX_ScheduleMissionRule_Rule3.Text,
                        Rule4 = this.TBX_ScheduleMissionRule_Rule4.Text,
                        ScheduleStateID = isenable ? 1 : 3
                    };

                    ((IActivityPage)this.Page).GameActivityContext.ScheduleMissionRule.Add(model);
                    ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                    // 重新繫結遊戲對應
                    this.LoadData();

                    // 通知Activity Server
                    if (!HttpClientHelper.PostRequest("api/MissionRule/" + model.SID))
                    {
                        WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                    }
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 刪除遊戲對應排程
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleMissionRule_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
                int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

                switch (e.CommandName)
                {
                    case "DelScheduleMissionRule":
                        var item = ((IActivityPage)this.Page).GameActivityContext.ScheduleMissionRule.Find(id);

                        if (item != null)
                        {
                            item.ScheduleStateID = 5;
                            ((IActivityPage)this.Page).GameActivityContext.Entry(item).State = EntityState.Modified;
                            ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                            // 重新繫結資料
                            this.LoadData();

                            // 通知Activity Server
                            if (!HttpClientHelper.DeleteRequest("api/MissionRule/" + id))
                            {
                                WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                            }
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 修改遊戲對應排程狀態
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleMissionRule_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ScheduleMissionRule row = e.Row.DataItem as ScheduleMissionRule;

                if (row.ScheduleStateID == 2 || row.ScheduleStateID >= 4)
                {
                    Button btn = e.Row.Cells[4].Controls[0] as Button;
                    if (btn != null)
                    {
                        btn.Visible = false;
                    }
                }
            }
        }
    }
}