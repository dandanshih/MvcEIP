﻿//-----------------------------------------------------------------------
// <copyright file="IActivityPage.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GWeb.AppUserControls.Activity
{
    public class MissionEventArgs : EventArgs
    {
        public int ID { get; set; }
        public MissionEventArgs(int id)
        {
            this.ID = id;
        }
    }
}