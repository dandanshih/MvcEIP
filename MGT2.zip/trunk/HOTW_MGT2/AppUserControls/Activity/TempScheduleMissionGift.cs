﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GWeb.AppUserControls.Activity
{
    /// <summary>
    /// 排程禮物列表暫存類別
    /// </summary>
    [Serializable]
    public class TempScheduleMissionGift
    {
        /// <summary>
        /// Gets or sets 識別用編號
        /// </summary>
        public Guid SID { get; set; }

        /// <summary>
        /// Gets or sets 禮物編號
        /// </summary>
        public int GiftID { get; set; }

        /// <summary>
        /// Gets or sets 禮物數量
        /// </summary>
        public int GiftNum { get; set; }

        /// <summary>
        /// Gets or sets 是否進禮物中心
        /// </summary>
        public bool IsGiftMarket { get; set; }

        /// <summary>
        /// Gets or sets 科目代碼
        /// </summary>
        public int DepositsItem { get; set; }
    }
}