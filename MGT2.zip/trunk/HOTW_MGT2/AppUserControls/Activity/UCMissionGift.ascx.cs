﻿//-----------------------------------------------------------------------
// <copyright file="UCMissionGift.ascx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.AppUserControls.Activity
{
    using GWeb.Models;
    using System;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    public partial class UCMissionGift : System.Web.UI.UserControl
    {
        private Game_Serial_Context gameSerial = new Game_Serial_Context();
        private Game_Activity_Context gameActivity = new Game_Activity_Context();

        private ListItemCollection DepositsItems
        {
            get
            {
                return DDL_DepositsItem.Items;
            }
        }

        public string GetGiftName(object giftid)
        {
            int id = int.TryParse(giftid.ToString(), out id) ? id : 0;
            var item = ((IActivityPage)this.Page).ItemList.Find(x => x.ItemID == id);
            return item == null ? string.Empty : item.ItemName;
        }

        public override void Dispose()
        {
            this.gameActivity.Dispose();
            this.gameSerial.Dispose();
            base.Dispose();
        }

        /// <summary>
        /// 繫結禮物資料
        /// </summary>
        public void LoadData()
        {
            var missionGiftList = this.gameActivity.MissionGift
                .Where(x => x.MissionID == ((IActivityPage)this.Page).MissionID)
                .ToList();
            // 分兩段查詢是因為使用EF時，未關閉連線，join 的資料會找不到
            var query = from item in missionGiftList
                        join litem in this.DepositsItems.Cast<ListItem>() on item.DepositsItem equals Convert.ToInt32(litem.Value)
                        join gift in ((IActivityPage)this.Page).ItemList on item.GiftID equals gift.ItemID
                        select new
                        {
                            MissionGiftID = item.MissionGiftID,
                            MissionID = item.MissionID,
                            GiftID = item.GiftID,
                            GiftName = gift.ItemName,
                            DepositsItem = item.DepositsItem,
                            DepositsItemName = litem.Text,
                            IsGiftMarket = item.IsGiftMarket,
                            GiftNum = item.GiftNum,
                            Mission = item.Mission
                        };

            var list = from c in ((IActivityPage)this.Page).ItemList
                       where !(from o in missionGiftList select o.GiftID).Contains(c.ItemID)
                       select c;

            // 繫結禮物資料
            this.DDL_MissionGift_GiftID.DataSource = list;
            this.DDL_MissionGift_GiftID.DataValueField = "ItemID";
            this.DDL_MissionGift_GiftID.DataTextField = "ItemName";
            this.DDL_MissionGift_GiftID.DataBind();

            this.GV_MissionGift.DataSource = query;
            this.GV_MissionGift.DataBind();
        }

        /// <summary>
        /// 新增禮物資料
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_MissionGift_Add_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int giftid = int.TryParse(DDL_MissionGift_GiftID.SelectedValue, out giftid) ? giftid : 0;
                int giftnum = int.TryParse(TBX_MissionGift_GiftNum.Text, out giftnum) ? giftnum : 0;
                int depositsitem = int.TryParse(DDL_DepositsItem.SelectedValue, out depositsitem) ? depositsitem : 0;

                MissionGift model = new MissionGift()
                {
                    MissionID = ((IActivityPage)this.Page).MissionID,
                    GiftID = giftid,
                    GiftNum = giftnum,
                    IsGiftMarket = CHK_IsGiftMarket.Checked,
                    DepositsItem = depositsitem
                };

                this.gameActivity.MissionGift.Add(model);
                this.gameActivity.SaveChanges();

                // 重新繫結禮物資料
                this.LoadData();
            }
        }

        /// <summary>
        /// 刪除禮物列表
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_MissionGift_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
            int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

            switch (e.CommandName)
            {
                case "DelMissionGift":
                    var item = this.gameActivity.MissionGift.Find(id);

                    if (item != null)
                    {
                        this.gameActivity.MissionGift.Remove(item);
                        this.gameActivity.SaveChanges();

                        // 重新繫結資料
                        this.LoadData();
                    }

                    break;
                default:
                    break;
            }
        }
    }
}