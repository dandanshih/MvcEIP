﻿//-----------------------------------------------------------------------
// <copyright file="UCMission.ascx.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace GWeb.AppUserControls.Activity
{
    using System;
    using System.Linq;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using GS.Utilities;
    using GWeb.Models;

    /// <summary>
    /// User Control for Mission
    /// </summary>
    public partial class UCMission : System.Web.UI.UserControl
    {
        public event EventHandler<MissionEventArgs> MissionGridViewClick;

        /// <summary>
        /// 資料存取物件
        /// </summary>
        private Game_Activity_Context ctx = new Game_Activity_Context();

        /// <summary>
        /// Load Data
        /// </summary>
        public void LoadData()
        {
            this.ViewState["MissionListSelectedRowIndex"] = null;
            int activityid = ((IActivityPage)this.Page).ActivityID;
            int take = this.UCPager_Mission.PageSize;
            int skip = (this.UCPager_Mission.CurrentPageNumber - 1) * take;
            var query = this.ctx.Mission.Where(x => x.ActivityID == activityid);

            // 繫結分頁筆數
            this.UCPager_Mission.RecordCount = query.Count();
            this.UCPager_Mission.DataBind();

            // 繫結資料列表
            this.GV_Mission.DataSource = query
                .OrderBy(x => x.MissionID)
                .Skip(skip)
                .Take(take)
                .ToList();
            this.GV_Mission.DataBind();
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public override void Dispose()
        {
            this.ctx.Dispose();
            base.Dispose();
        }

        /// <summary>
        /// 任務資料分頁
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void UCPager_Mission_Change(object sender, EventArgs e)
        {
            this.LoadData();
        }

        /// <summary>
        /// 新增任務
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_Mission_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    int missionid = int.TryParse(this.TBX_Mission_MissionID.Text, out missionid) ? missionid : 0;
                    int activityid = ((IActivityPage)this.Page).ActivityID;
                    bool isenable = bool.TryParse(this.DDL_Mission_IsEnable.SelectedValue, out isenable) ? isenable : false;

                    Mission model = new Mission()
                    {
                        MissionID = missionid,
                        ActivityID = activityid,
                        MissionName = TBX_Mission_MissionName.Text,
                        ProgName = TBX_ProgName.Text,
                        IsEnable = isenable
                    };

                    this.ctx.Mission.Add(model);
                    this.ctx.SaveChanges();

                    // 重新繫結任務資料
                    this.LoadData();

                    // 關閉其他UserControl
                    ((IActivityPage)this.Page).CloseAllUserControl();

                    TBX_Mission_MissionID.Text = string.Empty;
                    TBX_Mission_MissionName.Text = string.Empty;
                    TBX_ProgName.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 刪除任務
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_Mission_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
                int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

                switch (e.CommandName)
                {
                    // 顯示相關明細資料
                    case "ShowMissionDetail":
                        if (this.ViewState["MissionListSelectedRowIndex"] != null)
                        {
                            ((GridView)sender).Rows[(int)ViewState["MissionListSelectedRowIndex"]].BackColor = System.Drawing.Color.Empty;
                        }

                        ((GridView)sender).Rows[idx].BackColor = System.Drawing.Color.LightGreen;
                        this.ViewState["MissionListSelectedRowIndex"] = idx;

                        // 觸發事件
                        if (this.MissionGridViewClick != null)
                        {
                            this.MissionGridViewClick(this, new MissionEventArgs(id));
                        }

                        break;
                    case "DelMission":
                        var item = this.ctx.Mission.Find(id);

                        if (item != null)
                        {
                            // MissionGift
                            foreach (var subitem in this.ctx.MissionGift.Where(x => x.MissionID == id))
                            {
                                this.ctx.MissionGift.Remove(subitem);
                            }

                            // MissionGame
                            foreach (var subitem in this.ctx.MissionGame.Where(x => x.MissionID == id))
                            {
                                this.ctx.MissionGame.Remove(subitem);
                            }

                            // MissionQualification
                            foreach (var subitem in this.ctx.MissionQualification.Where(x => x.MissionID == id))
                            {
                                this.ctx.MissionQualification.Remove(subitem);
                            }

                            // ScheduleMission
                            foreach (var subitem in this.ctx.ScheduleMission.Where(x => x.MissionID == id))
                            {
                                // ScheduleMissionGift
                                foreach (var subitem2 in this.ctx.ScheduleMissionGift.Where(x => x.ScheduleMissionID == subitem.ScheduleMissionID))
                                {
                                    this.ctx.ScheduleMissionGift.Remove(subitem2);
                                }

                                this.ctx.ScheduleMission.Remove(subitem);
                            }

                            // ScheduleMissionQualification
                            foreach (var subitem in this.ctx.ScheduleMissionQualification.Where(x => x.MissionID == id))
                            {
                                this.ctx.ScheduleMissionQualification.Remove(subitem);
                            }

                            // ScheduleMissionRule
                            foreach (var subitem in this.ctx.ScheduleMissionRule.Where(x => x.MissionID == id))
                            {
                                this.ctx.ScheduleMissionRule.Remove(subitem);
                            }

                            this.ctx.Mission.Remove(item);
                            this.ctx.SaveChanges();

                            // 重新繫結資料
                            this.LoadData();
                            ((IActivityPage)this.Page).CloseAllUserControl();
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }
    }
}