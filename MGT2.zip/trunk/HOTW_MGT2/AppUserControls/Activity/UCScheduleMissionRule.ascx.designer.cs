﻿//------------------------------------------------------------------------------
// <自動產生的>
//     這段程式碼是由工具產生的。
//
//     對這個檔案所做的變更可能會造成錯誤的行為，而且如果重新產生程式碼，
//     所做的變更將會遺失。 
// </自動產生的>
//------------------------------------------------------------------------------

namespace GWeb.AppUserControls.Activity {
    
    
    public partial class UCScheduleMissionRule {
        
        /// <summary>
        /// DP_ScheduleMissionRule_ScheduleDateTime 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::EO.Web.DatePicker DP_ScheduleMissionRule_ScheduleDateTime;
        
        /// <summary>
        /// DDL_ScheduleMissionRule_GameGroupID 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList DDL_ScheduleMissionRule_GameGroupID;
        
        /// <summary>
        /// DDL_ScheduleMissionRule_IsEnable 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList DDL_ScheduleMissionRule_IsEnable;
        
        /// <summary>
        /// chk_ScheduleMissionRule_IsChangeRule 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.CheckBox chk_ScheduleMissionRule_IsChangeRule;
        
        /// <summary>
        /// TBX_ScheduleMissionRule_Rule1 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TBX_ScheduleMissionRule_Rule1;
        
        /// <summary>
        /// TBX_ScheduleMissionRule_Rule2 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TBX_ScheduleMissionRule_Rule2;
        
        /// <summary>
        /// TBX_ScheduleMissionRule_Rule3 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TBX_ScheduleMissionRule_Rule3;
        
        /// <summary>
        /// TBX_ScheduleMissionRule_Rule4 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TBX_ScheduleMissionRule_Rule4;
        
        /// <summary>
        /// BTN_ScheduleMissionRule_Add 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button BTN_ScheduleMissionRule_Add;
        
        /// <summary>
        /// GV_ScheduleMissionRule 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::GFC.Web.WebControls.TBGridView GV_ScheduleMissionRule;
        
        /// <summary>
        /// UCPager_ScheduleMissionRule 控制項。
        /// </summary>
        /// <remarks>
        /// 自動產生的欄位。
        /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
        /// </remarks>
        protected global::GWeb.AppUserControls.Pager.UCPager UCPager_ScheduleMissionRule;
    }
}
