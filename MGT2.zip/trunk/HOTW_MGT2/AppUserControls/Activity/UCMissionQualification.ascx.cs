﻿using GWeb.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.AppUserControls.Activity
{
    public partial class UCMissionQualification : System.Web.UI.UserControl
    {
        public event EventHandler<MissionEventArgs> OnGridViewClick;

        /// <summary>
        /// 繫結任務相關資料
        /// </summary>
        public void LoadData()
        {
            var missionQualificationList = ((IActivityPage)this.Page).GameActivityContext.MissionQualification
                .Where(x => x.MissionID == ((IActivityPage)this.Page).MissionID)
                .Include(x => x.C_QualificationCategory)
                .ToList();

            var qualificationList = ((IActivityPage)this.Page).GameActivityContext.C_QualificationCategory.ToList();

            var list = from c in qualificationList
                       where !(from o in missionQualificationList select o.QualificationID).Contains(c.QualificationID)
                       select c;

            // 繫結身份資料
            this.DDL_MissionQualification_QualificationID.DataSource = list;
            this.DDL_MissionQualification_QualificationID.DataValueField = "QualificationID";
            this.DDL_MissionQualification_QualificationID.DataTextField = "QualificationName";
            this.DDL_MissionQualification_QualificationID.DataBind();

            this.GV_MissionQualification.DataSource = missionQualificationList;
            this.GV_MissionQualification.DataBind();
        }

        /// <summary>
        /// 新增任務達成次數
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_MissionQualification_Add_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int missionid = ((IActivityPage)this.Page).MissionID;
                int qualificationid = int.TryParse(DDL_MissionQualification_QualificationID.SelectedValue, out qualificationid) ? qualificationid : 0;
                int allowCompleteTimes = int.TryParse(TBX_MissionQualification_AllowCompleteTimes.Text, out allowCompleteTimes) ? allowCompleteTimes : 0;

                MissionQualification model = new MissionQualification()
                {
                    MissionID = missionid,
                    QualificationID = qualificationid,
                    AllowCompleteTimes = allowCompleteTimes
                };

                ((IActivityPage)this.Page).GameActivityContext.MissionQualification.Add(model);
                ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                if (this.OnGridViewClick != null)
                {
                    this.OnGridViewClick(this, null);
                }
            }
        }

        /// <summary>
        /// 刪除達成次數
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_MissionQualification_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
            int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

            switch (e.CommandName)
            {
                case "DelMissionQualification":
                    var item = ((IActivityPage)this.Page).GameActivityContext.MissionQualification.Find(id);

                    if (item != null)
                    {
                        ((IActivityPage)this.Page).GameActivityContext.MissionQualification.Remove(item);
                        ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                        if (this.OnGridViewClick != null)
                        {
                            this.OnGridViewClick(this, null);
                        }
                    }

                    break;
                default:
                    break;
            }
        }
    }
}