﻿using GS.Utilities;
using GWeb.AppLibs;
using GWeb.Models;
using System;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web.UI.WebControls;

namespace GWeb.AppUserControls.Activity
{
    public partial class UCScheduleMission : System.Web.UI.UserControl
    {
        public string GetGiftName(object giftid)
        {
            int id = int.TryParse(giftid.ToString(), out id) ? id : 0;
            var item = ((IActivityPage)this.Page).ItemList.Find(x => x.ItemID == id);
            return item == null ? string.Empty : item.ItemName;
        }

        protected void UCPager_ScheduleMission_Change(object sender, EventArgs e)
        {
            this.LoadData();
        }

        /// <summary>
        /// 繫結任務排程資料
        /// </summary>
        public void LoadData()
        {
            int take = this.UCPager_ScheduleMission.PageSize;
            int skip = (this.UCPager_ScheduleMission.CurrentPageNumber - 1) * take;
            var query = ((IActivityPage)this.Page).GameActivityContext.ScheduleMission
                .Where(x => x.MissionID == ((IActivityPage)this.Page).MissionID);

            DP_ScheduleMission_ScheduleDateTime.SelectedDate = DateTime.Now.AddMinutes(10);

            // 繫結分頁筆數
            this.UCPager_ScheduleMission.RecordCount = query.Count();
            this.UCPager_ScheduleMission.DataBind();

            var giftList = from c in ((IActivityPage)this.Page).ItemList
                       where !(from o in ((IActivityPage)this.Page).TempScheduleMissionGiftList select o.GiftID).Contains(c.ItemID)
                       select c;

            // 繫結禮物選單
            this.DDL_ScheduleMissionGift_GiftID.DataSource = giftList;
            this.DDL_ScheduleMissionGift_GiftID.DataValueField = "ItemID";
            this.DDL_ScheduleMissionGift_GiftID.DataTextField = "ItemName";
            this.DDL_ScheduleMissionGift_GiftID.DataBind();

            this.GV_ScheduleMissionGift.DataSource = ((IActivityPage)this.Page).TempScheduleMissionGiftList;
            this.GV_ScheduleMissionGift.DataBind();

            // 繫結資料列表
            GV_ScheduleMission.DataSource = query
                .OrderByDescending(x => x.ScheduleMissionID)
                .Skip(skip)
                .Take(take)
                .Include(x => x.C_ScheduleState)
                .ToList(); ;
            GV_ScheduleMission.DataBind();
        }

        /// <summary>
        /// 新增禮物資料
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_ScheduleMissionGift_Add_Click(object sender, EventArgs e)
        {
            int giftid = int.TryParse(DDL_ScheduleMissionGift_GiftID.SelectedValue, out giftid) ? giftid : 0;
            int giftnum = int.TryParse(TBX_ScheduleMissionGift_GiftNum.Text, out giftnum) ? giftnum : 0;
            int depositsitem = int.TryParse(DDL_DepositsItem.SelectedValue, out depositsitem) ? depositsitem : 0;

            ((IActivityPage)this.Page).TempScheduleMissionGiftList.Add(
                new TempScheduleMissionGift()
                {
                    SID = Guid.NewGuid(),
                    GiftID = giftid,
                    GiftNum = giftnum,
                    IsGiftMarket = CHK_IsGiftMarket.Checked,
                    DepositsItem = depositsitem
                });

            // 重新繫結禮物資料
            this.LoadData();
        }

        /// <summary>
        /// 新增任務排程
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_ScheduleMission_Add_Click(object sender, EventArgs e)
        {
            try
            {
                int missionid = ((IActivityPage)this.Page).MissionID;
                bool isenable = bool.TryParse(DDL_ScheduleMission_IsEnable.SelectedValue, out isenable) ? isenable : false;

                GWeb.Models.ScheduleMission scheduleMission = new GWeb.Models.ScheduleMission()
                {
                    MissionID = missionid,
                    ScheduleDateTime = DP_ScheduleMission_ScheduleDateTime.SelectedDate,
                    IsEnable = isenable,
                    IsEditable = true,
                    IsClearGift = CHK_IsClearGift.Checked,
                    ScheduleStateID = isenable ? 1 : 3
                };

                ((IActivityPage)this.Page).GameActivityContext.ScheduleMission.Add(scheduleMission);

                // 新增禮物
                foreach (var missionGift in ((IActivityPage)this.Page).TempScheduleMissionGiftList)
                {
                    scheduleMission.ScheduleMissionGift.Add(
                        new ScheduleMissionGift()
                        {
                            GiftID = missionGift.GiftID,
                            GiftNum = missionGift.GiftNum,
                            IsGiftMarket = missionGift.IsGiftMarket,
                            DepositsItem = missionGift.DepositsItem
                        });
                }

                // 異動資料
                ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                // 清除暫存資料
                ((IActivityPage)this.Page).TempScheduleMissionGiftList.Clear();

                // 重新繫結資料
                this.LoadData();

                // 通知Activity Server
                if (!HttpClientHelper.PostRequest("api/MissionEntity/" + scheduleMission.ScheduleMissionID))
                {
                    WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 刪除排程資料
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleMission_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
                int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

                switch (e.CommandName)
                {
                    case "DelScheduleMission":
                        var item = ((IActivityPage)this.Page).GameActivityContext.ScheduleMission.Find(id);

                        if (item != null)
                        {
                            item.ScheduleStateID = 5;
                            ((IActivityPage)this.Page).GameActivityContext.Entry(item).State = EntityState.Modified;
                            ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                            // 重新繫結資料
                            this.LoadData();

                            // 通知Activity Server
                            if (!HttpClientHelper.DeleteRequest("api/MissionEntity/" + id))
                            {
                                WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                            }
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 禮物列表事件
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleMissionGift_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
            Guid id = Guid.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : Guid.Empty;

            switch (e.CommandName)
            {
                case "DelScheduleMissionGift":
                    var item = ((IActivityPage)this.Page).TempScheduleMissionGiftList.Find(x => x.SID == id);

                    if (item != null)
                    {
                        ((IActivityPage)this.Page).TempScheduleMissionGiftList.Remove(item);
                        this.LoadData();
                    }

                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 任務記錄繫結
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleMission_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ScheduleMission row = e.Row.DataItem as ScheduleMission;

                if (row.ScheduleStateID == 2 || row.ScheduleStateID >= 4)
                {
                    Button btn = e.Row.FindControl("BTN_Delete") as Button;

                    if (btn != null)
                    {
                        btn.Visible = false;
                    }
                }

                // 子GridView
                GridView gv = e.Row.FindControl("GV_GiftList") as GridView;
                if (gv != null)
                {
                    gv.DataSource = row.ScheduleMissionGift;
                    gv.DataBind();
                }
            }
        }
    }
}