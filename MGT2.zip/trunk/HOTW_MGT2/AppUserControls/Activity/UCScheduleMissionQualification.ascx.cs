﻿using GS.Utilities;
using GWeb.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GWeb.AppUserControls.Activity
{
    public partial class UCScheduleMissionQualification : System.Web.UI.UserControl
    {
        /// <summary>
        /// 跳頁重新繫結資料
        /// </summary>
        protected void UCPager_ScheduleMissionQualification_Change(object sender, EventArgs e)
        {
            this.LoadData();
        }

        /// <summary>
        /// 繫結完成條件排程
        /// </summary>
        public void LoadData()
        {
            int take = this.UCPager_ScheduleMissionQualification.PageSize;
            int skip = (this.UCPager_ScheduleMissionQualification.CurrentPageNumber - 1) * take;
            var query = ((IActivityPage)this.Page).GameActivityContext.ScheduleMissionQualification
                .Where(x => x.MissionID == ((IActivityPage)this.Page).MissionID);

            this.DP_ScheduleMissionQualification_ScheduleDateTime.SelectedDate = DateTime.Now.AddMinutes(10);

            // 繫結分頁筆數
            this.UCPager_ScheduleMissionQualification.RecordCount = query.Count();
            this.UCPager_ScheduleMissionQualification.DataBind();

            var qualificationList = ((IActivityPage)this.Page).GameActivityContext.C_QualificationCategory.ToList();

            var list = from c in qualificationList
                       where (from o in ((IActivityPage)this.Page).GameActivityContext.MissionQualification
                              where o.MissionID == ((IActivityPage)this.Page).MissionID
                              select o.QualificationID).Contains(c.QualificationID)
                       select c;

            if (list.Count() > 0)
            {
                this.Visible = true;

                // 繫結身份資料
                this.DDL_ScheduleMissionQualificationID.DataSource = list;
                this.DDL_ScheduleMissionQualificationID.DataValueField = "QualificationID";
                this.DDL_ScheduleMissionQualificationID.DataTextField = "QualificationName";
                this.DDL_ScheduleMissionQualificationID.DataBind();

                this.GV_ScheduleMissionQualification.DataSource = query
                    .OrderByDescending(x => x.SID)
                    .Skip(skip)
                    .Take(take)
                    .Include(x => x.C_QualificationCategory)
                    .Include(x => x.C_ScheduleState)
                    .ToList();
                this.GV_ScheduleMissionQualification.DataBind();
            }
            else
            {
                this.Visible = false;
            }
        }

        /// <summary>
        /// 排程完成條件列表
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void BTN_ScheduleMissionQualification_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    int missionid = ((IActivityPage)this.Page).MissionID;
                    int qualificationid = int.TryParse(DDL_ScheduleMissionQualificationID.SelectedValue, out qualificationid) ? qualificationid : 0;
                    int allowCompleteTimes = int.TryParse(TBX_ScheduleMissionQualification_AllowCompleteTimes.Text, out allowCompleteTimes) ? allowCompleteTimes : 0;

                    GWeb.Models.ScheduleMissionQualification model = new GWeb.Models.ScheduleMissionQualification()
                    {
                        MissionID = missionid,
                        QualificationID = qualificationid,
                        AllowCompleteTimes = allowCompleteTimes,
                        ScheduleDateTime = DP_ScheduleMissionQualification_ScheduleDateTime.SelectedDate,
                        ScheduleStateID = 1
                    };

                    ((IActivityPage)this.Page).GameActivityContext.ScheduleMissionQualification.Add(model);
                    ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                    // 重新繫結達成次數
                    this.LoadData();

                    // 通知Activity Server
                    if (!HttpClientHelper.PostRequest("api/MissionQualificationRestrict/" + model.SID))
                    {
                        WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                    }
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 刪除完成次數排程
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleMissionQualification_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                int idx = int.TryParse(e.CommandArgument.ToString(), out idx) ? idx : 0;
                int id = int.TryParse(((GridView)sender).DataKeys[idx].Value.ToString(), out id) ? id : 0;

                switch (e.CommandName)
                {
                    case "DelScheduleMissionQualification":
                        var item = ((IActivityPage)this.Page).GameActivityContext.ScheduleMissionQualification.Find(id);

                        if (item != null)
                        {
                            item.ScheduleStateID = 5;
                            ((IActivityPage)this.Page).GameActivityContext.Entry(item).State = EntityState.Modified;
                            ((IActivityPage)this.Page).GameActivityContext.SaveChanges();

                            // 重新繫結資料
                            this.LoadData();

                            // 通知Activity Server
                            if (!HttpClientHelper.DeleteRequest("api/MissionQualificationRestrict/" + id))
                            {
                                WebUtility.ResponseScript(this.Page, "Activity Server無法連線", true);
                            }
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(this.Page, ex.Message, true);
            }
        }

        /// <summary>
        /// 修改遊戲完成條件排程狀態
        /// </summary>
        /// <param name="sender">sender object</param>
        /// <param name="e">event args</param>
        protected void GV_ScheduleMissionQualification_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GWeb.Models.ScheduleMissionQualification row = e.Row.DataItem as GWeb.Models.ScheduleMissionQualification;

                if (row.ScheduleStateID == 2 || row.ScheduleStateID >= 4)
                {
                    Button btn = e.Row.Cells[4].Controls[0] as Button;
                    if (btn != null)
                    {
                        btn.Visible = false;
                    }
                }
            }
        }
    }
}