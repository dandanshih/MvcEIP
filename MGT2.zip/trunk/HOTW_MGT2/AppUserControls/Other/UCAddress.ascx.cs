﻿using System;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.Caching;
using System.Data.SqlClient;
using GS.Utilities;

namespace GWeb.AppUserControls.Other
{
	public partial class UCAddress : System.Web.UI.UserControl
	{
		#region Properties
		private const string CacheName = "AddressData";

		#region Values
		public string style
		{
			get;
			set;
		}

		/// <summary>
		/// 要顯示之控制項
		/// <para>-1: 全顯示</para>
		/// <para>1: 郵遞區號</para>
		/// <para>2: 縣市下拉選單</para>
		/// <para>4: 鄉鎮下拉選單</para>
		/// <para>8: 地址輸入框</para>
		/// </summary>
		public int VisibleFlag = -1;

		/// <summary>
		/// 郵遞區號
		/// </summary>
		public string ZipCode
		{
			get
			{
				return txt_ZipCode.Text;
			}
			set
			{
				txt_ZipCode.Text = value;
			}
		}

		/// <summary>
		/// 縣市編號
		/// </summary>
		public int CityID
		{
			get
			{
				return Convert.ToInt32(ddl_City.SelectedValue);
			}
			set
			{
				if (ddl_City.Items.Count <= 0)
				{
					BindCity();
				}
				ddl_City.SelectedValue = value.ToString();
				BindZone();
				BindZipCode();
			}
		}

		/// <summary>
		/// 縣市名稱
		/// </summary>
		public string CityName
		{
			get
			{
				return ddl_City.SelectedItem.Text;
			}
		}

		/// <summary>
		/// 鄉鎮編號
		/// </summary>
		public string ZoneID
		{
			get
			{
				return ddl_Zone.SelectedValue;
			}
			set
			{
				if (ddl_Zone.Items.Count < 2)
				{
					BindZone();
				}
				ddl_Zone.SelectedValue = value;
				BindZipCode();
			}
		}

		/// <summary>
		/// 鄉鎮名稱
		/// </summary>
		public string ZoneName
		{
			get
			{
				return ddl_Zone.SelectedItem.Text;
			}
		}

		/// <summary>
		/// 住址
		/// </summary>
		public string Address
		{
			get
			{
				return txt_Address.Text;
			}
			set
			{
				txt_Address.Text = value;
			}
		}

		/// <summary>
		/// 驗證控制項是否均通過
		/// </summary>
		public bool IsValid
		{
			get
			{
				return rev_Address.IsValid && rfv_Address.IsValid && cv_Address.IsValid && cv_Zone.IsValid && cv_DoubleEmpty.IsValid;
			}
		}
		#endregion

		#region SetConfig
		/// <summary>
		/// 控制項開關
		/// </summary>
		public bool Enabled
		{
			set
			{
				ddl_Zone.Enabled = value;
				ddl_City.Enabled = value;
				txt_Address.Enabled = value;
				cv_DoubleEmpty.Enabled = value;
			}
		}

		/// <summary>
		/// 取得或設定這個驗證控制項所屬之驗證群組的名稱
		/// </summary>
		public string ValidationGroup
		{
			get
			{
				return rev_Address.ValidationGroup;
			}
			set
			{
				rev_Address.ValidationGroup = value;
				rfv_Address.ValidationGroup = value;
				cv_Address.ValidationGroup = value;
				cv_Zone.ValidationGroup = value;
				cv_DoubleEmpty.ValidationGroup = value;
			}
		}

		/// <summary>
		/// 空字串驗證失敗之訊息
		/// </summary>
		public string ErrorMsgAddressEmpty
		{
			get { return rfv_Address.ErrorMessage; }
			set { rfv_Address.ErrorMessage = value; }
		}

		/// <summary>
		/// 是否空字串驗證
		/// </summary>
		public bool ErrorAddressEmptyEnabled
		{
			get { return rfv_Address.Enabled; }
			set { rfv_Address.Enabled = value; }
		}

		/// <summary>
		/// 地址格式錯誤之訊息
		/// </summary>
		public string ErrorMsgAddressFormat
		{
			get { return rev_Address.ErrorMessage; }
			set { rev_Address.ErrorMessage = value; }
		}

		/// <summary>
		/// 是否驗證地址格式
		/// </summary>
		public bool ErrorAddressFormatEnabled
		{
			get { return rev_Address.Enabled; }
			set { rev_Address.Enabled = value; }
		}

		/// <summary>
		/// 地址重複輸入縣市鄉鎮之錯誤訊息
		/// </summary>
		public string ErrorMsgAddressRepeat
		{
			get { return cv_Address.ErrorMessage; }
			set { cv_Address.ErrorMessage = value; }
		}

		/// <summary>
		/// 是否驗證地址格式
		/// </summary>
		public bool ErrorAddressRepeatEnabled
		{
			get { return cv_Address.Enabled; }
			set { cv_Address.Enabled = value; }
		}

		public bool ErrorZoneEmptyEnabled
		{
			get { return cv_Zone.Enabled; }
			set { cv_Zone.Enabled = value; }
		}

		public string ErrorMsgZoneEmpty
		{
			get { return cv_Zone.ErrorMessage; }
			set { cv_Zone.ErrorMessage = value; }
		}
		#endregion
		#endregion

		#region Private Method
		private DataTable GetData()
		{
			DataTable objTab = HttpContext.Current.Cache[CacheName] as DataTable;

			if (objTab == null)
			{
				objTab = SqlHelper.ExecuteDataset
				(
					GWeb.AppLibs.WebConfig.connectionString,
					CommandType.StoredProcedure,
					"NSP_GameWeb_GetZoneNameList"
				).Tables[0];

				DataRow[] objDrs = objTab.Select("CityID = 0 AND ZoneID='8860000001'");
				foreach (DataRow objDr in objDrs)
				{
					objDr["CityName"] = "請選擇縣市";
					objDr["ZoneName"] = "請選擇";
				}
				//objTab = new DataTable();
				//objTab.Columns.Add("ZipCode", typeof(int));
				//objTab.Columns.Add("CityID", typeof(int));
				//objTab.Columns.Add("CityName", typeof(string));
				//objTab.Columns.Add("ZoneName", typeof(string));
				//objTab.PrimaryKey = new DataColumn[] { objTab.Columns["ZipCode"] };

				//objTab.LoadDataRow(new object[] { 0, 0, "", "" }, false);
				//objTab.LoadDataRow(new object[] { 101, 1, "台中市", "北區" }, false);
				//objTab.LoadDataRow(new object[] { 102, 1, "台中市", "南區" }, false);
				//objTab.LoadDataRow(new object[] { 106, 1, "台中市", "中區" }, false);
				//objTab.LoadDataRow(new object[] { 103, 2, "彰化縣", "員林鎮" }, false);
				//objTab.LoadDataRow(new object[] { 107, 2, "彰化縣", "彰化市" }, false);
				//objTab.LoadDataRow(new object[] { 104, 3, "雲林鎮", "雲林市" }, false);
				//objTab.LoadDataRow(new object[] { 105, 3, "雲林鎮", "斗六" }, false);

				HttpContext.Current.Cache.Insert
				(
					CacheName,
					objTab,
					null,
#if(Online)
					DateTime.Now.AddDays(1),
#else
 DateTime.Now.AddMinutes(1),
#endif
 Cache.NoSlidingExpiration,
					CacheItemPriority.Normal,
					null
				);
			}

			return objTab;
		}

		private void BindCity()
		{
			DataTable objTab = new DataTable();
			DataTable objSourceTab = GetData();

			objTab = objSourceTab.Clone();

			var grouped = from row in objSourceTab.AsEnumerable()
						  group row by row["CityID"];

			foreach (var g in grouped)
			{
				objTab.Rows.Add(g.ElementAt(0).ItemArray);
			}

			ddl_City.DataSource = objTab;
			ddl_City.DataBind();
		}

		private void BindZone()
		{
			string RowFilter = string.Format("CityID={0}", CityID);
			ddl_Zone.DataSource = new DataView(GetData(), RowFilter, "", DataViewRowState.CurrentRows);
			ddl_Zone.DataBind();
		}

		private void BindZipCode()
		{
			string RowFilter = string.Format("CityID={0} AND ZoneID='{1}'", CityID, ZoneID);
			DataView objVW = new DataView(GetData(), RowFilter, "", DataViewRowState.CurrentRows);
			ZipCode = objVW[0]["ZipCode"].ToString();
		}
		#endregion

		#region Protected
		protected void Page_Load(object sender, EventArgs e)
		{
			upnl.Attributes.Add("style", style);

			if (!IsPostBack)
			{
				foreach (Control ctl in upnl.ContentTemplateContainer.Controls)
				{
					if (ctl is WebControl)
					{
						WebControl wctl = ctl as WebControl;
						if (!string.IsNullOrEmpty(wctl.Attributes["Flag"]))
						{
							int ctlFlag = int.Parse(wctl.Attributes["Flag"]);
							wctl.Visible = (ctlFlag & VisibleFlag) == ctlFlag;
						}
					}
				}
				BindCity();
				BindZone();
			}
		}

		protected void ddl_City_SelectedIndexChanged(object sender, EventArgs e)
		{
			BindZone();
			BindZipCode();
		}

		protected void ddl_Zone_SelectedIndexChanged(object sender, EventArgs e)
		{
			BindZipCode();
		}

		protected void cv_Address_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			if (!this.IsValid)
			{
				e.IsValid = true;
				return;
			}
			CustomValidator cv = (CustomValidator)sender;
			if (!VaildData())
			{
				//cv.ErrorMessage = "地址開頭請勿再次輸入下拉選單內容。";
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}

		protected void cv_Zone_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			if (!this.IsValid)
			{
				e.IsValid = true;
				return;
			}
			if (ddl_Zone.SelectedValue == "8860000001")
			{
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}

		protected void cv_DoubleEmpty_ServerValidate(object sender, ServerValidateEventArgs e)
		{
			if (!this.IsValid)
			{
				e.IsValid = true;
				return;
			}
			CustomValidator cv = (CustomValidator)sender;
			if ((string.IsNullOrEmpty(txt_Address.Text) && ddl_Zone.SelectedValue == "8860000001") ||
				(!string.IsNullOrEmpty(txt_Address.Text) && ddl_Zone.SelectedValue != "8860000001"))
			{
				e.IsValid = true;
			}
			else if (string.IsNullOrEmpty(txt_Address.Text) && !this.ErrorAddressEmptyEnabled)
			{
				cv.ErrorMessage = this.ErrorMsgAddressEmpty;
				e.IsValid = false;
			}
			else if (ddl_Zone.SelectedValue == "8860000001" && !this.ErrorZoneEmptyEnabled)
			{
				cv.ErrorMessage = this.ErrorMsgZoneEmpty;
				e.IsValid = false;
			}
			else
			{
				e.IsValid = true;
			}
		}
		#endregion

		#region Public Method
		public bool VaildData()
		{
			return
				(!txt_Address.Text.StartsWith(this.CityName) || !ddl_City.Visible) &&
				(!txt_Address.Text.StartsWith(this.ZoneName) || !ddl_Zone.Visible) &&
				(!txt_Address.Text.StartsWith(this.ZipCode) || !txt_ZipCode.Visible) &&
				(!string.IsNullOrEmpty(this.Address) || !txt_Address.Visible) &&
				!string.IsNullOrEmpty(txt_ZipCode.Text);
		}
		#endregion
	}
}