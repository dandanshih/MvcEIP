﻿using System;


namespace GWeb.AppUserControls.Other
{
    public partial class UCEntranceSelect : System.Web.UI.UserControl
    {
        #region Property
        public string SelectedValue
        {
            get
            {
                return ddl_Entrance.SelectedValue;
            }
            set
            {
                ddl_Entrance.SelectedValue = value;
            }
        }

        #endregion

        #region Protected Methods
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #endregion
    }
}
