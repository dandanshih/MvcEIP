﻿using System;
using System.Text;

namespace GWeb.AppUserControls.Other
{
	public partial class ThreeStateCheckBox : System.Web.UI.UserControl
	{
		#region Properties
		public string Text
		{
			get
			{
				return this.lbl.Text;
			}
			set
			{
				this.lbl.Text = value;
			}
		}

		public string Value
		{
			get
			{
				return this.hdf_Value.Value;
			}
			set
			{
				this.hdf_Value.Value = value;
			}
		}

		public int Power
		{
			get
			{
				int power = int.TryParse(hdf_Power.Value, out power) ? power : 0;
				return power;
			}
			set
			{
				this.hdf_Power.Value = value.ToString();
			}
		}

		public bool Enabled
		{
			get
			{
				return lbl.Enabled;
			}
			set
			{
				lbl.Enabled = value;
			}
		}
		#endregion

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			img.Attributes.Add("onclick", "checkThreeStateCheckBox('" + this.Enabled + "', this, '" + this.hdf_Value.ClientID + "');");
			if (string.IsNullOrEmpty(hdf_Value.Value))
			{
				Value = "Revoke";
			}

			switch (Value)
			{
				case "Grant":
					Value = "Grant";
					img.ImageUrl = (this.Enabled) ? "Grant.gif" : "xGrant.gif";
					break;
				case "Deny":
					Value = "Deny";
					img.ImageUrl = (this.Enabled) ? "Deny.gif" : "xDeny.gif";
					break;
				default:
					Value = "Revoke";
					img.ImageUrl = (this.Enabled) ? "Revoke.gif" : "xRevoke.gif";
					break;
			}

			if (!this.Page.ClientScript.IsStartupScriptRegistered("ThreeStateCheckBox"))
			{
				this.Page.ClientScript.RegisterStartupScript(GetType(), "ThreeStateCheckBox", this.BuildJavaScript(), true);
			}
		}

		private string BuildJavaScript()
		{
			StringBuilder objSB = new StringBuilder();
			objSB.AppendLine("function checkThreeStateCheckBox(isEnable, img, hdn) {");
			objSB.AppendLine("if (isEnable == 'False') return false;");
			objSB.AppendLine("var imgGrant = '" + ResolveUrl("~/AppUserControls/Other/Grant.gif") + "';");
			objSB.AppendLine("var imgDeny = '" + ResolveUrl("~/AppUserControls/Other/Deny.gif") + "';");
			objSB.AppendLine("var imgRevoke = '" + ResolveUrl("~/AppUserControls/Other/Revoke.gif") + "';");
			objSB.AppendLine("var objHdn = document.getElementById(hdn);");
			objSB.AppendLine("switch (objHdn.value) {");
			objSB.AppendLine("case 'Revoke':");
			objSB.AppendLine("img.src = imgGrant;");
			objSB.AppendLine("objHdn.value = 'Grant';");
			objSB.AppendLine("break;");
			objSB.AppendLine("case 'Grant':");
			objSB.AppendLine("img.src = imgDeny;");
			objSB.AppendLine("objHdn.value = 'Deny';");
			objSB.AppendLine("break;");
			objSB.AppendLine("default:");
			objSB.AppendLine("img.src = imgRevoke;");
			objSB.AppendLine("objHdn.value = 'Revoke';");
			objSB.AppendLine("break;");
			objSB.AppendLine("}");
			objSB.AppendLine("}");

			return objSB.ToString();
		}
		protected override void LoadViewState(object savedState)
		{

			base.LoadViewState(savedState);

		}

	}
}