﻿using System;

namespace GWeb.AppUserControls.Other
{
	public partial class UCPlatformSelect : System.Web.UI.UserControl
	{
		#region Property
		public string SelectedValue
		{
			get
			{
				return ddl_Platform.SelectedValue;
			}
			set
			{
				ddl_Platform.SelectedValue = value;
			}
		}
		#endregion

		protected void Page_Load(object sender, EventArgs e)
		{
		
		}
	}
}