﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.AppUserControls.Game
{
	public partial class UCGameSelect : AppLibs.UCBase
	{
		#region member

		string gameTypeSelectedValue = "0";
		string gameNameSeletedValue = "0";
		string gameZoneSeletedValue = "0";

		#endregion

		#region property

		/// <summary>
		/// 是否有免費區選項。
		/// </summary>
		public bool IsFree
		{
			get;
			set;
		}

		/// <summary>
		/// 是否有全部選項。
		/// </summary>
		public bool IsAll
		{
			get;
			set;
		}

		/// <summary>
		/// 回傳 GameType DropDownList。
		/// </summary>
		public DropDownList DDLGameType
		{
			get { return ddlGameType; }
			set { ddlGameType = value; }
		}

		/// <summary>
		/// 遊戲類別名稱。
		/// </summary>
		public string GameTypeSeletedText
		{
			get { return ddlGameType.SelectedItem.Text; }
			set { ddlGameType.SelectedItem.Text = value; }
		}

		/// <summary>
		/// 遊戲類別編號。
		/// </summary>
		public string GameTypeSeletedValue
		{
			get { return ddlGameType.SelectedItem.Value; }
			set { gameTypeSelectedValue = value; }
		}

		/// <summary>
		/// 遊戲名稱。
		/// </summary>
		public string GameSeletedText
		{
			get { return ddlGame.SelectedItem.Text; }
			set { ddlGame.SelectedItem.Text = value; }
		}

		/// <summary>
		/// 遊戲編號。
		/// </summary>
		public string GameSeletedValue
		{
			get { return ddlGame.SelectedItem.Value; }
			set { gameNameSeletedValue = value; }
		}

		/// <summary>
		/// 遊戲廳名稱。
		/// </summary>
		public string GameZoneSeletedText
		{
			get { return ddlGameZone.SelectedItem.Text; }
			set { ddlGameZone.SelectedItem.Text = value; }
		}

		/// <summary>
		/// 遊戲聽別編號。
		/// </summary>
		public string GameZoneSeletedValue
		{
			get { return ddlGameZone.SelectedItem.Value; }
			set { gameZoneSeletedValue = value; }
		}

		/// <summary>
		/// 取得或設定是否顯示遊戲類別。
		/// </summary>
		public bool ShowGameType
		{
			get { return divGameType.Visible; }
			set { divGameType.Visible = value; }
		}

		/// <summary>
		/// 取得或設定是否顯示遊戲。
		/// </summary>
		public bool ShowGame
		{
			get { return divGame.Visible; }
			set { divGame.Visible = value; }
		}

		/// <summary>
		/// 取得或設定是否顯示遊戲廳別。
		/// </summary>
		public bool ShowGameZone
		{
			get { return divGameZone.Visible; }
			set { divGameZone.Visible = value; }
		}

		/// <summary>
		/// 取得或設定遊戲類別標題文字。
		/// </summary>
		public string GameTypeText
		{
			get { return lblGameType.Text; }
			set { lblGameType.Text = value; }
		}

		/// <summary>
		/// 取得或設定遊戲類別標題文字。
		/// </summary>
		public string GameText
		{
			get { return lblGame.Text; }
			set { lblGame.Text = value; }
		}

		/// <summary>
		/// 取得或設定遊戲類別標題文字。
		/// </summary>
		public string GameZoneText
		{
			get { return lblGameZone.Text; }
			set { lblGameZone.Text = value; }
		}

		#endregion

		#region private

		/// <summary>
		/// 讀取遊戲類別。
		/// </summary>
		private void LoadGameType()
		{
			SqlParameter[] param = 
			{
				new SqlParameter("@ListType", "0"),
				new SqlParameter("@GameTypeID", "0"),
				new SqlParameter("@GameID", "0"),
				new SqlParameter("@IsShowFreeGame", "0")
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
															CommandType.StoredProcedure,
															"NSP_GameWeb_G_GetGameList",
															param);

			ddlGameType.DataTextField = "ListEName";
			ddlGameType.DataValueField = "ListID";
			ddlGameType.DataSource = objDtr;
			ddlGameType.DataBind();
			objDtr.Close();

			if (IsAll)
			{
				// 轉換語系
				try
				{
					ddlGameType.Items.Insert(0, new ListItem(GetGlobalResourceObject("Resources", "All").ToString(), "0"));
				}
				catch
				{
					ddlGameType.Items.Insert(0, new ListItem("All", "0"));
				}
			}
			else
			{
				// 轉換語系
				try
				{
					ddlGameType.Items.Insert(0, new ListItem(GetGlobalResourceObject("Resources", "Select").ToString(), "-1"));
				}
				catch
				{
					ddlGameType.Items.Insert(0, new ListItem("Select", "-1"));
				}
			}
		}

		/// <summary>
		/// 讀取遊戲名稱。
		/// </summary>
		private void LoadGame(string gameTypeID)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@ListType", "1"),
				new SqlParameter("@GameTypeID", gameTypeID),
				new SqlParameter("@GameID", "0"),
				new SqlParameter("@IsShowFreeGame", IsFree)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
															CommandType.StoredProcedure,
															"NSP_AgentWeb_G_GameList",
															param);

			ddlGame.DataTextField = "ListEName";
			ddlGame.DataValueField = "ListID";
			ddlGame.DataSource = objDtr;
			ddlGame.DataBind();
			objDtr.Close();

			if (IsAll)
			{
				// 轉換語系
				try
				{
					ddlGame.Items.Insert(0, new ListItem(GetGlobalResourceObject("Resources", "All").ToString(), "0"));
				}
				catch
				{
					ddlGame.Items.Insert(0, new ListItem("All", "0"));
				}
			}
			else
			{
				// 轉換語系
				try
				{
					ddlGame.Items.Insert(0, new ListItem(GetGlobalResourceObject("Resources", "Select").ToString(), "-1"));
				}
				catch
				{
					ddlGame.Items.Insert(0, new ListItem("Select", "-1"));
				}
			}
		}

		/// <summary>
		/// 讀取遊戲廳別。
		/// </summary>
		private void LoadGameZone(string gameID)
		{
			SqlParameter[] param =
			{
				new SqlParameter("@ListType", "2"),
				new SqlParameter("@GameTypeID", ddlGameType.SelectedItem.Value),
				new SqlParameter("@GameID", gameID),
				new SqlParameter("@IsShowFreeGame", IsFree)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
															CommandType.StoredProcedure,
															"NSP_GameWeb_G_GetGameList",
															param);

			ddlGameZone.DataTextField = "ListEName";
			ddlGameZone.DataValueField = "ListID";
			ddlGameZone.DataSource = objDtr;
			ddlGameZone.DataBind();
			objDtr.Close();

			if (IsAll)
			{
				// 轉換語系
				try
				{
					ddlGameZone.Items.Insert(0, new ListItem(GetGlobalResourceObject("Resources", "All").ToString(), "0"));
				}
				catch
				{
					ddlGameZone.Items.Insert(0, new ListItem("All", "0"));
				}				
			}
			else
			{
				// 轉換語系
				try
				{
					ddlGameZone.Items.Insert(0, new ListItem(GetGlobalResourceObject("Resources", "Select").ToString(), "-1"));
				}
				catch
				{
					ddlGameZone.Items.Insert(0, new ListItem("Select", "-1"));
				}				
			}
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadGameType();
				LoadGame(ddlGameType.SelectedItem.Value);
				LoadGameZone(ddlGame.SelectedItem.Value);
			}
		}

		protected void ddlGameType_SelectedIndexChanged(object sender, EventArgs e)
		{
			LoadGame(ddlGameType.SelectedItem.Value);
			LoadGameZone(ddlGame.SelectedItem.Value);
		}

		protected void ddlGame_SelectedIndexChanged(object sender, EventArgs e)
		{
			LoadGameZone(ddlGame.SelectedItem.Value);
		}

		protected void ddlGameType_DataBound(object sender, EventArgs e)
		{
			// 轉換語系
			foreach (ListItem item in ddlGameType.Items)
			{
				try
				{
                    item.Text = Utility.GetGameENameMapping(item.Text).ToString();
				}
				catch
				{

				}				
			}			

			if (gameTypeSelectedValue != "0")
			{
				ddlGameType.SelectedItem.Value = gameTypeSelectedValue;
			}
		}

		protected void ddlGame_DataBound(object sender, EventArgs e)
		{
			// 轉換語系
			foreach (ListItem item in ddlGame.Items)
			{
				try
				{
                    item.Text = Utility.GetGameENameMapping(item.Text).ToString();
				}
				catch
				{

				}				
			}
			

			if (gameNameSeletedValue != "0")
			{
				ddlGame.SelectedItem.Value = gameNameSeletedValue;
			}
		}

		protected void ddlGameZone_DataBound(object sender, EventArgs e)
		{
			// 轉換語系
			foreach (ListItem item in ddlGameZone.Items)
			{
				try
				{
                    item.Text = Utility.GetGameENameMapping(item.Text).ToString();
				}
				catch
				{

				}				
			}
			

			if (gameZoneSeletedValue != "0")
			{
				ddlGameZone.SelectedItem.Value = gameZoneSeletedValue;
			}
		}

		#endregion

		#region public

		public void BindData()
		{
			LoadGame(ddlGameType.SelectedItem.Value);
			LoadGameZone(ddlGame.SelectedItem.Value);
		}

		public override void DataBind()
		{
			base.DataBind();

			LoadGameType();
			LoadGame(ddlGameType.SelectedItem.Value);
			LoadGameZone(ddlGame.SelectedItem.Value);
		}

		#endregion
	}
}