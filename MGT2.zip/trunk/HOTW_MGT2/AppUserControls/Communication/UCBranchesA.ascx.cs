﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using GWeb.AppUserControls.Communication;

namespace GWeb.AppUserControls.Communication
{
	public partial class UCBranchesA : AbstractColleague
	{
		#region Properties
		public bool SelectType { get; set; }

		public int DataCount
		{
			get
			{
				return lb.Items.Count;
			}
		}

		public UCCommunicationData CommunicationData
		{
			get
			{
				UCCommunicationData data = new UCCommunicationData();
				data.ID = Convert.ToInt32(lb.SelectedValue);
				data.Name = lb.SelectedItem.Text;
				return data;
			}
		}
		#endregion

		#region Protected Method
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btn_Up_Click(object sender, EventArgs e)
		{
			if (lb.SelectedIndex <= 0)
			{
				return;
			}
			int NowIndex = lb.SelectedIndex;
			string[] str1 = new string[] { lb.Items[NowIndex].Value, lb.Items[NowIndex].Text };
			string[] str2 = new string[] { lb.Items[NowIndex - 1].Value, lb.Items[NowIndex - 1].Text };

			lb.Items[NowIndex].Value = str2[0];
			lb.Items[NowIndex].Text = str2[1];
			lb.Items[NowIndex - 1].Value = str1[0];
			lb.Items[NowIndex - 1].Text = str1[1];
			lb.SelectedIndex = NowIndex - 1;
		}

		protected void btn_Down_Click(object sender, EventArgs e)
		{
			if (lb.SelectedIndex == -1 || lb.SelectedIndex == lb.Items.Count - 1)
			{
				return;
			}
			int NowIndex = lb.SelectedIndex;
			string[] str1 = new string[] { lb.Items[NowIndex].Value, lb.Items[NowIndex].Text };
			string[] str2 = new string[] { lb.Items[NowIndex + 1].Value, lb.Items[NowIndex + 1].Text };

			lb.Items[NowIndex].Value = str2[0];
			lb.Items[NowIndex].Text = str2[1];
			lb.Items[NowIndex + 1].Value = str1[0];
			lb.Items[NowIndex + 1].Text = str1[1];
			lb.SelectedIndex = NowIndex + 1;
		}
		#endregion

		#region AbstractColleague成員
		public override void Reveive(string from, UCCommunicationData data)
		{
			ListItem li = new ListItem();
			li.Value = data.ID.ToString();
			li.Text = data.Name;
			lb.SelectedIndex = -1;
			li.Selected = true;
			lb.Items.Add(li);
		}

		public override void Remove(UCCommunicationData data)
		{
			data.ID = Convert.ToInt32(lb.SelectedValue);
			data.Name = lb.SelectedItem.Text;
			lb.Items.Remove(lb.SelectedItem);
		}

		public override void ColleagueDataBind(DataTable objTab)
		{
			string RowFilter = string.Format("IsSelected={0}", SelectType ? 1 : 0);
			lb.DataSource = new DataView(objTab, RowFilter, "", DataViewRowState.CurrentRows).ToTable();
			lb.DataBind();
		}

		public override DataTable BuildData()
		{
			DataTable objTab = new DataTable();
			objTab.Columns.Add("ID", typeof(int));
			objTab.Columns.Add("Name", typeof(string));
			objTab.Columns.Add("IsSelected", typeof(bool));

			foreach (ListItem li in lb.Items)
			{
				objTab.Rows.Add(new object[] { li.Value, li.Text, this.SelectType });
			}
			return objTab;
		}
		#endregion
	}
}