﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using GWeb.AppLibs;
using GWeb.AppUserControls.Communication;

namespace GWeb.AppUserControls.Communication
{
	public partial class UCCommunication : System.Web.UI.UserControl
	{
		#region Properties
		private IMediator mediator;

		/// <summary>
		/// 未選取項目標題文字
		/// </summary>
		public string NoSelectHeaderText
		{
			get
			{
				return lit_NoSelect.Text;
			}
			set
			{
				lit_NoSelect.Text = value;
			}
		}

		/// <summary>
		/// 已選取項目標題文字
		/// </summary>
		public string IsSelectHeaderText
		{
			get
			{
				return lit_IsSelect.Text;
			}
			set
			{
				lit_IsSelect.Text = value;
			}
		}

		/// <summary>
		/// 最多可選取數量
		/// </summary>
		public int MaxSelectCount 
		{
			get
			{
				return ViewState["MaxSelectCount"] != null ? Convert.ToInt32(ViewState["MaxSelectCount"]) : 1;
			}
			set
			{
				ViewState["MaxSelectCount"] = value;
			}
		}

		/// <summary>
		/// 繫結資料來源
		/// </summary>
		public DataTable SourceData { get; set; }
		#endregion

		#region Public Method
		/// <summary>
		/// 繫結資料
		/// </summary>
		public void BindData()
		{
			mediator = new ConcreteMediator();

			mediator.Register(UCBranches1);
			mediator.Register(UCBranches2);

			mediator.ColleagueDataBind(UCBranches1.ID, SourceData);
			mediator.ColleagueDataBind(UCBranches2.ID, SourceData);
		}

		/// <summary>
		/// 取得選取或未選取之資料
		/// </summary>
		/// <param name="IsSelected">bool值</param>
		/// <returns></returns>
		public DataTable GetData(bool IsSelected)
		{
			DataTable objTab = new DataTable();
			foreach (Control ctl in this.Controls)
			{
				if (ctl is UCBranchesA)
				{
					UCBranchesA uc = ctl as UCBranchesA;
					if (uc.SelectType == IsSelected)
					{
						objTab.Merge(uc.BuildData());
					}
				}
			}
			return objTab;
		}

		/// <summary>
		/// 取得所有列表資料
		/// </summary>
		/// <returns></returns>
		public DataTable GetAllData()
		{
			DataTable objTab = mediator.BuildCollegueData();
			return objTab;
		}
		#endregion

		#region Protected Method
		protected void Page_Load(object sender, EventArgs e)
		{
			mediator = new ConcreteMediator();

			mediator.Register(UCBranches1);
			mediator.Register(UCBranches2);

			//if (!IsPostBack && SourceData.Rows.Count > 0)
			//{
			//    BindData();
			//}
		}

		protected void btn_Send_Click(object sender, EventArgs e)
		{
			if (UCBranches2.DataCount < this.MaxSelectCount)
			{
				UCBranches1.Send(UCBranches2.ID, UCBranches1.CommunicationData);
			}
		}

		protected void btn_Receive_Click(object sender, EventArgs e)
		{
			UCBranches2.Send(UCBranches1.ID, UCBranches2.CommunicationData);
		}

		protected void btn_GetData_Click(object sender, EventArgs e)
		{

			DataTable objTab = mediator.BuildCollegueData();
			foreach (DataRow objDr in objTab.Rows)
			{
				Response.Write(objDr["Name"].ToString() + ": " + objDr["IsSelected"] + "<br>");
			}
		}
		#endregion
	}
}