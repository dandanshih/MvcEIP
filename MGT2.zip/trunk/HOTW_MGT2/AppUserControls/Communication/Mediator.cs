﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace GWeb.AppUserControls.Communication
{
	public struct UCCommunicationData
	{
		public int ID { get; set; }

		public string Name { get; set; }

		public bool IsSelected { get; set; }
	}

	public interface IMediator
	{
		void Register(AbstractColleague objCol);
		void ColleagueDataBind(string to, DataTable objTab);
		void Send(string from, string to, UCCommunicationData data);
		DataTable BuildCollegueData();
	}

	public class ConcreteMediator : IMediator
	{
		private Dictionary<string, AbstractColleague> objColls = new Dictionary<string, AbstractColleague>();

		public void Register(AbstractColleague objCol)
		{
			if (!this.objColls.ContainsValue(objCol))
			{
				this.objColls[objCol.ID] = objCol;
			}
			this.objColls[objCol.ID].Mediator = this;
		}

		public void ColleagueDataBind(string to, DataTable objTab)
		{
			this.objColls[to].ColleagueDataBind(objTab);
		}

		public void Send(string from, string to, UCCommunicationData data)
		{
			AbstractColleague objCol = this.objColls[to];
			if (objCol != null)
			{
				objCol.Reveive(from, data);
			}
		}

		public DataTable BuildCollegueData()
		{
			DataTable objTab = new DataTable();
			foreach (AbstractColleague objCol in objColls.Values)
			{
				objTab.Merge(objCol.BuildData());
			}
			return objTab;
		}
	}

	public abstract class AbstractColleague : System.Web.UI.UserControl
	{
		private IMediator _Mediator { get; set; }

		public IMediator Mediator
		{
			get { return _Mediator; }
			set { _Mediator = value; }
		}

		public UCCommunicationData data { get; set; }

		public void Send(string to, UCCommunicationData data)
		{
			_Mediator.Send(ID, to, data);
			Remove(data);
		}

		public abstract void Remove(UCCommunicationData data);

		public abstract void Reveive(string from, UCCommunicationData data);

		public abstract void ColleagueDataBind(DataTable objTab);

		public abstract DataTable BuildData();
	}
}