﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb.AppUserControls.Header
{
	public partial class UCMenu : GWeb.AppLibs.UCBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadMenuList();
			}
		}

		/// <summary>
		/// 讀取目前這個使用者的權限選單。
		/// </summary>
		private void LoadMenuList()
		{
			
			SqlParameter[] param = 
			{
				new SqlParameter("@AgentID", AUser.ExecAgentID) // Session["ExecAgentID"].ToString())
			};

			DataTable tabFunctionList = SqlHelper.ExecuteDataset
			(
				WebConfig.connectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_ReadMyFunction",
				param
			).Tables[0];

			// 將資料放入 Session 中，讓 PageBase 的部份可檢查該 AUser 不可進入不能進去的地方
			if (Session["MyFunctionList"] == null)
			{
				Session.Add("MyFunctionList", tabFunctionList);
			}
			else
			{
				Session["MyFunctionList"] = tabFunctionList;
			}

			// 以迴圈的方式建立功能表
			using (DataTable dt = (DataTable)Session["MyFunctionList"])
			{
				EO.Web.MenuItem miTopMenu = null;
				EO.Web.MenuItem miTmp = null;

				// 取出主選單
				DataView objMainVW = new DataView(dt, "ParentFunctionID=0", "FunctionOrder", DataViewRowState.CurrentRows);

				foreach (DataRowView MainRow in objMainVW)
				{
					// 取出子選單
					string Filter = string.Format("ParentFunctionID = {0} AND Authority > 0", MainRow["FunctionID"].ToString());
					DataView objSubVW = new DataView(dt, Filter, "FunctionOrder", DataViewRowState.CurrentRows);

					// 有符合條件的子選單才處理
					if (objSubVW.Count > 0)
					{
						try
						{
							miTmp = new EO.Web.MenuItem(GetLocalResourceObject("Func_" + MainRow["FunctionEName"].ToString()).ToString());
						}
						catch
						{
							//miTmp = new EO.Web.MenuItem(row["FunctionName"].ToString() + "-- 未設定語系!!");
							miTmp = new EO.Web.MenuItem(MainRow["FunctionName"].ToString());
						}

						miTmp.NavigateUrl = MainRow["FunctionURL"].ToString();

						// 加入主選單
						mnuMenu.Items.Add(miTmp);
						mnuMenu.Items.AddSeparator();

						miTopMenu = miTmp;

						// 加入子選單
						foreach (DataRowView SubRow in objSubVW)
						{
							try
							{
								miTmp = new EO.Web.MenuItem(GetLocalResourceObject("Func_" + SubRow["FunctionEName"].ToString()).ToString());
							}
							catch
							{
								//miTmp = new EO.Web.MenuItem(row["FunctionName"].ToString() + "-- 未設定語系!!");
								miTmp = new EO.Web.MenuItem(SubRow["FunctionName"].ToString());
							}

							miTmp.NavigateUrl = SubRow["FunctionURL"].ToString();
							miTopMenu.SubMenu.Items.Add(miTmp);
						}
					}
				}

				//foreach (DataRow row in dt.Rows)
				//{
				//    try
				//    {
				//        miTmp = new EO.Web.MenuItem(GetLocalResourceObject("Func_" + row["FunctionEName"].ToString()).ToString());
				//    }
				//    catch
				//    {
				//        //miTmp = new EO.Web.MenuItem(row["FunctionName"].ToString() + "-- 未設定語系!!");
				//        miTmp = new EO.Web.MenuItem(row["FunctionName"].ToString());
				//    }
				//    miTmp.NavigateUrl = row["FunctionURL"].ToString();

				//    if (Convert.ToInt32(row["FunctionLevel"]) == 1)
				//    {
				//        mnuMenu.Items.Add(miTmp);
				//        mnuMenu.Items.AddSeparator();
							
				//        miTopMenu = miTmp;
				//    }
				//    else
				//    {
				//        if (miTopMenu != null)
				//            miTopMenu.SubMenu.Items.Add(miTmp);
				//    }
				//}
			}

			//////////////////////////////////////////////////////////////////////////
			//EO.Web.MenuItem miQuit = new EO.Web.MenuItem(GetLocalResourceObject("Func_Logout").ToString());

            EO.Web.MenuItem miEditPwd = new EO.Web.MenuItem("修改密碼");
            miEditPwd.NavigateUrl = "~/EditPwd.aspx";
            mnuMenu.Items.Add(miEditPwd);

			EO.Web.MenuItem miQuit = new EO.Web.MenuItem("登出");
			miQuit.NavigateUrl = "~/Logout.aspx";
			mnuMenu.Items.Add(miQuit);
		}
	}
}