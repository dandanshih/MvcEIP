﻿using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;
using GFC.Utilities;
using GWeb.AppLibs;

namespace GWeb
{
	/// <summary>
	///Marquee 的摘要描述
	/// </summary>
	public class Marquee : IHttpHandler, IRequiresSessionState
	{

		public void ProcessRequest(HttpContext context)
		{
			context.Response.ContentType = "text/plain";

			string message = "";

            SqlParameter[] param =
			{
                new SqlParameter("@Languages", System.Threading.Thread.CurrentThread.CurrentUICulture.Name.Replace("-", "").ToUpper())
                
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.connectionString,
														  CommandType.StoredProcedure,
														  "NSP_AgentWeb_R_ReadUnusualLogToWebMarquee",
                                                          param
                                                          );
			
			// 將新警示訊息資料存成 DataTable
			DataTable objTab = new DataTable();
			objTab.Load(objDtr);
			objDtr.Close();

			if (context.Application["AlarmMessage"] == null)
			{
				// 將 DataTable 存在 Application
				context.Application["AlarmMessage"] = objTab;
			}
			else
			{
				foreach (DataRow row in objTab.Rows)
				{
					// 將新的警示訊息新增到 Application
					((DataTable)context.Application["AlarmMessage"]).ImportRow(row);
				}
			}

			if (((DataTable)context.Application["AlarmMessage"]).Rows.Count > 0)
			{
				foreach (DataRow row in ((DataTable)context.Application["AlarmMessage"]).Rows)
				{
					message += "<div>" + row["EventDescription"] + "</div>";
				}
			}
			//else
			//{
			//    message = "<div>" + "歡迎來到 Happy Online!" + "</div>";
			//}

			context.Response.Write(message);
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}