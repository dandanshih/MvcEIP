﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using GFC;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.AppUserControls.Report
{
    public partial class UCItemExchange : System.Web.UI.UserControl
    {
        #region member

        public int GameAreaType { get; set; }

        #endregion

        #region private

        private void EditAddresss(string ActID ,string Address)
        {
            SqlParameter[] param =
			{
                new SqlParameter("@ActID",ActID),
			    new SqlParameter("@Address",Address),
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_ChangeStickersLogAddress",
                param
            );
        }

        private void LoadChangeStickersLog()
        {
            table1.Visible = false;
            lblQueryDatetime1.Text = string.Format
                                    (
                                        "查詢時間為 {0} - {1}",
                                        (rblDateRangeType.SelectedValue.Equals("0") ? "2010/01/01 12:00:00" : UCDateRange1.StartDate),
                                        (rblDateRangeType.SelectedValue.Equals("0") ? DateTime.Now.ToString("yyyy/MM/dd") + " 11:59:59" : UCDateRange1.EndDate)
                                    );
            SqlParameter[] param =
			{
                new SqlParameter("@StartDate",rblDateRangeType.SelectedValue.Equals("0")? "2010/01/01 12:00:00":UCDateRange1.StartDate),
			    new SqlParameter("@EndDate",rblDateRangeType.SelectedValue.Equals("0")? DateTime.Now.ToString("yyyy/MM/dd") + " 11:59:59":UCDateRange1.EndDate),
			    new SqlParameter("@DateGroupType",rdlDateUnit.SelectedValue),
			    new SqlParameter("@GameAreaType", GameAreaType),
                new SqlParameter("@MemberAccount", txtMemberAccount.Text),
                new SqlParameter("@NickName", txtNickName.Text)
			};

            SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_R_ChangeStickersLog",
                        param);

            gvChangeStickersLog.DataSource = sdr;
            gvChangeStickersLog.DataBind();
            sdr.Close();
        }

        private void LoadChangeStickersLogDetail()
        {
            SqlParameter[] arParms =
			{
                new SqlParameter("@StartDate",hidStartDate.Value),
				new SqlParameter("@EndDate",hidEndDate.Value),
                new SqlParameter("@MemberAccount", hidMemberAccount.Value),
                new SqlParameter("@NickName", hidNickName.Value),
                new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",SqlDbType.Int),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};

            arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
            arParms[arParms.Length - 2].Value = UCPager1.PageSize;
            lblQueryDatetime2.Text = "查詢時間為 " + hidStartDate.Value + " - " + hidEndDate.Value;

            DataTable objDt = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_ChangeStickersLogDetail",
                arParms
            ).Tables[0];

            gvGameLog.DataSource = objDt;
            gvGameLog.DataBind();

            UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
            UCPager1.DataBind();
        }

        #endregion

        #region Protected

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // 預設日期
				//UCDateRange1.StartDate = DateTime.Now.ToString("yyyy/MM/dd 12:00:00");
				//UCDateRange1.EndDate = DateTime.Now.AddDays(1).ToString("yyyy/MM/dd 11:59:00");

                rblDateRangeType.SelectedValue = "1";
                table1.Visible = false;
            } 
        }

        /// <summary>
        /// 按下查詢鈕
        /// </summary>
        protected void btnQuery_Click(object sender, EventArgs e)
        {
            LoadChangeStickersLog();
        }

        #endregion

        #region Protected StickersLog
        
        /// <summary>
        /// 明細 / 匯出事件
        /// </summary>
        protected void gvChangeDateBound_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            // 匯出
            UCPager1.CurrentPageNumber = 1;
            string[] sDate = e.CommandArgument.ToString().Split('~');
            hidStartDate.Value = Convert.ToDateTime(sDate[0]).ToString("yyyy-MM-dd HH:mm:ss");
            hidEndDate.Value = Convert.ToDateTime(sDate[1]).ToString("yyyy-MM-dd HH:mm:ss");
            hidMemberAccount.Value = txtMemberAccount.Text;
            hidNickName.Value = txtNickName.Text;

            SqlParameter[] arParms =
			{
                new SqlParameter("@StartDate",hidStartDate.Value),
				new SqlParameter("@EndDate",hidEndDate.Value),
                new SqlParameter("@MemberAccount", hidMemberAccount.Value),
                new SqlParameter("@NickName", hidNickName.Value),
                new SqlParameter("@PageIndex",UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize",SqlDbType.Int),
				new SqlParameter("@TotalRecords",SqlDbType.BigInt)
			};
            arParms[arParms.Length - 1].Direction = ParameterDirection.Output;
            arParms[arParms.Length - 2].Value = UCPager1.PageSize;
            try
            {
                switch (e.CommandName)
                {
                    case "Detail":
                        table1.Visible = true;
                        lblQueryDatetime2.Visible = true;
                        lblQueryDatetime2.Text = "查詢時間為" + Convert.ToDateTime(sDate[0]).ToString("yyyy-MM-dd HH:mm:ss") + " - " +
                            Convert.ToDateTime(sDate[1]).ToString("yyyy-MM-dd HH:mm:ss");

                        SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.ConnectionString,
                           CommandType.StoredProcedure,
                           "NSP_AgentWeb_R_ChangeStickersLogDetail",
                           arParms);

                        gvGameLog.DataSource = sdr;
                        gvGameLog.DataBind();
                        sdr.Close();
                        UCPager1.RecordCount = Int32.Parse(arParms[arParms.Length - 1].Value.ToString());
                        UCPager1.DataBind();
                        break;
                    case "Export":
                        DataTable dt = SqlHelper.ExecuteDataset(WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_R_ChangeStickersLogDetail",
                        arParms).Tables[0];
                        //帳號、姓名、性別、暱稱、狀態、最後登入日期、手機、e-mail、總儲值點數、總押分、目前點數、遊戲登入次數。

                        dt.TableName = "商品兌換紀錄查詢";
						dt.Columns["RowNo"].ColumnName = "編號";
						dt.Columns["CreateDate"].ColumnName = "兌換時間";						
                        dt.Columns["MemberAccount"].ColumnName = "帳號";
                        dt.Columns["RealName"].ColumnName = "姓名";                        
                        dt.Columns["NickNAme"].ColumnName = "暱稱";
						dt.Columns["Mobile"].ColumnName = "手機";
						dt.Columns["GroupName"].ColumnName = "兌換商品";
						dt.Columns["Address"].ColumnName = "地址";
                        dt.Columns["Status"].ColumnName = "狀態";
                        dt.Columns["SendDate"].ColumnName = "寄出時間";

                        dt.Columns.Remove("MemberID");
						dt.Columns.Remove("Gender");
                        dt.Columns.Remove("MemberStatus");
						dt.Columns.Remove("LastLoginDate");
                        dt.Columns.Remove("Email");
                        dt.Columns.Remove("AmassedPoint");
                        dt.Columns.Remove("TotalBet");
						dt.Columns.Remove("Points");
						dt.Columns.Remove("AmassedIntoGameTimes");
						dt.Columns.Remove("StickerID");

                        NPOIRender.ExportDataTableToEXcel(dt, Response);
                        break;
                }
            }
            catch (Exception)
            {
            }
        }

        #endregion

        #region Protected StickersLogDetail

        /// <summary>
        /// 換頁事件
        /// </summary>
        protected void Pager_Change(object sender, EventArgs e)
        {
            LoadChangeStickersLogDetail();
        }
        
        /// <summary>
        /// 勾起全選時
        /// </summary>
        protected void cbAllSelectChange(object sender, EventArgs e)
        {
            foreach (GridViewRow gvr in gvGameLog.Rows)
            {
				if (gvr.Cells[9].Text == "處理中")
				{
					(gvr.Cells[0].FindControl("cbSelect") as CheckBox).Checked = (sender as CheckBox).Checked;
				}
            }
        }

        /// <summary>
        /// 欄位的 編輯/儲存/取消
        /// </summary>
        protected void gvGameLog_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            // 當前欄位索引
            int RowIdx = Convert.ToInt32(e.CommandArgument.ToString());

            // 地址儲存格
            TableCell CellAddress = gvGameLog.Rows[RowIdx].Cells[8];
            Label lblAddress = (Label)CellAddress.FindControl("lblAddress");
            TextBox txtAddress = (TextBox)CellAddress.FindControl("txtAddress");

            // 功能鍵儲存格
            TableCell CellControl = gvGameLog.Rows[RowIdx].Cells[11];
            HtmlGenericControl spEdit = (HtmlGenericControl)CellControl.FindControl("spEdit");
            HtmlGenericControl spSave = (HtmlGenericControl)CellControl.FindControl("spSave");
            HtmlGenericControl spCancel = (HtmlGenericControl)CellControl.FindControl("spCancel");
            // 編號
            string StickerID = ((HiddenField)CellControl.FindControl("hidStickerID")).Value;
            
            switch (e.CommandName)
            {
                case "btnEdit":
                    lblAddress.Visible = false;
                    txtAddress.Visible = true;

                    spEdit.Visible = false;
                    spSave.Visible = true;
                    spCancel.Visible = true;
                    break;
                case "btnSave":
                    // 編輯地址
                    EditAddresss(StickerID, txtAddress.Text);
                    // 重新Load資料
                    LoadChangeStickersLogDetail();
                    break;
                case "btnCancel":
                    lblAddress.Visible = true;
                    txtAddress.Visible = false;

                    spEdit.Visible = true;
                    spSave.Visible = false;
                    spCancel.Visible = false;
                    break;
            }
        }

        /// <summary>
        /// 已寄出事件
        /// </summary>
        protected void btnChange_Click(object sender, EventArgs e)
        {
            // 修改地址
            string sStickerIDList = "";
            CheckBox ckBox;

            for (int i = 0; i < gvGameLog.Rows.Count; i++)
            {
                ckBox = ((CheckBox)gvGameLog.Rows[i].Cells[0].FindControl("cbSelect"));

                if (ckBox.Checked)
                {
                    sStickerIDList += ((HiddenField)gvGameLog.Rows[i].Cells[11].FindControl("hidStickerID")).Value + ",";
                }
            }

            if (sStickerIDList.Length == 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, GetType(), "msg", "alert('請勾選項目');", true);
                return;
            }

            SqlParameter[] param =
			{
                new SqlParameter("@StickerIDList",sStickerIDList.Left(sStickerIDList.Length-1))
			};

            SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_G_ChangeStickersStatus",
                param);

            LoadChangeStickersLogDetail();
        }

        /// <summary>
        /// 列印寄送事件
        /// </summary>
        protected void btnPrint_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.TableName = "商品兌換紀錄查詢";
            dt.Columns.Add("姓名");
            dt.Columns.Add("兌換商品");
            dt.Columns.Add("地址");
            for (int i = 0; i < gvGameLog.Rows.Count; i++)
            {
                CheckBox ckBox = ((CheckBox)gvGameLog.Rows[i].Cells[0].FindControl("cbSelect"));
                if (ckBox.Checked)
                {
                    DataRow row = dt.NewRow();
                    row["姓名"] = gvGameLog.Rows[i].Cells[4].Text;
                    row["兌換商品"] = gvGameLog.Rows[i].Cells[7].Text;
                    row["地址"] = ((Label)gvGameLog.Rows[i].Cells[8].FindControl("lblAddress")).Text;
                    dt.Rows.Add(row);
                }
            }
            NPOIRender.ExportDataTableToEXcel(dt, Response);
        }

		protected void gvGameLog_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				if (DataBinder.Eval(e.Row.DataItem, "Status").ToString() == "寄出")
				{
					CheckBox chk = (CheckBox)e.Row.FindControl("cbSelect");
					chk.Enabled = false;
				}
			}
		}
        #endregion
    }
}