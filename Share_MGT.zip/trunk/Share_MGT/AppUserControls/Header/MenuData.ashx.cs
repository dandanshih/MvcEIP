﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Data;
using Share_MGT.AppLibs;
using System.Web.SessionState;

namespace Share_MGT.AppUserControls.Header
{
    /// <summary>
    /// MenuData 的摘要描述
    /// </summary>
    public class MenuData : IHttpHandler, IReadOnlySessionState
    {
        private struct MenuInfo
        {
            public int FunctionID { get; set; }

            public string FunctionUrl { get; set; }

            public string MenuName { get; set; }
        }

        private string LoadJsonList(HttpContext context)
        {
            string result = string.Empty;
            if (context.Session["MyFunctionList"] != null)
            {

				// 以迴圈的方式建立功能表 : MyFunctionList 是從 NSP_AgentWeb_A_ReadMyFunction 取得
                using (DataTable dt = (DataTable)context.Session["MyFunctionList"])
                {
                    var query = from item in dt.AsEnumerable()
                                 where Convert.ToInt32(item["ParentFunctionID"]) == 0
                                 orderby item["FunctionOrder"]
                                 select new
                                 {
                                     FunctionID = item["FunctionID"],
                                     FunctionUrl = item["FunctionURL"].ToString().TrimStart('~'),
									 FunctionOrder = item["FunctionOrder"],
									 MenuName = new Func<DataRow, string>((x) =>
                                     {
                                         try
                                         {
                                             return HttpContext.GetLocalResourceObject("~/AppUserControls/Header/", "Func_" + x["FunctionEName"].ToString()).ToString();
                                         }
                                         catch
                                         {
                                             return Utility.TextResource.GetTextResxByResxKey("AgentWebMenu", x["FunctionEName"]);
                                         }
                                     })(item),
                                     Children = from sub in dt.AsEnumerable()
                                                where Convert.ToInt32(sub["ParentFunctionID"]) == Convert.ToInt32(item["FunctionID"]) &&
                                                    (int.Parse(sub["Authority"].ToString()) & (int)EnumAuthority.Run) == (int)EnumAuthority.Run &&
                                                    (int.Parse(sub["MenuAuthority"].ToString()) & (int)EnumAuthority.Run) == (int)EnumAuthority.Run
                                                orderby sub["FunctionOrder"]
                                                select new
                                                {
                                                    FunctionID = sub["FunctionID"],
                                                    FunctionUrl = sub["FunctionURL"].ToString().TrimStart('~'),
													//FunctionOrder = sub["FunctionOrder"],
                                                    MenuName = new Func<DataRow, string>((x) =>
                                                    {
                                                        try
                                                        {
                                                            return HttpContext.GetLocalResourceObject("~/AppUserControls/Header/", "Func_" + x["FunctionEName"].ToString()).ToString();
                                                        }
                                                        catch
                                                        {
                                                            return Utility.TextResource.GetTextResxByResxKey("AgentWebMenu", x["FunctionEName"]);
                                                        }
                                                    })(sub),
                                                }
                                 };
                    //var query = from item in dt.AsEnumerable()
                    //            group item by item["ParentFunctionID"] into Group
                    //            where Convert.ToInt32(Group.Key) > 0 && Group.Max(x => Convert.ToInt64(x["Authority"])) > 0
                    //            select new
                    //            {
                    //                FunctionID = Group.Key,
                    //                FunctionUrl = Group.Max(x => x["FunctionURL"].ToString()),
                    //                MenuName = Group.Max(x =>
                    //                {
                    //                    try
                    //                    {
                    //                        return HttpContext.GetLocalResourceObject("~/AppUserControls/Header/", "Func_" + x["FunctionEName"].ToString());
                    //                    }
                    //                    catch
                    //                    {
                    //                        return Utility.TextResource.GetTextResxByResxKey("AgentWebMenu", x["FunctionEName"]);
                    //                    }
                    //                }),
                    //                Children = Group.Aggregate(new List<MenuInfo>(), (data, obj) =>
                    //                {
                    //                    if (((int.Parse(obj["Authority"].ToString()) & (int)EnumAuthority.Run) == (int)EnumAuthority.Run)
                    //                        && ((int.Parse(obj["MenuAuthority"].ToString()) & (int)EnumAuthority.Run) == (int)EnumAuthority.Run))
                    //                    {
                    //                        var menu = new MenuInfo();

                    //                        menu.FunctionID = Convert.ToInt32(obj["FunctionID"]);
                    //                        menu.FunctionUrl = obj["FunctionURL"].ToString();
                    //                        try
                    //                        {
                    //                            menu.MenuName = HttpContext.GetLocalResourceObject("~/AppUserControls/Header/", "Func_" + obj["FunctionEName"].ToString()).ToString();
                    //                        }
                    //                        catch
                    //                        {
                    //                            //miTmp = new EO.Web.MenuItem(row["FunctionName"].ToString() + "-- 未設定語系!!");
                    //                            menu.MenuName = Utility.TextResource.GetTextResxByResxKey("AgentWebMenu", obj["FunctionEName"]);
                    //                        }
                    //                        data.Add(menu);
                    //                    }
                    //                    return data;
                    //                })
                    //            };
                    JavaScriptSerializer jss = new JavaScriptSerializer();
                    result = jss.Serialize(query.ToList());
                }
            }
            return result;
        }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            context.Response.Write(LoadJsonList(context));
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}