﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace Share_MGT.AppUserControls.Series
{
    public partial class UCAppSelect : UCBase
    {
        
        #region Field
        private bool m_showAppGroup = true;
        private bool m_showApp = true;
        private bool m_isAll = false;
        private bool m_isAppGroupAll = true;
        private bool m_isAppAll = true;
        #endregion

        #region Property

        /// <summary>
        /// 取得AgentID。
        /// </summary>
        public int AgentID { get { return int.Parse(base.AUser.AgentID); } }

        /// <summary>
        /// 取得或設定是否顯示分桶群組。
        /// </summary>
        public bool ShowAppGroup { set { m_showAppGroup = value; } }

        /// <summary>
        /// 取得或設定是否顯示分桶。
        /// </summary>
        public bool ShowApp { set { m_showApp = value; } }

        /// <summary>
        /// 是否有全部選項。
        /// </summary>
        public bool IsAll { set { m_isAll = value; } }

        /// <summary>
        /// 分桶群組是否有全部選項。
        /// </summary>
        public bool IsAppGroupAll { set { m_isAppGroupAll = value; } }

        /// <summary>
        /// 分桶是否有全部選項。
        /// </summary>
        public bool IsAppAll { set { m_isAppAll = value; } }

        /// <summary>
        /// 分桶群組名稱。
        /// </summary>
        public string AppGroupName
        {
            get { return (ddlAppGroup.SelectedItem != null) ? ddlAppGroup.SelectedItem.Text : ""; }
        }

        /// <summary>
        /// 分桶群組編號。
        /// </summary>
        public int AppGroupNo
        {
            get { return Convert.ToInt32(ddlAppGroup.SelectedValue); }
        }

        /// <summary>
        /// 取得分桶名稱。
        /// </summary>
        public string AppName
        {
            get { return (ddlApp.SelectedItem != null) ? ddlApp.SelectedItem.Text : ""; }
        }

        /// <summary>
        /// 分桶編號。
        /// </summary>
        public int AppNo
        {
            get { return string.IsNullOrEmpty(ddlApp.SelectedValue) ? 0 : Convert.ToInt32(ddlApp.SelectedValue); }
        }

        #endregion

        #region Private Method

        /// <summary>
        /// 讀取分桶群組。
        /// </summary>
        private void LoadAppGroup()
        {
            ddlAppGroup.Items.Clear();

            SqlParameter[] param = 
			{
				new SqlParameter("@AgentID", AgentID)
			};

            DataTable dt = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Agent_AppGroup_List",
                param
            ).Tables[0];

            if (m_isAll && m_isAppGroupAll)
            {
                ddlAppGroup.Items.Add(new ListItem("全部", "-1"));
            }

            ddlAppGroup.AppendDataBoundItems = true;
            ddlAppGroup.DataTextField = "AppGroupName";
            ddlAppGroup.DataValueField = "AppGroupNo";
            ddlAppGroup.DataSource = dt;
            ddlAppGroup.DataBind();

        }

        /// <summary>
        /// 讀取分桶。
        /// </summary>
        private void LoadApp()
        {
            ddlApp.Items.Clear();

            SqlParameter[] param =
			{
				new SqlParameter("@AgentID", AgentID),
                new SqlParameter("@AppGroupNo", m_showAppGroup ? ddlAppGroup.SelectedValue : "-1")
			};

            DataTable dt = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Agent_App_List",
                param
            ).Tables[0];

            if (m_isAll && m_isAppAll)
            {
                ddlApp.Items.Add(new ListItem("全部", "-1"));
            }

            ddlApp.AppendDataBoundItems = true;
            ddlApp.DataTextField = "AppName";
            ddlApp.DataValueField = "AppNo";
            ddlApp.DataSource = dt;
            ddlApp.DataBind();
        }

        #endregion

        #region Protected Method

        // 要用這個，不然會取不到base.AUser (取base.AUser.AgentID用的)
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e); // 先讓父類別OnLoad之後，父類別的AUser才會有東西

            if (!IsPostBack)
            {
                pnlAppGroup.Visible = m_showAppGroup;

                pnlApp.Visible = m_showApp;

                // 讀取選單資料
                if (m_showAppGroup)
                {
                    LoadAppGroup();
                }
                if (m_showApp)
                {
                    LoadApp();
                }
            }
        }

        // 不能用這個，要用上面的OnLoad
        protected void Page_Init(object sender, EventArgs e)
        {
            
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlAppGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadApp();
        }

        #endregion
    }
}