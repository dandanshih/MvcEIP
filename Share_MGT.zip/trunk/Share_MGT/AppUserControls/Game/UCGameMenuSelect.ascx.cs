﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace Share_MGT.AppUserControls.Game
{
    public partial class UCGameMenuSelect : UCBase
    {
        #region Field
        private bool m_showGameType = true;
        private bool m_showGame = true;
        private int m_displayGame = 0;
        private bool m_isFree = false;
        private bool m_isAll = false;
        private bool m_isGameTypeAll = true;
        private bool m_isGameAll = true;
        #endregion

        #region Property

        /// <summary>
        /// 取得或設定是否顯示遊戲類別。
        /// </summary>
        public bool ShowGameType { set { m_showGameType = value; } }

        /// <summary>
        /// 設定顯示的遊戲列表，只有在 ShowGameType 為 false 的狀況下才會有效。
        /// </summary>
        public int DisplayGame { set { m_displayGame = value; } }

        /// <summary>
        /// 取得或設定是否顯示遊戲。
        /// </summary>
        public bool ShowGame { set { m_showGame = value; } }

        /// <summary>
        /// 是否有免費區選項。
        /// </summary>
        public bool IsFree { set { m_isFree = value; } }

        /// <summary>
        /// 是否有全部選項。
        /// </summary>
        public bool IsAll { set { m_isAll = value; } }

        /// <summary>
        /// 遊戲類別是否有全部選項。
        /// </summary>
        public bool IsGameTypeAll { set { m_isGameTypeAll = value; } }

        /// <summary>
        /// 遊戲是否有全部選項。
        /// </summary>
        public bool IsGameAll { set { m_isGameAll = value; } }

        /// <summary>
        /// 遊戲類別名稱。
        /// </summary>
        public string GameTypeSeletedText
        {
            get { return (ddlGameType.SelectedItem != null) ? ddlGameType.SelectedItem.Text : ""; }
        }

        /// <summary>
        /// 遊戲類別編號。
        /// </summary>
        public string GameTypeSeletedValue
        {
            get { return (ddlGameType.SelectedItem != null) ? ddlGameType.SelectedItem.Value : "-1"; }
        }

        /// <summary>
        /// 取得遊戲名稱。
        /// </summary>
        public string GameSeletedText
        {
            get { return (ddlGame.SelectedItem != null) ? ddlGame.SelectedItem.Text : ""; }
        }

        /// <summary>
        /// 遊戲編號。
        /// </summary>
        public string GameSeletedValue
        {
            get { return (ddlGame.SelectedItem != null) ? ddlGame.SelectedItem.Value : "0"; }
        }

        #endregion

        #region Private Method

        /// <summary>
        /// 讀取遊戲類別。
        /// </summary>
        private void LoadGameType()
        {
            ddlGameType.Items.Clear();

            SqlParameter[] param = 
			{
				new SqlParameter("@ListType", "999"),
				new SqlParameter("@GameTypeID", "0"),
				new SqlParameter("@GameID", "0"),
				new SqlParameter("@IsShowFreeGame", "0")
			};

            DataTable dt = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_G_GetGameList",
                param
            ).Tables[0];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["ResxKey"] = Utility.TextResource.GetTextResxByMessageID("GameMenuType", dt.Rows[i]["Message_id"]);
            }

            if (m_isAll && m_isGameTypeAll)
            {
                ddlGameType.Items.Add(new ListItem(GetLocalResourceObject("All").ToString(), "0"));
            }

            ddlGameType.AppendDataBoundItems = true;
            ddlGameType.DataTextField = "ResxKey";
            ddlGameType.DataValueField = "Message_id";
            ddlGameType.DataSource = dt;
            ddlGameType.DataBind();
        }

        /// <summary>
        /// 讀取遊戲名稱。
        /// </summary>
        private void LoadGame()
        {
            ddlGame.Items.Clear();

            SqlParameter[] param =
			{
				new SqlParameter("@ListType", "1"),
				new SqlParameter("@GameMenuType", m_showGameType ? ddlGameType.SelectedValue : m_displayGame.ToString() ),
				new SqlParameter("@GameID", "0"),
				new SqlParameter("@IsShowFreeGame", m_isFree)
			};

            DataTable dt = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_G_GetGameList",
                param
            ).Tables[0];

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["ResxKey"] = Utility.TextResource.GetTextResxByMessageID("GameName", dt.Rows[i]["Message_id"]);
            }

            if (m_isAll && m_isGameAll)
            {
                ddlGame.Items.Add(new ListItem(GetLocalResourceObject("All").ToString(), "0"));
            }

            ddlGame.AppendDataBoundItems = true;
            ddlGame.DataTextField = "ResxKey";
            ddlGame.DataValueField = "GameID";
            ddlGame.DataSource = dt;
            ddlGame.DataBind();
        }

        #endregion

        #region Protected Method

        protected void Page_Init(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                pnlGameType.Visible = m_showGameType;

                pnlGame.Visible = m_showGame;
                ddlGameType.AutoPostBack = m_showGame;

                // 讀取選單資料
                if (m_showGameType)
                {
                    LoadGameType();
                }
                if (m_showGame)
                {
                    LoadGame();
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlGameType_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadGame();
        }

        #endregion
    }
}