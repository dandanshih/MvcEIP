﻿using System;

namespace Share_MGT.AppUserControls.Marquee
{
	public partial class UCMarquee : System.Web.UI.UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}