﻿using System;
using Share_MGT.AppLibs;

namespace Share_MGT.AppUserControls.Other
{
	public partial class AuthorityButton : System.Web.UI.UserControl
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		// 要判斷的權限種類
		private EnumAuthority m_AuthorityType = EnumAuthority.None;
		public EnumAuthority AuthorityType
		{
			get
			{
				return this.m_AuthorityType;
			}
			set
			{
				this.m_AuthorityType = value;
			}
		}

		// 是否可見
		public override bool Visible
		{
			get
			{
				if (this.Page is FormBase)
				{
					return ((FormBase)this.Page).Authority.CheckAuthority(AuthorityType);
				}
				else
				{
					return base.Visible;
				}
			}
			set
			{
				base.Visible = value;
			}
		}
		
	}
}