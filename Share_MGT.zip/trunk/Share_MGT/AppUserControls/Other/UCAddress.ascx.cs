﻿using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Caching;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.AppUserControls.Other
{
    public partial class UCAddress : System.Web.UI.UserControl
    {
        #region private

        /// <summary>
        /// 讀取來源資料。
        /// </summary>
        /// <returns></returns>
        private DataTable GetData()
        {
            string CacheName = "AddressData";
            DataTable objTab = HttpContext.Current.Cache[CacheName] as DataTable;

            if (objTab == null)
            {
                objTab = SqlHelper.ExecuteDataset
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_GameWeb_GetZoneNameList"
                ).Tables[0];

                objTab = objTab.Select("CityName <> '' AND ZoneName <> ''").CopyToDataTable();

                HttpContext.Current.Cache.Insert
                (
                    CacheName,
                    objTab,
                    null,
					DateTime.Now.AddDays(1),
                    Cache.NoSlidingExpiration,
                    CacheItemPriority.Normal,
                    null
                );
            }

            return objTab;
        }

        /// <summary>
        /// 繫結縣市列表資料。
        /// </summary>
        private void BindCity()
        {
            DataTable objSourceTab = GetData();

            DataTable objTab = new DataTable();
            objTab.Columns.Add("CityID", typeof(string));
            objTab.Columns.Add("CityName", typeof(string));

            var grouped = from row in objSourceTab.AsEnumerable()
                          orderby row["SortNo"]
                          group row by row["CityID"];

            foreach (var g in grouped)
            {
                DataRow row = g.ElementAt(0);
                objTab.Rows.Add(row["CityID"], row["CityName"]);
            }

            ddl_City.DataSource = objTab;
            ddl_City.DataBind();

            BindZone();
        }

        /// <summary>
        /// 繫結鄉鎮列表資料。
        /// </summary>
        private void BindZone()
        {
            string RowFilter = string.Format("CityID = {0}", CityValue);
            ddl_Zone.DataSource = new DataView(GetData(), RowFilter, "", DataViewRowState.CurrentRows);
            ddl_Zone.DataBind();

            BindZipCode();
        }

        /// <summary>
        /// 讀取郵遞區號資料。
        /// </summary>
        private void BindZipCode()
        {
            string RowFilter = string.Format("CityID = {0} AND ZoneID = {1}", CityValue, ZoneValue);
            DataView objVW = new DataView(GetData(), RowFilter, "", DataViewRowState.CurrentRows);
            ZipText = objVW[0]["ZipCode"].ToString();
        }

        #endregion

        #region protected

        protected void Page_Init(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCity();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddl_City_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindZone();
        }

        protected void ddl_Zone_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindZipCode();
        }

        #endregion

        #region public

        /// <summary>
        /// 設定或取得 css 風格。
        /// </summary>
        public string Style
        {
            get { return pnlAddress.Attributes["style"] != null ? pnlAddress.Attributes["style"] : ""; }
            set { pnlAddress.Attributes.Add("style", value); }
        }

        /// <summary>
        /// 設定 TabIndex。
        /// </summary>
        public short TabIndex
        {
            set
            {
                txt_ZipCode.TabIndex = value;
                ddl_City.TabIndex = value;
                ddl_Zone.TabIndex = value;
            }
        }

        public bool Enabled
        {
            set
            {
                pnlAddress.Enabled = value;
            }
        }

        /// <summary>
        /// 取得或設定縣市的值。
        /// </summary>
        public string CityValue
        {
            get { return ddl_City.SelectedValue; }
            set
            {
                if (ddl_City.Items.FindByValue(value) != null)
                {
                    ddl_City.SelectedValue = value;
                    BindZone();
                }
            }
        }

        /// <summary>
        /// 取得或設定縣市的名稱。
        /// </summary>
        public string CityText
        {
            get { return ddl_City.SelectedItem.Text; }
            set
            {
                if (ddl_City.Items.FindByText(value) != null)
                {
                    ddl_City.SelectedIndex = -1;
                    ddl_City.Items.FindByText(value).Selected = true;
                    BindZone();
                }
            }
        }

        /// <summary>
        /// 取得或設定縣市的索引。
        /// </summary>
        public int CityIndex
        {
            get { return ddl_City.SelectedIndex; }
            set
            {
                if (ddl_City.Items.Count > value)
                {
                    ddl_City.SelectedIndex = value;
                    BindZone();
                }
            }
        }

        /// <summary>
        /// 取得或設定鄉鎮的值。
        /// </summary>
        public string ZoneValue
        {
            get { return ddl_Zone.SelectedValue; }
            set
            {
                if (ddl_Zone.Items.FindByValue(value) != null)
                {
                    ddl_Zone.SelectedValue = value;
                    BindZipCode();
                }
            }
        }

        /// <summary>
        /// 取得或設定鄉鎮的名稱。
        /// </summary>
        public string ZoneText
        {
            get { return ddl_Zone.SelectedItem.Text; }
            set
            {
                if (ddl_Zone.Items.FindByText(value) != null)
                {
                    ddl_Zone.SelectedIndex = -1;
                    ddl_Zone.Items.FindByText(value).Selected = true;
                    BindZipCode();
                }
            }
        }

        /// <summary>
        /// 取得郵遞區號。
        /// </summary>
        public string ZipText
        {
            get { return txt_ZipCode.Text; }
            private set { txt_ZipCode.Text = value; }
        }

        #endregion
    }
}