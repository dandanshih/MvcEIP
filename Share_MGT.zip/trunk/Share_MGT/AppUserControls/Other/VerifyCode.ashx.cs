﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;

namespace Share_MGT.AppUserControls.Other
{
	/// <summary>
	///VerifyCode 的摘要描述
	/// </summary>
	public class VerifyCode : IHttpHandler, System.Web.SessionState.IRequiresSessionState
	{
		public void ProcessRequest(HttpContext context)
		{
			RandomCode gif = new RandomCode();                      // 初始化驗證碼生成類別
			string valid = "";                                      // 定義隨機數
			MemoryStream ms = gif.Create(out valid);                // 獲取包括驗證碼圖片的內存流
			context.Session["gif"] = valid;                         // 驗證碼儲存在 Session 中供驗證
			context.Response.ClearContent();                        // 清空輸出流
			context.Response.ContentType = "image/png";             // 輸出流的格式
			context.Response.Cache.SetNoStore();					// 輸出的圖檔不存在 Client 中
			context.Response.BinaryWrite(ms.ToArray());             // 輸出
			context.Response.Flush();
		}
		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}

	/// <summary>
	/// RandomCode 的摘要說明
	/// </summary>
	public class RandomCode
	{
		/// <summary>
		/// 該方法用於生成指定位數的隨機數
		/// </summary>
		/// <param name="VcodeNum">參數是隨機數的位數</param>
		/// <returns>回傳一個隨機數字符串</returns>
		private string RndNum(int VcodeNum)
		{
			// 驗證碼可以顯示的字符集合
			string Vchar = "0,1,2,3,4,5,6,7,8,9";
			//",a,b,c,d,e,f,g,h,k,j,k,m,m,n,p,p,q,r,s,t,u,v,w,x,y,z" +
			//",A,B,C,D,E,F,G,H,J,J,K,L,M,N,P,P,Q,R,S,T,U,V,W,X,Y,Z";
			string[] VcArray = Vchar.Split(new Char[] { ',' });     // 拆分成數組
			string VNum = "";                                       // 產生的隨機數
			int temp = -1;                                          // 紀錄上次產生的隨機數, 避免重複

			Random rand = new Random();
			// 採用一個簡單的算法以保證生成隨機數的不同
			for (int i = 1; i < VcodeNum + 1; i++)
			{
				if (temp != -1)
				{
					// 初始化隨機數
					rand = new Random(i * temp * unchecked((int)DateTime.Now.Ticks));
				}
				int t = rand.Next(10);                              // 取得隨機數
                while (temp == t)
                {
                    // 隨機數重複時重新選取
                    t = rand.Next(10);
                }
				temp = t;                                           // 把本次產生的隨機數紀錄起來
				VNum += VcArray[t];                                 // 隨機數的位數加一
			}
			return VNum;
		}

		/// <summary>
		/// 該方法是將生成的隨機數寫入圖像文件
		/// </summary>
		/// <param name="VNum">VNum是一個隨機數</param>
		public MemoryStream Create(out string VNum)
		{
			VNum = RndNum(4);
			Bitmap Img = null;
			Graphics g = null;
			MemoryStream ms = null;
			System.Random random = new Random();
			// 驗證碼顏色集合
			Color[] c = { Color.Black, Color.Red, Color.DarkBlue, Color.Green, Color.Brown, Color.Navy, Color.DarkCyan, Color.Purple };
			// 驗證碼字體集合
			string[] fonts = { "Verdana", "Algerian", "Comic Sans MS", "Britannic Bold", "Broadway" };


			// 定義圖像的大小
			Img = new Bitmap((int)VNum.Length * 22, 24);

			g = Graphics.FromImage(Img);                            // 從 Img 生成新的 Graphic 對象

			g.Clear(Color.White);                                   // 背景設為白色

			// 再隨機位置畫背景點
			for (int i = 0; i < 300; i++)
			{
				int x = random.Next(Img.Width);
				int y = random.Next(Img.Height);
				g.DrawRectangle(new Pen(Color.LightGray, 0), x, y, 1, 1);
			}
			// 繪製驗證碼
			for (int i = 0; i < VNum.Length; i++)
			{
				int cindex = random.Next(7);                        // 隨機顏色索引值
				int findex = random.Next(5);                        // 隨機字體索引值
				// 字體
				Font f = new System.Drawing.Font(fonts[findex], 16, System.Drawing.FontStyle.Bold);
				// 顏色
				Brush b = new System.Drawing.SolidBrush(c[cindex]);
				// 繪製一個驗證字符
				g.DrawString(VNum.Substring(i, 1), f, b, 2 + (i * 20), 0);
			}
			ms = new MemoryStream();                                // 生成內存流對象
			Img.Save(ms, ImageFormat.Jpeg);                         // 將此圖像以 Png 格式保存至內存流

			// 回收資源
			g.Dispose();
			Img.Dispose();
			return ms;
		}
	}
}