﻿using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.AppUserControls.Pager
{
	[Themeable(true)]	// 必須增加此行才能使用主題
	public partial class UCPager : System.Web.UI.UserControl
	{
		#region property

		/// <summary>
		/// 是否使用多國語系。
		/// </summary>
		[DefaultValue("false"), Description("是否使用多國語系"), Category("分頁設定")]
		public bool IsLocalizable
		{
			get;
			set;
		}

		/// <summary> 
		/// 取得或設定資料總筆數，並且計算總頁數。
		/// </summary> 
		[DefaultValue(""), Description("取得或設定資料總筆數，並且計算總頁數"), Category("分頁設定")]
		public int RecordCount
		{
			get
			{
				if (ViewState["RecordCount"] == null)
				{
					ViewState["RecordCount"] = 0;
				}

				return Convert.ToInt32(ViewState["RecordCount"]);
			}

			set
			{
				ViewState["RecordCount"] = value;
				ViewState["TotalPages"] = (value / PageSize) + (value % PageSize == 0 ? 0 : 1);
			}
		}

		/// <summary>
		/// 取得或設定資料總頁數。
		/// </summary>
		[DefaultValue(""), Description("取得或設定資料總頁數"), Category("分頁設定")]
		public int TotalPages
		{
			get
			{
				if (ViewState["TotalPages"] == null)
				{
					ViewState["TotalPages"] = 0;
				}

				return Convert.ToInt32(ViewState["TotalPages"]);
			}

			set
			{
				ViewState["TotalPages"] = value;
			}
		}

		/// <summary>
		/// 取得或設定當前頁的筆數。
		/// </summary>
		[DefaultValue(""), Description("取得或設定當前頁的筆數"), Category("分頁設定")]
		public int CurrentPageRecordCount
		{
			get
			{
				if ((RecordCount - PageSize * CurrentPageNumber) >= 0)
				{
					ViewState["CurrentPageRecordCount"] = PageSize;
				}
				else
				{
					ViewState["CurrentPageRecordCount"] = RecordCount % PageSize;
				}

				return Convert.ToInt32(ViewState["CurrentPageRecordCount"]);
			}

			set
			{
				ViewState["CurrentPageRecordCount"] = value;
			}
		}

		/// <summary>
		/// 取得或設定一次顯示的頁數。
		/// </summary>
		[DefaultValue("10"), Description("取得或設定一次顯示的頁數"), Category("分頁設定")]
		public int NumberOfPages
		{
			get
			{
				if (ViewState["NumberOfPages"] == null)
				{
					ViewState["NumberOfPages"] = 10;
				}

				return Convert.ToInt32(ViewState["NumberOfPages"]);
			}

			set
			{
				ViewState["NumberOfPages"] = value;
			}
		}

		/// <summary>
		/// 取得或設定目前頁碼。
		/// </summary>
		[DefaultValue("1"), Description("取得或設定目前頁碼"), Category("分頁設定")]
		public int CurrentPageNumber
		{
			get
			{
				if (ViewState["CurrentPageNumber"] == null)
				{
					ViewState["CurrentPageNumber"] = 1;
				}

				return Convert.ToInt32(ViewState["CurrentPageNumber"]);
			}

			set
			{
				ViewState["CurrentPageNumber"] = value;
			}
		}

		/// <summary>
		/// 取得或設定每頁顯示的筆數。
		/// </summary>
		[DefaultValue("10"), Description("取得或設定每頁顯示的筆數"), Category("分頁設定")]
		public int PageSize
		{
			get
			{
				if (ViewState["PageSize"] == null)
				{
					ViewState["PageSize"] = 10;
				}

				return Convert.ToInt32(ViewState["PageSize"]);
			}

			set
			{
				ViewState["PageSize"] = value;
			}
		}

		/// <summary>
		/// 取得或設定分頁按鈕的間距。
		/// </summary>
		private Unit _SepratorSpacing = Unit.Pixel(5);
		[DefaultValue("5px"), Description("取得或設定分頁按鈕的間距"), Category("分頁設定")]
		public Unit SeparatorSpacing
		{
			get { return _SepratorSpacing; }
			set { _SepratorSpacing = value; }
		}

		/// <summary>
		/// 取得或設定 CSS 樣式。
		/// </summary>
		[DefaultValue(""), Description("取得或設定 CSS 樣式"), Category("分頁設定")]
		public string CssClass
		{
			get;
			set;
		}

		/// <summary>
		/// 取得或設定當前頁筆數及總筆數。
		/// </summary>
		private string _CurrentAndTotalRecordCountText = "{0} / {1}";
		[DefaultValue("{0} / {1}"), Description("取得或設定當前頁筆數及總筆數"), Category("按鈕文字"), Localizable(true)]
		public string CurrentAndTotalRecordCountText
		{
			get { return _CurrentAndTotalRecordCountText; }
			set { _CurrentAndTotalRecordCountText = value; }
		}

		/// <summary>
		/// 取得或設定當前頁碼及總頁數。
		/// </summary>
		private string _CurrentAndTotalPagesText = "{0} / {1}";
		[DefaultValue("{0} / {1}"), Description("取得或設定當前頁碼及總頁數"), Category("按鈕文字"), Localizable(true)]
		public string CurrentAndTotalPagesText
		{
			get { return _CurrentAndTotalPagesText; }
			set { _CurrentAndTotalPagesText = value; }
		}
		
		/// <summary>
		/// 取得或設定第一頁按鈕顯示的文字。
		/// </summary>
		private string _FirstText = "<<";
		[DefaultValue("<<"), Description("取得或設定第一頁按鈕顯示的文字"), Category("按鈕文字"), Localizable(true)]
		public string FirstText
		{
			get { return _FirstText; }
			set { _FirstText = value; }
		}

		/// <summary>
		/// 取得或設定上一頁按鈕顯示的文字。
		/// </summary>
		private string _PreviousText = "<";
		[DefaultValue("<"), Description("取得或設定上一頁按鈕顯示的文字"), Category("按鈕文字"), Localizable(true)]
		public string PreviousText
		{
			get { return _PreviousText; }
			set { _PreviousText = value; }
		}

		/// <summary>
		/// 取得或設定下一頁按鈕顯示的文字。
		/// </summary>
		private string _NextText = ">";
		[DefaultValue(">"), Description("取得或設定下一頁按鈕顯示的文字"), Category("按鈕文字"), Localizable(true)]
		public string NextText
		{
			get { return _NextText; }
			set { _NextText = value; }
		}

		/// <summary>
		/// 取得或設定最後一頁按鈕顯示的文字。
		/// </summary>
		private string _LastText = ">>";
		[DefaultValue(">>"), Description("取得或設定最後一頁按鈕的文字"), Category("按鈕文字"), Localizable(true)]
		public string LastText
		{
			get { return _LastText; }
			set { _LastText = value; }
		}

		/// <summary>S
		/// 取得或設定跳頁按鈕顯示的文字。
		/// </summary>
		private string _GoToText = "GoTo";
		[DefaultValue("GoTo"), Description("取得或設定跳頁按鈕顯示的文字"), Category("按鈕文字"), Localizable(true)]
		public string GoToText
		{
			get { return _GoToText; }
			set { _GoToText = value; }
		}

		/// <summary>
		/// 取得或設定分頁按鈕的分隔文字。
		/// </summary>
		[DefaultValue(""), Description("取得或設定分頁按鈕的分隔文字"), Category("按鈕文字"), Localizable(true)]
		public string Separator
		{
			get;
			set;
		}

		/// <summary> 
		/// 是否顯示 本頁筆數 / 總計筆數。
		/// </summary> 
		private bool _ShowCurrentAndTotalRecordCount = true;
		[DefaultValue("True"), Description("是否顯示 本頁筆數 / 總計筆數"), Category("顯示")]
		public bool ShowCurrentAndTotalRecordCount
		{
			get { return _ShowCurrentAndTotalRecordCount; }
			set { _ShowCurrentAndTotalRecordCount = value; }
		}

		/// <summary> 
		/// 是否顯示 當前頁 / 總頁數。
		/// </summary> 
		private bool _ShowCurrentAndTotalPages = true;
		[DefaultValue("True"), Description("是否顯示 當前頁 / 總頁數"), Category("顯示")]
		public bool ShowCurrentAndTotalPages
		{
			get { return _ShowCurrentAndTotalPages; }
			set { _ShowCurrentAndTotalPages = value; }
		}

		/// <summary> 
		/// 是否顯示第一頁按鈕。
		/// </summary> 
		private bool _ShowFisrt = true;
		[DefaultValue("True"), Description("是否顯示第一頁按鈕"), Category("顯示")]
		public bool ShowFirst
		{
			get { return _ShowFisrt; }
			set { _ShowFisrt = value; }
		}

		/// <summary> 
		/// 是否顯示上一頁按鈕。
		/// </summary> 
		private bool _ShowPrevious = true;
		[DefaultValue("True"), Description("是否顯示上一頁按鈕"), Category("顯示")]
		public bool ShowPrevious
		{
			get { return _ShowPrevious; }
			set { _ShowPrevious = value; }
		}

		/// <summary> 
		/// 是否顯示數字按鈕。
		/// </summary> 
		private bool _ShowNumber = true;
		[DefaultValue("True"), Description("是否顯示數字按鈕"), Category("顯示")]
		public bool ShowNumber
		{
			get { return _ShowNumber; }
			set { _ShowNumber = value; }
		}

		/// <summary> 
		/// 是否顯示下一頁按鈕。
		/// </summary> 
		private bool _ShowNext = true;
		[DefaultValue("True"), Description("是否顯示下一頁按鈕"), Category("顯示")]
		public bool ShowNext
		{
			get { return _ShowNext; }
			set { _ShowNext = value; }
		}

		/// <summary> 
		/// 是否顯示最後一頁按鈕。
		/// </summary> 
		private bool _ShowLast = true;
		[DefaultValue("True"), Description("是否顯示最後一頁按鈕"), Category("顯示")]
		public bool ShowLast
		{
			get { return _ShowLast; }
			set { _ShowLast = value; }
		}

		/// <summary>
		/// 取得或設定是否顯示下拉式頁碼。
		/// </summary>
		private bool _ShowSelectGoTo = true;
		[DefaultValue("True"), Description("取得或設定是否顯示下拉式頁碼"), Category("顯示")]
		public bool ShowSelectGoTo
		{
			get { return _ShowSelectGoTo; }
			set { _ShowSelectGoTo = value; }
		}

		/// <summary>
		/// 取得或設定是否顯示跳頁按鈕。
		/// </summary>
		private bool _ShowGoTo = true;
		[DefaultValue("True"), Description("取得或設定是否顯示跳頁按鈕"), Category("顯示")]
		public bool ShowGoTo
		{
			get { return _ShowGoTo; }
			set { _ShowGoTo = value; }
		}

		/// <summary>
		/// 取得或設定是否總是顯示。
		/// </summary>
		private bool _AlwaysShow = true;
		[DefaultValue("True"), Description("取得或設定是否總是顯示"), Category("顯示")]
		public bool AlwaysShow
		{
			get { return _AlwaysShow; }
			set { _AlwaysShow = value; }
		}

		/// <summary>
		/// 取得或設定是否自動顯示。
		/// </summary>
		private bool _AutoShow = true;
		[DefaultValue("True"), Description("取得或設定是否自動顯示"), Category("顯示")]
		public bool AutoShow
		{
			get { return _AutoShow; }
			set { _AutoShow = value; }
		}

		#endregion

		#region private

		/// <summary>
		/// 判斷是否為當前頁。
		/// </summary>
		/// <param name="pageNumber">頁數。</param>
		/// <returns>回傳布林值。</returns>
		private bool IsCurrentPage(int pageNumber)
		{
			return pageNumber == CurrentPageNumber;
		}

		/// <summary>
		/// 產生分頁連結。
		/// </summary>
		private void GenerateLinks()
		{
			//設定總是產生或筆數大於每頁顯示的筆數就顯示分頁
			if (AlwaysShow || RecordCount > PageSize)
			{
				// 檢查是否使用語系(暫時不用)
				//System.ComponentModel.AttributeCollection attributes = TypeDescriptor.GetProperties(this)["MyProperty"].Attributes;

				//LocalizableAttribute myAttribute = (LocalizableAttribute)attributes[typeof(LocalizableAttribute)];
				//if (myAttribute.IsLocalizable)
				//{
				//    // Insert code here.
				//}

				// 如果不使用語系則使用設定的屬性
				if (!IsLocalizable)
				{
					//設定按鈕文字
					lblCurrentAndTotalRecordCount.Text = string.Format(CurrentAndTotalRecordCountText, CurrentPageRecordCount, RecordCount);
					lblCurrentAndTotalPages.Text = string.Format(CurrentAndTotalPagesText, CurrentPageNumber, TotalPages);

					lnkbtnFirst.Text = FirstText;
					lnkbtnPrevious.Text = PreviousText;
					lnkbtnNext.Text = NextText;
					lnkbtnLast.Text = LastText;
					lnkbtnGoTo.Text = GoToText;
				}
				else
				{
					lblCurrentAndTotalRecordCount.Text = string.Format(GetLocalResourceObject("lblCurrentAndTotalRecordCountResource.Text").ToString(), CurrentPageRecordCount, RecordCount);
					lblCurrentAndTotalPages.Text = string.Format(GetLocalResourceObject("lblCurrentAndTotalPagesResource.Text").ToString(), CurrentPageNumber, TotalPages);
				}

				//設定 css
				pnlPagerContainer.CssClass = CssClass;

				//計算頁數範圍
				int minimum;
				int maximum;
				CalculateBoundry(NumberOfPages, TotalPages, CurrentPageNumber, out minimum, out maximum);

				//清空頁碼
				phPageNumber.Controls.Clear();

				//筆數是否大於 0
				bool dataToDisplay = TotalPages > 0;

				//筆數大於 0 並且設定顯示才產生頁碼
				if (dataToDisplay && ShowNumber)
				{
					GenerateNumberPagerLink();	//產生頁碼
				}

				//如果下拉式頁碼少於頁數而且筆數大於 0 並且設定顯示才產生下拉式頁碼
				if (dataToDisplay && ShowSelectGoTo && ddlGoTo.Items.Count != TotalPages)
				{
					ddlGoTo.Items.Clear();
					for (int i = 1; i <= TotalPages; i++)
					{
						ddlGoTo.Items.Add(i.ToString());
					}
				}

				if (!IsPostBack)
				{
					//設定下拉式頁碼
					if (dataToDisplay && ShowSelectGoTo)
					{
						ddlGoTo.SelectedValue = ddlGoTo.Items.FindByValue(CurrentPageNumber.ToString()).ToString();
					}

					//設定跳頁頁碼
					txtGoTo.Text = CurrentPageNumber.ToString();
				}

				//設定跳頁頁碼可輸入的長度
				txtGoTo.MaxLength = TotalPages.ToString().Length;

				//筆數大於 0 才產生控制項
				lblCurrentAndTotalPages.Visible = dataToDisplay;
				lnkbtnFirst.Visible = dataToDisplay;
				lnkbtnPrevious.Visible = dataToDisplay;
				lnkbtnNext.Visible = dataToDisplay;
				lnkbtnLast.Visible = dataToDisplay;
				ddlGoTo.Visible = dataToDisplay;
				lnkbtnGoTo.Visible = dataToDisplay;
				txtGoTo.Visible = dataToDisplay;

				//設定顯示才產生控制項
				lblCurrentAndTotalPages.Visible = ShowCurrentAndTotalPages;
				lnkbtnFirst.Visible = ShowFirst;
				lnkbtnPrevious.Visible = ShowPrevious;
				lnkbtnNext.Visible = ShowNext;
				lnkbtnLast.Visible = ShowLast;
				ddlGoTo.Visible = ShowSelectGoTo;
				txtGoTo.Visible = ShowGoTo;
				lnkbtnGoTo.Visible = ShowGoTo;

				if (AutoShow)
				{
					//如果在第一頁則第一頁和上一頁設定不能顯示
					lnkbtnFirst.Visible = !(CurrentPageNumber <= 1);
					lnkbtnPrevious.Visible = !(CurrentPageNumber <= 1);

					//如果在最後一頁則下一頁和最後一頁設定不能顯示
					lnkbtnNext.Visible = !(CurrentPageNumber >= TotalPages);
					lnkbtnLast.Visible = !(CurrentPageNumber >= TotalPages);
				}
				else
				{
					//如果在第一頁則第一頁和上一頁設定不能點選
					lnkbtnFirst.Enabled = !(CurrentPageNumber <= 1);
					lnkbtnPrevious.Enabled = !(CurrentPageNumber <= 1);

					//如果在最後一頁則下一頁和最後一頁設定不能點選
					lnkbtnNext.Enabled = !(CurrentPageNumber >= TotalPages);
					lnkbtnLast.Enabled = !(CurrentPageNumber >= TotalPages);
				}

				//設定間距
				string marginPx = (float.Parse(SeparatorSpacing.ToString().Replace("px", "")) / 2) + "px";
				lblCurrentAndTotalPages.Style.Add("margin", "auto " + marginPx);
				lnkbtnFirst.Style.Add("margin", "auto " + marginPx);
				lnkbtnPrevious.Style.Add("margin", "auto " + marginPx);
				lnkbtnNext.Style.Add("margin", "auto " + marginPx);
				lnkbtnLast.Style.Add("margin", "auto " + marginPx);
				ddlGoTo.Style.Add("margin", "auto " + marginPx);
				txtGoTo.Style.Add("margin-left", marginPx);
				lnkbtnGoTo.Style.Add("margin-right", marginPx);

				pnlPagerContainer.Visible = true;
			}
			else
			{
				pnlPagerContainer.Visible = false;
			}
		}

		/// <summary>
		/// 計算範圍。
		/// </summary>
		/// <param name="maximumPages">顯示的最大頁數。</param>
		/// <param name="totalPages">全部的頁數。</param>
		/// <param name="currentPage">當前頁碼。</param>
		/// <param name="lowerBound">回傳範圍最小值。</param>
		/// <param name="upperBound">回傳範圍最大值。</param>
		private static void CalculateBoundry(int maximumPages, int totalPages, int currentPage, out int lowerBound, out int upperBound)
		{
			if (totalPages < maximumPages)
			{
				lowerBound = 1;
				upperBound = totalPages;
			}
			else
			{
				int rightDisplay = maximumPages / 2;
				int leftDisplay = maximumPages - rightDisplay;

				lowerBound = currentPage - leftDisplay; //取得起始頁碼
				int lowerOffset = 0 - lowerBound; //計算當前頁碼的左邊是否有足夠的位置，lowerOffset 表示不夠的數量

				upperBound = currentPage + rightDisplay + (lowerOffset > 0 ? lowerOffset : 0); //取得結束頁碼，如果左邊位置不夠，則用結束頁碼加上不夠的數量
				int upperOffset = upperBound > totalPages ? upperBound - totalPages : 0;
				upperBound = (totalPages - upperBound) > 0 ? upperBound : totalPages;

				lowerBound = lowerBound > 0 ? (lowerBound + lowerBound > upperOffset ? lowerBound - upperOffset + 1 : 1) : 1;
			}
		}

		/// <summary>
		/// 產生數字頁碼。
		/// </summary>
		private void GenerateNumberPagerLink()
		{
			int minimum = 0;
			int maximum = 0;
			CalculateBoundry(NumberOfPages, TotalPages, CurrentPageNumber, out minimum, out maximum);

			LinkButton lnkbtn;
			Label lbl;

			for (int i = minimum; i <= maximum; i++)
			{
				lnkbtn = new LinkButton();
				lnkbtn.ID = "linkbtnNumber" + i.ToString();
				lnkbtn.Text = i.ToString();
				//lnkbtn.Enabled = !IsCurrentPage(i);
				lnkbtn.OnClientClick = "return " + (!IsCurrentPage(i)).ToString().ToLower();
				if (IsCurrentPage(i))
				{
					lnkbtn.CssClass = "current";	//當前頁加入 current class
				}
				lnkbtn.Style.Add("margin", "auto " + (float.Parse(SeparatorSpacing.ToString().Replace("px", "")) / 2) + "px");
				lnkbtn.Click += new EventHandler(this.lnkbtnNumber_Click);
				phPageNumber.Controls.Add(lnkbtn);

				//加入分隔文字，最後一個不加
				if (i < maximum)
				{
					lbl = new Label();
					lbl.Text = Separator;

					phPageNumber.Controls.Add(lbl);
				}
			}
		}

		#endregion

		#region protected

		/// <summary>
		/// 初始化。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Page_Init(object sender, EventArgs e)
		{
			// GenerateLinks();	
		}

		/// <summary>
		/// 初始化。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Page_Load(object sender, EventArgs e)
		{
			// 屬性在 Load 才會讀進來
			GenerateLinks();
		}

		/// <summary>
		/// 頁面改變。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Page_Change(object sender, PagerEventArgs e)
		{
			Change(sender, e);

			if (ShowSelectGoTo)
			{
				ddlGoTo.SelectedValue = ddlGoTo.Items.FindByValue(CurrentPageNumber.ToString()).ToString();
			}

			if (ShowGoTo)
			{
				txtGoTo.Text = CurrentPageNumber.ToString();
			}

			// GenerateLinks();
		}		

		#region 按鈕事件

		/// <summary>
		/// 第一頁按鈕事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lnkbtnFirst_Click(object sender, EventArgs e)
		{
			CurrentPageNumber = 1;

			if (Change != null)
			{
				PagerEventArgs args = new PagerEventArgs();
				Page_Change(this, args);
			}
		}

		/// <summary>
		/// 上一頁按鈕事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lnkbtnPrevious_Click(object sender, EventArgs e)
		{
			CurrentPageNumber--;

			if (Change != null)
			{
				PagerEventArgs args = new PagerEventArgs();
				Page_Change(this, args);
			}
		}

		/// <summary>
		/// 數字按鈕事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lnkbtnNumber_Click(object sender, EventArgs e)
		{
			int number = Convert.ToInt32(((LinkButton)sender).Text);
			CurrentPageNumber = number;

			if (Change != null)
			{
				PagerEventArgs args = new PagerEventArgs();
				Page_Change(this, args);
			}
		}

		/// <summary>
		/// 下一頁按鈕事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lnkbtnNext_Click(object sender, EventArgs e)
		{
			CurrentPageNumber++;
			
			if (Change != null)
			{
				PagerEventArgs args = new PagerEventArgs();
				Page_Change(this, args);
			}
		}

		/// <summary>
		/// 最後一頁按鈕事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lnkbtnLast_Click(object sender, EventArgs e)
		{
			CurrentPageNumber = TotalPages;
			
			if (Change != null)
			{
				PagerEventArgs args = new PagerEventArgs();
				Page_Change(this, args);
			}
		}

		/// <summary>
		/// 選擇跳頁事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ddlGoTo_SelectedIndexChanged(object sender, EventArgs e)
		{
			int number;
			if (int.TryParse(ddlGoTo.SelectedItem.Value, out number))
			{
				if (number <= TotalPages && number > 0)
				{
					CurrentPageNumber = number;
				}
			}

			if (Change != null)
			{
				PagerEventArgs args = new PagerEventArgs();
				Page_Change(this, args);
			}
		}

		/// <summary>
		/// 跳頁按鈕事件。
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void lnkbtnGoTo_Click(object sender, EventArgs e)
		{
			int number;
			if (int.TryParse(txtGoTo.Text, out number))
			{
				if (number <= TotalPages && number > 0)
				{
					CurrentPageNumber = number;
				}
			}

			if (Change != null)
			{
				PagerEventArgs args = new PagerEventArgs();
				Page_Change(this, args);
			}
		}

		#endregion

		#endregion
		
		#region public
		
		/// <summary>
		/// 將資料來源繫結至 Pager。
		/// </summary>
		public override void DataBind()
		{
			GenerateLinks();

			if (ShowSelectGoTo)
			{
				if (ddlGoTo.Items.Count > 0)
				{
					ddlGoTo.SelectedValue = ddlGoTo.Items.FindByValue(CurrentPageNumber.ToString()).ToString();
				}
			}

			if (ShowGoTo)
			{
				txtGoTo.Text = CurrentPageNumber.ToString();
			}			
		}
		
		#endregion

		#region even

		public class PagerEventArgs : EventArgs
		{
		}

		/// <summary>
		/// 建立事件。
		/// </summary>
		public event EventHandler<PagerEventArgs> Change;

		#endregion
	}
}