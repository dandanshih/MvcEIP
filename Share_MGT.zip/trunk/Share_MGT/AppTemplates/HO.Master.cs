﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.AppTemplates
{
	public partial class HO : Share_MGT.AppLibs.MPBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
#if (Debug)
            Page.Header.Title = Page.Config.Global.ProjectDescription + " (Debug in " + Page.DBConn.DataSource + ")";
#endif
			// 操作者帳號
            lit_User.Text = string.Format("{0} Login {1}", AUser.ExecAgentGroupID, AUser.ExecAgentAccount);

            if (AUser.IsShadowAccount)
            {
                lit_User.Text += "（" + AUser.AgentAccount + "）";
            }
		}

		/// <summary>
		/// 用來傳回開發時的路徑用
		/// </summary>
		public string BaseURL
		{
			get
			{
				try
				{
					return string.Format("http://{0}{1}",
										 HttpContext.Current.Request.ServerVariables["HTTP_HOST"],
										 (VirtualFolder.Equals("/")) ? string.Empty : VirtualFolder);
				}
				catch
				{
					// This is for design time
					return null;
				}
			}
		}

		/// <summary>
		/// Returns the name of the virtual folder where our project lives
		/// </summary>
		private static string VirtualFolder
		{
			get { return HttpContext.Current.Request.ApplicationPath; }
		}

		/// <summary>
		/// 持續更新使用者活動時間。
		/// </summary>
		protected void KeepOnline(object sender, EventArgs e)
		{
			// 如果有登入才動作
			if (Page.User.IsLogon)
			{
                if (!AgentUtility.KeepOnline(Page.User.OnlineID))
				{
					// 登出
					Response.Redirect("~/Logout.aspx");
				}
			}
		}
	}
}