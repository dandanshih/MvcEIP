﻿
function checkThreeStateCheckBox(isEnable, img, hdn) {
    if (isEnable == 'False')
        return false;

    var imgGrant = '/AppUserControls/Other/Grant.gif';
    var imgDeny = '/AppUserControls/Other/Deny.gif';
    var imgRevoke = '/AppUserControls/Other/Revoke.gif';

    var objHdn = document.getElementById(hdn);
    switch (objHdn.value) {
        case 'Revoke':
            img.src = imgGrant;
            objHdn.value = 'Grant';
            break;
        case 'Grant':
            img.src = imgDeny;
            objHdn.value = 'Deny';
            break;
        default:
            img.src = imgRevoke;
            objHdn.value = 'Revoke';
            break;
    }
}