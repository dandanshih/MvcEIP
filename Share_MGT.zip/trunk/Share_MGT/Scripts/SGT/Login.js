﻿/// <reference path="jquery.d.ts" />
// Module
var SGT;
(function (SGT) {
    // Class
    var LoginKeyboard = (function () {
        function LoginKeyboard() {
            // Set Focus Control
            $("#txtAccount, #txtPassword, #txtVerifyCode").focus($.proxy(function (e) {
                this.FocusObj = $(e.target);
            }, this));

            $("#txtAccount").focus();

            // 畫鍵盤
            this.drawKeyboard();
        }
        LoginKeyboard.prototype.drawKeyboard = function () {
            // 找出 asp.net 的 loginButton
            var btnLogin = $(".btnLogin");

            // 畫數字鍵盤
            this.draw(btnLogin, "1,2,3,4,5,6,7,8,9,0".split(",").sort(this.randOrd));

            // 畫英文鍵盤
            this.draw(btnLogin, "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z".split(",").sort(this.randOrd));

            // 畫倒退鍵
            $("<div class='btnBack' value='backspace'>←</div>").insertBefore(btnLogin);

            // 挷定事件
            this.bindEvent();
        };

        LoginKeyboard.prototype.draw = function (obj, keys) {
            for (var i in keys) {
                $("<div class='btnKey' value='" + keys[i] + "'>" + keys[i] + "</div>").insertBefore(obj);
            }
            ;
        };

        LoginKeyboard.prototype.randOrd = function () {
            return (Math.round(Math.random()) - 0.5);
        };

        LoginKeyboard.prototype.bindEvent = function () {
            $(".btnKey, .btnBack").click($.proxy(function (e) {
                // 取得所按的按鍵
                var str = $(e.target).attr("value");
                var obj = this.FocusObj;

                if (str == "backspace") {
                    if (obj.selection() == "") {
                        var selection = obj.selection("getPos");
                        obj.selection("setPos", {
                            start: selection.start - 1,
                            end: selection.end
                        });
                    }
                    ;
                    obj.selection("replace", { text: "", caret: "end" });
                } else {
                    if (obj.val().length < obj.attr("maxlength") || obj.selection() != "") {
                        obj.selection("replace", { text: str, caret: "end" });
                    }
                }
                ;

                obj.focus();
            }, this));
        };
        return LoginKeyboard;
    })();
    SGT.LoginKeyboard = LoginKeyboard;
})(SGT || (SGT = {}));

// Local variables
var login = new SGT.LoginKeyboard();
