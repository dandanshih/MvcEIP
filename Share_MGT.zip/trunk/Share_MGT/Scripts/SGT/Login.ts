﻿/// <reference path="jquery.d.ts" />

// Module
module SGT {

    // Class
    export class LoginKeyboard {

        private FocusObj;

        constructor() {

            // Set Focus Control
            $("#txtAccount, #txtPassword, #txtVerifyCode").focus($.proxy(function (e: JQueryEventObject) {
                this.FocusObj = $(e.target);
            }, this));

            $("#txtAccount").focus();

            // 畫鍵盤
            this.drawKeyboard();
        }

        private drawKeyboard() {
            // 找出 asp.net 的 loginButton
            var btnLogin: JQuery = $(".btnLogin");

            // 畫數字鍵盤
            this.draw(btnLogin, "1,2,3,4,5,6,7,8,9,0".split(",").sort(this.randOrd));
            // 畫英文鍵盤
            this.draw(btnLogin, "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z".split(",").sort(this.randOrd));
            // 畫倒退鍵
            $("<div class='btnBack' value='backspace'>←</div>").insertBefore(btnLogin);
            // 挷定事件
            this.bindEvent();
        }

        private draw(obj: JQuery, keys: string[]) {            
            for (var i in keys) {
                $("<div class='btnKey' value='" + keys[i] + "'>" + keys[i] + "</div>").insertBefore(obj);
            };
        }

        private randOrd() {
            return (Math.round(Math.random()) - 0.5);
        }

        private bindEvent() {
            $(".btnKey, .btnBack").click($.proxy(function (e: JQueryEventObject) {
                // 取得所按的按鍵
                var str: string = $(e.target).attr("value");
                var obj = this.FocusObj;

                // 倒退鍵
                if (str == "backspace") {
                    if (obj.selection() == "") {
                        var selection = obj.selection("getPos");
                        obj.selection("setPos", {
                            start: selection.start - 1, end: selection.end
                        });
                    };
                    obj.selection("replace", { text: "", caret: "end" });
                }
                // 其他按鍵 0~9 a~z
                else {
                    if (obj.val().length < obj.attr("maxlength") || obj.selection() != "") {
                        obj.selection("replace", { text: str, caret: "end" });
                    }
                };

                obj.focus();
            }, this));
        }
    }
}

// Local variables
var login = new SGT.LoginKeyboard();
