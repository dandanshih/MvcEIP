﻿/// <reference path="~/scripts/jquery-1.4.1-vsdoc.js" />

//jQuery.fn.webutility({
//	clearfield: function() {
//		$("input[type=text]").each(function(e) {
//			$(this).val("");
//		});
//		
//		$("input[type=password]").each(function(e) {
//			$(this).val("");
//		});

//		$("textarea").each(function(e) {
//			$(this).val("");
//		});
//	}
//});

$(function () {
	RadioSearch();
})

function RadioSearch() {
    $('.radioSearch input[type=radio]:checked ~ input[type=text]').attr("disabled", false);
	$('.radioSearch input[type=radio]:not(:checked) ~ input[type=text]').attr("disabled", true).val("");
	
	$('.radioSearch input[type=radio]').bind("click", function (e) {
        $('.radioSearch input[type=radio]:checked ~ input[type=text]').attr("disabled", false);
        $('.radioSearch input[type=radio]:not(:checked) ~ input[type=text]').attr("disabled", true).val("");
    });

//	var index = $('.radioSearch input[type=radio]').index($('.radioSearch input[type=radio]:checked'));
//	
//	if (index == -1) {
//		$('.radioSearch input[type=text]').attr("disabled", true);
//	}
//	else {
//		$('.radioSearch input[type=text]:eq(' + index + ')').attr("disabled", false);
//		$('.radioSearch input[type=text]:not(:eq(' + index + '))').attr("disabled", true);
//		$('.radioSearch input[type=text]:not(:eq(' + index + '))').val("");
//	}

//	$('.radioSearch input[type=radio]').bind("click", function (e) {
//		var index = $('.radioSearch input[type=radio]').index($('.radioSearch input[type=radio]:checked'));		
//		$('.radioSearch input[type=text]:eq(' + index + ')').attr("disabled", false);
//		$('.radioSearch input[type=text]:not(:eq(' + index + '))').attr("disabled", true);
//		$('.radioSearch input[type=text]:not(:eq(' + index + '))').val("");
//	});
}

//清空輸入欄位
function ClearField() {
	$("input[type=text]").each(function(e) {
		$(this).val("");
	});

	$("input[type=password]").each(function(e) {
		$(this).val("");
	});

	$("input[type=file]").each(function(e) {
		$(this).val("");
	});

	$("input[type=radio]").each(function(e) {
		$(this).attr("checked",false);
	});

	$("input[type=checkbox]").each(function(e) {
		$(this).attr("checked", false);
	});

	$("select").each(function(e) {
		$(this).get(0).selectedIndex = 0;
	});

	$("textarea").each(function(e) {
		$(this).val("");
	});
	return false;
}

//傳參數至 WebService
function WebService(webserviceUrlAndFunction, parms) {
	$.ajax({
		type: "POST",
		url: webserviceUrlAndFunction, //WebService的url與方法
		data: parms,
		//contentType: "application/json; charset=utf-8",
		dataType: "text",
		success: function(msg) {
			//var data =  eval("("+msg+")");
			alert(msg); //檢查用
		},
		error: function(msg) {
			alert("error");
		}
	});
}

// 自動符合視窗大小
function ResizeWindow() {
	window.resizeTo(parseInt($('#win').width()) + parseInt(50), parseInt($('#win').height()) + parseInt(110));
}

function OneClick(ctl, val) {
    // 如果頁面上 有驗證控制項的話，先確認是否已驗證通過
    if (typeof Page_ClientValidate == "function") {
        if (Page_ClientValidate()) {
            ctl.disabled = 'disabled';
            ctl.value = val;
        }
    } else {
        ctl.disabled = 'disabled';
        ctl.value = val;
    }
}