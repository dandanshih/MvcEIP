﻿using System;

namespace Share_MGT
{
	public partial class Index : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}