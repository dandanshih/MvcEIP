﻿using System;
using System.Data;
using System.IO;
using System.Web;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;



public class NPOIRender
{
    /// <summary>
    /// 產生會員生日查詢結果
    /// </summary>
    /// <param name="dt">資料表</param>
    /// <param name="startDate">查詢起始時間</param>
    /// <param name="endDate">查詢截止時間</param>
    /// <param name="tableName">資料表名稱</param>
    /// <returns></returns>
    public static Stream ExportMemberBirthdayQueryToEXcel(DataTable dt,string startDate,string endDate,string tableName)
    {
        MemoryStream ms = new MemoryStream();
        HSSFWorkbook wbk = new HSSFWorkbook();
        Sheet sht = wbk.CreateSheet(tableName);
        Row row;
        
        
        row = sht.CreateRow(0);
        row.CreateCell(0, CellType.STRING).SetCellValue("查詢生日區間：" + startDate + "起 至" + endDate + "止");

        #region 欄位名稱
        row = sht.CreateRow(sht.LastRowNum + 1);
        foreach (DataColumn dc in dt.Columns)
        {
            row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
        }
        #endregion 欄位名稱

        #region 資料
        foreach (DataRow dr in dt.Rows)
        {
            row = sht.CreateRow(sht.LastRowNum + 1);
            foreach (DataColumn dc in dt.Columns)
            {
				if (dc.ColumnName == "Point" || dc.ColumnName == "BonusPoint" || dc.ColumnName == "AllCount" || dc.ColumnName == "AllBonusPoint")
				{
					row.CreateCell(dc.Ordinal).SetCellValue(string.Format("{0:N0}", dr[dc]));
				}
				else
				{
					row.CreateCell(dc.Ordinal).SetCellValue(dr[dc].ToString());
				}
            }
        }
        #endregion 資料

        sht.AddMergedRegion(new CellRangeAddress(0, 0, 0, dt.Columns.Count - 1));       //第一列合併儲存格

        wbk.Write(ms);
        ms.Flush();
        ms.Position = 0;

        wbk = null;
        sht = null;

        

        return ms;

    }

	/// <summary>
	/// 將DataTable匯出成EXCEL
	/// </summary>
	/// <param name="dt">需要匯出的DATABLLE</param>
	/// <param name="rp">呼叫頁面的HTTP Response</param>
	/// <returns></returns>
	public static void ExportDataTableToEXcel(DataTable dt,HttpResponse rp)
	{
		MemoryStream ms = new MemoryStream();
		HSSFWorkbook wbk = new HSSFWorkbook();
		Sheet sht = wbk.CreateSheet(dt.TableName);
		Row row;


		#region 欄位名稱
		row = sht.CreateRow(sht.LastRowNum + 1);
		foreach (DataColumn dc in dt.Columns)
		{
			row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
		}
		#endregion 欄位名稱

		#region 資料
		Int32 cntRow = 1;
		foreach (DataRow dr in dt.Rows)
		{
			row = sht.CreateRow(sht.LastRowNum + 1);
			foreach (DataColumn dc in dt.Columns)
			{
				row.CreateCell(dc.Ordinal).SetCellValue(dr[dc].ToString());
			}
			
			if (cntRow == 65535)//如果資料筆數超過EXCEL的限制，就新開一分頁
			{
				wbk.Write(ms);
				ms.Flush();
				ms.Position = 0;

				sht = null;
				sht = wbk.CreateSheet(string.Format("{0}-分頁{1}", dt.TableName, wbk.NumberOfSheets + 1));
				cntRow = 1;
			}
			cntRow++;
		}
		#endregion 資料



		wbk.Write(ms);
		ms.Flush();
		ms.Position = 0;

		wbk = null;
		sht = null;


		// 設定強制下載標頭。
		string fileName = "ExportEXCELData" + DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss") + ".xls";
		rp.AddHeader("Content-Disposition", string.Format("attachment; filename=" + fileName));
		// 輸出檔案。
		rp.BinaryWrite(ms.ToArray());
		rp.End();
		ms.Close();
		ms.Dispose();

		//return ms;

	}
	/// <summary>
	/// 匯出會員回籠資料
	/// </summary>
	/// <param name="dt">來源資料表</param>
	/// <param name="tableName">資料表名稱</param>
	/// <returns></returns>
	public static Stream ExportMemberRetentionFilterToEXcel(DataTable dt, string tableName)
	{
		MemoryStream ms = new MemoryStream();
		HSSFWorkbook wbk = new HSSFWorkbook();
		Sheet sht = wbk.CreateSheet(tableName);
		Row row;




		#region 欄位名稱
		row = sht.CreateRow(sht.LastRowNum + 1);
		foreach (DataColumn dc in dt.Columns)
		{
			row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
		}
		#endregion 欄位名稱

		#region 資料
		foreach (DataRow dr in dt.Rows)
		{
			row = sht.CreateRow(sht.LastRowNum + 1);
			foreach (DataColumn dc in dt.Columns)
			{
				row.CreateCell(dc.Ordinal).SetCellValue(dr[dc].ToString());
			}
		}
		#endregion 資料

		

		wbk.Write(ms);
		ms.Flush();
		ms.Position = 0;

		wbk = null;
		sht = null;



		return ms;

	}

	/// <summary>
	/// 匯出會員IP比對帳號查詢資料
	/// </summary>
	/// <param name="ds"></param>
	/// <param name="tableName"></param>
	/// <returns></returns>
	public static Stream ExportMemberIPComparisonToEXcel(DataSet ds)
	{
		MemoryStream ms = new MemoryStream();
		HSSFWorkbook wbk = new HSSFWorkbook();

		foreach (DataTable dt in ds.Tables)
		{
			Sheet sht = wbk.CreateSheet(dt.TableName);
			Row row;




			#region 欄位名稱
			row = sht.CreateRow(sht.LastRowNum + 1);
			foreach (DataColumn dc in dt.Columns)
			{
				row.CreateCell(dc.Ordinal).SetCellValue(dc.Caption);
			}
			#endregion 欄位名稱

			#region 資料
			foreach (DataRow dr in dt.Rows)
			{
				row = sht.CreateRow(sht.LastRowNum + 1);
				foreach (DataColumn dc in dt.Columns)
				{
					row.CreateCell(dc.Ordinal).SetCellValue(dr[dc].ToString());
				}
			}
			#endregion 資料



			wbk.Write(ms);
			ms.Flush();
			ms.Position = 0;

			sht = null;
		}


		
		wbk = null;
		



		return ms;

	}

	public static MemoryStream RenderDataTableToExcel(DataTable SourceTable)
	{
		HSSFWorkbook workbook = new HSSFWorkbook();
		MemoryStream ms = new MemoryStream();
		Sheet sheet = workbook.CreateSheet("Sheet1");
		Row headerRow = sheet.CreateRow(0);


		// handling header.
		foreach (DataColumn column in SourceTable.Columns)
			headerRow.CreateCell(column.Ordinal).SetCellValue(column.ColumnName);

		// handling value.
		int rowIndex = 1;

		foreach (DataRow row in SourceTable.Rows)
		{
			Row dataRow = sheet.CreateRow(rowIndex);

			foreach (DataColumn column in SourceTable.Columns)
			{
				dataRow.CreateCell(column.Ordinal).SetCellValue(row[column].ToString());
			}

			rowIndex++;
		}

		workbook.Write(ms);
		ms.Flush();
		ms.Position = 0;

		sheet = null;
		headerRow = null;
		workbook = null;

		return ms;
	}

	public static void RenderDataTableToExcel(DataTable SourceTable, string FileName)
	{
		MemoryStream ms = RenderDataTableToExcel(SourceTable) as MemoryStream;
		FileStream fs = new FileStream(FileName, FileMode.Create, FileAccess.Write);
		byte[] data = ms.ToArray();

		fs.Write(data, 0, data.Length);
		fs.Flush();
		fs.Close();

		data = null;
		ms = null;
		fs = null;
	}

	public static DataTable RenderDataTableFromExcel(Stream ExcelFileStream, string SheetName, int HeaderRowIndex)
	{
		HSSFWorkbook workbook = new HSSFWorkbook(ExcelFileStream);
		Sheet sheet = workbook.GetSheet(SheetName);

		DataTable table = new DataTable();

		Row headerRow = sheet.GetRow(HeaderRowIndex);
		int cellCount = headerRow.LastCellNum;

		for (int i = headerRow.FirstCellNum; i < cellCount; i++)
		{
			DataColumn column = new DataColumn(headerRow.GetCell(i).StringCellValue);
			table.Columns.Add(column);
		}

		int rowCount = sheet.LastRowNum;

		for (int i = (sheet.FirstRowNum + 1); i < sheet.LastRowNum; i++)
		{
			Row row = sheet.GetRow(i);
			DataRow dataRow = table.NewRow();

			for (int j = row.FirstCellNum; j < cellCount; j++)
				dataRow[j] = row.GetCell(j).ToString();
		}

		ExcelFileStream.Close();
		workbook = null;
		sheet = null;
		return table;
	}

	public static DataTable RenderDataTableFromExcel(Stream ExcelFileStream, int SheetIndex, int HeaderRowIndex)
	{
		HSSFWorkbook workbook = new HSSFWorkbook(ExcelFileStream);
		Sheet sheet = workbook.GetSheetAt(SheetIndex);

		DataTable table = new DataTable();

		Row headerRow = sheet.GetRow(HeaderRowIndex);
		int cellCount = headerRow.LastCellNum;

		for (int i = headerRow.FirstCellNum; i < cellCount; i++)
		{
			DataColumn column = new DataColumn(headerRow.GetCell(i).StringCellValue);
			table.Columns.Add(column);
		}

		int rowCount = sheet.LastRowNum;

		for (int i = (sheet.FirstRowNum + 1); i < sheet.LastRowNum; i++)
		{
			Row row = sheet.GetRow(i);
			DataRow dataRow = table.NewRow();

			for (int j = row.FirstCellNum; j < cellCount; j++)
			{
				if (row.GetCell(j) != null)
					dataRow[j] = row.GetCell(j).ToString();
			}

			table.Rows.Add(dataRow);
		}

		ExcelFileStream.Close();
		workbook = null;
		sheet = null;
		return table;
	}
}