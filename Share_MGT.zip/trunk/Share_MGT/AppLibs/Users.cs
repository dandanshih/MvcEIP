﻿using System;

namespace Share_MGT
{
	/// <summary>
	/// 網站中 MUser 的 Info 
	/// </summary>
	[Serializable]
	public class AUser : IDisposable
	{
		#region property

		/// <summary>
		/// 是否登入。
		/// </summary>
		public bool IsLogin { get; set; }
		/// <summary>
		/// // 網站編號。
		/// </summary>
		public string SHID { get; set; }
		/// <summary>
		/// 上線的主帳號 ID。
		/// </summary>
		public string AgentID { get; set; }
		/// <summary>
		/// 上線的主帳號。
		/// </summary>
		public string AgentAccount { get; set; }
		/// <summary>
		/// 上線的主帳號暱稱。
		/// </summary>
		public string AgentNickName { get; set; }
		/// <summary>
		/// 上線的主帳號群組 ID。
		/// </summary>
		public string AgentGroupID { get; set; }
		/// <summary>
		/// 上線的實際帳號 ID。
		/// </summary>
		public string ExecAgentID { get; set; }
		/// <summary>
		/// 上線的實際帳號。
		/// </summary>
		public string ExecAgentAccount { get; set; }
		/// <summary>
		/// 上線的實際帳號暱稱。
		/// </summary>
		public string ExecAgentNickName { get; set; }
		/// <summary>
		/// 上線的實際帳號群組 ID。
		/// </summary>
		public string ExecAgentGroupID { get; set; }
		/// <summary>
		/// 上線的 ID。
		/// </summary>
		public string OnlineID { get; set; }
		/// <summary>
		/// 預設開啟的首頁。
		/// </summary>
		public string DefaultWebPage { get; set; }
		/// <summary>
		/// FrontServerIP
		/// </summary>
		public string FrontServerIP { get; set; }
		/// <summary>
		/// 階層群組英文名稱。
		/// </summary>
		public string GroupEName { get; set; }
		/// <summary>
		/// 是否為網站管理者。
		/// </summary>
		public bool IsWebAdmin { get; set; }
		/// <summary>
		/// 是否為子帳號。
		/// </summary>
		public bool IsShadowAccount { get; set; }
		/// <summary>
		/// 調閱室權限(1:RD 2:客服 3:玩家)。
		/// </summary>
		public int ReviewAuthority { get; set; }
		/// <summary>
		/// 來源頁面名稱(給SiteMap記住轉頁後的路徑)
		/// </summary>
		public string SourcePage { get; set; }

		#endregion

        public void Dispose()
        {
            
        }
    }
}
