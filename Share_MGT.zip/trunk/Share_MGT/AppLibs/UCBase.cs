﻿using System;

namespace Share_MGT.AppLibs
{
	public class UCBase : GFC.Web.UserControlBase
	{
		protected AUser AUser;

		protected override void OnLoad(EventArgs e)
		{
			AUser = (AUser)Session["AUser"];

			base.OnLoad(e);
		}
	}
}