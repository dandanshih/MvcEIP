﻿using System;
using System.Configuration;
using System.Net.Sockets;

namespace Share_MGT.AppLibs
{
	public class WebConfig
	{
        // 連線字串
        public static string ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ToString();
        public static string SysConnectionString = ConfigurationManager.ConnectionStrings["SysConnectionString"].ToString();
        public static string WinloselogConnectionString = ConfigurationManager.ConnectionStrings["WinloselogConnectionString"].ToString();
        public static string SMSDB = ConfigurationManager.ConnectionStrings["SMSDB"].ToString();

        // Common
        public static string CSEmail = ConfigurationManager.AppSettings["CSEmail"].ToString();

        // 環境別
        public static string Domain = ConfigurationManager.AppSettings["Domain"].ToString();
        public static string GameWebDomain = "http://" + ConfigurationManager.AppSettings["GameWebDomain"].ToString();
        public static string LogWebDomain = ConfigurationManager.AppSettings["LogWebDomain"].ToString();
        public static string DataInfoUrl = "http://" + ConfigurationManager.AppSettings["DataInfoUrl"].ToString();
        public static string GameReviewUrl = ConfigurationManager.AppSettings["GameReviewUrl"].ToString();
        public static string SeriesUrl = ConfigurationManager.AppSettings["SeriesUrl"];
        public static string PlatformID = ConfigurationManager.AppSettings["PlatformID"];
        public static string IsAllowQueryAgent = ConfigurationManager.AppSettings["IsAllowQueryAgent"];

        public static string QueryMonth = ConfigurationManager.AppSettings["QueryMonth"];
	}
}