﻿
namespace Share_MGT.AppLibs
{
    public delegate void ResultHandle(object sender, ResultStruct result);

    public struct ResultStruct
    {
        public int Code;
        public string Message;
    }
}