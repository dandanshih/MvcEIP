﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Sockets;
using System.Text;
using GFC.Utilities;

namespace Share_MGT.AppLibs
{
	public enum ServerType
	{
		FrontServer,
		IMServer
	}

	public class ServerInfo
	{
		/// <summary>
		/// Server種類
		/// </summary>
		public ServerType ServerType { get; set; }

		/// <summary>
		/// Server IP
		/// </summary>
		public string IP { get; set; }

		/// <summary>
		/// Server Port
		/// </summary>
		public int Port { get; set; }

		/// <summary>
		/// 發送之指令
		/// </summary>
		public string Command { get; set; }

		/// <summary>
		/// 發送使用之編碼
		/// </summary>
		public Encoding SendEncoding { get; set; }

		/// <summary>
		/// 接收使用之編碼
		/// </summary>
		public Encoding ReceiveEncoding { get; set; }
	}

	public static class CommonUtility
	{
		public static ServerInfo GetIMServerInfo()
		{
			ServerInfo SInfo = new ServerInfo();
			SInfo.ServerType = ServerType.IMServer;
			SInfo.SendEncoding = Encoding.UTF8;
			SInfo.ReceiveEncoding = Encoding.UTF8;
			SqlDataReader sdr = SqlHelper.ExecuteReader
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_S_GetIMSysInfoData",
				new SqlParameter("@IMID", "0")
			);
			if (sdr.Read())
			{
				SInfo.IP = sdr["MGTConnIP"].ToString();
				SInfo.Port = Convert.ToInt32(sdr["MGTConnPort"]);
			}
			return SInfo;
		}

		/// <summary>
		/// 呼叫 Server 並傳送指令。
		/// </summary>
		/// <param name="frontServerIP">FrontServerIP</param>
		/// <param name="command">封包指令。(例如 7&288&0&95&10&11&12&13&)</param>
		/// <returns></returns>
		public static string SendInfoToServer(ServerInfo SInfo)
		{
			Encoding SendCharacter = SInfo.SendEncoding;
			string SendStr = SInfo.Command;
			byte[] byteget = SendCharacter.GetBytes(SendStr);

			// 使用 ASCII 碼 0x0d0x0a 做結尾
			Array.Resize(ref byteget, byteget.Length + 2);
			byteget[byteget.Length - 2] = 13;
			byteget[byteget.Length - 1] = 10;

			Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

			try
			{
				IAsyncResult objResult = s.BeginConnect(SInfo.IP, SInfo.Port, null, null);
				objResult.AsyncWaitHandle.WaitOne(1000);
				if (!objResult.IsCompleted)
				{
					s.Close();
					s.Dispose();
					return "SendInfoToServer::connect timeout";
				}
				else
				{
					int result = s.Send(byteget, byteget.Length, SocketFlags.None);
					byte[] bytReceive = new byte[3072];
					// s.ReceiveTimeout = 5000;
					result = s.Receive(bytReceive);
					s.Close();
					s.Dispose();
					//return Encoding.Unicode.GetString(bytReceive).Replace("\0", "").Trim();
					return SInfo.ReceiveEncoding.GetString(bytReceive).Replace("\0", "").Trim();
				}
			}
			catch (Exception e)
			{
				log4net.LogManager.GetLogger("Error").Error("SendInfoToServer::" + SInfo.ServerType + "" + SInfo.IP + " command：" + SInfo.Command + " ErrorMessage：" + e.Message + "\r\nStackTrace:" + e.StackTrace + "\r\nSource:" + e.Source, e);
				s.Close();
				s.Dispose();
				return e.Message;
			}
		}
	}
}