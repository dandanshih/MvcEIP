﻿using GFC.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace Share_MGT.AppLibs
{
	public class FormBase : GFC.Web.PageBase
	{
		public Models.Game_Activity_Context ActivityDB = new Models.Game_Activity_Context();

		public override void Dispose()
		{
			this.ActivityDB.Dispose();
			base.Dispose();
		}

		#region Files
		protected AUser AUser;
		private AuthorityInfo m_Authority = null;
		#endregion

        #region Property
        /// <summary>
        /// 權限資訊。
		/// </summary>
		public AuthorityInfo Authority
		{
			get
			{
				if (this.m_Authority == null)
				{
					this.m_Authority = new AuthorityInfo();
				}
				return this.m_Authority;
			}
		}
		#endregion

        #region Private Method
        /// <summary>
        ///  取得 Function 列表。
        /// </summary>
        /// <param name="agentId">目前執行者編號</param>
        private void InitFunctionList(string agentId)
        {
            SqlParameter[] param = 
			{
				new SqlParameter("@AgentID", agentId)
			};

            DataTable tabFunctionList = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_ReadMyFunction",
                param
            ).Tables[0];

            // 將資料放入 Session 中，讓 PageBase 的部份可檢查該 AUser 不可進入不能進去的地方
            if (Session["MyFunctionList"] == null)
            {
                Session.Add("MyFunctionList", tabFunctionList);
            }
            else
            {
                Session["MyFunctionList"] = tabFunctionList;
            }
        }
        #endregion

        #region Protected Method
        protected override void OnLoad(EventArgs e)
		{
			if (Session["AUser"] == null)
			{
				Response.Redirect("~/Login.aspx");
			}
			else
			{
				AUser = (AUser)Session["AUser"];
                InitFunctionList(AUser.ExecAgentID);
			}
			
			// 不要讓按鈕 Disable
			IsButtonAutoDisableOnPostBack = false;

            switch (Request.CurrentExecutionFilePath.ToLower())
            {
                case "/index.aspx":
                case "/login.aspx":
                case "/logout.aspx":
                    break;
                default:
                    // 造成沒有權限有可能是FunctionEName 與網頁名稱不相同，導致找不到當前Function 權限
                    if (!Authority.CheckAuthority(EnumAuthority.Run))
                    {
                        switch (System.Threading.Thread.CurrentThread.CurrentUICulture.Name.ToString().ToLower())
                        {
                            case "en-us":
                                Utility.ShowDialog("You do not have permission to perform!", "location.href='/Index.aspx';");
                                break;
                            case "zh-tw":
                            case "zh-cn":
                                Utility.ShowDialog("您没有执行的权限", "location.href='/Index.aspx';");
                                break;
                            default:
                                Utility.ShowDialog("您没有执行的权限", "location.href='/Index.aspx';");
                                break;
                        }
                    }
                    break;
            }

			base.OnLoad(e);			
		}
        #endregion

        #region Public Method
        /// <summary>
		/// 將 TextBox 的斷行換成網頁可正常顯示的斷行符號
		/// </summary>
		public string ReplaceBr(string Value)
		{
			return Value.Replace("\r\n", "<br/>").Replace("\n", "<br/>");
		}

		/// <summary>
		/// 將 Label 的斷行符號 <br/> 換成 \r\n 的資料
		/// </summary>
		public string ReplaceBrBack(string Value)
		{
			return Value.Replace("<br/>", "\r\n");
		}
        #endregion
	}
}
