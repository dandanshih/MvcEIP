﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Share_MGT.AppLibs
{
    [Flags]
    public enum EnumPointType
    {
        /// <summary>
        /// 爽幣
        /// </summary>
        UCoin = 1,
        /// <summary>
        /// 老幣
        /// </summary>
        HCoin = 2
    }
}