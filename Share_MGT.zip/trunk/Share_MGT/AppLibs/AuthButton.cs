﻿
namespace Share_MGT.AppLibs
{
	public class AuthButton : System.Web.UI.WebControls.Button
	{
		// 要判斷的權限種類
		private EnumAuthority m_AuthorityType = EnumAuthority.None;
		public EnumAuthority AuthorityType
		{
			get
			{
				return this.m_AuthorityType;
			}
			set
			{
                switch (value)
                {
                    case EnumAuthority.PauseAccount:
                    case EnumAuthority.KickOut:
                    case EnumAuthority.Del:
                        this.CssClass = "btn btn-danger";
                        break;
                    default:
                        this.CssClass = "btn btn-default";
                        break;
                }
				this.m_AuthorityType = value;
			}
		}

		// 是否可見
		public override bool Visible
		{
			get
			{
				if (this.Page is FormBase && base.Visible)
				{
					return ((FormBase)this.Page).Authority.CheckAuthority(AuthorityType);
				}
				else
				{
					return base.Visible;
				}
			}
			set
			{
				base.Visible = value;
			}
		}
	}
}