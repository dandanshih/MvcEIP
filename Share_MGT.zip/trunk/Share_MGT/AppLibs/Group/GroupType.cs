﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Share_MGT.AppLibs.Group
{
    public enum GroupType
    {
        None = 0,
        // 研發
        RD = 1,
        // 技術客服主管
        TechnicalServiceManager = 2,
        // 技術客服
        TechnicalService = 3,
        // 公司
        Company = 4,
        // 營運商客服主管	
        CustomerServiceManager = 5,
        // 營運商客服
        CustomerService = 6,
        // 營運商
        Master = 7,
        // 股東
        Partner = 8,
        // 代理商
        Agent = 9,
        // 代理商
        Agent2 = 10,
        // 子帳號
        Shadow = 99,
        // 會員
        Member = 100
    }
}