﻿using System;
using System.Web;

namespace Share_MGT.AppLibs.Group
{
    public static class GroupTypeUtility
    {
        /// <summary>
        /// 取得目前查詢類別是否為【非階層式的帳號】。
        /// </summary>
        public static bool IsOperator(string sCurrentQry)
        {
            GroupType currentQry = Enum.TryParse(sCurrentQry, out currentQry) ? currentQry : GroupType.None;
            return IsOperator(currentQry);
        }

        /// <summary>
        /// 取得目前查詢類別是否為【非階層式的帳號】。
        /// </summary>
        public static bool IsOperator(GroupType currentQry)
        {
            return
            (
                currentQry == GroupType.TechnicalServiceManager
                || currentQry == GroupType.TechnicalService
                || currentQry == GroupType.CustomerServiceManager
                || currentQry == GroupType.CustomerService
                || currentQry == GroupType.Shadow
            );
        }

        /// <summary>
        /// 取得目前查詢類別是否為【階層式的帳號】。
        /// </summary>
        public static bool IsAgnet(string sCurrentQry)
        {
            GroupType currentQry = Enum.TryParse(sCurrentQry, out currentQry) ? currentQry : GroupType.None;
            return IsAgnet(currentQry);
        }

        /// <summary>
        /// 取得目前查詢類別是否為【階層式的帳號】。
        /// </summary>
        public static bool IsAgnet(GroupType currentQry)
        {
            return
            (
                currentQry == GroupType.RD
                || currentQry == GroupType.Company
                || currentQry == GroupType.Master
                || currentQry == GroupType.Partner
                || currentQry == GroupType.Agent
                || currentQry == GroupType.Agent2
            );
        }

        /// <summary>
        /// 取得目前查詢類別是否為【會員】。
        /// </summary>
        public static bool IsMember(GroupType currentQry)
        {
            return
            (
                currentQry == GroupType.Member
            );
        }

        public static string GetQryTypeName(string sCurrentQry)
        {
            return HttpContext.GetGlobalResourceObject("Resources", "GroupType_" + sCurrentQry).ToString();
        }

        public static string GetQryTypeName(GroupType currentQry)
        {
            return GetQryTypeName(((int)currentQry).ToString());
        }
    }
}