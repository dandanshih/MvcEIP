﻿using System;

namespace Share_MGT.AppLibs
{
	public class MPBase : GFC.Web.MasterPageBase
	{
		protected AUser AUser;

		protected override void OnLoad(EventArgs e)
		{
			AUser = (AUser)Session["AUser"];

			base.OnLoad(e);
		}
	}
}