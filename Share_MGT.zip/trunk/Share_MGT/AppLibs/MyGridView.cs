﻿using System.Web.UI.WebControls;

namespace Share_MGT.AppLibs
{
	/// <summary>
	/// MyGridView 的摘要描述
	/// </summary>
	public class MyGridView : System.Web.UI.WebControls.GridView
	{
		protected override void OnRowDataBound(GridViewRowEventArgs e)
		{
			//bool isEditable = ((MyBasePage)Page).AuthorityInfo.IsEditable;
			//bool isDelable = ((MyBasePage)Page).AuthorityInfo.IsDelable;

			bool isEditable = true;
			bool isDelable = true;

			if (e.Row.RowIndex >= 0)
			{
				LinkButton objHyp = null;

				//判斷是否有修改的權限
				if (e.Row.Cells[0].Controls.Count > 0)
				{
					objHyp = e.Row.Cells[0].Controls[0] as LinkButton;
					if (objHyp != null) objHyp.Enabled = isEditable;
				}

				//判斷是否有刪除的權限
				if (e.Row.Cells[1].Controls.Count > 0)
				{
					objHyp = e.Row.Cells[1].Controls[0] as LinkButton;
					if (objHyp != null)
					{
						objHyp.Enabled = isDelable;
						if (isDelable) objHyp.Attributes.Add("onclick", "return confirm('刪除動作無法回復，您確定嗎？');");
					}
				}
			}

			base.OnRowDataBound(e);
		}

		// 修改
		protected override void OnRowCommand(GridViewCommandEventArgs e)
		{
			base.OnRowCommand(e);

			//if (e.CommandName == "EditProfile")
			//{
			//    int sid = int.TryParse(e.CommandArgument.ToString(), out sid) ? sid : 0;
			//    ((IMasterSubject)this.Page.Master).ChangePageMode(PageMode.Edit, DataKeys[sid].Value);
			//}
		}

		//刪除
		protected override void OnRowDeleted(GridViewDeletedEventArgs e)
		{
			base.OnRowDeleted(e);
			//新增日誌
			// ((MyBasePage)this.Page).AddEventLog(EventCategory.Delete);
		}
	}
}