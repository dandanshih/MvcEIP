﻿using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Linq;
using System.Threading;
using System.Web;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;

namespace Share_MGT
{
    public class CommonResource
    {
        private DataTable _TextResourceTable = null;

        private object _Locker = new object();

        private bool _IsWriting = false;

        /// <summary>
        /// 初始化
        /// </summary>
        public CommonResource()
        {
        }

        public void LoadData()
        {
            _IsWriting = true;
            lock (_Locker)
            {
                SqlConnection sqlConn = new SqlConnection(GFC.Utility.ConfigurationManager.Sections.GetConfig().Global.MasterDBConnString);
                SqlDataAdapter sqlAdapter = new SqlDataAdapter("EXEC NSP_AgentWeb_S_GetMessagesList", sqlConn);
                _TextResourceTable = new DataTable("TextResource");
                sqlAdapter.Fill(_TextResourceTable);
            }
            _IsWriting = false;
        }

        /// <summary>
        /// 直接從資源檔取得指定類別的列表。
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public IEnumerable<ResxRow> GetResxTypeList(string type)
        {
            return GetResxTypeList(type, -1);
        }

        /// <summary>
        /// 直接從資源檔取得指定類別的列表。
        /// </summary>
        /// <param name="type"></param>
        /// <param name="flag">-1 為不篩選</param>
        /// <returns></returns>
        public IEnumerable<ResxRow> GetResxTypeList(string type, int flag)
        {
            string valueField = "Value_Default";

            string currentLanguage = Thread.CurrentThread.CurrentUICulture.Name.ToString().Replace("-", "").ToUpper();

            // 根據目前的語系指定資源值的欄位名稱
            if ((new string[] { "ZHTW", "ZHCN", "JAJP", "ENUS" }).Contains(currentLanguage))
            {
                valueField = "Value_" + currentLanguage;
            }

            // 如果資料表正在寫入中就等候寫入完畢

            while (_IsWriting)
            {
                System.Threading.Thread.Sleep(1000);
            }

            // 增加判斷是否有該語系欄位
            valueField = _TextResourceTable.Columns.Contains(valueField) ? valueField : "Value_Default";

            IEnumerable<ResxRow> rowCollection = from i in _TextResourceTable.AsEnumerable()
                                                 where i["ResxType"].ToString() == type 
                                                     && bool.Parse(i["IsEnabled"].ToString())
                                                     && (flag == -1 || ((int.Parse(i["Flag"].ToString()) & flag) == int.Parse(i["Flag"].ToString())))
                                                     //&& (flag == -1 || int.Parse(i["Flag"].ToString()) == flag)
                                                 select new ResxRow()
                                                 {
                                                     Value = Int64.Parse(i["Message_id"].ToString()),
                                                     Text = i[valueField].ToString()
                                                 };
            
            return rowCollection;
        }

        public string GetTextResxByMessageID(string type, object key)
        {
            return GetTextResx(type, "Message_id", key);
        }

        /// <summary>
        /// 取得資源
        /// </summary>
        /// <param name="type">資源種類</param>
        /// <param name="key">資源鍵</param>
        /// <returns></returns>
        public string GetTextResxByResxKey(string type, object key)
        {
            return GetTextResx(type, "ResxKey", key);
        }

        /// <summary>
        /// 取得資源
        /// </summary>
        /// <param name="type">資源種類</param>
        /// <param name="keyName">比對資源鍵的欄位</param>
        /// <param name="key">資源鍵</param>
        /// <returns></returns>
        public string GetTextResx(string type, string keyName, object key)
        {
            string valueField = "Value_Default";

            string currentLanguage = Thread.CurrentThread.CurrentUICulture.Name.ToString().Replace("-", "").ToUpper();

            // 根據目前的語系指定資源值的欄位名稱
            if ((new string[] { "ZHTW", "ZHCN", "JAJP", "ENUS" }).Contains(currentLanguage))
            {
                valueField = "Value_" + currentLanguage;
            }

            string result = "";

            // 如果資料表正在寫入中就等候寫入完畢

            while (_IsWriting)
            {
                System.Threading.Thread.Sleep(1000);
            }

            DataRow[] drs = _TextResourceTable.Select("ResxType='" + type + "' and " + keyName + "='" + key + "'");

            // 如果沒有該資源項目, 或是該資源項目為空白, 就直接傳回資源項目文字
            if (drs.Length == 0)
            {
                result = key.ToString();
            }
            else if (drs[0].Table.Columns.Contains(valueField) &&    // 20100302 Phil: 增加判斷是否有該語系欄位
                drs[0][valueField].ToString().Trim().Length != 0)
            {
                result = drs[0][valueField].ToString().Trim();
            }
            else if (drs[0]["Value_Default"].ToString().Trim().Length != 0)
            {
                result = drs[0]["Value_Default"].ToString().Trim();
            }

            // 傳回資源值
            return result;
        }

        /// <summary>
        /// 取得特定 ResxType 的列表。
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public EnumerableRowCollection GetTextResxRow(string type)
        {
            // 目前語系
            string currentLanguage = Thread.CurrentThread.CurrentUICulture.Name.ToString().Replace("-", "").ToUpper();
            // 允許語系
            string[] allowLanguage = { "ZHTW", "ZHCN", "JAJP", "ENUS" };
            // 預設語系欄位
            string defaultField = "Value_Default";
            // 根據目前的語系指定資源值的欄位名稱
            string valueField = allowLanguage.Contains(currentLanguage) ? "Value_" + currentLanguage : defaultField;

            // 如果資料表正在寫入中就等候寫入完畢
            while (_IsWriting)
            {
                System.Threading.Thread.Sleep(1000);
            }

            var result = from i in _TextResourceTable.AsEnumerable()
                         where i["ResxType"].ToString() == type
                         select new
                         {
                             Key = i["ResxKey"],
                             Value = (i[valueField] == null || i[valueField].ToString() == "") ? i[defaultField] : i[valueField],
                             Flag = Convert.ToInt64(i["Flag"])
                         };

            // 傳回資源值
            return result;
        }

        public string GetTextResxArray_MessageID(string type, object key)
        {
            return GetTextResxArray(type, "Message_id", key);
        }

        public string GetTextResxArray(string type, string keyName, object key)
        {
            if (string.IsNullOrEmpty(key.ToString().Trim()))
            {
                return key.ToString();
            }

            string[] arrayKey = key.ToString().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            string valueField = "Value_Default";

            string currentLanguage = Thread.CurrentThread.CurrentUICulture.Name.ToString().Replace("-", "").ToUpper();

            // 根據目前的語系指定資源值的欄位名稱
            if ((new string[] { "ZHTW", "ZHCN", "JAJP", "ENUS" }).Contains(currentLanguage))
            {
                valueField = "Value_" + currentLanguage;
            }

            // 如果資料表正在寫入中就等候寫入完畢

            while (_IsWriting)
            {
                System.Threading.Thread.Sleep(1000);
            }

            if (!_TextResourceTable.Columns.Contains(valueField))
            {
                valueField = "Value_Default";
            }

            EnumerableRowCollection<string> rowCollection = from i in _TextResourceTable.AsEnumerable()
                                                            where i["ResxType"].ToString() == type
                                                                    && arrayKey.Contains(i[keyName].ToString())
                                                            select i[valueField].ToString();

            if (rowCollection.Count() > 0)
            {
                return string.Join(",", rowCollection.ToArray());
            }
            else
            {
                return key.ToString();
            }
        }
    }

    public class ResxRow
    {
        public Int64 Value { get; set; }
        public string Text { get; set; }
    }
}
