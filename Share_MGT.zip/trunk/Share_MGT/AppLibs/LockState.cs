﻿//-----------------------------------------------------------------------
// <copyright file="LockInstance.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Share_MGT.AppLibs
{
    using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;

    /// <summary>
    /// LockInstance Class
    /// </summary>
    public sealed class LockState
    {
        private static LockState lck_instance = null;

        private static Object obj = new Object();

        public static LockState Instance
        {
            get
            {
                if (lck_instance == null)
                {
                    lock (obj)
                    {
                        if (lck_instance == null)
                        {
                            lck_instance = new LockState();
                        }
                    }
                }
                return lck_instance;
            }
        }

        public ConcurrentDictionary<string, bool> LockLists = new ConcurrentDictionary<string, bool>();

        public bool CheckLock(string key)
        {
            if (this.LockLists.ContainsKey(key))
            {
                return this.LockLists[key];
            }
            else
            {
                return false;
            }
        }

        public void AddLock(string key)
        {
            this.LockLists.AddOrUpdate(key, true, (k, val) => val);
        }

        public void RemoveLock(string key)
        {
            bool tmpData;
            // 如果移除失敗，則將值設為false
            if (!this.LockLists.TryRemove(key, out tmpData))
            {
                this.LockLists[key] = false;
            }
        }
    }
}