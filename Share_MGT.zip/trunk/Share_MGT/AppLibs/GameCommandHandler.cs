﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using GFC.Net;
using GFC.Utilities;
using GFC.Web;

namespace Share_MGT.AppLibs {

    /// <summary>
    /// 此類別提供遊戲命令功能，其命令的對象包含遊戲前台網站或 GameServer 等. 
    /// </summary>
    public class GameCommandHandler
    {
        /// <summary>
        /// 更新前台公告(目前無作用)
        /// </summary>
        /// <returns></returns>
        public static bool RefreshBulletin()
        {
            bool bResult = false;
            string[] sGameWebUrls = WebConfig.DataInfoUrl.Split(';');
            if (sGameWebUrls.Length <= 0)
            {
                return bResult;
            }

            // 前台命令參數
            string sCmdText = "CmdID=403";

            foreach (string url in sGameWebUrls)
            {
                WebRequestHandler request = new WebRequestHandler(url + "/appajaxs/UpdateCmdData.ashx?" + sCmdText);
                request.ReceiveTimeout = 5000;
                request.SendTimeout = 5000;
                request.Send();
            }

            bResult = true;
            return bResult;
        }

        /// <summary>
        /// 將會員登出遊戲與前台網站(目前無作用)
        /// </summary>
        /// <param name="memberID">會員編號</param>
        /// <returns></returns>
        public static bool LogoutMember(int memberID)
        {
            bool bResult = false;
            try
            {
                string[] sGameWebUrls = WebConfig.DataInfoUrl.Split(';');
                if (sGameWebUrls.Length <= 0)
                {
                    return bResult;
                }

                // 前台命令參數
                string sCmdText = "CmdID=404&MemberID=" + memberID.ToString();

                foreach (string url in sGameWebUrls)
                {
                    WebRequestHandler request = new WebRequestHandler(url + "/appajaxs/UpdateCmdData.ashx?" + sCmdText);
                    request.ReceiveTimeout = 5000;
                    request.SendTimeout = 5000;
                    request.Send();
                }

                bResult = true;
            }
            catch (Exception ex)
            {

                WebErrorHandler weh = new WebErrorHandler(HttpContext.Current);
                weh.Process(ex, "", "踢前台會員時發生錯誤");
                bResult = false;

            }
            return bResult;
        }

        /// <summary>
        /// 將會員登出遊戲與前台網站
        /// </summary>
        /// <param name="memberAccount">會員帳號</param>
        /// <returns></returns>
        public static bool LogoutMember(string memberAccount)
        {
            int iMemberID;
            SqlDataReader sqlReader = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_A_GetUserData",
                new SqlParameter("@MemberAccount", memberAccount)
            );

            if (sqlReader.Read())
            {
                iMemberID = Convert.ToInt32(sqlReader["MemberID"]);
                return LogoutMember(iMemberID);
            }
            return false;
        }

        /// <summary>
        /// 關機設定
        /// </summary>
        /// <returns></returns>
        public static bool ShutDown(int isMaintain, DateTime shutDownTime)
        {
            bool bResult = false;
            try
            {
                string[] sGameWebUrls = WebConfig.DataInfoUrl.Split(';');
                if (sGameWebUrls.Length <= 0)
                {
                    return bResult;
                }

                // 前台命令參數
                string sCmdText = "CmdID=407&IsMaintain=" + isMaintain + "&ShutDownTime=" + HttpContext.Current.Server.UrlEncode(shutDownTime.ToString());

                foreach (string url in sGameWebUrls)
                {
                    WebRequestHandler request = new WebRequestHandler(url + "/appajaxs/UpdateCmdData.ashx?" + sCmdText);
                    request.ReceiveTimeout = 5000;
                    request.SendTimeout = 5000;
                    request.Send();
                }

                bResult = true;
            }
            catch (Exception ex)
            {
                WebErrorHandler weh = new WebErrorHandler(HttpContext.Current);
                weh.Process(ex, "", "關機設定發生錯誤");
                bResult = false;
            }
            return bResult;
        }
    }
}