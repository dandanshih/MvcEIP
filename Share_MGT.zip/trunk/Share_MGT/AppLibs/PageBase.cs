﻿using System;

namespace Share_MGT.AppLibs
{
    public class PageBase : System.Web.UI.Page
    {
        protected AUser AUser;

        protected override void OnLoad(EventArgs e)
        {
            AUser = (AUser)Session["AUser"];

            base.OnLoad(e);
        }
    }
}