﻿//-----------------------------------------------------------------------
// <copyright file="ApiProcess.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Share_MGT.AppLibs
{
    using System;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Web.Script.Serialization;

    /// <summary>
    /// 接口處理
    /// </summary>
    public static class ApiProcess
    {
        /// <summary>
        /// 執行介接格式接口
        /// </summary>
        /// <typeparam name="TInputData">傳入格式</typeparam>
        /// <typeparam name="TOutputData">輸出格式</typeparam>
        /// <param name="url">網址</param>
        /// <param name="appID">分桶編號</param>
        /// <param name="appSecret">分桶金鑰</param>
        /// <param name="data">傳入資料</param>
        /// <returns>回傳結果</returns>
        public static TOutputData Run<TInputData, TOutputData>(string url, string appID, string appSecret, TInputData data)
        {
            long ourTimeStamp = Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds);
            string plainText = string.Format("{0}{1}{2}", appID, ourTimeStamp, appSecret);
            string ourHash = MD5Encrypt(plainText);

            JavaScriptSerializer jss = new JavaScriptSerializer();

            string getUrl = string.Format("{0}{1}appID={2}&timestamp={3}&hash={4}", url, url.Contains("?") ? "&" : "?", appID, ourTimeStamp, ourHash);
            string postData = jss.Serialize(data);

            TOutputData result = jss.Deserialize<TOutputData>(HttpPost(getUrl, postData));
            return result;
        }

        /// <summary>
        /// 執行介接格式接口
        /// </summary>
        /// <typeparam name="TOutputData">輸出格式</typeparam>
        /// <param name="url">網址</param>
        /// <param name="appID">分桶編號</param>
        /// <param name="appSecret">分桶金鑰</param>
        /// <returns>回傳結果</returns>
        public static TOutputData Run<TOutputData>(string url, string appID, string appSecret)
        {
            long ourTimeStamp = Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds);
            string plainText = string.Format("{0}{1}{2}", appID, ourTimeStamp, appSecret);
            string ourHash = plainText;

            JavaScriptSerializer jss = new JavaScriptSerializer();

            string getUrl = string.Format("{0}{1}appID={2}&timestamp={3}&hash={4}", url, url.Contains("?") ? "&" : "?", appID, ourTimeStamp, ourHash);
            string postData = string.Empty;

            TOutputData result = jss.Deserialize<TOutputData>(HttpPost(getUrl, postData));
            return result;
        }

        /// <summary>
        /// MD5 加密方法
        /// </summary>
        /// <param name="plainText">明碼文字</param>
        /// <returns>加密後文字</returns>
        public static string MD5Encrypt(string plainText)
        {
            var md5 = System.Security.Cryptography.MD5.Create();
            byte[] source = Encoding.Default.GetBytes(plainText);
            byte[] crypto = md5.ComputeHash(source);
            string result = BitConverter.ToString(crypto).Replace("-", string.Empty);
            return result;
        }

        /// <summary>
        /// Http Post
        /// </summary>
        /// <param name="getUrl">網址</param>
        /// <param name="postData">Post Data</param>
        /// <returns>回傳字串</returns>
        private static string HttpPost(string getUrl, string postData)
        {
            log4net.LogManager.GetLogger(typeof(ApiProcess)).InfoFormat(
                "Api Process Post Data, Url: {0}, PostData: {1}",
                getUrl,
                postData);

            byte[] aryData = Encoding.UTF8.GetBytes(postData);
            HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(getUrl);

            req.Method = "POST";
            req.ContentType = "application/json";
            req.ContentLength = aryData.Length;
            req.Accept = "application/json";

            using (Stream reqStream = req.GetRequestStream())
            {
                reqStream.Write(aryData, 0, aryData.Length);
            }

            string strResult = string.Empty;
            using (WebResponse res = req.GetResponse())
            {
                using (Stream resStream = res.GetResponseStream())
                {
                    using (StreamReader objSR = new StreamReader(resStream))
                    {
                        strResult = objSR.ReadToEnd();
                    }
                }
            }

            log4net.LogManager.GetLogger(typeof(ApiProcess)).InfoFormat(
                "Api Process Receive Data, Result: {0}",
                strResult);

            return strResult;
        }
    }
}