﻿using GFC.Utilities;
using GS.ServerCommander;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace Share_MGT.AppLibs
{
    /// <summary>
    /// 會員相關處理。
    /// </summary>
    public class MemberUtility
    {
        /// <summary>
        /// 踢會員。
        /// </summary>
        /// <param name="kickMember">資料庫回傳會員列表。</param>
        /// <param name="execAgentID">執行踢人動作的代理商編號。</param>
        /// <param name="frontServerIP">FrontServerIP</param>
        public static void Kick(DataTable kickMember, int execAgentID, string frontServerIP)
        {
            EnumerableRowCollection<DataRow> data = kickMember.AsEnumerable();

            StringBuilder sb;
            int dataLen = kickMember.Rows.Count;
            int replace = (dataLen / 10) + (dataLen % 10 == 0 ? 0 : 1);

            for (int i = 0; i < replace; i++)
            {
                sb = new StringBuilder();


                IEnumerable<DataRow> partial = data.Skip(i * 10).Take(10);

                foreach (DataRow row in partial)
                {
                    sb.AppendFormat("{0}\r\n", row["MemberID"]);
                }

                MemberUtility.Kick(sb.Remove(sb.Length - 2, 2).ToString());
            }
        }

        /// <summary>
        /// 踢會員。
        /// </summary>
        /// <param name="memberList">要踢的會員編號列表，以\r\n分隔不同MemberID。</param>
        public static void Kick(string memberList)
        {
            FSCommander.FS_AS_WEB_KICK_USER(memberList);
        }

        /// <summary>
        /// 會員帳號 停用/啟用。
        /// </summary>
        /// <param name="memberID">停用/啟用的會員編號。</param>
        /// <param name="execAgentID">執行動作的代理商帳號。</param>
        /// <param name="lockType">鎖定種類。(0:啟用 3:停用)</param>
        /// <param name="lockReason">鎖定原因。</param>
        /// <returns></returns>
        public static ResultStruct Pause(int memberID, int lockType, string lockReason, int execAgentID, string frontServerIP)
        {
            ResultStruct result = new ResultStruct();

            if (!(new int[] { 0, 3 }).Contains(lockType))
            {
                result.Code = 999;
                result.Message = "更新失敗";
                return result;
            }

            SqlParameter[] arParms =
			{
				new SqlParameter("@Result", DbType.Int32),
				new SqlParameter("@MemberID", memberID.ToString()),
				new SqlParameter("@PauseMemo", lockReason),
				new SqlParameter("@PauseType", lockType.ToString()),
				new SqlParameter("@ExecAgentID", execAgentID.ToString())
			};

            arParms[0].Direction = ParameterDirection.ReturnValue;

            DataTable kickMember = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_PauseAccount",
                arParms
            ).Tables[0];

            result.Code = int.Parse(arParms[0].Value.ToString());

            switch (result.Code)
            {
                case 0:
                    result.Message = "設定成功";

                    // 停用要踢帳號
                    if (lockType == 3)
                    {
                        Kick(kickMember, execAgentID, frontServerIP);
                    }
                    break;
                case 2:
                    result.Message = "查無此會員";
                    break;
                default:
                    result.Message = "更新失敗";
                    break;
            }

            return result;
        }

        /// <summary>
        /// 停用押注群組。
        /// </summary>
        /// <param name="memberID">停用/啟用的代理商編號</param>
        /// <param name="pauseType">0:啟用 3:停用</param>
        /// <param name="execAgentID">執行動作的代理商編號。</param>
        /// <param name="frontServerIP">FS IP。</param>
        /// <returns></returns>
        public static ResultStruct PauseBetGroup(int memberID, int pauseType, int execAgentID, string frontServerIP)
        {
            ResultStruct result = new ResultStruct();

            if (!(new int[] { 0, 3 }).Contains(pauseType))
            {
                result.Code = 999;
                result.Message = "更新失敗";
                return result;
            }

            SqlParameter[] param =
			{
				new SqlParameter("@Result", SqlDbType.SmallInt),
				new SqlParameter("@MemberID", memberID.ToString()),
				new SqlParameter("@PauseType", pauseType),
				new SqlParameter("@ExecAgentID", execAgentID.ToString())
			};

            param[0].Direction = ParameterDirection.ReturnValue;

            DataTable kickMember = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_PauseBet",
                param
            ).Tables[0];

            result.Code = int.Parse(param[0].Value.ToString());
            result.Message = (pauseType == 0) ? "啟用" : "停用";

            switch (result.Code)
            {
                case 0:
                    result.Message = result.Message + "成功";

                    // 停用要踢帳號
                    if (pauseType != 0)
                    {
                        MemberUtility.Kick(kickMember, execAgentID, frontServerIP);
                    }
                    break;
                default:
                    result.Message = result.Message + "設定失敗";
                    break;
            }

            return result;
        }

        /// <summary>
        /// 黑名單 設定/解除。
        /// </summary>
        /// <param name="memberAccount">指定加入黑名單的會員帳號。</param>
        /// <param name="nickName">指定加入黑名單的會員暱稱。</param>
        /// <param name="execAgent">執行動作的代理商帳號。</param>
        /// <param name="alarmType">0:解除 1:在遊戲中設定黑名單 2:在網頁中設定黑名單</param>
        /// <returns>0: 設定成功 -1:此帳號不存在 -2:此帳號已經被列為黑名單了 -3: 此帳號不是黑名單帳號</returns>
        public static ResultStruct SetBlackList(string memberAccount, string nickName, string execAgent, int alarmType)
        {
            ResultStruct result = new ResultStruct();

            // 帳號、暱稱 擇一查詢
            if (string.IsNullOrEmpty(memberAccount) && string.IsNullOrEmpty(nickName))
            {
                result.Code = 999;
                result.Message = "設定失敗";
            }
            else
            {
                if (!string.IsNullOrEmpty(nickName))
                {
                    memberAccount = "";
                }

                SqlParameter[] param =
			    {
                    new SqlParameter("@Result", SqlDbType.Int),
				    new SqlParameter("@MemberAccount", memberAccount),
                    new SqlParameter("@NickName", nickName),
				    new SqlParameter("@ExecAccount", execAgent),
				    new SqlParameter("@AlarmType", alarmType.ToString())
			    };

                param[0].Direction = ParameterDirection.ReturnValue;

                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_A_SetMemberAccountAlarmed",
                    param
                );

                result.Code = int.Parse(param[0].Value.ToString());

                switch (result.Code)
                {
                    case 0:
                        result.Message = "設定成功";
                        break;
                    case -1:
                        result.Message = "輸入的會員帳號不存在";
                        break;
                    case -2:
                        result.Message = "此帳號已經被列為黑名單了";
                        break;
                    case -3:
                        result.Message = "此帳號不是黑名單帳號";
                        break;
                    case -4:
                        result.Message = "執行的代理商不存在";
                        break;
                    default:
                        result.Message = "設定失敗";
                        break;
                }
            }

            return result;
        }

        /// <summary>
        /// 呼叫 Front Server 洗分。
        /// </summary>
        /// <param name="EventID"></param>
        /// <param name="MemberID"></param>
        /// <param name="Points"></param>
        /// <param name="PointType"></param>
        /// <returns></returns>
        public static string KeyOutToServer(long eventID, int memberID, decimal points, int pointType)
        {
            log4net.LogManager.GetLogger(typeof(MemberUtility)).DebugFormat("KeyOutToServer::EventID={0}, MemberID={1}, Points={2}, PointType={3}", eventID, memberID, points, pointType);
            string result = FSCommander.FS_AS_CREDIT_CHANGE(eventID, memberID, points, pointType);
            log4net.LogManager.GetLogger(typeof(MemberUtility)).DebugFormat("KeyOutToServer::EventID={0}, Result={1}", eventID, result);
            return result;
        }

        /// <summary>
        /// 會員刪除。
        /// </summary>
        /// <param name="memberID"></param>
        /// <param name="execAgentID"></param>
        /// <param name="frontServerIP"></param>
        /// <returns></returns>
        public static ResultStruct Del(int memberID, int execAgentID, string frontServerIP)
        {
            // 先將會員踢掉
            Kick(memberID.ToString());

            ResultStruct result = new ResultStruct();

            SqlParameter[] param =
			{
				new SqlParameter("@MemberID", memberID.ToString()),
                new SqlParameter("@ExecAgentID", execAgentID.ToString())
			};

            result.Code = int.Parse(SqlHelper.ExecuteScalar
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_Delete",
                param
            ).ToString());

            switch (result.Code)
            {
                case 0:
                    result.Message = "刪除成功";
                    break;
                case 1:
                    result.Message = "會員已刪除過，刪除失敗";
                    break;
                case 2:
                    result.Message = "會員還在線上，刪除失敗";
                    break;
                case 3:
                    result.Message = "會員不存在，刪除失敗";
                    break;
                case 4:
                    result.Message = "非下階會員無法刪除，刪除失敗";
                    break;
                case -1:
                default:
                    result.Message = "刪除失敗";
                    break;
            }

            return result;
        }

        /// <summary>
        /// 停用/啟用 VIP轉帳帳戶。
        /// </summary>
        /// <param name="memberID">會員編號。</param>
        /// <param name="isActivate">0:停用 1:啟用</param>
        /// <param name="agentID">執行動作的代理商主帳號。</param>
        /// <param name="execAgentID">執行動作的代理商帳號。</param>
        /// <returns></returns>
        public static ResultStruct VipPause(int memberID, int isActivate, int agentID, int execAgentID)
        {
            SqlParameter[] arParms =
			{
				new SqlParameter("@MemberID", memberID.ToString()),
				new SqlParameter("@IsActivate", isActivate.ToString()),
				new SqlParameter("@AgentID", agentID.ToString()),
				new SqlParameter("@ExecAgentID", execAgentID.ToString())
			};

            ResultStruct result = new ResultStruct();

            result.Code = int.Parse(SqlHelper.ExecuteScalar
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_ActivateVIPAccount",
                arParms
            ).ToString());

            switch (result.Code)
            {
                case 0:
                    result.Message = "設定成功";
                    break;
                case 1:
                    result.Message = "查無此會員";
                    break;
                case 2:
                    result.Message = "非下階會員無法設定";
                    break;
                case 3:
                    result.Message = "非VIP帳號無法設定";
                    break;
                default:
                    result.Message = "設定失敗";
                    break;
            }

            return result;
        }

        /// <summary>
        /// 通知 DB KeyIn 成功。
        /// </summary>
        /// <param name="fromAgentID"></param>
        /// <param name="toMemberID"></param>
        /// <param name="changePoint"></param>
        /// <param name="execAgentID"></param>
        /// <param name="tranUID"></param>
        /// <returns></returns>
		private static ResultStruct KeyInUpdateDB(string fromAgentID, string toMemberID, decimal changePoint, int execAgentID, string tranUID ,string ExecAgentIP)
        {
            ResultStruct result = new ResultStruct();

            SqlParameter[] param =
            {
                new SqlParameter("@ResultID", DbType.Int32),
                new SqlParameter("@FromAgentID", fromAgentID),
                new SqlParameter("@ToMemberID", toMemberID),
                new SqlParameter("@ChangePoint", changePoint.ToString()),
                new SqlParameter("@ExecAgentID", execAgentID.ToString()),
                new SqlParameter("@TranUID", tranUID),
				new SqlParameter("@ExecAgentIP", ExecAgentIP)
            };

            param[0].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KeyIn_Member_UpdateResult",
                param
            );

            result.Code = int.Parse(param[0].Value.ToString());

            switch (result.Code)
            {
                case 0:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyInUpdateDB_" + result.Code.ToString()).ToString();
                    break;
                case 1:
                case 3:
                case 5:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyInUpdateDB_" + result.Code.ToString()).ToString();
                    log4net.LogManager.GetLogger(typeof(MemberUtility)).DebugFormat("KeyInUpdateDB::FromAgentID={0}, ToMemberID={1}, ChangePoint={2}, ExecAgentID={3}, TranUID={4}, ResultCode={5}", fromAgentID, toMemberID, changePoint, execAgentID, tranUID, result.Code);
                    break;
                default:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyInUpdateDB_def").ToString();
                    log4net.LogManager.GetLogger(typeof(MemberUtility)).DebugFormat("KeyInUpdateDB::FromAgentID={0}, ToMemberID={1}, ChangePoint={2}, ExecAgentID={3}, TranUID={4}, ResultCode={5}", fromAgentID, toMemberID, changePoint, execAgentID, tranUID, result.Code);
                    break;
            }

            return result;
        }

        /// <summary>
        /// 通知 DB KeyOut 成功。
        /// </summary>
        /// <param name="fromAgentID"></param>
        /// <param name="toMemberID"></param>
        /// <param name="changePoint"></param>
        /// <param name="execAgentID"></param>
        /// <param name="tranUID"></param>
        /// <returns></returns>
		private static ResultStruct KeyOutUpdateDB(string fromMemberID, string toAgentID, decimal changePoint, int execAgentID, string tranUID, string execAgentIP)
        {
            ResultStruct result = new ResultStruct();

            SqlParameter[] param =
            {
                new SqlParameter("@ResultID", DbType.Int32),
                new SqlParameter("@FromMemberID", fromMemberID),
			    new SqlParameter("@ToAgentID", toAgentID),
			    new SqlParameter("@ChangePoint", changePoint.ToString()),
			    new SqlParameter("@ExecAgentID", execAgentID.ToString()),
                new SqlParameter("@TranUID", tranUID),
				new SqlParameter("@ExecAgentIP", execAgentIP)
            };

            param[0].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KeyOut_Member_UpdateResult",
                param
            );

            result.Code = int.Parse(param[0].Value.ToString());

            switch (result.Code)
            {
                case 0:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyOutUpdateDB_" + result.Code.ToString()).ToString();
                    break;
                case 1:
                case 3:
                case 5:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyOutUpdateDB_" + result.Code.ToString()).ToString();
                    log4net.LogManager.GetLogger(typeof(MemberUtility)).DebugFormat("KeyOutUpdateDB::FromMemberID={0}, ToAgentID={1}, ChangePoint={2}, ExecAgentID={3}, TranUID={4}, ResultCode={5}", fromMemberID, toAgentID, changePoint, execAgentID, tranUID, result.Code);
                    break;
                default:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyOutUpdateDB_def").ToString();
                    log4net.LogManager.GetLogger(typeof(MemberUtility)).DebugFormat("KeyOutUpdateDB::FromMemberID={0}, ToAgentID={1}, ChangePoint={2}, ExecAgentID={3}, TranUID={4}, ResultCode={5}", fromMemberID, toAgentID, changePoint, execAgentID, tranUID, result.Code);
                    break;
            }

            return result;
        }

        /// <summary>
        /// 會員KeyIn。
        /// </summary>
        /// <param name="fromMemberID"></param>
        /// <param name="toAgentID"></param>
        /// <param name="changePoint"></param>
        /// <param name="execAgentID"></param>
        /// <param name="frontServerIP"></param>
        /// <returns></returns>
        public static ResultStruct KeyIn(string fromAgentID, string toMemberID, decimal changePoint, int execAgentID, string frontServerIP)
        {
            ResultStruct result = new ResultStruct();
            string tranUID = "";

            SqlParameter[] param =
            {
			    new SqlParameter("@ResultID", SqlDbType.Int),
			    new SqlParameter("@TranUID", SqlDbType.UniqueIdentifier),
                new SqlParameter("@FromAgentID", fromAgentID),
			    new SqlParameter("@ToMemberID", toMemberID),
			    new SqlParameter("@ChangePoint", changePoint.ToString()),
			    new SqlParameter("@ExecAgentID", execAgentID.ToString())
            };

            param[0].Direction = ParameterDirection.Output;
            param[1].Direction = ParameterDirection.Output;

            DataSet ds = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KeyIn_Member",
                param
            );

            result.Code = int.Parse(param[0].Value.ToString());
            tranUID = Convert.ToString(param[1].Value);

            switch (result.Code)
            {
                case 0:
                    if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        // 會員在線上對server開洗分
                        var fsResult = KeyOutToServer
                        (
                            int.Parse(ds.Tables[0].Rows[0]["EventID"].ToString()),
                            int.Parse(ds.Tables[0].Rows[0]["Target_MemberID"].ToString()),
                            decimal.Parse(ds.Tables[0].Rows[0]["ChangePoints"].ToString()),
                            int.Parse(ds.Tables[0].Rows[0]["PointType"].ToString())
                        );

                        if (fsResult != "0")
                        {
                            // FS 開分失敗
                            result.Code = -1;
                            result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_Keyin_" + result.Code.ToString()).ToString();
                        }
                    }

                    if (result.Code == 0)
                    {
						string execAgentIP = Utility.GetClientIP();
                        // 通知 DB 完成
						result = KeyInUpdateDB(fromAgentID, toMemberID, changePoint, execAgentID, tranUID, execAgentIP);
                    }
                    break;
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_Keyin_" + result.Code.ToString()).ToString();
                    break;
                default:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_Keyin_def").ToString();
                    break;
            }

            return result;
        }

        /// <summary>
        /// 會員KeyOut。
        /// </summary>
        /// <param name="fromMemberID"></param>
        /// <param name="toAgentID"></param>
        /// <param name="changePoint"></param>
        /// <param name="execAgentID"></param>
        /// <param name="frontServerIP"></param>
        /// <returns></returns>
        public static ResultStruct KeyOut(string fromMemberID, string toAgentID, decimal changePoint, int execAgentID, string frontServerIP)
        {
            ResultStruct result = new ResultStruct();
            string tranUID = "";

            SqlParameter[] param =
            {
			    new SqlParameter("@ResultID", DbType.Int32),
			    new SqlParameter("@TranUID", SqlDbType.UniqueIdentifier),
                new SqlParameter("@FromMemberID", fromMemberID),
			    new SqlParameter("@ToAgentID", toAgentID),
			    new SqlParameter("@ChangePoint", changePoint.ToString()),
			    new SqlParameter("@ExecAgentID", execAgentID.ToString())
            };

            param[0].Direction = ParameterDirection.Output;
            param[1].Direction = ParameterDirection.Output;

            DataSet ds = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KeyOut_Member",
                param
            );

            result.Code = int.Parse(param[0].Value.ToString());
            tranUID = Convert.ToString(param[1].Value);

            switch (result.Code)
            {
                case 0:
                    if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        // 會員在線上對server開洗分
                        var fsResult = KeyOutToServer
                        (
                            int.Parse(ds.Tables[0].Rows[0]["EventID"].ToString()),
                            int.Parse(ds.Tables[0].Rows[0]["Target_MemberID"].ToString()),
                            decimal.Parse(ds.Tables[0].Rows[0]["ChangePoints"].ToString()),
                            int.Parse(ds.Tables[0].Rows[0]["PointType"].ToString())
                        );

                        if (fsResult != "0")
                        {
                            if (fsResult == "-99")
                            {
                                // 洗分失敗，玩家在遊戲中
                                result.Code = -2;
                            }
                            else
                            {
                                // FS 開分失敗
                                result.Code = -1;
                            }
                            result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyOut_" + result.Code.ToString()).ToString();
                        }
                    }

                    if (result.Code == 0)
                    {
						string execAgentIP = Utility.GetClientIP();
                        // 通知 DB 完成
						result = KeyOutUpdateDB(fromMemberID, toAgentID, changePoint, execAgentID, tranUID ,execAgentIP);
                    }
                    break;
                case 1:
                case 2:
                case 3:
                case 5:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyOut_" + result.Code.ToString()).ToString();
                    break;
                default:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "MemberUtility_ResultMessage_KeyOut_def").ToString();
                    break;
            }

            return result;
        }
    }
}