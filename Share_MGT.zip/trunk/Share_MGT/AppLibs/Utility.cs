﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using GFC.Web;
using System.Data;
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Collections.Generic;

namespace Share_MGT
{
    /// <summary>
    /// Utility 的摘要描述
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// 隨機產生密鑰。
        /// </summary>
        /// <returns></returns>        
        public static string GeneralKey(int n)
        {
            char[] arrChar = new char[]{           
				'a','b','d','c','e','f','g','h','i','j','k','l','m','n','p','r','q','s','t','u','v','w','z','y','x',           
				'0','1','2','3','4','5','6','7','8','9',           
				'A','B','C','D','E','F','G','H','I','J','K','L','M','N','Q','P','R','T','S','V','U','W','X','Y','Z'          
			};

            StringBuilder num = new StringBuilder();
            Random rnd = new Random(DateTime.Now.Millisecond);
            for (int i = 0; i < n; i++)
            {
                num.Append(arrChar[rnd.Next(0, arrChar.Length)].ToString());
            }

            return num.ToString();
        }

        /// <summary>
        /// 將 Ascii 碼轉成字元
        /// </summary>
        /// <param name="asciiCode">Ascii 的值，介於 0~255 </param>
        public static string Chr(int asciiCode)
        {
            if (asciiCode >= 0 && asciiCode <= 255)
            {
                System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();
                byte[] byteArray = new byte[] { (byte)asciiCode };
                string strCharacter = asciiEncoding.GetString(byteArray);
                return (strCharacter);
            }
            else
            {
                throw new Exception("ASCII Code is not valid.");
            }
        }

        /// <summary>
        /// 將字元轉為 Ascii
        /// </summary>
        /// <param name="character">字元</param>
        public static int Asc(string character)
        {
            if (character.Length == 1)
            {
                System.Text.ASCIIEncoding asciiEncoding = new System.Text.ASCIIEncoding();
                int intAsciiCode = (int)asciiEncoding.GetBytes(character)[0];
                return (intAsciiCode);
            }
            else
            {
                throw new Exception("Character is not valid.");
            }
        }

        /// <summary>
        /// 列出本頁面的所有訊息
        /// </summary>
        /// <param name="page">要顯示的 page</param>
        /// <param name="updateDate">更新日期</param>
        /// <param name="updatePerson">更新者</param>
        /// <param name="specialMode">特別模式</param>
        /// <param name="powerUser">最高權限操作者</param>
        public static void ShowPageInformation(Page page, string updateDate, string updatePerson, string specialMode, string powerUser)
        {
            page.Response.Write("<div style='background-color:White; font-size: x-small;'>");
            page.Response.Write(string.Format("<font style='color:Red;'>{0} =: </font><font style='color:Blue;'>{1}</font><br />"
                                                , "UpdateDate", updateDate));
            page.Response.Write(string.Format("<font style='color:Red;'>{0} =: </font><font style='color:Blue;'>{1}</font><br />"
                                                , "UpdatePerson", updatePerson));
            page.Response.Write(string.Format("<font style='color:Red;'>{0} =: </font><font style='color:Blue;'>{1}</font><br />"
                                                , "SpecialMode", specialMode));
            page.Response.Write(string.Format("<font style='color:Red;'>{0} =: </font><font style='color:Blue;'>{1}</font><br />"
                                                , "PowerUser", powerUser));
            page.Response.Write("</div>");
        }

        /// <summary>
        /// 在 Client 秀出 Alert 視窗
        /// </summary>
        /// <param name="myPage"></param>
        /// <param name="sMsg"></param>
        public static void ClientAlert(object sender, string sMsg)
        {
            string jsstr = "ctl00_dgMessage_ctl00_dslblMessage.innerHTML ='" + sMsg + "';ctl00_dgMessage.show(true);";
            ScriptManager.RegisterStartupScript((Control)sender, sender.GetType(), "ClientAlert", jsstr, true);
        }

        //訊息警示
        public static void ShowDialog(string msg, string cmd)
        {
            StringBuilder strJS = new StringBuilder();
            strJS.Append("<script language=\"javascript\">");
            if (!string.IsNullOrEmpty(msg))
            {
                msg = msg.Replace("\\", "\\\\");
                msg = msg.Replace("\"", "\'");
                msg = msg.Replace(Environment.NewLine, "\\n");

                //訊息
                strJS.AppendFormat("alert(\"{0}\");{1}", msg, Environment.NewLine);
            }

            if (!string.IsNullOrEmpty(cmd))
            {
                //指令
                strJS.AppendLine(cmd);
            }
            strJS.Append("</script>");

            System.Web.HttpContext.Current.Response.Write(strJS.ToString());
            System.Web.HttpContext.Current.Response.End();
        }

        //訂義結構體
        public enum DateInterval
        {
            Second, Minute, Hour, Day, Week, Month, Quarter, Year
        }

        //多型1，傳入字串
        public static long DateDiff(string Interval, DateTime arg_StartDate, DateTime arg_EndDate)
        {
            DateInterval objDateInterval;
            switch (Interval)
            {
                case "s":
                    objDateInterval = DateInterval.Second;
                    break;
                case "n":
                    objDateInterval = DateInterval.Minute;
                    break;
                case "h":
                    objDateInterval = DateInterval.Hour;
                    break;
                case "d":
                    objDateInterval = DateInterval.Day;
                    break;
                case "w":
                    objDateInterval = DateInterval.Week;
                    break;
                case "m":
                    objDateInterval = DateInterval.Month;
                    break;
                case "q":
                    objDateInterval = DateInterval.Quarter;
                    break;
                case "y":
                    objDateInterval = DateInterval.Year;
                    break;
                default:
                    objDateInterval = DateInterval.Second;
                    break;
            }
            return DateDiff(objDateInterval, arg_StartDate, arg_EndDate);
        }
        //多型2，傳入結構體
        public static long DateDiff(DateInterval arg_Interval, DateTime arg_StartDate, DateTime arg_EndDate)
        {
            long lngDateDiffValue = 0;
            System.TimeSpan objTimeSpan = new System.TimeSpan(arg_EndDate.Ticks - arg_StartDate.Ticks);
            switch (arg_Interval)
            {
                case DateInterval.Second:
                    lngDateDiffValue = (long)objTimeSpan.TotalSeconds;
                    break;
                case DateInterval.Minute:
                    lngDateDiffValue = (long)objTimeSpan.TotalMinutes;
                    break;
                case DateInterval.Hour:
                    lngDateDiffValue = (long)objTimeSpan.TotalHours;
                    break;
                case DateInterval.Day:
                    lngDateDiffValue = (long)objTimeSpan.TotalDays;
                    break;
                case DateInterval.Week:
                    lngDateDiffValue = (long)(objTimeSpan.TotalSeconds / (7 * 24 * 60 * 60)); //一個星期7天
                    break;
                case DateInterval.Month:
                    lngDateDiffValue = (long)(objTimeSpan.TotalSeconds / (30 * 24 * 60 * 60)); //一個月計30天
                    break;
                case DateInterval.Quarter:
                    lngDateDiffValue = (long)(objTimeSpan.TotalSeconds / (90 * 24 * 60 * 60)); //一季計3月
                    break;
                case DateInterval.Year:
                    lngDateDiffValue = (long)(objTimeSpan.TotalSeconds / (365 * 24 * 60 * 60));   //一年計365天
                    break;
            }
            return (lngDateDiffValue);
        }

        /// <summary>
        /// 取得網站 GFC 設定值
        /// </summary>
        public static GFC.Utility.ConfigurationManager.Sections Config
        {
            get { return GFC.Utility.ConfigurationManager.Sections.GetConfig(); }
        }

        public readonly static CommonResource TextResource = new CommonResource();

        /// <summary>
        /// 取得相對應的遊戲名稱
        /// </summary>
        /// <param name="names">遊戲 GameEName, 多組以逗號隔開</param>
        /// <returns></returns>
        public static string GetGameENameMapping(string names)
        {
            string[] sGameENames = names.Split(',');
            StringBuilder sbGameNames = new StringBuilder();
            foreach (string sGameEName in sGameENames)
            {

                sbGameNames.Append("," + Utility.TextResource.GetTextResxByResxKey("GameName", sGameEName));

            }
            if (sbGameNames.Length > 0)
            {
                sbGameNames = sbGameNames.Remove(0, 1);
            }
            return sbGameNames.ToString();
        }

        /// <summary>
        /// 取得相對應的遊戲名稱
        /// </summary>
        /// <param name="names">遊戲 GameEName, 多組以逗號隔開</param>
        /// <returns></returns>
        public static string GetGameENameMapping2(string names)
        {
            // ◉老幣區﹕PirateKing,FruitBar ◉爽幣區﹕PirateKing,水果吧

            string[] gameAreaType = names.Split(' ');
            string[] points;
            string[] uPoints;

            points = gameAreaType[1].Split('﹕')[1].Split(',');

            StringBuilder sbGameNames = new StringBuilder();

            sbGameNames.Append(gameAreaType[1].Split('﹕')[0] + "：");

            foreach (string sPoints in points)
            {
                sbGameNames.Append(Utility.TextResource.GetTextResxByResxKey("GameName", sPoints) + ",");
            }

            if (sbGameNames.Length > 0)
            {
                sbGameNames = sbGameNames.Remove(sbGameNames.Length - 1, 1);
            }

            if (gameAreaType.Length > 2)
            {
                uPoints = gameAreaType[2].Split('﹕')[1].Split(',');

                sbGameNames.Append(" " + gameAreaType[2].Split('﹕')[0] + "：");

                foreach (string sUPoints in uPoints)
                {
                    sbGameNames.Append(Utility.TextResource.GetTextResxByResxKey("GameName", sUPoints) + ",");
                }

                if (sbGameNames.Length > 0)
                {
                    sbGameNames = sbGameNames.Remove(sbGameNames.Length - 1, 1);
                }
            }

            return sbGameNames.ToString();
        }

        /// <summary>
        /// 取得Client IP。
        /// </summary>
        /// <returns></returns>
        public static string GetClientIP()
        {
            Regex reg = new Regex(@"^((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])$");

            string result = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (!string.IsNullOrEmpty(result))
            {
                if (result.IndexOf(".") == -1)
                {
                    result = null;
                }
                else
                {
                    if (result.IndexOf(",") != -1)
                    {
                        result = result.Replace(" ", "").Replace("\"", "");
                        string[] temparyip = result.Split(",;".ToCharArray());
                        for (int i = 0; i < temparyip.Length; i++)
                        {
                            if (reg.IsMatch(temparyip[i])
                                 && temparyip[i].Substring(0, 3) != "10."
                                 && temparyip[i].Substring(0, 7) != "192.168"
                                 && temparyip[i].Substring(0, 7) != "172.16.")
                            {
                                return temparyip[i];
                            }
                        }
                    }
                    else if (reg.IsMatch(result))
                    {
                        return result;
                    }
                    else
                    {
                        result = null;
                    }
                }
            }

            if (string.IsNullOrEmpty(result))
            {
                result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            if (string.IsNullOrEmpty(result))
            {
                result = HttpContext.Current.Request.UserHostAddress;
            }

            return result;
        }

        /// <summary>
        /// FS重讀LuckyMoney開放資訊
        /// </summary>
        public static void FSResetLuckMoney(string frontServerIP)
        {
            GS.ServerCommander.FSCommander.FS_AS_RELOAD_GAME_TO_LMGROUP();
        }

        /// <summary>
        /// 將帳號轉成 帳號******
        /// </summary>
        /// <param name="Account"></param>
        /// <returns></returns>
        public static string GetAccAccountTo(string Account)
        {
            string footer = "";
            string acc = Account;

            if (Account.Length > 3)
            {
                if (Account.Contains("@"))
                {
                    footer = "@" + Account.Split('@')[1];
                    acc = Account.Split('@')[0];
                }

                if (acc.Length > 3)
                {
                    acc = acc.Substring(0, 3) + new string('*', acc.Length - 3);
                }
            }

            return acc + footer;
        }

		// 建立 DataTable (有順序上的問題, 很麻煩要找一下)
		public static DataTable GetDataTable(Dictionary<string, string> dictInfo)
		{
			DataColumn Column;
			DataTable Tables = new DataTable();

			foreach (var KeyValue in dictInfo)
			{
				// 加入欄
				Column = new DataColumn();
				Column.DataType = System.Type.GetType(KeyValue.Value);
				Column.ColumnName = KeyValue.Key;
				Tables.Columns.Add(Column);
			}

			return Tables;
		}
    }
}
