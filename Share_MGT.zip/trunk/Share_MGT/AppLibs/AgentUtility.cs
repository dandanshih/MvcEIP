﻿using GFC.Utilities;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace Share_MGT.AppLibs
{
    /// <summary>
    /// 代理商相關處理。
    /// </summary>
    public class AgentUtility
    {
        /// <summary>
        /// 取得踢除後台代理商的佇列物件。
        /// </summary>
        public static Share_MGT.AppLibs.KickAgentQueue KickAgentQueue { get; set; }

        /// <summary>
        /// 保持在線狀態，如 90 秒未執行則回傳 false。
        /// </summary>
        /// <param name="onlineID">OnlineID。</param>
        /// <returns></returns>
        public static bool KeepOnline(string onlineID)
        {
            bool isOnline = false;

            SqlParameter[] param = 
			{
				new SqlParameter("@OnlineID", onlineID)
			};

            SqlDataReader objDtr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KeepUserOnline",
                param
            );

            if (objDtr.Read())
            {
                // 如果回傳 1 或 4 則進行登出動作
                if (objDtr[0].ToString() == "1" || objDtr[0].ToString() == "4")
                {
                    isOnline = false;
                }
                else
                {
                    isOnline = true;
                }
            }

            objDtr.Close();

            return isOnline;
        }

        /// <summary>
        /// 踢代理商。
        /// </summary>
        /// <param name="qryAgentID">指定要踢的代理商編號。</param>
        /// <param name="execAgentID">執行動作的代理商編號。</param>
        public static void Kick(int qryAgentID, int execAgentID)
        {
            // 加入一筆踢帳號佇列
            AgentUtility.KickAgentQueue.Add(qryAgentID);

            SqlParameter[] param =
			{
				new SqlParameter("@AgentID", qryAgentID.ToString()),
				new SqlParameter("@ExecAgentID", execAgentID.ToString()),
			};

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KickAgent",
                param
            );
        }

        /// <summary>
        /// 代理商帳號 停用/啟用。
        /// </summary>
        /// <param name="qryAgentID">停用/啟用的代理商編號</param>
        /// <param name="pauseType">0:啟用 3:停用</param>
        /// <param name="execAgentID">執行動作的代理商編號。</param>
        /// <param name="frontServerIP">FS IP。</param>
        /// <returns></returns>
        public static ResultStruct Pause(int qryAgentID, int pauseType, int execAgentID, string frontServerIP)
        {
            ResultStruct result = new ResultStruct();

            if (!(new int[] { 0, 3 }).Contains(pauseType))
            {
                result.Code = 999;
                result.Message = "更新失敗";
                return result;
            }

            SqlParameter[] param =
			{
				new SqlParameter("@Result", SqlDbType.SmallInt),
				new SqlParameter("@AgentID", qryAgentID),
				new SqlParameter("@PauseAccount", pauseType),
				new SqlParameter("@IsChained", true),
				new SqlParameter("@ExecAgentID", execAgentID)
			};

            param[0].Direction = ParameterDirection.ReturnValue;

            DataTable kickMember = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AgentAccountDisable",
                param
            ).Tables[0];

            result.Code = int.Parse(param[0].Value.ToString());
            result.Message = (pauseType == 0) ? "啟用" : "停用";

            switch (result.Code)
            {
                case 0:
                    result.Message = result.Message + "成功";

                    // 停用要踢帳號
                    if (pauseType != 0)
                    {
                        MemberUtility.Kick(kickMember, execAgentID, frontServerIP);
                    }
                    break;
                default:
                    result.Message = result.Message + "設定失敗";
                    break;
            }

            return result;
        }

        /// <summary>
        /// 停用押注群組。
        /// </summary>
        /// <param name="qryAgentID">停用/啟用的代理商編號</param>
        /// <param name="pauseType">0:啟用 3:停用</param>
        /// <param name="execAgentID">執行動作的代理商編號。</param>
        /// <param name="frontServerIP">FS IP。</param>
        /// <returns></returns>
        public static ResultStruct PauseBetGroup(int qryAgentID, int pauseType, int execAgentID, string frontServerIP)
        {
            ResultStruct result = new ResultStruct();

            if (!(new int[] { 0, 3 }).Contains(pauseType))
            {
                result.Code = 999;
                result.Message = "更新失敗";
                return result;
            }

            SqlParameter[] param =
			{
				new SqlParameter("@Result", SqlDbType.SmallInt),
				new SqlParameter("@AgentID", qryAgentID.ToString()),
				new SqlParameter("@PauseBet", pauseType),
				new SqlParameter("@IsChained", true),
				new SqlParameter("@ExecAgentID", execAgentID.ToString())
			};

            param[0].Direction = ParameterDirection.ReturnValue;

            DataTable kickMember = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AgentAccountPauseBet",
                param
            ).Tables[0];

            result.Code = int.Parse(param[0].Value.ToString());
            result.Message = (pauseType == 0) ? "啟用" : "停用";

            switch (result.Code)
            {
                case 0:
                    result.Message = result.Message + "成功";

                    // 停用要踢帳號
                    if (pauseType != 0)
                    {
                        MemberUtility.Kick(kickMember, execAgentID, frontServerIP);
                    }
                    break;
                default:
                    result.Message = result.Message + "設定失敗";
                    break;
            }

            return result;
        }

        /// <summary>
        /// 代理商KeyIn。
        /// </summary>
        /// <param name="fromAgentID">來源代理商編號</param>
        /// <param name="toAgentID">目標代理商編號</param>
        /// <param name="points">點數</param>
        /// <param name="execAgentID">執行動作的代理商編號</param>
        /// <returns></returns>
		public static ResultStruct KeyIn(string fromAgentID, string toAgentID, decimal points, int execAgentID, string execAgentIP)
        {
            ResultStruct result = new ResultStruct();

            SqlParameter[] param =
            {
			    new SqlParameter("@ResultID", DbType.Int32),
                new SqlParameter("@FromAgentID", fromAgentID),
			    new SqlParameter("@ToAgentID", toAgentID),
			    new SqlParameter("@ChangePoint", points.ToString()),
			    new SqlParameter("@ExecAgentID", execAgentID.ToString()),
				new SqlParameter("@ExecAgentIP", execAgentIP)
            };

            param[0].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KeyIn_Agent",
                param
            );

            result.Code = int.Parse(param[0].Value.ToString());
            
            switch (result.Code)
            {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "AgentUtility_ResultMessage_Keyin_" + result.Code.ToString()).ToString();
                    break;
                default:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "AgentUtility_ResultMessage_Keyin_def").ToString();
                    break;
            }

            return result;
        }

        /// <summary>
        /// 代理商KeyOut。
        /// </summary>
        /// <param name="fromAgentID">來源代理商編號</param>
        /// <param name="toAgentID">目標代理商編號</param>
        /// <param name="points">點數</param>
        /// <param name="execAgentID">執行動作的代理商編號</param>
        /// <returns></returns>
		public static ResultStruct KeyOut(string fromAgentID, string toAgentID, decimal points, int execAgentID, string execAgentIP)
        {
            ResultStruct result = new ResultStruct();

            SqlParameter[] param =
            {
			    new SqlParameter("@ResultID", DbType.Int32),
                new SqlParameter("@FromAgentID", fromAgentID),
			    new SqlParameter("@ToAgentID", toAgentID),
			    new SqlParameter("@ChangePoint", points.ToString()),
			    new SqlParameter("@ExecAgentID", execAgentID.ToString()),
				new SqlParameter("@ExecAgentIP", execAgentIP),
            };

            param[0].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_KeyOut_Agent",
                param
            );

            result.Code = int.Parse(param[0].Value.ToString());

            switch (result.Code)
            {
                case 0:
                case 1:
                case 2:
                case 3:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "AgentUtility_ResultMessage_KeyOut_" + result.Code.ToString()).ToString();
                    break;
                default:
                    result.Message = HttpContext.GetGlobalResourceObject("Resources", "AgentUtility_ResultMessage_KeyOut_def").ToString();
                    break;
            }

            return result;
        }
    }
}