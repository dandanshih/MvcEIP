﻿
namespace Share_MGT.AppLibs
{
	public enum IIS_Server_Protocol
	{
		// 發送回覆
		IM_QA_Send_Mail		= 256
	}
}