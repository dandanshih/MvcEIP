﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Script.Services;
using System.Web.Services;
using GFC.Utilities;


namespace Share_MGT.AppLibs
{
	/// <summary>
	/// 給查帳號異動LOG裡帳號AutoConpleate使用
	/// </summary>
	[ScriptService]
	[WebService(Namespace = "http://tempuri.org/")]
	[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
	[System.ComponentModel.ToolboxItem(false)]
	public class WSGetAccounts : System.Web.Services.WebService
	{
		/// <summary>
		/// 依據前置字元取得前10筆未刪除的後台人員帳號
		/// </summary>
		/// <param name="prefixText">前置字元</param>
		/// <param name="count"></param>
		/// <returns></returns>
		[WebMethod]
		[ScriptMethod]
		public List<string> GetTechnicalAccounts(string prefixText, int count)
		{
			List<string> lstAccount = new List<string>();
			SqlParameter[] arParms =
			{
				new SqlParameter("@InputStr",prefixText),
				new SqlParameter("@Type","1"),
				new SqlParameter("@Top",count)
			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_QuickQryAccount", arParms);
			while (sdr.Read())
			{
				lstAccount.Add(sdr["AgentAccount"].ToString());
			}
			sdr.Close();
			return lstAccount;
		}

		/// <summary>
		/// 依據前置字元取得前10筆未刪除的會員帳號
		/// </summary>
		/// <param name="prefixText">前置字元</param>
		/// <param name="count"></param>
		/// <returns></returns>
		[WebMethod]
		[ScriptMethod]
		public List<string> GetMemberAccounts(string prefixText, int count)
		{
			List<string> lstAccount = new List<string>();
			SqlParameter[] arParms =
			{
				new SqlParameter("@InputStr",prefixText),
				new SqlParameter("@Type","2"),
				new SqlParameter("@Top",count)
			};

			SqlDataReader sdr = SqlHelper.ExecuteReader(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_R_QuickQryAccount", arParms);
			while (sdr.Read())
			{
				lstAccount.Add(sdr["MemberAccount"].ToString());
			}
			sdr.Close();
			return lstAccount;
		}
	}
}
