﻿using System;
using System.Data;
using System.Web;

namespace Share_MGT.AppLibs
{
	public class AuthorityInfo
	{
		#region Members
		private EnumAuthority m_Authority = EnumAuthority.None;
		#endregion

		#region Constructors
		public AuthorityInfo()
		{
			int MenuAuthority = 0;
			int Authority = 0;

			// 從Session中取出選單資料
			if (HttpContext.Current.Session["MyFunctionList"] != null)
			{
				DataTable objTab = HttpContext.Current.Session["MyFunctionList"] as DataTable;
				string RowFilter = string.Format("FunctionEName='{0}'", this.FunctionEName);
				DataView objVW = new DataView(objTab, RowFilter, "FunctionID", DataViewRowState.CurrentRows);
				if (objVW.Count > 0)
				{
					int.TryParse(objVW[0]["MenuAuthority"].ToString(), out MenuAuthority);
					int.TryParse(objVW[0]["Authority"].ToString(), out Authority);
				}
			}

            System.Enum.TryParse<EnumAuthority>((MenuAuthority & Authority).ToString(), out this.m_Authority);
		}
		#endregion

		#region Properties
		// 選單英文名稱
		public string FunctionEName
		{
			get
			{
				string url = HttpContext.Current.Request.Url.ToString();
				return System.IO.Path.GetFileNameWithoutExtension(url).Split('_')[0];
			}
		}

		// 判斷權限
		public bool CheckAuthority(EnumAuthority AuthType)
		{
			return (this.m_Authority & AuthType) == AuthType;
		}

		// 執行權限
		public bool IsRunable
		{
			get
			{
				return CheckAuthority(EnumAuthority.Run);
			}
		}

		// 新增權限
		public bool IsAddable
		{
			get
			{
				return CheckAuthority(EnumAuthority.Add);
			}
		}

		// 修改權限
		public bool IsEditable
		{
			get
			{
				return CheckAuthority(EnumAuthority.Edit);
			}
		}

		// 刪除權限
		public bool IsDelable
		{
			get
			{
				return CheckAuthority(EnumAuthority.Del);
			}
		}
		#endregion
	}
}