﻿using System;
using Share_MGT.AppLibs;
using System.Data.SqlClient;
using System.Globalization;
using System.Threading;
using System.Linq;
using System.Web;

namespace Share_MGT
{
	public class Global : System.Web.HttpApplication
	{
		public const string SeparatorLevel1 = "#@$";
		public const string SeparatorLevel2 = "$#%";
		public const string SeparatorLevel3 = "%$^";
		public const string SeparatorLevel4 = "^%&";

        public static bool IsMaintain { get; set; }

        private void ReadIsMaintain()
        {
           // SqlDependency DataDependency = new SqlDependency();
          //  DataDependency.OnChange += new OnChangeEventHandler(SqlDependency_Changed);
            using (SqlConnection conn = new SqlConnection(WebConfig.SysConnectionString))
            {
                conn.Open();
                SqlCommand objCmd = new SqlCommand();
                objCmd.Connection = conn;
                objCmd.CommandText = "NSP_AgentWeb_S_SqlDependencyByDowntimeStatus";
                objCmd.CommandType = System.Data.CommandType.StoredProcedure;
                using (objCmd)
                {
                    //DataDependency.AddCommandDependency(objCmd);
                    IsMaintain = Convert.ToInt32(objCmd.ExecuteScalar()) == 1;
                }
            }
        }

		//protected void SqlDependency_Changed(object sender, EventArgs e)
		//{
		//   // SqlDependency dependency = (SqlDependency)sender;
		//  //  dependency.OnChange -= SqlDependency_Changed;
		//	ReadIsMaintain();
		//}

		protected void Application_Start(object sender, EventArgs e)
		{
			log4net.LogManager.GetLogger(typeof(Global)).Debug("Application_Start");

			EO.Web.Runtime.AddLicense(
				"CrWfWZekzRfonNzyBBDInbW2xtu0cqq6xuSvdabw+g7kp+rp2g+9RoGkscuf" +
				"dePt9BDtrNzpz+eupeDn9hnyntzCnrWfWZekzQzrpeb7z7iJWZekscufWZfA" +
				"8g/jWev9ARC8W8Tp/yChWe3pAx7oqOXBs+KtaZmkwOmMQ5ekscufWZekzQzj" +
				"nZf4ChvkdpnX/RTjnsTp/yChWe3pAx7oqOXBs+KtaZmkwOmMQ5ekscufWZek" +
				"zQzjnZf4ChvkdpnY8g3SrentAc2fr9z2BBTup7SmyNmvW5ezz7iJWZekscuf" +
				"WZfA8g/jWev9ARC8W8v29hDVotz7s8v1nun3+hrtdpm7v9uhWabCnrWfWZek" +
				"scufWbPl9Q+frfD09uihhuzwBRTPmt7ps8v1nun3+hrtdpm7v9uhWabCnrWf" +
				"WZekscufWbPl9Q+frfD09uihfNjw9hnjmummsSHkq+rtABm8W66ywc2faLWR" +
				"m8ufWZekscufddjo9cvzsufpzs3CmuPw8wzipJmkBxDxrODz/+ihcKW0s8uu" +
				"d4SOscufWZekscu7mtvosR/4qdzBs+zJes/ZARfumtvpA82fr9z2BBTup7Sm" +
				"yNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8W7vt8hfuoJmkBxDxrODz/+ih" +
				"cKW0s8uud4SOscufWZekscu7mtvosR/4qdzBs/7vpeD4BRDxW5f69h3youby" +
				"zs22Z6emsdq9RoGkscufWZeksefgndukBSTvnrSm3gzypNzo1g/orZmkBxDx" +
				"rODz/+ihcKW0s8uud4SOscufWZekscu7mtvosR/4qdzBs/LxotumsSHkq+rt" +
				"ABm8W66ywc2faLWRm8ufWZekscufddjo9cvzsufpzs3CqOPzA/vonOLpA82f" +
				"r9z2BBTup7SmyNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8W8r09hfrfN/p" +
				"9Bbkq5mkBxDxrODz/+ihcKW0s8uud4SOscufWZekscu7mtvosR/4qdzBs/Dj" +
				"ouvzA82fr9z2BBTup7SmyNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8W8Dx" +
				"8hLkk+bz/s2fr9z2BBTup7SmyNmvW5ezz7iJWZekscufWZfA8g/jWev9ARC8" +
				"W7vzCBnrqNjo9h2hWe3pAx7oqOXBs+KtaZmkwOmMQ5ekscufWZekzQzjnZf4" +
				"ChvkdpnK/Rrgrdz2s8v1nun3+hrtdpm7v9uhWabCnrWfWZekzdrgpePzCOmM" +
				"Q5ekscu7rODr/wzzrunpzxXXrNv81wHPqs7NygPWsMXYASHtasjBzueurODr" +
				"/wzzrunpz7iJdabw+g7kp+rpz7iJdePt9BDtrNzCng==");
             
            // 從資料庫載入資源檔
            Utility.TextResource.LoadData();

            // 加入 DB 監控
           // SqlDependency.Start(WebConfig.SysConnectionString);
            ReadIsMaintain();
		}

		protected void Session_Start(object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{
            //string[] SupportedLanguages = { "en-us", "zh-cn" };
            string[] SupportedLanguages = { "zh-cn" , "en-us" };

            HttpCookie languageCookie = Request.Cookies["Culture"];
            string language = "";

            if (languageCookie == null)
            {
                if (Request.UserLanguages != null)
                {
                    string[] userLanguages = Request.UserLanguages;
                    int index;

                    for (int i = 0; i < userLanguages.Length; i++)
                    {
                        index = Array.IndexOf(SupportedLanguages, userLanguages[i].ToLower());
                        if (index >= 0)
                        {
                            language = SupportedLanguages[index];
                            break;
                        }
                    }
                }

                if (language == "")
                    language = SupportedLanguages[0];
            }
            else
            {
                language = languageCookie.Value;
            }

            CultureInfo info = new CultureInfo(language);
            Thread.CurrentThread.CurrentCulture = info;
            Thread.CurrentThread.CurrentUICulture = info;
		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{

		}

		protected void Application_End(object sender, EventArgs e)
		{
			log4net.LogManager.GetLogger(typeof(Global)).Debug("Application_End");

         //   SqlDependency.Stop(WebConfig.SysConnectionString);
        }

        public override void Init()
        {
            base.Init();

            Application.Lock();
            if (AgentUtility.KickAgentQueue == null)
            {
                AgentUtility.KickAgentQueue = Share_MGT.AppLibs.KickAgentQueue.Instance;
            }
            Application.UnLock();
        }
	}
}