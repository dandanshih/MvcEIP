﻿using System.Web;

namespace Share_MGT {
    /// <summary>
    ///SysCommander 的摘要描述
    /// </summary>
    public class SysCommander : IHttpHandler {

        public void ProcessRequest(HttpContext context) {
            context.Response.ContentType = "text/plain";

            switch (context.Request["Cmd"]) {
                case "101":
                    // 從資料庫載入資源檔
                    Utility.TextResource.LoadData();
                    context.Response.Write("TextResource Reloaded");
                    break;
                default:
                    context.Response.Write("Unknow Command");
                    break;
            }

        }

        public bool IsReusable {
            get {
                return false;
            }
        }
    }
}