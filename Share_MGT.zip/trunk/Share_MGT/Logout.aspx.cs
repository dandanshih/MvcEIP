﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT
{
	public partial class Logout : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (Session["AUser"] != null)
			{
                AUser auser=Session["AUser"] as AUser;
                try
                {

                    // 20110510 Phil: 清除踢帳號佇列
                    AgentUtility.KickAgentQueue.Remove(int.Parse(auser.ExecAgentID));

                    SqlHelper.ExecuteNonQuery(
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_A_Logout",
                        new SqlParameter("@OnlineID", auser.OnlineID));
                    Session.Abandon();
                    Session.RemoveAll();
                }
                catch
                { }

                
			}

			Response.Redirect("~/Login.aspx");
		}
	}
}