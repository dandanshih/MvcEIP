﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Web;
using System.Threading;
using System.Globalization;

namespace Share_MGT
{
	public partial class Login : System.Web.UI.Page
	{
		#region private

		/// <summary>
		/// 檢查帳號密碼, 成功會傳回True。
		/// </summary>
		/// <param name="userName">帳號。</param>
		/// <param name="userPassword">密碼。</param>
		private string CheckLogin(string userName, string userPassword, ref string defaultPage)
		{
			// 登入前先清除 Session
			//Session.Abandon();
			//Session.RemoveAll();
			
			string sCheckLoginMsg = "";

			SqlParameter[] param = 
			{
				new SqlParameter("@ErrorMsg", SqlDbType.NVarChar, 50),
				new SqlParameter("@Account", userName),
				new SqlParameter("@Password", userPassword),
				new SqlParameter("@IP", Request.UserHostAddress == "::1" ? "127.0.0.1" : Request.UserHostAddress),
				new SqlParameter("@SessionID", Session.SessionID),
				new SqlParameter("@Host", "")
			};

			param[0].Direction = ParameterDirection.Output;

			SqlDataReader objDtr = SqlHelper.ExecuteReader(WebConfig.ConnectionString,
															CommandType.StoredProcedure,
                                                            "NSP_AgentWeb_A_Login",
															param);

			if (objDtr.Read())
			{

				// 將管理者登入的資料存成 Session
				AUser AUser = new AUser();

				AUser.IsLogin = true;
				AUser.AgentID = objDtr["AgentID"].ToString();
				AUser.AgentAccount = objDtr["AgentAccount"].ToString();
				AUser.AgentNickName = objDtr["AgentNickName"].ToString();
				AUser.AgentGroupID = objDtr["AgentGroupID"].ToString();
				AUser.ExecAgentID = objDtr["ExecAgentID"].ToString();
				AUser.ExecAgentAccount = objDtr["ExecAgentAccount"].ToString();
				AUser.ExecAgentNickName = objDtr["ExecAgentNickName"].ToString();
				AUser.ExecAgentGroupID = objDtr["ExecAgentNickName"].ToString();
				AUser.OnlineID = objDtr["OnlineID"].ToString();
				AUser.DefaultWebPage = objDtr["DefaultWebPage"].ToString();
				AUser.FrontServerIP = objDtr["FrontServerIP"].ToString();
				//AUser.GroupEName = objDtr["GroupEName"].ToString();
				AUser.IsWebAdmin = bool.Parse(objDtr["IsWebAdmin"].ToString());
                AUser.IsShadowAccount = bool.Parse(objDtr["IsShadow"].ToString());
				//AUser.ReviewAuthority = int.Parse(objDtr["ReviewAuthority"].ToString());

				// 將 Class 放在 Session 供其他頁面使用
				Session["AUser"] = AUser;

                // 輸出預設頁
                defaultPage = AUser.DefaultWebPage;

                // 20110510 Phil: 清除可能遺留的踢帳號佇列
                AgentUtility.KickAgentQueue.Remove(int.Parse(AUser.ExecAgentID));
			}
			else
			{
                switch(param[0].Value.ToString())
                {
                    case "Login_DuplicateOnline":
                    case "Login_NameOrPassErr":
                    case "Login_PauseAccount":
                    case "Login_UserIP_NotAllowed":
                        sCheckLoginMsg = GetLocalResourceObject(param[0].Value.ToString()).ToString();
                        break;
                    default:
                        sCheckLoginMsg = GetLocalResourceObject("Login_NameOrPassErr").ToString();
                        break;
                }

				// 如果登入失敗就清除 Session
				//Session.Abandon();
				//Session.RemoveAll();				
			}

			objDtr.Close();

			return sCheckLoginMsg;
		}

		#endregion

		#region protected

		protected void Page_Load(object sender, EventArgs e)
		{
			// 設定預設按鈕
			Page.Form.DefaultButton = btnLogin.UniqueID;

#if (Debug)
			string strJScript = "document.getElementById('txtPassword').value='123456';"
                                + "document.getElementById('txtAccount').value='rd';"
								+ "document.getElementById('txtVerifyCode').value='123456';";
			System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "rdlogin", strJScript, true);
			SqlConnection conn = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString);
			Page.Header.Title += " (Debug in " + conn.DataSource + ")";
			conn.Dispose();
			Page.SetFocus("txtPassword");
#endif

			// 已經有登入過了，而且 Server 尚未登出的情況下，就直接跳至 default 頁面
			if (Session["AUser"] != null)
			{
				Response.Redirect("~/Index.aspx", false);
				return;
			}

			// 如果有 QueryString 的話，要重新再讀取一次，讓 QueryString 消失
			if (Request.QueryString.Count != 0)
			{
				Response.Redirect("~/Login.aspx", false);
				return;
			}

            Page.SetFocus("txtAccount");

            if (!IsPostBack)
            {
                Response.Cookies.Add(new HttpCookie("Culture", rblCulture.SelectedValue));
                CultureInfo culture = new System.Globalization.CultureInfo(rblCulture.SelectedValue);
                Thread.CurrentThread.CurrentUICulture = culture;
                Thread.CurrentThread.CurrentCulture = culture;

                switch (Thread.CurrentThread.CurrentUICulture.Name.ToString().ToLower())
                {
                    case "en-us":
                    case "zh-tw":
					case "zh-cn":
                        rblCulture.SelectedValue = Thread.CurrentThread.CurrentUICulture.Name.ToString();
                        break;
                    default:
                        rblCulture.SelectedValue = "zh-cn";
                        break;
                }
            }
            //Page.Header.Title = GetGlobalResourceObject("Resources", "ManagerSystem").ToString();
		}

		/// <summary>
		/// 驗證使用者的帳號與密碼。
		/// </summary>
        protected void btnLogin_Click(object sender, EventArgs e)
		{
			if (Session["gif"] == null)
			{
				Server.Transfer("~/Login.aspx");
				return;
			}

			string sCheckLoginMsg = "";
            string defaultPage = "";

			// 開發模式直接給檢查碼
#if (Debug)   
                txtVerifyCode.Text = Session["gif"].ToString();
#endif

			// 確認驗證碼
			if (Session["gif"].ToString().ToUpper() != txtVerifyCode.Text.ToUpper())
			{
				Page.SetFocus("txtPassword");
				txtVerifyCode.Text = "";
				lblMessage.Text = GetLocalResourceObject("ResultMessage_VerifyError").ToString();
				lblMessage.Visible = true;
				return;
			}

            sCheckLoginMsg = CheckLogin(txtAccount.Text, txtPassword.Text, ref defaultPage);
			if (sCheckLoginMsg != "")
			{
                lblMessage.Text = sCheckLoginMsg;
				lblMessage.Visible = true;
				txtVerifyCode.Text = "";
				Page.SetFocus("txtPassword");
				return;
			}

            Response.Redirect(defaultPage);
		}

        /// <summary>
        /// 切換語系事件。
        /// </summary>
        protected void rblCulture_SelectedIndexChanged(object sender, EventArgs e)
        {
            Response.Cookies.Add(new HttpCookie("Culture", rblCulture.SelectedValue));
            CultureInfo culture = new System.Globalization.CultureInfo(rblCulture.SelectedValue);
            Thread.CurrentThread.CurrentUICulture = culture;
            Thread.CurrentThread.CurrentCulture = culture;
            Server.Transfer(Request.Path);
        }
		#endregion
	}
}