﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.I
{
	public partial class I04_Edit : FormBase
    {
        // 取得要修改的資料
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
				// 從網址取得由前一頁帶過來的 SID, 也就是桶金 ID
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_AppGroup_List",
                    new SqlParameter("@AppGroupNo", sid),
                    new SqlParameter("@AgentID", this.AUser.AgentID)
                );

                //繫結到相關欄位
                if (objDtr.Read())
                {
                    // 分桶群組ID
                    tbx_AppGroupID.Text = objDtr["AppGroupID"].ToString();
                    // 分桶群組金鑰
                    tbx_AppGroupSecret.Text = objDtr["AppGroupSecret"].ToString();
                    // 分桶群組名稱
                    tbx_AppGroupName.Text = objDtr["AppGroupName"].ToString();
                    // 允許IP
                    tbx_AllowIP.Text = objDtr["AllowIP"].ToString();
                    // Memo
                    tbx_Memo.Text = objDtr["Memo"].ToString();
                }

                objDtr.Close();
            }
        }

        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                // SQL參數
                SqlParameter[] param = new SqlParameter[] 
				{
					// 分桶群組No
                    new SqlParameter("@AppGroupNo", sid),
					// 分桶群組ID
					new SqlParameter("@AppGroupID", tbx_AppGroupID.Text),
                    // 分桶群組金鑰
                    new SqlParameter("@AppGroupSecret", tbx_AppGroupSecret.Text),
					// 分桶群組名稱
					new SqlParameter("@AppGroupName", tbx_AppGroupName.Text),
                    // 允許IP
					new SqlParameter("@AllowIP", tbx_AllowIP.Text),
					// Memo
					new SqlParameter("@Memo", tbx_Memo.Text),
                    // AgentID (沒這個會出事)
					new SqlParameter("@AgentID", 1),
                    // 檢查成不成功 (1才是成功)
                    new SqlParameter("@intResult", SqlDbType.Int),
                    // 成不成功的訊息
                    new SqlParameter("@strOutstring", SqlDbType.VarChar, 50)
				};
                param[param.Length - 2].Direction = ParameterDirection.Output;
                param[param.Length - 1].Direction = ParameterDirection.Output;

                // 執行
                SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AppGroup_Edit", param);

                int intResult = (int)param[param.Length - 2].Value;
                string strOutstring = param[param.Length - 1].Value.ToString();

                if (intResult == 1)
                {
                    try
                    {
                        string getUrl = string.Format("{0}/Common/Other/UpdateCommand?CmdID={1}", WebConfig.SeriesUrl, 102);
                        var request = new GFC.Net.WebRequestHandler(getUrl);
                        request.ReceiveTimeout = 5000;
                        request.SendTimeout = 5000;
                        request.HttpGet();
                    }
                    catch (Exception ex)
                    {
                        log4net.LogManager.GetLogger(typeof(I04_Edit)).Error("執行通知更新介接資訊時發生Error, Message:" + ex.Message, ex);
                    }
                    Response.Write("<script>alert('修改成功');location.href='I04.aspx';</script>");
                }
                else
                {
					Response.Write("<script>alert('intResult: " + intResult + "\nstrOutstring: " + strOutstring + "');location.href='I04.aspx';</script>");
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("I04.aspx");
        }
    }
}