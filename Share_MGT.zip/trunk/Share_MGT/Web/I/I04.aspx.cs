﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.I
{
	public partial class I04 : FormBase
    {
        private void BindAppGroupList()
        {
            gv_AppGroupList.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AppGroup_List",
                new SqlParameter("@AgentID", this.AUser.AgentID)
            ).Tables[0];
            gv_AppGroupList.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindAppGroupList();
            }
        }
    }
}