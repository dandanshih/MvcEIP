﻿// 從表24變表23

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.I
{
	public partial class I06 : FormBase
    {
        private void BindData()
        {
			int AppNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@AppNo", AppNo),
                new SqlParameter("@AgentID", this.AUser.AgentID),
                new SqlParameter("@GameID", "-1")
            };
            DataTable objTab = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_App_Game_List",
                objParam).Tables[0];
            var query = from item in objTab.AsEnumerable()
                        group item by item["AppNo"] into Gp
                        select new
                        {
                            AppNo = Gp.Key,
                            AppID = Gp.Max(obj => obj["AppID"].ToString()),
                            AppName = Gp.Max(obj => obj["AppName"].ToString()), 
                            GameNameData = Gp.Aggregate(string.Empty, (data, obj) =>
                                {
                                    if (obj["IsMgt"].ToString() == "1")
                                    {
                                        if (!string.IsNullOrEmpty(data))
                                        {
                                            data += "、";
                                        }
                                        data += Utility.TextResource.GetTextResxByMessageID("GameName", obj["GameID"]).ToString();
                                    }
                                    return data;
                                })
                        };
            gv_DataList.DataSource = query;
            gv_DataList.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
			if (!IsPostBack)
			{
				DataTable DBData = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_Agent_App_List"
					, new SqlParameter("@AgentID", this.AUser.AgentID)
				).Tables[0];
				ddl_AppGroup.DataSource = DBData;
				ddl_AppGroup.DataBind();
				// 記錄 AppID Map AppGroupNo
				Dictionary<int, int> dictMap = new Dictionary<int, int>();
				for (int Index = 0; Index < DBData.Rows.Count; Index++)
				{
					int AppNo = System.Convert.ToInt32(DBData.Rows[Index]["AppNo"]);
					int AppGroupNo = System.Convert.ToInt32 (DBData.Rows[Index]["AppGroupNo"]);
					dictMap[AppNo] = AppGroupNo;
				}
				ViewState["AppMap"] = dictMap;
			}
        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            BindData();
        }

		protected void btn_Add_Click(object sender, EventArgs e)
		{
			Response.Redirect("I06_Add.aspx");
		}

		// 取得更新表單
		DataTable GetEditDT(object AppNo, int GameID, int IsMgt)
		{
			DataTable Tables = Utility.GetDataTable(new Dictionary<string, string>() {
				{"AppNo", "System.Int32"}
				, {"GameID", "System.Int32"}
				, {"IsMgt", "System.Int32"}
				});

			// 做塞入資料的動作
			DataRow NewRow = Tables.NewRow();
			NewRow["GameID"] = GameID;
			NewRow["AppNo"] = System.Convert.ToInt32 (AppNo);
			NewRow["IsMgt"] = IsMgt;
			Tables.Rows.Add(NewRow);

			return Tables;
		}
		// 按下 Table 的行為
        protected void gv_DataList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
			int AppNo = System.Convert.ToInt32(e.CommandArgument.ToString());
			Dictionary<int, int> dictMap = ( Dictionary<int, int> )ViewState["AppMap"];
			int AppGroupNo = dictMap[AppNo];
			if (e.CommandName == "OnDelete")
			{
				DataTable DBdt = null;
				// 取得所有區域
				// 取得自己的遊戲
				DBdt = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_App_Game_List"
					, new SqlParameter("@AppNo", AppNo)
					, new SqlParameter("@AgentID", this.AUser.AgentID)
				).Tables[0];
				// 更新資料
				for (int Index = 0; Index < DBdt.Rows.Count; Index++)
				{
					int GameID = System.Convert.ToInt32(DBdt.Rows[Index]["GameID"]);
					DataTable dt = GetEditDT(AppNo, GameID, 0);
					// 做 db 的操作
					SqlParameter[] objParam = new SqlParameter[]
					{
						new SqlParameter("@AppGame", SqlDbType.Structured)
						, new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
					};
					objParam[0].Value = dt;
					SqlHelper.ExecuteNonQuery(
						WebConfig.ConnectionString,
						CommandType.StoredProcedure,
						"NSP_AgentWeb_A_App_Game_Edit"
						, objParam);
				}
				// 重新更新畫面
				BindData();
			}
			else if (e.CommandName == "OnEdit")
			{
				string strHttp = string.Format("I06_Edit.aspx?AppNo={0}&AppGroupNo={1}", AppNo, AppGroupNo);
				Response.Redirect(strHttp);
			}
        }
    }
}
