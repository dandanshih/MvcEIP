﻿// 表21
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.I
{
	public partial class I03 : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			// 分桶群組的資料
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataBind();
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		// 做新增的動作
		protected void btn_Add_Click(object sender = null, EventArgs e = null)
		{
			Response.Redirect("I03_Add.aspx");
		}

		// 做查詢的動作
		protected void btn_Query_Click(object sender = null, EventArgs e = null)
		{
			// 送過去做查詢
			int AppGroupNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			// 查詢資料做綁定的動作
			DataTable DBdt = null;
			// 取得所有的遊戲
			DBdt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_GameAreaType_List"
				, new SqlParameter("@AppGroupNo", AppGroupNo)
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			DataTable Tables = Utility.GetDataTable (new Dictionary<string,string> ()
			{
				{"AppGroupNo", "System.Int32"}
				, {"AppGroupName", "System.String"}
				, {"AppGroupNo_JPList", "System.String"}
			});
			Dictionary<string, string> dictMap = new Dictionary<string, string>();
			for (int Index = 0; Index < DBdt.Rows.Count; Index++)
			{
				DataRow NewRow = Tables.NewRow();
				NewRow["AppGroupNo"] = DBdt.Rows[Index]["AppGroupNo"];
				string strAppGroupNo = DBdt.Rows[Index]["AppGroupNo"].ToString();
				NewRow["AppGroupName"] = DBdt.Rows[Index]["AppGroupName"];
				NewRow["AppGroupNo_JPList"] = "";
				if (dictMap.ContainsKey(strAppGroupNo) == false)
				{
					Tables.Rows.Add(NewRow);
					dictMap[strAppGroupNo] = "";
				}
				dictMap[strAppGroupNo] += string.Format(",[{0}] {1}", DBdt.Rows[Index]["GameAreaType"], DBdt.Rows[Index]["Value_ZHTW"]);
			}
			for (int Index = 0; Index < Tables.Rows.Count; Index++)
			{
				string strAppGroupNo = Tables.Rows[Index]["AppGroupNo"].ToString();
				Tables.Rows[Index]["AppGroupNo_JPList"] = dictMap[strAppGroupNo].Substring(1);
			}
			gv_DataList.DataSource = Tables;
			gv_DataList.DataBind();
		}

		protected void grdList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			int AppGroupNo = System.Convert.ToInt32(e.CommandArgument.ToString());
			if (e.CommandName == "OnDelete")
			{
				// 取得所有的區域
				DataTable DBdt = null;
				// 取得現有的
				DBdt = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_AppGroup_GameAreaType_List"
					, new SqlParameter("@AppGroupNo", AppGroupNo)
					, new SqlParameter("@AgentID", this.AUser.AgentID)
				).Tables[0];
				// 一個一個刪除掉
				for (int Index = 0; Index < DBdt.Rows.Count; Index++)
				{
					int GameAreaType = System.Convert.ToInt32(DBdt.Rows[Index]["GameAreaType"]);
					// 做存檔的動作
					DataTable Tables = Utility.GetDataTable(new Dictionary<string, string>()
					{
						{"AppGroupNo", "System.Int32"}
						, {"GameAreaType", "System.Int32"}
						, {"IsMgt", "System.Int32"}
					});
					// 做塞入資料的動作
					DataRow NewRow = Tables.NewRow();
					NewRow["AppGroupNo"] = AppGroupNo;
					NewRow["GameAreaType"] = GameAreaType;
					NewRow["IsMgt"] = 0;
					Tables.Rows.Add(NewRow);
					// 做 db 的操作
					SqlParameter[] objParam = new SqlParameter[]
					{
						new SqlParameter("@AppGroupGameAreaType", SqlDbType.Structured)
						, new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
					};
					objParam[0].Value = Tables;
					SqlHelper.ExecuteNonQuery(
						WebConfig.ConnectionString
						, CommandType.StoredProcedure
						, "NSP_AgentWeb_A_AppGroup_GameAreaType_Edit"
						, objParam);
				}
				// 重導回這一頁
				btn_Query_Click();
			}
			else if (e.CommandName == "OnEdit")
			{
				string strHttp = string.Format("I03_Edit.aspx?AppGroupNo={0}", AppGroupNo);
				// 做轉址的動作
				Response.Redirect(strHttp);
			}
		}
	}
}