﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.I
{
	public partial class I06_Add : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			// 先綁定資料
			DataTable DBData = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_App_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataSource = DBData;
			ddl_AppGroup.DataBind();
			// 記錄 AppID Map AppGroupNo
			Dictionary<int, int> dictMap = new Dictionary<int, int>();
			for (int Index = 0; Index < DBData.Rows.Count; Index++)
			{
				int AppNo = System.Convert.ToInt32(DBData.Rows[Index]["AppNo"]);
				int AppGroupNo = System.Convert.ToInt32(DBData.Rows[Index]["AppGroupNo"]);
				dictMap[AppNo] = AppGroupNo;
			}
			ViewState["AppMap"] = dictMap;
			// 下拉選單改變要做處理
			OnSelectedGameChanged();
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		// 當選擇改變時
		protected void OnSelectedGameChanged(object sender = null, EventArgs e = null)
		{
			// 先取得畫面上的資料
			int AppNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			Dictionary<int, int> dictMap = (Dictionary<int, int>)ViewState["AppMap"];
			int AppGroupNo = dictMap[AppNo];
			// 再去取得所有的遊戲
			DataTable DBdt = null;
			// 取得所有的遊戲
			DBdt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_Game_List"
				, new SqlParameter("@AppGroupNo", AppGroupNo)
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			cbl_GameGroupList.DataSource = DBdt;
			cbl_GameGroupList.DataBind();
			// 取得自己的遊戲
			DBdt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_App_Game_List"
				, new SqlParameter("@AppNo", AppNo)
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			List<int> listGame = new List<int>();
			for (int Index = 0; Index < DBdt.Rows.Count; Index++)
			{
				lbl_GroupName.Text = DBdt.Rows[Index]["AppName"].ToString();
				int GameID = System.Convert.ToInt32(DBdt.Rows[Index]["GameID"]);
				listGame.Add(GameID);
			}
			for (int Index = 0; Index < cbl_GameGroupList.Items.Count; Index++)
			{
				int Value = System.Convert.ToInt32(cbl_GameGroupList.Items[Index].Value);
				if (listGame.Contains(Value) == true)
				{
					cbl_GameGroupList.Items[Index].Selected = true;
				}
				else
				{
					cbl_GameGroupList.Items[Index].Selected = false;
				}
			}
		}

		#region 存檔的動作
		// 取得更新表單
		DataTable GetEditDT(object AppNo, int GameID, int IsMgt)
		{
			DataTable Tables = Utility.GetDataTable(new Dictionary<string, string>() {
				{"AppNo", "System.Int32"}
				, {"GameID", "System.Int32"}
				, {"IsMgt", "System.Int32"}
				});

			// 做塞入資料的動作
			DataRow NewRow = Tables.NewRow();
			NewRow["GameID"] = GameID;
			NewRow["AppNo"] = System.Convert.ToInt32(AppNo);
			NewRow["IsMgt"] = IsMgt;
			Tables.Rows.Add(NewRow);

			return Tables;
		}

		DataTable GetEditDataTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AppGroupNo";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GameID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GroupID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "IsMgt";
			Tables.Columns.Add(Column);

			return Tables;
		}

		// 做存檔的動作
		protected void btn_Save_Click(object sender, EventArgs e)
		{
			// 先取得畫面上的資料
			int AppNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			Dictionary<int, int> dictMap = (Dictionary<int, int>)ViewState["AppMap"];
			int AppGroupNo = dictMap[AppNo];
			// 做存檔的動作
			//bool IsAll = cbl_GameGroupList.Items[0].Selected;
			bool IsAll = false;
			// 做畫面處理
			for (int Index = 0; Index < cbl_GameGroupList.Items.Count; Index++)
			{
				int GameID = System.Convert.ToInt32(cbl_GameGroupList.Items[Index].Value);
				bool IsSelected = cbl_GameGroupList.Items[Index].Selected;
				int IsMgt = 0;
				if (IsAll == true || IsSelected == true)
					IsMgt = 1;
				DataTable dt = GetEditDT(AppNo, GameID, IsMgt);
				// 做 db 的操作
				SqlParameter[] objParam = new SqlParameter[]
                {
                    new SqlParameter("@AppGame", SqlDbType.Structured)
                    , new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
                };
				objParam[0].Value = dt;
				SqlHelper.ExecuteNonQuery(
					WebConfig.ConnectionString
					, CommandType.StoredProcedure
					, "NSP_AgentWeb_A_App_Game_Edit"
					, objParam);
			}
			// 做更新畫面的動作
			OnSelectedGameChanged();
		}

		#endregion

		// 做取消的動作
		protected void btn_Cancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("I06.aspx");
		}
	}
}