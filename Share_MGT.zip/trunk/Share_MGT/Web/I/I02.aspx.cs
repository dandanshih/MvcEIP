﻿// 表20 : 分桶群組 Gruop 設定

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.I
{
	public partial class I02 : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataBind();
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		DataTable GetDataTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AppGroupNo";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "AppGroupName";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "GameName";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "GameList";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GameID";
			Tables.Columns.Add(Column);

			return Tables;
		}

		// 做新增的動作
		protected void btn_Add_Click(object sender=null, EventArgs e=null)
		{
			Response.Redirect("I02_Add.aspx");
		}

		// 做查詢的動作
		protected void btn_Query_Click(object sender=null, EventArgs e=null)
		{
			// 取得所選擇的動作
			int AppGroupNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			// 把資料綁定上去
			DataTable dt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_GameGroup_List",
				new SqlParameter("@AppGroupNo", AppGroupNo)
			).Tables[0];
			// 一筆一筆抓資料
			Dictionary<string, string> GameListMap = new Dictionary<string, string>();
			DataTable Data = GetDataTable();
			for (int Index = 0; Index < dt.Rows.Count; Index++)
			{
				// 產生要放的資料
				DataRow NewRow = Data.NewRow();
				// Copy 想要的資料
				NewRow["AppGroupNo"] = dt.Rows[Index]["AppGroupNo"];
				NewRow["AppGroupName"] = dt.Rows[Index]["AppGroupName"];
				NewRow["GameName"] = dt.Rows[Index]["GameName"];
				NewRow["GameID"] = dt.Rows[Index]["GameID"];
				string GameID = NewRow["GameID"].ToString();
				int GroupID = System.Convert.ToInt32 ( dt.Rows[Index]["GroupID"]);
				string strValueZHTW = dt.Rows[Index]["Value_ZHTW"].ToString();
				// 組合想要的資料
				if (GameListMap.ContainsKey(GameID) == false)
				{
					GameListMap[GameID] = "";
					Data.Rows.Add(NewRow);
				}
				GameListMap[GameID] += string.Format(",{0}-{1}", GroupID, strValueZHTW);
			}
			// 把資料給綁定上去
			for (int Index = 0; Index < Data.Rows.Count; Index++)
			{
				string GameID = Data.Rows[Index]["GameID"].ToString();
				string GameList = GameListMap[GameID].Substring(1);
				Data.Rows[Index]["GameList"] = GameList;
			}
			tb_Game.DataSource = Data;
			tb_Game.DataBind();
		}

		DataTable GetEditDataTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AppGroupNo";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GameID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GroupID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "IsMgt";
			Tables.Columns.Add(Column);

			return Tables;
		}

		protected void grdList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				// 上面的刪除結果
				case "Delete":
					{
						// 做刪除的動作
						string[] arrToken = e.CommandArgument.ToString().Split(',');
						int GameID = System.Convert.ToInt32(arrToken[0]);
						int AppGroupNo = System.Convert.ToInt32(arrToken[1]);
						// 再拿一次資料
						DataTable DBData = SqlHelper.ExecuteDataset(
							WebConfig.ConnectionString,
							CommandType.StoredProcedure,
							"NSP_AgentWeb_A_AppGroup_GameGroup_List"
							, new SqlParameter("@AppGroupNo", AppGroupNo)
							, new SqlParameter("@GameID", GameID)
						).Tables[0];
						//List<int> listOwner = new List<int>();
						for (int Index = 0; Index < DBData.Rows.Count; Index++)
						{
							//listOwner.Add(System.Convert.ToInt32( DBData.Rows[Index]["GroupID"]));
							int GroupID = System.Convert.ToInt32 (DBData.Rows[Index]["GroupID"]);
							DataTable EditDT = GetEditDataTable();
							DataRow NewRow = EditDT.NewRow();
							NewRow["AppGroupNo"] = AppGroupNo;
							NewRow["GameID"] = GameID;
							NewRow["GroupID"] = GroupID;
							NewRow["IsMgt"] = 0;
							EditDT.Rows.Add(NewRow);
							// 做 db 的操作
							SqlParameter[] objParam = new SqlParameter[]
							{
								new SqlParameter("@AppGroupGameGroup", SqlDbType.Structured),
								new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
							};
							objParam[0].Value = EditDT;
							SqlHelper.ExecuteNonQuery(
								WebConfig.ConnectionString,
								CommandType.StoredProcedure,
								"NSP_AgentWeb_A_AppGroup_GameGroup_Edit",
								objParam);
						}
						// [problem 應該要能夠按自己] 重導回這一頁
						Response.Redirect("I02.aspx");
						break;
					}
				case "Edit":
					{
						// 做轉址的動作
						string[] arrToken = e.CommandArgument.ToString().Split(',');
						string strHttp = string.Format("I02_Edit.aspx?GameID={0}&AppGroupNo={1}", arrToken[0], arrToken[1]);
						Response.Redirect(strHttp);
						break;
					}
				default:
					{
						break;
					}
			}
		}
	}
}