﻿// 表23分桶內遊戲 Group 設定

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.I
{
	public partial class I05 : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_App_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataBind();
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		DataTable GetDataTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AppNo";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "AppID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "AppName";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "GameList";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GameID";
			Tables.Columns.Add(Column);

			return Tables;
		}

		// 做新增的動作
		protected void btn_Add_Click(object sender = null, EventArgs e = null)
		{
			Response.Redirect("I05_Add.aspx");
		}

		// 做查詢的動作
		protected void btn_Query_Click(object sender = null, EventArgs e = null)
		{
			// 取得所選擇的動作
			int AppNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			// 把資料綁定上去
			DataTable dt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_App_Game_List"
				, new SqlParameter("@AppNo", AppNo)
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			// 一筆一筆抓資料
			Dictionary<string, string> GameListMap = new Dictionary<string, string>();
			DataTable Data = GetDataTable();
			for (int Index = 0; Index < dt.Rows.Count; Index++)
			{
				// 產生要放的資料
				DataRow NewRow = Data.NewRow();
				// Copy 想要的資料
				NewRow["AppNo"] = dt.Rows[Index]["AppNo"];
				NewRow["AppID"] = dt.Rows[Index]["AppID"];
				NewRow["AppName"] = dt.Rows[Index]["AppName"];
				NewRow["GameID"] = dt.Rows[Index]["GameID"];
				string GameID = NewRow["GameID"].ToString();
				string GameName = dt.Rows[Index]["GameName"].ToString();
				// 組合想要的資料
				if (GameListMap.ContainsKey(GameID) == false)
				{
					GameListMap[GameID] = "";
					Data.Rows.Add(NewRow);
				}
				GameListMap[GameID] += string.Format(",{0}", GameName);
			}
			// 把資料給綁定上去
			for (int Index = 0; Index < Data.Rows.Count; Index++)
			{
				string GameID = Data.Rows[Index]["GameID"].ToString();
				string GameList = GameListMap[GameID].Substring(1);
				Data.Rows[Index]["GameList"] = GameList;
			}
			tb_Game.DataSource = Data;
			tb_Game.DataBind();
		}

		protected void grdList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				// 上面的刪除結果
				case "Delete":
					{
						// [problem 應該要能夠按自己] 重導回這一頁
						Response.Redirect("I02.aspx");
						break;
					}
				case "Edit":
					{
						// 做轉址的動作
						string[] arrToken = e.CommandArgument.ToString().Split(',');
						string strHttp = string.Format("I02_Edit.aspx?GameID={0}&AppGroupNo={1}", arrToken[0], arrToken[1]);
						Response.Redirect(strHttp);
						break;
					}
				default:
					{
						break;
					}
			}
		}
	}
}