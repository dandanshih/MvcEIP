﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;
using GFC;

namespace Share_MGT.Web.I
{
	public partial class I07 : FormBase
	{
		private void BindCurrencyList()
		{
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_App_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataBind();
			// 取得幣值
			ddl_Currency.Items.Add(new ListItem()
			{
				Text = "全部",
				Value = "-1"
			});
			ddl_Currency.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_S_Currency_List"
			).Tables[0];
			ddl_Currency.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindCurrencyList();
			}
		}

		// 做查詢的動作
		protected void btn_Query_Click(object sender, EventArgs e)
		{
			UpdateHistory();
		}

		void UpdateHistory ()
		{
			// 取得相關資料
			int AppNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			int CurrencyNo = System.Convert.ToInt32(ddl_Currency.SelectedValue);
			// 跑 DB 取結果
			DataTable DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_App_LobbyGameAreaType_List"
				, new SqlParameter("@AppNo", AppNo)
				, new SqlParameter("@CurrencyNo", CurrencyNo)
				, new SqlParameter("@GameAreaType", -1)
			).Tables[0];
			tb_Game.DataSource = DBdt;
			tb_Game.DataBind();
		}

		protected void grdList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			if (e.CommandName == "OnEdit")
			{
				string[] arrToken = e.CommandArgument.ToString().Split(',');
				int AppNo = System.Convert.ToInt32(arrToken[0]);
				int CurrencyNo = System.Convert.ToInt32(arrToken[1]);
				string strHttp = string.Format("I07_Edit.aspx?AppNo={0}&CurrencyNo={1}", AppNo, CurrencyNo);
				Response.Redirect(strHttp);
			}

			// 做刪除的動作
			else if (e.CommandName == "OnDelete")
			{
				string[] arrToken = e.CommandArgument.ToString().Split(',');
				int AppNo = System.Convert.ToInt32(arrToken[0]);
				int CurrencyNo = System.Convert.ToInt32(arrToken[1]);
				// 跑 DB 取結果
				SqlHelper.ExecuteDataset
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_App_LobbyGameAreaType_Delete"
					, new SqlParameter("@AppNo", AppNo)
					, new SqlParameter("@CurrencyNo", CurrencyNo)
					, new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
				);
				UpdateHistory();
			}
		}

		// 做新增的動作
		protected void btn_Add_Click(object sender, EventArgs e)
		{
			string strHttp = string.Format("I07_Edit.aspx?AppNo={0}&CurrencyNo={1}", -1, -1);
			Response.Redirect(strHttp);
		}
	}
}