﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.I
{
	public partial class I01 : FormBase
    {
        private void BindAppGroupList()
        {
            ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AppGroup_List",
                new SqlParameter("@AgentID", this.AUser.AgentID)
            ).Tables[0];
            ddl_AppGroup.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindAppGroupList();
            }
        }
    }
}
