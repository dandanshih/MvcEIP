﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.I
{
	public partial class I01_Edit : FormBase
    {
        private void BindAppGroupList()
        {
            ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AppGroup_List",
                new SqlParameter("@AgentID", this.AUser.AgentID)
            ).Tables[0];
            ddl_AppGroup.DataBind();
        }

        // 取得要修改的資料
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                // TODO 加入驗證是否可進此修改頁
                if (string.IsNullOrEmpty(Request.QueryString["sid"]))
                {
                    Response.Redirect("AppSetting.aspx");
                    return;
                }
                BindAppGroupList();

                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_App_List",
                    new SqlParameter("@AppNo", sid)
                );

                //繫結到相關欄位
                if (objDtr.Read())
                {
                    // 分桶群組名稱
                    ddl_AppGroup.SelectedValue = objDtr["AppGroupNo"].ToString();
                    // 分桶ID
                    tbx_AppID.Text = objDtr["AppID"].ToString();
                    // 分桶名稱
                    tbx_AppName.Text = objDtr["AppName"].ToString();
                    // 分桶金鑰
                    tbx_AppSecret.Text = objDtr["AppSecret"].ToString();
                    // 分桶類型
                    rbl_AppType.SelectedValue = objDtr["AppTypeID"].ToString();
                    // 開通模式: 開洗分Url
                    tbx_KeyInOutUrl.Text = objDtr["KeyInOutUrl"].ToString();
                    // 開通模式: 登出Url
                    tbx_LogoutUrl.Text = objDtr["LogoutUrl"].ToString();
                    // 開通模式: 查詢點數Url
                    tbx_QueryPointUrl.Text = objDtr["QueryPointUrl"].ToString();
                    // 開洗分模式: 開分Url
                    tbx_Type2KeyinUrl.Text = objDtr["Type2_KeyinUrl"].ToString();
                    // 開洗分模式: 洗分Url
                    tbx_Type2KeyoutUrl.Text = objDtr["Type2_KeyoutUrl"].ToString();
                    // 開洗分模式: 登入Url
                    tbx_Type2LoginUrl.Text = objDtr["Type2_LoginUrl"].ToString();
                    // 開洗分模式: 登出Url
                    tbx_Type2LogoutUrl.Text = objDtr["Type2_LogoutUrl"].ToString();
                    // 開洗分模式: 序列化方式 (1: Json, 2: Xml)
                    rbl_SerializerType.SelectedValue = objDtr["Type2_SerializerType"].ToString();
                    // Memo
                    tbx_Memo.Text = objDtr["Memo"].ToString();
                }

                objDtr.Close();
                rbl_AppType_SelectedIndexChanged(this, e);
            }
        }

        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;
                
                // SQL參數
                SqlParameter[] param = new SqlParameter[] 
				{
                    // 分桶No
                    new SqlParameter("@AppNo", sid),
					// 分桶群組No
                    new SqlParameter("@AppGroupNo", ddl_AppGroup.SelectedValue),
					// 分桶ID
					new SqlParameter("@AppID", tbx_AppID.Text),
					// 分桶名稱
					new SqlParameter("@AppName", tbx_AppName.Text),
					// 分桶金鑰
					new SqlParameter("@AppSecret", tbx_AppSecret.Text),
                    // 分桶類型
                    new SqlParameter("@AppTypeID", rbl_AppType.SelectedValue),
                    // 開通模式: 開洗分Url
					new SqlParameter("@KeyInOutUrl", tbx_KeyInOutUrl.Text),
					// 開通模式: 登出Url
					new SqlParameter("@LogoutUrl", rbl_AppType.SelectedValue == "1" ? tbx_LogoutUrl.Text : WebConfig.SeriesUrl + "/conversion/conversionlogout"),
                    // 開通模式: 查詢點數Url
                    new SqlParameter("@QueryPointUrl", tbx_QueryPointUrl.Text),
                    // 開洗分模式: 開分Url
                    new SqlParameter("@Type2_KeyinUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2KeyinUrl.Text : string.Empty),
                    // 開洗分模式: 洗分Url
                    new SqlParameter("@Type2_KeyoutUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2KeyoutUrl.Text : string.Empty),
                    // 開洗分模式: 登入Url
                    new SqlParameter("@Type2_LoginUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2LoginUrl.Text : string.Empty),
                    // 開洗分模式: 登出Url
                    new SqlParameter("@Type2_LogoutUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2LogoutUrl.Text : string.Empty),
                    // 開洗分模式: 序列化方式 (1: Json, 2: Xml)
                    new SqlParameter("@Type2_SerializerType", rbl_SerializerType.SelectedValue),
					// Memo
					new SqlParameter("@Memo", tbx_Memo.Text),
                    // AgentID
					new SqlParameter("@AgentID", this.AUser.AgentID),
                    // 檢查成不成功 (1才是成功)
                    new SqlParameter("@intResult", SqlDbType.Int),
                    // 成不成功的訊息
                    new SqlParameter("@strOutstring", SqlDbType.VarChar, 50)
				};
                param[param.Length - 2].Direction = ParameterDirection.Output;
                param[param.Length - 1].Direction = ParameterDirection.Output;

                // 執行
                SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_App_Edit", param);

                int intResult = (int)param[param.Length - 2].Value;
                string strOutstring = param[param.Length - 1].Value.ToString();

                if (intResult == 1)
                {
                    try
                    {
                        string getUrl = string.Format("{0}/Common/Other/UpdateCommand?CmdID={1}", WebConfig.SeriesUrl, 102);
                        var request = new GFC.Net.WebRequestHandler(getUrl);
                        request.ReceiveTimeout = 5000;
                        request.SendTimeout = 5000;
                        request.HttpGet();
                    }
                    catch (Exception ex)
                    {
                        log4net.LogManager.GetLogger(typeof(I01_Edit)).Error("執行通知更新介接資訊時發生Error, Message:" + ex.Message, ex);
                    }

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertOK", "alert('修改成功');location.href='AppSetting.aspx';", true);
                    //Response.Write("<script>alert('修改成功');location.href='AppSetting.aspx';</script>");
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertErr", "alert('" + strOutstring + "');", true);
                    //Response.Write("<script>alert('intResult: " + intResult + "\nstrOutstring: " + strOutstring + "');location.href='AppSetting.aspx';</script>");
                }

                //Response.Redirect("AppSetting.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }

        protected void rbl_AppType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rbl_AppType.SelectedValue == "1")
            {
                ph_Type1.Visible = true;
                ph_Type2.Visible = false;
            }
            else if (rbl_AppType.SelectedValue == "2")
            {
                ph_Type1.Visible = false;
                ph_Type2.Visible = true;
            }
            else
            {
                ph_Type1.Visible = false;
                ph_Type2.Visible = false;
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("I01.aspx");
        }
    }
}