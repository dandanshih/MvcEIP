﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;
using GFC;

namespace Share_MGT.Web.I
{
	public partial class I07_Edit : FormBase
	{
		private void BindCurrencyList()
		{
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_App_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataBind();
			// 取得幣值
			ddl_Currency.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_S_Currency_List"
			).Tables[0];
			ddl_Currency.DataBind();
			// 更新資料
			UpdateJPList();
		}

		void UpdateJPList ()
		{
			ddl_JP.Items.Clear();
			int AppNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			// 大廳JP設定
			ddl_JP.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_G_GameAreaType_List_ByApp"
				, new SqlParameter("@AppNo", AppNo)
			).Tables[0];
			ddl_JP.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindCurrencyList();
				// 處理下拉選單的功能
				int AppNo = int.TryParse(Request.QueryString["AppNo"], out AppNo) ? AppNo : -1;
				int CurrencyNo = int.TryParse(Request.QueryString["CurrencyNo"], out CurrencyNo) ? CurrencyNo : -1;
				if (AppNo == -1 && CurrencyNo == -1)
					return;
				// 做下拉選單的處理
				for (int Index = 0; Index < ddl_AppGroup.Items.Count; Index++)
				{
					int Value = System.Convert.ToInt32(ddl_AppGroup.Items[Index].Value);
					if (Value == AppNo)
					{
						ddl_AppGroup.SelectedIndex = Index;
						break;
					}
				}
				for (int Index = 0; Index < ddl_Currency.Items.Count; Index++)
				{
					int Value = System.Convert.ToInt32(ddl_Currency.Items[Index].Value);
					if (Value == CurrencyNo)
					{
						ddl_Currency.SelectedIndex = Index;
						break;
					}
				}
				ddl_AppGroup.Enabled = false;
				ddl_Currency.Enabled = false;
			}
		}

		protected void OnAppNoChange(object sender, EventArgs e)
		{
			UpdateJPList();
		}

		// 傳回首頁
		protected void btn_Cancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("I07.aspx");
		}

		protected void btn_Save_Click(object sender, EventArgs e)
		{
			int AppNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			int CurrencyNo = System.Convert.ToInt32(ddl_Currency.SelectedValue);
			int GameAreaType = System.Convert.ToInt32(ddl_JP.SelectedValue);
			// 跑 DB 取結果
			SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_App_LobbyGameAreaType_Edit"
				, new SqlParameter("@AppNo", AppNo)
				, new SqlParameter("@CurrencyNo", CurrencyNo)
				, new SqlParameter("@GameAreaType", GameAreaType)
				, new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
			);
		}
	}
}