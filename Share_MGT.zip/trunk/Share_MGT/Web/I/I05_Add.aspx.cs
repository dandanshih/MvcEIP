﻿// 表23分桶內遊戲 Group 設定

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.I
{
	public partial class I05_Add : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}