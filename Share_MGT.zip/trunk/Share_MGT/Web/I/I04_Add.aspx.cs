﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.I
{
	public partial class I04_Add : FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                // SQL參數
                SqlParameter[] param = new SqlParameter[] 
				{
					// 分桶群組ID
					new SqlParameter("@AppGroupID", tbx_AppGroupID.Text),
                    // 分桶群組金鑰
                    new SqlParameter("@AppGroupSecret", tbx_AppGroupSecret.Text),
					// 分桶群組名稱
					new SqlParameter("@AppGroupName", tbx_AppGroupName.Text),
                    // 允許IP
					new SqlParameter("@AllowIP", tbx_AllowIP.Text),
					// Memo
					new SqlParameter("@Memo", tbx_Memo.Text),
                    // AgentID (沒這個會出事)
					new SqlParameter("@AgentID", 1),
                    // 檢查成不成功 (1才是成功)
                    new SqlParameter("@intResult", SqlDbType.Int),
                    // 成不成功的訊息
                    new SqlParameter("@strOutstring", SqlDbType.VarChar, 50)
				};
                param[param.Length - 2].Direction = ParameterDirection.Output;
                param[param.Length - 1].Direction = ParameterDirection.Output;

                // 執行
                SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AppGroup_Add", param);

                int intResult = (int)param[param.Length - 2].Value;
                string strOutstring = param[param.Length - 1].Value.ToString();

                if (intResult == 1)
                {
                    try
                    {
                        string getUrl = string.Format("{0}/Common/Other/UpdateCommand?CmdID={1}", WebConfig.SeriesUrl, 102);
                        var request = new GFC.Net.WebRequestHandler(getUrl);
                        request.ReceiveTimeout = 5000;
                        request.SendTimeout = 5000;
                        request.HttpGet();
                    }
                    catch (Exception ex)
                    {
                        log4net.LogManager.GetLogger(typeof(I04_Add)).Error("執行通知更新介接資訊時發生Error, Message:" + ex.Message, ex);
                    }
					Response.Write("<script>alert('新增成功');location.href='I04.aspx';</script>");
                }
                else
                {
					Response.Write("<script>alert('intResult: " + intResult + "\nstrOutstring: " + strOutstring + "');location.href='I04.aspx';</script>");
                }
                
                //Response.Redirect("AppGroupSetting.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
			Response.Redirect("I04.aspx");
        }
    }
}