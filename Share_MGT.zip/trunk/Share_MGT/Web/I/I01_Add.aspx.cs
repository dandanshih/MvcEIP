﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Web.UI;

namespace Share_MGT.Web.I
{
	public partial class I01_Add : FormBase
    {
        private void BindAppGroupList()
        {
            ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AppGroup_List",
                new SqlParameter("@AgentID", this.AUser.AgentID)
            ).Tables[0];
            ddl_AppGroup.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindAppGroupList();
            }
        }

        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            try
            {
                // SQL參數
                SqlParameter[] param = new SqlParameter[] 
				{
                    // 分桶群組No
                    new SqlParameter("@AppGroupNo", ddl_AppGroup.SelectedValue),
					// 分桶ID
					new SqlParameter("@AppID", tbx_AppID.Text),
					// 分桶名稱
					new SqlParameter("@AppName", tbx_AppName.Text),
					// 分桶金鑰
					new SqlParameter("@AppSecret", tbx_AppSecret.Text),
                    // 分桶類型
                    new SqlParameter("@AppTypeID", rbl_AppType.SelectedValue),
                    // 開通模式: 開洗分Url
					new SqlParameter("@KeyInOutUrl", tbx_KeyInOutUrl.Text),
					// 開通模式: 登出Url
					new SqlParameter("@LogoutUrl", rbl_AppType.SelectedValue == "1" ? tbx_LogoutUrl.Text : WebConfig.SeriesUrl + "/conversion/conversionlogout"),
                    // 開通模式: 查詢點數Url
                    new SqlParameter("@QueryPointUrl", tbx_QueryPointUrl.Text),
                    // 開洗分模式: 開分Url
                    new SqlParameter("@Type2_KeyinUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2KeyinUrl.Text : string.Empty),
                    // 開洗分模式: 洗分Url
                    new SqlParameter("@Type2_KeyoutUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2KeyoutUrl.Text : string.Empty),
                    // 開洗分模式: 登入Url
                    new SqlParameter("@Type2_LoginUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2LoginUrl.Text : string.Empty),
                    // 開洗分模式: 登出Url
                    new SqlParameter("@Type2_LogoutUrl", rbl_AppType.SelectedValue == "2" ? tbx_Type2LogoutUrl.Text : string.Empty),
                    // 開洗分模式: 序列化方式 (1: Json, 2: Xml)
                    new SqlParameter("@Type2_SerializerType", rbl_SerializerType.SelectedValue),
					// Memo
					new SqlParameter("@Memo", tbx_Memo.Text),
                    // AgentID
					new SqlParameter("@AgentID", this.AUser.AgentID),
                    // 檢查成不成功 (1才是成功)
                    new SqlParameter("@intResult", SqlDbType.Int),
                    // 成不成功的訊息
                    new SqlParameter("@strOutstring", SqlDbType.VarChar, 50)
				};
                param[param.Length - 2].Direction = ParameterDirection.Output;
                param[param.Length - 1].Direction = ParameterDirection.Output;

                // 執行
                SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_App_Add", param);

                int intResult = (int)param[param.Length - 2].Value;
                string strOutstring = param[param.Length - 1].Value.ToString();

                if (intResult == 1)
                {
                    try
                    {
                        string getUrl = string.Format("{0}/Common/Other/UpdateCommand?CmdID={1}", WebConfig.SeriesUrl, 102);
                        var request = new GFC.Net.WebRequestHandler(getUrl);
                        request.ReceiveTimeout = 5000;
                        request.SendTimeout = 5000;
                        request.HttpGet();
                    }
                    catch (Exception ex)
                    {
                        log4net.LogManager.GetLogger(typeof(I01_Add)).Error("執行通知更新介接資訊時發生Error, Message:" + ex.Message, ex);
                    }

                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alertOK", "alert('新增成功');location.href='AppSetting.aspx';", true);
                    //Response.Write("<script>alert('新增成功');location.href='AppSetting.aspx';</script>");
                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alertErr", "alert('" + strOutstring + "');", true);
                    //Response.Write("<script>alert('intResult: " + intResult + "\nstrOutstring: " + strOutstring + "');location.href='AppSetting.aspx';</script>");
                }

                //Response.Redirect("AppSetting.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }

        protected void rbl_AppType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rbl_AppType.SelectedValue == "1")
            {
                ph_Type1.Visible = true;
                ph_Type2.Visible = false;
            }
            else if (rbl_AppType.SelectedValue == "2")
            {
                ph_Type1.Visible = false;
                ph_Type2.Visible = true;
            }
            else
            {
                ph_Type1.Visible = false;
                ph_Type2.Visible = false;
            }
        }

        protected void btn_Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("AppSetting.aspx");
        }
    }
}