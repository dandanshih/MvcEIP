﻿// 表21
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.I
{
	public partial class I03_Add : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			// 分桶群組的資料
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataBind();
			// 做畫面上的更新
			OnSelectedGameChanged();
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		// 當選擇改變時
		protected void OnSelectedGameChanged(object sender = null, EventArgs e = null)
		{
			// 先取得 AppGroupNo
			int AppGroupNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			// 取得所有的區域
			DataTable DBdt = null;
			// 取得所有的遊戲
			DBdt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_G_GameAreaType_List"
			).Tables[0];
			cbl_GameGroupList.DataSource = DBdt;
			cbl_GameGroupList.DataBind();
			// 取得現有的
			DBdt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_GameAreaType_List"
				, new SqlParameter("@AppGroupNo", AppGroupNo)
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			List<string> listOwer = new List<string>();
			for (int Index = 0; Index < DBdt.Rows.Count; Index++)
			{
				string GameAreaType = DBdt.Rows[Index]["GameAreaType"].ToString();
				listOwer.Add(GameAreaType);
			}
			for (int Index = 0; Index < cbl_GameGroupList.Items.Count; Index++)
			{
				string GameAreaType = cbl_GameGroupList.Items[Index].Value;
				if (listOwer.Contains(GameAreaType) == true)
				{
					cbl_GameGroupList.Items[Index].Selected = true;
				}
				else
				{
					cbl_GameGroupList.Items[Index].Selected = false;
				}
			}
		}

		// 做存檔的動作
		protected void btn_Save_Click(object sender, EventArgs e)
		{
			// 先取得 AppGroupNo
			int AppGroupNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			// 取得畫面上的結果
			for (int Index = 0; Index < cbl_GameGroupList.Items.Count; Index++)
			{
				int GameAreaType = System.Convert.ToInt32(cbl_GameGroupList.Items[Index].Value);
				int IsMgt = 0;
				if (cbl_GameGroupList.Items[Index].Selected == true)
				{
					IsMgt = 1;
				}
				// 做存檔的動作
				DataTable Tables = Utility.GetDataTable ( new Dictionary<string,string> ()
				{
					{"AppGroupNo", "System.Int32"}
					, {"GameAreaType", "System.Int32"}
					, {"IsMgt", "System.Int32"}
				});
				// 做塞入資料的動作
				DataRow NewRow = Tables.NewRow();
				NewRow["AppGroupNo"] = AppGroupNo;
				NewRow["GameAreaType"] = GameAreaType;
				NewRow["IsMgt"] = IsMgt;
				Tables.Rows.Add(NewRow);
				// 做 db 的操作
				SqlParameter[] objParam = new SqlParameter[]
                {
                    new SqlParameter("@AppGroupGameAreaType", SqlDbType.Structured)
                    , new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
                };
				objParam[0].Value = Tables;
				SqlHelper.ExecuteNonQuery(
					WebConfig.ConnectionString
					, CommandType.StoredProcedure
					, "NSP_AgentWeb_A_AppGroup_GameAreaType_Edit"
					, objParam);
			}

			// 做更新畫面的動作
			OnSelectedGameChanged();
		}

		// 做取消的動作
		protected void btn_Cancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("I03.aspx");
		}
	}
}
