﻿// 表20的新增功能

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.I
{
	public partial class I02_Add : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			// 分桶群組
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_List"
				,new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataBind();
			// 遊戲名稱
			ddl_AppGame.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_G_GetGameList"
			).Tables[0];
			ddl_AppGame.DataBind();
			OnSelectedGameChanged();
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		// 當選擇改變時
		protected void OnSelectedGameChanged(object sender = null, EventArgs e=null)
		{
			// 取得現在的遊戲值
			int GameID = System.Convert.ToInt32(ddl_AppGame.SelectedValue);
			DataTable DBData = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_GameGroup_List"
				, new SqlParameter("@GameID", GameID)
			).Tables[0];
			// 把資料綁上去
			DataTable Data = GetDataTable();
			DataRow NewRow = Data.NewRow();
			NewRow["GroupID"] = -1;
			NewRow["GroupName"] = "全部";
			Data.Rows.Add(NewRow);
			// 一行一行把資料塞進去
			for (int Index = 0; Index < DBData.Rows.Count; Index++)
			{
				NewRow = Data.NewRow();
				NewRow["GroupID"] = DBData.Rows[Index]["GroupID"];
				NewRow["GroupName"] = DBData.Rows[Index]["Value_ZHTW"];
				Data.Rows.Add(NewRow);
			}
			cbl_GameGroupList.DataSource = Data;
			cbl_GameGroupList.DataBind();
			// 取得所選的資料
			int GroupID = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			DBData = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AppGroup_GameGroup_List"
				, new SqlParameter("@AppGroupNo", GroupID)
				, new SqlParameter("@GameID", GameID)
			).Tables[0];
			List<string> listOwner = new List<string>();
			for (int Index = 0; Index < DBData.Rows.Count; Index++)
			{
				listOwner.Add(DBData.Rows[Index]["GroupID"].ToString());
			}
			// 設定選擇
			//cbl_GameGroupList.Items[0].Selected = true;
			for (int Index = 0; Index < cbl_GameGroupList.Items.Count; Index++)
			{
				if (listOwner.Contains(cbl_GameGroupList.Items[Index].Value))
				{
					cbl_GameGroupList.Items[Index].Selected = true;
				}
				else
				{
					cbl_GameGroupList.Items[Index].Selected = false;
				}
			}
		}

		DataTable GetDataTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GroupID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "GroupName";
			Tables.Columns.Add(Column);

			return Tables;
		}

		DataTable GetEditDataTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AppGroupNo";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GameID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "GroupID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "IsMgt";
			Tables.Columns.Add(Column);

			return Tables;
		}

		// 做存檔的動作
		protected void btn_Save_Click(object sender, EventArgs e)
		{
			// 取得畫面上所選取的項目
			int AppGroupNo = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			int GameID = System.Convert.ToInt32(ddl_AppGame.SelectedValue);
			bool IsAll = cbl_GameGroupList.Items[0].Selected;
			for (int Index = 1; Index < cbl_GameGroupList.Items.Count; Index++)
			{
				// 做存檔的動作
				int GroupID = System.Convert.ToInt32(cbl_GameGroupList.Items[Index].Value);
				bool IsSelected = cbl_GameGroupList.Items[Index].Selected;
				int IsMgt = 0;
				if (IsAll == true || IsSelected == true)
					IsMgt = 1;
				DataTable dt = GetEditDataTable();
				DataRow NewRow = dt.NewRow();
				NewRow["GameID"] = GameID;
				NewRow["AppGroupNo"] = AppGroupNo;
				NewRow["GroupID"] = GroupID;
				NewRow["IsMgt"] = IsMgt;
				dt.Rows.Add(NewRow);
				// 做 db 的操作
				SqlParameter[] objParam = new SqlParameter[]
                {
                    new SqlParameter("@AppGroupGameGroup", SqlDbType.Structured),
                    new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
                };
				objParam[0].Value = dt;
				SqlHelper.ExecuteNonQuery(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_AppGroup_GameGroup_Edit",
					objParam);
			}

			// 做更新畫面的動作
			OnSelectedGameChanged();
		}

		// 做取消的動作
		protected void btn_Cancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("I02.aspx");
		}
	}
}