﻿using GFC.Net;
using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace Share_MGT.Web.A
{
    public partial class A07 : FormBase
    {
        private void ReloadMaintain(int cmdID)
        {
            string MaintainUrls = ConfigurationManager.AppSettings["ReloadMaintainUrl"];
            string[] urls = MaintainUrls.Split(';');
            foreach (string url in urls)
            {
                string cmd = string.Format("CmdID={0}", cmdID);
                WebRequestHandler request = new WebRequestHandler(url + "?" + cmd);
                request.ReceiveTimeout = 5000;
                request.SendTimeout = 5000;
                request.HttpGet();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGameWebShutdown_Click(object sender, EventArgs e)
        {
            try
            {
                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_SetDowntimeStatus",
                    new SqlParameter("@IsEnabled", "1")
                );
                ReloadMaintain(101);
                ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('設定成功!');", true);
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('設定失敗!');", true);
            }
        }

        protected void btnGameWebOpen_Click(object sender, EventArgs e)
        {
            try
            {
                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_SetDowntimeStatus",
                    new SqlParameter("@IsEnabled", "0")
                );
                ReloadMaintain(101);
                ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('設定成功!');", true);
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "Alert", "alert('設定失敗!');", true);
            }
        }
    }
}