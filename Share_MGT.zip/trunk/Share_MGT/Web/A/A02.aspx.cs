﻿using System;
using GFC.Web.WebControls;

namespace Share_MGT.Web.A
{
	public partial class A02 : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}

        protected void gv_FunctionList_DataBound(object sender, EventArgs e)
        {
            // 依權限顯示修改連結
            ((TBGridView)sender).Columns[0].Visible = this.Authority.IsEditable;
        }
	}
}