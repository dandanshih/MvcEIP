﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using Share_MGT.AppUserControls.Other;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.A
{
	public partial class A03 : Share_MGT.AppLibs.FormBase
    {
        #region Field
        private DataTable tab_Menu = null;
        private DataTable tab_Author_List = null;
        #endregion

        #region Private Method
        /// <summary>
        /// 讀取代理商群組資料。
        /// </summary>
        private void LoadAgentGroup()
        {
            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AgentGroup_List"
            );

            ddl_AgentGroup.DataSource = objDr;
            ddl_AgentGroup.DataBind();

            objDr.Close();
        }

        /// <summary>
        /// 繫結資料。
		/// </summary>
        private void BindPermission()
		{
			//取出選單資料
            tab_Menu = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_AgentGroup_Authority_List",
                new SqlParameter("@AgentID", AUser.AgentID),
                new SqlParameter("@AgentGroupID", ddl_AgentGroup.SelectedValue)
            ).Tables[0];

            // 取出權限種類資料
            tab_Author_List = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_S_AgentWeb_Authority_List"
            ).Tables[0];

			DataView objDV = new DataView(tab_Menu, "ParentFunctionID=0", "FunctionOrder", DataViewRowState.CurrentRows);
			rptMainMenu.DataSource = objDV;
			rptMainMenu.DataBind();
		}

        /// <summary>
        /// 取得權限的設定。
        /// </summary>
        /// <returns></returns>
        private DataTable GetAgentAuthority()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("FunctionID", typeof(int));
            dt.Columns.Add("GrantPower", typeof(int));
            dt.Columns.Add("DenyPower", typeof(int));

            // 主選單
            foreach (RepeaterItem item in rptMainMenu.Items)
            {
                RepeaterItemCollection subItems = (item.FindControl("rptSubMenu") as Repeater).Items;

                // 子選單
                foreach (RepeaterItem subItem in subItems)
                {
                    int functionID = int.Parse((subItem.FindControl("hidFunctionID") as HiddenField).Value);
                    int grantPower = 0;
                    int denyPower = 0;

                    RepeaterItemCollection authorityItems = (subItem.FindControl("rptAuthority") as Repeater).Items;
                    foreach (RepeaterItem authorityItem in authorityItems)
                    {
                        ThreeStateCheckBox threeCheckBox = authorityItem.FindControl("ThreeStateCheckBox1") as ThreeStateCheckBox;

                        if (threeCheckBox.Visible)
                        {
                            switch (threeCheckBox.Value)
                            {
                                case "Grant":
                                    grantPower += threeCheckBox.Power;
                                    break;
                                case "Deny":
                                    denyPower += threeCheckBox.Power;
                                    break;
                            }
                        }
                    }

                    dt.Rows.Add(functionID, grantPower, denyPower);
                }
            }

            return dt;
        }
        
        /// <summary>
        /// 更新權限。
        /// </summary>
        private ResultStruct UpdatePermission()
        {
            ResultStruct result = new ResultStruct();

            DataTable authority = GetAgentAuthority();

            if (authority.Rows.Count != 0)
            {
                SqlParameter[] param =
                {
                    new SqlParameter("@AgentGroupID", ddl_AgentGroup.SelectedValue),
                    new SqlParameter("@AgentID", AUser.AgentID),
                    new SqlParameter("@Source", authority)
                };

                result.Code = int.Parse(SqlHelper.ExecuteScalar
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_AgentGroup_Authority_EditByTable",
                    param
                ).ToString());

                if (result.Code == 0)
                {
                    result.Message = "設定完成";
                }
                else
                {
                    result.Message = "設定失敗";
                }
            }
            else
            {
                result.Code = -1;
                result.Message = "設定失敗";
            }

            return result;
        }
        #endregion

        #region Protected Method
        protected void Page_Load(object sender, EventArgs e)
        {
            // 第一次載入時執行
            if (!IsPostBack)
            {
                LoadAgentGroup();
                BindPermission();
            }
        }

        /// <summary>
        /// 使用者群組下拉選單 SelectedIndexChanged 事件。
        /// </summary>
        protected void ddl_AgentGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindPermission();
        }

        /// <summary>
        /// 主選單 ItemDataBound 事件 (ParentFunctionID = 0)。
        /// 將每個主選單底下的項目列表繫結到 子選單 中。
        /// </summary>
		protected void rptMainMenu_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataView objDV = new DataView(tab_Menu, "ParentFunctionID=" + ((DataRowView)e.Item.DataItem).Row["FunctionID"].ToString(), "FunctionOrder", DataViewRowState.CurrentRows);
                e.Item.FindControl("trMainMenu").Visible = (objDV.Count != 0);

                Repeater rptSubMenu = ((Repeater)e.Item.FindControl("rptSubMenu"));
                rptSubMenu.DataSource = objDV;
                rptSubMenu.DataBind();
			}
		}

        /// <summary>
        /// 子選單 ItemDataBound 事件。
        /// 繫結權限列表。
        /// </summary>
		protected void rptSubMenu_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                // 該子選單的編號
                int functionID = int.Parse(DataBinder.Eval(e.Item.DataItem, "FunctionID").ToString());
                // 取出該子選單的權限Flag
                int menuAuthority = int.Parse(DataBinder.Eval(e.Item.DataItem, "MenuAuthority").ToString());
                // 群組允許權限
                int grantPower = int.Parse(DataBinder.Eval(e.Item.DataItem, "GrantPower").ToString());
                // 群組禁止權限
                int denyPower = int.Parse(DataBinder.Eval(e.Item.DataItem, "DenyPower").ToString());

                DataTable dt = new DataTable();
                dt.Columns.Add("Text", typeof(string));
                dt.Columns.Add("Value", typeof(string));
                dt.Columns.Add("Power", typeof(int));
                dt.Columns.Add("Enabled", typeof(bool));

                // 篩選出權限列表與設定相關屬性
                foreach (DataRow row in tab_Author_List.Rows)
                {
                    int flagPower = int.Parse(row["FlagPower"].ToString());

                    if ((menuAuthority & flagPower) == flagPower)
                    {
                        bool enabled = (menuAuthority & flagPower) == flagPower;
                        string val = "";

                        if ((denyPower & flagPower) == flagPower)
                        {
                            val = "Deny";
                        }
                        else if ((grantPower & flagPower) == flagPower)
                        {
                            val = "Grant";
                        }
                        else
                        {
                            val = "Revoke";
                        }

                        dt.Rows.Add(row["AuthorityName"].ToString(), val, flagPower, enabled);
                    }
                }

                if (dt.Rows.Count > 0)
                {
                    Repeater rptAuthority = e.Item.FindControl("rptAuthority") as Repeater;
                    rptAuthority.DataSource = dt;
                    rptAuthority.DataBind();
                }
			}
		}

		/// <summary>
        /// 更新群組資料。
		/// </summary>
		protected void btnAdd_Click(object sender, EventArgs e)
		{
            if ((this.IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            ResultStruct result = UpdatePermission();

            ScriptManager.RegisterStartupScript(Page, GetType(), "msg", "alert('" + result.Message + "');", true);
		}

        #endregion
    }
}