﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.A
{
	public partial class A04_Edit : FormBase
	{
		#region 上半區的功能
		// 按下修改按鈕時的的動作
		protected void btn_Edit_Click(object sender, EventArgs e)
		{
			int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
			int agid = int.TryParse(Request.QueryString["agid"], out agid) ? agid : -1;
			// 呼叫 SP 去做處理
			DataSet objDS = null;
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@AgentID", aid),
				new SqlParameter("@AgentGroupID", ddl_AppGroup.SelectedValue),
				new SqlParameter("@AgentAccount", tbx_MemberAccount.Text),
				new SqlParameter("@AgentPassword", tbx_MemberPassword.Text),
				new SqlParameter("@AgentNickName", tbx_MemberNickName.Text),
				new SqlParameter("@ExecuteAgentID", this.AUser.ExecAgentID),
			};

			objDS = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"Game_Agent.dbo.NSP_AgentWeb_A_Agent_Edit",
				param
			);
			// 重做一次導頁的動作
			string strHttp = string.Format("A04_Edit.aspx?aid={0}&agid={1}", aid, ddl_AppGroup.SelectedValue);
			Response.Redirect(strHttp);
		}

		// 做綁定資料的動作
		void BindList()
		{
			// 取得群組資料
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AgentGroup_List"
			).Tables[0];
			ddl_AppGroup.DataBind();
		}
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				// 暫時先不需要弄回去
				//// TODO 加入驗證是否可進此修改頁
				//if (string.IsNullOrEmpty(Request.QueryString["sid"]))
				//{
				//	Response.Redirect("A04_Edit.aspx");
				//	return;
				//}
				BindList();
				// 取得要修改的那一個資料
				int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
				int agid = int.TryParse(Request.QueryString["agid"], out agid) ? agid : -1;
				log4net.LogManager.GetLogger("test").DebugFormat("aid={0}, agid={1}", aid, agid);
				// 去 DB 取得資料
				DataSet objDS = null;
				SqlParameter[] param = new SqlParameter[]
				{
					new SqlParameter("@AgentID", aid),
					new SqlParameter("@AgentGroupID", agid),
				};

				objDS = SqlHelper.ExecuteDataset
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"Game_Agent.dbo.NSP_AgentWeb_A_Agent_List",
					param
				);

				// 設定 Index
				ddl_AppGroup.SelectedValue = agid.ToString();
				// 設定帳號
				tbx_MemberAccount.Text = objDS.Tables[0].Rows[0]["AgentAccount"].ToString();
				// 設定暱稱
				tbx_MemberNickName.Text = objDS.Tables[0].Rows[0]["AgentNickName"].ToString();
				// 取得全部
				DataTable dt = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					System.Data.CommandType.StoredProcedure,
					"NSP_AgentWeb_A_Agent_AppGroup_List"
				).Tables[0];
				Dictionary<string, int> dictMap = new Dictionary<string,int> ();
				for (int Index = 0; Index < dt.Rows.Count; Index++)
				{
					string AppGroupName = dt.Rows[Index]["AppGroupName"].ToString();
					int AppGroupNo = System.Convert.ToInt32( dt.Rows[Index]["AppGroupNo"].ToString());
					dictMap[AppGroupName] = AppGroupNo;
				}
				// 丟到網頁暫存去
				ViewState["All"] = dictMap;
				// 取得現有的
				GetYes();
				// 做綁上去的動作
				UpdateListBox();
			}
		}

		#endregion

		#region 第二個 Table

		// 第二個 TABLE 的 >>
		protected void btn_ID_Send_Click(object sender, EventArgs e)
		{
			// 判定選到的東西
			if (lb_No_ID.SelectedItem == null)
				return;
			string strValue = lb_No_ID.SelectedItem.Text;
			if (strValue == "")
				return;
			Dictionary<string, int> dictAll = ViewState["AllID"] as Dictionary<string, int>;
			int iValue = dictAll[strValue];
			// 做 DB 的處理
			int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
			// 取得現有的
			SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_App_Edit"
				, new SqlParameter("@AgentID", aid)
				, new SqlParameter("@AppNo", iValue)
				, new SqlParameter("@IsMgt", 1)
				, new SqlParameter("@UpdateAgentID", aid)
			);
			// 更新畫面
			GetYesID();
			UpdateListBoxID();
		}

		// 第二個TABLE 的 <<
		protected void btn_ID_Receive_Click(object sender, EventArgs e)
		{
			// 判定選到的東西
			if (lb_Yes_ID.SelectedItem == null)
				return;
			string strValue = lb_Yes_ID.SelectedItem.Text;
			if (strValue == "")
				return;
			Dictionary<string, int> dictAll = ViewState["AllID"] as Dictionary<string, int>;
			int iValue = dictAll[strValue];
			// 做 DB 的處理
			int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
			// 取得現有的
			SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_App_Edit"
				, new SqlParameter("@AgentID", aid)
				, new SqlParameter("@AppNo", iValue)
				, new SqlParameter("@IsMgt", "0")
				, new SqlParameter("@UpdateAgentID", aid)
			);
			// 更新畫面
			GetYesID();
			UpdateListBoxID();
		}

		// 第一個 Table 右邊的 ListBox select Index Change 的事件
		protected void lb_GroupChanged(object sender, EventArgs e)
		{
			// 檢查有沒有選中
			if (lb_YesGroup.SelectedItem == null)
				return;
			string strValue = lb_YesGroup.SelectedItem.Text;
			if (strValue == "")
				return;
			// 取得全部資料
			Dictionary<string, int> dictAll = ViewState["All"] as Dictionary<string, int>;
			int iValue = dictAll[strValue];
			Dictionary<string, int> dictMap = new Dictionary<string, int>();
			// AppGroupNo 去取得 List 資料
			try
			{
				DataTable dt = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					System.Data.CommandType.StoredProcedure,
					"NSP_AgentWeb_A_App_List"
					, new SqlParameter("@AppGroupNo", iValue)
				).Tables[0];
				for (int Index = 0; Index < dt.Rows.Count; Index++)
				{
					string AppGroupName = dt.Rows[Index]["AppName"].ToString();
					int AppGroupNo = System.Convert.ToInt32(dt.Rows[Index]["AppNo"].ToString());
					dictMap[AppGroupName] = AppGroupNo;
				}
			}
			catch (Exception ex)
			{
			}
			// 丟到網頁暫存去
			ViewState["AllID"] = dictMap;
			ViewState["IDGroup"] = iValue;
			// GetAllYes
			GetYesID();
			UpdateListBoxID();
		}

		void GetYesID()
		{
			int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
			int AppGroupNo = System.Convert.ToInt32(ViewState["IDGroup"]);
			Dictionary<string, int> dictMap = new Dictionary<string, int>();
			// AppGroupNo 去取得 List 資料
			try
			{
				DataTable dt = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					System.Data.CommandType.StoredProcedure,
					"NSP_AgentWeb_A_Agent_App_List"
					, new SqlParameter("@AgentID", aid)
					, new SqlParameter("@AppGroupNo", AppGroupNo)
				).Tables[0];
				for (int Index = 0; Index < dt.Rows.Count; Index++)
				{
					string AppGroupName = dt.Rows[Index]["AppName"].ToString();
					int iNumber = System.Convert.ToInt32(dt.Rows[Index]["AppNo"].ToString());
					dictMap[AppGroupName] = iNumber;
				}
			}
			catch (Exception ex)
			{
			}
			// 丟到網頁暫存去
			ViewState["YesID"] = dictMap;
		}

		// 更新畫面 UI
		void UpdateListBoxID()
		{
			// 取得全部
			Dictionary<string, int> dictAll = ViewState["AllID"] as Dictionary<string, int>;
			// 取得現有
			Dictionary<string, int> dictYes = ViewState["YesID"] as Dictionary<string, int>;
			// 計算沒有
			Dictionary<string, int> dictNo = new Dictionary<string, int>();
			foreach (var KeyValue in dictAll)
			{
				if (dictYes.ContainsKey(KeyValue.Key) == true)
					continue;
				dictNo[KeyValue.Key] = KeyValue.Value;
			}
			// 重建 DataTable
			DataTable dtYes = GetListBoxTable();
			foreach (var KeyValue in dictYes)
			{
				var Row = dtYes.NewRow();
				Row["AppGroupName"] = KeyValue.Key;
				Row["AppGroupNo"] = KeyValue.Value;
				dtYes.Rows.Add(Row);
			}
			lb_Yes_ID.DataSource = dtYes;
			lb_Yes_ID.DataBind();
			DataTable dtNo = GetListBoxTable();
			foreach (var KeyValue in dictNo)
			{
				var Row = dtNo.NewRow();
				Row["AppGroupName"] = KeyValue.Key;
				Row["AppGroupNo"] = KeyValue.Value;
				dtNo.Rows.Add(Row);
			}
			lb_No_ID.DataSource = dtNo;
			lb_No_ID.DataBind();
			// 更新畫面
		}

		#endregion

		#region 第一個 Table
		protected void btn_Send_Click(object sender, EventArgs e)
		{
			// 檢查有沒有選中
			if (lb_NoGroup.SelectedItem == null)
				return;
			string strValue = lb_NoGroup.SelectedItem.Text;
			if (strValue == "")
				return;
			// 取得全部資料
			Dictionary<string, int> dictAll = ViewState["All"] as Dictionary<string, int>;
			int iValue = dictAll[strValue];
			// 做 SP 的更新
			int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
			// 取得現有的
			SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_AppGroup_Edit"
				, new SqlParameter("@AgentID", aid)
				, new SqlParameter("@AppGroupNo", iValue)
				, new SqlParameter("@IsMgt", 1)
				, new SqlParameter("@UpdateAgentID", aid)
			);
			// 更新一次
			GetYes();
			UpdateListBox();
		}

		protected void btn_Receive_Click(object sender, EventArgs e)
		{
			// 檢查有沒有選中
			if (lb_YesGroup.SelectedItem == null)
				return;
			string strValue = lb_YesGroup.SelectedItem.Text;
			if (strValue == "")
				return;
			// 取得全部資料
			Dictionary<string, int> dictAll = ViewState["All"] as Dictionary<string, int>;
			int iValue = dictAll[strValue];
			// 做 SP 的更新
			int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
			SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_AppGroup_Edit"
				, new SqlParameter("@AgentID", aid)
				, new SqlParameter("@AppGroupNo", iValue)
				, new SqlParameter("@IsMgt", "0")
				, new SqlParameter("@UpdateAgentID", aid)
			);
			// 更新一次
			GetYes();
			UpdateListBox();
		}

		void GetYes()
		{
			int aid = int.TryParse(Request.QueryString["aid"], out aid) ? aid : -1;
			int agid = int.TryParse(Request.QueryString["agid"], out agid) ? agid : -1;
			// 取得現有的
			DataTable dt = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_AppGroup_List"
				, new SqlParameter("@AgentID", aid)
			).Tables[0];
			Dictionary<string, int> dictMap = new Dictionary<string, int>();
			for (int Index = 0; Index < dt.Rows.Count; Index++)
			{
				string AppGroupName = dt.Rows[Index]["AppGroupName"].ToString();
				int AppGroupNo = System.Convert.ToInt32(dt.Rows[Index]["AppGroupNo"]);
				dictMap[AppGroupName] = AppGroupNo;
			}
			ViewState["Yes"] = dictMap;
		}

		protected void UpdateListBox()
		{
			// 取得全部
			Dictionary<string, int> dictAll = ViewState["All"] as Dictionary<string, int>;
			// 取得現有
			Dictionary<string, int> dictYes = ViewState["Yes"] as Dictionary<string, int>;
			// 計算沒有
			Dictionary<string, int> dictNo = new Dictionary<string, int>();
			foreach (var KeyValue in dictAll)
			{
				if (dictYes.ContainsKey(KeyValue.Key) == true)
					continue;
				dictNo[KeyValue.Key] = KeyValue.Value;
			}
			// 重建 DataTable
			DataTable dtYes = GetListBoxTable();
			foreach (var KeyValue in dictYes)
			{
				var Row = dtYes.NewRow();
				Row["AppGroupName"] = KeyValue.Key;
				Row["AppGroupNo"] = KeyValue.Value;
				dtYes.Rows.Add (Row);
			}
			lb_YesGroup.DataSource = dtYes;
			lb_YesGroup.DataBind();
			DataTable dtNo = GetListBoxTable();
			foreach (var KeyValue in dictNo)
			{
				var Row = dtNo.NewRow();
				Row["AppGroupName"] = KeyValue.Key;
				Row["AppGroupNo"] = KeyValue.Value;
				dtNo.Rows.Add(Row);
			}
			lb_NoGroup.DataSource = dtNo;
			lb_NoGroup.DataBind();
			// 更新畫面
		}

		DataTable GetListBoxTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "AppGroupName";
			Column.ReadOnly = true;
			Column.Unique = false;
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AppGroupNo";
			Column.ReadOnly = true;
			Column.Unique = false;
			Tables.Columns.Add(Column);

			return Tables;
		}
		#endregion

	}
}