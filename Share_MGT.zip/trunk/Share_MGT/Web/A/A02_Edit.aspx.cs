﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.A
{
	public partial class A02_Edit : Share_MGT.AppLibs.FormBase
	{
		int MenuAuthority = 0;

		// 取出要修改的資料
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!Page.IsPostBack)
            {
                bool IsGetData = false;
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : 0;

                if (sid != -1)
                {
                    // 取出該筆資料
                    SqlDataReader objDtr = SqlHelper.ExecuteReader
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_S_AgentWeb_Function_List",
                        new SqlParameter("@FunctionID", sid)
                    );

                    // 繫結到相關欄位
                    if (objDtr.Read())
                    {
                        // 選單類別
                        ddl_ParentFunctionID.SelectedValue = objDtr["ParentFunctionID"].ToString();
                        // 選單名稱
                        tbx_FunctionName.Text = objDtr["FunctionName"].ToString();
                        // 英文名稱
                        tbx_FunctionEName.Text = objDtr["FunctionEName"].ToString();
                        // 選單網址
                        tbx_FunctionURL.Text = objDtr["FunctionURL"].ToString();
                        // 選單順序
                        tbx_FunctionOrder.Text = objDtr["FunctionOrder"].ToString();
                        // 權限
                        MenuAuthority = Convert.ToInt32(objDtr["MenuAuthority"]);
                        // 是否啟用
                        chk_IsEnabled.Checked = objDtr.GetBoolean(objDtr.GetOrdinal("IsEnabled"));

                        ViewState["FunctionID"] = sid;

                        IsGetData = true;
                    }

                    objDtr.Close();
                }

                if (!IsGetData)
                {
                    ScriptManager.RegisterStartupScript(Page, GetType(), "msg", "alert('要修改的資料不存在!!\\n請按下確定後返回!!');location.href='A02.aspx';", true);
                }
            }
		}

		// 繫結權限列表
		protected void cbl_Authority_DataBound(object sender, EventArgs e)
		{
			foreach (ListItem item in cbl_Authority.Items)
			{
				int value = Convert.ToInt32(item.Value);
				item.Selected = ((MenuAuthority & value) == value);
			}
		}

		// 修改資料
		protected void btn_Edit_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int Authority = 0;
                int sid = 0;

                if (ViewState["FunctionID"] != null && int.TryParse(ViewState["FunctionID"].ToString(), out sid))
                {
                    foreach (ListItem item in cbl_Authority.Items)
                    {
                        if (item.Selected) Authority += Convert.ToInt32(item.Value);
                    }

                    SqlParameter[] param =
				    {
					    // 編號
					    new SqlParameter("@FunctionID", sid),
					    // 類別編號
					    new SqlParameter("@ParentFunctionID", ddl_ParentFunctionID.SelectedValue),
					    // 名稱
					    new SqlParameter("@FunctionName", tbx_FunctionName.Text),
					    // 英文名稱
					    new SqlParameter("@FunctionEName", tbx_FunctionEName.Text),
					    // 網址
					    new SqlParameter("@FunctionURL", tbx_FunctionURL.Text),
					    // 順序
					    new SqlParameter("@FunctionOrder", tbx_FunctionOrder.Text),
					    // 選單權限
					    new SqlParameter("@MenuAuthority", Authority),
					    // 是否啟用
					    new SqlParameter("@IsEnabled", chk_IsEnabled.Checked)
				    };

                    // 執行
                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_S_AgentWeb_Function_Edit",
                        param
                    );
                }

                Response.Redirect("A02.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}