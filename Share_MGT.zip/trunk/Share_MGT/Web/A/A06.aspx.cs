﻿using System;
using System.Reflection;

namespace Share_MGT.Web.A
{
    public partial class A06 : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Version v = Assembly.LoadFile(Server.MapPath("~/bin/AjaxControlToolkit.dll")).GetName().Version;
                // lbl_AjaxControlToolkit.Text = string.Format("{0}.{1}.{2}.{3}", v.Major, v.Minor, v.Revision, v.Build);
                lbl_AjaxControlToolkit.Text = v.ToString();

                v = Assembly.LoadFile(Server.MapPath("~/bin/EO.Web.dll")).GetName().Version;
                lbl_EO_Web.Text = v.ToString();

                v = Assembly.Load("Share_MGT").GetName().Version;
                lbl_AppCode.Text = v.ToString();

                // GFC 目前是取檔案版號, 非組件版號
                try
                {
                    lbl_GFC.Text = System.Diagnostics.FileVersionInfo.GetVersionInfo(Assembly.Load("GFC").Location).FileVersion;
                }
                catch { }
            }
        }   
    }
}