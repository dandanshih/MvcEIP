﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.A
{
	// 每一頁都有做檢查, 所以必須要換個繼承
	public partial class A04 : FormBase
	{
		// 轉接到新增的頁面
		protected void btn_Add_Click(object sender, EventArgs e)
		{
			Response.Redirect("A04_Add.aspx");
		}

		// 做綁定資料的動作
		void BindList()
		{
			// 綁定一開始的下拉選單
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AgentGroup_List"
			).Tables[0];
			ddl_AppGroup.DataBind();
			// 取得選項
			int iSelect = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			SetSelectGroup(iSelect);
		}

		// 做設定選項的工作
		void SetSelectGroup(int SelectIndex)
		{
			DataSet dsData = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"Game_Agent.dbo.NSP_AgentWeb_A_Agent_List"
				, new SqlParameter("@AgentGroupID", SelectIndex)
			);
			// 取得資料
			DataTable Tables = GetDataTable();
			// 做資料處理
			DataTable dtDB = dsData.Tables[0];
			for (int Index = 0; Index < dtDB.Rows.Count; Index++)
			{
				var NewRow = Tables.NewRow();
				// Copy 想要的資料
				NewRow["AgentID"] = dtDB.Rows[Index]["AgentID"];
				NewRow["AgentAccount"] = dtDB.Rows[Index]["AgentAccount"];
				NewRow["AgentNickName"] = dtDB.Rows[Index]["AgentNickName"];
				NewRow["ErrorLoginCount"] = dtDB.Rows[Index]["ErrorLoginCount"];
				NewRow["PauseAccountAgentID"] = dtDB.Rows[Index]["PauseAccountAgentID"];
				NewRow["IsWebAdmin"] = dtDB.Rows[Index]["IsWebAdmin"];
				NewRow["AgentGroupID"] = dtDB.Rows[Index]["AgentGroupID"];

				//NewRow["AgentGroupName"] = dtDB.Rows[Index]["AgentGroupName"];
				//NewRow["ShowAgentGroupID"] = dtDB.Rows[Index]["AgentGroupID"].ToString();

				// 取得 AgentGroupName
				int aid = int.TryParse(NewRow["AgentID"].ToString(), out aid) ? aid : -1;
				// 取得現有的
				DataTable dt = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					System.Data.CommandType.StoredProcedure,
					"NSP_AgentWeb_A_Agent_AppGroup_List"
					, new SqlParameter("@AgentID", aid)
				).Tables[0];
				Dictionary<string, int> dictMap = new Dictionary<string, int>();
				string strResult = "";
				for (int IndexGroup = 0; IndexGroup < dt.Rows.Count; IndexGroup++)
				{
					string AppGroupName = dt.Rows[IndexGroup]["AppGroupName"].ToString();
					if (strResult.Length == 0)
					{
						strResult += AppGroupName;
					}
					else
					{
						strResult += "<br/>" + AppGroupName;
					}
				}
				NewRow["AgentGroupName"] = strResult;
				// 取得 GroupID
				strResult = "";
				DataTable dt2 = SqlHelper.ExecuteDataset(
					WebConfig.ConnectionString,
					System.Data.CommandType.StoredProcedure,
					"NSP_AgentWeb_A_Agent_App_List"
					, new SqlParameter("@AgentID", aid)
				).Tables[0];
				for (int IndexGroup = 0; IndexGroup < dt2.Rows.Count; IndexGroup++)
				{
					string AppGroupName = dt2.Rows[IndexGroup]["AppName"].ToString();
					if (strResult.Length == 0)
					{
						strResult += AppGroupName;
					}
					else
					{
						strResult += "<br/>" + AppGroupName;
					}
				}
				NewRow["ShowAgentGroupID"] = strResult;

				// 加進去
				Tables.Rows.Add(NewRow);
			}
			// 做綁定資料的動作
			gdView.DataSource = Tables;
			gdView.DataBind();
		}

		DataTable GetDataTable()
		{
			DataColumn Column;
			DataTable Tables = new DataTable();
			// 加入欄
			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AgentID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "AgentGroupName";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "AgentGroupID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "ShowAgentGroupID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "AgentAccount";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.String");
			Column.ColumnName = "AgentNickName";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "ErrorLoginCount";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "PauseAccountAgentID";
			Tables.Columns.Add(Column);

			Column = new DataColumn();
			Column.DataType = System.Type.GetType("System.Int32");
			Column.ColumnName = "IsWebAdmin";
			Tables.Columns.Add(Column);

			return Tables;
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		protected void OnSelectedChange(object sender, EventArgs e)
		{
			int iSelect = System.Convert.ToInt32(ddl_AppGroup.SelectedValue);
			SetSelectGroup(iSelect);
		}

	}
}