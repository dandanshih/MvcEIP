﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.A
{
	public partial class A02_Add : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}

		protected void btn_Add_Click(object sender, EventArgs e)
		{
			if ((IsValid && this.Authority.IsAddable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int Authority = 0;
				foreach (ListItem item in cbl_Authority.Items)
				{
					if (item.Selected) Authority += Convert.ToInt32(item.Value);
				}

				SqlParameter[] param =
				{
					// 編號
					new SqlParameter("@ParentFunctionID", ddl_ParentFunctionID.SelectedValue),
					// 名稱
					new SqlParameter("@FunctionName", tbx_FunctionName.Text),
					// 英文名稱
					new SqlParameter("@FunctionEName", tbx_FunctionEName.Text),
					// 網址
					new SqlParameter("@FunctionURL", tbx_FunctionURL.Text),
					// 順序
					new SqlParameter("@FunctionOrder", tbx_FunctionOrder.Text),
					// 選單權限
					new SqlParameter("@MenuAuthority", Authority),
					// 是否啟用
					new SqlParameter("@IsEnabled", chk_IsEnabled.Checked)
				};

				SqlHelper.ExecuteNonQuery
                (
                    WebConfig.ConnectionString, 
                    CommandType.StoredProcedure, 
                    "NSP_AgentWeb_S_AgentWeb_Function_Add", 
                    param
                );

				Response.Redirect("A02.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}

		}
	}
}