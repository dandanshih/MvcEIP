﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace Share_MGT.Web.A
{
	public partial class A01 : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                BindList(-1);
            }
		}
        
        private void BindList(int editIndex)
        {
            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_S_GetMessagesList",
                new SqlParameter("@ResxType", ddlMessageType.SelectedValue)
            );

            grdMessage.EditIndex = editIndex;

            grdMessage.DataSource = objDr;
            grdMessage.DataBind();

            objDr.Close();
        }
        
        protected void grdMessage_RowEditing(object sender, GridViewEditEventArgs e)
        {
            BindList(e.NewEditIndex);
        }

        protected void grdMessage_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            BindList(-1);
        }

        protected void grdMessage_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            SqlParameter[] param = 
            {
                new SqlParameter("@ResxTypeID", e.Keys["ResxTypeID"]),
                new SqlParameter("@Message_id", e.Keys["Message_id"]),
                // -1 不改
                new SqlParameter("@SortNo", e.NewValues["SortNo"]),
                // 空字串不改
                new SqlParameter("@Value_Default", e.NewValues["Value_Default"]),
                new SqlParameter("@Value_ZHTW", e.NewValues["Value_ZHTW"]),
                new SqlParameter("@Value_ZHCN", e.NewValues["Value_ZHCN"]),
                new SqlParameter("@Value_JAJP", e.NewValues["Value_JAJP"]),
                new SqlParameter("@Value_ENUS", e.NewValues["Value_ENUS"]),
                new SqlParameter("@Value_ESMX", e.NewValues["Value_ESMX"])
            };

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_S_Messages_Save",
                param
            );

            BindList(-1);
        }

        protected void ddlMessageType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindList(-1);
        }

        protected void btn_ClearMarquee_Click(object sender, EventArgs e)
        {
            SqlHelper.ExecuteNonQuery
            (
                Share_MGT.AppLibs.WebConfig.ConnectionString,
                System.Data.CommandType.StoredProcedure,
                "NSP_AgentWeb_ClearMarquee"
            );

            ScriptManager.RegisterStartupScript(Page, GetType(), "setOK", "alert('設定成功!');", true);
        }
	}
}