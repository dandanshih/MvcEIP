﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.A
{
	public partial class A04_Add : FormBase
	{
		void BindList()
		{
			// 綁定一開始的下拉選單
			ddl_AppGroup.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_AgentGroup_List"
			).Tables[0];
			ddl_AppGroup.DataBind();
			// 把資料清空
			tbx_MemberAccount.Text = "";
			tbx_MemberNickName.Text = "";
			tbx_MemberPassword.Text = "";
			tbx_MemberPassword_Again.Text = "";
		}
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		protected void btn_Add_Click(object sender, EventArgs e)
		{
			// 做資料檢查
			string strAccount = tbx_MemberAccount.Text;
			string strNickName = tbx_MemberNickName.Text;
			string strPassword = tbx_MemberPassword.Text;
			string strPasswordAgain = tbx_MemberPassword_Again.Text;
			int iSelect = System.Convert.ToInt32( ddl_AppGroup.SelectedValue );
			if (strAccount == "")
			{
				l_Error.Text = "帳號不可以為空";
				return;
			}
			if (strNickName == "")
			{
				l_Error.Text = "帳稱不可以為空";
				return;
			}
			if (strPassword == "" || strPasswordAgain == "")
			{
				l_Error.Text = "密碼不可以為空";
				return;
			}
			if (strPassword != strPasswordAgain)
			{
				l_Error.Text = "二次密碼不一致, 請重新輸入";
				tbx_MemberPassword.Text = "";
				tbx_MemberPassword_Again.Text = "";
				return;
			}
			// 新增
			SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				System.Data.CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_Add"
				, new SqlParameter("@AgentGroupID", iSelect)
				, new SqlParameter("@AgentAccount", strAccount)
				, new SqlParameter("@AgentPassword", strPassword)
				, new SqlParameter("@AgentNickName", strNickName)
				, new SqlParameter("@ExecuteAgentID", this.AUser.AgentID)
			);
			// 導頁回去
			Response.Redirect("A04.aspx");
		}
	}
}
