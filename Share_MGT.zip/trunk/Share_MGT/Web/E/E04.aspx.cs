﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.E
{
    public partial class E04 : FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddlRoundLimit.Enabled = false;
            }
        }

        // 查詢
        protected void btnQuery_Click(object sender, EventArgs e)
        {
            tblGame.Visible = false;
            grdGameRankDetail.Visible = false;

            sds_GameRank_List.SelectParameters["AppNo"].DefaultValue = UCAppSelect1.AppNo.ToString();
            sds_GameRank_List.SelectParameters["StartDateTime"].DefaultValue = DateRange1.StartDate;
            sds_GameRank_List.SelectParameters["EndDateTime"].DefaultValue = DateRange1.EndDate;
            sds_GameRank_List.SelectParameters["GameID"].DefaultValue = "0";
            sds_GameRank_List.SelectParameters["SortType"].DefaultValue = cboSortType.SelectedValue;
            sds_GameRank_List.SelectParameters["ShowNum"].DefaultValue = cboTop.Text;
            sds_GameRank_List.SelectParameters["Rounds"].DefaultValue = ddlRoundLimit.SelectedValue;

            grdGameRank.DataBind();
            tblGame.Visible = true;
        }

        // 排序方式
        protected void cboSortType_OnSelectIndexChanged(Object sender, EventArgs e)
        {
            if (int.Parse(cboSortType.SelectedValue) >= 5)
            {
                ddlRoundLimit.Enabled = true;
            }
            else
            {
                ddlRoundLimit.Enabled = false;
                ddlRoundLimit.SelectedValue = "0";
            }
        }

        #region 主表
        protected void MasterGrid_DataBound(object sender, EventArgs e)
        {
            //GridView grdTmp = (GridView)sender;

            //if (grdTmp.Rows.Count == 0)
            //{
            //    return;
            //}

            //int[] CalculateColumns = { 3, 4, 5, 7 };
            //decimal[] Summary = new decimal[grdTmp.Columns.Count];
            //decimal dTmp = 0;

            //foreach (GridViewRow Rows in grdTmp.Rows)
            //{
            //    foreach (int iCells in CalculateColumns)
            //    {
            //        if (Decimal.TryParse(Rows.Cells[iCells].Text, out dTmp))
            //        {
            //            Rows.Cells[iCells].Text = dTmp.ToString("N0");
            //            Summary[iCells] += dTmp;
            //        }
            //    }
            //}
        }

        // 動態指定Button命令和參數
        protected void grdGameRank_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.DataItem == null)
                return;

            GridViewRow gvRow = (GridViewRow)e.Row;             // Bind to HTML Form
            DataRowView dvRow = (DataRowView)e.Row.DataItem;    // Bind to Database

            Button btn = gvRow.FindControl("btnSetTraceAccount") as Button;
            btn.CommandName = dvRow["IsAlarmedAccount"].ToString().Equals("False") ? "SetTraceAccount" : "RemoveTraceAccount";
            btn.CommandArgument = dvRow["MemberID"].ToString();
            btn.Text = dvRow["IsAlarmedAccount"].ToString().Equals("False") ? "生效" : "取消";
            btn.ForeColor = dvRow["IsAlarmedAccount"].ToString().Equals("False") ? Color.White : Color.Blue;
            btn.OnClientClick = dvRow["IsAlarmedAccount"].ToString().Equals("False") ? @"return confirm('確定要設定為關注名單嗎？')" : @"return confirm('確定要取消關注名單嗎？')";
        }

        protected void grdGameRank_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "Detail":
                    sds_GameRank_Detail.SelectParameters["MemberID"].DefaultValue = grdGameRank.DataKeys[Convert.ToInt32(e.CommandArgument)]["MemberID"].ToString();
                    sds_GameRank_Detail.SelectParameters["StartDate"].DefaultValue = DateRange1.StartDate;
                    sds_GameRank_Detail.SelectParameters["EndDate"].DefaultValue = DateRange1.EndDate;

                    grdGameRankDetail.DataBind();
                    grdGameRankDetail.Visible = true;

                    GridBtnColorSet(grdGameRank, Convert.ToInt32(e.CommandArgument), grdGameRankDetail);
                    break;
                case "SetTraceAccount":
                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_A_SetMemberAccountAlarmed",
                        new SqlParameter("@MemberID", e.CommandArgument),
                        new SqlParameter("@AlarmType", "2"),
                        new SqlParameter("@ExecuteAgentID", this.AUser.ExecAgentID)
                    );
                    grdGameRank.DataBind();
                    break;
                case "RemoveTraceAccount":
                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_A_SetMemberAccountAlarmed",
                        new SqlParameter("@MemberID", e.CommandArgument),
                        new SqlParameter("@AlarmType", "0"),
                        new SqlParameter("@ExecuteAgentID", this.AUser.ExecAgentID)
                    );
                    grdGameRank.DataBind();
                    break;
                default:
                    break;
            }
        }
        #endregion

        /************************************************************************/
        /* 秀各類別細項的資料  START                                            */
        /************************************************************************/
        private void GridBtnColorSet(GridView grdMaster, int NowRowIndex, GridView grdDetail)
        {
            foreach (GridViewRow Row in grdMaster.Rows)
            {
                Button btn = (Button)Row.FindControl("ctl00");
                if (Row.RowIndex == NowRowIndex)
                {
                    btn.ForeColor = System.Drawing.Color.Red;
                    string sTop = Convert.ToString(30 + NowRowIndex * 30) + "px";
                    grdDetail.Style.Add("Top", sTop);
                }
                else
                {
                    btn.ForeColor = System.Drawing.Color.Empty;
                }
            }
        }
    }
}