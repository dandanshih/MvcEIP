﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.E
{
    public partial class E06 : FormBase
    {
        private void BindData()
        {
            int TotalRecords = 0;

            DataSet objDS = null;

            SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@AppNo", UCAppSelect1.AppNo),
                new SqlParameter("@BeginDate", DateRange1.StartDate),
                new SqlParameter("@EndDate", DateRange1.EndDate),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@TotalRecords", TotalRecords)
			};
            param[param.Length - 1].Direction = ParameterDirection.Output;

            try
            {
                objDS = SqlHelper.ExecuteDataset
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "Game_Agent.dbo.NSP_AgentWeb_SendPrizeLog",
                    param
                );
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(E06)).Error("E04::BindData", ex);
            }

            if (objDS == null)
            {
                TotalRecords = 0;
            }
            else
            {
                TotalRecords = int.Parse(param[param.Length - 1].Value.ToString());
            }

            gv_List.DataSource = objDS.Tables[0];
            gv_List.DataBind();

			int iRowNumber = objDS.Tables[0].Rows.Count;

            // 取得總筆數
            UCPager1.RecordCount = TotalRecords;
            UCPager1.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                UCPager1.CurrentPageNumber = 1;
                BindData();
            }
        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            // 重新搜尋時設定第一頁
            UCPager1.CurrentPageNumber = 1;
            BindData();
        }

        // 登出列表分頁事件
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            BindData();
        }
    }
}