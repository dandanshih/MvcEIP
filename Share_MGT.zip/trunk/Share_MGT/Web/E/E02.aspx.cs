﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.E
{
    public partial class E02 : FormBase
    {
        private void BindCurrencyList()
        {
            ddl_Currency.Items.Add(new ListItem()
            {
                Text = "全部",
                Value = "-1"
            });
            ddl_Currency.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_S_Currency_List").Tables[0];
            ddl_Currency.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCurrencyList();
            }
        }

        // 查詢
        protected void btnQuery_Click(object sender, EventArgs e)
        {
            //電子總合
            dsWinloseReport.SelectParameters["StartDateTime"].DefaultValue = UCDateRange1.StartDate;
            dsWinloseReport.SelectParameters["EndDateTime"].DefaultValue = UCDateRange1.EndDate;
            dsWinloseReport.SelectParameters["AppNo"].DefaultValue = UCAppSelect1.AppNo.ToString();
            dsWinloseReport.SelectParameters["CurrencyNo"].DefaultValue = ddl_Currency.SelectedValue;
            grdWinloseReport.DataBind();

            //電子明細
            dsWinloseReportDetail.SelectParameters["StartDateTime"].DefaultValue = UCDateRange1.StartDate;
            dsWinloseReportDetail.SelectParameters["EndDateTime"].DefaultValue = UCDateRange1.EndDate;
            dsWinloseReportDetail.SelectParameters["AppNo"].DefaultValue = UCAppSelect1.AppNo.ToString();
            dsWinloseReportDetail.SelectParameters["CurrencyNo"].DefaultValue = ddl_Currency.SelectedValue;
            grdWinloseReportDetail.DataBind();
        }

        #region 電子遊戲總表
        // 加表頭
        protected void grdWinloseReport_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                GridView oGridView = (GridView)sender;
                GridViewRow oGridViewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
                oGridViewRow.Style.Add(HtmlTextWriterStyle.Height, "6px");

                for (int i = 0; i <= oGridView.Columns.Count - 1; i++)
                {
                    TableCell oTableCell = new TableCell();
                    oTableCell.Text = Convert.ToChar(65 + i).ToString();
                    oTableCell.BorderWidth = Unit.Pixel(1);
                    oTableCell.BorderStyle = BorderStyle.Inset;
                    oGridViewRow.Cells.Add(oTableCell);
                }

                oGridView.Controls[0].Controls.AddAt(0, oGridViewRow);
            }
        }

        // 加總合
        protected void grdWinloseReport_DataBound(object sender, EventArgs e)
        {
            GridView grdTmp = (GridView)sender;
            decimal[] Summary = new decimal[grdTmp.Columns.Count];
            int[] CalculateColumns = { 1, 2, 3, 4 };
            decimal dTmp = 0;

            foreach (GridViewRow Rows in grdTmp.Rows)
            {
                foreach (int iCells in CalculateColumns)
                {
                    if (Decimal.TryParse(Rows.Cells[iCells].Text, out dTmp))
                    {
                        Rows.Cells[iCells].Text = dTmp.ToString("N0");
                        Summary[iCells] += dTmp;
                    }
                }
            }

            if (grdTmp.FooterRow != null)
                foreach (int iCells in CalculateColumns)
                    grdTmp.FooterRow.Cells[iCells].Text = Summary[iCells].ToString("N0");
        }
        #endregion

        #region 電子遊戲明細
        // 加表頭
        protected void grdWinloseReportDetail_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                GridView oGridView = (GridView)sender;
                GridViewRow oGridViewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
                oGridViewRow.Style.Add(HtmlTextWriterStyle.Height, "7px");

                for (int i = 0; i <= oGridView.Columns.Count - 1; i++)
                {
                    TableCell oTableCell = new TableCell();
                    oTableCell.Text = Convert.ToChar(65 + i).ToString();
                    oTableCell.BorderWidth = Unit.Pixel(1);
                    oTableCell.BorderStyle = BorderStyle.Inset;
                    oGridViewRow.Cells.Add(oTableCell);
                }

                oGridView.Controls[0].Controls.AddAt(0, oGridViewRow);
            }
        }

        // 加總合
        protected void grdWinloseReportDetail_DataBound(object sender, EventArgs e)
        {
            GridView grdTmp = (GridView)sender;
            decimal[] Summary = new decimal[grdTmp.Columns.Count];
            int[] CalculateColumns = { 1, 2, 3, 4, 5, 6, 7, 8 };
            decimal dTmp = 0;

            foreach (GridViewRow Rows in grdTmp.Rows)
            {
                foreach (int iCells in CalculateColumns)
                {
                    if (Decimal.TryParse(Rows.Cells[iCells].Text, out dTmp))
                    {
                        Rows.Cells[iCells].Text = dTmp.ToString("N0");
                        Summary[iCells] += dTmp;
                    }
                }
            }

            if (grdTmp.FooterRow != null)
                foreach (int iCells in CalculateColumns)
                    grdTmp.FooterRow.Cells[iCells].Text = Summary[iCells].ToString("N0");
        }
        #endregion
    }
}