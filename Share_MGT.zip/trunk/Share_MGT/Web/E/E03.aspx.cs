﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.E
{
	public partial class E03 : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btnQuery_Click(object sender, EventArgs e)
		{
		}
	}
}