﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.E
{
    public partial class E05 : FormBase
    {
        private void BindData()
        {
            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@TotalRecords", SqlDbType.Int),
                new SqlParameter("@BeginDate", UCDateRange1.StartDate),
                new SqlParameter("@EndDate", UCDateRange1.EndDate),
                new SqlParameter("@MemberAccount", tbx_MemberAccount.Text),
                new SqlParameter("@AppNo", UCAppSelect1.AppNo),
                new SqlParameter("@GameID", UCGameSelect1.GameSeletedValue == "0" ? "-1": UCGameSelect1.GameSeletedValue),
                new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
                new SqlParameter("@PageSize", UCPager1.PageSize)
            };
            objParam[0].Direction = ParameterDirection.Output;

            gv_DataList.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_GetJPDetail",
                objParam);
            gv_DataList.DataBind();

            UCPager1.RecordCount = Convert.ToInt32(objParam[0].Value);
            UCPager1.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            UCPager1.CurrentPageNumber = 1;
            this.BindData();
        }

        protected void UCPager1_Change(object sender, EventArgs e)
        {
            this.BindData();
        }
    }
}