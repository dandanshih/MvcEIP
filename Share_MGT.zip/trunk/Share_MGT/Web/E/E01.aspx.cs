﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.E
{
    public partial class E01 : FormBase
    {
        private void BindData()
        {
            if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('只能查詢2個月內的記錄!');", true);
                return;
            }

            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@AppNo", "-1"),
                new SqlParameter("@AgentID", this.AUser.AgentID),
                new SqlParameter("@StartDateTime", this.UCDateRange1.StartDate),
                new SqlParameter("@EndDateTime", this.UCDateRange1.EndDate)
            };
            gv_DataList.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_Report_QryWinlose_AppNo_Statistic",
                objParam);
            gv_DataList.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            this.BindData();
        }
    }
}