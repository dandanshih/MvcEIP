﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

namespace Share_MGT.Web.H
{
    public partial class H02 : FormBase
    {
        #region Proterty
        /// <summary>
        /// GameStatus 所有列舉。
        /// </summary>
        private EnumerableRowCollection _GameStatusList { get; set; }

        /// <summary>
        /// 紀錄目前單一項目的 GameStatus
        /// rptList_ItemDataBound 與 rptGameStatus_ItemDataBound 之間溝通用。
        /// </summary>
        private int _GameStatus { get; set; }
        #endregion

        #region Private Method
        /// <summary>
        /// 取得目前的 GameStatus 設定。
        /// </summary>
        /// <returns></returns>
        private DataTable GetGameStatusCollection()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("GameID", typeof(int));
            dt.Columns.Add("GameAreaType", typeof(int));
            dt.Columns.Add("GroupID", typeof(int));
            dt.Columns.Add("GameStatus", typeof(Int64));
            dt.Columns.Add("GameTypeID", typeof(int));

            foreach (RepeaterItem item in rptList.Items)
            {
                string[] sid = (item.FindControl("hidSID") as HiddenField).Value.Split('_');
                if (sid.Length != 4)
                {
                    break;
                }

                Repeater rptGameStatus = item.FindControl("rptGameStatus") as Repeater;
                Int64 gameStatus = 0;

                foreach (RepeaterItem subItem in rptGameStatus.Items)
                {
                    CheckBox chk = subItem.FindControl("chkFlag") as CheckBox;
                    if (chk.Checked)
                    {
                        gameStatus += int.Parse(chk.Attributes["Flag"]);
                    }
                }

                dt.Rows.Add(sid[0], sid[1], sid[2], gameStatus, sid[3]);
            }

            return dt;
        }
        #endregion

        #region Protected Method
        protected void Page_Init(object sender, EventArgs e)
        {
            _GameStatusList = Utility.TextResource.GetTextResxRow("GameStatus");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string currentLanguage = System.Threading.Thread.CurrentThread.CurrentUICulture.Name.ToString().Replace("-", "").ToUpper();
                // 允許語系
                string[] allowLanguage = { "ZHTW", "ZHCN", "JAJP", "ENUS" };
                // 預設語系欄位
                string defaultField = "Value_Default";
                // 根據目前的語系指定資源值的欄位名稱
                string valueField = allowLanguage.Contains(currentLanguage) ? "Value_" + currentLanguage : defaultField;

                DataTable objTab = SqlHelper.ExecuteDataset(
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_G_GameAreaType_List").Tables[0];
                ddlGameType.DataTextField = valueField;
                ddlGameType.DataValueField = "Message_id";
                ddlGameType.DataSource = objTab;
                ddlGameType.DataBind();
            }
        }


        /// <summary>
        /// 每個項目列表的 ItemDataBound 事件。
        /// </summary>
        protected void rptList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                _GameStatus = int.Parse(DataBinder.Eval(e.Item.DataItem, "GameStatus").ToString());

                Repeater rpt = e.Item.FindControl("rptGameStatus") as Repeater;
                rpt.DataSource = _GameStatusList;
                rpt.DataBind();
            }
        }

        /// <summary>
        /// 每個單一項目的屬性列表 ItemDataBound 事件。
        /// </summary>
        protected void rptGameStatus_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                long key = long.Parse(DataBinder.Eval(e.Item.DataItem, "Flag").ToString());
                string value = DataBinder.Eval(e.Item.DataItem, "Value").ToString();

                CheckBox chk = e.Item.FindControl("chkFlag") as CheckBox;
                chk.Text = value;
                chk.Attributes["Flag"] = key.ToString();
                chk.Checked = ((_GameStatus & key) > 0);
                if (key == 4)
                {
                    chk.Enabled = false;
                    chk.Style["color"] = "#999999";
                }
            }
        }

        /// <summary>
        /// 編輯事件。
        /// </summary>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            DataTable gameGroupData = GetGameStatusCollection();

            if (gameGroupData.Rows.Count == 0)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "message", "alert('無資料可修改！');", true);
                return;
            }

            SqlParameter[] param = 
            {
                new SqlParameter("@GameGroupData", SqlDbType.Structured)
            };

            param[0].Value = gameGroupData;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_GameRule_GameStatus_Edit",
                param
            );

            ScriptManager.RegisterStartupScript(Page, GetType(), "message", "alert('修改成功！');", true);
        }
        #endregion
    
    }
}