﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.H
{
	public partial class H01_Detail : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			DataTable DBdt = null;
			// 取得參數
			string LogID = Request.QueryString["LogID"].ToString();
			string LMActivityID = Request.QueryString["LMActivityID"].ToString();
			// 取得名稱對應表
			Dictionary<string, string> dictMap = new Dictionary<string, string>();
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_LuckyMoney_Detail_GameData"
				, new SqlParameter("@LMActivityID", LMActivityID)
			).Tables[0];
			for (int Index = 0; Index < DBdt.Rows.Count; Index++)
			{
				string GameID = DBdt.Rows[Index]["GameID"].ToString();
				string GameName = DBdt.Rows[Index]["GameName"].ToString();
				dictMap[GameID] = GameName;
			}
			cbl_GameList.DataSource = DBdt;
			cbl_GameList.DataBind();
			// 取得資料
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_LuckyMoneyDetailMainDataHistory"
				, new SqlParameter("@LogID", LogID)
			).Tables[0];
			string StartDate = DBdt.Rows[0]["AfterStartDate"].ToString();
			string EndDate = DBdt.Rows[0]["AfterEndDate"].ToString();
			UCDateRange1.StartDate = StartDate;
			UCDateRange1.EndDate = EndDate;
			string strGameList = DBdt.Rows[0]["GameList"].ToString();
			DataTable DB = Utility.GetDataTable(new Dictionary<string, string>
			{
				{"GameID", "System.Int32"}
				, {"GameName", "System.String"}
			});
			foreach (var KeyValue in dictMap)
			{
				var NewRow = DB.NewRow();
				NewRow["GameID"] = KeyValue.Key;
				NewRow["GameName"] = KeyValue.Value;
			}
			for (int Index = 0; Index < cbl_GameList.Items.Count; Index++)
			{
				string Value = cbl_GameList.Items[Index].Value;
				if (strGameList.Contains(Value))
				{
					cbl_GameList.Items[Index].Selected = true;
				}
				else
				{
					cbl_GameList.Items[Index].Selected = false;
				}
				cbl_GameList.Items[Index].Enabled = false;
			}
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		protected void btn_Query_Click(object sender, EventArgs e)
		{
		}

		protected void btn_Cancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("H01.aspx");
		}
	}
}