﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.H
{
	// 每一頁都有做檢查, 所以必須要換個繼承
	public partial class H01 : FormBase
    {
		// 做綁定資料的動作
		void BindList()
		{
			// 取現在進行中的幸運金
			DataTable DBdt = null;
			// 跑 DB 取結果
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_LuckyMoney_List"
			).Tables[0];
			tb_Now.DataSource = DBdt;
			tb_Now.DataBind();
			// 取得歷史記錄
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_LuckyMoneyHistoryList"
				, new SqlParameter("@GameTypeID", "0")
			).Tables[0];
			tb_History.DataSource = DBdt;
			tb_History.DataBind();
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		public static bool IsButtonEnable(object IsEnable)
		{
			if (IsEnable.ToString() == "0")
			{
				return false;
			}
			return true;
		}

		public static string IsButtonEnableText(object IsEnable)
		{
			if (IsEnable.ToString() == "0")
			{
				return "己停用";
			}
			return "編輯";
		}

		public static string IsButtonStopText(object IsEnable)
		{
			if (IsEnable.ToString() == "0")
			{
				return "啟用";
			}
			return "停用";
		}

		// 上面表單的 Command
		protected void grdList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 按下停用的動作
			if (e.CommandName == "OnEdit")
			{
				string[] arrToken = e.CommandArgument.ToString().Split(',');
				// 取得 ID
				int LMActivityID = System.Convert.ToInt32(arrToken[0]);
				// 跳到另一個畫面
				string strHttp = string.Format("H01_Edit.aspx?LMActivityID={0}", LMActivityID);
				Response.Redirect(strHttp);
			}
			// 按下停用的動作
			else if (e.CommandName == "OnDelete")
			{
				string[] arrToken = e.CommandArgument.ToString().Split(',');
				// 取得 ID
				int LMActivityID = System.Convert.ToInt32 (arrToken[0]);
				// 取得資料
				int IsEnable = System.Convert.ToInt32(arrToken[1]);
				if (IsEnable == 1)
					IsEnable = 0;
				else
					IsEnable = 1;
				// 做刪除的動作
				SqlParameter[] param =
				{
					// 編號
					new SqlParameter("@LMActivityID", LMActivityID),
					// 名稱
					new SqlParameter("@IsEnable", IsEnable),
					// 英文名稱
					new SqlParameter("@ExecAgentID", this.AUser.AgentID),
				};

				SqlHelper.ExecuteNonQuery
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_R_LuckyMoneyPause",
					param
				);

				// 做畫面上的更新
				Response.Redirect("H01.aspx");
			}
		}

		// 下面表單的 Command
		protected void grdHistory_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 按下明細的動作
			if (e.CommandName == "OnDetail")
			{
				string[] arrToken = e.CommandArgument.ToString().Split(',');
				// 取得資料
				int LogID = System.Convert.ToInt32(arrToken[0]);
				// 取得 ID
				int LMActivityID = System.Convert.ToInt32(arrToken[1]);
				// 取得網址
				string strHttp = string.Format("H01_Detail.aspx?LogID={0}&LMActivityID={1}", LogID, LMActivityID);
				Response.Redirect(strHttp);
			}
		}
	}
}