﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.H
{
	// 每一頁都有做檢查, 所以必須要換個繼承
	public partial class H01_Edit : FormBase
	{
		// 做綁定資料的動作
		void BindList()
		{
			char[] defaultseps = { '\n', '\t', ' ' };
			DataTable DBdt = null;
			// 取得參數
			string LMActivityID = Request.QueryString["LMActivityID"].ToString();
			// 取得資料
			// 跑 DB 取結果
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_LuckyMoney_List"
			).Tables[0];
			for (int Index = 0; Index < DBdt.Rows.Count; Index++)
			{
				string strLMActivityID = DBdt.Rows[Index]["LMActivityID"].ToString();
				if (strLMActivityID == LMActivityID)
				{
					string UseTime = DBdt.Rows[Index]["UseTime"].ToString();
					string[] arrToken = UseTime.Split('~');
					string StartDate = arrToken[0].Trim(defaultseps);
					string EndDate = arrToken[1].Trim(defaultseps);
					UCDateRange1.StartDate = StartDate;
					UCDateRange1.EndDate = EndDate;
					break;
				}
			}
			// GameList
			Dictionary<string, string> dictMap = new Dictionary<string, string>();
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_LuckyMoney_Detail_GameData"
				, new SqlParameter("@LMActivityID", LMActivityID)
			).Tables[0];
			List<string> listCheck = new List<string>();
			for (int Index = 0; Index < DBdt.Rows.Count; Index++)
			{
				string GameID = DBdt.Rows[Index]["GameID"].ToString();
				string GameName = DBdt.Rows[Index]["GameName"].ToString();
				dictMap[GameID] = GameName;
				if (DBdt.Rows[Index]["CheckState"].ToString() == "1")
				{
					listCheck.Add(GameID);
				}
			}
			cbl_GameList.DataSource = DBdt;
			cbl_GameList.DataBind();
			for (int Index = 0; Index < cbl_GameList.Items.Count; Index++)
			{
				if (listCheck.Contains(cbl_GameList.Items[Index].Value) == true)
				{
					cbl_GameList.Items[Index].Selected = true;
				}
				else
				{
					cbl_GameList.Items[Index].Selected = false;
				}
			}
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
			}
		}

		protected void btn_Query_Click(object sender, EventArgs e)
		{
		}

		protected void btn_Save_Click(object sender, EventArgs e)
		{
			string LMActivityID = Request.QueryString["LMActivityID"].ToString();
			// 取得遊戲列表
			string strGameList = "";
			for (int Index = 0; Index < cbl_GameList.Items.Count; Index++)
			{
				if (cbl_GameList.Items[Index].Selected == true)
				{
					strGameList += "," + cbl_GameList.Items[Index].Value;
				}
			}
			strGameList = strGameList.Trim(',');
			string StartDate = UCDateRange1.StartDate;
			string EndDate = UCDateRange1.EndDate;
			// 寫入 DB
			SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_LuckyMoneyMainDataEdit"
				, new SqlParameter("@GameList", strGameList)
				, new SqlParameter("@ExecAgentID", this.AUser.AgentID)
				, new SqlParameter("@LMActivityID", LMActivityID)
				, new SqlParameter("@StartDate", StartDate)
				, new SqlParameter("@EndDate", EndDate)
			);

			// 更新畫面
			BindList();
		}

		protected void btn_Cancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("H01.aspx");
		}
	}
}