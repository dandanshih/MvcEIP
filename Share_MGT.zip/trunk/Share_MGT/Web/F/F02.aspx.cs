﻿using GFC.Utilities;
using GFC.Web;
using GFC.Web.WebControls;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.F
{
    public partial class F02 : FormBase
    {
        private void BindCurrencyList()
        {
            ddl_Currency.Items.Add(new ListItem()
            {
                Text = "全部",
                Value = "-1"
            });
            ddl_Currency.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_S_Currency_List").Tables[0];
            ddl_Currency.DataBind();
        }

        private void BindData()
        {
            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@AppNo", this.UCAppSelect1.AppNo),
                new SqlParameter("@CurrencyNo", this.ddl_Currency.SelectedValue),
                new SqlParameter("@AgentID", this.AUser.AgentID),
                new SqlParameter("@CalculateTime", this.UCDateRange1.StartDate),
                new SqlParameter("@MemberType", "-1")
            };
            gv_DataList.DataSource = SqlHelper.ExecuteDataset(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_Immediate_Winlose",
                objParam);
            gv_DataList.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCurrencyList();
                btn_Query_Click(null, null);
            }
        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            //檢查是否可查詢資料
            if (!Authority.CheckAuthority(EnumAuthority.LiveReNew))
            {
                Timer1.Enabled = false;
                return;
            }
            BindData();

            lit_Time.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            
        }

        protected void gv_DataList_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                //Build custom header.
                TBGridView Table = (TBGridView)sender;
                TableCell oTableCell;
                GridViewRow oGridViewRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Insert);
                
                for (int i = 0; i < Table.Columns.Count; i++)
                {
                    oTableCell = new TableCell();
                    if (i != 0)
                    {
                        oTableCell.Text = char.ConvertFromUtf32(65 + i - 1);
                    }
                    oGridViewRow.Cells.Add(oTableCell);
                }

                Table.Controls[0].Controls.AddAt(0, oGridViewRow);
            }
        }

        protected void gv_DataList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                int[] colorCol = new int[] { 1, 2, 3, 4, 5 };

                foreach (int i in colorCol)
                {
                    if (e.Row.Cells[i].Text != "")
                    {
                        if (float.Parse(e.Row.Cells[i].Text) < 0)
                        {
                            e.Row.Cells[i].ForeColor = System.Drawing.Color.Red;
                        }
                        else if (float.Parse(e.Row.Cells[i].Text) > 0)
                        {
                            e.Row.Cells[i].ForeColor = System.Drawing.Color.Blue;
                        }
                    }
                }
            }
        }

        protected void gv_DataList_DataBound(object sender, EventArgs e)
        {
            TBGridView table = (TBGridView)sender;

            if (table.FooterRow != null)
            {
                int[] totalCol = new int[] { 1, 2, 3, 4, 5 };
                decimal[] totalNum = new decimal[totalCol.Length];

                foreach (GridViewRow row in table.Rows)
                {
                    for (int i = 0; i < totalCol.Length; i++)
                    {
                        totalNum[i] += decimal.Parse(row.Cells[totalCol[i]].Text);
                    }
                }

                for (int i = 0; i < totalCol.Length; i++)
                {
                    table.FooterRow.Cells[totalCol[i]].Text = totalNum[i].ToString("N2");
                }
                table.FooterRow.Cells[0].Text = "合計";
            }
        }
    }
}