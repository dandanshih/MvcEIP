﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Share_MGT.AppLibs;
using GFC.Web;
using System.Data.SqlClient;
using System.Data;
using GFC.Utilities;
using System.Drawing;

namespace Share_MGT.Web.F
{
    public partial class F01 : FormBase
    {
        #region Private Method
        private void BindData()
        {
            int TotalRecords = 0;
            string MemberAccount = string.IsNullOrEmpty(tbx_MemberAccount.Text) ? "" : tbx_MemberAccount.Text;

            // 登入列表
            DataSet objDS = null;
            SqlParameter[] param = new SqlParameter[]
			{
                // 總筆數
				new SqlParameter("@TotalRecords", TotalRecords),
                // 分桶ID
                new SqlParameter("@AppNo", UCAppSelect1.AppNo),
				// 帳號
				new SqlParameter("@MemberAccount", MemberAccount),
				// 開始時間
				new SqlParameter("@StartDate", DateRange1.StartDate),
				// 結束時間
				new SqlParameter("@EndDate", DateRange1.EndDate),
				// 每頁筆數
				new SqlParameter("@PageSize", UCPager1.PageSize),
				// 目前頁次
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber)
				
			};
            param[0].Direction = ParameterDirection.Output;

            try
            {
                objDS = SqlHelper.ExecuteDataset
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_R_MemberAlarmedList",
                    param
                );
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(F01)).Error("E03::BindData", ex);
            }

            object objLogin = param[0].Value;
            if (objLogin != null && objLogin != DBNull.Value)
            {
                TotalRecords = int.Parse(objLogin.ToString());

                grdGameRank.DataSource = objDS;
                grdGameRank.DataBind();

                // 取得總比數
                UCPager1.RecordCount = TotalRecords;
                UCPager1.DataBind();
            }
        }

        private void GridBtnColorSet(GridView grdMaster, int NowRowIndex, GridView grdDetail)
        {
            foreach (GridViewRow Row in grdMaster.Rows)
            {
                Button btn = (Button)Row.FindControl("ctl00");
                if (Row.RowIndex == NowRowIndex)
                {
                    btn.ForeColor = System.Drawing.Color.Red;
                    string sTop = Convert.ToString(30 + NowRowIndex * 30) + "px";
                    grdDetail.Style.Add("Top", sTop);
                }
                else
                {
                    btn.ForeColor = System.Drawing.Color.Empty;
                }
            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                UCPager1.CurrentPageNumber = 1;
                BindData();
            }
        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            UCPager1.CurrentPageNumber = 1;
            BindData();
        }

        // 登出列表分頁事件
        protected void UCPager1_Change(object sender, EventArgs e)
        {
            BindData();
        }

        #region GridView事件
        
        protected void grdGameRank_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "SetTraceAccount":
                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_A_SetMemberAccountAlarmed",
                        new SqlParameter("@MemberID", e.CommandArgument),
                        new SqlParameter("@AlarmType", "2"),
                        new SqlParameter("@ExecuteAgentID", this.AUser.ExecAgentID)
                    );
                    grdGameRank.DataBind();
                    break;
                case "RemoveTraceAccount":
                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_A_SetMemberAccountAlarmed",
                        new SqlParameter("@MemberID", e.CommandArgument),
                        new SqlParameter("@AlarmType", "0"),
                        new SqlParameter("@ExecuteAgentID", this.AUser.ExecAgentID)
                    );
                    grdGameRank.DataBind();
                    break;
                default:
                    break;
            }
        }
        #endregion
    }
}