﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J01_Edit : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack)
			{
				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_QualificationCategory.Find(id);
				if (item != null)
				{
					TBX_QualificationName.Text = item.QualificationName;
				}
			}
		}

		protected void BTN_QualificationName_Edit_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_QualificationCategory.Find(id);
				if (item != null)
				{
					item.QualificationName = TBX_QualificationName.Text;
				}
				this.ActivityDB.SaveChanges();
				Response.Redirect("J01.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}