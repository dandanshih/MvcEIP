﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J06 : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack)
			{
				this.BindData();
			}
		}

		protected void UCPager_MissionRule_Change(object sender, EventArgs e)
		{
			this.BindData();
		}

		private void BindData()
		{
			int take = this.UCPager_MissionRule.PageSize;
			int skip = (this.UCPager_MissionRule.CurrentPageNumber - 1) * take;
			var query = this.ActivityDB.C_MissionRule;

			// 繫結分頁
			this.UCPager_MissionRule.RecordCount = query.Count();
			this.UCPager_MissionRule.DataBind();

			// 繫結資料
			this.GV_MissionRule.DataSource = query
				.OrderBy(x => x.MissionRuleID)
				.Skip(skip)
				.Take(take)
				.ToList();
			this.GV_MissionRule.DataBind();
		}
	}
}