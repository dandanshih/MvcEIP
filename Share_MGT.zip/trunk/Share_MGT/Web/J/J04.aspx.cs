﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J04 : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack)
			{
				this.BindData();
			}
		}

		/// <summary>
		/// 換頁重新繫結資料
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void UCPager_ActivityRecord_Change(object sender, EventArgs e)
		{
			this.BindData();
		}

		private void BindData()
		{
			int take = this.UCPager_ActivityRecord.PageSize;
			int skip = (this.UCPager_ActivityRecord.CurrentPageNumber - 1) * take;
			var query = this.ActivityDB.C_ActivityRecord;

			// 繫結分頁
			this.UCPager_ActivityRecord.RecordCount = query.Count();
			this.UCPager_ActivityRecord.DataBind();

			// 繫結資料
			this.GV_ActivityRecord.DataSource = query
				.OrderBy(x => x.ActivityRecordID)
				.Skip(skip)
				.Take(take)
				.ToList();
			this.GV_ActivityRecord.DataBind();
		}
	}
}