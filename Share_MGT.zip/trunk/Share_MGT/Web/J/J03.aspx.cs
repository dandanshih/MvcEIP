﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J03 : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack)
			{
				this.BindData();
			}
		}

		protected void UCPager_QualificationDetail_Change(object sender, EventArgs e)
		{
			this.BindData();
		}

		private void BindData()
		{
			int take = this.UCPager_QualificationDetail.PageSize;
			int skip = (this.UCPager_QualificationDetail.CurrentPageNumber - 1) * take;
			var query = this.ActivityDB.C_QualificationDetail;

			// 繫結分頁
			this.UCPager_QualificationDetail.RecordCount = query.Count();
			this.UCPager_QualificationDetail.DataBind();

			// 繫結資料
			this.GV_QualificationDetail.DataSource = query
				.OrderBy(x => x.QualificationDetailID)
				.Skip(skip)
				.Take(take)
				.Include(x => x.C_QualificationCategory)
				.Include(x => x.C_QualificationAttribute)
				.ToList();
			this.GV_QualificationDetail.DataBind();
		}
	}
}