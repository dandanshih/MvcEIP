﻿// Author : dandanshih
// Date : 2014/5/8 
// Event 活動設定
// doc 表16 : https://docs.google.com/a/gosmio.biz/viewer?a=v&pid=sites&srcid=Z29zbWlvLmJpenxydWJ5LXhpbi1waW5nLXRhaXxneDoyY2I1YzM0ZDM1ZGU2M2Qw

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.J
{
	// 每一頁都有做檢查, 所以必須要換個繼承
	public partial class J05 : FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
