﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J04_Edit : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_ActivityRecord.Find(id);

				if (item != null)
				{
					TBX_ActivityRecordName.Text = item.ActivityRecordName;
				}
			}
		}

		protected void BTN_ActivityRecord_Edit_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_ActivityRecord.Find(id);
				if (item != null)
				{
					item.ActivityRecordName = TBX_ActivityRecordName.Text;
					this.ActivityDB.SaveChanges();
					Response.Redirect("J04.aspx");
				}
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}