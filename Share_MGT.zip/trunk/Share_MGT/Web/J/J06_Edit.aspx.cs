﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J06_Edit : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack)
			{
				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_MissionRule.Find(id);
				if (item != null)
				{
					TBX_MissionRuleName.Text = item.MissionRuleName;
					TBX_Rule1.Text = item.Rule1;
					TBX_Rule2.Text = item.Rule2;
					TBX_Rule3.Text = item.Rule3;
					TBX_Rule4.Text = item.Rule4;
				}
			}
		}

		protected void BTN_MissionRule_Edit_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_MissionRule.Find(id);

				if (item != null)
				{
					item.MissionRuleName = TBX_MissionRuleName.Text;
					item.Rule1 = TBX_Rule1.Text;
					item.Rule2 = TBX_Rule2.Text;
					item.Rule3 = TBX_Rule3.Text;
					item.Rule4 = TBX_Rule4.Text;
					this.ActivityDB.SaveChanges();
				}

				Response.Redirect("J06.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}