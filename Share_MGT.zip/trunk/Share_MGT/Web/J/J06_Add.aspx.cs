﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;
using Share_MGT.Models;

namespace Share_MGT.Web.J
{
	public partial class J06_Add : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
		protected void BTN_MissionRule_Add_Click(object sender, EventArgs e)
		{
			if ((IsValid && this.Authority.IsAddable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				this.ActivityDB.C_MissionRule.Add(new C_MissionRule()
				{
					MissionRuleName = TBX_MissionRuleName.Text,
					Rule1 = TBX_Rule1.Text,
					Rule2 = TBX_Rule2.Text,
					Rule3 = TBX_Rule3.Text,
					Rule4 = TBX_Rule4.Text
				});
				this.ActivityDB.SaveChanges();
				Response.Redirect("MissionRule.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}