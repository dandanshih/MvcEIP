﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J03_Edit : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.Page.IsPostBack)
			{
				DDL_QualificationID.DataSource = this.ActivityDB.C_QualificationCategory.ToList();
				DDL_QualificationID.DataTextField = "QualificationName";
				DDL_QualificationID.DataValueField = "QualificationID";
				DDL_QualificationID.DataBind();

				DDL_QualificationAttributeID.DataSource = this.ActivityDB.C_QualificationAttribute.ToList();
				DDL_QualificationAttributeID.DataTextField = "QualificationAttributeName";
				DDL_QualificationAttributeID.DataValueField = "QualificationAttributeID";
				DDL_QualificationAttributeID.DataBind();

				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_QualificationDetail.Find(id);
				if (item != null)
				{
					TBX_QualificationAttributeValue.Text = item.QualificationAttributeValue.ToString();
				}
			}
		}

		protected void BTN_QualificationDetail_Edit_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int id = int.TryParse(Request.QueryString["sid"], out id) ? id : 0;
				var item = this.ActivityDB.C_QualificationDetail.Find(id);
				if (item != null)
				{
					int qualificationID = int.TryParse(DDL_QualificationID.SelectedValue, out qualificationID) ? qualificationID : 0;
					int aualificationAttributeID = int.TryParse(DDL_QualificationAttributeID.SelectedValue, out aualificationAttributeID) ? aualificationAttributeID : 0;
					int qualificationAttributeValue = int.TryParse(TBX_QualificationAttributeValue.Text, out qualificationAttributeValue) ? qualificationAttributeValue : 0;

					item.QualificationID = qualificationID;
					item.QualificationAttributeID = aualificationAttributeID;
					item.QualificationAttributeValue = qualificationAttributeValue;
				}

				this.ActivityDB.SaveChanges();
				Response.Redirect("J03.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}