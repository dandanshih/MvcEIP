﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.J
{
	public partial class J01_Add : FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void BTN_QualificationCategory_Add_Click(object sender, EventArgs e)
		{
			if ((IsValid && this.Authority.IsAddable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				this.ActivityDB.C_QualificationCategory.Add(new Models.C_QualificationCategory()
				{
					QualificationName = TBX_QualificationName.Text
				});
				this.ActivityDB.SaveChanges();
				Response.Redirect("J01.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}