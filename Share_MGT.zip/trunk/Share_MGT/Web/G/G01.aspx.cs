﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Share_MGT.AppLibs;
using GFC.Web;
using System.Data.SqlClient;
using System.Data;
using GFC.Utilities;

namespace Share_MGT.Web.G
{
    public partial class G01 : FormBase
    {
        #region Private
        /// <summary>
        /// 讀取每日人數。
        /// </summary>
        private void LoadDayPopulation()
        {
            if (DateTime.Now.Date.AddMonths(-2) > DateTime.Parse(UCDateRange1.StartDate).Date)
            {
                ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert(\"" + GetLocalResourceObject("ResultMessage_1").ToString() + "\");", true);
                return;
            }

            SqlParameter[] param =
			{
                new SqlParameter("@AppNo", this.UCAppSelect1.AppNo),
                new SqlParameter("@AgentID", AUser.AgentID),
				new SqlParameter("@StartDate", DateTime.Parse(UCDateRange1.StartDate).ToString("yyyy-MM-dd HH:mm:ss")),
				new SqlParameter("@EndDate", DateTime.Parse(UCDateRange1.EndDate).ToString("yyyy-MM-dd HH:mm:ss")),
				new SqlParameter("@GameMenuType", UCGameSelect1.GameTypeSeletedValue),
				new SqlParameter("@QryType", "2")
			};

            DataTable objDt = SqlHelper.ExecuteDataset
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_R_MemberPopulationAggregate",
                param
            ).Tables[0];

            for (int i = 0; i < objDt.Columns.Count; i++)
            {
                try
                {
                    objDt.Columns[i].ColumnName = Utility.TextResource.GetTextResxByMessageID("GameName", objDt.Columns[i].ColumnName);
                }
                catch { }
            }

            gvHourPopulation.DataSource = objDt;
            gvHourPopulation.DataBind();
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            LoadDayPopulation();
        }
    }
}