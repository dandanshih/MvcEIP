﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.C
{
	public partial class C01_Edit : Share_MGT.AppLibs.FormBase
	{
		// 取得要修改的資料
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				//取出該筆資料
				SqlDataReader objDtr = SqlHelper.ExecuteReader
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_G_Game_List",
					new SqlParameter("@GameID", sid)
				);

				//繫結到相關欄位
				if (objDtr.Read())
				{
					// 遊戲編號
					tbx_GameID.Text = objDtr["GameID"].ToString();
					// 遊戲類別編號
					ddl_GameTypeID.SelectedValue = objDtr["GameTypeID"].ToString();
					// 遊戲名稱
					tbx_GameName.Text = objDtr["GameName"].ToString();
					// 英文名稱
					tbx_GameEName.Text = objDtr["GameEName"].ToString();
					// 是否啟用
					chk_IsEnabled.Checked = (bool)objDtr["IsEnabled"];
					// 是否為吃角子老虎
					chk_IsSlotGame.Checked = (bool)objDtr["IsSlotGame"];
					// 是否可載入GameRestore
					chk_CanLoadGameRestore.Checked = (bool)objDtr["CanLoadGameRestore"];
					// 機率類型
					ddl_ProbType.SelectedValue = objDtr["ProbType"].ToString();
					// 大廳是否可見
					chk_IsVisible.Checked = (bool)objDtr["IsVisible"];
					// 電子區大廳頁數
					tbx_PageSize.Text = objDtr["PageSize"].ToString();
					// 對戰區每桌座位數
					tbx_TableSeatNum.Text = objDtr["TableSeatNum"].ToString();
				}

				objDtr.Close();
			}
		}

		// 修改資料
		protected void btn_Edit_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				// SQL參數
				SqlParameter[] param = new SqlParameter[] 
				{
					// 遊戲編號
					new SqlParameter("@GameID", tbx_GameID.Text),
					// 遊戲類別編號
					new SqlParameter("@GameTypeID", ddl_GameTypeID.SelectedValue),
					// 遊戲名稱
					new SqlParameter("@GameName", tbx_GameName.Text),
					// 英文名稱
					new SqlParameter("@GameEName", tbx_GameEName.Text),
					// 是否啟用
					new SqlParameter("@IsEnabled", chk_IsEnabled.Checked),
					// 是否為吃角子老虎
					new SqlParameter("@IsSlotGame", chk_IsSlotGame.Checked),
					// 是否可載入GameRestore
					new SqlParameter("@CanLoadGameRestore", chk_CanLoadGameRestore.Checked),
					// 機率類型
					new SqlParameter("@ProbType", ddl_ProbType.SelectedValue),
					// 大廳是否可見
					new SqlParameter("@IsVisible", chk_IsVisible.Checked),
					// 電子區大廳頁數
					new SqlParameter("@PageSize", tbx_PageSize.Text),
					// 對戰區每桌座位數
					new SqlParameter("@TableSeatNum", tbx_TableSeatNum.Text)
				};

				// 執行
				SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_Game_Edit", param);
				Response.Redirect("C01.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}