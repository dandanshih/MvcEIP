﻿using System;

namespace Share_MGT.Web.C
{
	public partial class C05_Edit : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}