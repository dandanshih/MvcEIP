﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.C
{
	public partial class C02_Add : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsAddable) == false)
            {
				Utility.ShowDialog("權限不足", "history.back();");
			}

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
                    // 遊戲編號
                    new SqlParameter("@GameID", Convert.ToInt32(ddl_Game.SelectedValue)),
                    // 彩金種類
                    new SqlParameter("@JPType", Convert.ToInt32(ddl_JPType.SelectedValue)),
                    // EnableJPLevel
                    new SqlParameter("@EnableJPLevel", Convert.ToInt32(tbx_EnableJPLevel.Text)),
                    // WinJPConditionBetGrand
                    new SqlParameter("@WinJPConditionBetGrand", Convert.ToInt32(tbx_WinJPConditionBetGrand.Text)),
                    // WinJPConditionBetMajor
                    new SqlParameter("@WinJPConditionBetMajor", Convert.ToInt32(tbx_WinJPConditionBetMajor.Text)),
                    // WinJPConditionBetMinor
                    new SqlParameter("@WinJPConditionBetMinor", Convert.ToInt32(tbx_WinJPConditionBetMinor.Text)),
                    // WinJPConditionBetMini
                    new SqlParameter("@WinJPConditionBetMini", Convert.ToInt32(tbx_WinJPConditionBetMini.Text)),
                    // ModeRate
                    new SqlParameter("@ModeRate", Convert.ToInt32(tbx_ModeRate.Text))
            };
            try
            {
                // 執行
                switch (SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_GameToJP_Add", param).ToString())
                {
                    case "0":
                        Response.Redirect("C02.aspx");
                        break;
                    case "1":
                        WebUtility.ResponseScript(Page, "alert('資料庫已有您所設定的遊戲與彩金種類，無法重覆新增!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                    default:
                        WebUtility.ResponseScript(Page, "alert('發生未知的錯誤，新增失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
	}
}