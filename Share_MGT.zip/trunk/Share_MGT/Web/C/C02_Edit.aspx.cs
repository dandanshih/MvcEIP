﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.C
{
	public partial class C02_Edit : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_G_GameToJP_QueryByGameToJPID",
                    new SqlParameter("@GameToJPID", sid)
                );
                bool isRead = false;
                //繫結到相關欄位
                if (objDtr.Read())
                {
                    ddl_Game.DataBind();
                    ddl_JPType.DataBind();
                    // 編號
                    lbl_GameToJPID.Text = objDtr["GameToJPID"].ToString();
                    // 遊戲編號
                    if (ddl_Game.Items.FindByValue(objDtr["GameID"].ToString()) == null)
                    { ddl_Game.SelectedIndex = -1; }
                    else
                    { ddl_Game.SelectedValue = objDtr["GameID"].ToString(); }
                    // 彩金種類
                    if (ddl_JPType.Items.FindByValue(objDtr["JPGroupID"].ToString()) == null)
                    { ddl_JPType.SelectedIndex = -1; }
                    else
                    { ddl_JPType.SelectedValue = objDtr["JPGroupID"].ToString(); }
                    // EnableJPLevel
                    chk_EnableJPLevel.Checked = Convert.ToBoolean(objDtr["EnableJPLevel"]);
                    // WinJPConditionBetGrand
                    tbx_WinJPConditionBetGrand.Text = objDtr["JPLevel0WinBet"].ToString();
                    // WinJPConditionBetMajor
                    tbx_WinJPConditionBetMajor.Text = objDtr["JPLevel1WinBet"].ToString();
                    // WinJPConditionBetMinor
                    tbx_WinJPConditionBetMinor.Text = objDtr["JPLevel2WinBet"].ToString();
                    // WinJPConditionBetMini
                    tbx_WinJPConditionBetMini.Text = objDtr["JPLevel3WinBet"].ToString();
                    // ModeRate
                    tbx_ModeRate.Text = objDtr["ModeRate"].ToString();
                    isRead = true;
                }
                objDtr.Close();
                if (!isRead)
                {
                    WebUtility.ResponseScript(Page, "alert('要修改的資料不存在!!\\n請按下確定後返回!!');location.href='C02.aspx';", WebUtility.ResponseScriptPlace.NearFormEnd);
                }
            }
		}

        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
				Utility.ShowDialog("權限不足", "history.back();");
			}

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
                // 編號
                new SqlParameter("@GameToJPID", Convert.ToInt32(lbl_GameToJPID.Text)),
                // 遊戲編號
                new SqlParameter("@GameID", Convert.ToInt32(ddl_Game.SelectedValue)),
                // 彩金種類
                new SqlParameter("@JPType", Convert.ToInt32(ddl_JPType.SelectedValue)),
                // EnableJPLevel
                new SqlParameter("@EnableJPLevel", Convert.ToInt32(chk_EnableJPLevel.Checked)),
                // WinJPConditionBetGrand
                new SqlParameter("@WinJPConditionBetGrand", Convert.ToInt32(tbx_WinJPConditionBetGrand.Text)),
                // WinJPConditionBetMajor
                new SqlParameter("@WinJPConditionBetMajor", Convert.ToInt32(tbx_WinJPConditionBetMajor.Text)),
                // WinJPConditionBetMinor
                new SqlParameter("@WinJPConditionBetMinor", Convert.ToInt32(tbx_WinJPConditionBetMinor.Text)),
                // WinJPConditionBetMini
                new SqlParameter("@WinJPConditionBetMini", Convert.ToInt32(tbx_WinJPConditionBetMini.Text)),
                // ModeRate
                new SqlParameter("@ModeRate", Convert.ToInt32(tbx_ModeRate.Text))
            };
            try
            {
                // 執行
                switch (SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_GameToJP_Edit", param).ToString())
                {
                    case "0":
                        Response.Redirect("C02.aspx");
                        break;
                    case "1":
                        WebUtility.ResponseScript(Page, "alert('資料庫已有您所設定的遊戲與彩金種類，無法修改!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                    case "2":
                        WebUtility.ResponseScript(Page, "alert('編號不存在，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                    default:
                        WebUtility.ResponseScript(Page, "alert('發生未知的錯誤，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
	}
}