﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.C
{
	public partial class C03_Add : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsAddable) == false)
            {
				Utility.ShowDialog("權限不足", "history.back();");
			}

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
					// 彩金種類
					new SqlParameter("@JPType", Convert.ToInt32(ddl_JPType.SelectedValue)),
					// 彩金層級
					new SqlParameter("@JPLevel", Convert.ToInt32(tbx_JPLevel.Text)),
					// 此層彩金是否開放
					new SqlParameter("@IsJPBoot", Convert.ToInt32(chk_IsJPBoot.Checked)),
					// 彩金中獎方式
					new SqlParameter("@JPMode", Convert.ToInt32(tbx_JPMode.Text)),
					// 彩金基底
					new SqlParameter("@JPBase", Convert.ToInt32(tbx_JPBase.Text)),
					// 彩金上限
					new SqlParameter("@JPLimit", Convert.ToInt32(tbx_JPLimit.Text)),
					// 彩金累積值
					new SqlParameter("@JPCurPoints", Convert.ToDecimal(tbx_JPCurPoints.Text)),
					// 彩金中獎值
					new SqlParameter("@JPBingo", Convert.ToInt32(tbx_JPBingo.Text)),
					// 彩金累積比率(千分比)
					new SqlParameter("@JPRatio", Convert.ToInt32(tbx_JPRatio.Text)),
					// 說明註記
					new SqlParameter("@Memo", tbx_Memo.Text),
                    // WinnersLimit
			        new SqlParameter("@WinnersLimit", tbx_WinnersLimit.Text)
            };
            try
            {
                // 執行
                if (SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPRule_Add", param).ToString().Equals("0"))
                {
                    Response.Redirect("C03.aspx");
                }
                else
                {
                    WebUtility.ResponseScript(Page, "alert('彩金層級已存在，無法重覆新增!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}