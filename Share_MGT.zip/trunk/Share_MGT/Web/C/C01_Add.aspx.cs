﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.C
{
	public partial class C01_Add : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		// 新增資料
		protected void btn_Add_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsAddable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				// SQL參數
				SqlParameter[] param = new SqlParameter[] 
				{
					// 遊戲編號
					new SqlParameter("@GameID", tbx_GameID.Text),
					// 遊戲類別編號
					new SqlParameter("@GameTypeID", ddl_GameTypeID.SelectedValue),
					// 遊戲名稱
					new SqlParameter("@GameName", tbx_GameName.Text),
					// 英文名稱
					new SqlParameter("@GameEName", tbx_GameEName.Text),
					// 是否啟用
					new SqlParameter("@IsEnabled", chk_IsEnabled.Checked),
					// 是否為吃角子老虎
					new SqlParameter("@IsSlotGame", chk_IsSlotGame.Checked),
					// 是否可載入GameRestore
					new SqlParameter("@CanLoadGameRestore", chk_CanLoadGameRestore.Checked),
					// 機率類型
					new SqlParameter("@ProbType", ddl_GameTypeID.SelectedValue),
					// 大廳是否可見
					new SqlParameter("@IsVisible", chk_IsVisible.Checked),
					// 電子區大廳頁數
					new SqlParameter("@PageSize", tbx_PageSize.Text),
					// 對戰區每桌座位數
					new SqlParameter("@TableSeatNum", tbx_TableSeatNum.Text)
				};
				
				// 執行
                SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_Game_Add", param);
				Response.Redirect("C01.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}