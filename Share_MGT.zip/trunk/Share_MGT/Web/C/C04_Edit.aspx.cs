﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;
using System.Web;

namespace Share_MGT.Web.C
{
	public partial class C04_Edit : Share_MGT.AppLibs.FormBase
	{
        private void BindData()
        {
            int GameID = int.TryParse(Request.QueryString["gameid"], out GameID) ? GameID : 0;
            int GroupID = int.TryParse(Request.QueryString["groupid"], out GroupID) ? GroupID : 0;
            // 取出該筆資料
            SqlDataReader objDtr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameServer_G_GameRule_QueryByID",
                new SqlParameter[]
                    { 
                        new SqlParameter("@GameID", GameID),
                        new SqlParameter("@GroupID", GroupID)
                    }
            );

            // 繫結到相關欄位
            bool isRead = false;
            if (objDtr.Read())
            {
                isRead = true;
                // 遊戲
                ddl_Game.SelectedValue = objDtr["GameID"].ToString();
                // GroupID
                //tbx_GroupID.Text = objDtr["GroupID"].ToString();
                lbl_GroupID.Text = objDtr["GroupID"].ToString();
                // 座位
                tbx_Seat.Text = objDtr["Seat"].ToString();
                // MinBet
                tbx_MinBet.Text = objDtr["MinBet"].ToString();
                // MinMen2ToCreateGrp
                tbx_MinMen2ToCreateGrp.Text = objDtr["MinMen2ToCreateGrp"].ToString();
                // MaxMen2ToCreateGrp
                tbx_MaxMen2ToCreateGrp.Text = objDtr["MaxMen2ToCreateGrp"].ToString();
                // BasePoints
                tbx_BasePoints.Text = objDtr["BasePoints"].ToString();
                // ConsiderTimer
                tbx_ConsiderTimer.Text = objDtr["ConsiderTimer"].ToString();
                // tmRunLogic
                tbx_tmRunLogic.Text = objDtr["tmRunLogic"].ToString();
                // IsSupportBanking
                cbx_IsSupportBanking.Checked = Convert.ToBoolean(objDtr["IsSupportBanking"]);
                // IsGroupBoot
                cbx_IsGroupBoot.Checked = Convert.ToBoolean(objDtr["IsGroupBoot"]);
                // IsCOMCanTakeOver
                cbx_IsCOMCanTakeOver.Checked = Convert.ToBoolean(objDtr["IsCOMCanTakeOver"]);
                // IsSupportBanking
                cbx_CanLookOnGame.Checked = Convert.ToBoolean(objDtr["CanLookOnGame"]);
                // ParamDataName
                tbx_ParamDataName.Text = objDtr["ParamDataName"].ToString();
                // ParamDataValue
                tbx_ParamDataValue.Text = objDtr["ParamDataValue"].ToString();
                // GameHistory
                tbx_GameHistory.Text = objDtr["GameHistory"].ToString();
                // ParamDataForGameSetting
                tbx_ParamDataForGameSetting.Text = objDtr["ParamDataForGameSetting"].ToString();
                // CoinPointBase
                tbx_CoinPointBase.Text = objDtr["CoinPointBase"].ToString();
                // DiTai
                tbx_DiTai.Text = objDtr["DiTai"].ToString();
                // ParamDataForProbSetting
                tbx_ParamDataForProbSetting.Text = objDtr["ParamDataForProbSetting"].ToString();
                // GameFlashSetting
                tbx_GameFlashSetting.Text = objDtr["GameFlashSetting"].ToString();
                // LobbyFlashSetting
                tbx_LobbyFlashSetting.Text = objDtr["LobbyFlashSetting"].ToString();
                // AllGameFlashSetting
                //tbx_AllGameFlashSetting.Text = objDtr["AllGameFlashSetting"].ToString();
                // GameAreaType
                ddlGameAreaType.SelectedValue = objDtr["GameAreaType"].ToString();
            }
            objDtr.Close();
            if (!isRead)
            {
                WebUtility.ResponseScript("alert('要修改的資料不存在!!\\n請按下確定後返回!!');location.href='C04.aspx';", WebUtility.ResponseScriptPlace.NearFormEnd);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindData();
            }
        }

        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }
            // SQL參數
            SqlParameter[] param = new SqlParameter[] 
			{
				// 遊戲 ID
				new SqlParameter("@GameID", ddl_Game.SelectedValue),
				// GroupID
				//new SqlParameter("@GroupID", tbx_GroupID.Text),
                new SqlParameter("@GroupID", lbl_GroupID.Text),
				// 座位
				new SqlParameter("@Seat", tbx_Seat.Text),
				// MinBet
				new SqlParameter("@MinBet", tbx_MinBet.Text),
				// MinMen2ToCreateGrp
				new SqlParameter("@MinMen2ToCreateGrp", tbx_MinMen2ToCreateGrp.Text),
				// MaxMen2ToCreateGrp
				new SqlParameter("@MaxMen2ToCreateGrp", tbx_MaxMen2ToCreateGrp.Text),
				// BasePoints
				new SqlParameter("@BasePoints", tbx_BasePoints.Text),
				// ConsiderTimer
				new SqlParameter("@ConsiderTimer", tbx_ConsiderTimer.Text),
				// tmRunLogic
				new SqlParameter("@tmRunLogic", tbx_tmRunLogic.Text),
				// IsSupportBanking
				new SqlParameter("@IsSupportBanking", Convert.ToInt32(cbx_IsSupportBanking.Checked)),
				// IsGroupBoot
				new SqlParameter("@IsGroupBoot", Convert.ToInt32(cbx_IsGroupBoot.Checked)),
				// IsCOMCanTakeOver
				new SqlParameter("@IsCOMCanTakeOver", Convert.ToInt32(cbx_IsCOMCanTakeOver.Checked)),
				// CanLookOnGame
				new SqlParameter("@CanLookOnGame", Convert.ToInt32(cbx_CanLookOnGame.Checked)),
				// ParamDataName
				new SqlParameter("@ParamDataName", HttpUtility.UrlDecode(tbx_ParamDataName.Text)),
				// ParamDataValue
				new SqlParameter("@ParamDataValue", HttpUtility.UrlDecode(tbx_ParamDataValue.Text)),
				// GameHistory 不允許更新
				//new SqlParameter("@GameHistory", tbx_GameHistory.Text),
				// ParamDataForGameSetting
				new SqlParameter("@ParamDataForGameSetting", HttpUtility.UrlDecode(tbx_ParamDataForGameSetting.Text)),
				// CoinPointBase 不允許更新
				//new SqlParameter("@CoinPointBase", tbx_CoinPointBase.Text),
				// DiTai
				new SqlParameter("@DiTai", tbx_DiTai.Text),
				// ParamDataForProbSetting
				new SqlParameter("@ParamDataForProbSetting", HttpUtility.UrlDecode(tbx_ParamDataForProbSetting.Text)),
				// GameAreaType
				new SqlParameter("@GameAreaType", ddlGameAreaType.SelectedValue),
                // GameFlashSetting
                new SqlParameter("@GameFlashSetting", HttpUtility.UrlDecode(tbx_GameFlashSetting.Text)),
                // LobbyFlashSetting
                new SqlParameter("@LobbyFlashSetting", HttpUtility.UrlDecode(tbx_LobbyFlashSetting.Text))
			};

            try
            {
                // 執行
                SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_GameServer_G_GameRule_Edit", param);
                Response.Redirect("C04.aspx");
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(ex.Message, WebUtility.ResponseScriptPlace.NearFormBegin);
                BindData();
            }
        }
	}
}