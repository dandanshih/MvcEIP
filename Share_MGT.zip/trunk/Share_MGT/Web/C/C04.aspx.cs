﻿using System;

namespace Share_MGT.Web.C
{
	public partial class C04 : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

        protected void rptGameList_PreRender(object sender, EventArgs e)
        {
            lbl_EmptyDataMessage.Visible = (rptGameList.Items.Count == 0);
        }
	}
}