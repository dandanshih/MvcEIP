﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.C
{
	public partial class C06_Add : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void btn_Add_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsAddable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				SqlParameter[] param = 
				{
					// 讀取器編號
					new SqlParameter("LoaderID", tbx_LoaderID.Text.TrimEnd()),
					// 公開金鑰
					new SqlParameter("Modulus", tbx_Modulus.Text.TrimEnd()),
					new SqlParameter("Exponent", tbx_Exponent.Text.TrimEnd()),
					// 私密金鑰
					new SqlParameter("P", tbx_P.Text.TrimEnd()),
					new SqlParameter("Q", tbx_Q.Text.TrimEnd()),
					new SqlParameter("DP", tbx_DP.Text.TrimEnd()),
					new SqlParameter("DQ", tbx_DQ.Text.TrimEnd()),
					new SqlParameter("InverseQ", tbx_InverseQ.Text.TrimEnd()),
					new SqlParameter("D", tbx_D.Text.TrimEnd()),
					new SqlParameter("Memo", tbx_Memo.Text.TrimEnd()),
					new SqlParameter("ExecAgentID", AUser.ExecAgentID.TrimEnd())
				};

				SqlHelper.ExecuteReader
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_S_S_FlashCommunicationKey_Edit",
					param
				);

				Response.Redirect("C06.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}