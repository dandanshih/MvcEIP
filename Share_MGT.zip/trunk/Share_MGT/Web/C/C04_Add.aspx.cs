﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;
using System.Web;

namespace Share_MGT.Web.C
{
	public partial class C04_Add : Share_MGT.AppLibs.FormBase
	{
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            int Rows = 0;
            try
            {
                Rows = (int)SqlHelper.ExecuteScalar
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_AgentWeb_G_GameRule_Count",
                        new SqlParameter[]
                        { 
                            new SqlParameter("@GameID", ddl_Game.SelectedValue),
                            new SqlParameter("@GroupID", tbx_GroupID.Text)
                        }
                    );
                if (Rows > 0)
                {
                    WebUtility.ResponseScript("alert('遊戲與GroupID值重覆設定!!請變更遊戲或GroupID值，再儲存一次!!');", WebUtility.ResponseScriptPlace.NearFormBegin);
                }
                else
                {
                    // SQL參數
                    SqlParameter[] param = new SqlParameter[] 
                    {
					    // GameRule 編號
					    //new SqlParameter("@GameRuleID", Request.QueryString["sid"]),
					    // GameID
					    new SqlParameter("@GameID", ddl_Game.SelectedValue),
					    // GroupID
					    new SqlParameter("@GroupID", tbx_GroupID.Text),
					    // Seat
					    new SqlParameter("@Seat", tbx_Seat.Text),
					    // MinBet
					    new SqlParameter("@MinBet", tbx_MinBet.Text),
					    // MinMen2ToCreateGrp
					    new SqlParameter("@MinMen2ToCreateGrp", tbx_MinMen2ToCreateGrp.Text),
					    // MaxMen2ToCreateGrp
					    new SqlParameter("@MaxMen2ToCreateGrp", tbx_MaxMen2ToCreateGrp.Text),
					    // BasePoints
					    new SqlParameter("@BasePoints", tbx_BasePoints.Text),
					    // ConsiderTimer
					    new SqlParameter("@ConsiderTimer", tbx_ConsiderTimer.Text),
					    // tmRunLogic
					    new SqlParameter("@tmRunLogic", tbx_tmRunLogic.Text),
					    // IsSupportBanking
					    new SqlParameter("@IsSupportBanking", Convert.ToInt32(cbx_IsSupportBanking.Checked)),
					    // IsGroupBoot
					    new SqlParameter("@IsGroupBoot", Convert.ToInt32(cbx_IsGroupBoot.Checked)),
					    // IsCOMCanTakeOver
					    new SqlParameter("@IsCOMCanTakeOver", Convert.ToInt32(cbx_IsCOMCanTakeOver.Checked)),
					    // CanLookOnGame
					    new SqlParameter("@CanLookOnGame", Convert.ToInt32(cbx_CanLookOnGame.Checked)),
					    // ParamDataName
					    new SqlParameter("@ParamDataName", HttpUtility.UrlDecode(tbx_ParamDataName.Text)),
					    // ParamDataValue
					    new SqlParameter("@ParamDataValue", HttpUtility.UrlDecode(tbx_ParamDataValue.Text)),
					    // GameHistory
					    new SqlParameter("@GameHistory", HttpUtility.UrlDecode(tbx_GameHistory.Text)),
					    // ParamDataForGameSetting
					    new SqlParameter("@ParamDataForGameSetting", HttpUtility.UrlDecode(tbx_ParamDataForGameSetting.Text)),
					    // CoinPointBase
					    new SqlParameter("@CoinPointBase", tbx_CoinPointBase.Text),
					    // DiTai
					    new SqlParameter("@DiTai", tbx_DiTai.Text),
					    // ParamDataForProbSetting
					    new SqlParameter("@ParamDataForProbSetting", HttpUtility.UrlDecode(tbx_ParamDataForProbSetting.Text)),
						// GameAreaType
						new SqlParameter("@GameAreaType", ddl_Game.SelectedValue),
                        // GameFlashSetting
                        new SqlParameter("@GameFlashSetting", HttpUtility.UrlDecode(tbx_GameFlashSetting.Text)),
                        // LobbyFlashSetting
                        new SqlParameter("@LobbyFlashSetting", HttpUtility.UrlDecode(tbx_LobbyFlashSetting.Text))
                    };

                    // 執行
                    SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_GameServer_G_GameRule_Add", param);
                    Response.Redirect("C04.aspx");
                }
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(ex.Message, WebUtility.ResponseScriptPlace.NearFormBegin);
            }
        }
	}
}