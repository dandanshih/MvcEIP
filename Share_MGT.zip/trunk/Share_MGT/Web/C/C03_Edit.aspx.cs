﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.C
{
	public partial class C03_Edit : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_G_JPRule_QueryByJPRuleID",
                    new SqlParameter("@JPRuleID", sid)
                );
                bool isRead = false;
                //繫結到相關欄位
                if (objDtr.Read())
                {
                    ddl_JPType.DataBind();
                    // 編號
                    lbl_JPRuleID.Text = objDtr["JPRuleID"].ToString();
                    // 彩金種類
                    if (ddl_JPType.Items.FindByValue(objDtr["JPGroupID"].ToString()) == null)
                    { ddl_JPType.SelectedIndex = -1; }
                    else
                    { ddl_JPType.SelectedValue = objDtr["JPGroupID"].ToString(); }
                    // 彩金層級
                    tbx_JPLevel.Text = objDtr["JPLevel"].ToString();
                    // 此層彩金是否開放
                    chk_IsJPBoot.Checked = Convert.ToBoolean(objDtr["IsJPBoot"]);
                    // 彩金中獎方式
                    tbx_JPMode.Text = objDtr["JPMode"].ToString();
                    // 彩金基底
                    tbx_JPBase.Text = objDtr["JPBase"].ToString();
                    // 彩金上限
                    tbx_JPLimit.Text = objDtr["JPLimit"].ToString();
                    // 彩金累積值
                    tbx_JPCurPoints.Text = objDtr["JPCurPoints"].ToString();
                    // 彩金中獎值
                    tbx_JPBingo.Text = objDtr["JPBingo"].ToString();
                    // 彩金累積比率(千分比)
                    tbx_JPRatio.Text = objDtr["JPRatio"].ToString();
                    // 說明註記
                    tbx_Memo.Text = objDtr["Memo"].ToString();
                    // WinnersLimit
                    tbx_WinnersLimit.Text = objDtr["WinnersLimit"].ToString();

                    isRead = true;
                }
                objDtr.Close();
                if (!isRead)
                {
                    WebUtility.ResponseScript(Page, "alert('要修改的資料不存在!!\\n請按下確定後返回!!');location.href='C03.aspx';", WebUtility.ResponseScriptPlace.NearFormEnd);
                }
            }
		}

        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
				Utility.ShowDialog("權限不足", "history.back();");
			}

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
                //
                new SqlParameter("@JPRuleID", lbl_JPRuleID.Text),
			    // 彩金類別編號
			    new SqlParameter("@JPType", Convert.ToInt32(ddl_JPType.SelectedValue)),
			    // 彩金層級
			    new SqlParameter("@JPLevel", Convert.ToInt32(tbx_JPLevel.Text)),
			    // 此層彩金是否開放
			    new SqlParameter("@IsJPBoot", Convert.ToInt32(chk_IsJPBoot.Checked)),
			    // 彩金中獎方式
			    new SqlParameter("@JPMode", Convert.ToInt32(tbx_JPMode.Text)),
			    // 彩金基底
			    new SqlParameter("@JPBase", Convert.ToInt32(tbx_JPBase.Text)),
			    // 彩金上限
			    new SqlParameter("@JPLimit", Convert.ToInt32(tbx_JPLimit.Text)),
			    // 彩金累積值
			    new SqlParameter("@JPCurPoints", Convert.ToDecimal(tbx_JPCurPoints.Text)),
			    // 彩金中獎值
			    new SqlParameter("@JPBingo", Convert.ToInt32(tbx_JPBingo.Text)),
			    // 彩金累積比率(千分比)
			    new SqlParameter("@JPRatio", Convert.ToInt32(tbx_JPRatio.Text)),
			    // 說明註記
			    new SqlParameter("@Memo", tbx_Memo.Text),
                // WinnersLimit
			    new SqlParameter("@WinnersLimit", tbx_WinnersLimit.Text)
            };
            try
            {
                // 執行
                switch (SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPRule_Edit", param).ToString())
                {
                    case "0":
                        Response.Redirect("C03.aspx");
                        break;
                    case "1":
                        WebUtility.ResponseScript(Page, "alert('彩金層級重覆，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                    case "2":
                        WebUtility.ResponseScript(Page, "alert('編號不存在，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                    default:
                        WebUtility.ResponseScript(Page, "alert('發生未知的錯誤，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
	}
}