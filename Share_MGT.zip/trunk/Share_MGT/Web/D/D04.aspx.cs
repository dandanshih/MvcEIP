﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.D
{
    public partial class D04 : FormBase
    {
        private void BindData()
        {
            int TotalRecords = 0;
			// 由網頁取得輸入的帳號
            string MemberAccount = string.IsNullOrEmpty(tbx_MemberAccount.Text) ? "" : tbx_MemberAccount.Text;

            // 登入列表
            DataSet objDS = null;
            SqlParameter[] param = new SqlParameter[]
			{
                // 總筆數
				new SqlParameter("@TotalRecords", TotalRecords),
				// 帳號
				new SqlParameter("@MemberAccount", MemberAccount),
                // 分桶編號
                new SqlParameter("@AppNo", UCAppSelect1.AppNo),
				// 每頁筆數
				new SqlParameter("@PageSize", UCPager1.PageSize),
				// 目前頁次
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber)
				
			};
            param[0].Direction = ParameterDirection.Output;

            try
            {
                objDS = SqlHelper.ExecuteDataset
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_Member_LoginLog_List",
                    param
                );
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(D04)).Error("D04::BindData", ex);
            }

            object objLogin = param[0].Value;
            if (objLogin != null && objLogin != DBNull.Value)
            {
                TotalRecords = int.Parse(objLogin.ToString());

                gv_Login.DataSource = objDS;
                gv_Login.DataBind();

                // 取得總筆數
                UCPager1.RecordCount = TotalRecords;
                UCPager1.DataBind();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //    UCPager_LoginList.CurrentPageNumber = 1;
            //    //UCPager_LogoutList.CurrentPageNumber = 1;
            //    BindData();
            //}
        }

        // 重新搜尋時設定第一頁
        protected void btn_Query_Click(object sender, EventArgs e)
        {
            UCPager1.CurrentPageNumber = 1;
            BindData();
        }

        // 登入列表分頁事件
        protected void UCPager_Change(object sender, EventArgs e)
        {
            BindData();
        }
    }
}