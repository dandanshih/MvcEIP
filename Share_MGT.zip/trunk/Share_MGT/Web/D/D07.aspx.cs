﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;
using GFC;

namespace Share_MGT.Web.D
{
	public partial class D07 : FormBase
	{
		private void BindCurrencyList()
		{
			// 取得幣值
			ddl_Currency.Items.Add(new ListItem()
			{
				Text = "全部",
				Value = "-1"
			});
			ddl_Currency.DataSource = SqlHelper.ExecuteDataset(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_S_Currency_List").Tables[0];
			ddl_Currency.DataBind();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindCurrencyList();
			}
		}

		// 查詢
		protected void btnQuery_Click(object sender, EventArgs e)
		{
			btn_Query_Click(sender, e);
		}

		// 帳戶總合帳查詢
		protected void btn_Query_Click (object sender, EventArgs e)
		{
			// 帳戶總合帳
			dsWinloseReport.SelectParameters["BeginDate"].DefaultValue = UCDateRange1.StartDate;
			dsWinloseReport.SelectParameters["EndDate"].DefaultValue = UCDateRange1.EndDate;
			dsWinloseReport.SelectParameters["AppNo"].DefaultValue = UCAppSelect1.AppNo.ToString();
			dsWinloseReport.SelectParameters["CurrencyNo"].DefaultValue = ddl_Currency.SelectedValue;
			dsWinloseReport.SelectParameters["MemberAccount"].DefaultValue = tbx_MemberAccount.Text;
			grdWinloseReport.DataBind();
			// 
			DetailQuery();
		}

		// 明細的查詢
		protected void grdList_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			// 按下明細的行為
			if (e.CommandName == "OnDetail")
			{
				string Item = e.CommandArgument.ToString();
				string strHttp = string.Format("D07_Edit.aspx?AppNo={0}&CurrencyNo={1}&MemberAccount={2}&DepositsItem={3}&BeginDate={4}&EndDate={5}"
					, UCAppSelect1.AppNo
					, ddl_Currency.SelectedValue
					, tbx_MemberAccount.Text.ToSafeString()
					, Item
					, UCDateRange1.StartDate
					, UCDateRange1.EndDate
					);
				
				// 開新的網頁
				GFC.Web.WebUtility.ResponseScript(Page, string.Format ("myWindow=window.open('{0}')", strHttp), GFC.Web.WebUtility.ResponseScriptPlace.NearFormEnd);
			}
		}

		void DetailQuery ()
		{
			// 做明細的查詢
			int TotalRecords = 0;
			DataSet objDS = null;
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@AppNo", UCAppSelect1.AppNo)
				, new SqlParameter("@CurrencyNo", ddl_Currency.SelectedValue)
				, new SqlParameter("@MemberAccount", tbx_MemberAccount.Text)
                , new SqlParameter("@BeginDate", UCDateRange1.StartDate)
                , new SqlParameter("@EndDate", UCDateRange1.EndDate)
				// 每頁筆數
				, new SqlParameter("@PageSize", UCPager1.PageSize)
				// 目前頁次
				, new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber)
				// 總筆數
				, new SqlParameter("@TotalRecords", TotalRecords)
			};
			param[param.Length - 1].Direction = ParameterDirection.Output;

			try
			{
				objDS = SqlHelper.ExecuteDataset
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"Game_Agent.dbo.NSP_AgentWeb_R_MemberAccountingLogDetail",
					param
				);
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(D07)).Error("D07::BindData", ex);
			}

			if (objDS == null)
			{
				TotalRecords = 0;
			}
			else
			{
				TotalRecords = int.Parse(param[param.Length - 1].Value.ToString());
			}

			grdDetail.DataSource = objDS;
			grdDetail.DataBind();

			// 取得總筆數
			UCPager1.RecordCount = TotalRecords;
			UCPager1.DataBind();
		}

		// 登出列表分頁事件
		protected void UCPager1_Change(object sender, EventArgs e)
		{
			DetailQuery();
		}
	}
}