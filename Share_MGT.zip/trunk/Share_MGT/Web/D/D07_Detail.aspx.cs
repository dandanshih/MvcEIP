﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC;
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.D
{
//	public partial class D07_Detail : System.Web.UI.Page
	public partial class D07_Detail : FormBase
	{
		void BindList()
		{
			// 從網頁參數列取得
			string AppNo = Request.QueryString["AppNo"].ToString();
			string CurrencyNo = Request.QueryString["CurrencyNo"].ToString();
			string MemberAccount = Request.QueryString["MemberAccount"].ToString();
			string DepositsItem = Request.QueryString["DepositsItem"].ToString();
			DateTime dBeginDate;
			DateTime.TryParse(Request.QueryString["BeginDate"].ToString().ToSafeString(), out dBeginDate);
			string BeginDate = dBeginDate.ToString("yyyy/MM/dd HH:mm:ss");
			DateTime dEndDate;
			DateTime.TryParse(Request.QueryString["EndDate"].ToString().ToSafeString(), out dEndDate);
			string EndDate = dEndDate.ToString("yyyy/MM/dd HH:mm:ss");
			//string BeginDate = "2014/01/01 10:00:00";
			//string EndDate = "2014/07/26 19:59:59";

			// 呼叫 Sp 取得
			int TotalRecords = 0;
			// 登入列表
			SqlParameter[] param = new SqlParameter[]
			{
                // 總筆數
				new SqlParameter("@TotalRecords", TotalRecords)
				// 每頁筆數
				, new SqlParameter("@PageSize", UCPager1.PageSize)
				// 目前頁次
				, new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber)
				// 其他資料
				, new SqlParameter("@AppNo", AppNo)
				, new SqlParameter("@CurrencyNo", CurrencyNo)
				, new SqlParameter("@MemberAccount", MemberAccount)
				, new SqlParameter("@BeginDate", BeginDate)
				, new SqlParameter("@EndDate", EndDate)
				, new SqlParameter("@DepositsItem", DepositsItem)
				
			};
			param[0].Direction = ParameterDirection.Output;
			grdDetail.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_MemberAccountingLogDetailByItem"
				, param
			).Tables[0];
			grdDetail.DataBind();
		}
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				BindList();
			}
		}
		// 登出列表分頁事件
		protected void UCPager1_Change(object sender, EventArgs e)
		{
			BindList();
		}
	}
}