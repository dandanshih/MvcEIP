﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.D
{
    public partial class D03 : FormBase
    {
        private void BindData()
        {
            int TotalRecords = 0;
            string MemberAccount = string.IsNullOrEmpty(tbx_MemberAccount.Text) ? string.Empty : tbx_MemberAccount.Text;
            DataSet objDS = null;

            SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@MemberAccount", MemberAccount),
                new SqlParameter("@KeyinStatus", chk_KeyinDescription.Checked ? "1" : "-1"),
				new SqlParameter("@KeyoutStatus", chk_KeyoutDescription.Checked ? "1" : "-1"),
                new SqlParameter("@AppNo", UCAppSelect1.AppNo),
				new SqlParameter("@PageSize", UCPager1.PageSize),
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
				new SqlParameter("@TotalRecords", TotalRecords)
			};

            param[param.Length - 1].Direction = ParameterDirection.Output;

            try
            {
                objDS = SqlHelper.ExecuteDataset
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_Member_Keyinout_List",
                    param
                );
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(D03)).Error("D03::BindData", ex);
            }

            if (objDS == null)
            {
                TotalRecords = 0;
            }
            else
            {
                TotalRecords = int.Parse(param[param.Length - 1].Value.ToString());
            }

            gv1.DataSource = objDS;
            gv1.DataBind();

            // 取得總筆數
            UCPager1.RecordCount = TotalRecords;
            UCPager1.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                UCPager1.CurrentPageNumber = 1;
                BindData();
            }
        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            // 重新搜尋時設定第一頁
            UCPager1.CurrentPageNumber = 1;
            BindData();
        }

        protected void UCPage1_Change(object sender, EventArgs e)
        {
            BindData();
        }

        // 洗分成功的資料，就隱藏手動洗分的按鈕
        protected void gv1_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                DataRowView objDRV = e.Row.DataItem as DataRowView;
                string strKeyinDescription = objDRV["KeyinDescription"].ToString();
                string strKeyoutDescription = objDRV["KeyoutDescription"].ToString();

                int keyoutStatus = Convert.ToInt32(objDRV["KeyoutStatus"]);

                // 判斷手動洗分按鈕的狀態
                Button objBtn = e.Row.Cells[e.Row.Cells.Count - 1].Controls[0] as Button;
                if (keyoutStatus == 1)
                {
                    objBtn.Visible = false;
                }
                else if (keyoutStatus == 0)
                {
                    objBtn.Text = "尚未離線";
                    objBtn.Enabled = false;
                }
            }
        }

        protected void gv1_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            if (e.CommandName.Equals("MemberKeyOut"))
            {
                int idx = Convert.ToInt32(e.CommandArgument);
                string memberID = gv1.DataKeys[idx]["MemberID"].ToString();
                string WID = string.IsNullOrEmpty(gv1.Rows[idx].Cells[3].Text) ? string.Empty : gv1.Rows[idx].Cells[3].Text;
                GoKeyout(memberID, WID);
                BindData();
            }
        }

        private void GoKeyout(string memberID, string wid)
        {
            SqlDataReader objSdr = SqlHelper.ExecuteReader(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_AgentWeb_A_Member_Keyout",
                new SqlParameter("@MemberID", memberID),
                new SqlParameter("@WID", wid));
            DataTable objTabOnlineID = new DataTable();
            objTabOnlineID.Columns.Add("OnlineID", typeof(long));
            while (objSdr.Read())
            {
                objTabOnlineID.LoadDataRow(new object[] { objSdr["OnlineID"] }, true);
            }
            objSdr.Close();
            objSdr.Dispose();
            objSdr = null;
            SqlParameter param = new SqlParameter("@OnlineID", objTabOnlineID);
            param.SqlDbType = SqlDbType.Structured;
            objSdr = SqlHelper.ExecuteReader(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "Game_Branch.dbo.NSP_Service_LogoutReady_GetPoint",
                param);

            string apiUrl = WebConfig.SeriesUrl + "/conversion/conversionlogout";
            while (objSdr.Read())
            {
                string appID = objSdr["AppID"].ToString();
                string appSecret = objSdr["AppSecret"].ToString();
                string userID = objSdr["MemberAccount"].ToString();
                decimal amount = Convert.ToInt32(objSdr["Point"]);
                string currency = objSdr["Currency"].ToString();
                var ls = new List<LogoutInto>();
                ls.Add(new LogoutInto()
                    {
                        UserID = userID,
                        WID = wid,
                        Amount = amount,
                        Currency = currency
                    });
                var keyinResult = ApiProcess.Run<List<LogoutInto>, LogoutOutputStruct>(
                    apiUrl,
                    appID,
                    appSecret,
                    ls);
            }
            objSdr.Close();
            objSdr.Dispose();
        }

        /// <summary>
        /// 登出資訊結構
        /// </summary>
        private struct LogoutInto
        {
            /// <summary>
            /// Gets or sets 玩家編號
            /// </summary>
            public string UserID { get; set; }

            /// <summary>
            /// Gets or sets 登入流水號
            /// </summary>
            public string WID { get; set; }

            /// <summary>
            /// Gets or sets 剩餘點數
            /// </summary>
            public decimal Amount { get; set; }

            /// <summary>
            /// Gets or sets 點數幣別
            /// </summary>
            public string Currency { get; set; }
        }

        /// <summary>
        /// 介接商登出回傳結構
        /// </summary>
        private struct LogoutOutputStruct
        {
            /// <summary>
            /// Gets or sets 回傳結果代碼
            /// </summary>
            public int ResultNo { get; set; }

            /// <summary>
            /// Gets or sets 回傳結果訊息
            /// </summary>
            public string ResultMsg { get; set; }
        }
    }
}