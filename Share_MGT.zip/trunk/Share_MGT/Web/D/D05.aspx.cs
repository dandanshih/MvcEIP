﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 為了每一頁所換的繼承
using GFC.Utilities;
using Share_MGT.AppLibs;
using System.Data;
using System.Data.SqlClient;

namespace Share_MGT.Web.D
{
	public partial class D05 : FormBase
    {
		// 做綁定資料的動作
		void BindList()
		{
			DataTable DBdt = null;
			// 分桶ＩＤ
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_A_Agent_App_List"
				, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_AppGroup.DataSource = DBdt;
			ddl_AppGroup.DataBind();
			ddl_AppGroup1.DataSource = DBdt;
			ddl_AppGroup1.DataBind();
			// 語言
			DBdt = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_S_Language_List"
				//, new SqlParameter("@AgentID", this.AUser.AgentID)
			).Tables[0];
			ddl_Lang.DataSource = DBdt;
			ddl_Lang.DataBind();
			ddl_Lang1.DataSource = DBdt;
			ddl_Lang1.DataBind();
			// 綁上日/時/分
			Dictionary<string, string> dictMap = new Dictionary<string, string>
			{
				{"Number", "System.String"}
				, {"Value", "System.Int32"}
			};
			// Default = 0
			DataTable dt = Utility.GetDataTable(dictMap);
			for (int Index = 0; Index < 3; Index++)
			{
				DataRow NewRow = dt.NewRow();
				NewRow["Number"] = Index.ToString();
				NewRow["Value"] = Index;
				dt.Rows.Add(NewRow);
			}
			ddl_day.DataSource = dt;
			ddl_day.DataBind();
			ddl_day.SelectedIndex = 0;
			// Default = 0
			dt = Utility.GetDataTable(dictMap);
			for (int Index = 0; Index < 24; Index++)
			{
				DataRow NewRow = dt.NewRow();
				NewRow["Number"] = Index.ToString();
				NewRow["Value"] = Index;
				dt.Rows.Add(NewRow);
			}
			// Default = 30
			ddl_hour.DataSource = dt;
			ddl_hour.DataBind();
			ddl_hour.SelectedIndex = 0;
			dt = Utility.GetDataTable(dictMap);
			for (int Index = 0; Index < 60; Index++)
			{
				DataRow NewRow = dt.NewRow();
				NewRow["Number"] = Index.ToString();
				NewRow["Value"] = Index;
				dt.Rows.Add(NewRow);
			}
			ddl_min.DataSource = dt;
			ddl_min.DataBind();
			ddl_min.SelectedIndex = 30;
		}

		// 只要 Reload Page 要做的事情
		protected void Page_Load(object sender, EventArgs e)
		{
			// 如果是由 Link 過來的, 也就是只要做一次
			if (!IsPostBack)
			{
				BindList();
				// 更新歷史
				UpdateHistory();
			}
		}

		// 從 DB 更新資料
		void UpdateHistory()
		{
			// 呼叫 Sp 取得
			int TotalRecords = 0;
			// 登入列表
			SqlParameter[] param = new SqlParameter[]
			{
                // 總筆數
				new SqlParameter("@TotalRecords", TotalRecords)
				// 每頁筆數
				, new SqlParameter("@PageSize", UCPager1.PageSize)
				// 目前頁次
				, new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber)
				// 其他資料
				, new SqlParameter("@AgentID", this.AUser.AgentID)
				, new SqlParameter("@BType", "0")
				
			};
			param[0].Direction = ParameterDirection.Output;
			grdDetail.DataSource = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_R_HistoryBulletin_Get"
				, param
			).Tables[0];
			grdDetail.DataBind();
		}

		// 按下[發送]行為
		protected void btn_Query_Click(object sender, EventArgs e)
		{
			// 取得資料
			string AppNo = ddl_AppGroup.SelectedValue;
			string LanguageNo = ddl_Lang.SelectedValue;
			string strTitle = "";
			string strMessage = tb_Message.Text;
			// StartTime
			string StartDate = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
			int Day = System.Convert.ToInt32(ddl_day.SelectedValue);
			int Hour = System.Convert.ToInt32(ddl_hour.SelectedValue);
			int Min = System.Convert.ToInt32(ddl_min.SelectedValue);
			string EndDate = System.DateTime.Now.AddDays(Day).AddHours(Hour).AddMinutes(Min).ToString("yyyy/MM/dd HH:mm:ss");
			// 跑資料
			SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_B_Bulletin_New"
				, new SqlParameter("@AppNo", AppNo)
				, new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
				, new SqlParameter("@StartDate", StartDate)
				, new SqlParameter("@EndDate", EndDate)
				, new SqlParameter("@BType", "game1")
				, new SqlParameter("@BContent", strMessage)
				, new SqlParameter("@Title", strTitle)
				, new SqlParameter("@SleepSeconds", "0")
				, new SqlParameter("@Flag", -1)
				, new SqlParameter("@LanguageNo", LanguageNo)
			);
			UpdateHistory();
		}

		protected void btn_Query_Normal_Click(object sender, EventArgs e)
		{
			// 取得資料
			string AppNo = ddl_AppGroup1.SelectedValue;
			string LanguageNo = ddl_Lang1.SelectedValue;
			string strTitle = "";
			string strMessage = tb_Normal.Text;
			// StartTime
			string StartDate = UCDateRange1.StartDate;
			string EndDate = UCDateRange1.EndDate;
			// 跑資料
			SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_AgentWeb_B_Bulletin_New"
				, new SqlParameter("@AppNo", AppNo)
				, new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
				, new SqlParameter("@StartDate", StartDate)
				, new SqlParameter("@EndDate", EndDate)
				, new SqlParameter("@BType", "game2")
				, new SqlParameter("@BContent", strMessage)
				, new SqlParameter("@Title", strTitle)
				, new SqlParameter("@SleepSeconds", "0")
				, new SqlParameter("@Flag", -1)
				, new SqlParameter("@LanguageNo", LanguageNo)
			);
			UpdateHistory();
		}

		// 登出列表分頁事件
		protected void UCPager1_Change(object sender, EventArgs e)
		{
			UpdateHistory();
		}

		protected void grdDetail_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			//　按我停用
			if (e.CommandName == "OnAction")
			{
				// 取得 ＩＤ
				int BulletinID = System.Convert.ToInt32(e.CommandArgument);
				SqlHelper.ExecuteDataset
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_B_Bulletin_Pause"
					, new SqlParameter("@BulletinID", BulletinID)
					, new SqlParameter("@UpdateAgentID", this.AUser.AgentID)
				);
				UpdateHistory();
			}
			else if (e.CommandName == "OnEdit")
			{
			}
			else if (e.CommandName == "OnDelete")
			{
			}
		}

		#region 轉換公告類型

		public static string GetBulletinString(object Value)
		{
			return "";
		}

		#endregion

		#region 轉換按鈕狀態

		public bool IsVisible(object oPause)
		{
			return false;
		}

		static string GetIsPause(object STATE)
		{
			string strState = STATE.ToString();
			if (strState == "OverDue")
				return "0";
			else if (strState == "Paused")
				return "0";
			else
				return "1";
		}

		public static string GetPauseString(object STATE)
		{
			string strState = STATE.ToString();
			if (strState == "OverDue")
				return "己經過期";
			else if (strState == "Paused")
				return "被暫停";
			else
				return "按我停用";
		}

		public static System.Drawing.Color GetPauseStringColor(object STATE)
		{
			string strIsPause = GetIsPause(STATE);
			if (strIsPause == "0")
				return System.Drawing.Color.Red;
			return System.Drawing.Color.Black;
		}

		public static bool GetPauseStringEnable(object STATE)
		{
			string strIsPause = GetIsPause(STATE);
			if (strIsPause == "0")
				return false;
			return true;
		}

		#endregion
	}
}