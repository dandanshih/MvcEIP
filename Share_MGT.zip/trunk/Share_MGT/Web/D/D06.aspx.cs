﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.D
{
    public partial class D06 : FormBase
    {
        private void BindData()
        {
            pnl_Detail.Visible = true;
            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@AppNo", UCAppSelect1.AppNo),
                new SqlParameter("@MemberAccount", tbx_MemberAccont.Text),
                new SqlParameter("@AgentID", this.AUser.AgentID)
            };
            SqlDataReader objSdr = SqlHelper.ExecuteReader(
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_A_Member_GetDataByAccount",
                objParam);
            if (objSdr.Read())
            {
                lbl_MemberAccount.Text = objSdr["MemberAccount"].ToString();
                lbl_NickName.Text = objSdr["NickName"].ToString();
                lbl_Currency.Text = objSdr["Currency"].ToString();
                lbl_Point.Text = objSdr["Point"].ToString();
                cb_IsOnline.Checked = objSdr["IsOnline"].ToString() == "1";
                mv.ActiveViewIndex = 0;
            }
            else
            {
                mv.ActiveViewIndex = 1;
            }
            objSdr.Close();
            objSdr.Dispose();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Query_Click(object sender, EventArgs e)
        {
            BindData();
        }
    }
}