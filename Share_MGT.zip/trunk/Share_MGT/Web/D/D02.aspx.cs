﻿using GFC.Utilities;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.D
{
    public partial class D02 : FormBase
    {
        private void BindData()
		{
			
			DataSet objDS = null;

			SqlParameter[] param = new SqlParameter[]
			{
                // 總筆數
				new SqlParameter("@TotalRecords", SqlDbType.Int),
				// 帳號
				new SqlParameter("@MemberAccount", tbx_MemberAccount.Text),
				// 單號
				new SqlParameter("@WID", tbx_WID.Text),
				// 遊戲編號
				new SqlParameter("@GameID", UCGameSelect1.GameSeletedValue == "0" ? "-1" : UCGameSelect1.GameSeletedValue),
				// 每頁筆數
				new SqlParameter("@PageSize", UCPager1.PageSize),
                // 排列順序
                //new SqlParameter("@OrderBy", "DESC"),
				// 目前頁次
				new SqlParameter("@PageIndex", UCPager1.CurrentPageNumber),
                // 分桶編號
                new SqlParameter("@AppNo", UCAppSelect1.AppNo)
			};

			param[0].Direction = ParameterDirection.Output;

			try
			{
				objDS = SqlHelper.ExecuteDataset
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
                    "NSP_AgentWeb_R_WinloseLog",
					param
				);
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(D02)).Error("D05::BindData", ex);
			}

			object obj = param[0].Value;
			if (obj != null && obj != DBNull.Value)
			{
				TBGridView1.DataSource = objDS;
				TBGridView1.DataBind();

				// 取得總比數
                UCPager1.RecordCount = int.Parse(obj.ToString());
				UCPager1.DataBind();
			}
		}

		protected void Page_Load(object sender, EventArgs e)
		{
            //string jsShowMovie = "function ShowMovie(GameID, GroupID, TableID, SeatID, RoundID, GameTypeID, MemberID, Auth) {" +
            //                     "$('#ifMovie').attr('src', '" + "http://" + WebConfig.LogWebDomain + "/Review.aspx" +
            //                     "?GameID=' + GameID + '&GroupID=' + GroupID + '&TableID=' + TableID + '&SeatID=' + SeatID + '&RoundID=' + RoundID + '&GameTypeID=' + GameTypeID + '&MemberID=' + MemberID + '&Auth=' + Auth);" +
            //                     "$('#divMovie').css('display','block');" +
            //                     "scroller('divMovie', 400);" + "}";
            ////WebUtility.ResponseScript(Page, string.Empty, jsShowMovie, false);
            //ScriptManager.RegisterStartupScript(this, this.GetType(), Guid.NewGuid().ToString().Replace("-","").Substring(0, 12), jsShowMovie, true);

            //if (!IsPostBack)
            //{
            //    UCPager1.CurrentPageNumber = 1;
            //    BindData();
            //}
		}

		protected void btn_Query_Click(object sender, EventArgs e)
		{
			// 重新搜尋時設定第一頁
			UCPager1.CurrentPageNumber = 1;

			BindData();
		}

		/// <summary>
		/// 分頁事件
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void UCPage1_Change(object sender, EventArgs e)
		{
			BindData();
		}

        //protected void TBGridView1_RowDataBonud(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        string gameTypeID = DataBinder.Eval(e.Row.DataItem, "GameTypeID").ToString();
        //        string GameID = DataBinder.Eval(e.Row.DataItem, "GameID").ToString();
        //        string GroupID = DataBinder.Eval(e.Row.DataItem, "GroupID").ToString();
        //        string TableID = DataBinder.Eval(e.Row.DataItem, "TableID").ToString();
        //        // Ruby的座位數從DB出來有加1
        //        int SeatID = int.TryParse(DataBinder.Eval(e.Row.DataItem, "SeatID").ToString(), out SeatID) ? SeatID - 1 : 0;
        //        string RoundID = DataBinder.Eval(e.Row.DataItem, "RoundNo").ToString();
        //        string GameTypeID = DataBinder.Eval(e.Row.DataItem, "GameTypeID").ToString();
        //        string MemberID = DataBinder.Eval(e.Row.DataItem, "MemberID").ToString();

        //        switch (gameTypeID)
        //        {
        //            case "1":
        //                ((Button)e.Row.FindControl("btnMovie")).Visible = false;
        //                break;
        //            case "2":
        //                ((Button)e.Row.FindControl("btnMovie")).OnClientClick = string.Format
        //                (
        //                    "javascript:ShowMovie('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}'); return false;",
        //                    GameID,
        //                    GroupID,
        //                    TableID,
        //                    SeatID,
        //                    RoundID,
        //                    GameTypeID,
        //                    MemberID,
        //                    // 調閱室權限(1:RD 2:客服 3:玩家)
        //                    // AUser.ReviewAuthority.ToString()
        //                    3
        //                );
        //                break;
        //            case "3":
        //                ((Button)e.Row.FindControl("btnMovie")).OnClientClick = string.Format
        //                (
        //                    "javascript:ShowMovie('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}'); return false;",
        //                    GameID,
        //                    GroupID,
        //                    TableID,
        //                    SeatID,
        //                    RoundID,
        //                    GameTypeID,
        //                    MemberID,
        //                    // 調閱室權限(1:RD 2:客服 3:玩家)。
        //                    // AUser.ReviewAuthority.ToString()
        //                    3
        //                );
        //                break;
        //            default:
        //                break;
        //        }
        //    }
        //}
    }
}