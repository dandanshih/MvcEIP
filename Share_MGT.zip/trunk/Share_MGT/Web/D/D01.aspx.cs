﻿using GFC.Utilities;
using GS.ServerCommander;
using Share_MGT.AppLibs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Share_MGT.Web.D
{
    public partial class D01 : FormBase
    {
        #region Private Method
        /// <summary>
        /// 取得會員編號
        /// </summary>
        /// <param name="MemberAccount">會員帳號</param>
        /// <returns>會員編號</returns>
        private string GetMemberID(string MemberAccount)
        {
            string MemberID = "0";

            try
            {
                using (SqlDataReader objDtr = SqlHelper.ExecuteReader(
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_A_Member_GetDataByAccount",
                    new SqlParameter("@AppNo", UCAppSelect1.AppNo),
                    new SqlParameter("@MemberAccount", MemberAccount),
                    new SqlParameter("@AgentID", this.AUser.AgentID)))
                {
                    if (objDtr.Read())
                    {
                        MemberID = objDtr["MemberID"].ToString();
                    }
                    objDtr.Close();
                    objDtr.Dispose();
                }
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(D01)).Error("GetMemberID", ex);
            }
            return MemberID;
        }

        private List<string> GetAllMemberID()
        {
            List<string> MemberIDList = new List<string>();

            try
            {
                using (SqlDataReader objDtr = SqlHelper.ExecuteReader(
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_A_MemberOnlineList",
                    new SqlParameter("@AppNo", UCAppSelect1.AppNo),
                    new SqlParameter("@AgentID", this.AUser.AgentID)))
                {
                    while (objDtr.Read())
                    {
                        MemberIDList.Add(objDtr["MemberID"].ToString());
                    }
                    objDtr.Close();
                    objDtr.Dispose();
                }
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(D01)).Error("GetAllMemberID", ex);
            }

            return MemberIDList;
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        // 踢單一會員
        protected void tbx_KickMember_Click(object sender, EventArgs e)
        {
            lbl_Result.Text = "";
            string MemberAccount = string.IsNullOrEmpty(tbx_MemberAccount.Text) ? "" : tbx_MemberAccount.Text;
            string MemberID = GetMemberID(MemberAccount);
            string result = FSCommander.FS_AS_WEB_KICK_USER(MemberID);
            lbl_Result.Text = result.Replace("\r\n", "") == "1" ? "True" : "False";
            tbx_log("tbx_KickMember_Click");
        }

        // 踢所有會員
        protected void tbx_KickAllMember_Click(object sender, EventArgs e)
        {
            lbl_Result.Text = "";
            List<string> list = GetAllMemberID();
            foreach (string MemberID in list)
            {
                FSCommander.FS_AS_WEB_KICK_USER(MemberID);
            }
            lbl_Result.Text = "True";
            tbx_log("tbx_KickAllMember_Click");
        }

        // 加入異動Log
        private void tbx_log(string tbx_name)
        {

            log4net.LogManager.GetLogger(typeof(D01)).DebugFormat
            (
                "C01::KickMember::IP:{0}, tbx_name:{1}, LoginAgent:{2}"
                , Request.UserHostAddress
                , tbx_name
                , Session["AUser"]
            );
        }
    }
}