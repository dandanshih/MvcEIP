﻿using System;

namespace Share_MGT.Web.B
{
	public partial class B02 : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}
	}
}