﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
    public partial class B07_Add : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
					// 編號
					new SqlParameter("@JPGroupID", Convert.ToInt32(tbx_JPType.Text)),
					// 名稱
					new SqlParameter("@JPGroupEName", tbx_JPTypeEName.Text),
					// 英文名稱
					new SqlParameter("@JPGroupName", tbx_JPTypeName.Text),
					// 是否啟用
					new SqlParameter("@IsEnabled", Convert.ToInt32(ddl_IsEnabled.SelectedValue)),
					// 類別
					new SqlParameter("@JPKind", Convert.ToInt32(ddl_JPKind.SelectedValue)),
                    // 備註
					new SqlParameter("@Memo", tbx_Memo.Text),
                    // 遊戲區域類型
					new SqlParameter("@GameAreaType", Convert.ToInt32(tbx_GameAreaType.Text))
            };
            try
            {
                // 執行
                SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPGroup_Add", param);
                Response.Redirect("B07.aspx");
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(Page, "alert('編號已存在，無法重覆新增!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}