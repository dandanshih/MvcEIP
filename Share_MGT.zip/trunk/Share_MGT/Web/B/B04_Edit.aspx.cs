﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
    public partial class B04_Edit : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_G_JPKind_GetByID",
                    new SqlParameter("@JPKindID", sid)
                );
                bool isRead = false;
                //繫結到相關欄位
                if (objDtr.Read())
                {
                    // 編號
                    lbl_JPKindID.Text = objDtr["JPKindID"].ToString();
                    // 名稱
                    tbx_JPKindName.Text = objDtr["JPKindName"].ToString();

                    isRead = true;
                }
                objDtr.Close();
                if (!isRead)
                {
                    WebUtility.ResponseScript(Page, "alert('要修改的資料不存在!!\\n請按下確定後返回!!');location.href='B04.aspx';", WebUtility.ResponseScriptPlace.NearFormEnd);
                }
            }
        }
        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
				Utility.ShowDialog("權限不足", "history.back();");
			}

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
                // 編號
                new SqlParameter("@JPKind",Convert.ToInt32(lbl_JPKindID.Text)),
				// 英文名稱
				new SqlParameter("@JPKindName", tbx_JPKindName.Text)
            };
            try
            {
                // 執行
                SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPKind_Edit", param);
                Response.Redirect("B04.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}