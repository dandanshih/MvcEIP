﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
    public partial class B07_Edit : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_G_JPType_QueryByJPType",
                    new SqlParameter("@JPType", sid)
                );
                bool isRead = false;
                //繫結到相關欄位
                if (objDtr.Read())
                {
                    // 編號
                    lbl_JPType.Text = objDtr["JPGroupID"].ToString();
                    // 名稱
                    tbx_JPTypeName.Text = objDtr["JPGroupName"].ToString();
                    // 英文名稱
                    tbx_JPTypeEName.Text = objDtr["JPGroupEName"].ToString();
                    // 是否啟用
                    ddl_IsEnabled.SelectedValue = objDtr["IsEnabled"].ToString();
                    // 類別
                    ddl_JPKind.SelectedValue = objDtr["JPKind"].ToString();
                    // 備註
                    tbx_Memo.Text = objDtr["Memo"].ToString();
                    // 遊戲區域類型
                    tbx_GameAreaType.Text = objDtr["GameAreaType"].ToString();

                    isRead = true;
                }
                objDtr.Close();
                if (!isRead)
                {
                    WebUtility.ResponseScript(Page, "alert('要修改的資料不存在!!\\n請按下確定後返回!!');location.href='B04.aspx';", WebUtility.ResponseScriptPlace.NearFormEnd);
                }
            }
        }
        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
					// 編號
					new SqlParameter("@JPGroup", Convert.ToInt32(lbl_JPType.Text)),
					// 名稱
					new SqlParameter("@JPGroupEName", tbx_JPTypeEName.Text),
					// 英文名稱
					new SqlParameter("@JPGroupName", tbx_JPTypeName.Text),
					// 是否啟用
					new SqlParameter("@IsEnabled", Convert.ToInt32(ddl_IsEnabled.SelectedValue)),
					// 類別
					new SqlParameter("@JPKind", Convert.ToInt32(ddl_JPKind.SelectedValue)),
                    // 備註
					new SqlParameter("@Memo", tbx_Memo.Text),
                    // 遊戲區域類型
					new SqlParameter("@GameAreaType", Convert.ToInt32(tbx_GameAreaType.Text))
            };
            try
            {
                // 執行
                SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPGroup_Edit", param);
                Response.Redirect("B07.aspx");
            }
            catch (Exception ex)
            {
                WebUtility.ResponseScript(Page, "alert('編號不存在，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}