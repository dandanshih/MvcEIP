﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
	public partial class B03_Add : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}

		// 新增資料
		protected void btn_Add_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid) && this.Authority.IsAddable)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				// SQL參數
				SqlParameter[] param = new SqlParameter[] 
				{
					// 群組名稱
					new SqlParameter("@GameTypeName", tbx_GameTypeName.Text),
					// 權限名稱
					new SqlParameter("@GameTypeEName", tbx_GameTypeEName.Text),
					// 排列順序
					new SqlParameter("@OrderSeq", tbx_OrderSeq.Text),
                    // 是否為免費遊戲
					new SqlParameter("@IsFreeGame", chk_IsFreeGame.Checked),
					// 是否啟用
					new SqlParameter("@IsEnabled", chk_IsEnabled.Checked)
				};

				// 執行
				SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_GameType_Add", param);
				Response.Redirect("B03.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back()");
			}
		}
	}
}