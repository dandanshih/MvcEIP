﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
    public partial class B06_Add : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsAddable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {				
				// 彩金模式名稱
				new SqlParameter("@JPModeName", tbx_JPModeName.Text),
				// 備註
				new SqlParameter("@Memo", tbx_Memo.Text)
            };
            try
            {
                // 執行
                SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPMode_Add", param);
                Response.Redirect("B06.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}