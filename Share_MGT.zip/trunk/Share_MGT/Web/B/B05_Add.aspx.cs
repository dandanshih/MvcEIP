﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
    public partial class B05_Add : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // 新增資料
        protected void btn_Add_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsAddable) == false)
            {
				Utility.ShowDialog("權限不足", "history.back();");
			}

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
					// 彩金群組編號
					new SqlParameter("@JPType", Convert.ToInt32(ddl_JPGroup.SelectedValue)),
					// 彩金類別序號
					new SqlParameter("@JPWinType", Convert.ToInt32(tbx_JPWinType.Text)),
					// 英文名稱
					new SqlParameter("@JPWinTypeEName", tbx_JPWinTypeEName.Text),
					// 名稱
					new SqlParameter("@JPWinTypeName", tbx_JPWinTypeName.Text),
            };
            try
            {
                // 執行
                if (SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPWinType_Add", param).ToString().Equals("0"))
                {
                    Response.Redirect("B05.aspx");
                }
                else
                {
                    WebUtility.ResponseScript(Page, "alert('彩金類別序號已存在，無法重覆新增!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}