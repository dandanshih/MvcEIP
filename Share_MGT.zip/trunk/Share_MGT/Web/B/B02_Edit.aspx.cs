﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
	public partial class B02_Edit : Share_MGT.AppLibs.FormBase
	{
		// 取出要修改的資料
		protected void Page_Load(object sender, EventArgs e)
		{

			if (!IsPostBack)
			{
				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				//取出該筆資料
				SqlDataReader objDtr = SqlHelper.ExecuteReader
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_A_AgentGroup_List",
					new SqlParameter("@AgentGroupID", sid)
				);

				//繫結到相關欄位
				if (objDtr.Read())
				{
					// 名稱
					tbx_AgentGroupName.Text = objDtr["AgentGroupName"].ToString();
					// 英文名稱
					tbx_AgentGroupEName.Text = objDtr["AgentGroupEName"].ToString();
					// 順序
					tbx_AgentGroupSeq.Text = objDtr["AgentGroupSeq"].ToString();
				}

				objDtr.Close();
			}
		}

		// 修改資料
		protected void btn_Edit_Click(object sender, EventArgs e)
		{
			if ((IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				// SQL參數
				SqlParameter[] param = new SqlParameter[] 
				{
					// 名稱
					new SqlParameter("@AgentGroupName", tbx_AgentGroupName.Text),
					// 英文名稱
					new SqlParameter("@AgentGroupEName", tbx_AgentGroupEName.Text),
					// 順序
					new SqlParameter("@AgentGroupSeq", tbx_AgentGroupSeq.Text),
					// 編號
					new SqlParameter("@AgentGroupID", sid)
				};

				// 執行
				SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_A_AgentGroup_Edit", param);
				Response.Redirect("B02.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}