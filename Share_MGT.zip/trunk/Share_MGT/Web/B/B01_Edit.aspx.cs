﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
	public partial class B01_Edit : Share_MGT.AppLibs.FormBase
	{
		// 取得要修改的資料
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				//取出該筆資料
				SqlDataReader objDtr = SqlHelper.ExecuteReader
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_S_AgentWeb_Authority_List",
					new SqlParameter("@FlagBit", sid)
				);

				//繫結到相關欄位
				if (objDtr.Read())
				{
					// FlagBit
					tbx_FlagBit.Text = objDtr["FlagBit"].ToString();
					// 權限名稱
					tbx_AuthorityName.Text = objDtr["AuthorityName"].ToString();
					// 排列順序
					tbx_AuthoritySeq.Text = objDtr["AuthoritySeq"].ToString();
					// 備註
					tbx_Comment.Text = objDtr["Comment"].ToString();
				}

				objDtr.Close();
			}
		}

		// 修改資料
		protected void btn_Edit_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{

				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				// SQL參數
				SqlParameter[] param = new SqlParameter[] 
				{
					// FlagBit
					new SqlParameter("@FlagBit", tbx_FlagBit.Text),
					// 權限名稱
					new SqlParameter("@AuthorityName", tbx_AuthorityName.Text),
					// 排列順序
					new SqlParameter("@AuthoritySeq", tbx_AuthoritySeq.Text),
					// 備註
					new SqlParameter("@Comment", tbx_Comment.Text),
					// 原編號
					new SqlParameter("@SID", sid)
				};
				
				// 執行
				SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_S_AgentWeb_Authority_Edit", param);
				Response.Redirect("B01.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}