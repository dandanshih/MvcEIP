﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
	public partial class B03_Edit : Share_MGT.AppLibs.FormBase
	{
		// 取出要修改的資料
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				//取出該筆資料
				SqlDataReader objDtr = SqlHelper.ExecuteReader
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_AgentWeb_G_GameType_List",
					new SqlParameter("@GameTypeID", sid)
				);

				//繫結到相關欄位
				if (objDtr.Read())
				{
					// 名稱
					tbx_GameTypeName.Text = objDtr["GameTypeName"].ToString();
					// 英文名稱
					tbx_GameTypeEName.Text = objDtr["GameTypeEName"].ToString();
					// 順序
					tbx_OrderSeq.Text = objDtr["OrderSeq"].ToString();
					// 是否為免費遊戲
                    chk_IsFreeGame.Checked = (bool)objDtr["IsFreeGame"];
                    // 是否啟用
                    chk_IsEnabled.Checked = (bool)objDtr["IsEnabled"];
				}

				objDtr.Close();
			}
		}

		// 修改資料
		protected void btn_Edit_Click(object sender, EventArgs e)
		{
			if ((IsValid && this.Authority.IsEditable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

				// SQL參數
				SqlParameter[] param = new SqlParameter[] 
				{
					// 編號
					new SqlParameter("@GameTypeID", sid),
					// 群組名稱
					new SqlParameter("@GameTypeName", tbx_GameTypeName.Text),
					// 權限名稱
					new SqlParameter("@GameTypeEName", tbx_GameTypeEName.Text),
					// 排列順序
					new SqlParameter("@OrderSeq", tbx_OrderSeq.Text),
					// 是否啟用
					new SqlParameter("@IsEnabled", chk_IsEnabled.Checked)
				};

				// 執行
				SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_GameType_Edit", param);
				Response.Redirect("B03.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back()");
			}
		}
	}
}