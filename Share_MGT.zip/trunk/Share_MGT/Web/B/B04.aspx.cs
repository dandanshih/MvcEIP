﻿using System;

namespace Share_MGT.Web.B
{
    public partial class B04 : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
			this.Button1.Visible = this.Authority.IsAddable;
        }
    }
}