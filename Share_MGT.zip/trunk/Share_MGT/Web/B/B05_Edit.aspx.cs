﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using GFC.Web;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
    public partial class B05_Edit : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_G_JPWinType_QueryByJPWinTypeID",
                    new SqlParameter("@JPWinTypeID", sid)
                );
                bool isRead = false;
                //繫結到相關欄位
                if (objDtr.Read())
                {
                    ddl_JPGroup.DataBind();
                    // 編號                    
                    lbl_JPWinTypeID.Text = objDtr["JPWinTypeID"].ToString();
                    // 彩金群組編號
                    if (ddl_JPGroup.Items.FindByValue(objDtr["JPGroupID"].ToString()) == null)
                    { ddl_JPGroup.SelectedIndex = -1; }
                    else
                    { ddl_JPGroup.SelectedValue = objDtr["JPGroupID"].ToString(); }
                    // 彩金類別序號
                    tbx_JPWinType.Text = objDtr["JPWinType"].ToString();
                    // 名稱
                    tbx_JPWinTypeName.Text = objDtr["JPWinTypeName"].ToString();
                    // 英文名稱
                    tbx_JPWinTypeEName.Text = objDtr["JPWinTypeEName"].ToString();
                    // 是否啟用
                    isRead = true;
                }
                objDtr.Close();
                if (!isRead)
                {
                    WebUtility.ResponseScript(Page, "alert('要修改的資料不存在!!\\n請按下確定後返回!!');location.href='B05.aspx';", WebUtility.ResponseScriptPlace.NearFormEnd);
                }
            }
        }
        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
				Utility.ShowDialog("權限不足", "history.back();");
			}

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
                // 編號
                new SqlParameter("@JPWinTypeID",Convert.ToInt32(lbl_JPWinTypeID.Text)),
				// 彩金類別編號                        
				new SqlParameter("@JPType", Convert.ToInt32(ddl_JPGroup.SelectedValue)),
				// 彩金類別序號
				new SqlParameter("@JPWinType", Convert.ToInt32(tbx_JPWinType.Text)),
				// 英文名稱
				new SqlParameter("@JPWinTypeEName", tbx_JPWinTypeEName.Text),
				// 名稱
				new SqlParameter("@JPWinTypeName", tbx_JPWinTypeName.Text),
            };
            try
            {
                // 執行
                switch (SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPWinType_Edit", param).ToString())
                { 
                    case "0":
                        Response.Redirect("B05.aspx");
                        break;
                    case "1":
                        WebUtility.ResponseScript(Page, "alert('彩金類別序號重覆，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                    case "2":
                        WebUtility.ResponseScript(Page, "alert('編號不存在，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                    default:
                        WebUtility.ResponseScript(Page, "alert('發生未知的錯誤，修改失敗!!');", WebUtility.ResponseScriptPlace.NearFormEnd);
                        break;
                }
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}