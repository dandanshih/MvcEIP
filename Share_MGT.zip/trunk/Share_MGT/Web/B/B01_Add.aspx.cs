﻿using System;
using System.Data;
using System.Data.SqlClient;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
	public partial class B01_Add : Share_MGT.AppLibs.FormBase
	{
		protected void Page_Load(object sender, EventArgs e)
		{
		}

		// 新增資料
		protected void btn_Add_Click(object sender, EventArgs e)
		{
			if ((Page.IsValid && this.Authority.IsAddable) == false)
			{
				Utility.ShowDialog("權限不足", "history.back();");
			}

			try
			{
				// SQL參數
				SqlParameter[] param = new SqlParameter[] 
				{
					// FlagBit
					new SqlParameter("@FlagBit", tbx_FlagBit.Text),
					// 權限名稱
					new SqlParameter("@AuthorityName", tbx_AuthorityName.Text),
					// 排列順序
					new SqlParameter("@AuthoritySeq", tbx_AuthoritySeq.Text),
					// 備註
					new SqlParameter("@Comment", tbx_Comment.Text)
				};

				// 執行
				SqlHelper.ExecuteNonQuery(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_S_AgentWeb_Authority_Add", param);
				Response.Redirect("B01.aspx");
			}
			catch (Exception ex)
			{
				Utility.ShowDialog(ex.Message, "history.back();");
			}
		}
	}
}