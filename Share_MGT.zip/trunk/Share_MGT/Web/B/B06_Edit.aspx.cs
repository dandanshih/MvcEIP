﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using GFC.Utilities;
using Share_MGT.AppLibs;

namespace Share_MGT.Web.B
{
    public partial class B06_Edit : Share_MGT.AppLibs.FormBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int sid = int.TryParse(Request.QueryString["sid"], out sid) ? sid : -1;

                //取出該筆資料
                SqlDataReader objDtr = SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_AgentWeb_G_JPMode_GetByID",
                    new SqlParameter("@JPMode", sid)
                );
                //繫結到相關欄位
                if (objDtr.Read())
                {
                    // 編號                    
                    lbl_JPMode.Text = objDtr["JPMode"].ToString();
                    // 彩金模式名稱
                    tbx_JPModeName.Text = objDtr["JPModeName"].ToString();
                    // 備註
                    tbx_Memo.Text = objDtr["Memo"].ToString();
                }
                objDtr.Close();
            }
        }
        // 修改資料
        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            if ((Page.IsValid && this.Authority.IsEditable) == false)
            {
                Utility.ShowDialog("權限不足", "history.back();");
            }

            // SQL參數
            SqlParameter[] param = new SqlParameter[]
            {
                // 編號
                new SqlParameter("@JPMode",Convert.ToInt32(lbl_JPMode.Text)),				
				// 彩金模式名稱
				new SqlParameter("@JPModeName", tbx_JPModeName.Text),
				// 備註
				new SqlParameter("@Memo", tbx_Memo.Text)
            };
            try
            {
                // 執行
                SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.StoredProcedure, "NSP_AgentWeb_G_JPMode_Edit", param);
                Response.Redirect("B06.aspx");
            }
            catch (Exception ex)
            {
                Utility.ShowDialog(ex.Message, "history.back();");
            }
        }
    }
}