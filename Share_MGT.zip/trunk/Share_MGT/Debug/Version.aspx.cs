﻿using System;
using System.Reflection;

namespace Share_MGT.Debug
{
	public partial class Version : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			Assembly objAsm = Assembly.GetExecutingAssembly();
			lblVersion.Text = objAsm.GetName().Version.ToString();
		}
	}
}