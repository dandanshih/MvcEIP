﻿//-----------------------------------------------------------------------
// <copyright file="IDataCache.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace SGT.CachedSQLCommander
{
    /// <summary>
    /// IDataCache Class
    /// </summary>
    public interface IDataCache
    {
        /// <summary>
        /// 經由 cache 機制讀出序列化物件
        /// </summary>
        /// <param name="key">索引值</param>
        /// <returns>資料物件</returns>
        object GetData(string key);

        /// <summary>
        /// 經由 cache 機制寫入序列化物件
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="obj">資料物件</param>
        void SetData(string key, object obj);

        /// <summary>
        /// 從資料庫取得 byte []
        /// </summary>
        /// <param name="key">索引值</param>
        /// <returns>資料內容</returns>
        byte[] GetRealData(string key);

        /// <summary>
        /// 將data 回寫回資料庫
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="data">資料內容</param>
        /// <returns>成功 / 失敗</returns>
        bool SetRealData(string key, byte[] data);
    }
}
