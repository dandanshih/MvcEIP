﻿//-----------------------------------------------------------------------
// <copyright file="Cached_ServerStruct{TData}.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace SGT.CachedSQLCommander
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using SGT.CachedSQLCommander.Libs;

    /// <summary>
    /// 將資料以Server互傳Struct方式處理
    /// </summary>
    /// <typeparam name="TData">Struct結構</typeparam>
    public class Cached_ServerStruct<TData> : CachedBase<TData>
    {
        #region CachedBase<TData> 成員
        /// <summary>
        /// 將Byte[] 轉換成 TData 型別
        /// </summary>
        /// <param name="arry">byte[] 類型之資料</param>
        /// <returns>轉換後之TData 類型資料</returns>
        protected override TData ConvertToData(byte[] arry)
        {
            return Converter.ByteArrayTo<TData>(arry);
        }

        /// <summary>
        /// 將TData 轉換成 byte[]
        /// </summary>
        /// <param name="data">TData 類型之資料</param>
        /// <returns>轉換後之byte[] 類型資料</returns>
        protected override byte[] ConvertToBytes(TData data)
        {
            return Converter.ToByteArray(data);
        }
        #endregion
    }
}
