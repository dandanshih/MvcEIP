﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGT.CachedSQLCommander
{
    /// <summary>
    /// 儲存 Object 與 cas 的類別
    /// </summary>
    public class MemObject
    {
        private object m_obj = null;
        private ulong m_cas = 0;
        public MemObject()
        {
        }

        public MemObject(object obj, ulong cas)
        {
            m_obj = obj;
            m_cas = cas;
        }

        /// <summary>
        /// 取得物件
        /// </summary>
        public object obj
        {
            get { return m_obj; }
            set { m_obj = value; }
        }

        public ulong cas
        {
            get { return m_cas; }
            set { m_cas = value; }
        }
    }
}
