﻿//-----------------------------------------------------------------------
// <copyright file="Converter.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace SGT.CachedSQLCommander.Libs
{
    using System;
    using System.Runtime.InteropServices;

    /// <summary>
    /// 將 C# 的 Struct 改成 ByteArray ，使用這個的可以讓記憶體中的 Struct 直接轉換成 ByteArray
    /// 而不使用 Serialize 的原因是因為 C# 會多寫一些他自己語言特性的資料在裡面，會讓整個 Size 變大
    /// </summary>
    public class Converter
    {
        /// <summary>
        /// 將 Struct 變成 ByteArray
        /// </summary>
        /// <param name="obj">要轉換的物件</param>
        /// <returns>回傳 ByteArray </returns>
        public static byte[] ToByteArray(object obj)
        {
            int length = Marshal.SizeOf(obj);
            byte[] bytearray = new byte[length];
            IntPtr ptr = Marshal.AllocHGlobal(length);
            Marshal.StructureToPtr(obj, ptr, false);
            Marshal.Copy(ptr, bytearray, 0, length);
            Marshal.FreeHGlobal(ptr);
            return bytearray;
        }

        /// <summary>
        /// 將 ByteArray 轉換回指定的 Struct
        /// </summary>
        /// <typeparam name="T">要轉換的目標型別</typeparam>
        /// <param name="bytes">要轉換的 ByteArray</param>
        /// <returns>轉換後的目標型別</returns>
        public static T ByteArrayTo<T>(byte[] bytes)
        {
            GCHandle handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
            T stuff = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
            handle.Free();
            return stuff;
        }
    }
}
