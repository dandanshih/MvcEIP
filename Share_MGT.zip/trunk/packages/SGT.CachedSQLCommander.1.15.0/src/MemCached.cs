﻿//-----------------------------------------------------------------------
// <copyright file="MemCache.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace SGT.CachedSQLCommander
{
    using Enyim.Caching;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    /// <summary>
    /// MemCache Class
    /// </summary>
    public sealed class MemCached
    {
        private static volatile MemcachedClient mem_client;

        private static object syncRoot = new Object();

        public static MemcachedClient Instance
        {
            get
            {
                if (mem_client == null)
                {
                    lock (syncRoot)
                    {
                        if (mem_client == null)
                        {
                            mem_client = new MemcachedClient();
                        }
                    }
                }
                return mem_client;
            }
        }
    }
}
