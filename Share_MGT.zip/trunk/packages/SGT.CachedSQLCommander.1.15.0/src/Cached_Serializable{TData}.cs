﻿//-----------------------------------------------------------------------
// <copyright file="Cached_Serializable{TData}.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace SGT.CachedSQLCommander
{
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;

    /// <summary>
    /// 可序列化結構類別
    /// </summary>
    /// <typeparam name="TData">Struct結構</typeparam>
    public class Cached_Serializable<TData> : CachedBase<TData>
    {
        #region CachedBase<TData> 成員
        /// <summary>
        /// 將資料以序列化方式轉換成TData
        /// </summary>
        /// <param name="arry">byte[] 類型之資料</param>
        /// <returns>轉換後之TData 類型資料</returns>
        protected override TData ConvertToData(byte[] arry)
        {
            TData data = default(TData);
            using (MemoryStream ms = new MemoryStream(arry))
            {
                BinaryFormatter bf = new BinaryFormatter();
                data = (TData)bf.Deserialize(ms);
            }

            return data;
        }

        /// <summary>
        /// 將資料以序列化方式轉換成byte[]
        /// </summary>
        /// <param name="data">TData 類型之資料</param>
        /// <returns>轉換後之byte[] 類型資料</returns>
        protected override byte[] ConvertToBytes(TData data)
        {
            byte[] arry = null;
            using (MemoryStream ms = new MemoryStream())
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ms, data);
                arry = ms.ToArray();
            }

            return arry;
        }
        #endregion
    }
}
