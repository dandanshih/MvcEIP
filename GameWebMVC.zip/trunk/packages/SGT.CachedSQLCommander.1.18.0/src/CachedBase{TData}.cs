﻿//-----------------------------------------------------------------------
// <copyright file="CachedBase{TData}.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace SGT.CachedSQLCommander
{
    using Enyim.Caching;
    using Enyim.Caching.Memcached;

    /// <summary>
    /// 抽象類別，實做此類別為各種資料格式進行轉型
    /// </summary>
    /// <typeparam name="TData">Struct結構</typeparam>
    public abstract class CachedBase<TData>
    {
        #region Properties
        /// <summary>
        /// Cas 編號
        /// </summary>
        private ulong casID;

        /// <summary>
        /// Gets: MemCached Client
        /// </summary>
        protected MemcachedClient MemClient
        {
            get
            {
                return MemCached.Instance;
            }
        }
        #endregion

        #region Public Method
        /// <summary>
        /// 取得MemCached資料
        /// </summary>
        /// <param name="key">索引值</param>
        /// <returns>回傳TData類型之資料</returns>
        public TData GetData(string key)
        {
            CasResult<byte[]> result = this.MemClient.GetWithCas<byte[]>(key);
            this.casID = result.Cas;
            if (result.Result == null || result.Result.Length == 0)
            {
                return default(TData);
            }
            else
            {
                return this.ConvertToData(result.Result);
            }
        }

        /// <summary>
        /// 設定無時效性資料至MemCached
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="data">資料內容</param>
        /// <returns>設定成功與否</returns>
        public bool SetData(string key, TData data)
        {
            byte[] arry = this.ConvertToBytes(data);
            return this.MemClient.Cas(Enyim.Caching.Memcached.StoreMode.Set, key, arry, this.casID).Result;
        }

        /// <summary>
        /// 設定有時效性資料至MemCached
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="data">資料內容</param>
        /// <param name="expires">有效時間</param>
        /// <returns>設定成功與否</returns>
        public bool SetData(string key, TData data, System.TimeSpan expires)
        {
            byte[] arry = this.ConvertToBytes(data);
            return this.MemClient.Cas(Enyim.Caching.Memcached.StoreMode.Set, key, arry, expires, this.casID).Result;
        }

        /// <summary>
        /// 設定有時效性資料至MemCached
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="data">資料內容</param>
        /// <param name="expires">有效日期</param>
        /// <returns>設定成功與否</returns>
        public bool SetData(string key, TData data, System.DateTime expires)
        {
            byte[] arry = this.ConvertToBytes(data);
            return this.MemClient.Cas(Enyim.Caching.Memcached.StoreMode.Set, key, arry, expires, this.casID).Result;
        }
        #endregion

        #region Abstract
        /// <summary>
        /// 將Byte[] 轉換成 TData 型別
        /// </summary>
        /// <param name="arry">byte[] 類型之資料</param>
        /// <returns>轉換後之TData 類型資料</returns>
        protected abstract TData ConvertToData(byte[] arry);

        /// <summary>
        /// 將TData 轉換成 byte[]
        /// </summary>
        /// <param name="data">TData 類型之資料</param>
        /// <returns>轉換後之byte[] 類型資料</returns>
        protected abstract byte[] ConvertToBytes(TData data);
        #endregion
    }
}
