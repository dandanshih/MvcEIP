﻿//-----------------------------------------------------------------------
// <copyright file="CachedReader.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace SGT.CachedSQLCommander
{
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;
    using Enyim.Caching;
    using Enyim.Caching.Memcached;

    /// <summary>
    /// 通用 Cache 機制類別，子類別需實作
    /// getData() setData() 對 DB 的操作
    /// </summary>
    public abstract class CachedReader : IDataCache
    {
        /// <summary>
        /// MemCached Client
        /// </summary>
        private MemcachedClient memClient
        {
            get
            {
                return MemCached.Instance;
            }
        }
        
        /// <summary>
        /// 取得資料
        /// <para>先從MemCached取，如果取不到則改向DB資料取</para>
        /// </summary>
        /// <param name="key">索引值</param>
        /// <returns>資料物件</returns>
        public object GetData(string key)
        {
            MemObject memobj = GetCASData(key);
            if (memobj != null)
            {
                return memobj.obj;
            }
            return null;
        }

        public MemObject GetCASData(string key)
        {            
            byte[] data = null;
            MemObject retObj = new MemObject();
            //// 試著從 Memcached 取得資料
            var memData = this.GetCachedData(key);
            data = memData.Result as byte[];
            retObj.cas = memData.Cas;
            if (data == null || data.Length == 0)
            {
                // 無資料，由SQL 取得資料
                data = this.GetRealData(key);
                if (data == null || data.Length == 0)
                {
                    return null;
                }
                else
                {
                    // 回存 Memcached
                    retObj.cas = this.SetCachedData(key, data).Cas;
                }
            }

            if (data != null && data.Length > 0)
            {
                MemoryStream ms = new MemoryStream(data);
                BinaryFormatter bf = new BinaryFormatter();                
                retObj.obj = bf.Deserialize(ms);
                
                return retObj;
            }

            return null;
        }

        /// <summary>
        /// 設定資料
        /// <para>同步向MemCached及DB設定資料</para>
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="obj">資料物件</param>
        public void SetData(string key, object obj)
        {
            // 序列化成 byte []
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, obj);
            byte[] data = ms.ToArray();

            // 存回 Memcached
            this.SetCachedData(key, data);

            // 存回 DB
            this.SetRealData(key, data);
        }
        
        public bool SetCASData(string key, MemObject memobj)
        {
            // 序列化成 byte []
            MemoryStream ms = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ms, memobj.obj);
            byte[] data = ms.ToArray();

            // 存回 Memcached
            if (this.SetCachedData(key, data, memobj.cas).Result == true)
            {
                // 存回 DB
                this.SetRealData(key, data);
                return true;
            }

            return false;            
        }

        /// <summary>
        /// 給繼承者實做取DB資料
        /// </summary>
        /// <param name="key">索引值</param>
        /// <returns>資料物件</returns>
        public abstract byte[] GetRealData(string key);

        /// <summary>
        /// 給繼承者實做設定DB資料
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="data">資料物件</param>
        /// <returns>成功 / 失敗</returns>
        public abstract bool SetRealData(string key, byte[] data);

        /// <summary>
        /// 從 Memcached 取得資料
        /// </summary>
        /// <param name="key">索引值</param>
        /// <returns>資料byte[]</returns>
        protected CasResult<object> GetCachedData(string key)
        {            
            return this.memClient.GetWithCas(key);
        }

        /// <summary>
        /// 存回 Memcached
        /// </summary>
        /// <param name="key">索引值</param>
        /// <param name="arry">資料物件</param>
        /// <returns>成功 / 失敗</returns>
        protected CasResult<bool> SetCachedData(string key, byte[] arry)
        {            
            return this.memClient.Cas(Enyim.Caching.Memcached.StoreMode.Set, key, arry);
        }

        protected CasResult<bool> SetCachedData(string key, byte[] arry, ulong cas)
        {
            return this.memClient.Cas(Enyim.Caching.Memcached.StoreMode.Set, key, arry,cas);            
        }
    }
}
