﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.DynamicPages
{
    public class DynamicPagesAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "DynamicPages";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "DynamicPages_HotActive1",
                "DynamicPages/{area}/HotActive/{action}/{id}",
                new { area = "Web", action = "WinnersBingoPartTwo", controller = "HotActive", id = UrlParameter.Optional }
            );

            context.MapRoute(
                "DynamicPages_default",
                "DynamicPages/{area}/{controller}/{action}/{id}",
                new { area = "Web", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
