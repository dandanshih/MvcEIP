﻿using GameWeb_Models.Models.Bank;
using GameWeb_Models.Models.Bank.Enum;
using GameWeb_Models.Models.Member;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.Payment;
using HOTW_GameWebMVC.Attributes;
using HOTW_GameWebMVC.Models.Bank;
using PaymentGateway.StoreAPI;
using System;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace HOTW_GameWebMVC.Areas.DynamicPages.Controllers
{
	public class BankController : DynamicController
	{
		#region GoPaymentGateway 處理流程
		/// <summary>
		/// 線上購點(PG程序)。
		/// </summary>
		/// <returns>
		/// Code
		///     0: 成功
		///     1: ValueID 或 ProductID 小於等於零
		///     2: Price 或 Points 小於等於零
		///     -1~-5: GoPaymentGateway 錯誤訊息
		/// </returns>
		private PaymentResult GoPG_PointBuyOnline(PointBuyGoPayment data)
		{
			if (data.ValueID <= 0 || data.ProductID <= 0)
			{
				return new PaymentResult() { Code = 1, Message = "請選擇儲值類型" };
			}

			if (data.Price <= 0 || data.Points <= 0)
			{
				return new PaymentResult() { Code = 2, Message = "交易失敗" };
			}

			PaymentInfo info = new PaymentInfo();
			info.ProductGroup = 1;
			info.PaymentValueID = data.ValueID;
			info.ProductType = data.ProductID;
			info.Amount = data.Price;
			info.Point = data.Points + data.GiftPoints;
			info.EcouponCode = data.ECoupon;
			info.IsCheck = true;
			info.OrderFinalUrlQueryString = "1#@$1";

			info.MemberID = int.Parse(Session["MemberID"].ToString());
			info.MemberAccount = Session["MemberAccount"].ToString();
			info.CustInvoiceType = data.InvoiceType;
			info.CustEmail = data.InvoiceEmail;
			info.CustName = data.InvoiceName;
			info.CustZoneID = data.InvoiceZoneID;
			info.CustAddress = data.InvoiceAddress;

			info.Platinum = data.Platinum;

			PaymentUtility pcu = new PaymentUtility();
			return pcu.GoPaymentGateway(info);
		}

		/// <summary>
		/// MyCard InGame 流程。
		/// </summary>
		private PaymentResult GoPG_PointBuySN_MyCard(PointBuyGoPayment data)
		{
			PaymentResult result = new PaymentResult();

			PaymentClientMvc pmc = new PaymentClientMvc
			(
				WebConfig.PaymentGatewayHost,
				WebConfig.PaymentStoreID,
				WebConfig.PaymentEncryptKey
			);

			pmc.RequestType = 109;
			pmc.StoreOrderID = "";
			pmc.RequestType = 109;
			pmc.PGOrderID = Session["PGOrderIDToCard"].ToString();
			pmc.PaymentTypeID = 10702;
			pmc.CustPID = Session["MemberAccount"].ToString();
			pmc.IsInvoiceType = "0";
			pmc.StoreOrderID = Session["SSOrderIDToCard"].ToString();
			pmc.OrderExtension = HttpUtility.UrlEncode(string.Format("MyCardId={0}&amp;MyCardPwd={1}", data.StoreCardSN.Trim(), data.StoreCardPwd.Trim()));
			pmc.BeforePaying += new BeforePayingHandler((s, e2) => { });
			pmc.OrderReportUrl = WebConfig.PaymentOrderReportUrl;
			pmc.OrderFinalUrl = WebConfig.PaymentOrderFinalUrl + "/" + HttpUtility.UrlEncode(HttpUtility.UrlEncode("1#@$2"));
			pmc.OrderRecordedUrl = WebConfig.PaymentOrderRecordedUrl;

			Session.Remove("PGOrderIDToCard");
			Session.Remove("SSOrderIDToCard");

			// 傳送訂單資料給PaymentGateway
			result.View = pmc.SendOrderRequest();

			return result;
		}

		/// <summary>
		/// 序號儲值(PG程序)。
		/// </summary>
		/// <returns>
		/// Code
		///     0: 成功
		///     1: ProductID 小於等於零
		///     2: 儲值序號為空
		///     3: 驗證碼為空
		///     -1~-5: GoPaymentGateway 錯誤訊息
		/// </returns>
		private PaymentResult GoPG_PointBuySN(PointBuyGoPayment data)
		{
			// MyCard 的 InGame 流程
			if (Session["PGOrderIDToCard"] != null && Session["SSOrderIDToCard"] != null && !string.IsNullOrEmpty(data.StoreCardSN) && !string.IsNullOrEmpty(data.StoreCardPwd))
			{
				return GoPG_PointBuySN_MyCard(data);
			}

			if (data.ProductID <= 0)
			{
				return new PaymentResult() { Code = 1, Message = "請選擇儲值類型" };
			}

			// 老子儲值卡、UniCard 需要驗證序號
			if (new int[] { 10, 12 }.Contains(data.ProductID))
			{
				if (string.IsNullOrEmpty(data.StoreCardSN))
				{
					return new PaymentResult() { Code = 2, Message = "請輸入儲值序號" };
				}

				if (string.IsNullOrEmpty(data.StoreCardPwd))
				{
					return new PaymentResult() { Code = 3, Message = "請輸入驗證碼" };
				}
			}

			int memberId = int.Parse(Session["MemberID"].ToString());
			var memberDetail = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = memberId });

			PaymentInfo info = new PaymentInfo();
			info.ProductGroup = 2;
			info.ProductType = data.ProductID;
			info.Amount = 1;
			info.IsStoredValue = 1;
			// 老子儲值卡
			if (data.ProductID == 10)
			{
				info.PaymentGatewayExtension = HttpUtility.UrlEncode(string.Format("CardSN={0}&amp;CardPassword={1}", data.StoreCardSN.TrimEnd(), data.StoreCardPwd.TrimEnd()));
			}
			// UniCard
			if (data.ProductID == 12)
			{
				info.PaymentGatewayExtension = HttpUtility.UrlEncode(string.Format("contentId=08online&amp;cardSN={0}&amp;cardPassword={1}", data.StoreCardSN.TrimEnd(), data.StoreCardPwd.TrimEnd()));
			}
			info.OrderFinalUrlQueryString = "1#@$2";

			info.MemberID = memberDetail.MemberID;
			info.MemberAccount = memberDetail.MemberAccount;
			info.CustInvoiceType = 0;

			info.Platinum = data.Platinum;

			PaymentUtility pcu = new PaymentUtility();
			return pcu.GoPaymentGateway(info);
		}

		/// <summary>
		/// 包月儲值(PG程序)。
		/// </summary>
		/// <returns>
		/// Code
		///     0: 成功
		///     1: ValueID 或 ProductID 小於等於零
		///     2: Price 或 Points 小於等於零
		///     -1~-5: GoPaymentGateway 錯誤訊息
		/// </returns>
		private PaymentResult GoPG_PointBuyMonthly(PointBuyGoPayment data)
		{
			if (data.ValueID <= 0 || data.ProductID <= 0)
			{
				return new PaymentResult() { Code = 1, Message = "請選擇儲值類型" };
			}

			if (data.Price <= 0 || data.Points <= 0)
			{
				return new PaymentResult() { Code = 2, Message = "交易失敗" };
			}

			PaymentInfo info = new PaymentInfo();
			info.ProductGroup = 3;
			info.PaymentValueID = data.ValueID;
			info.ProductType = data.ProductID;
			info.Amount = data.Price;
			info.Point = data.Points + data.GiftPoints;
			info.IsCheck = true;
			info.OrderFinalUrlQueryString = "1#@$3";

			info.MemberID = int.Parse(Session["MemberID"].ToString());
			info.MemberAccount = Session["MemberAccount"].ToString();
			info.CustInvoiceType = data.InvoiceType;
			info.CustEmail = data.InvoiceEmail;
			info.CustName = data.InvoiceName;
			info.CustZoneID = data.InvoiceZoneID;
			info.CustAddress = data.InvoiceAddress;

			info.Platinum = data.Platinum;

			PaymentUtility pcu = new PaymentUtility();
			return pcu.GoPaymentGateway(info);
		}

		/// <summary>
		/// 線上轉點(PG程序)。
		/// </summary>
		/// <returns>
		/// Code
		///     0: 成功 
		///     1: ProductID 小於或等於零 
		///     -1~-5: GoPaymentGateway 錯誤訊息
		/// </returns>
		private PaymentResult GoPG_TransferOnline(PointBuyGoPayment data)
		{
			if (data.ProductID <= 0)
			{
				return new PaymentResult() { Code = 1, Message = "請選擇儲值類型" };
			}

			int memberId = int.Parse(Session["MemberID"].ToString());
			var memberDetail = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = memberId });

			PaymentInfo info = new PaymentInfo();
			info.ProductGroup = 4;
			info.ProductType = data.ProductID;
			info.OrderFinalUrlQueryString = "1#@$4";

			info.MemberID = memberDetail.MemberID;
			info.MemberAccount = memberDetail.MemberAccount;
			info.CustInvoiceType = 0;

			info.Platinum = data.Platinum;

			PaymentUtility pcu = new PaymentUtility();
			return pcu.GoPaymentGateway(info);
		}
		#endregion

		#region GoPaymentGateway 中繼頁
		/// <summary>
		/// Lobby儲值購點的PG中繼頁，避免玩家直接重新整理又再次 CreateOrder。
		/// </summary>
		/// <returns></returns>
		[AcceptVerbs("Post")]
		[CheckLoginState(true)]
		public ActionResult PointBuyRedirect(PointBuyGoPayment data)
		{
			if (Request.Form.Count < 1)
			{
				return new RedirectResult("/Mvc");
			}

			data = new JavaScriptSerializer().Deserialize<PointBuyGoPayment>(Request.Form[0]);
			PaymentResult result;

			int sumMenuId = 0;

			switch (data.ProductGroup)
			{
				case ProductGroupType.PointBuyOnline:
					result = GoPG_PointBuyOnline(data);
					sumMenuId = 1;
					break;
				case ProductGroupType.PointBuySN:
					result = GoPG_PointBuySN(data);
					sumMenuId = 2;
					break;
				case ProductGroupType.PointBuyMonthly:
					result = GoPG_PointBuyMonthly(data);
					sumMenuId = 3;
					break;
				case ProductGroupType.TransferOnline:
					result = GoPG_TransferOnline(data);
					sumMenuId = 4;
					break;
				default:
					return new RedirectResult("/Mvc");
			}

			if (result.Code == 0)
			{
				return result.View;
			}
			else
			{
				return new RedirectResult("PointBuyShow/" + HttpUtility.UrlEncode(string.Format("{0}#@${1}", sumMenuId, result.Code)), true);
			}
		}

		/// <summary>
		/// Web儲值購點的PG中繼頁，避免玩家直接重新整理又再次 CreateOrder。
		/// </summary>
		/// <returns></returns>
		[AcceptVerbs("Post")]
		[CheckLoginState(true)]
		public ActionResult PointBuyWebRedirect(PointBuyGoPayment data)
		{
			if (Request.Form.Count < 1)
			{
				return new RedirectResult("/Mvc");
			}

			data = new JavaScriptSerializer().Deserialize<PointBuyGoPayment>(Request.Form[0]);
			PaymentResult result;

			string redirectUrl = "";

			switch (data.ProductGroup)
			{
				case ProductGroupType.PointBuyOnline:
					result = GoPG_PointBuyOnline(data);
					redirectUrl = "PointBuyOnline";
					break;
				case ProductGroupType.PointBuySN:
					result = GoPG_PointBuySN(data);
					redirectUrl = "PointBuySN";
					break;
				case ProductGroupType.PointBuyMonthly:
					result = GoPG_PointBuyMonthly(data);
					redirectUrl = "PointBuyMonthly";
					break;
				case ProductGroupType.TransferOnline:
					result = GoPG_TransferOnline(data);
					redirectUrl = "TransferOnline";
					break;
				default:
					return new RedirectResult("/Mvc");
			}

			if (result.Code == 0)
			{
				return result.View;
			}
			else
			{
				return new RedirectResult(redirectUrl + "/" + result.Code, true);
			}
		}
		#endregion

		/// <summary>
		/// APP-儲值-老子序號。
		/// </summary>
		[AcceptVerbs("Get")]
		//		[CheckLoginState(true)]
		public ActionResult PayBySNType()
		{
			return View();
		}

		/// <summary>
		/// APP-儲值-MyCard。
		/// </summary>
		[AcceptVerbs("Get")]
		//[CheckLoginState(true)]
		public ActionResult PayByMyCard()
		{
			return View();
		}

		/// <summary>
		/// APP-儲值序號。
		/// </summary>
		[AcceptVerbs("Get")]
		//		[CheckLoginState(true)]
		public ActionResult SNKeyin()
		{
			return View(false);
		}


		/// <summary>
		/// APP-儲值-信用卡發票。
		/// </summary>
		[AcceptVerbs("Get")]
		//		[CheckLoginState(true)]
		public ActionResult CreditCardInvoice()
		{
			return View();
		}

		/// <summary>
		/// APP-序號。
		/// </summary>
		[AcceptVerbs("Get")]
		//[CheckLoginState(true)]
		public ActionResult PointBySN()
		{
			return View();
		}

		/// <summary>
		/// APP-儲值產品包序號。
		/// </summary>
		[AcceptVerbs("Get")]
		//		[CheckLoginState(true)]
		public ActionResult ProductSNKeyin()
		{
			return View();
		}

		/// <summary>
		/// APP-儲值購買方式。
		/// </summary>
		[AcceptVerbs("Get")]
		//		[CheckLoginState(true)]
		public ActionResult CardDesc()
		{
			return View(false);
		}

		/// <summary>
		/// APP-儲值購買方式。
		/// </summary>
		[AcceptVerbs("Get")]
		//		[CheckLoginState(true)]
		public ActionResult PointBuyType()
		{
			return View();
		}

		/// <summary>
		/// 線上購點。
		/// </summary>
		[AcceptVerbs("Get")]
		[CheckLoginState(true)]
		public ActionResult PointBuyOnline()
		{
			return View();
		}

		/// <summary>
		/// 序號儲值。
		/// </summary>
		[AcceptVerbs("Get")]
		//[CheckLoginState(true)]
		public ActionResult PointBuySN()
		{
			return View(false);
		}

		/// <summary>
		/// MyCard 輸入卡號頁面
		/// </summary>
		/// <param name="RequestType">PaymentGateway 執行編號</param>
		/// <returns></returns>
		[AcceptVerbs("Post")]
		public ActionResult MyCardSN(string RequestType)
		{
			PaymentClientMvc pc = new PaymentClientMvc
			(
				WebConfig.PaymentGatewayHost,
				WebConfig.PaymentStoreID,
				WebConfig.PaymentEncryptKey
			);
			try
			{
				PayingEventArgs info = pc.ReceivePassiveOrderResult();
				if (!string.IsNullOrEmpty(info.PGOrderID))
				{
					Session["PGOrderIDToCard"] = info.PGOrderID;
					Session["SSOrderIDToCard"] = info.SSOrderID;
					return View();
				}
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(BankController)).Error("PointBuySN::Post", ex);
			}
			return Redirect("/Mvc");
		}

		/// <summary>
		/// 包月儲值。
		/// </summary>
		[AcceptVerbs("Get")]
		[CheckLoginState(true)]
		public ActionResult PointBuyMonthly()
		{
			return View();
		}

		/// <summary>
		/// 線上轉點。
		/// </summary>
		[AcceptVerbs("Get")]
		[CheckLoginState(true)]
		public ActionResult TransferOnline()
		{
			return View();
		}

		/// <summary>
		/// 大廳線上購點結果顯示頁。
		/// </summary>
		/// <returns></returns>
		[AcceptVerbs("Get")]
		[CheckLoginState(true)]
		public ActionResult PointBuyShow()
		{
			return View();
		}

		/// <summary>
		/// 老幣轉帳。
		/// </summary>
		[AcceptVerbs("Get")]
		[CheckLoginState(true)]
		public ActionResult TransferCenter()
		{
			return View();
		}

		/// <summary>
		/// 轉帳紀錄。
		/// </summary>
		[AcceptVerbs("Get")]
		[CheckLoginState(true)]
		public ActionResult TransferRecord()
		{
			return View();
		}

		/// <summary>
		/// 儲值完成頁。
		/// </summary>
		/// <returns>
		/// ResultType
		///     0: 成功
		///     1: 失敗
		///     2: 成功+包月小瑪莉遊戲
		/// </returns>
		[AcceptVerbs("Post","Get")]
		[CheckLoginState(true)]
		public ActionResult PaymentFinsh()
		{
			PaymentClientMvc payingHandler = new PaymentClientMvc
			(
				WebConfig.PaymentGatewayHost,
				WebConfig.PaymentStoreID,
				WebConfig.PaymentEncryptKey
			);
			try
			{
				var result = BankEntities.GetOrderInfo(new GetOrderInfoInputModel { SSOrderID = payingHandler.OrderFinal().SSOrderID });



				return View(result);

			}
			catch (System.Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(BankController)).Error("執行Action PaymentFinsh 時發生錯誤: " + ex.Message, ex);
				return Redirect("/Mvc");
			}
		}

		[AcceptVerbs("Get")]
		public ActionResult PackageIntro()
		{
			return View();
		}

		// GET: /DynamicPages/Bank/PartialTransferCenter
		public ActionResult PartialTransferCenter()
		{
			return View();
		}

	}
}
