﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.DynamicPages.Controllers
{
	public class NewsController : DynamicController
	{
		// GET: /DynamicPages/News/News
		public ActionResult News()
		{
			return View();
		}

		// GET: /DynamicPages/News/RankVIPGame
		public ActionResult RankVIPGame()
		{
			return View();
		}

		// GET: /DynamicPages/News/NewsDetil
		public ActionResult NewsDetil()
		{
			return View();
		}
	}
}
