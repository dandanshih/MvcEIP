﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.DynamicPages.Controllers
{
    public class HotActiveController : DynamicController
    {
        /// <summary>
        /// 活動賽事。
        /// </summary>
        public ActionResult Active()
        {
            return View();
        }

        /// <summary>
        /// 老子大樂透。
        /// </summary>
        public ActionResult Lottery()
        {
            return View();
        }

        /// <summary>
        /// 尊榮卡別活動。
        /// </summary>
        public ActionResult WinnersCard()
        {
            return View();
        }

        /// <summary>
        /// 合作廠商活動。
        /// </summary>
        public ActionResult WinnersPartner()
        {
            return View();
        }

        /// <summary>
        /// 萬元現金大放送
        /// </summary>
        /// <returns></returns>
        public ActionResult WinnersBandV()
        {
            return View();
        }

        /// <summary>
        /// 填E-mail抽大獎。
        /// </summary>
        public ActionResult WinnersEmail()
        {
            return View();
        }

        public ActionResult WinnersBingoPlanet()
        {
            return View();
        }

        public ActionResult WinnersDoubleSixI()
        {
            return View();
        }

        public ActionResult WinnersDoubleSixII()
        {
            return View();
        }

        #region 活動比賽
        public ActionResult WinnersRefuel()
        {
            return View();
        }

        public ActionResult WinnersMillion()
        {
            return View();
        }

        public ActionResult WinnersSuper8()
        {
            return View();
        }

        public ActionResult WinnersBaccarat()
        {
            return View();
        }

        public ActionResult WinnersRankingCash()
        {
            return View();
        }

        public ActionResult WinnersNightCash()
        {
            return View();
        }

        public ActionResult WinnersGold()
        {
            return View();
        }

        public ActionResult WinnersSpecial7()
        {
            return View();
        }

        public ActionResult WinnersSpecial7List()
        {
            return View();
        }

        public ActionResult WinnersCallFor()
        {
            return View();
        }

        public ActionResult WinnersChargePump()
        {
            return View();
        }

        public ActionResult WinnersTenThirty()
        {
            return View();
        }

        public ActionResult WinnersPushCheese()
        {
            return View();
        }

        public ActionResult WinnersBingo()
        {
            return View();
        }
        #endregion

        public ActionResult WinnersBingoPartTwo()
        {
            return View();
        }
    }
}
