﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.DynamicPages.Controllers
{
    public class NoviceController : DynamicController
    {
        //
        // GET: /DynamicPages/Novice/Platinum

        public ActionResult Platinum()
        {
            return View();
        }

        // GET: /DynamicPages/Novice/VirtualT
        public ActionResult VirtualT()
        {
            return View();
        }

        public ActionResult NoviceInterface()
        {
            return View();
        }

        public ActionResult NovicePoints()
        {
            return View();
        }

        public ActionResult NoviceTalk()
        {
            return View();
        }

        public ActionResult NoviceHead()
        {
            return View();
        }

        public ActionResult NoviceEgg()
        {
            return View();
        }

        public ActionResult NoviceShop()
        {
            return View();
        }

        public ActionResult Revolutions()
        {
            return View();
        }
    }
}
