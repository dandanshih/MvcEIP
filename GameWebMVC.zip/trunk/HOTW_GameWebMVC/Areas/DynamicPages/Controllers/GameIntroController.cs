﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.DynamicPages.Controllers
{
    public class GameIntroController : DynamicController
    {
        public ActionResult GameIntroE()
        {
            return View();
        }

        public ActionResult GameIntroM()
        {
            return View();
        }

        public ActionResult GameIntroR()
        {
            return View();
        }

		public ActionResult virtualT()
		{
			return View();
		}

        public ActionResult Platinum()
        {
            return View();
        }

        public ActionResult God()
        {
            return View();
        }

        public ActionResult JPIntro()
        {
            return View();
        }

        public ActionResult Revolutions()
        {
            return View();
        }

        public ActionResult GameIntroS()
        {
            return View();
        }
    }
}
