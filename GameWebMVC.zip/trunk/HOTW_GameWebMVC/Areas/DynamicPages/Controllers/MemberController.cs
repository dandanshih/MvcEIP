﻿using HOTW_GameWebMVC.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.DynamicPages.Controllers
{
    public class MemberController : DynamicController
    {
        // GET: /DynamicPages/Member/CardDesc
        public ActionResult CardDesc()
        {
            return View();
        }

        // GET: /DynamicPages/Member/CardWelfare
        public ActionResult CardWelfare()
        {
            return View();
        }

        // GET: /DynamicPages/Member/LoginPage
        public ActionResult LoginPage()
        {
            this.ViewData["sss"] = Request.QueryString["code"];

            return View();
        }

        // GET: /DynamicPages/Member/EditMemberData
        public ActionResult EditMemberData()
        {
            return View();
        }

        // GET: /DynamicPages/Member/GameRecord
        public ActionResult GameRecord()
        {
            return View();
        }

        // GET: /DynamicPages/Member/GameReview
        public ActionResult GameReview()
        {
            return View();
        }

        // GET: /DynamicPages/Member/GiftCenter
        [CheckLoginState(true)]
        public ActionResult GiftCenter()
        {
            return View();
        }

        // GET: /DynamicPages/Member/ExchangeNovice
        [CheckLoginState(true)]
        public ActionResult ExchangeNovice()
        {
            return View();
        }

        // GET: /DynamicPages/Member/Passbook
        public ActionResult Passbook()
        {
            return View();
        }

        // GET: /DynamicPages/Member/PassBookBonus
        public ActionResult PassBookBonus()
        {
            return View();
        }

        // GET: /DynamicPages/Member/PersonalGlory
        [CheckLoginState(true)]
        public ActionResult PersonalGlory()
        {
            return View();
        }

        // GET: /DynamicPages/Member/MyFriend
        [CheckLoginState(true)]
        public ActionResult MyFriend()
        {
            return View();
        }

        // GET: /DynamicPages/Member/ShoppingLimit
        public ActionResult ShoppingLimit()
        {
            return View();
        }

        // GET: /DynamicPages/Member/ForgetPassword
        [CheckLoginState]
        public ActionResult ForgetPassword()
        {
            return View();
        }

        // GET: /DynamicPages/Member/AccountSet
        [CheckLoginState(true)]
        public ActionResult AccountSet()
        {
            return View();
        }

        // GET: /DynamicPages/Member/InsertMergerMA
        [CheckLoginState(true)]
        public ActionResult InsertMergerMA()
        {
            return View();
        }

        // GET: /DynamicPages/Member/MemberPasswordModify
        [CheckLoginState(true)]
        public ActionResult MemberPasswordModify()
        {
            return View();
        }

        // GET: /DynamicPages/Member/MemberRegister
        public ActionResult MemberRegister()
        {
            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterAD
        public ActionResult MemberRegisterAD()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterFastOne
        public ActionResult MemberRegisterFastOne()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterFastTwo
        public ActionResult MemberRegisterFastTwo()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterFastThree
        public ActionResult MemberRegisterFastThree()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterFastFour
        public ActionResult MemberRegisterFastFour()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterGoogleFastOne
        public ActionResult MemberRegisterGoogleFastOne()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterGoogleFastTwo
        public ActionResult MemberRegisterGoogleFastTwo()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterGoogleFastThree
        public ActionResult MemberRegisterGoogleFastThree()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterGoogleFastFour
        public ActionResult MemberRegisterGoogleFastFour()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterFastPachiSlot
        public ActionResult MemberRegisterFastPachiSlot()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterFastFive
        public ActionResult MemberRegisterFastFive()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        // GET: /DynamicPages/Member/MemberRegisterGoogleFastFive
        public ActionResult MemberRegisterGoogleFastFive()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }

        public ActionResult MRGoogleWaterMargin()
        {
            if (Convert.ToBoolean(Session["IsLogin"]))
            {
                Response.Redirect("/MVC");
            }
            else if (Session["GuestMemberID"] != null)
            {
                Session.Abandon();
            }

            return View();
        }
    }
}
