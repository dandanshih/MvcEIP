﻿using HOTW_GameWebMVC.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace HOTW_GameWebMVC.Areas.DynamicPages.Controllers
{
    public class CSCenterController : DynamicController
    {
        /// <summary>
        /// 聯絡我們。
        /// </summary>
        public ActionResult Contact()
        {
            return View();
        }

        /// <summary>
        /// 意見回饋。
        /// </summary>
        [CheckLoginState(true)]
        public ActionResult Bug()
        {
            return View();
        }

        /// <summary>
        /// 常見間題。
        /// </summary>
        public ActionResult QA()
        {
            return View();
        }

        /// <summary>
        /// 常見間題明細。
        /// </summary>
        public ActionResult QADetail()
        {
            return View();
        }

        /// <summary>
        /// 使用者規章-遊戲管理規章。
        /// </summary>
        public ActionResult GameRules()
        {
            return View();
        }

        /// <summary>
        /// 使用者規章-會員服務條款。
        /// </summary>
        public ActionResult Service()
        {
            return View();
        }

        /// <summary>
        /// 使用者規章-隱私權條款。
        /// </summary>
        public ActionResult Private()
        {
            return View();
        }
    }
}
