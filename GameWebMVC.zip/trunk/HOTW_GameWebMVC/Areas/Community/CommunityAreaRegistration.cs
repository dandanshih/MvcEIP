﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.Community
{
    public class CommunityAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Community";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Community_default",
                "Community/{platform}/{controller}/{action}",
                new { action = "Index", platform = "Online113" }
            );
        }
    }
}
