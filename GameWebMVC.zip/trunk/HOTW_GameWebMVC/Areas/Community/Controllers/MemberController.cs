﻿using GS.Web.CPA;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.Community.Controllers
{
    public class MemberController : CommunityController
    {
        #region 顯示畫面
        /// <summary>
        /// 新會員註冊升級VIP頁
        /// </summary>
        /// <returns></returns>
        public ActionResult FirstUpgrade()
        {
            DataContext tmpContext = new DataContext(RouteData.Values["platform"].ToString());
            // 沒有Session 代表還沒登113會員，沒有UserID
            if (tmpContext.Session == null)
            {
                // 導回113 登入頁
                return Redirect("");
            }
            if (!tmpContext.Session.IsLogin)
            {
                return Redirect("");
            }
            const long UseFlag = 32768;
            if ((tmpContext.Session.LoginEventFlag & UseFlag) > 0)
            {
                tmpContext.SaveLogic += (session) =>
                {
                    if ((session.LoginEventFlag & UseFlag) > 0)
                    {
                        session.LoginEventFlag = ActivityFlagMgr.ClearFlag(session.MemberID, UseFlag, session.LoginEventFlag);
                    }
                };
                tmpContext.Save();
            }
            return View(tmpContext.Session);
        }

        public ActionResult MobileAuthentication()
        {
            DataContext tmpContext = new DataContext(RouteData.Values["platform"].ToString());
            // 沒有Session 代表還沒登113會員，沒有UserID
            if (tmpContext.Session == null)
            {
                // 導回113 登入頁
                return Redirect("");
            }
            if (!tmpContext.Session.IsLogin)
            {
                return Redirect("");
            }
            return View();
        }

        public ActionResult MobileAuthenticationFrequently()
        {
            DataContext tmpContext = new DataContext(RouteData.Values["platform"].ToString());
            // 沒有Session 代表還沒登113會員，沒有UserID
            if (tmpContext.Session == null)
            {
                // 導回113 登入頁
                return Redirect("");
            }
            if (!tmpContext.Session.IsLogin)
            {
                return Redirect("");
            }
            return View();
        }

        public ActionResult CancelMobileAuthentication()
        {
            DataContext tmpContext = new DataContext(RouteData.Values["platform"].ToString());
            // 沒有Session 代表還沒登113會員，沒有UserID
            if (tmpContext.Session == null)
            {
                // 導回113 登入頁
                return Redirect("");
            }
            if (!tmpContext.Session.IsLogin)
            {
                return Redirect("");
            }
            return View();
        }

        public ActionResult CloseUpgrade()
        {
            return View();
        }
        #endregion

        #region Api項目
        [AcceptVerbs("Post")]
        public JsonResult InputMobile(string mobile, string nickname)
        {
            DataContext context = new DataContext(RouteData.Values["platform"].ToString());
            
            var session = context.Session;
            MemberResultData resultData;
            ResultData repResult = new ResultData();
            #region 驗證
            if (!string.IsNullOrEmpty(mobile) && !Regex.IsMatch(mobile, @"^[09]{2}[0-9]{8}$"))
            {
                repResult.ResultCode = 101;
                repResult.ResultMsg = "手機格式錯誤";
                return Json(repResult);
            }
            #endregion

            if (!session.IsLogin || session.MemberID <= 0)
            {
                repResult.ResultCode = 99;
            }
            else if (new MemberAttribute(session.MemberAttribute).IsHCoin)
            {
                repResult.ResultCode = 98;
                repResult.ResultMsg = "您已是VIP會員";
            }
            else
            {
                nickname = string.IsNullOrEmpty(nickname.Trim()) ? session.NickName : nickname.Trim();
                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = session.MemberID;
                minfo.Mobile = mobile;
                minfo.NickName = nickname;
                resultData = MemberEventUtility.EditData(minfo);

                if (resultData.ResultCode == 10)
                {
                   
                   

                    context.SaveLogic += (sess) =>
                    {
                        if (sess.OtherData == null)
                        {
                            sess.OtherData = new Dictionary<string, object>();
                        }
                        sess.OtherData["WaitMobileAuthMobile"] = mobile;

                        if (sess.NickName != nickname)
                        {
                            // 清除Flag
                            //sess.NickName = nickname;
                            const long NickNameFlag = 4;
                            sess.LoginEventFlag = ActivityFlagMgr.ClearFlag(minfo.MemberID, NickNameFlag, sess.LoginEventFlag);
                        }
                    };

                    context.Save();
                }
                repResult.ResultCode = resultData.ResultCode;
                repResult.ResultMsg = resultData.ResultMsg;
            }

            return Json(repResult);
        }

        [AcceptVerbs("Post")]
        public JsonResult ApiMobileAuthentication(string verificationCode)
        {
            DataContext context = new DataContext(RouteData.Values["platform"].ToString());
            var session = context.Session;

            MemberResultData resultData;
            ResultData repResult = new ResultData();

            #region 驗證
            if (string.IsNullOrEmpty(verificationCode))
            {
                repResult.ResultCode = 101;
                repResult.ResultMsg = "驗證碼不可空白!";
                return Json(repResult);
            }
            #endregion

            if (session.MemberID <= 0 || !session.OtherData.ContainsKey("WaitMobileAuthMobile"))
            {
                repResult.ResultCode = 99;
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = session.MemberID;
                minfo.Mobile = session.OtherData["WaitMobileAuthMobile"].ToString();
                minfo.MobileVaildCode = verificationCode;
                resultData = MemberEventUtility.MobileVaild(minfo);

                repResult.ResultCode = resultData.ResultCode;
                repResult.ResultMsg = resultData.ResultMsg;

                if (repResult.ResultCode == 0)
                {
                    try
                    {
                        context.SaveLogic += (sess) =>
                        {
                            sess.OtherData.Remove("WaitMobileAuthMobile");
                        };
                        context.Save();

                        minfo = new MemberInfo();
                        minfo.MemberAccount = session.MemberAccount;
                        minfo.MemberPassword = session.MemberPassword;
                        minfo.Mobile4Num = " ";
                        minfo.Platform = this.Platform;
                        minfo.SourceName = this.Platform;
                        minfo.ClientIP = Request.UserHostAddress;
                        minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Community;
                        minfo.SessionID = Session.SessionID;
                        resultData = MemberEventUtility.LogoutWithLogin(minfo);
                    }
                    catch (Exception ex)
                    {
                        log4net.LogManager.GetLogger(typeof(MemberController)).Error("LogoutWithLoginFail", ex);
                        resultData = new MemberResultData();
                        resultData.ResultCode = 99;
                    }
                }
                // 若有 Initial 過則儲存 SessionID
                //CPAHandler handler = new CPAHandler(WebConfig.CPAConnectionString);
                //handler.Add(CPAType.Other, EventType.Register);
                //handler.SaveData();
                //handler.Clear();
            }

            return Json(repResult);
        }

        [AcceptVerbs("Post")]
        public JsonResult ReSendVerificationCode()
        {
            DataContext context = new DataContext(RouteData.Values["platform"].ToString());
            var session = context.Session;

            MemberResultData resultData;
            ResultData repResult = new ResultData();

            if (session.MemberID <= 0 || !session.OtherData.ContainsKey("WaitMobileAuthMobile"))
            {
                repResult.ResultCode = 99;
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = session.MemberID;
                minfo.MemberAccount = session.MemberAccount;
                minfo.Mobile = session.OtherData["WaitMobileAuthMobile"].ToString();
                resultData = MemberEventUtility.ReSendSMS(minfo);

                if (resultData.ResultCode == 0)
                {
#if(!Online)
                    string SqlCmd = "SELECT VerificationCode FROM A_Member WHERE MemberAccount = @MemberAccount";
                    System.Data.SqlClient.SqlParameter param = new System.Data.SqlClient.SqlParameter("@MemberAccount", minfo.MemberAccount);
                    repResult.Data = GS.Utilities.SqlHelper.ExecuteScalar
                    (
                        WebConfig.ConnectionString,
                        System.Data.CommandType.Text,
                        SqlCmd,
                        param
                    ).ToString();
#endif
                }
                repResult.ResultCode = resultData.ResultCode;
                repResult.ResultMsg = resultData.ResultMsg;
            }

            return Json(repResult);
        }

        [AcceptVerbs("Post")]
        public JsonResult ApiCancelMobileAuthentication()
        {
            DataContext context = new DataContext(RouteData.Values["platform"].ToString());
            var session = context.Session;

            MemberResultData resultData;
            ResultData repResult = new ResultData();

            if (session.MemberID <= 0 || !session.OtherData.ContainsKey("WaitMobileAuthMobile"))
            {
                repResult.ResultCode = 99;
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = session.MemberID;
                minfo.Mobile = session.OtherData["WaitMobileAuthMobile"].ToString(); ;

                resultData = MemberEventUtility.CancelMobileVaild(minfo);

                repResult.ResultCode = resultData.ResultCode;
                repResult.ResultMsg = resultData.ResultMsg;

                if (repResult.ResultCode == 0)
                {
                    context.SaveLogic += (sess) =>
                    {
                        sess.OtherData.Remove("WaitMobileAuthMobile");
                    };
                    context.Save();
                }
            }

            return Json(repResult);
        }

        struct ResultData
        {
            public int ResultCode { get; set; }

            public string ResultMsg { get; set; }

            public string Data { get; set; }
        }
        #endregion
    }
}
