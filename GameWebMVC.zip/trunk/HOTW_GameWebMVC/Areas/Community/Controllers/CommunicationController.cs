﻿using HOTW_GameWebMVC.AppLibs;
using System;
using System.Web.Mvc;
using System.Web.Security;
using GameWeb_Models.Models.Member;
using HOTW_GameWebMVC.AppLibs.Payment;
using System.Web;
using PaymentGateway.StoreAPI;


namespace HOTW_GameWebMVC.Areas.Community.Controllers
{
    public class CommunicationController : CommunityController
    {
        private const string AES_Key = "xrcjJY0WPjPh459i";

        private const string AES_IV = "jbPg9piZNqNs77ER";

        private JsonResult GoPayment(string bankOrderID, string userID, decimal amount, int groupID, int typeID, int valueID, string paymentExtension)
        {
            var error = new
            {
                code = "205"
            };
            #region 新增訂單
            PaymentInfo info = new PaymentInfo();
            info.Amount = amount;
            info.ProductGroup = groupID;
            info.ProductType = typeID;
            info.IsAsync = true;
            info.MemberAccount = userID + "@Online113";
            info.RequestType = 101;
            info.BankOrderID = bankOrderID;
            info.PaymentValueID = valueID;
            info.PaymentGatewayExtension = HttpUtility.HtmlEncode(paymentExtension);


            PaymentUtility pcu = new PaymentUtility();
            PaymentResult payResult = pcu.GoPaymentGateway(info);
            if (payResult.Code != 0)
            {
                switch (payResult.Code)
                {
                    case -1:
                        error = new { code = "201" };
                        log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("會員不存在!!");
                        return Json(error, JsonRequestBehavior.AllowGet);
                    case -2:
                        error = new { code = "202" };
                        log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("站內訂單建立失敗!!");
                        return Json(error, JsonRequestBehavior.AllowGet);
                    case -5:
                        error = new { code = "203" };
                        log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("關機維護中!!");
                        return Json(error, JsonRequestBehavior.AllowGet);
                    default:
                        log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("其他錯誤: ResultCode=" + payResult.Code);
                        return Json(error, JsonRequestBehavior.AllowGet);
                }
            }
            if (payResult.View == null)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("沒收到View 值，表示PaymentGateway失敗!");
                return Json(error, JsonRequestBehavior.AllowGet);
            }
            #endregion
            #region 更新訂單且開分
            PaymentClientMvc pmc = new PaymentClientMvc
            (
                WebConfig.PaymentGatewayHost
                , WebConfig.PaymentStoreID
                , WebConfig.PaymentEncryptKey
            );
            ResponseInfo rinfo = new ResponseInfo();
            rinfo.BankOrderID = bankOrderID;
            // 因為會進這支都是成功單，所以直接下0
            rinfo.ResultCode = 0;
            rinfo.CommitPaymentTypeID = 10804;
            rinfo.CommitAmount = amount;
            PayingEventArgs args = pmc.OrderProcess(rinfo);
            if (args.ResultCode == 0)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("交易成功!!");
                return Json(new
                {
                    code = "100"
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).InfoFormat("交易失敗!! ResultCode: {0}, ResultMsg: {1}", args.ResultCode, args.ResultText);
                return Json(error, JsonRequestBehavior.AllowGet);
            }
            #endregion
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (WebConfig.Online113_AllowIPs.IsAllowIP())
            {
                base.OnActionExecuting(filterContext);
            }
            else
            {
                filterContext.Result = Content("");
                base.OnActionExecuting(filterContext);
            }
        }

        #region 113 介接Action
        [AcceptVerbs("Post", "Get")]
        public JsonResult Login(string plat, string game, string server, string user, string time, string sign, string ip)
        {
            string privKey = WebConfig.Online113_Key;

            var error = new
            {
                code = "200",
                url = ""
            };
            // 如果為維護狀態，直接回覆狀態
			if (MvcApplication.IsMaintain && !WebConfig.Online113_User_AllowIPs.IsAllowIP(ip))
            {
                return Json(error, JsonRequestBehavior.AllowGet);
            }

            long OurTimeStamp = Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds);
            long CmuTimeStamp = Convert.ToInt64(time);
            long DiffTimeStamp = Math.Abs(OurTimeStamp - CmuTimeStamp);
            // 如果時間戳記超過5分鐘，也回傳失敗
            if (DiffTimeStamp > 300)
            {
                return Json(error, JsonRequestBehavior.AllowGet);
            }

            string strPlain = string.Format
            (
                "{0}{1}{2}{3}{4}{5}",
                plat,
                game,
                server,
                user,
                time,
                privKey
            );
            string hash = FormsAuthentication.HashPasswordForStoringInConfigFile(strPlain, "MD5").ToLower();
            if (sign != hash)
            {
                return Json(error, JsonRequestBehavior.AllowGet);
            }
            try
            {
                string uid = CommonUtility.AESEncrypt(user, AES_Key, AES_IV);
                string t = CommonUtility.AESEncrypt(OurTimeStamp.ToString(), AES_Key, AES_IV);
                return Json(new
                {
                    code = "100",
                    url = string.Format
                    (
                        "http://{0}/Mvc/Community/Online113/Game/Index?uid={1}&t={2}&gameName={3}",
                        WebConfig.Domain,
                        uid,
                        t,
                        game
                    )
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Error("Login()，AES加密失敗!", ex);
                return Json(error, JsonRequestBehavior.AllowGet);
            }
        }

        [AcceptVerbs("Post", "Get")]
		public JsonResult GetUserData(string plat, string game, string server, string user, string sign, string ip)
        {
            string privKey = WebConfig.Online113_Key;

            var error = new
            {
                code = 203,
                role = "",
                level = ""
            };

            string strPlain = string.Format
            (
                "{0}{1}{2}{3}{4}",
                plat,
                game,
                server,
                user,
                privKey
            );
            string hash = FormsAuthentication.HashPasswordForStoringInConfigFile(strPlain, "MD5").ToLower();
            if (sign != hash)
            {
                return Json(error, JsonRequestBehavior.AllowGet);
            }

            try
            {
                var dbResult = MemberEntities.MiniMemberData(new MiniMemberDataInputModel { MemberAccount = user + "@Online113" });
                if (dbResult == null)
                {
                    return Json(new
                    {
                        code = 201,
                        role = "",
                        level = ""
                    }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var result = new
                    {
                        code = 100,
                        role = dbResult.NickName,
                        level = dbResult.Level
                    };
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Error("GetUserData() 發生錯誤! UserID: " + user, ex);
                return Json(error, JsonRequestBehavior.AllowGet);
            }
        }

        [AcceptVerbs("Post", "Get")]
		public JsonResult Payment(string plat, string game, string server, string user, string tradeno, decimal gold, string time, string sign, string ip)
        {
            string privKey = WebConfig.Online113_Key;
            string inputInfo = string.Format
            (
                "plat={0}&game={1}&server={2}&user={3}&tradeno={4}&gold={5}&time={6}&sign={7}",
                plat,
                game,
                server,
                user,
                tradeno,
                gold,
                time,
                privKey
            );
            log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("收到113金流參數: " + inputInfo);

            var error = new
            {
                code = "205"
            };
            // 如果為維護狀態，直接回覆狀態
			if (MvcApplication.IsMaintain && !WebConfig.Online113_User_AllowIPs.IsAllowIP(ip))
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("回傳維護中狀態!!");
				error = new
				{
					code = "203"
				};
                return Json(error, JsonRequestBehavior.AllowGet);
            }

            #region 驗證傳入之參數
			//long OurTimeStamp = Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds);
			//long CmuTimeStamp = Convert.ToInt64(time);
			//long DiffTimeStamp = Math.Abs(OurTimeStamp - CmuTimeStamp);
            // 如果時間戳記超過5分鐘，也回傳失敗
			//if (DiffTimeStamp > 300)
			//{
			//	log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("時間戳記超過5分鐘!!");
			//	return Json(error, JsonRequestBehavior.AllowGet);
			//}

            string strPlain = string.Format
            (
                "{0}{1}{2}{3}{4}{5}{6}{7}",
                plat,
                game,
                server,
                user,
                tradeno,
                gold,
                time,
                privKey
            );
            string hash = FormsAuthentication.HashPasswordForStoringInConfigFile(strPlain, "MD5").ToLower();
            if (sign != hash)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("加密驗證失敗!!");
                return Json(error, JsonRequestBehavior.AllowGet);
            }
            #endregion

            try
            {
                return GoPayment(tradeno, user, gold, 7, 19, 0, inputInfo);
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Error("儲值發生錯誤!", ex);
                return Json(error, JsonRequestBehavior.AllowGet);
            }
        }

		public JsonResult PaymentMonthly(string plat, string game, string server, string user, string tradeno, decimal gold, int valueid, string time, string sign, string ip)
        {
            string privKey = WebConfig.Online113_Key;
            string inputInfo = string.Format
            (
                "plat={0}&game={1}&server={2}&user={3}&tradeno={4}&gold={5}&time={6}&sign={7}&valueid={8}",
                plat,
                game,
                server,
                user,
                tradeno,
                gold,
                time,
				sign,
                valueid
            );
            log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("收到113 包月金流參數: " + inputInfo);

            var error = new
            {
                code = "205"
            };
            // 如果為維護狀態，直接回覆狀態
			if (MvcApplication.IsMaintain && !WebConfig.Online113_User_AllowIPs.IsAllowIP(ip))
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("回傳維護中狀態!!");
				error = new
				{
					code = "203"
				};
                return Json(error, JsonRequestBehavior.AllowGet);
            }

            #region 驗證傳入之參數
			//long OurTimeStamp = Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds);
			//long CmuTimeStamp = Convert.ToInt64(time);
			//long DiffTimeStamp = Math.Abs(OurTimeStamp - CmuTimeStamp);
			//// 如果時間戳記超過5分鐘，也回傳失敗
			//if (DiffTimeStamp > 300)
			//{
			//	log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("時間戳記超過5分鐘!!");
			//	return Json(error, JsonRequestBehavior.AllowGet);
			//}

            string strPlain = string.Format
            (
                "{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                plat,
                game,
                server,
                user,
                tradeno,
                gold,
                valueid,
                time,
                privKey
            );
            string hash = FormsAuthentication.HashPasswordForStoringInConfigFile(strPlain, "MD5").ToLower();
            if (sign != hash)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Info("加密驗證失敗!!");
                return Json(error, JsonRequestBehavior.AllowGet);
            }
            #endregion

            try
            {
                return GoPayment(tradeno, user, gold, 3, 20, valueid, inputInfo);
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(CommunicationController)).Error("儲值發生錯誤!", ex);
                return Json(error, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion
    }
}
