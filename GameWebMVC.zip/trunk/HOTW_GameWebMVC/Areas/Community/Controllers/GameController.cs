﻿using GameWeb_Models.Models.Member;
using GameWeb_Models.Models.Sessions;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.Community.Controllers
{
    public class GameController : CommunityController
    {
        private const string AES_Key = "xrcjJY0WPjPh459i";

        private const string AES_IV = "jbPg9piZNqNs77ER";

        public ActionResult Index(string uid, string t, string gameName)
        {
            if (!string.IsNullOrEmpty(Request.Form["StateType"]))
            {
                return Index(Request.Form["StateType"]);
            }
            Response.AddHeader("p3p", "CP=\"IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT\"");
            Session["IsOnline113"] = true;
            Response.Cookies["SGTSessionID"].Value = Session.SessionID;

			if (MvcApplication.IsMaintain && !WebConfig.Online113_User_AllowIPs.IsAllowIP())
            {
                // 前往維護頁
                // TODO: 給維護頁網址
                return Redirect("ErrorPage?msg=99");
            }
            SGT.Web.Session.HOTW.SessionData sessionInfo = null;
            try
            {
                //string userID = "123";
                string time = CommonUtility.AESDecrypt(t, AES_Key, AES_IV);
                string userID = CommonUtility.AESDecrypt(uid, AES_Key, AES_IV);
                DataContext context = new DataContext("Online113");
                string memberAccount = string.Format("{0}@{1}", userID, this.Platform);
                bool needLogin = true;
                if (context.Session != null && context.Session.MemberAccount == memberAccount)
                {
                    int keepCnt = MemberEntities.KeepOnline(new KeepOnlineInputModel { MemberID = context.Session.MemberID, OnlineID = (int)context.Session.OnlineID, SessionID = "" });
                    if (keepCnt != 1)
                    {
                        needLogin = true;
                    }
                    else
                    {
                        needLogin = false;
                        sessionInfo = context.Session;
                    }
                }
                if(needLogin)
                {
                    if (context.Session != null)
                    {
                        string sid = string.Format
                        (
                            "{0}_{1}_{2}_{3}",
                            this.Platform,
                            Session.SessionID,
                            "MemberInfo",
                            WebConfig.Platform
                        );
                        GS.ServerCommander.FSCommander.FS_AS_USER_LOGOUT(context.Session.MemberID.ToString(), context.Session.OnlineID.ToString());
                    }
                    long OurTimeStamp = Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds);
                    long CmuTimeStamp = Convert.ToInt64(time);
                    long DiffTimeStamp = Math.Abs(OurTimeStamp - CmuTimeStamp);
#if(!Debug)
                    // 如果時間戳記超過5分鐘，也回傳失敗
                    if (DiffTimeStamp > 300)
                    {
                        // TODO: 給網址
                        return Redirect("ErrorPage");
                    }
#endif         
                    MemberInfo minfo = new MemberInfo()
                    {
                        MemberAccount = memberAccount,
                        SourceName = this.Platform,
                        Platform = this.Platform,
                        ClientIP = Request.UserHostAddress,
                        FSLoginType = LoginType.Community,
                        SessionID = Session.SessionID,
						IsAmortization = true
                    };

                    MemberResultData rData = MemberEventUtility.CWLogin(minfo);
                    if (rData.ResultCode == 1 || rData.ResultCode == 19 || rData.ResultCode == 10)
                    {
                        if (rData.ResultCode == 19)
                        {
                            ViewBag.ConfirmRelogin = true;
                        }
                        sessionInfo = new DataContext("Online113").Session;
                    }
                    else
                    {
                        return Redirect("ErrorPage?msg=" + rData.ResultCode);
                    }
                }
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(GameController)).Error("登入" + this.Platform + " 會員發生錯誤!" + ex.Message, ex);
                return Redirect("ErrorPage?msg=99");
            }


            return View(sessionInfo);
        }

        [HttpPost]
        public ActionResult Index(string StateType)
        {
            Response.AddHeader("p3p", "CP=\"IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT\"");
            Response.Cookies["SGTSessionID"].Value = Session.SessionID;

            if (MvcApplication.IsMaintain && !WebConfig.Online113_User_AllowIPs.IsAllowIP())
            {
                // 前往維護頁
                // TODO: 給維護頁網址
                return Redirect("ErrorPage?msg=99");
            }
            SGT.Web.Session.HOTW.SessionData sessionInfo = null;
            try
            {
                DataContext context = new DataContext("Online113");
                sessionInfo = context.Session;
                if (context.Session != null && !context.Session.IsLogin)
                {
                    switch (StateType)
                    {
                        case "ReLogin":
                            MemberInfo minfo = new MemberInfo();
			                minfo.MemberID = context.Session.MemberID;
                            minfo.MemberAccount = context.Session.MemberAccount;
                            minfo.SourceName = "Online113";
                            minfo.Platform = "Online113";
			                minfo.ClientIP = Request.UserHostAddress;
			                minfo.FSLoginType = LoginType.ReLogin;

			                MemberResultData mrd = MemberEventUtility.CWLogin(minfo);

                            if (mrd.ResultCode == 1 || mrd.ResultCode == 10)
                            {
                                sessionInfo = new DataContext("Online113").Session;
                            }
                            else
                            {
                                return Redirect("ErrorPage?msg=" + mrd.ResultCode);
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(GameController)).Error("登入" + this.Platform + " 會員發生錯誤!" + ex.Message, ex);
                return Redirect("ErrorPage?msg=99");
            }


            return View(sessionInfo);
        }

        public ActionResult ErrorPage(string msg)
        {
            return View();
        }
    }
}
