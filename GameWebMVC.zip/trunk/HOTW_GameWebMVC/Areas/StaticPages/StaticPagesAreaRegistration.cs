﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.StaticPages
{
	public class StaticPagesAreaRegistration : AreaRegistration
	{
		public override string AreaName
		{
			get
			{
				return "StaticPages";
			}
		}

		public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "StaticPages_default",
                "StaticPages/{area}/{controller}/{id}/{id2}",
                new { area = "Web", action = "Index", id = UrlParameter.Optional, id2 = UrlParameter.Optional }
            );
		}
	}
}
