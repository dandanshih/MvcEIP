﻿using HOTW_GameWebMVC.AppLibs;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Areas.StaticPages.Controllers
{
    public class ActionPageController : StaticController
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
