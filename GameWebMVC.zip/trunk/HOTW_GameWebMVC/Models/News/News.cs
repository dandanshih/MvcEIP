﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HOTW_GameWebMVC.Models.News
{
	public class News
	{
		public string ImageUrl { get; set; }
		public string ModifiedDate { get; set; }
		public string NewsTitle { get; set; }
		public string NewsDesc { get; set; }
		public int NewsID { get; set; }
	}
}