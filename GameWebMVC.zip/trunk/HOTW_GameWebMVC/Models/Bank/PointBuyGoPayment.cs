﻿using GameWeb_Models.Models.Bank.Enum;

namespace HOTW_GameWebMVC.Models.Bank
{
    public class PointBuyGoPayment
    {
        /// <summary>
        /// 交易金額。
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// 交易點數。
        /// </summary>
        public decimal Points { get; set; }

        /// <summary>
        /// 每日補點。
        /// </summary>
        public decimal EveryDayPoints { get; set; }

        /// <summary>
        /// 贈點。
        /// </summary>
        public decimal GiftPoints { get; set; }

        /// <summary>
        /// 儲值類型。
        /// </summary>
        public ProductGroupType ProductGroup { get; set; }

        /// <summary>
        /// 儲值金額編號。
        /// </summary>
        public int ValueID { get; set; }

        /// <summary>
        /// 付款方式編號。
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// ECoupon序號。
        /// </summary>
        public string ECoupon { get; set; }

        /// <summary>
        /// 發票取得方式 (0:捐給創世基金會 1:索取電子發票 2:索取紙本發票)。
        /// </summary>
        public int InvoiceType { get; set; }

        /// <summary>
        /// 發票寄送Email。
        /// </summary>
        public string InvoiceEmail { get; set; }

        /// <summary>
        /// 發票寄送人。
        /// </summary>
        public string InvoiceName { get; set; }

        /// <summary>
        /// 發票寄送縣市編號。
        /// </summary>
        public int InvoiceCityID { get; set; }

        /// <summary>
        /// 發票寄送區域編號。
        /// </summary>
        public string InvoiceZoneID { get; set; }

        /// <summary>
        /// 發票寄送地址。
        /// </summary>
        public string InvoiceAddress { get; set; }

        /// <summary>
        /// 儲值卡序號。
        /// </summary>
        public string StoreCardSN { get; set; }

        /// <summary>
        /// 儲值卡驗證碼。
        /// </summary>
        public string StoreCardPwd { get; set; }

        /// <summary>
        /// 來源平台。
        /// </summary>
        public int Platinum { get; set; }
    }
}