﻿using GameWeb_Models.Models.Bank.Enum;

namespace HOTW_GameWebMVC.Models.Bank
{
    /// <summary>
    /// 會員儲值記錄結構。
    /// </summary>
    public class PayRecord
    {
        /// <summary>
        /// 儲值類型。
        /// </summary>
        public ProductGroupType ProductGroup { get; set; }

        /// <summary>
        /// 儲值金額編號。
        /// </summary>
        public int ValueID { get; set; }

        /// <summary>
        /// 付款方是編號。
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// 發票取得方式 (0:捐給創世基金會 1:索取電子發票 2:索取紙本發票)。
        /// </summary>
        public int InvoiceType { get; set; }

        /// <summary>
        /// 發票寄送Email。
        /// </summary>
        public string InvoiceEmail { get; set; }

        /// <summary>
        /// 發票寄送人。
        /// </summary>
        public string InvoiceName { get; set; }

        /// <summary>
        /// 發票寄送縣市編號。
        /// </summary>
        public int InvoiceCityID { get; set; }

        /// <summary>
        /// 發票寄送區域編號。
        /// </summary>
        public string InvoiceZoneID { get; set; }

        /// <summary>
        /// 發票寄送地址。
        /// </summary>
        public string InvoiceAddress { get; set; }
    }
}
