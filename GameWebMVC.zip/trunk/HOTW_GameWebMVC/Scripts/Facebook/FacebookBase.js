﻿/// <reference path="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js" />

// 初始化 Facebook
// 引用時，需在HTML端加入<div id="fb-root"></div>，及宣告JavaScript變數: FBAppID
// 如需登入，請宣告 FBScope
$(function () {
	window.fbAsyncInit = function () {	//初始化登入狀態，使用JavaScript SDK
		//輸入應用程式ID
		FB.init({
		    appId: SGT.WebSiteInfo.FBAppID,
			status: true,
			cookie: true,
			xfbml: true,
			oauth: true,
			//frictionlessRequests: true,
			hideFlashCallback: onFlashHide
		});
		FB.Event.subscribe('auth.statusChange', function (response) {
			FacebookNowStatus = response.status;
		});
	};

	(function(d){
		var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
		if (d.getElementById(id)) {return;}
		js = d.createElement('script'); js.id = id; js.async = true;
		js.src = "//connect.facebook.net/zh_TW/all.js";
		ref.parentNode.insertBefore(js, ref);
	}(document));
});

var FacebookNowStatus = '';
function onFlashHide(params) {
	if (params.state == 'opened') {
		displayFlashScreenshot();
		// FB.Canvas.hideFlashElement(params.elem);		
	} else {
		// FB.Canvas.showFlashElement(params.elem);
		hideFlashScreenshot();
	}
}


function displayFlashScreenshot() {	
	var screenshotData = swfobject.getObjectById('WebLoad').callWebLoad("GetLoadBG", "");		
	$('#screenshotObject').attr("src", 'data:image/jpeg;base64,' + screenshotData);		
	$('#divBody').height($('#WebLoad').height());
	$('#flashContent').css("top", "-10000px");
	$('#imageContent').css("top", "");
}

function hideFlashScreenshot() {	
	$('#flashContent').css("top", "");
	$('#imageContent').css("top", "-10000px");
}

// Constructor
var Facebook = function () {
	var self = this;
	if (FacebookNowStatus === 'connected') {
		self.IsLogin = true;
	} else {
		self.IsLogin = false;
	}
}

// Properties
Facebook.prototype = {
	IsLogin: false,
	Platform: 'Web',
	UserInfo: {},
	Callback: function () { }
};

// Facebook 登入
Facebook.prototype.Login = function (config) {
	var self = this;
	var DefaultConfig = {
		// 呼叫Facebook登入前執行之Function
		Init: function () { },
		// 登入成功後執行之Function
		LoginOK: function () { },
		// 登入失敗後執行之Function
		LoginFail: function () { }
	};
	$.extend(DefaultConfig, config);

	DefaultConfig.Init();

	FB.login(function (response) {
		if (response.authResponse) {
			self.IsLogin = true;
			DefaultConfig.LoginOK();
		} else {
			self.IsLogin = false;
			DefaultConfig.LoginFail();
		}
	}, { scope: SGT.WebSiteInfo.FBAppScope });
}

// 取得Facebook會員資料
Facebook.prototype.GetUserInfo = function (config) {
	var self = this;

	var DefaultConfig = {
		// 呼叫Facebook取會員資訊API前執行之Function
		Init: function () { },
		// 取得會員資訊後執行之Function
		CallBack: function (UserInfo) { },
		// 登入失敗後執行之Function
		EventFail: function () { }
	};
	$.extend(DefaultConfig, config);

	// 判斷是否登入Facebook
	if (!this.IsLogin) {
		this.Login({
			// 登入成功後回呼
			LoginOK: function () { self.GetUserInfo(config); },
			LoginFail: function () { DefaultConfig.EventFail(); }
		});
		return;
	}

	DefaultConfig.Init();

	FB.api(
	{
		method: 'fql.query',
		query: 'SELECT uid, name, pic_square, email, sex, birthday_date FROM user WHERE uid = me()'
	},
	function (response) {
		$.extend(self.UserInfo, response[0]);
		DefaultConfig.CallBack(self.UserInfo);
	});
}

// Facebook 發佈
Facebook.prototype.Feed = function (config) {
	var self = this;
	// 判斷是否登入Facebook
	if (!this.IsLogin) {
		this.Login({
			LoginOK: function () { self.Feed(config); }
		});
		return;
	}

	var DefaultConfig = {
		method: 'feed',
		display: this.Platform == "FB" ? "iframe" : 'popup',
		message: '',
		user_prompt_message: '寫些東西分享給朋友',
		picture: 'http://' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/Html/UploadFiles/FBFeed/08ICon.gif',
		name: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT.WebSiteInfo.Urls.MainUrl,
		link: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT.WebSiteInfo.Urls.MainUrl,
		caption: (this.Platform == "FB") ? '老子有錢臉書遊戲' : '老子有錢 Online',
		description: '',
		actions: '',
		target_id: ''
	};
	$.extend(DefaultConfig, config);

	FB.ui(
		DefaultConfig,
		function (response) {						
			self.Callback();
		}
	);
}

// Facebook 不跳框直接發佈
Facebook.prototype.Publish = function (config) {
	var self = this;
	// 判斷是否登入Facebook
	if (!this.IsLogin) {
		this.Login({
			LoginOK: function () { self.Publish(config); }
		});
		return;
	}

	var DefaultConfig = {
		message: '',
		picture: 'http://' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/Html/UploadFiles/FBFeed/08ICon.gif',
		name: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT.WebSiteInfo.Urls.MainUrl,
		link: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT.WebSiteInfo.Urls.MainUrl,
		caption: ' ',
		description: '',
		actions: ''
	};
	$.extend(DefaultConfig, config);
	
	FB.api(
		'/feed',
		'post',
		DefaultConfig,
		function (response) {
			if (!response || response.error) {
				// alert('發佈失敗！');
			}
			else {
				// alert('發佈成功！');
			}
		}
	);

}

// Facebook 邀請好友
Facebook.prototype.Invite = function (config) {
	var self = this;
	// 判斷是否登入Facebook
	if (!this.IsLogin) {
		this.Login({
			LoginOK: function () { self.Invite(config); }
		});
		return;
	}

	var DefaultConfig = {
		method: 'apprequests',
		title: '老子有錢 Online',
		message: '趕快加入老子有錢拿好康',
		data: 'Invite'
	};
	$.extend(DefaultConfig, config);
	FB.ui(
		DefaultConfig,
		function (response) {
			self.Callback();
		}
	);
}

// Facebook 金流
Facebook.prototype.Purchase = function (config, callback) {

	var self = this;
	// 判斷是否登入Facebook
	if (!this.IsLogin) {
		this.Login({
			LoginOK: function () { self.Purchase(config, callback); }
		});
		return;
	}

	var DefaultConfig = {
		method: 'pay',
		order_info: {
			item_id: 'OrderID',
			title: 'ProductTitle',
			description: 'Description',
			price: 0,
			image_url: 'ImageUrl',
			product_url: 'ProductUrl'
		},
		purchase_type: 'item',
		dev_purchase_params: { oscif: true }
	};

	$.extend(DefaultConfig, config);

	FB.ui(DefaultConfig, callback);
}