﻿/// <reference path="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js" />
/// <reference path="Facebook/FacebookBase.js" />
var FeedMsg = {
	// 中獎發佈訊息
	Winning: {
		// 電子
		// 5PK
		100100: "恭喜!! {0}玩家 玩老子有錢 5PK，中正同花大順! 水喔!! ",
		100101: "恭喜!! {0}玩家 玩老子有錢 5PK，中五梅! 水喔!! ",
		100102: "恭喜!! {0}玩家 玩老子有錢 5PK，中同花順! 水喔!! ",
		100103: "恭喜!! {0}玩家 玩老子有錢 5PK，中鐵支! 水喔!! ",
		// 海盜王
		100200: "恭喜!! {0}玩家 玩老子有錢 海盜王，中船長 5連線! 水喔!! ",
		100201: "恭喜!! {0}玩家 玩老子有錢 海盜王，中廚師 5連線! 水喔!! ",
		100202: "恭喜!! {0}玩家 玩老子有錢 海盜王，中小女孩 5連線! 水喔!! ",
		100203: "恭喜!! {0}玩家 玩老子有錢 海盜王，中海盜王彩金! 恭喜!! ",
		// 水果吧
		100300: "恭喜!! {0}玩家 玩老子有錢 水果吧，中全盤彩金! 水喔!!",
		100301: "恭喜!! {0}玩家 玩老子有錢 水果吧，中藍七 3連線! 水喔!!",
		100302: "恭喜!! {0}玩家 玩老子有錢 水果吧，中紅七 3連線! 水喔!!",
		100303: "恭喜!! {0}玩家 玩老子有錢 水果吧，中藍BAR 3連線! 水喔!!",
		100304: "恭喜!! {0}玩家 玩老子有錢 水果吧，中綠BAR 3連線! 水喔!!",
		100305: "恭喜!! {0}玩家 玩老子有錢 水果吧，中連線彩金! 恭喜!!",
		100353: "恭喜!! {0}玩家 玩老子有錢 水果吧，中單一水果全盤! 恭喜!!",
		// 幸運鑽石
		100400: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中鑽石 5連線! 水喔!! ",
		100401: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中紅七 5連線! 水喔!! ",
		100402: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中三BAR 5連線! 水喔!! ",
		100403: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中二BAR 5連線! 水喔!! ",
		100404: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中一BAR 5連線! 水喔!! ",
		100405: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中金礦彩金! 恭喜!! ",
		// 夜店
		100500: "恭喜{0}玩家在老子有錢 夜店，中兔女郎5連線! 水喔!!",
		100501: "恭喜{0}玩家在老子有錢 夜店，中三層兔女郎5連線! 水喔!!",
		100502: "恭喜{0}玩家在老子有錢 夜店，中兩層兔女郎5連線! 水喔!!",
		100503: "恭喜{0}玩家在老子有錢 夜店，中金礦彩金! 恭喜!!",
		// 維京人
		100600: "恭喜!! {0}玩家 玩老子有錢 維京人，中船長 5連線! 水喔!! ",
		100601: "恭喜!! {0}玩家 玩老子有錢 維京人，中廚師 5連線! 水喔!! ",
		100602: "恭喜!! {0}玩家 玩老子有錢 維京人，中小女孩 5連線! 水喔!! ",
		100603: "恭喜!! {0}玩家 玩老子有錢 維京人，中金礦彩金! 恭喜!! ",
		// 對戰
		// 老子10點半
		100803: "恭喜{0}玩家在老子有錢 老子10點半 裡過六關!!",
		100804: "恭喜{0}玩家在老子有錢 老子10點半 裡過七關!!",
		// 老子來德州
		100908: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到同花!!",
		100907: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到葫蘆!!",
		100900: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到鐵支擊敗對手!!",
		100901: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到同花順擊敗對手!!",
		100902: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到同花大順擊敗對手!!",
		100903: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到鐵支彩金!!",
		100904: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到同花順彩金!!",
		100905: "恭喜{0}玩家在老子有錢 老子來德州 裡，拿到同花大順彩金!!",
		// 老子撿紅點
		101001: "恭喜{0}玩家在老子有錢 老子撿紅點 裡，贏了150分以上!!",
		101002: "恭喜{0}玩家在老子有錢 老子撿紅點 裡，零分逆轉!!",
		// 老子大老二
		101203: "恭喜{0}玩家在老子有錢 老子大老二 裡，贏了對手200張以上的牌!!",
		101200: "恭喜{0}玩家在老子有錢 老子大老二 裡，贏了對手500張以上的牌!!",
		101201: "恭喜{0}玩家在老子有錢 老子大老二 裡，贏了對手1000張以上的牌!!",
		101202: "恭喜{0}玩家在老子有錢 老子大老二 裡，拿到了一條龍!!",
		// 老子來一將
		101304: "恭喜{0}玩家在老子有錢 老子來一將 裡，贏了4台以上!!",
		101300: "恭喜{0}玩家在老子有錢 老子來一將 裡，贏了8台以上!!",
		101301: "恭喜{0}玩家在老子有錢 老子來一將 裡，贏了12台以上!!",
		101302: "恭喜{0}玩家在老子有錢 老子來一將 裡，贏了16台以上!!",
		// 唬怕唬
		103101: "恭喜{0}玩家在老子有錢 老子唬怕唬 裡，贏得最高上限點數!!",
		// 13支
		103200: "恭喜{0}玩家在老子有錢 老子13支 裡，拿到了一條龍!!",
		103201: "恭喜{0}玩家在老子有錢 老子13支 裡，全壘打獲勝!!",
		// 大滿貫
		100700: "恭喜{0}玩家在老子有錢 老子大滿貫 裡，達成 役滿!!",
		100701: "恭喜{0}玩家在老子有錢 老子大滿貫 裡，達成 三倍滿!!",
		100702: "恭喜{0}玩家在老子有錢 老子大滿貫 裡，達成 倍滿!!",
		100703: "恭喜{0}玩家在老子有錢 老子大滿貫 裡，達成 大三元!!",
		100704: "恭喜{0}玩家在老子有錢 老子大滿貫 裡，達成 大四喜!!",
		// 比賽
		// 老子大老二比賽
		101503: "恭喜{0}玩家在老子有錢 歡樂開打-大老二比賽 裡，贏了對手200張以上的牌!!",
		101500: "恭喜{0}玩家在老子有錢 歡樂開打-大老二比賽 裡，贏了對手500張以上的牌!!",
		101501: "恭喜{0}玩家在老子有錢 歡樂開打-大老二比賽 裡，贏了對手1000張以上的牌!!",
		101502: "恭喜{0}玩家在老子有錢 歡樂開打-大老二比賽 裡，拿到了一條龍!!",
		// 老子來一將比賽
		101604: "恭喜{0}玩家在老子有錢 歡樂開打-來一將比賽 裡，贏了4台以上!!",
		101600: "恭喜{0}玩家在老子有錢 歡樂開打-來一將比賽 裡，贏了8台以上!!",
		101601: "恭喜{0}玩家在老子有錢 歡樂開打-來一將比賽 裡，贏了12台以上!!",
		101602: "恭喜{0}玩家在老子有錢 歡樂開打-來一將比賽 裡，贏了16台以上!!",
		// 13支比賽
		101700: "恭喜{0}玩家在老子有錢 歡樂開打-老子13支比賽 裡，拿到了一條龍!!",
		101701: "恭喜{0}玩家在老子有錢 歡樂開打-老子13支比賽 裡，全壘打獲勝!!",
		101702: "恭喜{0}玩家在老子有錢 歡樂開打-老子13支比賽 裡，全壘打獲勝!!",
		// 老子撿紅點比賽
		101801: "恭喜{0}玩家在老子有錢 歡樂開打-老子撿紅點比賽 裡，贏了150分以上!!",
		101802: "恭喜{0}玩家在老子有錢 歡樂開打-老子撿紅點比賽 裡，零分逆轉!!",
		// 唬怕唬比賽
		101901: "恭喜{0}玩家在老子有錢 歡樂開打-老子唬怕唬比賽 裡，贏得最高上限點數!!",
		// 7PK
		102600: "恭喜{0}玩家在老子有錢 老子 7PK 裡，達成 鐵支!!",
		102601: "恭喜{0}玩家在老子有錢 老子 7PK 裡，達成 同花順!!",
		102602: "恭喜{0}玩家在老子有錢 老子 7PK 裡，達成 五梅!!",
		102603: "恭喜{0}玩家在老子有錢 老子 7PK 裡，達成 同花大順!!",
		102604: "恭喜{0}玩家在老子有錢 老子 7PK 裡，達成 正同花大順!!",
		// 小瑪莉
		102800: "恭喜!! 玩家{0} 在小瑪莉遊戲中贏了全部JP!!",
		102801: "恭喜!! 玩家{0} 在小瑪莉遊戲中贏了 1/2 JP!!",
		// 動物樂園
		103300: "恭喜{0}玩家在老子有錢 動物樂園 裡，贏得大獎!!",
		// 百家樂
		103401: "恭喜{0}玩家在老子有錢 老子百家樂 裡押中和!!",
		103402: "恭喜{0}玩家在老子有錢 老子百家樂 裡押中閒對!!",
		103403: "恭喜{0}玩家在老子有錢 老子百家樂 裡押中莊對!!",
		// 暗棋
		103500: "恭喜{0}玩家在 老子下暗棋裡獲得滿百加倍!!",
		103501: "恭喜{0}玩家在 老子下暗棋裡獲得兩百加倍!!",
		// 賓果
		103600: "恭喜{0}玩家在  餐廳賓果裡拿到賓果彩金!!",
        // 經典7PK
        103000: "恭喜 {0} 玩家在老子有錢經典7PK 裡，拿到大柳!!",
        103001: "恭喜 {0} 玩家在老子有錢經典7PK 裡，拿到五梅!!",
        103002: "恭喜 {0} 玩家在老子有錢經典7PK 裡，拿到小柳!!",
        103003: "恭喜 {0} 玩家在老子有錢經典7PK 裡，拿到鐵支!!",
        // 新幸運鑽石
        104300: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中鑽石 5連線! 水喔!! ",
        104301: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中紅七 5連線! 水喔!! ",
        104302: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中三BAR 5連線! 水喔!! ",
        104303: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中二BAR 5連線! 水喔!! ",
        104304: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中一BAR 5連線! 水喔!! ",
        104305: "恭喜!! {0}玩家 玩老子有錢 幸運鑽石，中金礦彩金! 恭喜!! ",
        // 希臘傳說
        104401: "恭喜{0}玩家在老子有錢 希臘傳說，中宙斯5連線! 水喔!!",
        104402: "恭喜{0}玩家在老子有錢 希臘傳說，中波賽頓5連線! 水喔!!",
        104403: "恭喜{0}玩家在老子有錢 希臘傳說，中金礦彩金! 恭喜!!",
        // 海洋世界
        104500: "恭喜!! {0}玩家 玩老子有錢 海洋世界，中鯊魚5連線! 水喔!!",
        104501: "恭喜!! {0}玩家 玩老子有錢 海洋世界，中魟魚5連線! 水喔!!",
        104502: "恭喜!! {0}玩家 玩老子有錢 海洋世界，中海龜5連線! 水喔!!",
        104503: "恭喜!! {0}玩家 玩老子有錢 海洋世界，中金礦彩金! 恭喜!! ",
	    // 超八
        102953: "恭喜!! {0}玩家 玩老子有錢 超八，中超八! 水喔!!"
	},
	// Web 小瑪莉中獎發佈訊息
	Maly: {
		Web: [
			"剛剛免費獲得日本正版『海賊王公仔』！我的朋友們~告訴你這麼棒的好康！快點連結來免費領最熱血的海賊王公仔！",
			"快按這裡！你也一起來拿免費日本正版『海賊王公仔』！我把我的運氣分給你！你一定也可以跟我一樣獲得最大獎！",
			"剛剛免費獲得日本正版『海賊王公仔』！別說我沒告訴你！這裡有日本直送正版海賊王限量公仔可以領！想拿就點連結來領！"
		],
		Facebook: {
			Default: [
				"他們真的有送耶~~我果真拿到可愛的喬巴公仔了<center></center>還是日本正版的耶！！！老子有錢讚啦"
			],

		}
	}
};

// 同步更新 Facebook 頭像
function UpdateFacebookPhoto() {
	var fb_util = new Facebook();
	var strPic = "";
	fb_util.GetUserInfo({
		CallBack: function (userinfo) {
			strPic = userinfo.pic_square;
			swfobject.getObjectById("WebLoad").CallWinByNameAS("FaceBookReturn", strPic);
		},
        EventFail: function () {
			swfobject.getObjectById("WebLoad").CallWinByNameAS("CancelFB", strPic);
		}
	});
}

// MasterPage 春龍發佈
function RichGoldShare() {
	var fb_util = new Facebook();
	fb_util.Platform = GetPlatform();
	fb_util.Feed({
		picture: 'http://' + GetDataInfo() + '/Html/UploadFiles/FBFeed/RichGold.jpg',
		description: '我好想要你全壘打喔！只要全壘打次數最多就可以免費得到西堤套餐雙人劵，而且天天進來玩還可以拿到發財金喔！'
		}
	);
}

var IsLockFeedForGame = false;
// 遊戲中獎時PO文到 Facebook
function FeedForGame(GameID, GroupID, ActID) {
	if (IsFBPublish == 'publish') {
        if (IsLockFeedForGame) return;

		IsLockFeedForGame = true;
		var fb_util = new Facebook();
		fb_util.Platform = GetPlatform();

		// 顯示FLASH		
		fb_util.Callback = function () { IsLockFeedForGame = false; }

		fb_util.GetUserInfo({
            CallBack: function (userinfo) {
				fb_util.Feed({
					display: 'popup',
					picture: 'http://' + GetDataInfo() + '/Html/UploadFiles/FBFeed/' + ActID + '.png',
					name: userinfo.name + ' 中獎了',
					caption: (fb_util.Platform == "FB") ? '『老子有錢臉書遊戲』讓我體驗到有錢的感覺~' : '老子有錢 Online',
					description: String.Format(FeedMsg.Winning[ActID], userinfo.name),
                    actions: [{ name: '馬上玩', link: getFBCanvasUrl() }]
                });
			}
		});
	}
}

// 小瑪莉中獎發文
function ADFeedForMaly() {
	// 把FLASH藏起來防止被檔住
	displayFlashScreenshot();

	var fb_util = new Facebook();
	fb_util.Platform = GetPlatform();
	var minNum = 0, maxNum, n, wallMsgs, FeedConfig, fbApp;
    switch (fb_util.Platform) {
		case "FB":
			fbApp = getFBApp();
            if (fbApp == "zeroeight_thirdteen" || fbApp == "zeroeight_texas") {//fbApp == "zeroeight_bigtwo" || fbApp == "zeroeight_pick") {
				wallMsgs = ["我還以為是唬爛的！！但是我真的領到免錢F幣了~~這遊戲也太有誠意了吧><"];

				FeedConfig = {
					method: 'feed',
					name: '老子不唬爛~~我真的拿到喬巴公仔了',
					display: 'iframe', // page, popup, iframe, touch, or wap.
					picture: GetCdn() + '/Html/Images/FBLayout/main_content/Feed/MalyFeedMJ.jpg',
					link: getFBCanvasUrl()
				};
			}
            else if (fbApp == "zeroeight_mj") {
				wallMsgs = ["原來領個5枚F幣這麼簡單！！我不過就玩場麻將而已！！好想多領幾枚喔！！飲恨~~~~~"];

				FeedConfig = {
					method: 'feed',
					name: '要拿F幣也太簡單了吧！！',
					display: 'iframe', // page, popup, iframe, touch, or wap.
					picture: GetCdn() + '/Html/Images/FBLayout/main_content/Feed/MalyFeedMJ.jpg',
					link: getFBCanvasUrl()
				};
			}
            else if (fbApp == "zeroeight_bigtwo") {
				wallMsgs = ["原來領個5枚F幣這麼簡單！！我不過就玩場大老二而已！！好想多領幾枚喔！！飲恨~~~~~"];

				FeedConfig = {
					method: 'feed',
					name: '要拿F幣也太簡單了吧！！',
					display: 'iframe', // page, popup, iframe, touch, or wap.
					picture: GetCdn() + '/Html/Images/FBLayout/main_content/Feed/MalyFeedMJ.jpg',
					link: getFBCanvasUrl()
				};
			}
            else if (fbApp == "zeroeight_pick") {
				wallMsgs = ["原來領個5枚F幣這麼簡單！！我不過就玩場撿紅點而已！！好想多領幾枚喔！！飲恨~~~~~"];

				FeedConfig = {
					method: 'feed',
					name: '要拿F幣也太簡單了吧！！',
					display: 'iframe', // page, popup, iframe, touch, or wap.
					picture: GetCdn() + '/Html/Images/FBLayout/main_content/Feed/MalyFeedMJ.jpg',
					link: getFBCanvasUrl()
				};
			}
			else {
				wallMsgs = FeedMsg.Maly.Facebook.Default;

				FeedConfig = {
					method: 'feed',
					display: 'iframe', // page, popup, iframe, touch, or wap.
					picture: GetCdn() + '/Html/Images/FBLayout/main_content/Feed/MalyFeed.jpg',
					link: getFBCanvasUrl()
				};
			}
		break;
		default:
			wallMsgs = FeedMsg.Maly.Web;

			FeedConfig = {
				picture: GetCdn() + '/Html/Images/FBLayout/main_content/Feed/MalyFeed.jpg',
				link: "http://" + GetDomain()
			};
		break;
	}
	maxNum = wallMsgs.length - 1;
	n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;

	fb_util.GetUserInfo({
        CallBack: function (userinfo) {
			var MsgConfig = {
				name: userinfo.name + ' 中獎了',
				description: String.Format(wallMsgs[n], userinfo.name)
			};

			$.extend(FeedConfig, MsgConfig);

			// 顯示FLASH		
			fb_util.Callback = function () { IsLockFeedForGame = false; hideFlashScreenshot(); }

            if (fb_util.Platform == "FB") {
				fb_util.Feed(FeedConfig);
			} else {
				//fb_util.Publish(FeedConfig);
			}
		}
	});
}