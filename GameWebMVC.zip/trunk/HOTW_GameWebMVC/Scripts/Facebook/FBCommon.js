﻿/// <reference path="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js" />

// 離開視窗Logout
//$(function () {
//	window.onunload = function () {
//		FBWindowClose();
//	};

//	// setInterval(KeepOnlineToFB, 30000);	
//});

// 通知 Server 登出 (Flash 呼叫登出用)
function LogoutFB() {
	$.ajax({
		type: "POST",
		url: "/AppAjaxs/Logout.ashx",
		async: "true",
		success: function (data) {
			window.location.href = '/FB/FBError.aspx';
		},
		error: function (e) {
			// alert(e.responseText);
		}
	});
}

// 通知 Server 登出 (網頁關掉或轉頁用)
function LogoutOnFB() {
	if (!IsRefresh) {
		$.ajax({
			type: "POST",
			url: "/AppAjaxs/Logout.ashx",
			async: "true",
			success: function (data) {
				// alert(data);
			},
			error: function (e) {
				// alert(e.responseText);
			}
		});
	}
}

// 離開/關閉視窗
function FBWindowClose() {
	LogoutOnFB();
}

function FBConfirmClose() {

}

// 取得好友資料 (偵錯用)
function GetAppFriendList() {
	$.ajax({
		type: "POST",
		url: "/Appajaxs/FB/GetAppFriendList.ashx",
		async: "true",
		success: function (data) {
			alert(data);
		},
		error: function (e) {
			// alert(e.responseText);
		}
	});
}

// 讀取 FBMainBase
function LoadFBMainBase(fileName, winName, gameName, arg1) {	
	var winName = winName;
	var gameName = gameName;
	var arg1 = arg1;

	// 移除陣列資料
	GameWins = $.grep(GameWins, function (obj) {
		return false;
	});

	// 檢查視窗規則
	checkWins(winName);

	// 初始化視窗物件
	var objWin = {
		winName: winName,
		gameName: gameName
	};

	var flashvars = {
		winName: winName,
		gameName: gameName,
		arg1: arg1
	};

	var params = {
		wmode: navigator.userAgent.indexOf("Chrome") == -1 ? "opaque" : "transparent",
		allowScriptAccess: "always",
		allowFullScreen: "true"
	};

	var attributes = {
		name: 'divContent_' + winName,
		id: 'divContent_' + winName
	};

	// 載入視窗
	$('#boxBody').empty();
	$('#boxBody').append("<div class='FlashGameBox' id='divContainer_" + winName + "' style='width: 760px; height: 570px;'><div class='FlashGameTitle' id='divTitle_" + winName + "'></div><div id='divContent_" + winName + "'></div></div>");
	swfobject.embedSWF(GetCdn() + '/Html/GameFlash/' + fileName, 'divContent_' + winName, '760', '570', '10', '../../Scripts/expressInstall.swf', flashvars, params, attributes);
			
	GameWins.push(objWin);
}

function LoadIFrame(url) {
	var index = url.indexOf("?");

	if (index == -1) {
		url = url + "?fbApp=" + getFBApp() + "&Coin=" + GetMType();
	}
	else {
		url = url + "&fbApp=" + getFBApp() + "&Coin=" + GetMType();
	}
	
	var iframe = '<iframe id="iPage" style="width: 760px; height: 570px; margin: 0; padding: 0; border: 0; display: block;" frameborder="0" marginheight="0" marginwidth="0" scrolling="no" src="' + url + '"></iframe>';
	$('#boxBody').html(iframe);
}

// 打開購買商品頁面
function Purchase() {
	$('#boxBody').empty();
	$('#boxBody').load("/FB/Purchase.aspx?fbApp=" + getFBApp() + "&Coin=" + GetMType());
}

// 致能邀請好友超連結
function EnableInvite() {
	// 顯示FLASH
	hideFlashScreenshot();

	$('#aInvite').attr("disabled", false);
	$('#aInvite').attr("OnClick", "swfobject.getObjectById('Friend').inviteFriend(); return false;");
}

// 禁能邀請好友超連結
function DisableInvite() {
	// 把FLASH藏起來防止被檔住
	displayFlashScreenshot();
	
	$('#aInvite').attr("disabled", true);
	$('#aInvite').attr("OnClick", "return false;");
	// $("#aInvite").disable();
}

function InivteMessage() {
	var minNum = 0;
	var maxNum = 0;
	var n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;
	var fbApp = getFBApp();

	var title = new Object();
	var message = new Object();

	if (fbApp == "zeroeight_mj" || fbApp == "zeroeight_texas" || fbApp == "zeroeight_bigtwo" || fbApp == "zeroeight_pick" || fbApp == "zeroeight_thirdteen" || fbApp == "zeroeight_bingo") {
		minNum = 0;
		maxNum = 0;
		n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;

		title[0] = "邀請你的朋友，一起來領取10枚F幣";
		message[0] = "真的有免錢F幣可以領耶！！我還以為是唬爛的>< But 我領到了~~想領要快~~活動結束就沒了";
	}
	else if (fbApp == "zeroeight_ten") {
		minNum = 0;
		maxNum = 0;
		n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;

		title[0] = "邀請你的朋友，一起來喝咖啡。";
		message[0] = "我需要喝杯咖啡醒醒腦！！我想你也是。85度C咖啡免費招待~快來老子有錢臉書遊戲~我試過了真的不用錢！！！";
	}
	else if (fbApp == "zeroeight_xxxxx") {
		minNum = 0;
		maxNum = 0;
		n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;

		title[0] = "邀請你的朋友，一起來領取Facebook限量按讚筆！";
		message[0] = "Facebook出限量按讚筆！老子有錢臉書遊戲用送的！太簡單了~我剛剛成功領取一支！快點加入幫我搜集啦！";
	}
	else if (fbApp == "money_fb") {
	    minNum = 0;
	    maxNum = 0;
	    n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;

	    title[0] = "邀請你的朋友！";
	    message[0] = "Hi! 我需要你幫忙，看看這遊戲好不好玩，裡面有好多經典遊戲，讓你就像在遊藝場玩遊戲一樣，還有麻將、大老二...等等。幫忙的話人人還可以抽一千！";
	}
	else {
		minNum = 0;
		maxNum = 0;
		n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;

		title[0] = "邀請你的朋友，一起來領取海賊王公仔！";
		message[0] = "有FB遊戲在送喬巴公仔耶！！我領到了~超級可愛的！！喬巴果然是王道~~想領的要快喔！送完就沒了><";		
	}

	return title[0] + "," + message[0];
}

function uiInvite() {
	DisableInvite();

	var settings = {
		width: 600,
		height: 150,
		offsetTop: -100,
		borderEnable: 0,
		alwaysShow: 0
	};

	CloseAllDialog();
	OpenDialog('/FB/Invite.aspx' + '?fbApp=' + getFBApp() + '&Coin=' + GetMType(), settings);
	return;	

//	var uid;
//	var exclude_ids = "";
//	var surplus = 0;

//	var arrInviteMessage = InivteMessage().split(",");
//	var title = arrInviteMessage[0];
//	var message = arrInviteMessage[1];
//		
//	FB.api('/me', function (response) {
//		uid = response.id;
//		
//		$.ajax({
//			type: "GET",
//			url: "/AppAjaxs/FB/GetAppFriendList.ashx" + "?friendType=3",
//			async: false,
//			success: function (data) {
//				// friendType=0 取得非會員
//				// friendType=1 取得會員
//				// friendType=2 取得非會員且未被邀請過好友
//				// friendType=3 取得要排除的會員	

//				var arrFriend = data.split("#@$");
//				// 剩餘邀請數量，大於等於 20 以 20 計
//				surplus = arrFriend[0] >= 20 ? 20 : arrFriend[0];

//				for (var i = 1; i < arrFriend.length; i++) {
//					exclude_ids += arrFriend[i].split("$#%")[0] + ",";
//				}

//				if (exclude_ids.length > 0) {
//					exclude_ids = exclude_ids.substring(0, exclude_ids.length - 1);
//				}
//				else {
//					exclude_ids = "0";
//				}
//			},
//			error: function (e) {
//				// alert(e.responseText);
//			}
//		});
//		
//		FB.ui({
//			method: 'apprequests',
//			title: title,
//			message: message,
//			data: 'Invite',
//			max_recipients: '20',
//			// filters: [{ name: 'Other Set', user_ids: "[" + exclude_ids + str + "]"}]
//			exclude_ids: "[" + exclude_ids + "]"
//		},
//		// InviteCallback(uid));
//		function (response) {
//			if (response && response.request) {
//				$.ajax({
//					type: "Post",
//					url: "/AppAjaxs/FB/InviteData.ashx",
//					data: "request_ids=" + response.request + "&uid=" + uid + "&to=" + response.to,
//					success: function (data) {
//						swfobject.getObjectById("divMainFriend").InviteFriendGame(data);
//						swfobject.getObjectById("divMainFriend").RemoveFriend(response.to.toString().replace(/\,/g, "#@$"));						
//					},
//					error: function (e) {
//						// 致能邀請好友超連結
//						$('#aInvite').attr("disabled", false);
//						swfobject.getObjectById("divMainFriend").RemoveFriend("x");						
//					}
//				});
//			}
//			else {
//				// 致能邀請好友超連結
//				$('#aInvite').attr("disabled", false);
//				swfobject.getObjectById("divMainFriend").RemoveFriend("x");
//			}
//		});
//	});
}

function uiInviteToOne(uid) {
	DisableInvite();

	// 關閉彈跳視窗
	CloseAllDialog();	

	// 禁能邀請好友超連結
	$('#aInvite').attr("disabled", true);
	$('#aInvite').attr("OnClick", "return false;");
	// $("#aInvite").disable();

	var surplus = 0;

	var arrInviteMessage = InivteMessage().split(",");
	var title = arrInviteMessage[0];
	var message = arrInviteMessage[1];

	FB.ui({
		method: 'apprequests',
		message: message,
		to: uid,
		data: 'Invite'
	},
	function (response) {
		if (response && response.request) {
			$.ajax({
				type: "Post",
				url: "/AppAjaxs/FB/InviteData.ashx",
				data: "request_ids=" + response.request + "&uid=" + uid + "&to=" + response.to,
				success: function (data) {					
					CloseAllDialog();
					try {
						swfobject.getObjectById("WebLoad").InviteFriendGame(data);
					} catch (e) {

					}
					swfobject.getObjectById("WebLoad").RemoveFriend(response.to.toString().replace(/\,/g, "#@$"));
				},
				error: function (e) {
					// 致能邀請好友超連結
					CloseAllDialog();
					EnableInvite();
					swfobject.getObjectById("WebLoad").RemoveFriend("x");
				}
			});
		}
		else {
			// 致能邀請好友超連結
			EnableInvite();
			swfobject.getObjectById("WebLoad").RemoveFriend("x");
		}
	});	
}

// 轉輪結束發文(有中F幣)
function InviteFeed() {
	var wallMessage = new Object();
	var picture = '';

	var minNum = 0;
	var maxNum = 2;
	var n = Math.floor(Math.random() * (maxNum - minNum + 1)) + minNum;
	var fbApp = getFBApp();

	FB.api(
	{
		method: 'fql.query',
		query: 'SELECT name FROM user WHERE uid = me()'
	},
	function (response) {
		// wallMessage[0] = "謝謝" + "" + "讓我免費獲得F幣！你也一起快來領！";
		wallMessage[0] = "好友大集氣！邀請朋友讓我拿到F幣啦！真是有拜有保庇！";
		wallMessage[1] = "我快HOLD不住啦！F幣也太好拿了吧！只是邀請朋友就拿的到！";
		wallMessage[2] = response[0].name + "剛剛邀請朋友免費獲得F幣！好友大集氣！按下邀請免費拿F幣！";

		picture = GetCdn() + '/Html/Images/FBLayout/main_content/Feed/FBCreditsFeed.jpg';

		FB.api('/feed', 'post', {
			message: '',
			picture: picture,
			name: response[0].name + ' 中獎了',
			link: getFBCanvasUrl(),
			caption: '『老子有錢臉書遊戲』讓我體驗到有錢的感覺~',
			description: wallMessage[0]
			// actions: [{ name: '馬上玩', link: 'http://' + '<%: GWeb.AppLibs.WebConfig.FBAppCanvasPage + "Default.aspx?KeyCode=" %>' + data}]
		},
		function (response) {
			if (!response || response.error) {
				
			}
			else {

			}
		});
	});
}

function Feed(settings) {
	var _defaultSettings = {
		param: {
			method: 'feed',
			display: 'iframe', // page, popup, iframe, touch, or wap.
			message: '',
			user_prompt_message: '',
			picture: '',
			name: '',
			link: '',
			caption: '',
			description: '',
			actions: { name: '', link: '' },
			target_id: ''
		},
		callback: ''
	};

	var _settings = $.extend(_defaultSettings, settings);

	FB.ui(_settings.param, _settings.callback);
}

function Invite(settings) {
	var _defaultSettings = {
		param: {
			method: 'apprequests',
			display: 'iframe', // page, popup, iframe, touch, or wap.			
			title: '',
			message: '',
			data: 'Invite',
			max_recipients: '20',
			filters: '',
			exclude_ids: ''
		},
		callback: ''
	};

	var _settings = $.extend(_defaultSettings, settings);

	FB.ui(_settings.param, _settings.callback);
}