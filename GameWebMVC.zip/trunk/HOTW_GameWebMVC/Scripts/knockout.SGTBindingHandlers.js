﻿ko.bindingHandlers.DateString = {
    update: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        var value = valueAccessor(),
            allBindings = allBindingsAccessor();
        var valueUnwrapped = ko.utils.unwrapObservable(value);
        var pattern = allBindings.DateFormatString || 'MM/dd/yyyy';

        var GetDate = new Date(Date.parse($.browser.msie ? valueUnwrapped.replace(/\-/ig, '/').split('.')[0] : valueUnwrapped));

        $(element).text(GetDate.format(pattern));
    }
}