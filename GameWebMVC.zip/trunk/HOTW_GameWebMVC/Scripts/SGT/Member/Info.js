﻿
// 卡別資訊
SGT.Main.Add('PersonalCard', {
	Store: ko.observable(),
	Bet: ko.observable(),
	CurrentLevel: ko.observable(),
	NextLevel: ko.observable(),
	NextDate: ko.observable("0000/0/0"),
	NextMonth: function () {
		var month = (new Date(SGT.Main.QueryFns['PersonalCard'].NextDate()).getMonth() + 1) % 12;		
		return month == 0 ? 12: month;
	},
	NextDay: function () {
	    return new Date(SGT.Main.QueryFns['PersonalCard'].NextDate()).getDate();
	},
	ConvertToCardName: function (level) {
		if (level == 1) {
			return "普卡";
		}
		else if (level == 2) {
			return "銀卡";
		}
		else if (level == 3) {
			return "金卡";
		}
		else if (level == 4) {
			return "白金卡";
		}
		else {
			return "一般";
		}

		return "";
	},
	StoreBar: function (config) {
		var percent = 0;
		var imageUrl = "";
		
		var DefaultConfig = {
            IsMini: true
		}
		DefaultConfig = $.extend(DefaultConfig, config);
		
		if (SGT.Main.QueryFns['PersonalCard'].Store().NowValue < SGT.Main.QueryFns['PersonalCard'].Store().No2Value) {
			percent = (SGT.Main.QueryFns['PersonalCard'].Store().NowValue - SGT.Main.QueryFns['PersonalCard'].Store().No1Value) / SGT.Main.QueryFns['PersonalCard'].Store().No2Value * 0.5 * 100;
		} else if (SGT.Main.QueryFns['PersonalCard'].Store().NowValue >= SGT.Main.QueryFns['PersonalCard'].Store().No3Value) {
			percent = 100;
		} else {
			percent = 50 + ((SGT.Main.QueryFns['PersonalCard'].Store().NowValue - SGT.Main.QueryFns['PersonalCard'].Store().No2Value) / (SGT.Main.QueryFns['PersonalCard'].Store().No3Value - SGT.Main.QueryFns['PersonalCard'].Store().No2Value) * 0.5 * 100);
		}
		var ImgFolder = DefaultConfig.IsMini ? (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/main/") : (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/content/");
		var ImgFileType = DefaultConfig.IsMini ? ".jpg" : ".png";
		
		if (percent <= 0) {
		    imageUrl = ImgFolder + "strip00" + ImgFileType;
		}
		else if (percent <= 16) {
		    imageUrl = ImgFolder + "strip01" + ImgFileType;
		}
		else if (percent <= 32) {
		    imageUrl = ImgFolder + "strip02" + ImgFileType;
		}
		else if (percent < 50) {
		    imageUrl = ImgFolder + "strip03" + ImgFileType;
		}
		else if (percent == 50) {
		    imageUrl = ImgFolder + "strip04" + ImgFileType;
		}
		else if (percent <= 66) {
		    imageUrl = ImgFolder + "strip05" + ImgFileType;
		}
		else if (percent <= 82) {
		    imageUrl = ImgFolder + "strip06" + ImgFileType;
		}
		else if (percent < 100) {
		    imageUrl = ImgFolder + "strip07" + ImgFileType;
		}
		else if (percent >= 100) {
		    imageUrl = ImgFolder + "strip08" + ImgFileType;
		}

		return imageUrl;
	},
	BetBar: function (config) {
		var percent = 0;
		var imageUrl = "";
		var DefaultConfig = {
		    IsMini: true
		}
		$.extend(DefaultConfig, config);

		if (SGT.Main.QueryFns['PersonalCard'].Bet().NowValue < SGT.Main.QueryFns['PersonalCard'].Bet().No2Value) {
			percent = (SGT.Main.QueryFns['PersonalCard'].Bet().NowValue - SGT.Main.QueryFns['PersonalCard'].Bet().No1Value) / SGT.Main.QueryFns['PersonalCard'].Bet().No2Value * 0.5 * 100;
		} else if (SGT.Main.QueryFns['PersonalCard'].Bet().NowValue >= SGT.Main.QueryFns['PersonalCard'].Bet().No3Value) {
			percent = 100;
		} else {
			percent = 50 + ((SGT.Main.QueryFns['PersonalCard'].Bet().NowValue - SGT.Main.QueryFns['PersonalCard'].Bet().No2Value) / (SGT.Main.QueryFns['PersonalCard'].Bet().No3Value - SGT.Main.QueryFns['PersonalCard'].Bet().No2Value) * 0.5 * 100);
		}

		var ImgFolder = DefaultConfig.IsMini ? (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/main/") : (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/content/");
		var ImgFileType = DefaultConfig.IsMini ? ".jpg" : ".png";

		if (percent <= 0) {
		    imageUrl = ImgFolder + "strip00" + ImgFileType;
		}
		else if (percent <= 16) {
		    imageUrl = ImgFolder + "strip01" + ImgFileType;
		}
		else if (percent <= 32) {
		    imageUrl = ImgFolder + "strip02" + ImgFileType;
		}
		else if (percent < 50) {
		    imageUrl = ImgFolder + "strip03" + ImgFileType;
		}
		else if (percent == 50) {
		    imageUrl = ImgFolder + "strip04" + ImgFileType;
		}
		else if (percent <= 66) {
		    imageUrl = ImgFolder + "strip05" + ImgFileType;
		}
		else if (percent <= 82) {
		    imageUrl = ImgFolder + "strip06" + ImgFileType;
		}
		else if (percent < 100) {
		    imageUrl = ImgFolder + "strip07" + ImgFileType;
		}
		else if (percent >= 100) {
		    imageUrl = ImgFolder + "strip08" + ImgFileType;
		}

		return imageUrl;
	}
});

$SGT.PageLoad.Add(function () {
    var platform = "Web";
    if (typeof GetPlatform == 'function') {
        platform = GetPlatform();
    }
    $.getJSON("/Mvc/api/staticdata/Get", { Flags: "PersonalCard", Platform: platform }, function (data) {
        if (data.PersonalCard != null) {
            $.each(data.PersonalCard.DataList, function (index, obj) {
                if (index == 0) { SGT.Main.QueryFns['PersonalCard'].Store(obj); }
                if (index == 1) { SGT.Main.QueryFns['PersonalCard'].Bet(obj); }
            });
            SGT.Main.QueryFns['PersonalCard'].CurrentLevel(data.PersonalCard.CurrentLevel);
            SGT.Main.QueryFns['PersonalCard'].NextLevel(data.PersonalCard.NextLevel);
            SGT.Main.QueryFns['PersonalCard'].NextDate(data.PersonalCard.NextDate);
        }
		// 測試資料

		//SGT.Main.QueryFns['PersonalNews'].push({ MessageData: '一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十' });
		//SGT.Main.QueryFns['PersonalNews'].push({ MessageData: '一二三四五六七八九十一二三四五六七八九十' });
		//SGT.Main.QueryFns['PersonalNews'].push({ MessageData: '一二三四五六七八九十一二三四五六七八九十' });
		//SGT.Main.QueryFns['PersonalNews'].push({ MessageData: 'aa' });
		//SGT.Main.QueryFns['PersonalNews'].push({ MessageData: '一二三四五六七八九十一二三四五六七八九十' });
		//SGT.Main.QueryFns['PersonalNews'].push({ MessageData: '一二三四五六七八九十一二三四五六七八九十' });		
		
		//SGT.Main.QueryFns['PersonalGlory'].push({ RowNo: 1, EventDec: '一二三四五六七八九十一二三四五六七八九十', EventDate: '2012-09-01' });
		//SGT.Main.QueryFns['PersonalGlory'].push({ RowNo: 2, EventDec: '一二三四五六七八九十一二三四五六七八九十', EventDate: '2012-09-01' });
		//SGT.Main.QueryFns['PersonalGlory'].push({ RowNo: 3, EventDec: 'cc', EventDate: '2012-09-01' });
		//SGT.Main.QueryFns['PersonalGlory'].push({ RowNo: 4, EventDec: 'cc', EventDate: '2012-09-01' });
		//SGT.Main.QueryFns['PersonalGlory'].push({ RowNo: 5, EventDec: 'cc', EventDate: '2012-09-01' });		
				
		//SGT.Main.QueryFns['PersonalCard'].Store({ NowValue: 900, No1Level: 1, No1Value: 100, No2Level: 2, No2Value: 500, No3Level: 3, No3Value: 1000 });
		//SGT.Main.QueryFns['PersonalCard'].Bet({ NowValue: 30000, No1Level: 1, No1Value: 1000, No2Level: 2, No2Value: 50000, No3Level: 3, No3Value: 100000 });

		// 測試資料
	});	
});