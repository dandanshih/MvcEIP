declare var getParameter;
declare var SGT;
declare var $;
declare var ko;
declare var PopPage;
declare var $SGT;

module SGT.Member {

    // �����ഫ����
    export class AccountChangeProcess {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {

        }

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ����J���������
        ToMobileEnter(): void {
            if (!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                return;
            }

            SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileEnter");
        }

        // ����J������ҽX������
        ToMobileAuthentication(): void {
            if (!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                return;
            }

            SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileAuthentication");
        }

        // ������ҥ��Ѫ�����
        ToMobileAuthenticationFail(): void {
            if (!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                return;
            }

            SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileAuthenticationFail");
        }

        // ������Ҧ��\������
        ToMobileAuthenticationSuccess(): void {
            if (!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                return;
            }

            SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileAuthenticationSuccess");
        }

        // ��������
        Close(): void {
            if (!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                return;
            }

            SGT.Global.PopIframeMgr.Remove('CWLoginIframe');
        }
    }

    // �i��J����j���سB�z
    export class AccountChange_MobileEnter {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {
        }


        /// --------------------------------------
        /// ko
        /// --------------------------------------
        Mobile = ko.observable('');
        IsSubmitEnable = ko.observable(true);


        /// --------------------------------------
        /// function
        /// --------------------------------------
        Submit(): void {
            var obj = this;

            // ��w���s
            obj.IsSubmitEnable(false);
            var data =
            {
                Mobile: obj.Mobile()
            };

            $.ajax({
                type: "Post",
                url: "/Mvc/api/AccountChange/EnterMobile",
                data: data,
                success: function (data) {

                    if (data.ResultCode == 0) {
                        window['top'].SGT.Main.QueryFns['AccountChangeProcess'].ToMobileAuthentication();
                    } else if (data.ResultCode == 1) {
                        window['top'].SGT.Main.QueryFns['AccountChangeProcess'].ToMobileAuthenticationFail();
                    } else {
                        // ��w���s
                        obj.IsSubmitEnable(true);
                        alert(data.ResultMsg);
                    }
                },
                error: function (e) {
                    // alert(e.responseText);
                    // �Ѱ���w
                    obj.IsSubmitEnable(true);
                }
            });
        }
    }

    // �i��J������ҽX�j���سB�z
    export class AccountChange_MobileAuth {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {
        }


        /// --------------------------------------
        /// ko
        /// --------------------------------------
        AuthCode = ko.observable('');
        IsReSendEnable = ko.observable(true);
        IsSubmitEnable = ko.observable(true);


        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ���s�o�e���ҽX
        ReSendAuthCode(): void {
            var obj = this;

            // ��w���s
            obj.IsReSendEnable(false);

            $.ajax({
                type: "Post",
                url: "/Mvc/api/AccountChange/ReSendAuthCode",
                success: function (data) {
                    // �Ѱ���w
                    obj.IsReSendEnable(true);

                    if (data.ResultCode == 0) {
                        alert(data.ResultMsg);
                        if (data.Data) {
                            obj.AuthCode(data.Data);
                        }
                    } else {
                        alert(data.ResultMsg);
                    }
                },
                error: function (e) {
                    // alert(e.responseText);
                    // �Ѱ���w
                    obj.IsReSendEnable(true);
                }
            });
        }

        // �e�X
        Submit(): void {
            var obj = this;

            // ��w���s
            obj.IsSubmitEnable(false);
            var data =
            {
                MobileVaildCode: obj.AuthCode()
            };

            $.ajax({
                type: "Post",
                url: "/Mvc/api/AccountChange/MobileAuthentication",
                data: data,
                success: function (data) {

                    if (data.ResultCode == 0) {
                        alert(data.ResultMsg);
                        window['top'].SGT.Main.QueryFns['AccountChangeProcess'].ToMobileAuthenticationSuccess();
                    }
                    else {
                        alert(data.ResultMsg);
                    }

                    if (data.ResultCode != 0) {
                        // �Ѱ���w
                        obj.IsSubmitEnable(true);
                    }

                },
                error: function (e) {
                    // alert(e.responseText);
                    // �Ѱ���w
                    obj.IsSubmitEnable(true);
                }
            });
        }

    }

    // �i���Ҧ��\�j���سB�z
    export class AccountChange_MemberTypeChange {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {
        }


        /// --------------------------------------
        /// ko
        /// --------------------------------------
        Account = ko.observable('');
        Password = ko.observable('');
        ConfirmPassword = ko.observable('');
        Email = ko.observable('');
        IsSubmitEnable = ko.observable(true);


        /// --------------------------------------
        /// function
        /// --------------------------------------
        // �e�X
        Submit(): void {
            var obj = this;

            // ��w���s
            obj.IsSubmitEnable(false);

            if (obj.Password() != obj.ConfirmPassword()) {
                alert($SGT.Message.AccountChange.Utility[0]);
                obj.IsSubmitEnable(true);
                return;
            }

            var data =
            {
                MemberAccount: obj.Account()
                , MemberPassword: obj.Password()
                , EMail: obj.Email()
            };

            $.ajax({
                type: "Post",
                url: "/Mvc/api/AccountChange/MemberTypeChange",
                data: data,
                success: function (data) {

                    if (data.ResultCode == 0) {
                        alert(data.ResultMsg);
                        window['top'].SGT.Main.QueryFns['AccountChangeProcess'].Close();
                    }
                    else {
                        alert(data.ResultMsg);
                    }

                    if (data.ResultCode != 0) {
                        // �Ѱ���w
                        obj.IsSubmitEnable(true);
                    }

                },
                error: function (e) {
                    // alert(e.responseText);
                    // �Ѱ���w
                    obj.IsSubmitEnable(true);
                }
            });
        }

    }
}