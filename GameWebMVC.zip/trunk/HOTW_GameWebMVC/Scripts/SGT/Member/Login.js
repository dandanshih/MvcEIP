﻿
SGT.Main.Add('Member', {
	IsLogin: ko.observable(false),
	MemberAccount: ko.observable(""),
	MemberPassword: ko.observable(""),
	IsRemember: ko.observable(false),
	NickName: ko.observable(""),
	Level: ko.observable(1),
	Code: ko.observable(""),
	VIP_Level: ko.observable(0),
	IsUCoin: ko.observable(false),
	Mobile: ko.observable(""),
	VerifyCode: ko.observable(""),
	VerifyCodeUrl: ko.observable("/AppUserControls/Other/VerifyCode.ashx"),

	HCoin: ko.observable(0.00),
	UCoin: ko.observable(0.00),
    // 真人
	LM1: ko.observable(0.00),
    // 電子 (發財金)
	LM2: ko.observable(0.00),
    // 對戰 (幸運金)
	LM3: ko.observable(0.00),
	LMData: ko.observable(),
	CardDeadline: ko.observable(""),	

	TypeToShow: ko.observable("account"),
	TypeToSend: ko.observable("text"),	

	// 保持在線
	keepOnline: function () {
		if (!SGT.Main.QueryFns['Member'].IsLogin()) {
			return;
		}

		$.getJSON(
			"//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/UserKeepOnline.ashx?callback=?",
			function (data) {
			    if (data.Result == "Clear" || data.Result == "NoLogin") {
					SGT.Main.QueryFns['Member'].IsLogin(false);
					location.reload();
				}
			}
		);
	},

	// 登入
	login: function () {
		// 避免自動完成取不到資料，所以加上這段
		var account = $('#id').val();
		var password = $('#password').val();
		if (account != "") {
			SGT.Main.QueryFns['Member'].MemberAccount(account)
		}
		if (password != "") {
			SGT.Main.QueryFns['Member'].MemberPassword(password)
		}
    	
		// 有保持登入的資料則不進行驗證    	
		if (SGT.Main.QueryFns['Member'].Code() == "" && !SGT.Main.QueryFns['Member'].validate()) {
			return;
		}
		//window.onbeforeunload = null;        
		var memberAccount = SGT.Main.QueryFns['Member'].Code() == "" ? RsaEncrypt(SGT.Main.QueryFns['Member'].MemberAccount()) : "";
		var memberPassword = SGT.Main.QueryFns['Member'].Code() == "" ? RsaEncrypt(SGT.Main.QueryFns['Member'].MemberPassword()) : "";
		var isReMember = SGT.Main.QueryFns['Member'].IsRemember();
		var code = SGT.Main.QueryFns['Member'].Code();
        
		$.ajax({
			type: "POST",
			url: "/MVC/api/account/Login",
			async: true,
			data: { "account": memberAccount, "password": memberPassword, "isRemember": isReMember, "code": code },
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 1) {
					SGT.Main.QueryFns['Member'].setKeepLoginCookie(data.Data);
					// setCookie("keepLogin", data.Data, 365);
					location.reload();
				}
				else if (data.ResultCode == 19) {
					if (confirm("此帳號尚有遊戲進行或託管中，您確定要繼續登入，並結束進行中的遊戲嗎?")) {
						SGT.Main.QueryFns['Member'].reLogin();
					}
				}
				else if (data.ResultCode == 98) {
					alert("登入資訊不正確");
				}
				else if (data.ResultCode == 99) {
					alert("伺服器維護中!");
				}
				else if (data.ResultCode == 30) {
				    location.href = "/Mvc";
				}
				else {
				    SGT.Main.QueryFns['Member'].setKeepLoginCookie("");
				    // setCookie("keepLogin", "", -1);
				    alert(data.ResultMsg);
				}
			},
			error: function (e) {
				console.log(e);
				//alert("error:" + e.responseText);
			}
		});
	},

	// 後踢前
	reLogin: function () {
		if (!SGT.Main.QueryFns['Member'].validate()) { return; }

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/ReLogin",
			async: true,
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 1) {
					SGT.Main.QueryFns['Member'].setKeepLoginCookie(data.Data);
					location.reload();
				}
				else if (data.ResultCode == 99) {
					alert("登入失敗");
				}
				else {
					alert(data.ResultMsg);
				}
			},
			error: function (e) {
				console.log(e);
				//alert("error:" + e.responseText);
			}
		});
	},

	// 社群後踢前
	cwReLogin: function () {
		$.ajax({
			type: "POST",
			url: "/MVC/api/account/ReLogin",
			async: true,
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 1) {    				
					location.reload();
				}
				else if (data.ResultCode == 99) {
					alert("登入失敗");
				}
				else {
					alert(data.ResultMsg);
				}
			},
			error: function (e) {
				console.log(e);
				//alert("error:" + e.responseText);
			}
		});
	},

	// 登出
	logout: function () {
		var unloadMsg = '';
		var memFlag = SGT.Member.Info.PermissionFlagID;
                
		var showFlag = 3;
		if((showFlag & memFlag) > 0){
		    unloadMsg = '確定要離開老子有錢嗎？';
		    useunload = true;
		}else {
		    if (!SGT.Member.Info.IsShortcut) {
		        //unloadMsg = '馬上安裝並啟動老子有錢捷徑，送老幣和樂透券哦！';
		        unloadMsg = '確定要離開老子有錢嗎？';
		    } else if (!SGT.Member.Info.IsFavorite && SGT.Member.Info.IsShortcut) {
		        //unloadMsg = '加老子有錢為最愛，從最愛登入可領300點哦！';
		        unloadMsg = '確定要離開老子有錢嗎？';
		    } else if (SGT.Member.Info.IsFavorite && SGT.Member.Info.IsShortcut) {
		        unloadMsg = '確定要離開老子有錢嗎？';
		    }
		}
		//window.onbeforeunload = null;
		confirm(unloadMsg) ? new function () {
			$.ajax({
				type: "POST",
				url: "/MVC/api/account/Logout",
				async: true,
				dataType: "json",
				success: function (data) {
					//SGT.Main.QueryFns['Member'].setKeepLoginCookie("");
					//// setCookie("keepLogin", "", -1);
					//SGT.Main.QueryFns['Member'].IsRemember(false);
					//SGT.Main.QueryFns['Member'].Code("");
					//// location.reload();
					location.href = "/MVC";
				},
				error: function (e) {
					//alert("error:" + e.responseText);
				}
			});
		} : new function () { };

	},

	// 忘記密碼
	forgetPassword: function () {
		// 有保持登入的資料則不進行驗證    	
		if (!SGT.Main.QueryFns['Member'].forgetPasswordValidate()) {
			return;
		}

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/ForgetPassword",
			async: false,
			data: { "account": SGT.Main.QueryFns['Member'].MemberAccount(), "nickName": SGT.Main.QueryFns['Member'].NickName(), "mobile": SGT.Main.QueryFns['Member'].Mobile(), "typeToSend": SGT.Main.QueryFns['Member'].TypeToSend(), "verifyCode": SGT.Main.QueryFns['Member'].VerifyCode() },
			success: function (data) {
				if (data.ResultCode == 0) {
					location.href = "/MVC/Account/NewPasswordSend";
				}
				else {
					alert(data.ResultMsg);
				}
			},
			error: function (e) {
				alert("error:");
			}
		});
	},

	// 清空帳號或暱稱欄位
	clearAccountOrNickName: function () {
		if (SGT.Main.QueryFns['Member'].TypeToShow() == "account") {
			SGT.Main.QueryFns['Member'].NickName("");
		}
		else {
			SGT.Main.QueryFns['Member'].MemberAccount("");
		}
	},

	// 產生新的驗證碼
	newVerifyCode: function () {
		var url = "/AppUserControls/Other/VerifyCode.ashx";		
		SGT.Main.QueryFns['Member'].VerifyCodeUrl(url + "?id=" + Math.floor(Math.random() * 1000000000));		
	},

	// 登入驗證
	validate: function () {
		if (SGT.Main.QueryFns['Member'].MemberAccount().length == 0) {
			alert("請輸入帳號！");
			return false;
		}

		if (SGT.Main.QueryFns['Member'].MemberPassword().length == 0) {
			alert("請輸入密碼！");
			return false;
		}

		return true;
	},

	// 忘記密碼驗證
	forgetPasswordValidate: function () {
		var valFlag = true;

		if (SGT.Main.QueryFns['Member'].MemberAccount() == "" && SGT.Main.QueryFns['Member'].NickName() == "")
		{
			alert("「帳號」、「暱稱」請擇一填寫");
			valFlag = false;
		}
		else if (SGT.Main.QueryFns['Member'].Mobile() == "") {
			alert("請輸入手機號碼");
			valFlag = false;
		}
		else if (SGT.Main.QueryFns['Member'].VerifyCode() == "") {
			alert("請輸入驗證碼");
			valFlag = false;
		}

		return valFlag;
	},

    // 打開其他帳號登入頁面
	openCWLogin: function () {
        if (SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
            return;
        }
        SGT.Global.PopIframeMgr.Add("CWLoginIframe");
        SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/CWLogin");
        SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Center(580, 255);
        SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Show();
        SGT.Global.PopIframeMgr.BodyMaskHide();
    },

	// 打開升級VIP頁面
    openUpgradeVIP: function () {
    	if (SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"]) {
    		return;
    	}
    	SGT.Global.PopIframeMgr.Add("UpgradeVIPIframe");
    	SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"].Load("/MVC/UpgradeVIP/InputMobile");
    	SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"].Center(580, 396);
    	SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"].Show();
    	SGT.Global.PopIframeMgr.BodyMaskHide();
    },

	// 打開忘記密碼頁面
    openForgetPassword: function () {
    	if (SGT.Global.PopIframeMgr.PopIframes["ForgetPasswordIframe"]) {
    		return;
    	}
    	SGT.Global.PopIframeMgr.Add("ForgetPasswordIframe");
    	SGT.Global.PopIframeMgr.PopIframes["ForgetPasswordIframe"].Load("/MVC/Account/ForgetPassword");
    	SGT.Global.PopIframeMgr.PopIframes["ForgetPasswordIframe"].Center(600, 425);
    	SGT.Global.PopIframeMgr.PopIframes["ForgetPasswordIframe"].Show();
    	SGT.Global.PopIframeMgr.BodyMaskHide();
    },

    // 設定保持登入的 cookie
    setKeepLoginCookie: function (data) {
    	// swfobject.getObjectById("FlashCookie").SetCookieData(data);		
    	$.cookie('keepOnline', data, { expires: 30, path: '/' });
    },

    // 取得 cookie 保持登入的資料
    getKeepLoginCookie: function () {
    	//return swfobject.getObjectById("FlashCookie").GetCookieData();
    	return $.cookie('keepOnline');
    },

    // 取得會員點數資訊
    getMemberPoint: function () {
        $.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/AppAjaxs/PlayerPointInfo.ashx?callback=?", function (data) {
            SGT.Main.QueryFns['Member'].HCoin(data.HCoin);
            SGT.Main.QueryFns['Member'].LM1(data.LM1);
            SGT.Main.QueryFns['Member'].LM2(data.LM2);
            SGT.Main.QueryFns['Member'].LM3(data.LM3);
            SGT.Main.QueryFns['Member'].LMData(data.LMData);
        });
    },

	// 取得卡別資訊
    getCardInfo: function () {
    	$.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/GetCardInfo.ashx?callback=?", function (data) {    		
    		SGT.Main.QueryFns['Member'].CardDeadline(data.CardDeadline);    		
    	});
    },

    // 顯示請先登入會員提示
    ShowLoginTips: function () {
        if (SGT.Main.QueryFns['Member'].IsLogin()) {
            return true;
        }
        else {
        	$('#warning_02').show();
        	location.href = "#";
            return false;
        }
    },

	// 顯示請登入新的老子有錢帳號提示
    ShowLoginNewAccountTips: function () {
    	$('#warning_04').show();    	
    	return false;    	
    },

    HideLoginTips: function () {
        $('#warning_02').hide();
        return false;
    }
});

// 發財金總額
SGT.Main.QueryFns['Member'].LMTotal = ko.computed(function () {
    return ((parseInt(parseFloat(SGT.Main.QueryFns['Member'].LM2()) * 100)) / 100).toFixed(2);
}, SGT.Main.QueryFns['Member']);

// 卡別身分
SGT.Main.QueryFns['Member'].CardIdentity = ko.computed(function () {
	var temp = "";
	if (SGT.Main.QueryFns['Member'].VIP_Level() == 1)	{
		temp = "普卡會員";
	}
	else if (SGT.Main.QueryFns['Member'].VIP_Level() == 2) {
		temp = "銀卡會員";
	}
	else if (SGT.Main.QueryFns['Member'].VIP_Level() == 3) {
		temp = "金卡會員";
	}
	else if (SGT.Main.QueryFns['Member'].VIP_Level() == 4) {
		temp = "白金卡會員";
	}
	else {
		temp = "一般會員";
	}
	
	return temp;
}, SGT.Main.QueryFns['Member']);