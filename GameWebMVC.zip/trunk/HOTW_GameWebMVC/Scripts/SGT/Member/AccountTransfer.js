﻿
SGT.Main.Add('AccountTransfer', {
	MemberAccount: ko.observable(""),
	MemberPassword: ko.observable(""),
	PasswordConfirm: ko.observable(""),
	Mobile: ko.observable(""),
	Email: ko.observable(""),
	Agree: ko.observable(false),
	VerificationCode: ko.observable(""),
	IsRemember: ko.observable(false),
	IsAgree: ko.observable(false),

	MemberAccountOK: ko.observable(""),
	MemberPasswordOK: ko.observable(""),
	PasswordConfirmOK: ko.observable(""),
	MobileOK: ko.observable(""),
	EmailOK: ko.observable(""),

	MemberAccountMsg: ko.observable(""),
	MemberPasswordMsg: ko.observable("密碼必須是 6 ~ 12 碼的英文數字組合<br />密碼範例：hi0857"),
	PasswordConfirmMsg: ko.observable(""),
	MobileMsg: ko.observable(""),
	MobileMsg2: ko.observable(""),
	EmailMsg: ko.observable(""),
	AgreeMsg: ko.observable(""),
	VerificationCodeMsg: ko.observable(""),
	TotalMsg: ko.observable(""),

	ResetButtonEnable: ko.observable(true),
	RegisterButtonEnable: ko.observable(true),
	MobileAuthenticationButtonEnable: ko.observable(true),
	ReSendVerificationCodeButtonEnable: ko.observable(true),
	CancelConfirmMobileAuthenticationButtonEnable: ko.observable(true),
	CancelMobileAuthenticationButtonEnable: ko.observable(true),
	ReturnMobileAuthenticationButtonEnable: ko.observable(true),

	// 啟用/禁用 按鈕
	enableButton: function (enable) {
		SGT.Main.QueryFns['AccountTransfer'].ResetButtonEnable(enable);
		SGT.Main.QueryFns['AccountTransfer'].RegisterButtonEnable(enable);
		SGT.Main.QueryFns['AccountTransfer'].MobileAuthenticationButtonEnable(enable);
		SGT.Main.QueryFns['AccountTransfer'].ReSendVerificationCodeButtonEnable(enable);
		SGT.Main.QueryFns['AccountTransfer'].CancelConfirmMobileAuthenticationButtonEnable(enable);
		SGT.Main.QueryFns['AccountTransfer'].CancelMobileAuthenticationButtonEnable(enable);
		SGT.Main.QueryFns['AccountTransfer'].ReturnMobileAuthenticationButtonEnable(enable);		
	},

	// 註冊(帳號轉移)
	register: function () {
	    
		if (!SGT.Main.QueryFns['AccountTransfer'].accountValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].passwordValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].passwordConfirmValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].mobileValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].emailValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].agreeValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].otherValidate
			) {			
			return;
		}

		var memberAccount = SGT.Main.QueryFns['AccountTransfer'].MemberAccount();
		var memberPassword = SGT.Main.QueryFns['AccountTransfer'].MemberPassword();
		var mobile = SGT.Main.QueryFns['AccountTransfer'].Mobile();
		var email = SGT.Main.QueryFns['AccountTransfer'].Email();

		var registerModel = { "MemberAccount": memberAccount, "MemberPassword": memberPassword, "Mobile": mobile, "Email": email };

		// 禁用按鈕
		SGT.Main.QueryFns['AccountTransfer'].enableButton(false);		

		$.ajax({
			type: "POST",
			url: "/MVC/api/accounttransfer/ATRegister",
			async: true,
			data: registerModel,
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0 && mobile != "") {
					SGT.Main.QueryFns['AccountTransfer'].openMobileAuthentication();
				}
				else if (data.ResultCode == 0 && mobile == "") {
					SGT.Main.QueryFns['AccountTransfer'].logoutWithLogin();					
				}
				else if (data.ResultCode == 6) {
					alert("帳號已轉換");
					Close();
				}
				else {
					alert(data.ResultMsg);
				}

				if (data.ResultCode != 0) {
					// 啟用按鈕					
					SGT.Main.QueryFns['AccountTransfer'].enableButton(true);					
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['AccountTransfer'].enableButton(true);				
			},
			complete: function () {

			}
		});
	},

	// 手機認證
	mobileAuthentication: function () {
		if (!SGT.Main.QueryFns['AccountTransfer'].verificationCodeValidate()) {
			return;
		}
		
		var verificationCode = SGT.Main.QueryFns['AccountTransfer'].VerificationCode();

		// 禁用按鈕
		SGT.Main.QueryFns['AccountTransfer'].enableButton(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/accounttransfer/ATMobileAuthentication",
			async: true,
			data: { "verificationCode": verificationCode },
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {					
					alert("驗證碼正確! 恭喜您帳號啟用成功!");
					SGT.Main.QueryFns['AccountTransfer'].logoutWithLogin();	
				}
				else if (data.ResultCode == 2) {
					alert("驗證碼逾時");
				}
				else if (data.ResultCode == 3) {
					SGT.Main.QueryFns['AccountTransfer'].openMobileAuthenticationFrequently();					
				}
				else if (data.ResultCode == 4) {
					alert("您使用的帳號已被使用");
				}
				else if (data.ResultCode == 5) {
					alert("您使用的E-mail信箱已被使用");
				}				
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");
				}
				else {
					alert("驗證碼錯誤!");
					// alert(data.ResultMsg);
				}

				if (data.ResultCode != 0) {
					// 啟用按鈕
					SGT.Main.QueryFns['AccountTransfer'].enableButton(true);
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['AccountTransfer'].enableButton(true);
			},
			complete: function () {

			}
		});
	},

	// 重新發送手機驗證碼
	reSendVerificationCode: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['AccountTransfer'].enableButton(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/ReSendVerificationCode",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {
					SGT.Main.QueryFns['AccountTransfer'].VerificationCode(data.Data);
					alert("簡訊已送出，請注意您的手機並請儘速啟用帳號。");
				}
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");
				}
				else {
					SGT.Main.QueryFns['AccountTransfer'].openMobileAuthenticationFrequently();
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
			},
			complete: function () {
				// 啟用按鈕
				SGT.Main.QueryFns['AccountTransfer'].enableButton(true);
			}
		});
	},

	// 登入
	login: function () {
		$.ajax({
			type: "POST",
			url: "/MVC/api/accounttransfer/Login",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 1) {
					var flag = (data.Data == "true");
					SGT.Main.QueryFns['AccountTransfer'].openTransferFinish(flag);
				}
				else if (data.ResultCode == 98) {
					alert("登入資訊不正確");
				}
				else if (data.ResultCode == 99) {
					alert("伺服器維護中!");
				}
				else {								
					alert(data.ResultMsg);
				}
			},
			error: function (e) {
				console.log(e);
				//alert("error:" + e.responseText);
			}
		});
	},

	// 登出並登入
	logoutWithLogin: function () {
		var flag = SGT.WebSiteInfo.IsHCoin;

		$.ajax({
			type: "POST",
			url: "/MVC/api/accounttransfer/LogoutWithLogin",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 1) {					
					SGT.Main.QueryFns['AccountTransfer'].openTransferFinish(flag);
				}
				else if (data.ResultCode == 98) {
					alert("登入資訊不正確");
				}
				else if (data.ResultCode == 99) {
					alert("伺服器維護中!");
				}
				else {
					alert(data.ResultMsg);
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
			}
		});
	},

	// 設定保持登入 cookie
	setKeepLoginCookie: function () {
		SGT.Main.QueryFns['AccountTransfer'].IsRemember(!SGT.Main.QueryFns['AccountTransfer'].IsRemember());

		var isRemember = SGT.Main.QueryFns['AccountTransfer'].IsRemember();

		$.ajax({
			type: "POST",
			url: "/MVC/api/accounttransfer/SetKeepLoginCookie",
			async: true,
			data: { "isRemember": isRemember },
			dataType: "json",
			success: function (data) {				
				$.cookie('keepOnline', data.Data, { expires: 30, path: '/' });
			},
			error: function (e) {
				alert("error:" + e.responseText);
			},
			complete: function () {

			}
		});
	},

	// 帳號轉移(錯過期)
	registerThird: function() {
		if (!SGT.Main.QueryFns['AccountTransfer'].accountValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].passwordValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].passwordConfirmValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].mobileValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].emailValidate() ||
			// !SGT.Main.QueryFns['AccountTransfer'].agreeValidate() ||
			!SGT.Main.QueryFns['AccountTransfer'].otherValidate()
			) {
			return;
		}

		var memberAccount = SGT.Main.QueryFns['AccountTransfer'].MemberAccount();
		var memberPassword = SGT.Main.QueryFns['AccountTransfer'].MemberPassword();
		var mobile = SGT.Main.QueryFns['AccountTransfer'].Mobile();
		var email = SGT.Main.QueryFns['AccountTransfer'].Email();

		var registerModel = { "MemberAccount": memberAccount, "MemberPassword": memberPassword, "Mobile": mobile, "Email": email };

		// 禁用按鈕
		SGT.Main.QueryFns['AccountTransfer'].enableButton(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/accounttransfer/ATRegisterThird",
			async: true,
			data: registerModel,
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {
					SGT.Main.QueryFns['AccountTransfer'].openMobileAuthentication();
				}
				else {
					alert(data.ResultMsg);
				}

				if (data.ResultCode != 0) {
					// 啟用按鈕					
					SGT.Main.QueryFns['AccountTransfer'].enableButton(true);
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['AccountTransfer'].enableButton(true);
			},
			complete: function () {

			}
		});
	},

	// 帳號驗證
	accountValidate: function () {
		// 初始化訊息
		SGT.Main.QueryFns['AccountTransfer'].MemberAccountOK("");
		SGT.Main.QueryFns['AccountTransfer'].MemberAccountMsg("");

		var valFlag = true;

		if (SGT.Main.QueryFns['AccountTransfer'].MemberAccount() == "") {
			SGT.Main.QueryFns['AccountTransfer'].MemberAccountMsg("帳號不可空白");
			valFlag = false;
		}
		else if (!SGT.Main.QueryFns['AccountTransfer'].MemberAccount().match(/^[0-9a-zA-Z]{6,12}$/)) {
			SGT.Main.QueryFns['AccountTransfer'].MemberAccountMsg("帳號必須是 6 ~ 12 碼的英文數字組合");
			valFlag = false;
		}
		else if (!SGT.Main.QueryFns['AccountTransfer'].MemberAccount().match(/(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$/)) {
			SGT.Main.QueryFns['AccountTransfer'].MemberAccountMsg("帳號至少須包含一個英文字母");
			valFlag = false;
		}
		else if ((SGT.Main.QueryFns['AccountTransfer'].MemberAccount().indexOf(SGT.Main.QueryFns['AccountTransfer'].MemberPassword()) > -1 && SGT.Main.QueryFns['AccountTransfer'].MemberPassword() != "") ||
				 (SGT.Main.QueryFns['AccountTransfer'].MemberAccount().indexOf(SGT.Main.QueryFns['AccountTransfer'].Mobile()) > -1 && SGT.Main.QueryFns['AccountTransfer'].Mobile() != "")) {
			SGT.Main.QueryFns['AccountTransfer'].MemberAccountMsg("帳號中不可包含密碼或手機號碼");
			valFlag = false;
		}
		else {
			$.ajax({
				type: "POST",
				url: "/AppAjaxs/RegisterValidation.ashx",
				async: false,
				data: "CheckType=1&CheckData=" + SGT.Main.QueryFns['AccountTransfer'].MemberAccount(),
				success: function (data) {
					if (data != "此帳號已有人使用") {
						SGT.Main.QueryFns['AccountTransfer'].MemberAccountOK(data);						
						valFlag = true;
					}
					else {
						SGT.Main.QueryFns['AccountTransfer'].MemberAccountMsg(data);
						valFlag = false;
					}
				},
				error: function (e) {
					valFlag = false;
					//alert(e.responseText);
				}
			});
		}

		return valFlag;
	},

	// 密碼驗證
	passwordValidate: function () {
		// 初始化訊息
		SGT.Main.QueryFns['AccountTransfer'].MemberPasswordOK("");
		SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg("");

		var passwdBar = document.getElementById('passwdBar');
		if (passwdBar != null) {
			ResetBar();
		}

		if (SGT.Main.QueryFns['AccountTransfer'].MemberPassword() == "") {
			SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg("密碼不可空白<br />密碼範例：hi0857");
			return false;
		}

		if (!SGT.Main.QueryFns['AccountTransfer'].MemberPassword().match(/^[0-9a-zA-Z]{6,12}$/)) {
			SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg("密碼必須是 6 ~ 12 碼的英文數字組合<br />密碼範例：hi0857");
			return false;
		}

		if (SGT.Main.QueryFns['AccountTransfer'].MemberPassword().match(/^[0-9]{6,12}$/)) {
			SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg("密碼至少須包含一個英文字母<br />密碼範例：hi0857");
			return false;
		}

		// 驗證密碼是否含四種不同字元以上
		var CompareString = '';
		for (i = 0; i < SGT.Main.QueryFns['AccountTransfer'].MemberPassword().length; i++) {
			if (CompareString.indexOf(SGT.Main.QueryFns['AccountTransfer'].MemberPassword().charAt(i)) == -1) {
				CompareString += SGT.Main.QueryFns['AccountTransfer'].MemberPassword().charAt(i);
			}
		}
		if (CompareString.length < 4) {
			SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg("密碼必須包含4種(含)字元以上<br />密碼範例：hi0857");
			return false;
		}

		if ((SGT.Main.QueryFns['AccountTransfer'].MemberPassword().indexOf(SGT.Main.QueryFns['AccountTransfer'].MemberAccount()) > -1 && SGT.Main.QueryFns['AccountTransfer'].MemberAccount() != "") ||
			(SGT.Main.QueryFns['AccountTransfer'].MemberPassword().indexOf(SGT.Main.QueryFns['AccountTransfer'].Mobile()) > -1 && SGT.Main.QueryFns['AccountTransfer'].Mobile() != "")) {
			SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg("密碼中不可包含帳號或手機號碼<br />密碼範例：hi0857");
			return false;
		}

		var sPW = SGT.Main.QueryFns['AccountTransfer'].MemberPassword().toLowerCase();
		for (i = 0; i < sPW.length; i++) {
			// 判斷是否輸入3個連續數字或字母
			var code = sPW.charCodeAt(i);
			var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
			var code2 = '' + code + (code + 1) + (code + 2);
			var code3 = '' + code + (code - 1) + (code - 2);
			if (sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
				SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg("密碼不可為連續數字或字母<br />密碼範例：hi0857");
				return false;
			}
		}

		if (passwdBar != null) {
			var ctl = document.getElementById("password");
			CreateRatePasswdReq(ctl);
		}

		SGT.Main.QueryFns['AccountTransfer'].MemberPasswordOK('<img src="' + SGT.WebSiteInfo.Urls.CdnUrl + '/Html/Images/Layout/main_content/member/yes.jpg">');
		SGT.Main.QueryFns['AccountTransfer'].MemberPasswordMsg('<br /><br />');
		return true;
	},

	// 密碼確認驗證
	passwordConfirmValidate: function () {
		// 初始化訊息
		SGT.Main.QueryFns['AccountTransfer'].PasswordConfirmOK("");
		SGT.Main.QueryFns['AccountTransfer'].PasswordConfirmMsg("");

		if (SGT.Main.QueryFns['AccountTransfer'].PasswordConfirm() == "") {
			SGT.Main.QueryFns['AccountTransfer'].PasswordConfirmMsg("確認密碼不可空白");
			return false;
		}

		if (SGT.Main.QueryFns['AccountTransfer'].MemberPassword() != SGT.Main.QueryFns['AccountTransfer'].PasswordConfirm()) {
			SGT.Main.QueryFns['AccountTransfer'].PasswordConfirmMsg("兩次密碼錯誤");
			return false;
		}

		SGT.Main.QueryFns['AccountTransfer'].PasswordConfirmOK('<img src="' + SGT.WebSiteInfo.Urls.CdnUrl + '/Html/Images/Layout/main_content/member/yes.jpg">');
		return true;
	},

	// 手機驗證
	mobileValidate: function () {
		// 初始化訊息
		SGT.Main.QueryFns['AccountTransfer'].MobileOK("");
		SGT.Main.QueryFns['AccountTransfer'].MobileMsg("");
		SGT.Main.QueryFns['AccountTransfer'].MobileMsg2("");

		var valFlag = true;

		if (SGT.WebSiteInfo.IsHCoin) {
			valFlag = true;
			return valFlag;
		}

		if (SGT.Main.QueryFns['AccountTransfer'].Mobile() == "") {
		    SGT.Main.QueryFns['AccountTransfer'].MobileMsg("手機號碼不可空白");
		    SGT.Main.QueryFns['AccountTransfer'].MobileMsg2("請填寫手機保護您資料安全及使用權利");
			return false;
		}

		if (SGT.Main.QueryFns['AccountTransfer'].Mobile() != "") {
			if (!SGT.Main.QueryFns['AccountTransfer'].Mobile().match(/^[09]{2}[0-9]{8}$/)) {
				SGT.Main.QueryFns['AccountTransfer'].MobileMsg("手機號碼格式錯誤");
				valFlag = false;
			}
			else if ((SGT.Main.QueryFns['AccountTransfer'].Mobile().indexOf(SGT.Main.QueryFns['AccountTransfer'].MemberAccount()) > -1 && SGT.Main.QueryFns['AccountTransfer'].MemberAccount() != "") ||
				(SGT.Main.QueryFns['AccountTransfer'].Mobile().indexOf(SGT.Main.QueryFns['AccountTransfer'].MemberPassword()) > -1 && SGT.Main.QueryFns['AccountTransfer'].MemberPassword() != "")) {
				SGT.Main.QueryFns['AccountTransfer'].MobileMsg("手機中不可包含密碼或手機號碼");
				valFlag = false;
			}
			else {
				$.ajax({
					type: "POST",
					url: "/AppAjaxs/RegisterValidation.ashx",
					async: false,
					data: "CheckType=3&CheckData=" + SGT.Main.QueryFns['AccountTransfer'].Mobile(),
					success: function (data) {
					    if (data.substr(0, 4) == '<img') {
							SGT.Main.QueryFns['AccountTransfer'].MobileOK(data);
							valFlag = true;
						}
						else {
							SGT.Main.QueryFns['AccountTransfer'].MobileMsg(data);							
							valFlag = false;
						}
					},
					error: function (e) {
						valFlag = false;
					}
				});
			}
		}		

		return valFlag;
	},

	// 手機驗證(找社群帳號)
	mobileValidateFindAccount: function () {
		// 初始化訊息
		SGT.Main.QueryFns['AccountTransfer'].MobileMsg("");

		var valFlag = true;

		if (SGT.Main.QueryFns['AccountTransfer'].Mobile() == "") {
			SGT.Main.QueryFns['AccountTransfer'].MobileMsg("手機號碼不可空白");
			return false;
		}

		if (SGT.Main.QueryFns['AccountTransfer'].Mobile() != "") {
			if (!SGT.Main.QueryFns['AccountTransfer'].Mobile().match(/^[09]{2}[0-9]{8}$/)) {
				SGT.Main.QueryFns['AccountTransfer'].MobileMsg("手機號碼格式錯誤");
				valFlag = false;
			}
			else {
				
			}			
		}

		return valFlag;
	},

	// Email 驗證
	emailValidate: function () {
		// 初始化訊息
		SGT.Main.QueryFns['AccountTransfer'].EmailOK("");
		SGT.Main.QueryFns['AccountTransfer'].EmailMsg("");

		var valFlag = true;

		//if (SGT.Main.QueryFns['AccountTransfer'].Email() == "") {
		//	SGT.Main.QueryFns['AccountTransfer'].EmailMsg("Email不可空白");
		//	return false;
		//}

		if (SGT.Main.QueryFns['AccountTransfer'].Email() != "") {
			if (!SGT.Main.QueryFns['AccountTransfer'].Email().match(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/)) {
				SGT.Main.QueryFns['AccountTransfer'].EmailMsg("電子信箱格式錯誤");
				valFlag = false;
			}
			else {
				$.ajax({
					type: "POST",
					url: "/AppAjaxs/RegisterValidation.ashx",
					async: false,
					data: "CheckType=8&CheckData=" + SGT.Main.QueryFns['AccountTransfer'].Email(),
					success: function (data) {
						if (data != "此電子信箱已被使用") {
							SGT.Main.QueryFns['AccountTransfer'].EmailOK(data);
							valFlag = true;
						}
						else {
							SGT.Main.QueryFns['AccountTransfer'].EmailMsg(data);
							valFlag = false;
						}
					},
					error: function (e) {
						valFlag = false;
					}
				});
			}
		}

		return valFlag;
	},

	// 驗證碼驗證
	verificationCodeValidate: function () {
		if (SGT.Main.QueryFns['AccountTransfer'].VerificationCode() == "") {
			alert("驗證碼不可空白！");
			// SGT.Main.QueryFns['AccountTransfer'].VerificationCodeMsg("驗證碼不可空白！");
			return false;
		}

		return true;
	},

	// 其他驗證
	otherValidate: function () {
		var valFlag = true;

		if (SGT.WebSiteInfo.IsHCoin) {
			valFlag = true;
			return valFlag;
		}

		if (SGT.Main.QueryFns['AccountTransfer'].Mobile() == "") {
			SGT.Main.QueryFns['AccountTransfer'].MobileMsg2("請填寫手機保護您資料安全及使用權利");
			valFlag = false;
		}

		return valFlag;
	},

    // 勾選我同意驗證
	agreeValidate: function () {
	    var valFlag = true;

	    if (!SGT.Main.QueryFns['AccountTransfer'].IsAgree()) {
	        SGT.Main.QueryFns['AccountTransfer'].AgreeMsg('須同意服務條款');
	        valFlag = false;
        }

	    return valFlag;
	},

	// 打開轉移帳號頁面
	openRegister: function () {
		if (SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"]) {
			return;
		}
				
		SGT.Global.PopIframeMgr.Add("AccountTransferIframe");
		SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"].Load("/MVC/AccountTransfer/Register");
		SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"].Center(502, 402);
		SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"].Show();
		SGT.Global.PopIframeMgr.BodyMaskHide();
	},
	
	// 打開手機驗證頁面
	openMobileAuthentication: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/AccountTransfer/MobileAuthentication" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	// 打開手機驗證頻繁頁面
	openMobileAuthenticationFrequently: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/AccountTransfer/MobileAuthenticationFrequently" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	// 打開驗證成功頁面
	openMobileAuthenticationSuccess: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/AccountTransfer/MobileAuthenticationSuccess" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	// 打開驗證失敗頁面
	openMobileAuthenticationFail: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/AccountTransfer/MobileAuthenticationFail" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	// 打開登入頁面(已轉移)
	openLogin: function () {
		if (SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"]) {
			return;
		}

		SGT.Global.PopIframeMgr.Add("AccountTransferIframe");
		SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"].Load("/MVC/AccountTransfer/Login");
		SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"].Center(580, 396);
		SGT.Global.PopIframeMgr.PopIframes["AccountTransferIframe"].Show();
		SGT.Global.PopIframeMgr.BodyMaskHide();		
	},

	// 打開社群帳號登入頁面
	openCWLogin: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/AccountTransfer/CWLogin" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	// 打開轉移成功頁面
	openTransferFinish: function (hasMobile) {
		var urlParam = "";
		var isGameMenu = getParameter("IsGameMenu") == "1";
		urlParam += (isGameMenu ? "&isGameMenu=1" : "");
		urlParam += (hasMobile ? "?hasMobile=1" : "");
		urlParam = urlParam != "" ? ("?" + urlParam.substring(1)) : "";

		location.href = "/MVC/AccountTransfer/TransferFinish" + urlParam;
	}
});