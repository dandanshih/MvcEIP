declare var $;
declare var SGT;
declare var swfobject;

module SGT.Member {

    // �y�z��@���ʪ����c
    class EventFlag {
        // Flag
        Flag: number;
        // �O�_�ҥ�
        IsEnable: bool;
        // iframe ���|
        DataUrl: string;
        // iframe �e��
        IframeWidth: number;
        // iframe ����
        IframeHeight: number;
        // ���J iframe ���������ƥ�
        OnIFrameLoadComplete(ifrm): void { }
    }

    // ���ʶ��X
    export class FnActivity {
        
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {
            var obj: EventFlag;
            
            // ���d�p����
            obj = new EventFlag();
            obj.Flag = 1;
            obj.IsEnable = true;
            obj.DataUrl = '/Mvc/Htmls/Shared/LoginActivity.html';
            obj.IframeWidth = 800;
            obj.IframeHeight = 572;
            obj.OnIFrameLoadComplete = function (ifrm) {
                var ifrmWindow = ifrm.contentWindow;
                var newDiv = ifrmWindow.document.createElement("div");
                newDiv.id = 'fl_Activity';
                ifrmWindow.document.body.appendChild(newDiv);

                $.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/GetMarioPlatinum.ashx?callback=?", { Data: 1 },function (data) {
                    if (data && data.SysTime) {
                        ifrmWindow.swfobject.embedSWF(
                            SGT.WebSiteInfo.Urls.CdnUrl + data.SwfName,
                            'fl_Activity',
                            '800px',
                            '572px',
                            '10',
                            '/Scripts/expressInstall.swf',
                            { ActDate: data.SysTime },
                            { wmode: "transparent", allowScriptAccess: "always" },
                            {}
                        );
                    }
                });
            }
            this.LoginEventFlag.push(obj);

            // �ժ��d�p����
            obj = new EventFlag();
            obj.Flag = 2;
            obj.IsEnable = true;
            obj.DataUrl = '/Mvc/Htmls/Shared/LoginActivity.html';
            obj.IframeWidth = 800;
            obj.IframeHeight = 572;
            obj.OnIFrameLoadComplete = function (ifrm) {
                var ifrmWindow = ifrm.contentWindow;
                var newDiv = ifrmWindow.document.createElement("div");
                newDiv.id = 'fl_Activity';
                ifrmWindow.document.body.appendChild(newDiv);

                $.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/GetMarioPlatinum.ashx?callback=?", { Data: 2 }, function (data) {
                    if (data && data.SysTime) {
                        ifrmWindow.swfobject.embedSWF(
                            SGT.WebSiteInfo.Urls.CdnUrl + data.SwfName,
                            'fl_Activity',
                            '800px',
                            '572px',
                            '10',
                            '/Scripts/expressInstall.swf',
                            { ActDate: data.SysTime },
                            { wmode: "transparent", allowScriptAccess: "always" },
                            {}
                        );
                    }
                });
            }
            this.LoginEventFlag.push(obj);

            // ���d�|�����
            obj = new EventFlag();
            obj.Flag = 4;
            obj.IsEnable = true;
            obj.DataUrl = '/Mvc/Htmls/Shared/Card3.html';
            obj.IframeWidth = 600;
            obj.IframeHeight = 423;
            this.LoginEventFlag.push(obj);

            // �ժ��d�|�����
            obj = new EventFlag();
            obj.Flag = 8;
            obj.IsEnable = true;
            obj.DataUrl = '/Mvc/Htmls/Shared/Card4.html';
            obj.IframeWidth = 600;
            obj.IframeHeight = 423;
            this.LoginEventFlag.push(obj);
            
            // �]�뺿�� 500
            obj = new EventFlag();
            obj.Flag = 2048;
            obj.IsEnable = true;
            obj.DataUrl = '/Mvc/Htmls/Shared/LoginActivity.html';
            obj.IframeWidth = 800;
            obj.IframeHeight = 572;
            obj.OnIFrameLoadComplete = function (ifrm) {
                var ifrmWindow = ifrm.contentWindow;
                var newDiv = ifrmWindow.document.createElement("div");
                newDiv.id = 'fl_Activity';
                ifrmWindow.document.body.appendChild(newDiv);

                $.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/GetMarioPlatinum.ashx?callback=?", { Data: 2048 }, function (data) {
                    if (data && data.SysTime) {
                        ifrmWindow.swfobject.embedSWF(
                            SGT.WebSiteInfo.Urls.CdnUrl + data.SwfName,
                            'fl_Activity',
                            '800px',
                            '572px',
                            '10',
                            '/Scripts/expressInstall.swf',
                            { ActDate: data.SysTime },
                            { wmode: "transparent", allowScriptAccess: "always" },
                            {}
                        );
                    }
                });
            }
            this.LoginEventFlag.push(obj);
            
            // �]�뺿�� 2000
            obj = new EventFlag();
            obj.Flag = 4096;
            obj.IsEnable = true;
            obj.DataUrl = '/Mvc/Htmls/Shared/LoginActivity.html';
            obj.IframeWidth = 800;
            obj.IframeHeight = 572;
            obj.OnIFrameLoadComplete = function (ifrm) {
                var ifrmWindow = ifrm.contentWindow;
                var newDiv = ifrmWindow.document.createElement("div");
                newDiv.id = 'fl_Activity';
                ifrmWindow.document.body.appendChild(newDiv);

                $.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/GetMarioPlatinum.ashx?callback=?", { Data: 4096 }, function (data) {
                    if (data && data.SysTime) {
                        ifrmWindow.swfobject.embedSWF(
                            SGT.WebSiteInfo.Urls.CdnUrl + data.SwfName,
                            'fl_Activity',
                            '800px',
                            '572px',
                            '10',
                            '/Scripts/expressInstall.swf',
                            { ActDate: data.SysTime },
                            { wmode: "transparent", allowScriptAccess: "always" },
                            {}
                        );
                    }
                });
            }
            this.LoginEventFlag.push(obj);
        }
        
        /// --------------------------------------
        /// property
        /// --------------------------------------
        PopIframeName: string = "LoginActivity";
        Flags: number = 0;
        LoginEventFlag = [];
        
        /// --------------------------------------
        /// function
        /// --------------------------------------
        Init(flag: number): void {
            this.Flags = flag;
            this.Next();
        }

        Next(): void {
            var self = this;
            var NowFlag = this.Flags;
            if (SGT.Global.PopIframeMgr.PopIframes[this.PopIframeName] != undefined) {
                SGT.Global.PopIframeMgr.Remove(this.PopIframeName);
            }
            
            $.each(this.LoginEventFlag, function (idx, obj) {
                if (obj.IsEnable && (NowFlag & obj.Flag) == obj.Flag) {

                    SGT.Global.PopIframeMgr.Add(self.PopIframeName);
                    SGT.Global.PopIframeMgr.PopIframes[self.PopIframeName].SetScrollBar(false);
                    SGT.Global.PopIframeMgr.PopIframes[self.PopIframeName].Load(obj.DataUrl, obj.OnIFrameLoadComplete);
                    SGT.Global.PopIframeMgr.PopIframes[self.PopIframeName].Center(obj.IframeWidth, obj.IframeHeight);
                    SGT.Global.PopIframeMgr.PopIframes[self.PopIframeName].Show();
                    SGT.Global.PopIframeMgr.BodyMaskHide();
                    self.UpdateFlag(obj.Flag);
                    return false;
                }
            });
        }

        UpdateFlag(flag: number): void {
            if ((this.Flags & flag) > 0) {
                this.Flags = this.Flags ^ flag;
            }
        }

        ClearFlag(flag: number): void {
            $.ajax({
    		    type: "POST",
    		    url: "/MVC/api/account/ClearFlag",
    		    async: true,
    		    data: { "flag": flag },
    		    dataType: "json",
    		    success: function (data) {
    			
    		    },
    		    error: function (e) {    			
    			    // alert("error:" + e.responseText);
    		    }
    	    });
        }
    }
}