﻿
SGT.Main.Add('UpgradeVIP', {
	Mobile: ko.observable(""),
	VerificationCode: ko.observable(""),

	MobileMsg: ko.observable(""),
	VerificationCodeMsg: ko.observable(""),

	ResetButtonEnable: ko.observable(true),
	InputMobileButtonEnable: ko.observable(true),
	MobileAuthenticationButtonEnable: ko.observable(true),
	ReSendVerificationCodeButtonEnable: ko.observable(true),
	CancelConfirmMobileAuthenticationButtonEnable: ko.observable(true),
	CancelMobileAuthenticationButtonEnable: ko.observable(true),
	ReturnMobileAuthenticationButtonEnable: ko.observable(true),

	// 啟用/禁用 按鈕
	enableButton: function (enable) {
		SGT.Main.QueryFns['UpgradeVIP'].ResetButtonEnable(enable);
		SGT.Main.QueryFns['UpgradeVIP'].InputMobileButtonEnable(enable);
		SGT.Main.QueryFns['UpgradeVIP'].MobileAuthenticationButtonEnable(enable);
		SGT.Main.QueryFns['UpgradeVIP'].ReSendVerificationCodeButtonEnable(enable);
		SGT.Main.QueryFns['UpgradeVIP'].CancelConfirmMobileAuthenticationButtonEnable(enable);
		SGT.Main.QueryFns['UpgradeVIP'].CancelMobileAuthenticationButtonEnable(enable);
		SGT.Main.QueryFns['UpgradeVIP'].ReturnMobileAuthenticationButtonEnable(enable);
	},

	// 資料重設
	reset: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].ResetButtonEnable(false);
		SGT.Main.QueryFns['UpgradeVIP'].InputMobileButtonEnable(false);
		SGT.Main.QueryFns['UpgradeVIP'].MobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['UpgradeVIP'].ReSendVerificationCodeButtonEnable(false);
		SGT.Main.QueryFns['UpgradeVIP'].CancelConfirmMobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['UpgradeVIP'].CancelMobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['UpgradeVIP'].ReturnMobileAuthenticationButtonEnable(false);
				
		SGT.Main.QueryFns['UpgradeVIP'].Mobile("");
		SGT.Main.QueryFns['UpgradeVIP'].VerificationCode("");

		SGT.Main.QueryFns['UpgradeVIP'].MobileMsg("");
		SGT.Main.QueryFns['UpgradeVIP'].VerificationCodeMsg("");

		// 啟用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].ResetButtonEnable(true);
		SGT.Main.QueryFns['UpgradeVIP'].InputMobileButtonEnable(true);
		SGT.Main.QueryFns['UpgradeVIP'].MobileAuthenticationButtonEnable(true);
		SGT.Main.QueryFns['UpgradeVIP'].ReSendVerificationCodeButtonEnable(true);
		SGT.Main.QueryFns['UpgradeVIP'].CancelConfirmMobileAuthenticationButtonEnable(true);
		SGT.Main.QueryFns['UpgradeVIP'].CancelMobileAuthenticationButtonEnable(true);
		SGT.Main.QueryFns['UpgradeVIP'].ReturnMobileAuthenticationButtonEnable(true);
	},

	// 輸入手機
	inputMobile: function () {		
		if (!SGT.Main.QueryFns['UpgradeVIP'].mobileValidate()) {
			return;
		}
		
		var mobile = SGT.Main.QueryFns['UpgradeVIP'].Mobile();

		// 禁用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].enableButton(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/upgradevip/inputMobile",
			async: true,
			data: { "mobile": mobile },
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 10) {					
					SGT.Main.QueryFns['UpgradeVIP'].openMobileAuthentication();
				}
				else if (data.ResultCode == 99) {
					alert("未登入");
				}
				else {
					alert(data.ResultMsg);
				}

				if (data.ResultCode != 10) {
					// 啟用按鈕
					SGT.Main.QueryFns['UpgradeVIP'].enableButton(true);
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['UpgradeVIP'].enableButton(true);
			},
			complete: function () {

			}
		});
	},

	// 手機認證
	mobileAuthentication: function () {
		if (!SGT.Main.QueryFns['UpgradeVIP'].verificationCodeValidate()) {
			return;
		}

		var verificationCode = SGT.Main.QueryFns['UpgradeVIP'].VerificationCode();

		// 禁用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].enableButton(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/MobileAuthentication",
			async: true,
			data: { "verificationCode": verificationCode },
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {										
					alert("驗證碼正確! 恭喜您帳號啟用成功!");
					SGT.Main.QueryFns['UpgradeVIP'].logoutWithLogin();					
				}
				else if (data.ResultCode == 2) {
					alert("驗證碼逾時");
				}
				else if (data.ResultCode == 3) {
					SGT.Main.QueryFns['UpgradeVIP'].openMobileAuthenticationFrequently();					
				}
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");
				}
				else {
					alert("驗證碼錯誤!");
					// alert(data.ResultMsg);
				}

				if (data.ResultCode != 0) {
					// 啟用按鈕
					SGT.Main.QueryFns['UpgradeVIP'].enableButton(true);
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['UpgradeVIP'].enableButton(true);
			},
			complete: function () {

			}
		});
	},

	// 重新發送手機驗證碼
	reSendVerificationCode: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].enableButton(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/ReSendVerificationCode",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {
					SGT.Main.QueryFns["UpgradeVIP"].VerificationCode(data.Data);
					alert("簡訊已送出，請注意您的手機並請儘速啟用帳號。");
				}
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");
				}
				else {
					SGT.Main.QueryFns['UpgradeVIP'].openMobileAuthenticationFrequently();
					// alert(data.ResultMsg);					
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
			},
			complete: function () {
				// 啟用按鈕
				SGT.Main.QueryFns['UpgradeVIP'].enableButton(true);
			}
		});
	},

	// 確認取消手機驗證
	cancelConfirmMobileAuthentication: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].enableButton(false);

		SGT.Main.QueryFns['UpgradeVIP'].openCancelMobileAuthentication();		
	},

	// 取消手機驗證
	cancelMobileAuthentication: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].enableButton(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/CancelMobileAuthentication",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {
					SGT.Main.QueryFns['UpgradeVIP'].close();
				}
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");					
				}
				else {
					alert(data.ResultMsg);
				}

				if (data.ResultCode != 0) {
					// 啟用按鈕
					SGT.Main.QueryFns['UpgradeVIP'].enableButton(true);
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['UpgradeVIP'].enableButton(true);
			},
			complete: function () {

			}
		});
	},

	// 返回手機驗證
	returnMobileAuthentication: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['UpgradeVIP'].enableButton(false);		

		SGT.Main.QueryFns['UpgradeVIP'].openMobileAuthentication();		
	},
		
	// 登出並登入
	logoutWithLogin: function () {
		var flag = SGT.WebSiteInfo.IsHCoin;

		$.ajax({
			type: "POST",
			url: "/MVC/api/upgradevip/LogoutWithLogin",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 1) {
					top.location.reload();
					// SGT.Main.QueryFns['UpgradeVIP'].close();					
				}
				else if (data.ResultCode == 98) {
					alert("登入資訊不正確");
				}
				else if (data.ResultCode == 99) {
					alert("伺服器維護中!");
				}
				else {
					alert(data.ResultMsg);
				}
			},
			error: function (e) {
				alert("error:" + e.responseText);
			}
		});
	},

	// 手機驗證
	mobileValidate: function () {
		var valFlag = true;
		
		if (SGT.Main.QueryFns['UpgradeVIP'].Mobile() == "") {
			SGT.Main.QueryFns['UpgradeVIP'].MobileMsg("手機號碼不可空白");
			return false;
		}

		if (SGT.Main.QueryFns['UpgradeVIP'].Mobile() != "") {
			if (!SGT.Main.QueryFns['UpgradeVIP'].Mobile().match(/^[09]{2}[0-9]{8}$/)) {
				SGT.Main.QueryFns['UpgradeVIP'].MobileMsg("手機號碼格式錯誤");
				valFlag = false;
			}
			else {
				$.ajax({
					type: "POST",
					url: "/AppAjaxs/RegisterValidation.ashx",
					async: false,
					data: "CheckType=3&CheckData=" + SGT.Main.QueryFns['UpgradeVIP'].Mobile(),
					success: function (data) {
						SGT.Main.QueryFns['UpgradeVIP'].MobileMsg(data);

						if (data.substr(0, 4) == '<img') {
							valFlag = true;
						}
						else {
							valFlag = false;
						}
					},
					error: function (e) {						
						valFlag = false;
					}
				});
			}
		}
		else {
			SGT.Main.QueryFns['UpgradeVIP'].MobileMsg("");
		}

		return valFlag;
	},

	// 驗證碼驗證
	verificationCodeValidate: function () {
		if (SGT.Main.QueryFns['UpgradeVIP'].VerificationCode() == "") {
			alert("驗證碼不可空白！");			
			return false;
		}

		return true;
	},

	// 打開輸入手機頁面
	openInputMobile: function () {
		if (SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"]) {
			return;
		}
				
		SGT.Global.PopIframeMgr.Add("UpgradeVIPIframe");
		SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"].Load("/MVC/UpgradeVIP/InputMobile");
		SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"].Center(580, 396);
		SGT.Global.PopIframeMgr.PopIframes["UpgradeVIPIframe"].Show();
		SGT.Global.PopIframeMgr.BodyMaskHide();
	},
	
	// 打開手機驗證頁面
	openMobileAuthentication: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/UpgradeVIP/MobileAuthentication" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	// 打開取消手機驗證頁面
	openCancelMobileAuthentication: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/UpgradeVIP/CancelMobileAuthentication" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	// 打開手機驗證頻繁頁面
	openMobileAuthenticationFrequently: function () {
		var isGameMenu = getParameter("IsGameMenu") == "1";
		location.href = "/MVC/UpgradeVIP/MobileAuthenticationFrequently" + (isGameMenu ? "?isGameMenu=1" : "");
	},

	close: function () {
		if (getParameter("isGameMenu") == "1") {
			top.swfobject.getObjectById("WebLoad").callWebLoad('CloseIFrame', '');
		}
		else {
			top.SGT.Global.PopIframeMgr.RemoveAll();
		}
	}
});
