var SGT;
(function (SGT) {
    (function (Member) {
        var AccountChangeProcess = (function () {
            function AccountChangeProcess() {
            }
            AccountChangeProcess.prototype.ToMobileEnter = function () {
                if(!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                    return;
                }
                SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileEnter");
            };
            AccountChangeProcess.prototype.ToMobileAuthentication = function () {
                if(!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                    return;
                }
                SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileAuthentication");
            };
            AccountChangeProcess.prototype.ToMobileAuthenticationFail = function () {
                if(!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                    return;
                }
                SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileAuthenticationFail");
            };
            AccountChangeProcess.prototype.ToMobileAuthenticationSuccess = function () {
                if(!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                    return;
                }
                SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"].Load("/MVC/AccountChange/MobileAuthenticationSuccess");
            };
            AccountChangeProcess.prototype.Close = function () {
                if(!SGT.Global.PopIframeMgr.PopIframes["CWLoginIframe"]) {
                    return;
                }
                SGT.Global.PopIframeMgr.Remove('CWLoginIframe');
            };
            return AccountChangeProcess;
        })();
        Member.AccountChangeProcess = AccountChangeProcess;        
        var AccountChange_MobileEnter = (function () {
            function AccountChange_MobileEnter() {
                this.Mobile = ko.observable('');
                this.IsSubmitEnable = ko.observable(true);
            }
            AccountChange_MobileEnter.prototype.Submit = function () {
                var obj = this;
                obj.IsSubmitEnable(false);
                var data = {
                    Mobile: obj.Mobile()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/AccountChange/EnterMobile",
                    data: data,
                    success: function (data) {
                        if(data.ResultCode == 0) {
                            window['top'].SGT.Main.QueryFns['AccountChangeProcess'].ToMobileAuthentication();
                        } else {
                            if(data.ResultCode == 1) {
                                window['top'].SGT.Main.QueryFns['AccountChangeProcess'].ToMobileAuthenticationFail();
                            } else {
                                obj.IsSubmitEnable(true);
                                alert(data.ResultMsg);
                            }
                        }
                    },
                    error: function (e) {
                        obj.IsSubmitEnable(true);
                    }
                });
            };
            return AccountChange_MobileEnter;
        })();
        Member.AccountChange_MobileEnter = AccountChange_MobileEnter;        
        var AccountChange_MobileAuth = (function () {
            function AccountChange_MobileAuth() {
                this.AuthCode = ko.observable('');
                this.IsReSendEnable = ko.observable(true);
                this.IsSubmitEnable = ko.observable(true);
            }
            AccountChange_MobileAuth.prototype.ReSendAuthCode = function () {
                var obj = this;
                obj.IsReSendEnable(false);
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/AccountChange/ReSendAuthCode",
                    success: function (data) {
                        obj.IsReSendEnable(true);
                        if(data.ResultCode == 0) {
                            alert(data.ResultMsg);
                            if(data.Data) {
                                obj.AuthCode(data.Data);
                            }
                        } else {
                            alert(data.ResultMsg);
                        }
                    },
                    error: function (e) {
                        obj.IsReSendEnable(true);
                    }
                });
            };
            AccountChange_MobileAuth.prototype.Submit = function () {
                var obj = this;
                obj.IsSubmitEnable(false);
                var data = {
                    MobileVaildCode: obj.AuthCode()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/AccountChange/MobileAuthentication",
                    data: data,
                    success: function (data) {
                        if(data.ResultCode == 0) {
                            alert(data.ResultMsg);
                            window['top'].SGT.Main.QueryFns['AccountChangeProcess'].ToMobileAuthenticationSuccess();
                        } else {
                            alert(data.ResultMsg);
                        }
                        if(data.ResultCode != 0) {
                            obj.IsSubmitEnable(true);
                        }
                    },
                    error: function (e) {
                        obj.IsSubmitEnable(true);
                    }
                });
            };
            return AccountChange_MobileAuth;
        })();
        Member.AccountChange_MobileAuth = AccountChange_MobileAuth;        
        var AccountChange_MemberTypeChange = (function () {
            function AccountChange_MemberTypeChange() {
                this.Account = ko.observable('');
                this.Password = ko.observable('');
                this.ConfirmPassword = ko.observable('');
                this.Email = ko.observable('');
                this.IsSubmitEnable = ko.observable(true);
            }
            AccountChange_MemberTypeChange.prototype.Submit = function () {
                var obj = this;
                obj.IsSubmitEnable(false);
                if(obj.Password() != obj.ConfirmPassword()) {
                    alert($SGT.Message.AccountChange.Utility[0]);
                    obj.IsSubmitEnable(true);
                    return;
                }
                var data = {
                    MemberAccount: obj.Account(),
                    MemberPassword: obj.Password(),
                    EMail: obj.Email()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/AccountChange/MemberTypeChange",
                    data: data,
                    success: function (data) {
                        if(data.ResultCode == 0) {
                            alert(data.ResultMsg);
                            window['top'].SGT.Main.QueryFns['AccountChangeProcess'].Close();
                        } else {
                            alert(data.ResultMsg);
                        }
                        if(data.ResultCode != 0) {
                            obj.IsSubmitEnable(true);
                        }
                    },
                    error: function (e) {
                        obj.IsSubmitEnable(true);
                    }
                });
            };
            return AccountChange_MemberTypeChange;
        })();
        Member.AccountChange_MemberTypeChange = AccountChange_MemberTypeChange;        
    })(SGT.Member || (SGT.Member = {}));
    var Member = SGT.Member;

})(SGT || (SGT = {}));

