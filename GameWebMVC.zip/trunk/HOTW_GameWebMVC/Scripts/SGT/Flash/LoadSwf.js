var SGT;
(function (SGT) {
    (function (Flash) {
        var LoadSwf = (function () {
            function LoadSwf() {
                this.Url = "";
                this.DivContainer = "";
                this.Width = 500;
                this.Height = 500;
                this.Version = 10;
                this.ExpressInstallPath = "../../Scripts/expressInstall.swf";
                this.Flashvars = {
                };
                this.Params = {
                    wmode: "transparent",
                    allowScriptAccess: "always",
                    allowFullScreen: "true"
                };
                this.Attributes = {
                };
            }
            LoadSwf.prototype.LoadFlash = function () {
                swfobject.embedSWF(this.Url, this.DivContainer, this.Width.toString(), this.Height.toString(), this.Version.toString(), this.ExpressInstallPath, this.Flashvars, this.Params, this.Attributes);
            };
            return LoadSwf;
        })();
        Flash.LoadSwf = LoadSwf;        
    })(SGT.Flash || (SGT.Flash = {}));
    var Flash = SGT.Flash;
})(SGT || (SGT = {}));
