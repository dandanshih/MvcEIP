declare var top;

module SGT.Flash {

    // �j�U�ϥΨƥ�
    export class FlashEvent {
        
        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ������������
        static CloseSelf(): void {
            parent["swfobject"].getObjectById("WebLoad").callWebLoad('CloseIFrame', '');
        }

        // �q�o�]�����ءA�ݱa���B
        static ShowLuckMoney(money: string): void {
            parent["swfobject"].getObjectById("WebLoad").callWebLoad('ShowLuckMoney', money);
        }
    }
}
