declare var swfobject;

module SGT.Flash {
    
    // ���J Flash �Ѽ�
    export class LoadSwf {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () { 
        }
        
        /// --------------------------------------
        /// property
        /// --------------------------------------
        // ���J Flash ���|
        Url: string = "";
        // ���J Flash ���Ҫ� Selector
        DivContainer: string = "";
        // Flash �e��
        Width: number = 500;
        // Flash ����
        Height: number = 500;
        // �̧C����
        Version: number = 10;
        // expressInstall �s��
        ExpressInstallPath: string = "../../Scripts/expressInstall.swf";
        // Flash �Ѽ�
        Flashvars: Object = {};
        // Flash ���ҰѼ�
        Params: Object = { wmode: "transparent", allowScriptAccess: "always", allowFullScreen: "true" };
        // Flash �ۭq�Ѽ�
        Attributes: Object = {};
        
        /// --------------------------------------
        /// function
        /// --------------------------------------
        LoadFlash(): void {
            swfobject.embedSWF(
                this.Url
                , this.DivContainer
                , this.Width.toString()
                , this.Height.toString()
                , this.Version.toString()
                , this.ExpressInstallPath
                , this.Flashvars
                , this.Params
                , this.Attributes
            );
        }
    }
}