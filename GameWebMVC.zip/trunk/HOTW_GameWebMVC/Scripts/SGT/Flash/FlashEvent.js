var SGT;
(function (SGT) {
    (function (Flash) {
        var FlashEvent = (function () {
            function FlashEvent() { }
            FlashEvent.CloseSelf = function CloseSelf() {
                parent["swfobject"].getObjectById("WebLoad").callWebLoad('CloseIFrame', '');
            }
            FlashEvent.ShowLuckMoney = function ShowLuckMoney(money) {
                parent["swfobject"].getObjectById("WebLoad").callWebLoad('ShowLuckMoney', money);
            }
            return FlashEvent;
        })();
        Flash.FlashEvent = FlashEvent;        
    })(SGT.Flash || (SGT.Flash = {}));
    var Flash = SGT.Flash;

})(SGT || (SGT = {}));

