﻿SGT.WebSiteInfo.Urls = {

    DataInfoUrl: '@HOTW_GameWebMVC.AppLibs.WebConfig.DataInfoUrl',

    CdnUrl: '@HOTW_GameWebMVC.AppLibs.WebConfig.CdnURL',

    LogUrl: '@HOTW_GameWebMVC.AppLibs.WebConfig.LogWebDomain',

    MainUrl: '@HOTW_GameWebMVC.AppLibs.WebConfig.Domain',
    
    GetUrl: function (UrlType) {
        return this[UrlType];
    }
}

SGT.WebSiteInfo.FBAppID = '@HOTW_GameWebMVC.AppLibs.WebConfig.FBAppID';

SGT.WebSiteInfo.FBAppScope = '@HOTW_GameWebMVC.AppLibs.WebConfig.FBPerms';