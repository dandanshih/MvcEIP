var SGT;
(function (SGT) {
    (function (StaticPages) {
        var CallForUpload = (function () {
            function CallForUpload(koName, sessionId) {
                if (typeof koName === "undefined") { koName = 'CallForUpload'; }
                if (typeof sessionId === "undefined") { sessionId = ''; }
                this.KoName = '';
                this.SessionID = '';
                this.KoName = koName;
                this.SessionID = sessionId;
                this.CheckMember();
                setInterval(this.KeepOnline, 30000);
            }
            CallForUpload.prototype.KeepOnline = function () {
                $.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/UserKeepOnline.ashx?callback=?", function (data) {
                    if(data.Result == "Clear" || data.Result == "NoLogin") {
                        location.href = '/MVC';
                    }
                });
            };
            CallForUpload.prototype.Uploadify = function (ctrlID) {
                var self = this;
                $(ctrlID).uploadify({
                    swf: '/MVC/Scripts/Uploadify/uploadify.swf',
                    uploader: 'http://' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/AppAjaxs/UploadCallForPhoto.ashx',
                    multi: false,
                    auto: true,
                    fileTypeExts: '*.jpg;*.gif;*.png;',
                    fileTypeDesc: 'Image Files (.JPG, .GIF, .PNG)',
                    fileSizeLimit: '10 MB',
                    removeCompleted: true,
                    width: 83,
                    height: 27,
                    buttonText: "",
                    formData: {
                        ID: self.SessionID
                    },
                    queueID: "xx",
                    onSelectError: function (file, errorCode, errorMsg) {
                        switch(errorCode) {
                            case -110:
                                this.queueData.errorMsg = $SGT.Message.CallForUpload.Uploadify[4];
                                break;
                            case -120:
                            default:
                                this.queueData.errorMsg = $SGT.Message.CallForUpload.Uploadify[5];
                                break;
                        }
                    },
                    onUploadSuccess: function (file, data, response) {
                        switch(data) {
                            case "0":
                                alert($SGT.Message.CallForUpload.Uploadify[0]);
                                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step03' + location.search;
                                break;
                            case "1":
                                location.href = '/MVC';
                                break;
                            case "2":
                                alert($SGT.Message.CallForUpload.Uploadify[6]);
                                break;
                            case "3":
                                alert($SGT.Message.CallForUpload.Uploadify[1]);
                                break;
                            case "1002":
                                alert($SGT.Message.CallForUpload.Uploadify[3]);
                                location.href = '/MVC';
                                break;
                            case "1000":
                            case "1003":
                            default:
                                alert($SGT.Message.CallForUpload.Uploadify[2]);
                                location.href = '/MVC';
                                break;
                        }
                    },
                    onUploadError: function (file, errorCode, errorMsg, errorString) {
                        alert($SGT.Message.CallForUpload.Uploadify[1]);
                    },
                    onUploadComplete: function (file) {
                    }
                });
            };
            CallForUpload.prototype.CheckMember = function () {
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/CheckMember",
                    async: true,
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 1001:
                                break;
                            case 1002:
                                alert($SGT.Message.CallForUpload.CheckMember[1]);
                                location.href = '/MVC';
                                break;
                            default:
                                alert($SGT.Message.CallForUpload.CheckMember[0]);
                                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01' + location.search;
                                ;
                                break;
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            return CallForUpload;
        })();
        StaticPages.CallForUpload = CallForUpload;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
