declare var $;
declare var ko;
declare var GetPlatform;
declare var changeDiv;
module SGT.StaticPages {

    export class JsonObj {
        CumulativeWinPoints: number = 0;
        CumulativeNumber: number = 0;
        Data: JsonData[] = [];
    }
    export class JsonData {
        RankNo: string = "";
        NickName: string = "";
        RankTimes: number = 0;
        RankValue: number = 0;
    }
    export class ActionTenThirty {
        //�^�Ǹ�Ƶ��c
        dataBase1: (input?: JsonData[]) => JsonData[] = ko.observableArray([]);
        dataBase2: (input?: JsonData[]) => JsonData[] = ko.observableArray([]);
        //���ʭ�/�j�U(0/1)
        //Type: (input?: number) => number = ko.observable(0);
        //�����Ӥ��]/�L���m���](0/1)
        //Kind: (input?: number) => number = ko.observable(0);


        public DataBind(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: {
                    Platform: platform,
                    Type: 0,
                    Kind: 0
                },
                url: '/MVC/api/HotActive/GetTenPointHalf',
                async: false,
                success: function (data) {
                    self.dataBase1(data.Result.Data);
                },
                error: function (ex) {
                }
            });
            /*
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: {
                    Platform: platform,
                    Type: 0,
                    Kind: 1
                },
                url: '/MVC/api/HotActive/GetTenPointHalf',
                async: false,
                success: function (data) {
                    self.dataBase2(data.Result.Data);
                },
                error: function (ex) {
                }
            });     
            console.log(self.dataBase1());
            console.log(self.dataBase2());
            console.log(self.dataBase1().length);
            console.log(self.dataBase2().length);
            */
        }

        public changeTag(Tag: number): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            switch (Tag) {
                case 1:
                    if (self.dataBase1().length == 0) {
                        $.ajax({
                            type: 'POST',
                            dataType: "json",
                            data: {
                                Platform: platform,
                                Type: 0,
                                Kind: 0
                            },
                            url: '/MVC/api/HotActive/GetTenPointHalf',
                            async: false,
                            success: function (data) {
                                self.dataBase1(data.Result.Data);
                            },
                            error: function (ex) {
                            }
                        });
                        changeDiv(Tag);
                    } else {
                        changeDiv(Tag);
                    }
                    break;
                case 2:
                    if (self.dataBase2().length == 0) {
                        $.ajax({
                            type: 'POST',
                            dataType: "json",
                            data: {
                                Platform: platform,
                                Type: 0,
                                Kind: 1
                            },
                            url: '/MVC/api/HotActive/GetTenPointHalf',
                            async: false,
                            success: function (data) {
                                self.dataBase2(data.Result.Data);
                            },
                            error: function (ex) {
                            }
                        });
                        changeDiv(Tag);
                    } else {
                        changeDiv(Tag);
                    }
                    break;
                case 3:
                    changeDiv(Tag);
                    break;
            }
        }
    }
}