var SGT;
(function (SGT) {
    (function (StaticPages) {
        var RankByWin = (function () {
            function RankByWin(koName) {
                if (typeof koName === "undefined") { koName = 'RankByWin'; }
                this.KoName = '';
                this.RankList1 = ko.observableArray([]);
                this.RankByWin1 = ko.observableArray([]);
                this.RankByWin2 = ko.observableArray([]);
                this.KoName = koName;
                this.GetRank();
            }
            RankByWin.prototype.GetRank = function () {
                var self = this;
                $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetRankByJP.ashx?callback=?', {
                    Data: "1#@$100"
                }, function (data) {
                    self.RankList1(data.RankList);
                });
                $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetRankByWin.ashx?callback=?', {
                    Data: 1
                }, function (data) {
                    self.RankByWin1(data.Data);
                });
                $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetRankByWin.ashx?callback=?', {
                    Data: 2
                }, function (data) {
                    self.RankByWin2(data.Data);
                });
            };
            return RankByWin;
        })();
        StaticPages.RankByWin = RankByWin;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
