/// <reference path="../../../Uploadify/jquery.uploadify.js" />

declare var SGT;
declare var $SGT;
declare var $;
declare var ko;

module SGT.StaticPages {

    // �ի����a���l�O_�W���ɮ�
    export class CallForUpload {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor(koName: string = 'CallForUpload', sessionId: string = '') {
            this.KoName = koName;
            this.SessionID = sessionId;

            // �ˬd�|������
            this.CheckMember();

            // �O���b�u
            setInterval(this.KeepOnline, 30000);
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';
        private SessionID: string = '';

        /// --------------------------------------
        /// ko function
        /// --------------------------------------

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // �O���b�u
        KeepOnline(): void {
            $.getJSON(
                "//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/UserKeepOnline.ashx?callback=?",
                function (data) {
                    if (data.Result == "Clear" || data.Result == "NoLogin") {
                        location.href = '/MVC';
                    }
                }
            );
        }

        // ô���W���ɮ׫��s���\��
        Uploadify(ctrlID: string):void {
            var self = this;

            $(ctrlID).uploadify({
                swf: '/MVC/Scripts/Uploadify/uploadify.swf',
                // �D�n�W�Ǩϥ� handle�A���ϥ� http:// �b chrome ���p�U�|�o�� 404���~
                uploader: 'http://' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/AppAjaxs/UploadCallForPhoto.ashx',
                // �O�_�h���ɮפW��
                multi: false,
                // ����ɮק����O�_�����W��
                auto: true,
                // ����ɮ׵��� - ���\���ɦW
                fileTypeExts: '*.jpg;*.gif;*.png;',
                // ����ɮ׵��� - ���\���ɦW�T��
                fileTypeDesc: 'Image Files (.JPG, .GIF, .PNG)',
                // number:�ɮפj�p(KB) 0 ������
                // string: �i������J B KB MB GB
                fileSizeLimit: '10 MB',
                // �����Y�q queue �R��
                removeCompleted: true,
                // �W�ǫ��s�e��
                width: 83,
                // �W�ǫ��s����
                height: 27,
                // �W�ǫ��s��r
                buttonText: "",
                // Post ��ơA�] FF ������ Session�A�G�N SessionID �L�h
                formData: { ID: self.SessionID },
                // �]�w���s�b�� queueID ���W�Ƕi�פ���ܥX��
                queueID: "xx",
                // ����ɮרƥ�
                onSelectError: function (file, errorCode, errorMsg) {
                    // �N errorMsg �Ƽg�L�h
                    switch (errorCode) {
                        // �ɮ׶W�L�j�p
                        case -110:
                            this.queueData.errorMsg = $SGT.Message.CallForUpload.Uploadify[4];
                            break;
                        // ������ɮ׬� 0 bytes
                        case -120:
                        default:
                            this.queueData.errorMsg = $SGT.Message.CallForUpload.Uploadify[5];
                            break;
                    }
                },
                // ���\�ƥ�
                onUploadSuccess: function (file, data, response) {
                    switch (data) {
                        // ���\
                        case "0":
                            alert($SGT.Message.CallForUpload.Uploadify[0]);
                            location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step03' + location.search;
                            break;
                        // ���n�J
                        case "1":
                            location.href = '/MVC';
                            break;
                        // ������ɮ�
                        case "2":
                            alert($SGT.Message.CallForUpload.Uploadify[6]);
                            break;
                        // �������~
                        case "3":
                            alert($SGT.Message.CallForUpload.Uploadify[1]);
                            break;
                        // �����ŦX_�ɮפw�f��
                        case "1002":
                            alert($SGT.Message.CallForUpload.Uploadify[3]);
                            location.href = '/MVC';
                            break;
                        // ���ŦX���ʸ��
                        case "1000":
                        // �����ŦX�����������
                        case "1003":
                        default:
                            alert($SGT.Message.CallForUpload.Uploadify[2]);
                            location.href = '/MVC';
                            break;
                    }
                },
                // ���~�ƥ�
                onUploadError: function (file, errorCode, errorMsg, errorString) {
                    alert($SGT.Message.CallForUpload.Uploadify[1]);
                },
                // �����ƥ�
                onUploadComplete: function (file) {

                }
            });
        }

        CheckMember(): void {
	        $.ajax({
	            type: "POST",
	            url: "/MVC/api/StaticPages/CheckMember",
	            async: true,
	            dataType: "json",
	            success: function (data) {
	                switch (data.ResultCode) {
                        // ���f��
	                    case 1001:
	                        break;
                        // �w�f��
	                    case 1002:
	                        alert($SGT.Message.CallForUpload.CheckMember[1]);
	                        location.href = '/MVC';
	                        break;
	                    default:
	                        alert($SGT.Message.CallForUpload.CheckMember[0]);
                            location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01' + location.search;;
	                        break;
	                }
	            },
	            error: function (e) {
	                //alert("error:" + e.responseText);
	            },
	            complete: function () {
	                
	            }
	        });
        }
    }
}