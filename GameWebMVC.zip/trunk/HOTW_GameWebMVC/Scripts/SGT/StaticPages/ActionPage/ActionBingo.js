var SGT;
(function (SGT) {
    (function (StaticPages) {
        var ActionBingo = (function () {
            function ActionBingo() {
                this.platform = "Web";
                this.ResultCode = ko.observable(-1);
                this.GoldCoin = ko.observable(0);
                this.LuckyCoin = ko.observable(0);
                this.SubCNT = ko.observable(0);
                this.VerifiedCNT = ko.observable(0);
                this.TotalAmount = ko.observable(0);
                var self = this;
                if(typeof GetPlatform == "function") {
                    this.platform = GetPlatform();
                }
            }
            ActionBingo.prototype.ChangeView = function (index) {
                var self = this;
                switch(index) {
                    case 1:
                        $.ajax({
                            type: "POST",
                            url: "/MVC/api/HotActive/GetRestaurantBingoCoinStatus",
                            async: false,
                            data: {
                                Platform: this.platform
                            },
                            dataType: "JSON",
                            success: function (data) {
                                if(data.Result != null) {
                                    self.ResultCode(data.Result.ResultCode);
                                    self.GoldCoin(data.Result.GoldCoin);
                                    self.LuckyCoin(data.Result.LuckyCoin);
                                }
                            },
                            error: function (e) {
                            },
                            complete: function () {
                            }
                        });
                        break;
                    case 2:
                        $.ajax({
                            type: "POST",
                            url: "/MVC/api/HotActive/GetRestaurantBingoIntroducerStatus",
                            async: false,
                            data: {
                                Platform: this.platform
                            },
                            dataType: "JSON",
                            success: function (data) {
                                if(data.Result != null) {
                                    self.ResultCode(data.Result.ResultCode);
                                    self.SubCNT(data.Result.SubCNT);
                                    self.VerifiedCNT(data.Result.VerifiedCNT);
                                    self.TotalAmount(data.Result.TotalAmount);
                                }
                            },
                            error: function (e) {
                            },
                            complete: function () {
                            }
                        });
                        break;
                    default:
                        break;
                }
            };
            return ActionBingo;
        })();
        StaticPages.ActionBingo = ActionBingo;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
