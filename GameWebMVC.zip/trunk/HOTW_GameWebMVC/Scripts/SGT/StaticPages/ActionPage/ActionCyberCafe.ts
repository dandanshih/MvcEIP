﻿declare var $;
declare var ko;
declare var GetPlatform;
declare var changeDiv;
declare var OpenLink;
module SGT.StaticPages {
    export class ActionCyberCafe {
        //活動狀態
        IsOpen: (input?: string) => string = ko.observable("");
        //日期年月日
        toDay: (input?: string) => string = ko.observable("");
        //指定IP
        IsWarning: (input?: bool) => bool = ko.observable(false);
        //會員登入狀態
        IsLogin: (input?: bool) => bool = ko.observable(false);
        //總分數
        TotalWinLose: (input?: number) => number = ko.observable(0);
        //會員等級
        MemberLevel: (input?: number) => number = ko.observable(0);

        //egg1 ClassStyle
        Egg1 = ko.observableArray();
        //egg2 ClassStyle
        Egg2 = ko.observableArray();
        //egg3 ClassStyle
        Egg3 = ko.observableArray();

        //egg1 領取狀態
        Egg1Type: (input?: bool) => bool = ko.observable(true);
        //egg2 領取狀態
        Egg2Type: (input?: bool) => bool = ko.observable(true);
        //egg3 領取狀態
        Egg3Type: (input?: bool) => bool = ko.observable(true);

        //送交防多點擊開關
        AjaxType: (input?: bool) => bool = ko.observable(false);

        //回傳DB
        //dataList = ko.observableArray();




        public dataBind(): void {
            var self = this;
            var today = new Date();
            //顯示日期
            self.toDay(today.getFullYear() + "/" + (today.getMonth() + 1) + "/" + today.getDate());
            //設定platform
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            //取資訊
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform },
                url: '/MVC/api/HotActive/QueryPlayerWinLoseLog',
                async: false,
                success: function (data) {
                    //活動狀態
                    self.IsOpen(data.Result.IsOpen);
                    //指定IP
                    self.IsWarning(data.Result.IsWarning);
                    //會員登入狀態
                    self.IsLogin(data.Result.IsLogin);
                    //會員等級
                    self.MemberLevel(data.Result.Data.VIP_Level);
                    //總分數
                    self.TotalWinLose(data.Result.Data.TotalWinLose);
                    //egg1 領取狀態
                    
                    (data.Result.Data.Egg0 ) ? self.Egg1Type(true) : self.Egg1Type(false);
                    //egg2 領取狀態
                    (data.Result.Data.Egg1) ? self.Egg2Type(true) : self.Egg2Type(false);
                    //egg3 領取狀態
                    (data.Result.Data.Egg2) ? self.Egg3Type(true) : self.Egg3Type(false);
                    
                    //alert('登入:' + data.Result.IsLogin + "警示燈:" + data.Result.IsWarning + "會員等級:" + data.Result.Data.VIP_Level + "總分:" + data.Result.Data.TotalWinLose + "蛋1:" + data.Result.Data.Egg0 + "蛋2:" + data.Result.Data.Egg1 + "蛋3:" + data.Result.Data.Egg2);
                    //self.eggType();
                    /*
                    //指定IP
                    self.IsWarning(true);
                    //會員登入狀態
                    self.IsLogin(true);
                    //會員等級
                    self.MemberLevel(1);
                    //總分數
                    self.TotalWinLose(130);
                    //egg1 領取狀態
                    (1s == 1) ? self.Egg1Type(true) : self.Egg1Type(false);
                    //egg2 領取狀態
                    (0 == 1) ? self.Egg2Type(true) : self.Egg2Type(false);
                    //egg3 領取狀態
                    (0 == 1) ? self.Egg3Type(true) : self.Egg3Type(false);

                    alert('登入:' + self.IsLogin() + "警示燈:" + self.IsWarning() + "會員等級:" + self.MemberLevel() + "總分:" + self.TotalWinLose() + "蛋1:" + self.Egg1Type() + "蛋2:" + self.Egg2Type() + "蛋3:" + self.Egg3Type());
                    */

                    //self.dataList([data.Result]);
                },
                error: function (ex) {
                    //alert("asd");
                }
            });
            //self.TotalWinLose(self.dataList()[0]['Data']['TotalWinLose']);
            //alert(self.toDay);
            self.eggType();
        }
        
        //送交
        public getPresent(eggNumber:number) {
            var self = this;
            if (self.AjaxType()==false) {
                self.AjaxType(true); 
                var platform: string = "Web";
                if (typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: { Platform: platform, Which: eggNumber },
                    url: '/MVC/api/HotActive/PlayerGetColorEgg',
                    async: true,
                    success: function (data) {
                        //alert(data.Result.Data.ResultCode);

                        if (data.Result.Data.ResultCode == 1) {
                            alert(data.Result.Data.ResultCodeMsg);
                            self.dataBind();
                            self.AjaxType(false);
                        } else {

                            alert(data.Result.Data.ResultCodeMsg);
                            self.dataBind();
                            self.AjaxType(false);
                        }
                    },
                    error: function (ex) {
                        //alert("asd");
                    }
                });
                
            }
        }
        
        //蛋狀態判斷
        public eggType(): void {
            var self = this;
            //Egg01判斷開啟或關閉
            
            if (self.MemberLevel() >= 0 && self.TotalWinLose() >= 10 && self.Egg1Type() == false && self.IsWarning() == false && self.IsLogin() == true)
            {
                self.Egg1({ "egg": "egg01_2", "btn": "btn04_1" });
            }
            else {
                self.Egg1({ "egg": "egg01_1", "btn": "btn04_4" });
            }
            
            //Egg02判斷開啟或關閉 
            if (self.MemberLevel() >= 0 && self.TotalWinLose() >= 50 && self.Egg2Type() == false && self.IsWarning() == false && self.IsLogin() == true) {
                self.Egg2({ "egg": "egg02_2", "btn": "btn04_1" });
            }
            else {
                self.Egg2({ "egg": "egg02_1", "btn": "btn04_4" });
            }
            //Egg03判斷開啟或關閉 
            if (self.MemberLevel() >= 1 && self.TotalWinLose() >= 150 && self.Egg3Type() == false && self.IsWarning() == false && self.IsLogin() == true) {
                self.Egg3({ "egg": "egg03_2", "btn": "btn04_1" });
            }
            else {
                self.Egg3({ "egg": "egg03_1", "btn": "btn04_4" });
            }
        }

        //判斷活動時間開啟狀態
        public checkProjectOpen() {
            var self = this;
            if (self.IsOpen() == "0")
            {
                alert("活動尚未開始");
            }
            else if (self.IsOpen() == "1")
            {
                if (self.IsLogin()) {
                    changeDiv(3);
                    self.dataBind();
                }
                else
                {
                    OpenLink('/MVC/StaticPages/Web/ActionPage/ActionCyberCafe/Iframe');
                    return false;
                }
            }
            else if (self.IsOpen() == "2")
            {
                alert("活動結束，謝謝您的參予");
            }   
        }
        //計時器
        /*
        public timekeeper(tid:number=0) {
            var self = this;
          
            if (self.IsLogin() == true) {
                self.dataBind();
                var D1 = new Date();
                var MiniS = 0;
                if (tid != 0) {
                    clearInterval(tid);
                }
                
                var A1 = (11 - (D1.getMinutes() % 10));

                if (A1 == 10)
                {
                    MiniS = 10 * 60 * 1000;
                    var Tid = setInterval(function () { self.timekeeper(Tid); }, MiniS);
                }
                else if (A1==11)
                {
                    MiniS = 60 * 1000;
                    var Tid = setInterval(function () { self.timekeeper(Tid); }, MiniS);
                }
                else
                {
                    MiniS = A1 * 60 * 1000;
                    var Tid = setInterval(function () { self.timekeeper(Tid); }, MiniS);
                }
            }
        }
        */
        public timekeeper() {
            var self = this;

            if (self.IsLogin() == true) {
                self.dataBind();
                var D1 = new Date();
                var MiniS = 0;
                
                var A1 = (11 - (D1.getMinutes() % 10));

                if (A1 == 10) {
                    MiniS = 10 * 60 * 1000;
                    setTimeout(function () { self.timekeeper(); }, MiniS);
                }
                else if (A1 == 11) {
                    MiniS = 60 * 1000;
                    setTimeout(function () { self.timekeeper(); }, MiniS);
                }
                else {
                    MiniS = A1 * 60 * 1000;
                    setTimeout(function () { self.timekeeper(); }, MiniS);
                }
            }
        }
    }

     
}