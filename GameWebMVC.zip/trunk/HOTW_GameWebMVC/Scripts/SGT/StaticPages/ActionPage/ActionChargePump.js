﻿var SGT;
(function (SGT) {
    (function (StaticPages) {
        var dataBase0Fromat = (function () {
            function dataBase0Fromat() {
                this.Name = "";
                this.Date = "";
                this.Monry = 0;
            }
            return dataBase0Fromat;
        })();
        StaticPages.dataBase0Fromat = dataBase0Fromat;        
        var dataBase1 = (function () {
            function dataBase1() {
                this.RankNo = 0;
                this.NickName = "";
                this.TotalWin = 0;
            }
            return dataBase1;
        })();
        StaticPages.dataBase1 = dataBase1;        
        var dataBase2 = (function () {
            function dataBase2() {
                this.RankNo = 0;
                this.NickName = "";
                this.TotalWin = 0;
            }
            return dataBase2;
        })();
        StaticPages.dataBase2 = dataBase2;        
        var ActionChargePump = (function () {
            function ActionChargePump() {
                this.dataBase0 = ko.observableArray([]);
                this.ResultEventID = ko.observable("");
                this.IsLogin = ko.observable(false);
                this.openType = ko.observable(1);
                this.GoldCoin = ko.observable("0");
                this.VIP_Level = ko.observable("一般");
                this.LuckyPoint = ko.observable("0");
                this.DateTime = ko.observable();
                this.Data1 = ko.observableArray([]);
                this.Data2 = ko.observableArray([]);
            }
            ActionChargePump.prototype.bindTag0 = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform
                    },
                    url: '/MVC/api/HotActive/GetCashAwardList',
                    async: false,
                    success: function (data) {
                        self.dataBase0(data.Result.Data);
                    },
                    error: function (ex) {
                    }
                });
            };
            ActionChargePump.prototype.bindTag1 = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        EventGroupID: 1
                    },
                    url: '/MVC/api/HotActive/GetBefore10ListCompetence',
                    async: false,
                    success: function (data) {
                        self.ResultEventID(data.Result.ResultEventID);
                    },
                    error: function (ex) {
                    }
                });
            };
            ActionChargePump.prototype.goTag = function (tag) {
                changeDiv(tag);
                var self = this;
            };
            ActionChargePump.prototype.getDateTag = function (tagNumber) {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        EventID: self.getTagString(tagNumber),
                        PageSize: 25,
                        PageIndex: 1
                    },
                    url: '/MVC/api/HotActive/GetBefore10List',
                    async: false,
                    success: function (data) {
                        if(data.Result.ResultCode == -1) {
                            alert('此時段活動尚未開啟');
                        } else {
                            self.Data1(data.Result.ResultData.Data1);
                            self.Data2(data.Result.ResultData.Data2);
                            changeDiv2(tagNumber);
                        }
                    },
                    error: function (ex) {
                    }
                });
            };
            ActionChargePump.prototype.bindTag2 = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    url: '/MVC/api/HotActive/GetMemberActivityData',
                    async: false,
                    data: {
                        Platform: platform
                    },
                    success: function (data) {
                        self.IsLogin(data.Result.IsLogin);
                        self.DateTime(data.Result.DateTime);
                        self.GoldCoin(self.numFormat3(data.Result.Data.GoldCoin));
                        self.LuckyPoint(self.numFormat3(data.Result.Data.LuckyPoint));
                        self.VIP_Level(self.vipLevelChangeString(data.Result.Data.VIP_Level));
                        self.openType(self.getPpenType(new Date().toString()));
                    },
                    error: function (ex) {
                    }
                });
            };
            ActionChargePump.prototype.getTagString = function (ResultEventID) {
                switch(ResultEventID) {
                    case 1:
                        return "E201307180031";
                        break;
                    case 2:
                        return "E201307180032";
                        break;
                    case 3:
                        return "E201307180033";
                        break;
                    case 4:
                        return "E201307180034";
                        break;
                    default:
                        return "E201307180031";
                }
            };
            ActionChargePump.prototype.getTagNumber = function (ResultEventID) {
                switch(ResultEventID) {
                    case "E201307180031":
                        return 1;
                        break;
                    case "E201307180032":
                        return 2;
                        break;
                    case "E201307180033":
                        return 3;
                        break;
                    case "E201307180034":
                        return 4;
                        break;
                    default:
                        return 1;
                }
            };
            ActionChargePump.prototype.vipLevelChangeString = function (vipLevel) {
                switch(vipLevel) {
                    case 0:
                        return "一般";
                        break;
                    case 1:
                        return "普";
                        break;
                    case 2:
                        return "銀";
                        break;
                    case 3:
                        return "金";
                        break;
                    case 4:
                        return "白金";
                        break;
                    default:
                        return "一般";
                }
            };
            ActionChargePump.prototype.numFormat3 = function (stringValue) {
                var stringEnd = " ";
                var n = "";
                var str = stringValue.toString();
                if(str.indexOf(".") != -1) {
                    var aa = str.split(".");
                    str = aa[0];
                    stringEnd = "." + aa[1];
                }
                str = "" + eval(str);
                var len = str.length;
                for(var i = len - 1; i >= 0; i--) {
                    n = str.charAt(i) + n;
                    if((((len - i) % 3) == 0) && (i != 0)) {
                        n = "," + n;
                    }
                }
                return n + stringEnd;
            };
            ActionChargePump.prototype.timekeeper = function (m) {
                var self = this;
                self.bindTag0();
                self.bindTag1();
                self.bindTag2();
                var MiniS = m * 60 * 1000;
                setTimeout(function () {
                    self.timekeeper(m);
                }, MiniS);
            };
            ActionChargePump.prototype.getPpenType = function (DateTime) {
                var date20130718 = Date.parse("2013/7/18 11:00");
                var date20130731 = Date.parse("2013/8/1 8:00");
                var date20130801 = Date.parse("2013/8/1 11:00");
                var date20130715 = Date.parse("2013/8/15 8:00");
                var date20130816 = Date.parse("2013/8/15 11:00");
                var date20130829 = Date.parse("2013/8/29 8:00");
                var serverTime = Date.parse(DateTime.toString());
                if(date20130718 < serverTime && serverTime < date20130731) {
                    return 1;
                } else if(date20130801 < serverTime && serverTime < date20130715) {
                    return 2;
                } else if(date20130816 < serverTime && serverTime < date20130829) {
                    return 3;
                } else {
                    return 1;
                }
            };
            return ActionChargePump;
        })();
        StaticPages.ActionChargePump = ActionChargePump;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
