var SGT;
(function (SGT) {
    (function (StaticPages) {
        var ActionNoviceLucky = (function () {
            function ActionNoviceLucky() {
                this.IsLogin = ko.observable(false);
            }
            ActionNoviceLucky.prototype.DataBind = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
            };
            return ActionNoviceLucky;
        })();
        StaticPages.ActionNoviceLucky = ActionNoviceLucky;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
