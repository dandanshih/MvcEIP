/// <reference path="../../Pages/Shared/SGTPage.ts" />
declare var $: any;
declare var ko: any;
declare var GetPlatform: any;

module SGT.StaticPages {

    export class ActionBingoHistoryStruct {

        MachineName: string = "";

        DateTime: string = "";

        Number: string = "";

        Count: string = "";

        NickName: string = "";

    }

    export class DropDownListStruct {

        Text: string = "";

        Value: string = "";

    }

    export class ActionBingoHistory {

        Type: string = "0";

        platform: string = "Web";

        PageName: string = "ActionBingoHistory";

        ArrayList: (input?: ActionBingoHistoryStruct[]) => ActionBingoHistoryStruct[] = ko.observableArray([]);

        YearMonthArrayList: (input?: DropDownListStruct[]) => DropDownListStruct[] = ko.observableArray([]);

        MachineNameArrayList: (input?: DropDownListStruct[]) => DropDownListStruct[] = ko.observableArray([]);

        YearMonth: (input?: string) => string = ko.observable("-1");

        MachineName: (input?: string) => string = ko.observable("-1");

        Page: SGT.Pages.Page;

        constructor() {

            this.GetYearMonth();

            this.GetMachineName();

            this.PagePreLoad();

        }

        PagePreLoad(): void {

            if (typeof GetPlatform == "function") {
                this.platform = GetPlatform();
            }

            this.Page = new SGT.Pages.Page(() => { this.GetRestaurantBingoGameRecord(); });

            this.Page.PageSize(20);

            SGT.Pages.PageMgr.Add(this.PageName, this.Page);

            this.PageLoad();
        }

        PageLoad(): void {

            var self = this;

            $.ajax({
                type: "POST",
                url: "/MVC/api/HotActive/GetRestaurantBingoGameRecord",
                async: false,
                data: { Platform: this.platform, Type: this.Type, YearMonth: this.YearMonth(), MachineName: this.MachineName(), PageSize: this.Page.PageSize(), PageIndex: this.Page.PageIndex() },
                dataType: "JSON",
                success: function (data) {
                    if (data.Result.Data != null) {
                        self.ArrayList(data.Result.Data);
                        self.Page.TotalRecord(data.Result.TotalCount);
                    }
                },
                error: function (e) {
                },
                complete: function () {
                }
            });
        }

        GetYearMonth(): void {

            var self = this;

            $.ajax({
                type: "POST",
                url: "/MVC/api/HotActive/GetRestaurantBingoGameRecordYearMonth",
                async: false,
                data: {},
                dataType: "JSON",
                success: function (data) {
                    if (data.Result.Data != null) {
                        self.YearMonthArrayList(data.Result.Data);
                    }
                },
                error: function (e) {
                },
                complete: function () {
                }
            });
        }

        GetMachineName(): void {

            var self = this;

            $.ajax({
                type: "POST",
                url: "/MVC/api/HotActive/GetRestaurantBingoGameRecordMachineName",
                async: false,
                data: {},
                dataType: "JSON",
                success: function (data) {
                    if (data.Result.Data != null) {
                        self.MachineNameArrayList(data.Result.Data);
                    }
                },
                error: function (e) {
                },
                complete: function () {
                }
            });
        }

        GetRestaurantBingoGameRecord(): void {

            var self = this;

            $.ajax({
                type: "POST",
                url: "/MVC/api/HotActive/GetRestaurantBingoGameRecord",
                async: false,
                data: { Platform: this.platform, Type: this.Type, YearMonth: this.YearMonth(), MachineName: this.MachineName(), PageSize: this.Page.PageSize(), PageIndex: this.Page.PageIndex() },
                dataType: "JSON",
                success: function (data) {
                    if (data.Result.Data != null) {
                        self.ArrayList(data.Result.Data);
                        self.Page.TotalRecord(data.Result.TotalCount);
                    }
                },
                error: function (e) {
                },
                complete: function () {
                }
            });
        }

        YearMonthChangeEvent(): void {

            this.GetRestaurantBingoGameRecord();

        }

        MachineNameChangeEvent(): void {

            this.GetRestaurantBingoGameRecord();

        }
    }
}