﻿declare var $;
declare var ko;
declare var GetPlatform;

module SGT.StaticPages {
    export class ActionNoviceLucky{

        //是否登入
        IsLogin: (input?: bool) => bool = ko.observable(false);


        public DataBind(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            /*
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform },
                url: '/MVC/api/HotActive/GetCashAwardList',
                async: false,
                success: function (data) {
                    self.dataBase0(data.Result.Data);
                },
                error: function (ex) {
                }
            });
            */
        }

       
    }
}