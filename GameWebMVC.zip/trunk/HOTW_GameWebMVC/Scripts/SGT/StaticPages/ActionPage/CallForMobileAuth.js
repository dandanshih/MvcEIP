var SGT;
(function (SGT) {
    (function (StaticPages) {
        var CallForMobileAuth = (function () {
            function CallForMobileAuth(koName) {
                if (typeof koName === "undefined") { koName = 'CallForMobileAuth'; }
                this.KoName = '';
                this.IsRun = false;
                this.VerificationCode = ko.observable("");
                this.KoName = koName;
            }
            CallForMobileAuth.prototype.MobileAuth = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                var self = this;
                if(!this.VerificationCodeValidate()) {
                    return;
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/MobileAuthentication",
                    async: true,
                    data: {
                        "verificationCode": self.VerificationCode()
                    },
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 0:
                                alert($SGT.Message.CallForMobileAuth.MobileAuth[0]);
                                self.AutoLogin();
                                break;
                            case 2:
                            case 3:
                            case 99:
                                alert($SGT.Message.CallForMobileAuth.MobileAuth[1]);
                                location.href = '/MVC';
                                break;
                            default:
                                alert($SGT.Message.CallForMobileAuth.MobileAuth[2]);
                                self.IsRun = false;
                                break;
                        }
                    },
                    error: function (e) {
                        self.IsRun = false;
                    },
                    complete: function () {
                    }
                });
            };
            CallForMobileAuth.prototype.AutoLogin = function () {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/ActionAutoLogin",
                    async: true,
                    data: "",
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 1:
                                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step02' + location.search;
                                break;
                            case 98:
                                alert($SGT.Message.CallForMobileAuth.AutoLogin[0]);
                                location.href = '/MVC';
                                break;
                            case 12:
                            case 99:
                                alert($SGT.Message.CallForMobileAuth.AutoLogin[1]);
                                location.href = '/MVC';
                                break;
                            case 1000:
                                alert(data.ResultMsg);
                                self.FreeAutoLogin();
                                break;
                            default:
                                alert(data.ResultMsg);
                                location.href = '/MVC';
                                break;
                        }
                    },
                    error: function (e) {
                    }
                });
            };
            CallForMobileAuth.prototype.FreeAutoLogin = function () {
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/AutoLogin",
                    async: true,
                    data: "",
                    dataType: "json",
                    success: function (data) {
                        location.href = '/MVC';
                    },
                    error: function (e) {
                    }
                });
            };
            CallForMobileAuth.prototype.ReSend = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/ReSendVerificationCode",
                    async: true,
                    data: "",
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 0:
                                self.VerificationCode(data.Data);
                                alert($SGT.Message.CallForMobileAuth.ReSend[0]);
                                self.IsRun = false;
                                break;
                            case 99:
                                alert($SGT.Message.CallForMobileAuth.ReSend[1]);
                                location.href = '/MVC';
                            default:
                                alert(data.ResultMsg);
                                self.FreeAutoLogin();
                                break;
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            CallForMobileAuth.prototype.CancelConfirm = function () {
                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01_2b_1' + location.search;
            };
            CallForMobileAuth.prototype.VerificationCodeValidate = function () {
                if(this.VerificationCode() == "") {
                    alert($SGT.Message.CallForMobileAuth.VerificationCodeValidate[0]);
                    return false;
                }
                return true;
            };
            return CallForMobileAuth;
        })();
        StaticPages.CallForMobileAuth = CallForMobileAuth;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
