var SGT;
(function (SGT) {
    (function (StaticPages) {
        var CallForLogin = (function () {
            function CallForLogin(koName) {
                if (typeof koName === "undefined") { koName = 'CallForLogin'; }
                this.KoName = '';
                this.IsRun = false;
                this.Account = ko.observable("");
                this.Password = ko.observable("");
                this.KoName = koName;
            }
            CallForLogin.prototype.BackRegister = function () {
                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01' + location.search;
            };
            CallForLogin.prototype.Login = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                var self = this;
                if(!this.Validate()) {
                    return;
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/ActionLogin",
                    async: true,
                    data: {
                        "account": RsaEncrypt(this.Account()),
                        "password": RsaEncrypt(this.Password())
                    },
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 1:
                                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step02' + location.search;
                                ;
                                break;
                            case 30:
                                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01' + location.search;
                                ;
                                break;
                            case 19:
                                self.IsRun = false;
                                if(confirm(data.ResultMsg)) {
                                    self.ReLogin();
                                }
                                break;
                            case 98:
                            case 99:
                            case 1000:
                            default:
                                alert(data.ResultMsg);
                                self.IsRun = false;
                                break;
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            CallForLogin.prototype.ReLogin = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                var self = this;
                if(!this.Validate()) {
                    return;
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/ActionReLogin",
                    async: true,
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 1:
                                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step02' + location.search;
                                ;
                                break;
                            default:
                                alert(data.ResultMsg);
                                self.IsRun = false;
                                break;
                        }
                    },
                    error: function (e) {
                    }
                });
            };
            CallForLogin.prototype.Validate = function () {
                if(this.Account().length == 0) {
                    alert($SGT.Message.CallForLogin.Validate[0]);
                    return false;
                }
                if(this.Password().length == 0) {
                    alert($SGT.Message.CallForLogin.Validate[1]);
                    return false;
                }
                return true;
            };
            return CallForLogin;
        })();
        StaticPages.CallForLogin = CallForLogin;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
