//declare var SGT;
declare var $SGT;
declare var $;
declare var ko;
declare var RsaEncrypt;

module SGT.StaticPages {

    // �@��|���n�J�}��
    export class MemberLogin {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor(callBack: () => void ) {
            this.CallBack = callBack;
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        // ���\��e�����������|
        private CallBack: () => void;
        // �O�_�����椤
        private IsRun: bool = false;

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �b��
        Account = ko.observable("");
        // �K�X
        Password = ko.observable("");

        /// --------------------------------------
        /// private function
        /// --------------------------------------
        // ���e�n�J
        private ReLogin(): void {
            if (this.IsRun) {
                return;
            }

            this.IsRun = true;

            if (!this.Validate()) {
                return;
            }

            var self = this;
            $.ajax({
                type: "POST",
                url: "/MVC/api/StaticPages/ReLogin",
                async: false,
                dataType: "json",
                success: function (data) {
                    switch (data.ResultCode) {
                        // �n�J���\
                        case 1:
                            if (self.CallBack) {
                                self.CallBack();
                            }
                            break;
                        default:
                            alert(data.ResultMsg);
                            self.IsRun = false;
                            break;
                    }
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                    self.IsRun = false;
                }
            });
        }

        // �n�J�e����
        private Validate(): bool {
            if (this.Account().length == 0) {
                alert($SGT.Message.CallForLogin.Validate[0]);
                return false;
            }

            if (this.Password().length == 0) {
                alert($SGT.Message.CallForLogin.Validate[1]);
                return false;
            }

            return true;
        }

        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // �n�J
        Login(): void {
            if (this.IsRun) {
                return;
            }
            this.IsRun = true;

            // ���O���n�J����ƫh���i������
            if (!this.Validate()) {
                return;
            }

            var self = this;
            $.ajax({
                type: "POST",
                url: "/MVC/api/StaticPages/Login",
                async: false,
                data: { "account": RsaEncrypt(self.Account()), "password": RsaEncrypt(self.Password()) },
                dataType: "json",
                success: function (data) {
                    switch (data.ResultCode) {
                        case 1:     // �n�J���\
                        case 30:    // �w�n�J
                            if (self.CallBack) {
                                self.CallBack();
                            }
                            break;
                        // ���e
                        case 19:
                            if (confirm(data.ResultMsg)) {
                                self.IsRun = false;
                                self.ReLogin();
                            } else {
                                self.IsRun = false;
                            }
                            break;
                        default:
                            alert(data.ResultMsg);
                            self.IsRun = false;
                            break;
                    }
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                    self.IsRun = false;
                },
                complete: function () {

                }
            });
        }

        // ���s�n�J
        CommunityLogin(communityType: string, isIframe: bool): void {
            if (this.IsRun) {
                return;
            }
            this.IsRun = true;

            var doc = isIframe ? parent.document : document;

            var form = doc.createElement("form");
            form["name"] = "payForm";
            form["method"] = "post";
            form["action"] = '/Mvc/CWLogin/ActionCommunityLogin';
            form["target"] = "_self";

            var ele = doc.createElement("input");
            ele["name"] = "submitButton";
            ele["value"] = communityType;
            ele["hidden"] = true;
            ele["type"] = 'hidden';

            form.appendChild(ele);

            doc.body.appendChild(form);
            doc.forms[doc.forms.length - 1]["submit"]();
        }
    }
}
