var SGT;
(function (SGT) {
    (function (StaticPages) {
        var ActionBingoHistoryStruct = (function () {
            function ActionBingoHistoryStruct() {
                this.MachineName = "";
                this.DateTime = "";
                this.Number = "";
                this.Count = "";
                this.NickName = "";
            }
            return ActionBingoHistoryStruct;
        })();
        StaticPages.ActionBingoHistoryStruct = ActionBingoHistoryStruct;        
        var DropDownListStruct = (function () {
            function DropDownListStruct() {
                this.Text = "";
                this.Value = "";
            }
            return DropDownListStruct;
        })();
        StaticPages.DropDownListStruct = DropDownListStruct;        
        var ActionBingoHistory = (function () {
            function ActionBingoHistory() {
                this.Type = "0";
                this.platform = "Web";
                this.PageName = "ActionBingoHistory";
                this.ArrayList = ko.observableArray([]);
                this.YearMonthArrayList = ko.observableArray([]);
                this.MachineNameArrayList = ko.observableArray([]);
                this.YearMonth = ko.observable("-1");
                this.MachineName = ko.observable("-1");
                this.GetYearMonth();
                this.GetMachineName();
                this.PagePreLoad();
            }
            ActionBingoHistory.prototype.PagePreLoad = function () {
                var _this = this;
                if(typeof GetPlatform == "function") {
                    this.platform = GetPlatform();
                }
                this.Page = new SGT.Pages.Page(function () {
                    _this.GetRestaurantBingoGameRecord();
                });
                this.Page.PageSize(20);
                SGT.Pages.PageMgr.Add(this.PageName, this.Page);
                this.PageLoad();
            };
            ActionBingoHistory.prototype.PageLoad = function () {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/HotActive/GetRestaurantBingoGameRecord",
                    async: false,
                    data: {
                        Platform: this.platform,
                        Type: this.Type,
                        YearMonth: this.YearMonth(),
                        MachineName: this.MachineName(),
                        PageSize: this.Page.PageSize(),
                        PageIndex: this.Page.PageIndex()
                    },
                    dataType: "JSON",
                    success: function (data) {
                        if(data.Result.Data != null) {
                            self.ArrayList(data.Result.Data);
                            self.Page.TotalRecord(data.Result.TotalCount);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            ActionBingoHistory.prototype.GetYearMonth = function () {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/HotActive/GetRestaurantBingoGameRecordYearMonth",
                    async: false,
                    data: {
                    },
                    dataType: "JSON",
                    success: function (data) {
                        if(data.Result.Data != null) {
                            self.YearMonthArrayList(data.Result.Data);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            ActionBingoHistory.prototype.GetMachineName = function () {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/HotActive/GetRestaurantBingoGameRecordMachineName",
                    async: false,
                    data: {
                    },
                    dataType: "JSON",
                    success: function (data) {
                        if(data.Result.Data != null) {
                            self.MachineNameArrayList(data.Result.Data);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            ActionBingoHistory.prototype.GetRestaurantBingoGameRecord = function () {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/HotActive/GetRestaurantBingoGameRecord",
                    async: false,
                    data: {
                        Platform: this.platform,
                        Type: this.Type,
                        YearMonth: this.YearMonth(),
                        MachineName: this.MachineName(),
                        PageSize: this.Page.PageSize(),
                        PageIndex: this.Page.PageIndex()
                    },
                    dataType: "JSON",
                    success: function (data) {
                        if(data.Result.Data != null) {
                            self.ArrayList(data.Result.Data);
                            self.Page.TotalRecord(data.Result.TotalCount);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            ActionBingoHistory.prototype.YearMonthChangeEvent = function () {
                this.GetRestaurantBingoGameRecord();
            };
            ActionBingoHistory.prototype.MachineNameChangeEvent = function () {
                this.GetRestaurantBingoGameRecord();
            };
            return ActionBingoHistory;
        })();
        StaticPages.ActionBingoHistory = ActionBingoHistory;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
