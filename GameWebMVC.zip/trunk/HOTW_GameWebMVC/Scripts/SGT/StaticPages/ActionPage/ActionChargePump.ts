﻿declare var $;
declare var ko;
declare var GetPlatform;
declare var changeDiv;
declare var changeDiv2;
module SGT.StaticPages {
    
    //dateBase0強型別
    export class dataBase0Fromat
    {
        Name: string = "";
        Date: string = "";
        Monry: number = 0;
    }

    /*
    //dateBase1強型別
    export class dataBase1Fromat {
        EventID: number = 0;
        IsShow: bool = false;
        Data1: dataBase1[] = [];
        Data2: dataBase2[] = [];
    }
 */
    export class dataBase1 {
        //名次
        RankNo:number=0;
        // 玩家暱稱
        NickName: string = "";
        // 總勝分數
        TotalWin: number = 0;
    }
    export class dataBase2 {
        //名次
        RankNo: number = 0;
        // 玩家暱稱
        NickName: string = "";
        // 總勝分數
        TotalWin: number = 0;
    }
    
   



    export class ActionChargePump {
        /*頁籤1資料*/
        dataBase0: (input?: dataBase0Fromat[]) => dataBase0Fromat[] = ko.observableArray([]);
        
        /*頁籤2資料*/
        ResultEventID: (input?: string) => string = ko.observable("");
        //dataBase1: (input?: dataBase1Fromat[]) => dataBase1Fromat[] = ko.observableArray([]);
        //預設顯示頁籤
        //DefaultTab: (input?: string) => string = ko.observable("E201307180031");
        

        /*頁籤3資料*/
        //是否登入
        IsLogin: (input?: bool) => bool = ko.observable(false);
        //開啟狀態
        openType: (input?: number) => number = ko.observable(1);
        //金幣數量    
        GoldCoin :(input?: string) => string = ko.observable("0");
        //會員卡別等級
        VIP_Level: (input?: string) => string = ko.observable("一般");
        //幸運金點數
        LuckyPoint: (input?: string) => string = ko.observable("0");
        //server時間
        DateTime: (input?: string) => string = ko.observable();
        //Data1
        Data1: (input?: dataBase1[]) => dataBase1[] = ko.observableArray([]);
        //Data2
        Data2: (input?: dataBase2[]) => dataBase2[] = ko.observableArray([]);

        //Tag0 資料綁定
        public bindTag0(): void {
            
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform },
                url: '/MVC/api/HotActive/GetCashAwardList',
                async: false,
                success: function (data) {
                    self.dataBase0(data.Result.Data);
                },
                error: function (ex) {
                }
            });
            
        }

        //Tag1 資料綁定
        public bindTag1(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform:platform,EventGroupID:1},
                url: '/MVC/api/HotActive/GetBefore10ListCompetence',
                async: false,
                success: function (data) {
                    self.ResultEventID(data.Result.ResultEventID);
                },
                error: function (ex) {
                    
                }
            });          
        }


        public goTag(tag:number): void
        {
            changeDiv(tag);
            var self = this;
            //self.mouseRemoveHover();
        }
        
        //取時間區段資訊
        public getDateTag(tagNumber: number): void
        {      
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: {
                    Platform: platform,
                    EventID: self.getTagString(tagNumber),
                    PageSize: 25,
                    PageIndex:1
                },
                url: '/MVC/api/HotActive/GetBefore10List',
                async: false,
                success: function (data) {
                    if (data.Result.ResultCode == -1)
                    {
                        alert('此時段活動尚未開啟');
                    }
                    else
                    {
                        self.Data1(data.Result.ResultData.Data1);
                        self.Data2(data.Result.ResultData.Data2);
                        changeDiv2(tagNumber);
                    }
                },
                error: function (ex) {
                 }
            });        
        }

       

        //Tag2 資料綁定
        public bindTag2(): void
        {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                url: '/MVC/api/HotActive/GetMemberActivityData',
                async: false,
                data: { Platform: platform },
                success: function (data) {
                    //登入狀態
                    self.IsLogin(data.Result.IsLogin);
                    //srever時間
                    self.DateTime(data.Result.DateTime);
                    //金幣數量
                    self.GoldCoin(self.numFormat3(data.Result.Data.GoldCoin));
                    //幸運金點數
                    self.LuckyPoint(self.numFormat3(data.Result.Data.LuckyPoint));
                    //會員卡別等級
                    self.VIP_Level(self.vipLevelChangeString(data.Result.Data.VIP_Level));
                  

                    //取Server時間
                    //self.openType(self.getPpenType(self.DateTime()));
                    //取Clien時間
                    self.openType(self.getPpenType(new Date().toString()));

                    //alert(self.getPpenType(self.DateTime()).toString());
                    //console.log(data.Result.DateTime);
                    //alert(typeof (data.Result.DateTime));
                },
                error: function (ex) {
                    //alert("asd");
                }
            });
        }

        //移除滑鼠效果
        /*
        public mouseRemoveHover(): void
        {
             var self = this;
            for (var i = 0; i < self.dataBase1().length; i++) {

                if (!self.dataBase1()[i]['IsShow']) {

                    $("#GameBtn2_img" + (i + 1)).attr('onmouseover', '');
                    $("#GameBtn2_img" + (i + 1)).attr('onmousedown', '');
                    $("#GameBtn2_img" + (i + 1)).attr('onmouseout', '');
                }
            }
        }
        */

        //取代碼轉字串
        public getTagString(ResultEventID: number): string {
            switch (ResultEventID) {
                case 1:
                    return "E201307180031";
                    break;
                case 2:
                    return "E201307180032";
                    break;
                case 3:
                    return "E201307180033";
                    break;
                case 4:
                    return "E201307180034";
                    break;
                default:
                    return "E201307180031";
            }
        }

        //取代碼頁籤
        public getTagNumber(ResultEventID:string):number
        {
            switch (ResultEventID)
            {
                case "E201307180031":
                    return 1;
                    break;
                case "E201307180032":
                    return 2;
                    break;
                case "E201307180033":
                    return 3;
                    break;
                case "E201307180034":
                    return 4;
                    break;
                default:
                    return 1;
            }
        }

        //會員卡別轉換
        public vipLevelChangeString(vipLevel: number): string
        {
            switch (vipLevel)
            {
                case 0:
                    return "一般";
                    break;
                case 1:
                    return "普";
                    break;
                case 2:
                    return "銀";
                    break;
                case 3:
                    return "金";
                    break;
                case 4:
                    return "白金";
                    break;
                default:
                    return "一般";
            }
        }

        //點數加分號
        public numFormat3(stringValue:number):string {
            var stringEnd = " ";
            var n = "";
            var str = stringValue.toString();
            if (str.indexOf(".") != -1) {
                var aa = str.split(".");
                str = aa[0];
                stringEnd = "." + aa[1]
            }
            str = "" + eval(str);
            var len = str.length;
            for (var i = len - 1 ; i >= 0 ; i--) {
                n = str.charAt(i) + n;
                if ((((len - i) % 3) == 0) && (i != 0)) {
                    n = "," + n;
                }
            }
            return n + stringEnd;
        }

        //計時器
        public timekeeper(m: number): void {
            var self = this;
            self.bindTag0();
            self.bindTag1();
            self.bindTag2();
            var MiniS = m *60* 1000;
            setTimeout(function () { self.timekeeper(m) }, MiniS);
        }
        //判斷神秘加碼開啟狀態

        public getPpenType(DateTime): number{
            
           
            var date20130718 = Date.parse("2013/7/18 11:00");
            var date20130731 = Date.parse("2013/8/1 8:00");

            var date20130801 = Date.parse("2013/8/1 11:00");
            var date20130715 = Date.parse("2013/8/15 8:00");

            var date20130816 = Date.parse("2013/8/15 11:00");
            var date20130829 = Date.parse("2013/8/29 8:00");

            
            
            var serverTime = Date.parse(DateTime.toString());
           
            
            
            if (date20130718 < serverTime && serverTime < date20130731) {
                return 1;
            }
            else if (date20130801 < serverTime && serverTime < date20130715) {
                return 2;
            }
            else if (date20130816 < serverTime && serverTime < date20130829) {
                return 3;
            }
            else {
                return 1;
            }
          
        }       
    }
}
