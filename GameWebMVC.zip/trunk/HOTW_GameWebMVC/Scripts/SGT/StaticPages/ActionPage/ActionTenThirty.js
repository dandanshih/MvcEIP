var SGT;
(function (SGT) {
    (function (StaticPages) {
        var JsonObj = (function () {
            function JsonObj() {
                this.CumulativeWinPoints = 0;
                this.CumulativeNumber = 0;
                this.Data = [];
            }
            return JsonObj;
        })();
        StaticPages.JsonObj = JsonObj;        
        var JsonData = (function () {
            function JsonData() {
                this.RankNo = "";
                this.NickName = "";
                this.RankTimes = 0;
                this.RankValue = 0;
            }
            return JsonData;
        })();
        StaticPages.JsonData = JsonData;        
        var ActionTenThirty = (function () {
            function ActionTenThirty() {
                this.dataBase1 = ko.observableArray([]);
                this.dataBase2 = ko.observableArray([]);
            }
            ActionTenThirty.prototype.DataBind = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        Type: 0,
                        Kind: 0
                    },
                    url: '/MVC/api/HotActive/GetTenPointHalf',
                    async: false,
                    success: function (data) {
                        self.dataBase1(data.Result.Data);
                    },
                    error: function (ex) {
                    }
                });
            };
            ActionTenThirty.prototype.changeTag = function (Tag) {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                switch(Tag) {
                    case 1:
                        if(self.dataBase1().length == 0) {
                            $.ajax({
                                type: 'POST',
                                dataType: "json",
                                data: {
                                    Platform: platform,
                                    Type: 0,
                                    Kind: 0
                                },
                                url: '/MVC/api/HotActive/GetTenPointHalf',
                                async: false,
                                success: function (data) {
                                    self.dataBase1(data.Result.Data);
                                },
                                error: function (ex) {
                                }
                            });
                            changeDiv(Tag);
                        } else {
                            changeDiv(Tag);
                        }
                        break;
                    case 2:
                        if(self.dataBase2().length == 0) {
                            $.ajax({
                                type: 'POST',
                                dataType: "json",
                                data: {
                                    Platform: platform,
                                    Type: 0,
                                    Kind: 1
                                },
                                url: '/MVC/api/HotActive/GetTenPointHalf',
                                async: false,
                                success: function (data) {
                                    self.dataBase2(data.Result.Data);
                                },
                                error: function (ex) {
                                }
                            });
                            changeDiv(Tag);
                        } else {
                            changeDiv(Tag);
                        }
                        break;
                    case 3:
                        changeDiv(Tag);
                        break;
                }
            };
            return ActionTenThirty;
        })();
        StaticPages.ActionTenThirty = ActionTenThirty;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
