declare var SGT;
declare var $SGT;
declare var $;
declare var ko;
declare var getParameter;

module SGT.StaticPages {

    // �ի����a���l�O_�����������
    export class CallForCancelMobileAuth {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor(koName: string = 'CallForCancelMobileAuth') {
            this.KoName = koName;
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';
        // �O�_���b���椤
        private IsRun: bool = false;

        /// --------------------------------------
        /// ko function
        /// --------------------------------------

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ��^����
        BackMobileAuth(): void {
            location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01_2b' + location.search;
        }

        // �����������
        CancelMobileAuth(): void {
            if (this.IsRun) {
                return;
            }

            this.IsRun = true;
            var self = this;

            $.ajax({
                type: "POST",
                url: "/MVC/api/StaticPages/CancelMobileAuthentication",
                async: true,
                data: "",
                dataType: "json",
                success: function (data) {
                    alert(data.ResultMsg);

                    if (data.ResultCode == 0) {
                        self.FreeAutoLogin();
                    } else {
                        location.href = '/MVC';
                    }
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {

                }
            });
        }
        
        // �۰ʵn�J
        FreeAutoLogin(): void {
            $.ajax({
                type: "POST",
                url: "/MVC/api/StaticPages/AutoLogin",
                async: true,
                data: "",
                dataType: "json",
                success: function (data) {
                    location.href = '/MVC';
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                }
            });
        }
    }
}
