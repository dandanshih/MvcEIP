﻿var SGT;
(function (SGT) {
    (function (StaticPages) {
        var ActionCyberCafe = (function () {
            function ActionCyberCafe() {
                this.IsOpen = ko.observable("");
                this.toDay = ko.observable("");
                this.IsWarning = ko.observable(false);
                this.IsLogin = ko.observable(false);
                this.TotalWinLose = ko.observable(0);
                this.MemberLevel = ko.observable(0);
                this.Egg1 = ko.observableArray();
                this.Egg2 = ko.observableArray();
                this.Egg3 = ko.observableArray();
                this.Egg1Type = ko.observable(true);
                this.Egg2Type = ko.observable(true);
                this.Egg3Type = ko.observable(true);
                this.AjaxType = ko.observable(false);
            }
            ActionCyberCafe.prototype.dataBind = function () {
                var self = this;
                var today = new Date();
                self.toDay(today.getFullYear() + "/" + (today.getMonth() + 1) + "/" + today.getDate());
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform
                    },
                    url: '/MVC/api/HotActive/QueryPlayerWinLoseLog',
                    async: false,
                    success: function (data) {
                        self.IsOpen(data.Result.IsOpen);
                        self.IsWarning(data.Result.IsWarning);
                        self.IsLogin(data.Result.IsLogin);
                        self.MemberLevel(data.Result.Data.VIP_Level);
                        self.TotalWinLose(data.Result.Data.TotalWinLose);
                        (data.Result.Data.Egg0) ? self.Egg1Type(true) : self.Egg1Type(false);
                        (data.Result.Data.Egg1) ? self.Egg2Type(true) : self.Egg2Type(false);
                        (data.Result.Data.Egg2) ? self.Egg3Type(true) : self.Egg3Type(false);
                    },
                    error: function (ex) {
                    }
                });
                self.eggType();
            };
            ActionCyberCafe.prototype.getPresent = function (eggNumber) {
                var self = this;
                if(self.AjaxType() == false) {
                    self.AjaxType(true);
                    var platform = "Web";
                    if(typeof GetPlatform == "function") {
                        platform = GetPlatform();
                    }
                    $.ajax({
                        type: 'POST',
                        dataType: "json",
                        data: {
                            Platform: platform,
                            Which: eggNumber
                        },
                        url: '/MVC/api/HotActive/PlayerGetColorEgg',
                        async: true,
                        success: function (data) {
                            if(data.Result.Data.ResultCode == 1) {
                                alert(data.Result.Data.ResultCodeMsg);
                                self.dataBind();
                                self.AjaxType(false);
                            } else {
                                alert(data.Result.Data.ResultCodeMsg);
                                self.dataBind();
                                self.AjaxType(false);
                            }
                        },
                        error: function (ex) {
                        }
                    });
                }
            };
            ActionCyberCafe.prototype.eggType = function () {
                var self = this;
                if(self.MemberLevel() >= 0 && self.TotalWinLose() >= 10 && self.Egg1Type() == false && self.IsWarning() == false && self.IsLogin() == true) {
                    self.Egg1({
                        "egg": "egg01_2",
                        "btn": "btn04_1"
                    });
                } else {
                    self.Egg1({
                        "egg": "egg01_1",
                        "btn": "btn04_4"
                    });
                }
                if(self.MemberLevel() >= 0 && self.TotalWinLose() >= 50 && self.Egg2Type() == false && self.IsWarning() == false && self.IsLogin() == true) {
                    self.Egg2({
                        "egg": "egg02_2",
                        "btn": "btn04_1"
                    });
                } else {
                    self.Egg2({
                        "egg": "egg02_1",
                        "btn": "btn04_4"
                    });
                }
                if(self.MemberLevel() >= 1 && self.TotalWinLose() >= 150 && self.Egg3Type() == false && self.IsWarning() == false && self.IsLogin() == true) {
                    self.Egg3({
                        "egg": "egg03_2",
                        "btn": "btn04_1"
                    });
                } else {
                    self.Egg3({
                        "egg": "egg03_1",
                        "btn": "btn04_4"
                    });
                }
            };
            ActionCyberCafe.prototype.checkProjectOpen = function () {
                var self = this;
                if(self.IsOpen() == "0") {
                    alert("活動尚未開始");
                } else if(self.IsOpen() == "1") {
                    if(self.IsLogin()) {
                        changeDiv(3);
                        self.dataBind();
                    } else {
                        OpenLink('/MVC/StaticPages/Web/ActionPage/ActionCyberCafe/Iframe');
                        return false;
                    }
                } else if(self.IsOpen() == "2") {
                    alert("活動結束，謝謝您的參予");
                }
            };
            ActionCyberCafe.prototype.timekeeper = function () {
                var self = this;
                if(self.IsLogin() == true) {
                    self.dataBind();
                    var D1 = new Date();
                    var MiniS = 0;
                    var A1 = (11 - (D1.getMinutes() % 10));
                    if(A1 == 10) {
                        MiniS = 10 * 60 * 1000;
                        setTimeout(function () {
                            self.timekeeper();
                        }, MiniS);
                    } else if(A1 == 11) {
                        MiniS = 60 * 1000;
                        setTimeout(function () {
                            self.timekeeper();
                        }, MiniS);
                    } else {
                        MiniS = A1 * 60 * 1000;
                        setTimeout(function () {
                            self.timekeeper();
                        }, MiniS);
                    }
                }
            };
            return ActionCyberCafe;
        })();
        StaticPages.ActionCyberCafe = ActionCyberCafe;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
