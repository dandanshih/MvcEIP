declare var $: any;
declare var ko: any;
declare var GetPlatform: any;

module SGT.StaticPages {

    export class ActionBingo {

        platform: string = "Web";

        // -1/0/1/2/3
        ResultCode: (input?: number) => number = ko.observable(-1);

        GoldCoin: (input?: number) => number = ko.observable(0);

        LuckyCoin: (input?: number) => number = ko.observable(0);

        SubCNT: (input?: number) => number = ko.observable(0);

        VerifiedCNT: (input?: number) => number = ko.observable(0);

        TotalAmount: (input?: number) => number = ko.observable(0);

        constructor() {

            var self = this;

            if (typeof GetPlatform == "function") {
                this.platform = GetPlatform();
            }

        }

        ChangeView(index: number): void {

            var self = this;

            switch (index) {
                case 1:
                    $.ajax({
                        type: "POST",
                        url: "/MVC/api/HotActive/GetRestaurantBingoCoinStatus",
                        async: false,
                        data: { Platform: this.platform },
                        dataType: "JSON",
                        success: function (data) {
                            if (data.Result != null) {
                                self.ResultCode(data.Result.ResultCode);
                                self.GoldCoin(data.Result.GoldCoin);
                                self.LuckyCoin(data.Result.LuckyCoin);
                            }
                        },
                        error: function (e) {
                        },
                        complete: function () {
                        }
                    });
                    break;
                case 2:
                    $.ajax({
                        type: "POST",
                        url: "/MVC/api/HotActive/GetRestaurantBingoIntroducerStatus",
                        async: false,
                        data: { Platform: this.platform },
                        dataType: "JSON",
                        success: function (data) {
                            if (data.Result != null) {
                                self.ResultCode(data.Result.ResultCode);
                                self.SubCNT(data.Result.SubCNT);
                                self.VerifiedCNT(data.Result.VerifiedCNT);
                                self.TotalAmount(data.Result.TotalAmount);
                            }
                        },
                        error: function (e) {
                        },
                        complete: function () {
                        }
                    });
                    break;
                default:
                    break;
            }
        }
    }
}