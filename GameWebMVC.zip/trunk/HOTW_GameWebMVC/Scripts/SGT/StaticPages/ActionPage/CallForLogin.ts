declare var SGT;
declare var $SGT;
declare var $;
declare var ko;
declare var RsaEncrypt;

module SGT.StaticPages {

    // �ի����a���l�O_�n�J
    export class CallForLogin {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (koName: string = 'CallForLogin') {
            this.KoName = koName;
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';
        // �O�_���b���椤
        private IsRun: bool = false;

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �b��
        Account = ko.observable("");
        // �K�X
        Password = ko.observable("");

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // �^���U��
        BackRegister(): void {
            location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01'+ location.search;
        }

	    // �n�J
	    Login(): void {
	        if (this.IsRun) { return; }

	        this.IsRun = true;

	        var self = this;

	        // ���O���n�J����ƫh���i������
	        if (!this.Validate()) {
	            return;
	        }

	        $.ajax({
	            type: "POST",
	            url: "/MVC/api/StaticPages/ActionLogin",
	            async: true,
	            data: { "account": RsaEncrypt(this.Account()), "password": RsaEncrypt(this.Password()) },
	            dataType: "json",
	            success: function (data) {
	                switch (data.ResultCode) {
	                    // �n�J���\
	                    case 1:
                            location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step02' + location.search;;
	                        break;
	                    // �w�n�J
	                    case 30:
                            location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01' + location.search;;
	                        break;
	                    // ���e
	                    case 19:
                            self.IsRun = false;
	                        if (confirm(data.ResultMsg)) {
	                            self.ReLogin();
	                        }
	                        break;
	                    case 98:
	                    case 99:
                        // �D���ʭ����U�|��
	                    case 1000:
	                    default:
	                        alert(data.ResultMsg);
                            self.IsRun = false;
	                        break;
	                }
	            },
	            error: function (e) {
	                //alert("error:" + e.responseText);
	            },
	            complete: function () {
	                
	            }
	        });
	    }
        
	    // ���e
	    ReLogin(): void {
	        if (this.IsRun) { return; }

	        this.IsRun = true;

	        var self = this;

	        if (!this.Validate()) {
	            return;
	        }

	        $.ajax({
	            type: "POST",
	            url: "/MVC/api/StaticPages/ActionReLogin",
	            async: true,
	            dataType: "json",
	            success: function (data) {
                    switch (data.ResultCode) {
	                    // �n�J���\
	                    case 1:
                            location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step02' + location.search;;
	                        break;
	                    default:
	                        alert(data.ResultMsg);
	                        self.IsRun = false;
	                        break;
	                }
	            },
	            error: function (e) {
	                //alert("error:" + e.responseText);
	            }
	        });
	    }

        // �n�J����
	    Validate(): bool {
	        if (this.Account().length == 0) {
	            alert($SGT.Message.CallForLogin.Validate[0]);
	            return false;
	        }

	        if (this.Password().length == 0) {
	            alert($SGT.Message.CallForLogin.Validate[1]);
	            return false;
	        }

	        return true;
	    }
    }
}
