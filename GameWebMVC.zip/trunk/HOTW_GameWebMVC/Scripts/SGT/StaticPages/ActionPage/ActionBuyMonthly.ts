﻿declare var $: any;
declare var ko: any;
declare var GetPlatform: any;
declare var OpenLink: any;

module SGT.StaticPages {

    export class ActionBuyMonthly {

        platform: string = "Web";

        ResultCode: (input?: number) => number = ko.observable(1);

        constructor() {
            this.PageLoad();
        }

        PageLoad(): void {

            var self = this;

            if (typeof GetPlatform == "function") {
                this.platform = GetPlatform();
            }

            //$.ajax({
            //    type: "POST",
            //    url: "/MVC/api/HotActive/NewMonthPaymentDiscountCheck",
            //    async: false,
            //    data: { Platform: this.platform },
            //    dataType: "JSON",
            //    success: function (data) {
            //        self.ResultCode(data.Result.ResultCode);
            //    },
            //    error: function (e) {
            //    },
            //    complete: function () {
            //    }
            //});
        }

        NewMonthPaymentDiscountCheck(): void {

            var self = this;

            var _ResultMsg;

            //$.ajax({
            //    type: "POST",
            //    url: "/MVC/api/HotActive/NewMonthPaymentDiscountCheck",
            //    async: false,
            //    data: { Platform: this.platform },
            //    dataType: "JSON",
            //    success: function (data) {
            //        self.ResultCode(data.Result.ResultCode);
            //    },
            //    error: function (e) {
            //    },
            //    complete: function () {
            //    }
            //});

            switch (this.ResultCode()) {
                case -1:
                    _ResultMsg = "請先登入遊戲帳號！";
                    break;
                case 0:
                    _ResultMsg = "此帳號符合活動條件！";
                    break;
                case 1:
                    _ResultMsg = "活動已經結束囉！";
                    break;
                case 2:
                    _ResultMsg = "此帳號不符合活動條件。原因：未通過手機驗證。";
                    break;
                case 3:
                    _ResultMsg = "此帳號不符合活動條件。原因：此帳號曾購買過包月。";
                    break;
                case 4:
                    _ResultMsg = "此帳號不符合活動條件。原因：同手機驗證之相關帳號已選購過包月。";
                    break;
                case 5:
                    _ResultMsg = "此帳號不符合活動條件。原因：您尚未具備普卡資格，請先儲值升級享有更多優惠喔！";
                    break;
                case 6:
                    _ResultMsg = "此帳號不符合活動條件。原因：您已有包月首購半價交易正在進行中！";
                    break;
                default:
                    _ResultMsg = "此帳號不符合活動條件。";
                    break;
            }

            if (this.ResultCode() != -1) {

                alert(_ResultMsg);

                location.reload();

            } else {
                if (this.platform != "FB") {
                    OpenLink('/mvc/StaticPages/web/ActionPage/ActionNoviceLucky/Iframe');

                    return;
                } else {
                    alert(_ResultMsg);

                    location.reload();
                }
            }

            return;
        }
    }
}