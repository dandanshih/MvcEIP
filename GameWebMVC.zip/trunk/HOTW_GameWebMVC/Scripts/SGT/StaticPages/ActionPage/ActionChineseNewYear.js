﻿var SGT;
(function (SGT) {
    (function (StaticPages) {
        var ActionChineseNewYear = (function () {
            function ActionChineseNewYear() {
                this.platform = "Web";
                this.ResultCode = ko.observable(-1);
                if(typeof GetPlatform == "function") {
                    this.platform = GetPlatform();
                }
            }
            ActionChineseNewYear.prototype.Check = function () {
                var self = this;
                var _ResultMsg = "";
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/HotActive/ActionChineseNewYearCheck",
                    async: false,
                    data: {
                        Platform: this.platform
                    },
                    dataType: "JSON",
                    success: function (data) {
                        self.ResultCode(data.Result.ResultCode);
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
                switch(this.ResultCode()) {
                    case -1:
                        _ResultMsg = "請先登入遊戲帳號！";
                        break;
                    case 1:
                        _ResultMsg = "您尚未成為普卡以上會員！";
                        break;
                    case 2:
                        _ResultMsg = "您本週的發財金補幣點數為6,666點。";
                        break;
                    case 3:
                        _ResultMsg = "您本週的發財金補幣點數為666點。";
                        break;
                    case 4:
                        _ResultMsg = "活動已經結束囉！";
                        break;
                    default:
                        _ResultMsg = "活動已經結束囉！";
                        break;
                }
                if(this.ResultCode() != -1) {
                    alert(_ResultMsg);
                } else {
                    if(this.platform != "FB" && this.platform != "Online113") {
                        OpenLink('/mvc/StaticPages/web/ActionPage/ActionNoviceLucky/Iframe');
                        return;
                    } else {
                        alert(_ResultMsg);
                    }
                }
                return;
            };
            return ActionChineseNewYear;
        })();
        StaticPages.ActionChineseNewYear = ActionChineseNewYear;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
