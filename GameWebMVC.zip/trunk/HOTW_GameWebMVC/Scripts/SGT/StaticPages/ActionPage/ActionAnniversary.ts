﻿declare var $;
declare var ko;
declare var GetPlatform;
declare var changeDiv2;
module SGT.StaticPages {

    export class DataFromat {
        RankNo: number = 0;
        NickName: string = "";
        TotalScore: number = 0;
        GetJP:number=0;
    }

    export class ActionAnniversary {
        Date: (input?: string) => string = ko.observable("");
        Data: (input?: DataFromat[]) => DataFromat[] = ko.observableArray([]);
        getTagNumber: (input?: number) => number = ko.observable(1);
        
        constructor() {
            var self = this;
            self.Date(self.GetNewDate());
            $(function () {             
                switch (self.Date()) {
                    case "E201309050011":
                        self.getTagNumber(1);
                        self.ClickTag(1);          
                        break;
                    case "E201309050012":
                        self.getTagNumber(2);
                        self.ClickTag(2);              
                        break;
                    default:
                        self.ClickTag(1);
                }
            });

        }
     
    

        //取現在時段
        public GetNewDate(): string {
            var EventID = "";
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: {
                    EventGroupID: 3,
                },
                url: '/MVC/api/HotActive/GetEventInfoListByEventGroupID',
                async: false,
                success: function (data) {                
                    //EventID = data.Result.ResultEventID;
                    EventID = "E201309050012";
                },
                error: function (ex) {
                }
            });
            return EventID;
        }

        //綁資料
        public BindData(EventID: string): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: {
                    Platform: platform,
                    EventID: EventID,
                    Type: 0,
                    RankType:2
                },
                url: '/MVC/api/HotActive/GetElectronicsWinPointsDarenPointsRace',
                async: false,
                success: function (data) {
                    self.Data(data.Result.Data);
                },
                error: function (ex) {
                }
            });
        }

        //點擊
        public ClickTag(tagNumber: number): void {
            var self = this;
            if (self.Date() == "E201309050011" ) {
                switch (tagNumber) {
                    case 1:
                        self.BindData("E201309050011");
                        changeDiv2(tagNumber);
                        break;
                    case 2:
                        alert("活動尚未開始");
                        changeDiv2(1);
                        break;
                }
            } else if (self.Date() == "E201309050012") {
             
                switch (tagNumber) {
                    case 1:
                        self.BindData("E201309050011");
                        changeDiv2(tagNumber);
                        break;
                    case 2:
                        self.BindData("E201309050012");
                        changeDiv2(tagNumber);
                        break;
                }
            }
        }      
    }
}
