﻿var SGT;
(function (SGT) {
    (function (StaticPages) {
        var DataFromat = (function () {
            function DataFromat() {
                this.RankNo = 0;
                this.NickName = "";
                this.TotalScore = 0;
                this.GetJP = 0;
            }
            return DataFromat;
        })();
        StaticPages.DataFromat = DataFromat;        
        var ActionAnniversary = (function () {
            function ActionAnniversary() {
                this.Date = ko.observable("");
                this.Data = ko.observableArray([]);
                this.getTagNumber = ko.observable(1);
                var self = this;
                self.Date(self.GetNewDate());
                $(function () {
                    switch(self.Date()) {
                        case "E201309050011":
                            self.getTagNumber(1);
                            self.ClickTag(1);
                            break;
                        case "E201309050012":
                            self.getTagNumber(2);
                            self.ClickTag(2);
                            break;
                        default:
                            self.ClickTag(1);
                    }
                });
            }
            ActionAnniversary.prototype.GetNewDate = function () {
                var EventID = "";
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        EventGroupID: 3
                    },
                    url: '/MVC/api/HotActive/GetEventInfoListByEventGroupID',
                    async: false,
                    success: function (data) {
                        EventID = "E201309050012";
                    },
                    error: function (ex) {
                    }
                });
                return EventID;
            };
            ActionAnniversary.prototype.BindData = function (EventID) {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        EventID: EventID,
                        Type: 0,
                        RankType: 2
                    },
                    url: '/MVC/api/HotActive/GetElectronicsWinPointsDarenPointsRace',
                    async: false,
                    success: function (data) {
                        self.Data(data.Result.Data);
                    },
                    error: function (ex) {
                    }
                });
            };
            ActionAnniversary.prototype.ClickTag = function (tagNumber) {
                var self = this;
                if(self.Date() == "E201309050011") {
                    switch(tagNumber) {
                        case 1:
                            self.BindData("E201309050011");
                            changeDiv2(tagNumber);
                            break;
                        case 2:
                            alert("活動尚未開始");
                            changeDiv2(1);
                            break;
                    }
                } else if(self.Date() == "E201309050012") {
                    switch(tagNumber) {
                        case 1:
                            self.BindData("E201309050011");
                            changeDiv2(tagNumber);
                            break;
                        case 2:
                            self.BindData("E201309050012");
                            changeDiv2(tagNumber);
                            break;
                    }
                }
            };
            return ActionAnniversary;
        })();
        StaticPages.ActionAnniversary = ActionAnniversary;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
