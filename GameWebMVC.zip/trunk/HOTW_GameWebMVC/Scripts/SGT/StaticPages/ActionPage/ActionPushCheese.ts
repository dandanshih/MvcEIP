declare var $: any;
declare var ko: any;
declare var GetPlatform: any;

module SGT.StaticPages {

    export class PushTheCaskActiveDataStruct {
        RankNo: number = 0;
        NickName: string = "";
        RankTimes: number = 0;
        RankValue: number = 0;

        //RankNo2: number = 0;
        //NickName2: string = "";
        //RankTimes2: number = 0;
        //RankValue2: number = 0;
    }

    export class ActionPushCheese {

        platform: string = "Web";

        ArrayList1: (input?: PushTheCaskActiveDataStruct[]) => PushTheCaskActiveDataStruct[] = ko.observableArray([]);

        ArrayList2: (input?: PushTheCaskActiveDataStruct[]) => PushTheCaskActiveDataStruct[] = ko.observableArray([]);

        constructor() {
            this.PageLoad();
        }

        PageLoad(): void {
            if (typeof GetPlatform == "function") {
                this.platform = GetPlatform();
            }
        }

        GetPushTheCaskActiveData(EventID: string, Type: number, RankType: number, PageSize: number, PageIndex: number): void {
            var self = this;
            $.ajax({
                type: "POST",
                url: "/MVC/api/HotActive/GetPushTheCaskActiveData",
                async: false,
                data: { Platform: this.platform, EventID: EventID, Type: Type, RankType: RankType, PageSize: PageSize, PageIndex: PageIndex },
                dataType: "JSON",
                success: function (data) {
                    if (data.Result.Data != null) {
                        if (RankType == 1) {
                            self.ArrayList1(data.Result.Data);
                        } else if (RankType == 2) {
                            self.ArrayList2(data.Result.Data);
                        }
                    }
                },
                error: function (e) {
                },
                complete: function () {
                }
            });
        }
    }
}