var SGT;
(function (SGT) {
    (function (StaticPages) {
        var PushTheCaskActiveDataStruct = (function () {
            function PushTheCaskActiveDataStruct() {
                this.RankNo = 0;
                this.NickName = "";
                this.RankTimes = 0;
                this.RankValue = 0;
            }
            return PushTheCaskActiveDataStruct;
        })();
        StaticPages.PushTheCaskActiveDataStruct = PushTheCaskActiveDataStruct;        
        var ActionPushCheese = (function () {
            function ActionPushCheese() {
                this.platform = "Web";
                this.ArrayList1 = ko.observableArray([]);
                this.ArrayList2 = ko.observableArray([]);
                this.PageLoad();
            }
            ActionPushCheese.prototype.PageLoad = function () {
                if(typeof GetPlatform == "function") {
                    this.platform = GetPlatform();
                }
            };
            ActionPushCheese.prototype.GetPushTheCaskActiveData = function (EventID, Type, RankType, PageSize, PageIndex) {
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/HotActive/GetPushTheCaskActiveData",
                    async: false,
                    data: {
                        Platform: this.platform,
                        EventID: EventID,
                        Type: Type,
                        RankType: RankType,
                        PageSize: PageSize,
                        PageIndex: PageIndex
                    },
                    dataType: "JSON",
                    success: function (data) {
                        if(data.Result.Data != null) {
                            if(RankType == 1) {
                                self.ArrayList1(data.Result.Data);
                            } else if(RankType == 2) {
                                self.ArrayList2(data.Result.Data);
                            }
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            return ActionPushCheese;
        })();
        StaticPages.ActionPushCheese = ActionPushCheese;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
