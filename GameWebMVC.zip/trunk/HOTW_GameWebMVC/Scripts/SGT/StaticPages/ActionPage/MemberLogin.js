var SGT;
(function (SGT) {
    (function (StaticPages) {
        var MemberLogin = (function () {
            function MemberLogin(callBack) {
                this.IsRun = false;
                this.Account = ko.observable("");
                this.Password = ko.observable("");
                this.CallBack = callBack;
            }
            MemberLogin.prototype.ReLogin = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                if(!this.Validate()) {
                    return;
                }
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/ReLogin",
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 1:
                                if(self.CallBack) {
                                    self.CallBack();
                                }
                                break;
                            default:
                                alert(data.ResultMsg);
                                self.IsRun = false;
                                break;
                        }
                    },
                    error: function (e) {
                        self.IsRun = false;
                    }
                });
            };
            MemberLogin.prototype.Validate = function () {
                if(this.Account().length == 0) {
                    alert($SGT.Message.CallForLogin.Validate[0]);
                    return false;
                }
                if(this.Password().length == 0) {
                    alert($SGT.Message.CallForLogin.Validate[1]);
                    return false;
                }
                return true;
            };
            MemberLogin.prototype.Login = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                if(!this.Validate()) {
                    return;
                }
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/Login",
                    async: false,
                    data: {
                        "account": RsaEncrypt(self.Account()),
                        "password": RsaEncrypt(self.Password())
                    },
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 1:
                            case 30:
                                if(self.CallBack) {
                                    self.CallBack();
                                }
                                break;
                            case 19:
                                if(confirm(data.ResultMsg)) {
                                    self.IsRun = false;
                                    self.ReLogin();
                                } else {
                                    self.IsRun = false;
                                }
                                break;
                            default:
                                alert(data.ResultMsg);
                                self.IsRun = false;
                                break;
                        }
                    },
                    error: function (e) {
                        self.IsRun = false;
                    },
                    complete: function () {
                    }
                });
            };
            MemberLogin.prototype.CommunityLogin = function (communityType, isIframe) {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                var doc = isIframe ? parent.document : document;
                var form = doc.createElement("form");
                form["name"] = "payForm";
                form["method"] = "post";
                form["action"] = '/Mvc/CWLogin/ActionCommunityLogin';
                form["target"] = "_self";
                var ele = doc.createElement("input");
                ele["name"] = "submitButton";
                ele["value"] = communityType;
                ele["hidden"] = true;
                ele["type"] = 'hidden';
                form.appendChild(ele);
                doc.body.appendChild(form);
                doc.forms[doc.forms.length - 1]["submit"]();
            };
            return MemberLogin;
        })();
        StaticPages.MemberLogin = MemberLogin;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
