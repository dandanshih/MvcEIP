declare var SGT;
declare var $SGT;
declare var $;
declare var ko;

module SGT.StaticPages {

    // �Ʀ�]
    export class RankByWin {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (koName: string = 'RankByWin') {
            this.KoName = koName;
            this.GetRank();
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // ���m�]���
        RankList1 = ko.observableArray([]);
        // �Ӥ��]���
        RankByWin1 = ko.observableArray([]);
        // Ĺ���]���
        RankByWin2 = ko.observableArray([]);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        private GetRank(): void {
            var self = this;

            $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetRankByJP.ashx?callback=?', { Data: "1#@$100" }, function (data) {
                self.RankList1(data.RankList);
            });

            $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetRankByWin.ashx?callback=?', { Data: 1 }, function (data) {
                self.RankByWin1(data.Data);
            });

            $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetRankByWin.ashx?callback=?', { Data: 2 }, function (data) {
                self.RankByWin2(data.Data);
            });
        }
    }

}
