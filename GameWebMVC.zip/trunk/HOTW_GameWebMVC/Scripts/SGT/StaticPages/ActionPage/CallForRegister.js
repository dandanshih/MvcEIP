var SGT;
(function (SGT) {
    (function (StaticPages) {
        var CallForRegister = (function () {
            function CallForRegister(koName) {
                if (typeof koName === "undefined") { koName = 'CallForRegister'; }
                this.KoName = '';
                this.IsRun = false;
                this.Account = ko.observable("");
                this.Password = ko.observable("");
                this.PasswordConfirm = ko.observable("");
                this.Mobile = ko.observable("");
                this.Agree = ko.observable(false);
                this.AccountMsg = ko.observable("");
                this.PasswordMsg = ko.observable($SGT.Message.CallForRegister.PasswordValidate[5]);
                this.PasswordConfirmMsg = ko.observable("");
                this.MobileMsg = ko.observable("");
                this.AgreeMsg = ko.observable("");
                this.KoName = koName;
                this.Ad = new SGT.Utilities.ADManagement();
            }
            CallForRegister.prototype.ToLogin = function () {
                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01_2a' + location.search;
            };
            CallForRegister.prototype.Register = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                var appName = getParameter("Type");
                var self = this;
                if(!this.AccountValidate() || !this.PasswordValidate() || !this.PasswordConfirmValidate() || !this.MobileValidate() || !this.AgreeValidate()) {
                    this.IsRun = false;
                    return;
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/ActionRegister/" + appName,
                    async: true,
                    data: {
                        "MemberAccount": self.Account(),
                        "MemberPassword": self.Password(),
                        "Mobile": self.Mobile()
                    },
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 0:
                                self.Ad.UpdateCount(1);
                                location.href = "/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01_2b" + location.search;
                                break;
                            case 200:
                                alert(data.ResultMsg);
                                location.href = "/MVC";
                                break;
                            case 300:
                                location.href = "/MVC";
                                break;
                            default:
                                alert(data.ResultMsg);
                                self.IsRun = false;
                                break;
                        }
                    },
                    error: function (e) {
                        self.IsRun = false;
                    },
                    complete: function () {
                    }
                });
            };
            CallForRegister.prototype.Logout = function () {
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/Logout",
                    async: true,
                    dataType: "json",
                    success: function (data) {
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            CallForRegister.prototype.Reset = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                this.Account("");
                this.Password("");
                this.PasswordConfirm("");
                this.Mobile("");
                this.Agree(false);
                this.AccountMsg("");
                this.PasswordMsg($SGT.Message.CallForRegister.PasswordValidate[0]);
                this.PasswordConfirmMsg("");
                this.MobileMsg("");
                this.AgreeMsg("");
                var passwdBar = document.getElementById('passwdBar');
                if(passwdBar != null) {
                    ResetBar();
                }
                this.IsRun = false;
            };
            CallForRegister.prototype.AccountValidate = function () {
                var self = this;
                var valFlag = false;
                if(this.Account() == "") {
                    this.AccountMsg($SGT.Message.CallForRegister.AccountValidate[0]);
                } else if(!this.Account().match(/^[0-9a-zA-Z]{6,12}$/)) {
                    this.AccountMsg($SGT.Message.CallForRegister.AccountValidate[1]);
                } else if(!this.Account().match(/(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$/)) {
                    this.AccountMsg($SGT.Message.CallForRegister.AccountValidate[2]);
                } else if((this.Account().indexOf(this.Password()) > -1 && this.Password() != "") || (this.Account().indexOf(this.Mobile()) > -1 && this.Mobile() != "")) {
                    this.AccountMsg($SGT.Message.CallForRegister.AccountValidate[3]);
                } else {
                    $.ajax({
                        type: "POST",
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        async: false,
                        data: "CheckType=1&CheckData=" + this.Account(),
                        success: function (data) {
                            self.AccountMsg(data);
                            if(data != $SGT.Message.CallForRegister.AccountValidate[4]) {
                                valFlag = true;
                            }
                        },
                        error: function (e) {
                        }
                    });
                }
                return valFlag;
            };
            CallForRegister.prototype.PasswordValidate = function () {
                var passwdBar = document.getElementById('passwdBar');
                if(passwdBar != null) {
                    ResetBar();
                }
                if(this.Password() == "") {
                    this.PasswordMsg($SGT.Message.CallForRegister.PasswordValidate[1]);
                    return false;
                }
                if(!this.Password().match(/^[0-9a-zA-Z]{6,12}$/)) {
                    this.PasswordMsg($SGT.Message.CallForRegister.PasswordValidate[0]);
                    return false;
                }
                if(this.Password().match(/^[0-9]{6,12}$/)) {
                    this.PasswordMsg($SGT.Message.CallForRegister.PasswordValidate[2]);
                    return false;
                }
                var CompareString = '';
                for(i = 0; i < this.Password().length; i++) {
                    if(CompareString.indexOf(this.Password().charAt(i)) == -1) {
                        CompareString += this.Password().charAt(i);
                    }
                }
                if(CompareString.length < 4) {
                    this.PasswordMsg($SGT.Message.CallForRegister.PasswordValidate[3]);
                    return false;
                }
                if((this.Password().indexOf(this.Account()) > -1 && this.Account() != "") || (this.Password().indexOf(this.Mobile()) > -1 && this.Mobile() != "")) {
                    this.PasswordMsg($SGT.Message.CallForRegister.PasswordValidate[4]);
                    return false;
                }
                var sPW = this.Password().toLowerCase();
                for(var i = 0; i < sPW.length; i++) {
                    var code = sPW.charCodeAt(i);
                    var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
                    var code2 = '' + code + (code + 1) + (code + 2);
                    var code3 = '' + code + (code - 1) + (code - 2);
                    if(sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                        this.PasswordMsg($SGT.Message.CallForRegister.PasswordValidate[5]);
                        return false;
                    }
                }
                if(passwdBar != null) {
                    var ctl = document.getElementById("password");
                    CreateRatePasswdReq(ctl);
                }
                this.PasswordMsg('<img src="' + SGT.WebSiteInfo.Urls.CdnUrl + '/Html/Images/Layout/main_content/member/yes.jpg">');
                return true;
            };
            CallForRegister.prototype.PasswordConfirmValidate = function () {
                if(this.PasswordConfirm() == "") {
                    this.PasswordConfirmMsg($SGT.Message.CallForRegister.PasswordConfirmValidate[0]);
                    return false;
                }
                if(this.Password() != this.PasswordConfirm()) {
                    this.PasswordConfirmMsg($SGT.Message.CallForRegister.PasswordConfirmValidate[1]);
                    return false;
                }
                this.PasswordConfirmMsg('<img src="' + SGT.WebSiteInfo.Urls.CdnUrl + '/Html/Images/Layout/main_content/member/yes.jpg">');
                return true;
            };
            CallForRegister.prototype.MobileValidate = function () {
                var self = this;
                var valFlag = true;
                if(this.Mobile() == "") {
                    this.MobileMsg($SGT.Message.CallForRegister.MobileValidate[0]);
                    return false;
                }
                if(!this.Mobile().match(/^[09]{2}[0-9]{8}$/)) {
                    this.MobileMsg($SGT.Message.CallForRegister.MobileValidate[1]);
                    valFlag = false;
                } else if((this.Mobile().indexOf(this.Account()) > -1 && this.Account() != "") || (this.Mobile().indexOf(this.Password()) > -1 && this.Password() != "")) {
                    this.MobileMsg($SGT.Message.CallForRegister.MobileValidate[2]);
                    valFlag = false;
                } else {
                    $.ajax({
                        type: "POST",
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        async: false,
                        data: "CheckType=3&CheckData=" + this.Mobile(),
                        success: function (data) {
                            self.MobileMsg(data);
                            valFlag = (data.substr(0, 4) == '<img');
                        },
                        error: function (e) {
                            valFlag = false;
                        }
                    });
                }
                return valFlag;
            };
            CallForRegister.prototype.AgreeValidate = function () {
                if(this.Agree() == false) {
                    this.AgreeMsg($SGT.Message.CallForRegister.AgreeValidate[0]);
                    return false;
                }
                this.AgreeMsg("");
                return true;
            };
            return CallForRegister;
        })();
        StaticPages.CallForRegister = CallForRegister;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
