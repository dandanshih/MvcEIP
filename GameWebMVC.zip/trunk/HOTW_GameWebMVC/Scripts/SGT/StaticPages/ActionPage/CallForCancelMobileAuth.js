var SGT;
(function (SGT) {
    (function (StaticPages) {
        var CallForCancelMobileAuth = (function () {
            function CallForCancelMobileAuth(koName) {
                if (typeof koName === "undefined") { koName = 'CallForCancelMobileAuth'; }
                this.KoName = '';
                this.IsRun = false;
                this.KoName = koName;
            }
            CallForCancelMobileAuth.prototype.BackMobileAuth = function () {
                location.href = '/MVC/StaticPages/Web/ActionPage/ActionCallFor/step01_2b' + location.search;
            };
            CallForCancelMobileAuth.prototype.CancelMobileAuth = function () {
                if(this.IsRun) {
                    return;
                }
                this.IsRun = true;
                var self = this;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/CancelMobileAuthentication",
                    async: true,
                    data: "",
                    dataType: "json",
                    success: function (data) {
                        alert(data.ResultMsg);
                        if(data.ResultCode == 0) {
                            self.FreeAutoLogin();
                        } else {
                            location.href = '/MVC';
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            CallForCancelMobileAuth.prototype.FreeAutoLogin = function () {
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/StaticPages/AutoLogin",
                    async: true,
                    data: "",
                    dataType: "json",
                    success: function (data) {
                        location.href = '/MVC';
                    },
                    error: function (e) {
                    }
                });
            };
            return CallForCancelMobileAuth;
        })();
        StaticPages.CallForCancelMobileAuth = CallForCancelMobileAuth;        
    })(SGT.StaticPages || (SGT.StaticPages = {}));
    var StaticPages = SGT.StaticPages;
})(SGT || (SGT = {}));
