var SGT;
(function (SGT) {
    (function (Utilities) {
        var Cycle = (function () {
            function Cycle() {
                this.TargetSelector = '';
                this.Speed = 5000;
                this.EndWaitTime = 0;
                this.Src = [];
                this.IsHover = false;
                this.HoverSelector = '';
                this.MouseOverSrc = '';
                this.TimerHandle = null;
                this.ImageArray = [];
                this.ImageIndex = 0;
            }
            Cycle.prototype.Init = function () {
                for(var i = 0, max = this.Src.length; i < max; i++) {
                    var tmpImg = new Image();
                    tmpImg.src = this.Src[i];
                    this.ImageArray.push(tmpImg);
                }
                if(this.MouseOverSrc) {
                    var tmpImg = new Image();
                    tmpImg.src = this.MouseOverSrc;
                    this.ImageArray.push(tmpImg);
                }
                this.HoverSelector = this.HoverSelector ? this.HoverSelector : this.TargetSelector;
                var self = this;
                if(self.IsHover && self.HoverSelector) {
                    $(self.HoverSelector).bind('mouseover', function () {
                        self.Stop();
                        if(self.MouseOverSrc) {
                            $(self.TargetSelector).attr('src', self.MouseOverSrc);
                        }
                    });
                    $(self.HoverSelector).bind('mouseout', function () {
                        self.Start();
                    });
                }
                self.Start();
            };
            Cycle.prototype.TimePcs = function () {
                if(this.Src.length == 0) {
                    return;
                }
                var self = this;
                if((self.ImageIndex + 1) >= this.Src.length) {
                    self.ImageIndex = -1;
                    if(this.EndWaitTime) {
                        this.TimerHandle = setTimeout(function () {
                            self.TimePcs();
                        }, this.EndWaitTime);
                        return;
                    }
                }
                $(this.TargetSelector).attr('src', this.Src[++self.ImageIndex]);
                this.TimerHandle = setTimeout(function () {
                    self.TimePcs();
                }, this.Speed);
            };
            Cycle.prototype.Start = function () {
                var self = this;
                $(self.TargetSelector).attr('src', self.Src[self.ImageIndex]);
                self.TimerHandle = setTimeout(function () {
                    self.TimePcs();
                }, self.Speed);
            };
            Cycle.prototype.Stop = function () {
                if(this.TimerHandle != null) {
                    window.clearTimeout(this.TimerHandle);
                }
            };
            return Cycle;
        })();
        Utilities.Cycle = Cycle;        
    })(SGT.Utilities || (SGT.Utilities = {}));
    var Utilities = SGT.Utilities;
})(SGT || (SGT = {}));
