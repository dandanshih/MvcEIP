declare var $;
//declare var SGT;

module SGT.Global {
    export class PopIframeMgr{
        static Obj = null;
        static PopIframes: Object = {};
        static BodyMask = null;
        static Add(CtlID: string) : void {
            if (this.PopIframes[CtlID]) {
                return;
            }
            this.PopIframes[CtlID] = new SGT.Global.PopIframe(CtlID);
        }
        static Remove(CtlID: string) : void {
            if (this.PopIframes[CtlID].IsSource) {
                $('#' + CtlID).html('').css({ 'visibility': 'hidden' });
            } else {
                this.PopIframes[CtlID].Iframe.contentWindow.document.write("");
                document.forms[0].removeChild(this.PopIframes[CtlID].Ctl);
                this.PopIframes[CtlID].Ctl = null;
                delete this.PopIframes[CtlID];
                if (this.BodyMask != null) {
                    document.body.removeChild(this.BodyMask);
                }
            }
        }
        static RemoveAll(): void {
            for (var c in this.PopIframes) {
                document.forms[0].removeChild(this.PopIframes[c].Ctl);
                delete this.PopIframes[c];
            }
            this.Obj = null;
            if (this.BodyMask != null) {
                document.body.removeChild(this.BodyMask);
            }
        }
        static UseObject(CtlID): void {
            this.Obj = this.PopIframes[CtlID];
        }
        static AllMaskHide(): void {
            for (var objID in this.PopIframes) {
                this.PopIframes[objID].MaskHide();
            }
        }
        static AllMaskShow(): void {
            for (var objID in this.PopIframes) {
                this.PopIframes[objID].MaskShow();
            }
        }
        static BodyMaskHide(): void {
            var newMask = document.createElement("div");
            newMask.id = 'BodyMask';
            newMask.style.position = "fixed";
            newMask.style.zIndex = '99';
            var _scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
            var _scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
            newMask.style.height = "100%";
            newMask.style.width = "100%";
            newMask.style.top = "0px";
            newMask.style.left = "0px";
            newMask.style.background = "gray";
            newMask.style.filter = "alpha(opacity=70)";
            newMask.style.opacity = "0.40";
            document.body.appendChild(newMask);
            this.BodyMask = newMask;
        }
    }

    export class PopIframe {
        Ctl = null;
        Iframe = null;
        IframeID = null;
        HasScrollBar: bool = true;
        IsSource: bool = false;

        constructor (CtlID: string) {
            var CtlDiv;
            if (document.getElementById(CtlID) == null) {
                CtlDiv = document.createElement("div");
                document.forms[0].appendChild(CtlDiv);
                CtlDiv.id = CtlID;
            } else {
                this.IsSource = true;
                CtlDiv = document.getElementById(CtlID);
            }

            CtlDiv.style.position = "absolute";
            CtlDiv.style.backgroundColor = "transparent";
            CtlDiv.style.border = "0px";
            CtlDiv.style.visibility = "hidden";
            CtlDiv.style.zIndex = 100;
    
            this.Ctl = CtlDiv;
            this.IframeID = "Iframe_" + CtlID;
        }

        Hide() {
            this.Ctl.style.visibility = "hidden";
        }
        Show() {
        this.Ctl.style.visibility = "visible";
        //this.Ctl.style.zIndex = 1;
        }
        SetScrollBar(bl) {
            this.HasScrollBar = bl;
            if (this.Iframe != null) {
                this.Iframe.scrolling = this.HasScrollBar ? "auto" : "no";
            }
        }
        Load (url, callback) {
            var ifrm;
            if (document.getElementById(this.IframeID) == null) {
                ifrm = document.createElement("iframe");
                ifrm.id = this.IframeID;
            } else {
                ifrm = document.getElementById(this.IframeID);
            }
            ifrm.src = url;
            ifrm.setAttribute("scrolling", this.HasScrollBar ? "auto" : "no");
            ifrm.setAttribute("frameborder", "0");
            ifrm.setAttribute("width", "100%");
            ifrm.setAttribute("height", "100%");
            ifrm.setAttribute("allowtransparency", "true");
            this.Ctl.appendChild(ifrm);
            this.Iframe = ifrm;

            if (callback == undefined || callback == null) {
                return;
            }
            var iframeId = '#' + this.IframeID;
            if ($.browser.msie) {
                // ie �P�_ iframe �O�_���J����
                $(iframeId).bind("readystatechange", function () {
                    if (this.readyState == "complete" || this.readyState == "loaded") {
                        $(iframeId).unbind('readystatechange');
                        callback(ifrm);
                    }
                });
            } else {
                // �䥦�s�����P�_ iframe �O�_���J����
                $(iframeId).bind("load", function () { $(iframeId).unbind('load'); callback(ifrm); });
            }
        }
        Move (x, y, w, h) {
            this.Ctl.style.left = x + 'px';
            this.Ctl.style.top = y + 'px';
            this.Ctl.style.width = w + "px";
            this.Ctl.style.height = h + "px";
        }
        Center(w, h){
            this.Ctl.style.top = "50%";
            this.Ctl.style.position = "absolute";
            this.Ctl.style.left = "50%";
            this.Ctl.style.marginLeft = -(w / 2) + 'px';
            this.Ctl.style.marginTop = -(h / 2) + 'px';
            this.Ctl.style.position = 'fixed';
            this.Ctl.style.zIndex = 100;
            this.Ctl.style.width = w + "px";
            this.Ctl.style.height = h + "px";
        }
        SetLayer(zIndex) {
            this.Ctl.style.zIndex = zIndex;
        }
        MaskShow() {
            try {
                if (this.Iframe.document.getElementById('newMask')) {
                    this.Iframe.document.body.removeChild(this.Iframe.document.getElementById('newMask'));
                }
            }
            catch (e) {
                //alert(e.message);
            }
        }
        MaskHide() {
            var newMask = this.Iframe.document.createElement("div");
            newMask.id = 'newMask';
            newMask.style.position = "absolute";
            newMask.style.zIndex = "1";
            var _scrollWidth = Math.max(this.Iframe.document.body.scrollWidth, this.Iframe.document.documentElement.scrollWidth);
            var _scrollHeight = Math.max(this.Iframe.document.body.scrollHeight, this.Iframe.document.documentElement.scrollHeight);
            newMask.style.width = _scrollWidth + "px";
            newMask.style.height = _scrollHeight + "px";
            newMask.style.top = "0px";
            newMask.style.left = "0px";
            newMask.style.background = "gray"; //"#fff";
            //newMask.style.filter = "alpha(opacity=0)";
            newMask.style.filter = "alpha(opacity=70)";
            newMask.style.opacity = "0.40";
            this.Iframe.document.body.appendChild(newMask);
        }
    }
}