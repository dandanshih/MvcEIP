declare var $;
declare var escape;
declare var unescape;

module SGT.Utilities {
    export class ADManagement {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (appName: string = "") {

            if (appName == "") {
                this.ADType = this.GetQueryString("Type");
            } else {
                this.ADType =  appName
            }

            this.UpdateCount(2);
        }

        // property
        private ADType: string = '';

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // �]�wCookie
        SetCookie(sName: string, sValue: string): void {
            document.cookie = sName + "=" + escape(sValue) + ";";
        }
        
        // ���oCookie����
        GetCookie(sName: string): string {
            var aCookie = document.cookie.split("; ");
            for (var i = 0; i < aCookie.length; i++) {
                var aCrumb = aCookie[i].split("=");
                if (sName == aCrumb[0])
                    return unescape(aCrumb[1]);
            }
            return null;
        }
        
        // ���o���}�Ѽ�
        GetQueryString(parameterName): string {
            var queryString = location.search.substring(1).toLowerCase();
            var parameterName = (parameterName + "=").toLowerCase();

            if (queryString.length > 0) {
                var begin = queryString.indexOf(parameterName);
                if (begin != -1) {
                    begin += parameterName.length;
                    var end = queryString.indexOf("&", begin);
                    if (end == -1) {
                        end = queryString.length
                    }
                    return unescape(queryString.substring(begin, end));
                }
                return null;
            }
        }

        // ��s����
        // �b�DIE�s�����s�� UpdateCount �ɡA�Y����O�쭶����|���椣�� getJSON �o�q�A�ҥH�ϥ� callback �өI�s����{���X
        UpdateCount(eType: number, callback: Function = null): void {
            var self = this;
            var cookieName = 'Ad_' + eType;

            if (this.ADType && self.GetCookie(cookieName) == null) {
                self.SetCookie(cookieName, this.ADType);
                
                $.getJSON(
                    "/Mvc/api/ad/updatecount",
                    { AppName: self.ADType, EType: eType },
                    function (data) {
                        if (callback) {
                            callback();
                        }
                    }
                );
            } else {
                if (callback) {
                    callback();
                }
            }
        }
    }
}