﻿

$SGT.Message =
{
    // 禮物中心記錄
    GiftCenter: {
        Utility: [
            '您的FB幣餘額不足{0}枚！！'
            , '您確定兌換老幣？'
            , '請選擇縣市'
            , '請選擇'
        ],
        Error: [
            '請輸入姓名'
            , '請選擇縣市'
            , '請選擇鄉鎮市'
            , '請輸入寄送地址'
            , '寄送地址格式錯誤'
            , '聯絡電話格式錯誤'
            , '請輸入E-mail'
            , '信箱格式錯誤'
        ]
    },
    AccountChange: {
        Utility: [
            '密碼輸入兩次不同！'
        ]
    },
    EnterNoviceSN: {
        Error: [
            '請輸入序號！'
            , '序號錯誤！'
            , '已領取！'
        ]
    },
    MemberLogin: {
        Validate: [
            "請輸入帳號！"
            , "請輸入密碼！"
        ]
    },
    CallForLogin: {
        Validate: [
            "請輸入帳號！"
            , "請輸入密碼！"
        ]
    },
    CallForRegister: {
        AccountValidate: [
            "帳號不可空白"
            , "帳號必須是 6 ~ 12 碼的英文數字組合"
            , "帳號至少須包含一個英文字母"
            , "帳號中不可包含密碼或手機號碼"
            , "此帳號已有人使用"
        ],
        PasswordValidate: [
            "密碼必須是 6 ~ 12 碼的英文數字組合<br />密碼範例：hi0857"
            , "密碼不可空白<br />密碼範例：hi0857"
            , "密碼至少須包含一個英文字母<br />密碼範例：hi0857"
            , "密碼必須包含4種(含)字元以上<br />密碼範例：hi0857"
            , "密碼中不可包含帳號或手機號碼<br />密碼範例：hi0857"
            , "密碼不可為連續數字或字母<br />密碼範例：hi0857"
        ],
        PasswordConfirmValidate: [
            "確認密碼不可空白"
            , "兩次密碼錯誤"
        ],
        MobileValidate: [
            "手機號碼不可空白"
            , "手機號碼格式錯誤"
            , "手機中不可包含密碼或手機號碼"
        ],
        AgreeValidate: [
            "須同意服務條款"
        ]
    },
    CallForMobileAuth: {
        MobileAuth: [
            "驗證碼正確！恭喜您帳號啟用成功！"
            , "驗證碼逾時！"
            , "驗證碼錯誤！"
        ],
        AutoLogin: [
            "登入資訊不正確！"
            , "遊戲目前進行維護中，請稍後再來玩！"
        ],
        ReSend: [
            "簡訊已送出，請注意您的手機並請儘速啟用帳號。"
            , "驗證碼逾時！"
        ],
        VerificationCodeValidate: [
            "驗證碼不可空白！"
        ]
    },
    CallForUpload: {
        Uploadify: [
            "上傳成功！"
            , "上傳失敗！"
            , "您的身份不符合活動資格！"
            , "您的帳號已通過審核，請勿再次上傳檔案！"
            , "您所選取的檔案超過限制 (10MB)！"
            , "您所選取的檔案格式錯誤！"
            , "請選擇一個圖片上傳！"
        ],
        CheckMember: [
            "請重新登入會員！"
            , "您的帳號已通過審核，請勿再次上傳檔案！"
        ]
    },
    PointBuyBase: {
        Base_Check_ECoupon: [
            "此序號輸入錯誤，請重新確認",
            "未達指定金額",
            "此序號限本人使用",
            "非使用期限",
            "此序號已被鎖定，請聯繫客服人員"
        ],
        Base_Check_Email: [
            "請輸入信箱",
            "信箱格式錯誤"
        ],
        Base_Check_InvoiceName: [
            "請輸入收件人",
            "發票收件人格式錯誤"
        ],
        Base_Check_InvoiceAddress: [
            "請輸入地址",
            "地址格式錯誤"
        ],
        Base_Check_StoreCardSN: [
            "請輸入儲值序號"
        ],
        Base_Check_StoreCardPwd: [
            "請輸入驗證碼"
        ]
    },
    PointBuyOnline: {
        CheckAddress: [
            "請選擇縣市鄉鎮區"
        ],
        CheckAgree: [
            "請先同意購點同意書"
        ],
        ShowMessage: [
            "交易失敗！"
            , "請選擇儲值類型！"
            , "您的儲值額度已達本月上限，請利用其他儲值方式進行儲值，謝謝。"
        ]
    },
    PointBuySN: {
        ShowMessage: [
            "交易失敗！"
            , "請選擇儲值類型！"
            , "請輸入儲值序號！"
            , "請輸入驗證碼！"
            , "您的儲值額度已達本月上限，請利用其他儲值方式進行儲值，謝謝。"
        ]
    },
    PointBuyMonthly: {
        CheckAddress: [
            "請選擇縣市鄉鎮區"
        ],
        CheckAgree: [
            "請先同意購點同意書"
        ],
        ShowMessage: [
            "交易失敗！"
            , "請選擇儲值類型！"
            , "您的儲值額度已達本月上限，請利用其他儲值方式進行儲值，謝謝。"
            , "親愛的會員您好，您已有包月首購半價交易正在進行中，請利用其他儲值方式進行儲值，若有任何疑問，請撥打客服專線04-2236-8000，我們將竭誠為您服務。"
        ]
    },
    TransferOnline: {
        ShowMessage: [
            "交易失敗！"
            , "請選擇儲值類型！"
            , "您的儲值額度已達本月上限，請利用其他儲值方式進行儲值，謝謝。"
        ]
    },
    TransferBase: {
        Base_Submit_MemberTransfer: [
            "轉帳失敗！"
        ],
        Base_Check_Nick: [
            "請輸入對方暱稱",
            "暱稱長度限制為50字元"
        ],
        Base_Check_Point: [
            "請輸入金額",
            "須為正整數",
            "金額超過上限"
        ],
        Base_Check_VerifyCode: [
            "請輸入手機轉帳驗證碼"
        ]
    },
    TransferCenter: {
        GoTransferVerify: [
            "您已成功將老幣 {0} 點轉出給 {1}，<br />若有任何疑問，歡迎撥打客服專線04-2236-8000，<br />我們將竭誠為您服務。<br />",
            "您已成功將老幣 {0} 點轉出給 {1}，<br />若有任何疑問，歡迎撥打客服專線，<br />我們將竭誠為您服務。<br />"
        ]
    }
}
