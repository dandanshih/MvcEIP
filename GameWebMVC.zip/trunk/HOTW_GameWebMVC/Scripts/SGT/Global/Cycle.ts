declare var $;

module SGT.Utilities {

    // �Ϥ������]�w
    export class Cycle {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {
        }

        /// --------------------------------------
        /// property
        /// --------------------------------------
        // �n�������ؼ� img ����
        TargetSelector: string = '';
        // �t��
        Speed: number = 5000;
        // �C���Ϥ����񧹫�ҭn����ɶ�
        EndWaitTime: number = 0;
        // �����Ϥ��}�C
        Src: string[] = [];

        // ���ƹ����L�O�_�������
        IsHover: bool = false;
        // Hover �ƥ�ô�����ؼ�
        HoverSelector: string = '';
        // onmouseover �Ҹm���Ϥ�
        MouseOverSrc: string = '';
        
        // Timer����
        private TimerHandle: number = null;
        // �w���Ϥ��s��}�C
        private ImageArray = [];
        // �ثe�������
        private ImageIndex: number = 0;

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ������l��
        Init(): void {
            // �N�Ϥ����w���J ImageArray
            for (var i = 0, max = this.Src.length; i < max; i++) {
                var tmpImg = new Image();
                tmpImg.src = this.Src[i];
                this.ImageArray.push(tmpImg);
            }

            if (this.MouseOverSrc) {
                var tmpImg = new Image();
                tmpImg.src = this.MouseOverSrc;
                this.ImageArray.push(tmpImg);
            }

            this.HoverSelector = this.HoverSelector ? this.HoverSelector : this.TargetSelector;

            var self = this;
            if (self.IsHover && self.HoverSelector) {
                $(self.HoverSelector).bind('mouseover', function () {
                    self.Stop();

                    if (self.MouseOverSrc) {
                        $(self.TargetSelector).attr('src', self.MouseOverSrc);
                    }
                });

                $(self.HoverSelector).bind('mouseout', function () {
                    self.Start();
                });
            }
            self.Start();
        }

        // ����������D�n�{��
        private TimePcs(): void {
            if (this.Src.length == 0) { return; }

            var self = this;

            if ((self.ImageIndex + 1) >= this.Src.length) {
                self.ImageIndex = -1;

                if (this.EndWaitTime) {
                    this.TimerHandle = setTimeout(function () { self.TimePcs() }, this.EndWaitTime);
                    return;
                }
            }

            $(this.TargetSelector).attr('src', this.Src[++self.ImageIndex]);
            this.TimerHandle = setTimeout(function () { self.TimePcs() }, this.Speed);
        }

        // �Ұʽ���
        private Start(): void {
            var self = this;
            $(self.TargetSelector).attr('src', self.Src[self.ImageIndex]);
            self.TimerHandle = setTimeout(function () { self.TimePcs(); }, self.Speed);
        }

        // �������
        private Stop(): void {
            if (this.TimerHandle != null) { window.clearTimeout(this.TimerHandle); }
        }
    }
}