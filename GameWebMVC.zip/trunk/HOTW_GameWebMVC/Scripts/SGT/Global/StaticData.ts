declare var $;
declare var SGT;
declare var unescape;
declare var escape;

module SGT.Utilities {
    /// --------------------------------------
    /// ���Ѥ��Ϊ��R�A��k
    /// --------------------------------------
    export class StaticData {
        /// --------------------------------------
        /// �s�� MenuStyleChange ���������
        /// --------------------------------------
        static MenuStyle: Object = new Object();

        /// --------------------------------------
        /// �l���Ϥ��ܴ�
        /// tag
        ///      data-menuid: ���ID�A�]�w�� img ����
        ///      data-alterpic: �� selector = data-menuid �ɭn�������Ϥ����|�A�]�w�� img ����
        /// input
        ///      selector: �n�j�M���϶�
        ///      menuid: ���e��ܪ� menu id
        /// --------------------------------------
        static MenuStyleChange(selector: string, menuid: number): void {
            var replaceAttrs: string[] = ['onmouseover', 'onmouseout', 'onmousedown'];
            var root = this;

            // ������ [selector > ul > li > a > img] ���榡�A�קK�_�����]�w���~
            var items = $(selector + " > ul > li > a > img");
            var selectedLen = 0;
            
            if (items.length > 0) {
                if (!root.MenuStyle[selector]) {
                    root.MenuStyle[selector] = new Object();
                }

                items.each(function (index, obj) {
                    var self = $(this);
                    var myid = self.attr('data-menuid');

                    // �S�]�w menuid �h���]
                    if (myid == undefined) {
                        return;
                    }

                    if (!root.MenuStyle[selector][myid]) {
                        root.MenuStyle[selector][myid] = new Object();
                        root.MenuStyle[selector][myid]['src'] = self.attr('src');
                        $.each(replaceAttrs, function (attrIndex, attrObj) {
                            root.MenuStyle[selector][myid][attrObj] = self.attr(attrObj);
                        });
                    }

                    var data = root.MenuStyle[selector][myid];

                    // �O�_�n���
                    if (self.attr("data-menuid") == menuid) {
                        selectedLen++;
                        //selectState = true;

                        self.attr('src', SGT.WebSiteInfo.Urls.CdnUrl + self.attr('data-alterpic'));
                        // �R�����[�ݩ�
                        $.each(replaceAttrs, function (attrIndex, attrObj) { 
                            self.removeAttr(attrObj); 
                        });
                    }
                    else {
                        self.attr('src', data['src']);
                        // �W�[���[�ݩ�
                        $.each(replaceAttrs, function (attrIndex, attrObj) { 
                            self.attr(attrObj, data[attrObj]); 
                        });
                    }
                });

                if (selectedLen > 0) {
                    $(selector).show();
                } else {
                    $(selector).hide();
                }
            }
        }


        /// --------------------------------------
        /// �M�����椺��J���
        /// --------------------------------------
        static ClearField(): void {
            $("input[type=text]").each(function (e) { $(this).val(""); });
            $("input[type=password]").each(function (e) { $(this).val(""); });
            $("input[type=file]").each(function (e) { $(this).val(""); });
            $("input[type=radio]").each(function (e) { $(this).attr("checked", false); });
            $("input[type=checkbox]").each(function (e) { $(this).attr("checked", false); });
            $("select").each(function (e) { $(this).get(0).selectedIndex = 0; });
            $("textarea").each(function (e) { $(this).val(""); });
        }


        /// --------------------------------------
        /// �N GameID �P GroupID �s�X
        /// --------------------------------------
        static GameEncode(gameId: string, groupId: string): string {
            var iRand = 0, iRand2 = 0;
            var GameID16 = parseInt(gameId).toString(16);
            var Result = '';
            iRand = parseInt((Math.random() * 3 + 1).toString());
            iRand2 = parseInt((Math.random() * 9 + 1).toString());
            var arr = GameID16.toString().split("");
            for (var item = 0, max = arr.length; item < max; item++) {
                if (iRand == (item + 1)) {
                    Result += iRand2 + arr[item];
                } else {
                    Result += arr[item];
                }
            }
            Result += iRand;
            Result += '_' + groupId;
            return Result;
        }

        /// --------------------------------------
        /// ���o Get �ѼơA�p�L�ѼƦ^�� null
        /// --------------------------------------
        static GetParameter(ParameterName: string): string {
            var queryString = location.search.substring(1).toLowerCase();
            // Add "=" to the parameter name (i.e. ParameterName=value)
            var ParameterName = (ParameterName + "=").toLowerCase();

            if (queryString.length > 0) {
                // Find the beginning of the string
                var begin: number = queryString.indexOf(ParameterName);
                // If the parameter name is not found, skip it, otherwise return the value
                if (begin != -1) {
                    // Add the length (integer) to the beginning
                    begin += ParameterName.length;
                    // Multiple parameters are separated by the "&" sign
                    var end: number = queryString.indexOf("&", begin);
                    if (end == -1) {
                        end = queryString.length
                    }
                    // Return the string
                    return unescape(queryString.substring(begin, end));
                }
                // Return "null" if no parameter has been found
                return null;
            }
        }
        
        /// --------------------------------------
        /// ���o�ƭȫ��A Get �Ѽ�
        /// --------------------------------------
        static GetQueryInt(QueryName: string, Min: number = 0, Max: number = 99): number {
            var result = Min;

            if (QueryName) {
                var val = GetParameter(QueryName);
                // ���ҬO�_���ƭ�
                result = new window['RegExp'](/^\d+$/).test(val) ? parseInt(val) : Min;
                // ��� Min ~ Max ����
                result = (result >= Min && result <= Max) ? result : Min;
            }

            return result;
        }

        static SetCookie(key: string, value: string): void {
            document.cookie = key + "=" + escape(value) + ";";
        }

        static GetCookie(key: string): string {
            var aCookie = document.cookie.split("; ");
            for (var i = 0; i < aCookie.length; i++) {
                var aCrumb = aCookie[i].split("=");
                if (key == aCrumb[0])
                    return unescape(aCrumb[1]);
            }
            return "";
        }
    }
}
