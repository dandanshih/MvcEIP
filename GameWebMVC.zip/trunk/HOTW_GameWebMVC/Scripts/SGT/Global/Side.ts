declare var $;

module SGT.Utilities {

    // �I���Ϥ��ưʮĪG
    export class Side {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (param: Object) {
            $.extend(this, param);
            this.Initial();
        }
        
        /// --------------------------------------
        /// property
        /// --------------------------------------
        Width: number = 0;
        Height: number = 0;
        Speed: number = 0;
        ParentCtl: any = null;
        
        /// --------------------------------------
        /// function
        /// --------------------------------------
        Initial() {
            var _this = this;
            $(_this.ParentCtl).css({
                width: _this.Width,
                height: _this.Height,
                'min-height': _this.Height,
            });
            $(_this.ParentCtl).find("ul:first");
        }

        Up() {
            var _this = this;
            var _field = $(_this.ParentCtl).find('li:first');
            var _ul = $(_this.ParentCtl).find("ul:first");
            var _li = $(_this.ParentCtl).find('li');
            $(_ul).css({
                height: _this.Height * _li.length,
                width: _this.Width
            });

            _field.animate({ marginTop: -_this.Height + 'px' }, _this.Speed, function () {
                _field.css('marginTop', 0).appendTo(_ul);
            });
        }

        Right() {
            var _this = this;
            var _field = $(_this.ParentCtl).find('li:last');
            var _firstli = $(_this.ParentCtl).find('li:first');
            var _ul = $(_this.ParentCtl).find("ul:first");
            var _li = $(_this.ParentCtl).find('li');
            $(_ul).css({
                height: _this.Height,
                width: _this.Width * _li.length
            });

            _firstli.animate({ marginLeft: _this.Width + 'px' }, _this.Speed, function () {
                _field.css('marginLeft', 0).prependTo(_ul);
                _firstli.css('marginLeft', 0);
            });
        }

        Left() {
            var _this = this;
            var _field = $(_this.ParentCtl).find('li:first');
            var _ul = $(_this.ParentCtl).find("ul:first");
            var _li = $(_this.ParentCtl).find('li');
            $(_ul).css({
                height: _this.Height,
                width: _this.Width * _li.length
            });
            //var MoveSize = this.Height;

            _field.animate({ marginLeft: -_this.Width + 'px' }, _this.Speed, function () {
                _field.css('marginLeft', 0).appendTo(_ul);
            });
        }
    }
}