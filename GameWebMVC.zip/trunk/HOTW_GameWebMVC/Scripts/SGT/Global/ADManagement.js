var SGT;
(function (SGT) {
    (function (Utilities) {
        var ADManagement = (function () {
            function ADManagement(appName) {
                if (typeof appName === "undefined") { appName = ""; }
                this.ADType = '';
                if(appName == "") {
                    this.ADType = this.GetQueryString("Type");
                } else {
                    this.ADType = appName;
                }
                this.UpdateCount(2);
            }
            ADManagement.prototype.SetCookie = function (sName, sValue) {
                document.cookie = sName + "=" + escape(sValue) + ";";
            };
            ADManagement.prototype.GetCookie = function (sName) {
                var aCookie = document.cookie.split("; ");
                for(var i = 0; i < aCookie.length; i++) {
                    var aCrumb = aCookie[i].split("=");
                    if(sName == aCrumb[0]) {
                        return unescape(aCrumb[1]);
                    }
                }
                return null;
            };
            ADManagement.prototype.GetQueryString = function (parameterName) {
                var queryString = location.search.substring(1).toLowerCase();
                var parameterName = (parameterName + "=").toLowerCase();
                if(queryString.length > 0) {
                    var begin = queryString.indexOf(parameterName);
                    if(begin != -1) {
                        begin += parameterName.length;
                        var end = queryString.indexOf("&", begin);
                        if(end == -1) {
                            end = queryString.length;
                        }
                        return unescape(queryString.substring(begin, end));
                    }
                    return null;
                }
            };
            ADManagement.prototype.UpdateCount = function (eType, callback) {
                if (typeof callback === "undefined") { callback = null; }
                var self = this;
                var cookieName = 'Ad_' + eType;
                if(this.ADType && self.GetCookie(cookieName) == null) {
                    self.SetCookie(cookieName, this.ADType);
                    $.getJSON("/Mvc/api/ad/updatecount", {
                        AppName: self.ADType,
                        EType: eType
                    }, function (data) {
                        if(callback) {
                            callback();
                        }
                    });
                } else {
                    if(callback) {
                        callback();
                    }
                }
            };
            return ADManagement;
        })();
        Utilities.ADManagement = ADManagement;        
    })(SGT.Utilities || (SGT.Utilities = {}));
    var Utilities = SGT.Utilities;
})(SGT || (SGT = {}));
