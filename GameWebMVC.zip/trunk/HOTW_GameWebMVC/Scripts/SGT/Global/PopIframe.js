var SGT;
(function (SGT) {
    (function (Global) {
        var PopIframeMgr = (function () {
            function PopIframeMgr() {
            }
            PopIframeMgr.Add = function (CtlID) {
                if (this.PopIframes[CtlID]) {
                    return;
                }
                this.PopIframes[CtlID] = new SGT.Global.PopIframe(CtlID);
            };
            PopIframeMgr.Remove = function (CtlID) {
                if (this.PopIframes[CtlID].IsSource) {
                    $('#' + CtlID).html('').css({ 'visibility': 'hidden' });
                } else {
                    this.PopIframes[CtlID].Iframe.contentWindow.document.write("");
                    document.forms[0].removeChild(this.PopIframes[CtlID].Ctl);
                    this.PopIframes[CtlID].Ctl = null;
                    delete this.PopIframes[CtlID];
                    if (this.BodyMask != null) {
                        document.body.removeChild(this.BodyMask);
                    }
                }
            };
            PopIframeMgr.RemoveAll = function () {
                for (var c in this.PopIframes) {
                    document.forms[0].removeChild(this.PopIframes[c].Ctl);
                    delete this.PopIframes[c];
                }
                this.Obj = null;
                if (this.BodyMask != null) {
                    document.body.removeChild(this.BodyMask);
                }
            };
            PopIframeMgr.UseObject = function (CtlID) {
                this.Obj = this.PopIframes[CtlID];
            };
            PopIframeMgr.AllMaskHide = function () {
                for (var objID in this.PopIframes) {
                    this.PopIframes[objID].MaskHide();
                }
            };
            PopIframeMgr.AllMaskShow = function () {
                for (var objID in this.PopIframes) {
                    this.PopIframes[objID].MaskShow();
                }
            };
            PopIframeMgr.BodyMaskHide = function () {
                var newMask = document.createElement("div");
                newMask.id = 'BodyMask';
                newMask.style.position = "fixed";
                newMask.style.zIndex = '99';
                var _scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
                var _scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
                newMask.style.height = "100%";
                newMask.style.width = "100%";
                newMask.style.top = "0px";
                newMask.style.left = "0px";
                newMask.style.background = "gray";
                newMask.style.filter = "alpha(opacity=70)";
                newMask.style.opacity = "0.40";
                document.body.appendChild(newMask);
                this.BodyMask = newMask;
            };
            PopIframeMgr.Obj = null;
            PopIframeMgr.PopIframes = {};
            PopIframeMgr.BodyMask = null;
            return PopIframeMgr;
        })();
        Global.PopIframeMgr = PopIframeMgr;

        var PopIframe = (function () {
            function PopIframe(CtlID) {
                this.Ctl = null;
                this.Iframe = null;
                this.IframeID = null;
                this.HasScrollBar = true;
                this.IsSource = false;
                var CtlDiv;
                if (document.getElementById(CtlID) == null) {
                    CtlDiv = document.createElement("div");
                    document.forms[0].appendChild(CtlDiv);
                    CtlDiv.id = CtlID;
                } else {
                    this.IsSource = true;
                    CtlDiv = document.getElementById(CtlID);
                }

                CtlDiv.style.position = "absolute";
                CtlDiv.style.backgroundColor = "transparent";
                CtlDiv.style.border = "0px";
                CtlDiv.style.visibility = "hidden";
                CtlDiv.style.zIndex = 100;

                this.Ctl = CtlDiv;
                this.IframeID = "Iframe_" + CtlID;
            }
            PopIframe.prototype.Hide = function () {
                this.Ctl.style.visibility = "hidden";
            };
            PopIframe.prototype.Show = function () {
                this.Ctl.style.visibility = "visible";
            };
            PopIframe.prototype.SetScrollBar = function (bl) {
                this.HasScrollBar = bl;
                if (this.Iframe != null) {
                    this.Iframe.scrolling = this.HasScrollBar ? "auto" : "no";
                }
            };
            PopIframe.prototype.Load = function (url, callback) {
                var ifrm;
                if (document.getElementById(this.IframeID) == null) {
                    ifrm = document.createElement("iframe");
                    ifrm.id = this.IframeID;
                } else {
                    ifrm = document.getElementById(this.IframeID);
                }
                ifrm.src = url;
                ifrm.setAttribute("scrolling", this.HasScrollBar ? "auto" : "no");
                ifrm.setAttribute("frameborder", "0");
                ifrm.setAttribute("width", "100%");
                ifrm.setAttribute("height", "100%");
                ifrm.setAttribute("allowtransparency", "true");
                this.Ctl.appendChild(ifrm);
                this.Iframe = ifrm;

                if (callback == undefined || callback == null) {
                    return;
                }
                var iframeId = '#' + this.IframeID;
                if ($.browser.msie) {
                    $(iframeId).bind("readystatechange", function () {
                        if (this.readyState == "complete" || this.readyState == "loaded") {
                            $(iframeId).unbind('readystatechange');
                            callback(ifrm);
                        }
                    });
                } else {
                    $(iframeId).bind("load", function () {
                        $(iframeId).unbind('load');
                        callback(ifrm);
                    });
                }
            };
            PopIframe.prototype.Move = function (x, y, w, h) {
                this.Ctl.style.left = x + 'px';
                this.Ctl.style.top = y + 'px';
                this.Ctl.style.width = w + "px";
                this.Ctl.style.height = h + "px";
            };
            PopIframe.prototype.Center = function (w, h) {
                this.Ctl.style.top = "50%";
                this.Ctl.style.position = "absolute";
                this.Ctl.style.left = "50%";
                this.Ctl.style.marginLeft = -(w / 2) + 'px';
                this.Ctl.style.marginTop = -(h / 2) + 'px';
                this.Ctl.style.position = 'fixed';
                this.Ctl.style.zIndex = 100;
                this.Ctl.style.width = w + "px";
                this.Ctl.style.height = h + "px";
            };
            PopIframe.prototype.SetLayer = function (zIndex) {
                this.Ctl.style.zIndex = zIndex;
            };
            PopIframe.prototype.MaskShow = function () {
                try  {
                    if (this.Iframe.document.getElementById('newMask')) {
                        this.Iframe.document.body.removeChild(this.Iframe.document.getElementById('newMask'));
                    }
                } catch (e) {
                }
            };
            PopIframe.prototype.MaskHide = function () {
                var newMask = this.Iframe.document.createElement("div");
                newMask.id = 'newMask';
                newMask.style.position = "absolute";
                newMask.style.zIndex = "1";
                var _scrollWidth = Math.max(this.Iframe.document.body.scrollWidth, this.Iframe.document.documentElement.scrollWidth);
                var _scrollHeight = Math.max(this.Iframe.document.body.scrollHeight, this.Iframe.document.documentElement.scrollHeight);
                newMask.style.width = _scrollWidth + "px";
                newMask.style.height = _scrollHeight + "px";
                newMask.style.top = "0px";
                newMask.style.left = "0px";
                newMask.style.background = "gray";

                newMask.style.filter = "alpha(opacity=70)";
                newMask.style.opacity = "0.40";
                this.Iframe.document.body.appendChild(newMask);
            };
            return PopIframe;
        })();
        Global.PopIframe = PopIframe;
    })(SGT.Global || (SGT.Global = {}));
    var Global = SGT.Global;
})(SGT || (SGT = {}));
