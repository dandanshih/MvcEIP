var SGT;
(function (SGT) {
    (function (Utilities) {
        var StaticData = (function () {
            function StaticData() { }
            StaticData.MenuStyle = new Object();
            StaticData.MenuStyleChange = function MenuStyleChange(selector, menuid) {
                var replaceAttrs = [
                    'onmouseover', 
                    'onmouseout', 
                    'onmousedown'
                ];
                var root = this;
                var items = $(selector + " > ul > li > a > img");
                var selectedLen = 0;
                if(items.length > 0) {
                    if(!root.MenuStyle[selector]) {
                        root.MenuStyle[selector] = new Object();
                    }
                    items.each(function (index, obj) {
                        var self = $(this);
                        var myid = self.attr('data-menuid');
                        if(myid == undefined) {
                            return;
                        }
                        if(!root.MenuStyle[selector][myid]) {
                            root.MenuStyle[selector][myid] = new Object();
                            root.MenuStyle[selector][myid]['src'] = self.attr('src');
                            $.each(replaceAttrs, function (attrIndex, attrObj) {
                                root.MenuStyle[selector][myid][attrObj] = self.attr(attrObj);
                            });
                        }
                        var data = root.MenuStyle[selector][myid];
                        if(self.attr("data-menuid") == menuid) {
                            selectedLen++;
                            self.attr('src', SGT.WebSiteInfo.Urls.CdnUrl + self.attr('data-alterpic'));
                            $.each(replaceAttrs, function (attrIndex, attrObj) {
                                self.removeAttr(attrObj);
                            });
                        } else {
                            self.attr('src', data['src']);
                            $.each(replaceAttrs, function (attrIndex, attrObj) {
                                self.attr(attrObj, data[attrObj]);
                            });
                        }
                    });
                    if(selectedLen > 0) {
                        $(selector).show();
                    } else {
                        $(selector).hide();
                    }
                }
            };
            StaticData.ClearField = function ClearField() {
                $("input[type=text]").each(function (e) {
                    $(this).val("");
                });
                $("input[type=password]").each(function (e) {
                    $(this).val("");
                });
                $("input[type=file]").each(function (e) {
                    $(this).val("");
                });
                $("input[type=radio]").each(function (e) {
                    $(this).attr("checked", false);
                });
                $("input[type=checkbox]").each(function (e) {
                    $(this).attr("checked", false);
                });
                $("select").each(function (e) {
                    $(this).get(0).selectedIndex = 0;
                });
                $("textarea").each(function (e) {
                    $(this).val("");
                });
            };
            StaticData.GameEncode = function GameEncode(gameId, groupId) {
                var iRand = 0, iRand2 = 0;
                var GameID16 = parseInt(gameId).toString(16);
                var Result = '';
                iRand = parseInt((Math.random() * 3 + 1).toString());
                iRand2 = parseInt((Math.random() * 9 + 1).toString());
                var arr = GameID16.toString().split("");
                for(var item = 0, max = arr.length; item < max; item++) {
                    if(iRand == (item + 1)) {
                        Result += iRand2 + arr[item];
                    } else {
                        Result += arr[item];
                    }
                }
                Result += iRand;
                Result += '_' + groupId;
                return Result;
            };
            StaticData.GetParameter = function GetParameter(ParameterName) {
                var queryString = location.search.substring(1).toLowerCase();
                var ParameterName = (ParameterName + "=").toLowerCase();
                if(queryString.length > 0) {
                    var begin = queryString.indexOf(ParameterName);
                    if(begin != -1) {
                        begin += ParameterName.length;
                        var end = queryString.indexOf("&", begin);
                        if(end == -1) {
                            end = queryString.length;
                        }
                        return unescape(queryString.substring(begin, end));
                    }
                    return null;
                }
            };
            StaticData.GetQueryInt = function GetQueryInt(QueryName, Min, Max) {
                if (typeof Min === "undefined") { Min = 0; }
                if (typeof Max === "undefined") { Max = 99; }
                var result = Min;
                if(QueryName) {
                    var val = StaticData.GetParameter(QueryName);
                    result = new window['RegExp'](/^\d+$/).test(val) ? parseInt(val) : Min;
                    result = (result >= Min && result <= Max) ? result : Min;
                }
                return result;
            };
            StaticData.SetCookie = function SetCookie(key, value) {
                document.cookie = key + "=" + escape(value) + ";";
            };
            StaticData.GetCookie = function GetCookie(key) {
                var aCookie = document.cookie.split("; ");
                for(var i = 0; i < aCookie.length; i++) {
                    var aCrumb = aCookie[i].split("=");
                    if(key == aCrumb[0]) {
                        return unescape(aCrumb[1]);
                    }
                }
                return "";
            };
            return StaticData;
        })();
        Utilities.StaticData = StaticData;        
    })(SGT.Utilities || (SGT.Utilities = {}));
    var Utilities = SGT.Utilities;
})(SGT || (SGT = {}));
