var SGT;
(function (SGT) {
    (function (Utilities) {
        var Side = (function () {
            function Side(param) {
                this.Width = 0;
                this.Height = 0;
                this.Speed = 0;
                this.ParentCtl = null;
                $.extend(this, param);
                this.Initial();
            }
            Side.prototype.Initial = function () {
                var _this = this;
                $(_this.ParentCtl).css({
                    width: _this.Width,
                    height: _this.Height,
                    'min-height': _this.Height
                });
                $(_this.ParentCtl).find("ul:first");
            };
            Side.prototype.Up = function () {
                var _this = this;
                var _field = $(_this.ParentCtl).find('li:first');
                var _ul = $(_this.ParentCtl).find("ul:first");
                var _li = $(_this.ParentCtl).find('li');
                $(_ul).css({
                    height: _this.Height * _li.length,
                    width: _this.Width
                });
                _field.animate({
                    marginTop: -_this.Height + 'px'
                }, _this.Speed, function () {
                    _field.css('marginTop', 0).appendTo(_ul);
                });
            };
            Side.prototype.Right = function () {
                var _this = this;
                var _field = $(_this.ParentCtl).find('li:last');
                var _firstli = $(_this.ParentCtl).find('li:first');
                var _ul = $(_this.ParentCtl).find("ul:first");
                var _li = $(_this.ParentCtl).find('li');
                $(_ul).css({
                    height: _this.Height,
                    width: _this.Width * _li.length
                });
                _firstli.animate({
                    marginLeft: _this.Width + 'px'
                }, _this.Speed, function () {
                    _field.css('marginLeft', 0).prependTo(_ul);
                    _firstli.css('marginLeft', 0);
                });
            };
            Side.prototype.Left = function () {
                var _this = this;
                var _field = $(_this.ParentCtl).find('li:first');
                var _ul = $(_this.ParentCtl).find("ul:first");
                var _li = $(_this.ParentCtl).find('li');
                $(_ul).css({
                    height: _this.Height,
                    width: _this.Width * _li.length
                });
                _field.animate({
                    marginLeft: -_this.Width + 'px'
                }, _this.Speed, function () {
                    _field.css('marginLeft', 0).appendTo(_ul);
                });
            };
            return Side;
        })();
        Utilities.Side = Side;        
    })(SGT.Utilities || (SGT.Utilities = {}));
    var Utilities = SGT.Utilities;

})(SGT || (SGT = {}));

