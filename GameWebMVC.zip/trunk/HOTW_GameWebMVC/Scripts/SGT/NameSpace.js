﻿
var SGT = {};

var $SGT = {};

SGT.Member = {
	Login: {}
};

SGT.WebSiteInfo = {
    Version: {},
    Urls: {},
    CheckMaintain: function () {
        if (SGT.WebSiteInfo.IsMaintain) {
            alert('遊戲目前進行維護中，請稍後再來玩！');
            return true;
        } else {
            return false;
        }
    }
};

SGT.Global = {
    PopIframeMgr: {},
    Utilities: {},
    Event: {}
};

SGT.DataInfo = {};


SGT.Main = {
    QueryFns: {
    },
    Add: function (key, value) {
        if (this.QueryFns[key]) {
            throw '重複';
        }
        this.QueryFns[key] = value;
    },
    Bind: function () {
        ko.applyBindings(this.QueryFns);
    }
}

SGT.Global.Utilities.EventObserver = function () {
    var listeners = [];
    this.Add = function (fn) {
        listeners.push(fn);
    };
    this.Publish = function () {
        $.each(listeners, function (idx, obj) {
            if (obj != undefined) {
                obj();
            }
        });
    };
};

$SGT.PrePageLoad = SGT.Global.Event.PrePageLoad = new SGT.Global.Utilities.EventObserver();

$SGT.PageLoad = SGT.Global.Event.PageLoad = new SGT.Global.Utilities.EventObserver();

$SGT.PageCompleted = SGT.Global.Event.PageCompleted = new SGT.Global.Utilities.EventObserver();

$(function () {
    SGT.Global.Event.PrePageLoad.Publish();

    SGT.Global.Event.PageLoad.Publish();

    SGT.Global.Event.PageCompleted.Publish();
});
