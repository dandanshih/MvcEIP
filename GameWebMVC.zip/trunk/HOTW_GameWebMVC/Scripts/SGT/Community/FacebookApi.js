var SGT;
(function (SGT) {
    
})(SGT || (SGT = {}));

var SGT;
(function (SGT) {
    (function (Community) {
        var Facebook = (function () {
            function Facebook() {
                this.Setting = {
                    AppID: '',
                    AppScope: ''
                };
                this.CommunityApi = null;
            }
            Facebook.prototype.Register = function (config) {
                $.extend(this.Setting, config);
                var _setting = this.Setting;
                window.attachEvent('fbAsyncInit', function () {
                    FB.init({
                        appId: _setting,
                        status: true,
                        cookie: true,
                        xfbml: true,
                        oauth: true,
                        hideFlashCallback: function (params) {
                            if(params.state == 'opened') {
                                var screenshotData = swfobject.getObjectById('WebLoad').callWebLoad("GetLoadBG", "");
                                $('#screenshotObject').attr("src", 'data:image/jpeg;base64,' + screenshotData);
                                $('#divBody').height($('#WebLoad').height());
                                $('#flashContent').css("top", "-10000px");
                                $('#imageContent').css("top", "");
                            } else {
                                $('#flashContent').css("top", "");
                                $('#imageContent').css("top", "-10000px");
                            }
                        }
                    });
                    FB.Event.subscribe('auth.statusChange', function (response) {
                        FacebookNowStatus = response.status;
                    });
                });
                ((function (d) {
                    var js;
                    var id = 'facebook-jssdk';
                    var ref = d.getElementsByTagName('script')[0];

                    if(d.getElementById(id)) {
                        return;
                    }
                    js = d.createElement('script');
                    js.id = id;
                    js.async = true;
                    js.src = "//connect.facebook.net/zh_TW/all.js";
                    ref.parentNode.insertBefore(js, ref);
                })(document));
                this.CommunityApi = new FacebookApi(this.Setting);
            };
            return Facebook;
        })();
        Community.Facebook = Facebook;        
        var FacebookApi = (function () {
            function FacebookApi(Setting) {
                this.Setting = Setting;
                this.Platform = 'Web';
                this.UserInfo = {
                };
                this.Callback = function () {
                };
            }
            FacebookApi.prototype.Login = function (config, callback) {
                if (typeof callback === "undefined") { callback = null; }
                var self = this;
                var DefaultConfig = {
                    Init: function () {
                    },
                    LoginOK: function () {
                    },
                    LoginFail: function () {
                    }
                };
                $.extend(DefaultConfig, config);
                DefaultConfig.Init();
                FB.login(function (response) {
                    if(response.authResponse) {
                        self.IsLogin = true;
                        DefaultConfig.LoginOK();
                    } else {
                        self.IsLogin = false;
                        DefaultConfig.LoginFail();
                    }
                }, {
                    scope: self.Setting["AppScope"]
                });
            };
            FacebookApi.prototype.GetUserInfo = function (config, callback) {
                if (typeof callback === "undefined") { callback = null; }
                var self = this;
                var DefaultConfig = {
                    Init: function () {
                    },
                    CallBack: function (UserInfo) {
                    },
                    EventFail: function () {
                    }
                };
                $.extend(DefaultConfig, config);
                if(!this.IsLogin) {
                    this.Login({
                        LoginOK: function () {
                            self.GetUserInfo(config);
                        },
                        LoginFail: function () {
                            DefaultConfig.EventFail();
                        }
                    });
                    return;
                }
                DefaultConfig.Init();
                FB.api({
                    method: 'fql.query',
                    query: 'SELECT uid, name, pic_square, email, sex, birthday_date FROM user WHERE uid = me()'
                }, function (response) {
                    $.extend(self.UserInfo, response[0]);
                    DefaultConfig.CallBack(self.UserInfo);
                });
            };
            FacebookApi.prototype.Feed = function (config) {
                var self = this;
                if(!this.IsLogin) {
                    this.Login({
                        LoginOK: function () {
                            self.Feed(config);
                        }
                    });
                    return;
                }
                var DefaultConfig = {
                    method: 'feed',
                    display: this.Platform == "FB" ? "iframe" : 'popup',
                    message: '',
                    user_prompt_message: '�g�ǪF����ɵ��B��',
                    picture: 'http://' + SGT["WebSiteInfo"].Urls.DataInfoUrl + '/Html/UploadFiles/FBFeed/08ICon.gif',
                    name: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
                    link: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
                    caption: (this.Platform == "FB") ? '�Ѥl�����y�ѹC��' : '�Ѥl���� Online',
                    description: '',
                    actions: '',
                    target_id: ''
                };
                $.extend(DefaultConfig, config);
                FB.ui(DefaultConfig, function (response) {
                    self.Callback();
                });
            };
            FacebookApi.prototype.Publish = function (config) {
                var self = this;
                if(!this.IsLogin) {
                    this.Login({
                        LoginOK: function () {
                            self.Publish(config);
                        }
                    });
                    return;
                }
                var DefaultConfig = {
                    message: '',
                    picture: 'http://' + SGT["WebSiteInfo"].Urls.DataInfoUrl + '/Html/UploadFiles/FBFeed/08ICon.gif',
                    name: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
                    link: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
                    caption: ' ',
                    description: '',
                    actions: ''
                };
                $.extend(DefaultConfig, config);
                FB.api('/feed', 'post', DefaultConfig, function (response) {
                    if(!response || response.error) {
                    } else {
                    }
                });
            };
            FacebookApi.prototype.Invite = function (config) {
                var self = this;
                if(!this.IsLogin) {
                    this.Login({
                        LoginOK: function () {
                            self.Invite(config);
                        }
                    });
                    return;
                }
                var DefaultConfig = {
                    method: 'apprequests',
                    title: '�Ѥl���� Online',
                    message: '���֥[�J�Ѥl�������n�d',
                    data: 'Invite'
                };
                $.extend(DefaultConfig, config);
                FB.ui(DefaultConfig, function (response) {
                    self.Callback();
                });
            };
            FacebookApi.prototype.Purchase = function (config, callback) {
                if (typeof callback === "undefined") { callback = null; }
                var self = this;
                if(!this.IsLogin) {
                    this.Login({
                        LoginOK: function () {
                            self.Purchase(config, callback);
                        }
                    });
                    return;
                }
                var DefaultConfig = {
                    method: 'pay',
                    order_info: {
                        item_id: 'OrderID',
                        title: 'ProductTitle',
                        description: 'Description',
                        price: 0,
                        image_url: 'ImageUrl',
                        product_url: 'ProductUrl'
                    },
                    purchase_type: 'item',
                    dev_purchase_params: {
                        oscif: true
                    }
                };
                $.extend(DefaultConfig, config);
                FB.ui(DefaultConfig, callback);
            };
            return FacebookApi;
        })();
        Community.FacebookApi = FacebookApi;        
    })(SGT.Community || (SGT.Community = {}));
    var Community = SGT.Community;

})(SGT || (SGT = {}));

