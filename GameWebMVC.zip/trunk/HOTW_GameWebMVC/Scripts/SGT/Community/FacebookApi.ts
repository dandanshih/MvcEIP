/// <reference path="ICommunity.ts" />
/// <reference path="../NameSpace.js" />
/// <reference path="../WebSiteInfo/Razor.js" />

declare var $;
declare var SGT: any;
declare var swfobject;
declare var FB;
declare var FacebookNowStatus;
declare var getFBCanvasUrl;

module SGT.Community {
    export class Facebook implements ICommunity {
        private Setting: Object = {
            AppID: '',
            AppScope: ''
        }

        Register(config: Object): void {
            $.extend(this.Setting, config);
            var _setting: Object = this.Setting;
            window.attachEvent('fbAsyncInit', function () {	//��l�Ƶn�J���A�A�ϥ�JavaScript SDK
		    //��J���ε{��ID
		        FB.init({
		            appId: _setting,
			        status: true,
			        cookie: true,
			        xfbml: true,
			        oauth: true,
			        //frictionlessRequests: true,
			        hideFlashCallback: function (params) {
			            if (params.state == 'opened') {
			                var screenshotData = swfobject.getObjectById('WebLoad').callWebLoad("GetLoadBG", "");
			                $('#screenshotObject').attr("src", 'data:image/jpeg;base64,' + screenshotData);
			                $('#divBody').height($('#WebLoad').height());
			                $('#flashContent').css("top", "-10000px");
			                $('#imageContent').css("top", "");
			                // FB.Canvas.hideFlashElement(params.elem);		
			            } else {
			                // FB.Canvas.showFlashElement(params.elem);
			                $('#flashContent').css("top", "");
			                $('#imageContent').css("top", "-10000px");
			            }
			        }
		        });
		        FB.Event.subscribe('auth.statusChange', function (response) {
			        FacebookNowStatus = response.status;
		        });
	        });

	        (function(d){
		        var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
		        if (d.getElementById(id)) {return;}
		        js = d.createElement('script'); js.id = id; js.async = true;
		        js.src = "//connect.facebook.net/zh_TW/all.js";
		        ref.parentNode.insertBefore(js, ref);
	        }(document));
	        this.CommunityApi = new FacebookApi(this.Setting);
        }

        CommunityApi: ICommunityApi = null;
    }

    export class FacebookApi implements ICommunityApi {

        constructor (public Setting: Object) { }

        IsLogin: bool;

        Platform: string = 'Web';
        UserInfo: Object = { };
        Callback = function () { };

        Login(config: Object, callback = null): void {
            var self = this;

	        var DefaultConfig = {
		        // �I�sFacebook�n�J�e���椧Function
		        Init: function () { },
		        // �n�J���\����椧Function
		        LoginOK: function () { },
		        // �n�J���ѫ���椧Function
		        LoginFail: function () { }
	        };

	        $.extend(DefaultConfig, config);

	        DefaultConfig.Init();

	        FB.login(function (response) {
		        if (response.authResponse) {
			        self.IsLogin = true;
			        DefaultConfig.LoginOK();
		        } else {
			        self.IsLogin = false;
			        DefaultConfig.LoginFail();
		        }
	        }, { scope: self.Setting["AppScope"] });
        }

        GetUserInfo(config: Object, callback = null): void{
            var self = this;

	        var DefaultConfig = {
		        // �I�sFacebook���|����TAPI�e���椧Function
		        Init: function () { },
		        // ���o�|����T����椧Function
		        CallBack: function (UserInfo) { },
		        // �n�J���ѫ���椧Function
		        EventFail: function () { }
	        };
	        $.extend(DefaultConfig, config);

	        // �P�_�O�_�n�JFacebook
	        if (!this.IsLogin) {
		        this.Login({
			        // �n�J���\��^�I
			        LoginOK: function () { self.GetUserInfo(config); },
			        LoginFail: function () { DefaultConfig.EventFail(); }
		        });
		        return;
	        }

	        DefaultConfig.Init();

	        FB.api(
	        {
		        method: 'fql.query',
		        query: 'SELECT uid, name, pic_square, email, sex, birthday_date FROM user WHERE uid = me()'
	        },
	        function (response) {
		        $.extend(self.UserInfo, response[0]);
		        DefaultConfig.CallBack(self.UserInfo);
	        });
        }

        Feed(config: Object): void{
            var self = this;
	        // �P�_�O�_�n�JFacebook
	        if (!this.IsLogin) {
		        this.Login({
			        LoginOK: function () { self.Feed(config); }
		        });
		        return;
	        }

	        var DefaultConfig = {
		        method: 'feed',
		        display: this.Platform == "FB" ? "iframe" : 'popup',
		        message: '',
		        user_prompt_message: '�g�ǪF����ɵ��B��',
		        picture: 'http://' + SGT["WebSiteInfo"].Urls.DataInfoUrl + '/Html/UploadFiles/FBFeed/08ICon.gif',
		        name: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
		        link: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
		        caption: (this.Platform == "FB") ? '�Ѥl�����y�ѹC��' : '�Ѥl���� Online',
		        description: '',
		        actions: '',
		        target_id: ''
	        };
	        $.extend(DefaultConfig, config);

	        FB.ui(
		        DefaultConfig,
		        function (response) {						
			        self.Callback();
		        }
	        );
        }

        Publish(config: Object): void{
            var self = this;
	        // �P�_�O�_�n�JFacebook
	        if (!this.IsLogin) {
		        this.Login({
			        LoginOK: function () { self.Publish(config); }
		        });
		        return;
	        }

	        var DefaultConfig = {
		        message: '',
		        picture: 'http://' + SGT["WebSiteInfo"].Urls.DataInfoUrl + '/Html/UploadFiles/FBFeed/08ICon.gif',
		        name: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
		        link: (this.Platform == "FB") ? getFBCanvasUrl() : 'http://' + SGT["WebSiteInfo"].Urls.MainUrl,
		        caption: ' ',
		        description: '',
		        actions: ''
	        };
	        $.extend(DefaultConfig, config);
	
	        FB.api(
		        '/feed',
		        'post',
		        DefaultConfig,
		        function (response) {
			        if (!response || response.error) {
				        // alert('�o�G���ѡI');
			        }
			        else {
				        // alert('�o�G���\�I');
			        }
		        }
	        );
        }

        Invite(config: Object): void{
            var self = this;
	        // �P�_�O�_�n�JFacebook
	        if (!this.IsLogin) {
		        this.Login({
			        LoginOK: function () { self.Invite(config); }
		        });
		        return;
	        }

	        var DefaultConfig = {
		        method: 'apprequests',
		        title: '�Ѥl���� Online',
		        message: '���֥[�J�Ѥl�������n�d',
		        data: 'Invite'
	        };
	        $.extend(DefaultConfig, config);
	        FB.ui(
		        DefaultConfig,
		        function (response) {
			        self.Callback();
		        }
	        );
        }

        Purchase(config: Object, callback = null): void{
            var self = this;
	        // �P�_�O�_�n�JFacebook
	        if (!this.IsLogin) {
		        this.Login({
			        LoginOK: function () { self.Purchase(config, callback); }
		        });
		        return;
	        }

	        var DefaultConfig = {
		        method: 'pay',
		        order_info: {
			        item_id: 'OrderID',
			        title: 'ProductTitle',
			        description: 'Description',
			        price: 0,
			        image_url: 'ImageUrl',
			        product_url: 'ProductUrl'
		        },
		        purchase_type: 'item',
		        dev_purchase_params: { oscif: true }
	        };

	        $.extend(DefaultConfig, config);

	        FB.ui(DefaultConfig, callback);
        }
    }
}