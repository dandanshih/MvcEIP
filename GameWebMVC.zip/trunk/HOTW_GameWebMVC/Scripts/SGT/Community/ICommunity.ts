
module SGT.Community {
    export interface ICommunity {
        Register(config: Object): void;

        CommunityApi: ICommunityApi;
    }

    export interface ICommunityApi {
        IsLogin: bool;
        Login(config: Object, callback): void;
        GetUserInfo(config: Object, callback): void;
        Feed(config: Object): void;
        Publish(config: Object): void;
        Invite(config: Object): void;
        Purchase(config: Object, callback): void;
    }
}
