/// <reference path="IFlagData.ts" />
declare var $;

module SGT.DataInfo {
    // StaticPages �ϥΤ��C�|��
    export enum FlagsDataType {
        // �̷s�����C
        News = 1,
        // �m��Ĺ���Ʀ�]�C
        RankByJp = 2,
        // �ʤj�I���Ʀ�]�C
        RankByMoney = 4,
        // �槽Ĺ���Ʀ�]�C
        RankBySingleWin = 8,
        // �`Ĺ���Ʀ�]�C
        RankByTotalWin = 16,
        // �C���C��
        Games = 32,
        // �ڪ��M�ݮ���
        PersonalNews = 64,
        // �ڪ��a�A�v
        PersonalGlory = 128,
        // �d�O��T
        PersonalCard = 256,
        // �|����T
        MemberData = 512,
        //�̷s�Ʀ�]
        RankVIPGame = 2048,
        //�ڪ��B��
        MyFriend = 4096,
        // �f�C���Ʀ�]
        RankByPachinko = 8196
    }

    // ��������C# Dictionary��
    export class SignalDataType {
        constructor(public Key: FlagsDataType, public Value: IFlagData) { }
    }

    // FlagsData �޲z��
    export class FlagsDataManager {
        Flags: number = 0;

        UseList: IFlagData[] = [];

        IFlagList: SignalDataType[] = [];

        constructor() {
            this.IFlagList.push(new SignalDataType(FlagsDataType.News, new News()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.RankByJp, new RankByJp()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.RankByMoney, new RankByMoney()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.RankBySingleWin, new RankBySingleWin()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.RankByTotalWin, new RankByTotalWin()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.Games, new Games()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.PersonalNews, new PersonalNews()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.MyFriend, new MyFriend()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.PersonalGlory, new PersonalGlory()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.PersonalCard, new PersonalCard()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.MemberData, new MemberData()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.RankVIPGame, new RankVIPGameData()));
            this.IFlagList.push(new SignalDataType(FlagsDataType.RankByPachinko, new RankByPachinko()));
        }

        Add(dataType: FlagsDataType) {
            if ((this.Flags & dataType) == dataType) {
                throw "DataManager already have " + dataType;
            }
            for (var i: number = 0, max: number = this.IFlagList.length; i < max; i++) {
                var sType: SignalDataType = this.IFlagList[i];
                if (sType.Key == dataType) {
                    this.Flags |= dataType;
                    this.UseList.push(sType.Value);
                }
            }
        }

        Modify(data: Object) {
            for (var i: number = 0, max: number = this.UseList.length; i < max; i++) {
                this.UseList[i].DoAction(data);
            }
        }

        ModifyOne(dataType: FlagsDataType, data: Object) {
            for (var i: number = 0, max: number = this.IFlagList.length; i < max; i++) {
                var sType: SignalDataType = this.IFlagList[i];
                if (sType.Key == dataType) {
                    sType.Value.DoAction(data);
                    break;
                }
            }
        }
    }

    export class News implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['News'](data["News"]);
        }
    }
    export class RankByJp implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['RankByJp'](data["RankByJp"]);
        }
    }
    export class RankByMoney implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['RankByMoney'](data["RankByMoney"]);
        }
    }
    export class RankBySingleWin implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['RankBySingleWin'].List(data["RankBySingleWin"]);
        }
    }
    export class RankByPachinko implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['RankByPachinko'](data["RankByPachinko"]);
        }
    }
    export class RankByTotalWin implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['RankByTotalWin'](data["RankByTotalWin"]);
        }
    }
    export class Games implements IFlagData {
        DoAction(data: Object): void {
            $.each(data["Games"], function (index, obj) {
                $.each(obj, function (i, o) {
                    SGT["Main"].QueryFns['Games'][index].push(o);
                });
            });
        }
    }
    export class PersonalNews implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['PersonalNews'](data["PersonalNews"]);
        }
    }
    export class MyFriend implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['MyFriend'](data["MyFriend"]);
        }
    }
    export class PersonalGlory implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['PersonalGlory'](data["PersonalGlory"]);
        }
    }
    export class PersonalCard implements IFlagData {
        DoAction(data: Object): void {
            $.each(data["PersonalCard"].DataList, function (index, obj) {
                if (index == 0) { SGT["Main"].QueryFns['PersonalCard'].Store(obj); }
                if (index == 1) { SGT["Main"].QueryFns['PersonalCard'].Bet(obj); }
            });
            SGT["Main"].QueryFns['PersonalCard'].CurrentLevel(data["PersonalCard"].CurrentLevel);
            SGT["Main"].QueryFns['PersonalCard'].NextLevel(data["PersonalCard"].NextLevel);
            SGT["Main"].QueryFns['PersonalCard'].NextDate(data["PersonalCard"].NextDate);
        }
    }
    export class MemberData implements IFlagData {
        DoAction(data: Object): void {
            if (SGT["Global"].PopIframeMgr.PopIframes["ChangePassword"]) {
                return;
            }
            SGT["Member"].Activity = new SGT["Member"].FnActivity();
            SGT["Member"].Activity.Init(data["MemberData"].WebLoginEventFlag);
        }
    }

    export class RankVIPGameData implements IFlagData {
        DoAction(data: Object): void {
            SGT["Main"].QueryFns['RankVIPGame'](data["RankVIPGame"]);
        }
    }
}