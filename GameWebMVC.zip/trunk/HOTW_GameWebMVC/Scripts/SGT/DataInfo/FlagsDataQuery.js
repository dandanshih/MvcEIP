var SGT;
(function (SGT) {
    (function (DataInfo) {
        // StaticPages 使用之列舉值
        (function (FlagsDataType) {
            // 最新消息。
            FlagsDataType[FlagsDataType["News"] = 1] = "News";

            // 彩金贏分排行榜。
            FlagsDataType[FlagsDataType["RankByJp"] = 2] = "RankByJp";

            // 百大富豪排行榜。
            FlagsDataType[FlagsDataType["RankByMoney"] = 4] = "RankByMoney";

            // 單局贏分排行榜。
            FlagsDataType[FlagsDataType["RankBySingleWin"] = 8] = "RankBySingleWin";

            // 總贏分排行榜。
            FlagsDataType[FlagsDataType["RankByTotalWin"] = 16] = "RankByTotalWin";

            // 遊戲列表
            FlagsDataType[FlagsDataType["Games"] = 32] = "Games";

            // 我的專屬消息
            FlagsDataType[FlagsDataType["PersonalNews"] = 64] = "PersonalNews";

            // 我的榮譽史
            FlagsDataType[FlagsDataType["PersonalGlory"] = 128] = "PersonalGlory";

            // 卡別資訊
            FlagsDataType[FlagsDataType["PersonalCard"] = 256] = "PersonalCard";

            // 會員資訊
            FlagsDataType[FlagsDataType["MemberData"] = 512] = "MemberData";

            //最新排行榜
            FlagsDataType[FlagsDataType["RankVIPGame"] = 2048] = "RankVIPGame";

            //我的朋友
            FlagsDataType[FlagsDataType["MyFriend"] = 4096] = "MyFriend";

            // 柏青哥排行榜
            FlagsDataType[FlagsDataType["RankByPachinko"] = 8196] = "RankByPachinko";
        })(DataInfo.FlagsDataType || (DataInfo.FlagsDataType = {}));
        var FlagsDataType = DataInfo.FlagsDataType;

        // 拿做類似C# Dictionary用
        var SignalDataType = (function () {
            function SignalDataType(Key, Value) {
                this.Key = Key;
                this.Value = Value;
            }
            return SignalDataType;
        })();
        DataInfo.SignalDataType = SignalDataType;

        // FlagsData 管理器
        var FlagsDataManager = (function () {
            function FlagsDataManager() {
                this.Flags = 0;
                this.UseList = [];
                this.IFlagList = [];
                this.IFlagList.push(new SignalDataType(FlagsDataType.News, new News()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.RankByJp, new RankByJp()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.RankByMoney, new RankByMoney()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.RankBySingleWin, new RankBySingleWin()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.RankByTotalWin, new RankByTotalWin()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.Games, new Games()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.PersonalNews, new PersonalNews()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.MyFriend, new MyFriend()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.PersonalGlory, new PersonalGlory()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.PersonalCard, new PersonalCard()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.MemberData, new MemberData()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.RankVIPGame, new RankVIPGameData()));
                this.IFlagList.push(new SignalDataType(FlagsDataType.RankByPachinko, new RankByPachinko()));
            }
            FlagsDataManager.prototype.Add = function (dataType) {
                if ((this.Flags & dataType) == dataType) {
                    throw "DataManager already have " + dataType;
                }
                for (var i = 0, max = this.IFlagList.length; i < max; i++) {
                    var sType = this.IFlagList[i];
                    if (sType.Key == dataType) {
                        this.Flags |= dataType;
                        this.UseList.push(sType.Value);
                    }
                }
            };

            FlagsDataManager.prototype.Modify = function (data) {
                for (var i = 0, max = this.UseList.length; i < max; i++) {
                    this.UseList[i].DoAction(data);
                }
            };

            FlagsDataManager.prototype.ModifyOne = function (dataType, data) {
                for (var i = 0, max = this.IFlagList.length; i < max; i++) {
                    var sType = this.IFlagList[i];
                    if (sType.Key == dataType) {
                        sType.Value.DoAction(data);
                        break;
                    }
                }
            };
            return FlagsDataManager;
        })();
        DataInfo.FlagsDataManager = FlagsDataManager;

        var News = (function () {
            function News() {
            }
            News.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['News'](data["News"]);
            };
            return News;
        })();
        DataInfo.News = News;
        var RankByJp = (function () {
            function RankByJp() {
            }
            RankByJp.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['RankByJp'](data["RankByJp"]);
            };
            return RankByJp;
        })();
        DataInfo.RankByJp = RankByJp;
        var RankByMoney = (function () {
            function RankByMoney() {
            }
            RankByMoney.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['RankByMoney'](data["RankByMoney"]);
            };
            return RankByMoney;
        })();
        DataInfo.RankByMoney = RankByMoney;
        var RankBySingleWin = (function () {
            function RankBySingleWin() {
            }
            RankBySingleWin.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['RankBySingleWin'].List(data["RankBySingleWin"]);
            };
            return RankBySingleWin;
        })();
        DataInfo.RankBySingleWin = RankBySingleWin;
        var RankByPachinko = (function () {
            function RankByPachinko() {
            }
            RankByPachinko.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['RankByPachinko'](data["RankByPachinko"]);
            };
            return RankByPachinko;
        })();
        DataInfo.RankByPachinko = RankByPachinko;
        var RankByTotalWin = (function () {
            function RankByTotalWin() {
            }
            RankByTotalWin.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['RankByTotalWin'](data["RankByTotalWin"]);
            };
            return RankByTotalWin;
        })();
        DataInfo.RankByTotalWin = RankByTotalWin;
        var Games = (function () {
            function Games() {
            }
            Games.prototype.DoAction = function (data) {
                $.each(data["Games"], function (index, obj) {
                    $.each(obj, function (i, o) {
                        SGT["Main"].QueryFns['Games'][index].push(o);
                    });
                });
            };
            return Games;
        })();
        DataInfo.Games = Games;
        var PersonalNews = (function () {
            function PersonalNews() {
            }
            PersonalNews.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['PersonalNews'](data["PersonalNews"]);
            };
            return PersonalNews;
        })();
        DataInfo.PersonalNews = PersonalNews;
        var MyFriend = (function () {
            function MyFriend() {
            }
            MyFriend.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['MyFriend'](data["MyFriend"]);
            };
            return MyFriend;
        })();
        DataInfo.MyFriend = MyFriend;
        var PersonalGlory = (function () {
            function PersonalGlory() {
            }
            PersonalGlory.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['PersonalGlory'](data["PersonalGlory"]);
            };
            return PersonalGlory;
        })();
        DataInfo.PersonalGlory = PersonalGlory;
        var PersonalCard = (function () {
            function PersonalCard() {
            }
            PersonalCard.prototype.DoAction = function (data) {
                $.each(data["PersonalCard"].DataList, function (index, obj) {
                    if (index == 0) {
                        SGT["Main"].QueryFns['PersonalCard'].Store(obj);
                    }
                    if (index == 1) {
                        SGT["Main"].QueryFns['PersonalCard'].Bet(obj);
                    }
                });
                SGT["Main"].QueryFns['PersonalCard'].CurrentLevel(data["PersonalCard"].CurrentLevel);
                SGT["Main"].QueryFns['PersonalCard'].NextLevel(data["PersonalCard"].NextLevel);
                SGT["Main"].QueryFns['PersonalCard'].NextDate(data["PersonalCard"].NextDate);
            };
            return PersonalCard;
        })();
        DataInfo.PersonalCard = PersonalCard;
        var MemberData = (function () {
            function MemberData() {
            }
            MemberData.prototype.DoAction = function (data) {
                if (SGT["Global"].PopIframeMgr.PopIframes["ChangePassword"]) {
                    return;
                }
                SGT["Member"].Activity = new SGT["Member"].FnActivity();
                SGT["Member"].Activity.Init(data["MemberData"].WebLoginEventFlag);
            };
            return MemberData;
        })();
        DataInfo.MemberData = MemberData;

        var RankVIPGameData = (function () {
            function RankVIPGameData() {
            }
            RankVIPGameData.prototype.DoAction = function (data) {
                SGT["Main"].QueryFns['RankVIPGame'](data["RankVIPGame"]);
            };
            return RankVIPGameData;
        })();
        DataInfo.RankVIPGameData = RankVIPGameData;
    })(SGT.DataInfo || (SGT.DataInfo = {}));
    var DataInfo = SGT.DataInfo;
})(SGT || (SGT = {}));
