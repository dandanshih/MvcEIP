
module SGT.DataInfo {
    export interface IFlagData {
        DoAction(data: Object): void;
    }
}