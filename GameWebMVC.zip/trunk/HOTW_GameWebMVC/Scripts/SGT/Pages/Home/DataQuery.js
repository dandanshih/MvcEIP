﻿
// 樂透金額
SGT.Main.Add('Lottery', ko.observable('累積金額 0'));
// JP
SGT.Main.Add('JP', {
    JP1: ko.observable('0.00'),
    JP2: ko.observable('0.00'),
    JP3: ko.observable('0.00'),
    JP4: ko.observable('0.00')
});
// 彩金贏分排行榜
SGT.Main.Add('RankByJp', ko.observableArray([]));
// 百大富豪排行榜
SGT.Main.Add('RankByMoney', ko.observableArray([]));
// 單局贏分排行榜
SGT.Main.Add('RankBySingleWin', {
    List: ko.observableArray([]),
    PopWin: function () {
        var dataItem = this;
        SGT.Global.PopIframeMgr.Add("RankBySingleWin");
        SGT.Global.PopIframeMgr.PopIframes["RankBySingleWin"].SetScrollBar(false);
        SGT.Global.PopIframeMgr.PopIframes["RankBySingleWin"].Load('/MVC/Htmls/Shared/SingleWinFrame.html',
        function (ifrm) {
            ifrm.contentWindow.init(
                function () { SGT.Global.PopIframeMgr.Remove('RankBySingleWin'); },
                dataItem.GameID,
                SGT.WebSiteInfo.Urls.LogUrl,
                SGT.WebSiteInfo.Urls.DataInfoUrl,
                dataItem.GameData
            );
        });
        SGT.Global.PopIframeMgr.PopIframes["RankBySingleWin"].Show();
    }
});
// 柏青哥排行榜
SGT.Main.Add('RankByPachinko', ko.observableArray([]));
// 總贏分排行榜
SGT.Main.Add('RankByTotalWin', ko.observableArray([]));
// 我的排行
SGT.Main.Add('MyRank', ko.observableArray([]));
// 最新消息
SGT.Main.Add('News', ko.observableArray([]));
// 官網遊戲列表
SGT.Main.Add('Games', {
    'Favorites': ko.observableArray([]),
    'All': ko.observableArray([]),
    OpenFreeGame: function (data) {
        if (SGT.WebSiteInfo.CheckMaintain()) {
            return;
        }
        if (SGT.Global.PopIframeMgr.PopIframes["FreeGame"]) {
            return;
        }
        SGT.Main.QueryFns['Member'].HideLoginTips();

        SGT.Global.PopIframeMgr.Add("FreeGame");
        SGT.Global.PopIframeMgr.PopIframes["FreeGame"].Load("/Web/Game/MiniList.aspx?IsExperience=1&FirstIn=1&IsFree=1&gameName=" + SGT.Utilities.StaticData.GameEncode(data.GameID, data.GroupID));
        SGT.Global.PopIframeMgr.PopIframes["FreeGame"].Center(801, 600);
        SGT.Global.PopIframeMgr.PopIframes["FreeGame"].SetScrollBar(false);
        SGT.Global.PopIframeMgr.PopIframes["FreeGame"].Show();
        SGT.Global.PopIframeMgr.BodyMaskHide();
    },
    OpenGameMenu: function (data) {

        PopGamePage({ gameName: SGT.Utilities.StaticData.GameEncode(data.GameID, data.GroupID) });
    }
});
// 我的專屬消息
SGT.Main.Add('PersonalNews', ko.observableArray([]));
//// 我的榮譽史
SGT.Main.Add('PersonalGlory', ko.observableArray([]));


// 首頁右側廣告
SGT.Main.Add('IndexAD', ko.observableArray([]));

$SGT.PrePageLoad.Add(function () {
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.News);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.RankByJp);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.RankByMoney);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.RankBySingleWin);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.RankByPachinko);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.RankByTotalWin);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.Games);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.PersonalNews);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.PersonalGlory);
    $SGT.FlagsMgr.Add(SGT.DataInfo.FlagsDataType.MemberData);
});
$SGT.PageLoad.Add(function () {
    // JP
    $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetJPInfo.ashx?callback=?', { PointType: 2 }, function (data) {
        $.each(data.Data, function (index, obj) {
            // 補滿 11 個字元，_代表空白
            var jpFormat = function (str) {
                var strLen = str.length;
                for (i = 0; i < 11 - strLen; i++) {
                    str = '_' + str;
                }
                return str;
            };

            switch (obj.GameID) {
                case 9201: SGT.Main.QueryFns['JP'].JP1(jpFormat(obj.Data)); break;
                case 9202: SGT.Main.QueryFns['JP'].JP2(jpFormat(obj.Data)); break;
                case 9203: SGT.Main.QueryFns['JP'].JP3(jpFormat(obj.Data)); break;
                case 9204: SGT.Main.QueryFns['JP'].JP4(jpFormat(obj.Data)); break;
            }
        });
    });

    // 樂透金額
    //$.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/GetLottoCount.ashx?callback=?', { data: 1 }, function (data) {
    //    SGT.Main.QueryFns['Lottery']("累積金額 " + data.Bonus.toString());
    //});
    // IM 都靠這支等我們通知，絕不能砍!!
    //$.getJSON("//" + SGT.WebSiteInfo.Urls.DataInfoUrl + "/DataInfo/GetOnlineMemberCounter.ashx?callback=?", { ResultType: 2 }, function (data) { });

    $.ajax({
        type: "POST",
        url: "/Mvc/Api/AD/GetADList",
        data: {
            AdFlag: 8192,
            AdPointType: 2,
            AdPlatform: 1
        },
        success: function (data) {
            $.each(data, function (index, obj) {
                obj.HasHref = obj.ConnectionUrl != '' ? true : false;

                var v = obj.AdUrl.split(".");

                if (v[1] == "swf") {
                    obj.IsSwf = true;
                } else {
                    obj.IsSwf = false;
                }

                SGT.Main.QueryFns['IndexAD'].push(obj);

                if (v[1] == "swf") {

                    swfobject.embedSWF('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + obj.AdUrl,
                        'adFlash_' + obj.AdID,
                        "100%",
                        obj.ConnectionUrl + 'px',
                        "9",
                        "../../Scripts/expressInstall.swf",
                        {},
                        { wmode: "transparent", allowScriptAccess: "always", scale: "NoScale" },
                        {});
                }
            });
            //SGT.Main.QueryFns['IndexAD'](data);
        },
        error: function (e) {
            // alert(e.responseText);
        }
    });
});

//$SGT.PageCompleted.Add(function () {
//    if (!SGT.Main.QueryFns['Member'].IsLogin()) {
//        var isShowFlash = $.cookie('ShowFlashAD');

//        if (isShowFlash != '1') {
//            // 新春廣告用
//            var newMask = document.createElement("div");
//            newMask.id = 'BodyMask';
//            newMask.style.position = "fixed";
//            newMask.style.zIndex = '99';
//            var _scrollWidth = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
//            var _scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
//            newMask.style.height = "100%";
//            newMask.style.width = "100%";
//            newMask.style.top = "0px";
//            newMask.style.left = "0px";
//            newMask.style.background = "black";
//            newMask.style.filter = "alpha(opacity=70)";
//            newMask.style.opacity = "0.70";
//            newMask.style.zIndex = 100;
//            document.body.appendChild(newMask);

//            var CtlDiv;
//            CtlDiv = document.createElement("div");
//            CtlDiv.id = "ShowFlashAD";
//            CtlDiv.style.position = "absolute";
//            CtlDiv.style.backgroundColor = "transparent";
//            CtlDiv.style.border = "0px";
//            CtlDiv.style.visibility = "visible";
//            CtlDiv.style.zIndex = 101;

//            var w = 850;
//            var h = 610;
//            CtlDiv.style.top = "50%";
//            CtlDiv.style.left = "50%";
//            CtlDiv.style.marginLeft = (-(w / 2) + 72) + 'px';
//            CtlDiv.style.marginTop = -(h / 2) + 'px';
//            CtlDiv.style.zIndex = 101;
//            CtlDiv.style.width = w + "px";
//            CtlDiv.style.height = h + "px";

//            var flashDiv = document.createElement("div");
//            flashDiv.id = "FlashAD";
//            CtlDiv.appendChild(flashDiv);
//            document.forms[0].appendChild(CtlDiv);

//            swfobject.embedSWF(SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Flash/2013NewYear.swf", "FlashAD", w, h, "9", "../../Scripts/expressInstall.swf", {}, { wmode: "transparent", allowScriptAccess: "always" });

//            $.cookie('ShowFlashAD', '1', { path: '/' });
//        }
//    }
//});

//function NewYearClose () {
//    $("#BodyMask").html("");
//    $("#BodyMask").remove();
//    $("#ShowFlashAD").html("");
//    $("#ShowFlashAD").remove();
//}