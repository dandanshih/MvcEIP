﻿
SGT.Main.Add('Register', {
	MemberAccount: ko.observable(""),
	MemberPassword: ko.observable(""),
	PasswordConfirm: ko.observable(""),
	//Mobile: ko.observable(""),
	Email: ko.observable(""),
	BingoSN: ko.observable(""),
	IntroducerNickName: ko.observable(""),
	Agree: ko.observable(false),
	VerificationCode: ko.observable(""),

	MemberAccountMsg: ko.observable(""),
	//MemberPasswordMsg: ko.observable("密碼必須是 6 ~ 12 碼的英文數字組合"),
	MemberPasswordMsg: ko.observable(""),
	PasswordConfirmMsg: ko.observable(""),
	//MobileMsg: ko.observable(""),
	EmailMsg: ko.observable(""),
	BingoSNMsg: ko.observable(""),
	IntroducerNickNameMsg: ko.observable(""),
	AgreeMsg: ko.observable(""),
	VerificationCodeMsg: ko.observable(""),
	TotalMsg: ko.observable(""),
    // 填寫序號 or 推薦人 控制，此值要搭配 Radio 的 value
	//RadioOptionType: ko.observable(""),
	//RadioOptionDefVal: ko.observable("BingoSN"),
	//RadioOptionEnable: ko.observable(false),

	ResetButtonEnable: ko.observable(true),
	RegisterButtonEnable: ko.observable(true),
	MobileAuthenticationButtonEnable: ko.observable(true),
	ReSendVerificationCodeButtonEnable: ko.observable(true),
	CancelConfirmMobileAuthenticationButtonEnable: ko.observable(true),
	CancelMobileAuthenticationButtonEnable: ko.observable(true),
	ReturnMobileAuthenticationButtonEnable: ko.observable(true),

	// 資料重設
	reset: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['Register'].ResetButtonEnable(false);
		SGT.Main.QueryFns['Register'].RegisterButtonEnable(false);
		SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(false);
		SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].CancelMobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].ReturnMobileAuthenticationButtonEnable(false);

		SGT.Main.QueryFns['Register'].MemberAccount("");
		SGT.Main.QueryFns['Register'].MemberPassword("");
		SGT.Main.QueryFns['Register'].PasswordConfirm("");
		//SGT.Main.QueryFns['Register'].Mobile("");
		SGT.Main.QueryFns['Register'].Email("");
		//SGT.Main.QueryFns['Register'].BingoSN("");
		SGT.Main.QueryFns['Register'].IntroducerNickName("");
		SGT.Main.QueryFns['Register'].Agree(false);
		SGT.Main.QueryFns['Register'].VerificationCode("");

		SGT.Main.QueryFns['Register'].MemberAccountMsg("");
		SGT.Main.QueryFns['Register'].MemberPasswordMsg("");
		SGT.Main.QueryFns['Register'].PasswordConfirmMsg("");
		//SGT.Main.QueryFns['Register'].MobileMsg("");
		SGT.Main.QueryFns['Register'].EmailMsg("");
		SGT.Main.QueryFns['Register'].BingoSNMsg("");
		SGT.Main.QueryFns['Register'].IntroducerNickNameMsg("");
		SGT.Main.QueryFns['Register'].AgreeMsg("");
		SGT.Main.QueryFns['Register'].VerificationCodeMsg("");
		SGT.Main.QueryFns['Register'].TotalMsg("");

		//SGT.Main.QueryFns['Register'].RadioOptionType("");

		// 啟用按鈕
		SGT.Main.QueryFns['Register'].ResetButtonEnable(true);
		SGT.Main.QueryFns['Register'].RegisterButtonEnable(true);
		SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(true);
		SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(true);
		SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(true);
		SGT.Main.QueryFns['Register'].CancelMobileAuthenticationButtonEnable(true);
		SGT.Main.QueryFns['Register'].ReturnMobileAuthenticationButtonEnable(true);

		var passwdBar = document.getElementById('passwdBar');
		if (passwdBar != null) {
			ResetBar();
		}

	    // 2013/06/07加入這段
		$("input").val("");
		$("input[type=password]").blur();
		SGT.Main.QueryFns['Register'].MemberPasswordMsg("");
		SGT.Main.QueryFns['Register'].PasswordConfirmMsg("");
	},

	// 註冊
	register: function () {
		if (!SGT.Main.QueryFns['Register'].accountValidate() ||
			!SGT.Main.QueryFns['Register'].passwordValidate() ||
			!SGT.Main.QueryFns['Register'].passwordConfirmValidate() ||
			//!SGT.Main.QueryFns['Register'].mobileValidate() ||
			!SGT.Main.QueryFns['Register'].emailValidate() ||
			!SGT.Main.QueryFns['Register'].agreeValidate() ||
			//!SGT.Main.QueryFns['Register'].otherValidate() ||
            !SGT.Main.QueryFns['Register'].BingoSNValidate() // ||
		    //!SGT.Main.QueryFns['Register'].IntroducerNickNameValidate()
			)
		{
			return;
		}				
		var memberAccount = SGT.Main.QueryFns['Register'].MemberAccount();
		var memberPassword = SGT.Main.QueryFns['Register'].MemberPassword();
		var mobile = "";//SGT.Main.QueryFns['Register'].Mobile();
		var email = SGT.Main.QueryFns['Register'].Email();
		var bingoSN = SGT.Main.QueryFns['Register'].BingoSN();
		var introducerNickName = "";//SGT.Main.QueryFns['Register'].IntroducerNickName();
		var registerModel = { "MemberAccount": memberAccount, "MemberPassword": memberPassword, "Mobile": mobile, "Email": email, "BingoSN": bingoSN, "IntroducerNickName": introducerNickName };
		
		// 禁用按鈕
		SGT.Main.QueryFns['Register'].ResetButtonEnable(false);
		SGT.Main.QueryFns['Register'].RegisterButtonEnable(false);
		$.ajax({
			type: "POST",
			url: "/MVC/api/account/Register",
			async: true,
			data: registerModel,
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0 && mobile != "") {
					location.href = "MobileAuthentication" + location.search;
				}
				else if (data.ResultCode == 0 && mobile == "") {
					SGT.Main.QueryFns['Register'].autoLogin();
				}
				else {					
				    alert(data.ResultMsg);
				    if (data.ResultCode == 200 && mobile == "") {
				        location.href = "/MVC";
				    }
				}

				if (data.ResultCode != 0) {
					// 啟用按鈕					
					SGT.Main.QueryFns['Register'].ResetButtonEnable(true);
					SGT.Main.QueryFns['Register'].RegisterButtonEnable(true);
				}
			},
			error: function (e) {				
				//alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['Register'].ResetButtonEnable(true);
				SGT.Main.QueryFns['Register'].RegisterButtonEnable(true);
			},
			complete: function () {

			}
		});
	},

	// 手機認證
	mobileAuthentication: function () {
		if (!SGT.Main.QueryFns['Register'].verificationCodeValidate()) {
			return;
		}
		
		var verificationCode = SGT.Main.QueryFns['Register'].VerificationCode();
		
		// 禁用按鈕
		SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(false);
		SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/MobileAuthentication",
			async: false,
			data: { "verificationCode": verificationCode },
			dataType: "json",
			success: function (data) {				
				if (data.ResultCode == 0) {
					// 清除關閉確認視窗
				    $('body').attr('onbeforeunload', '');
				    alert("驗證碼正確! 恭喜您帳號啟用成功!");
				    SGT.Main.QueryFns['Register'].autoLogin();
				}
				else if (data.ResultCode == 2) {
					alert("驗證碼逾時");
				}
				else if (data.ResultCode == 3) {
					location.href = "MobileAuthenticationFrequently" + location.search;
				}
				else if(data.ResultData == 6)
				{
				    $('body').attr('onbeforeunload', '');
				    alert("您已完成驗證。");
				    SGT.Main.QueryFns['Register'].autoLogin();
				}
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");
				}
				else {
					alert("驗證碼錯誤!");
					// alert(data.ResultMsg);
				}

				if (data.ResultCode != 0)
				{
					// 啟用按鈕
					SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(true);
					SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(true);
					SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(true);
				}
			},
			error: function (e) {
				//alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(true);
				SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(true);
				SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(true);
			},
			complete: function () {
				
			}
		});		
	},

	// 重新發送手機驗證碼
	reSendVerificationCode: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(false);
		SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/ReSendVerificationCode",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {
					SGT.Main.QueryFns["Register"].VerificationCode(data.Data);
					alert("簡訊已送出，請注意您的手機並請儘速啟用帳號。");
				}
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");
				}
				else if (data.ResultCode == 4) {
				    $('body').attr('onbeforeunload', '');
				    alert("您已完成驗證。");
				    SGT.Main.QueryFns['Register'].autoLogin();
                }
				else {
					// 清除關閉確認視窗
					 $('body').attr('onbeforeunload', '');					
					 location.href = "MobileAuthenticationFrequently" + location.search;
					 // alert(data.ResultMsg);					
				}
			},
			error: function (e) {
				//alert("error:" + e.responseText);
			},
			complete: function () {
				// 啟用按鈕
				SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(true);
				SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(true);
				SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(true);
			}
		});
	},

	// 確認取消手機驗證
	cancelConfirmMobileAuthentication: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['Register'].MobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].ReSendVerificationCodeButtonEnable(false);
		SGT.Main.QueryFns['Register'].CancelConfirmMobileAuthenticationButtonEnable(false);

		$('body').attr('onbeforeunload', ''); location.href = 'CancelMobileAuthentication' + location.search;
	},

	// 取消手機驗證
	cancelMobileAuthentication: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['Register'].CancelMobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].ReturnMobileAuthenticationButtonEnable(false);

		$.ajax({
			type: "POST",
			url: "/MVC/api/account/CancelMobileAuthentication",
			async: true,
			data: "",
			dataType: "json",
			success: function (data) {
				if (data.ResultCode == 0) {
					SGT.Main.QueryFns['Register'].autoLogin();					
				}
				else if (data.ResultCode == 99) {
					alert("驗證碼逾時");
					// alert("因您超過限定時間尚未完成手機驗證，請重新登入遊戲。");
				}
				else {
					alert(data.ResultMsg);
				}

				if (data.ResultCode != 0) {
					// 啟用按鈕
					SGT.Main.QueryFns['Register'].CancelMobileAuthenticationButtonEnable(true);
					SGT.Main.QueryFns['Register'].ReturnMobileAuthenticationButtonEnable(true);
				}
			},
			error: function (e) {
				//alert("error:" + e.responseText);
				// 啟用按鈕
				SGT.Main.QueryFns['Register'].CancelMobileAuthenticationButtonEnable(true);
				SGT.Main.QueryFns['Register'].ReturnMobileAuthenticationButtonEnable(true);
			},
			complete: function () {
				
			}
		});		
	},

	// 返回手機驗證
	returnMobileAuthentication: function () {
		// 禁用按鈕
		SGT.Main.QueryFns['Register'].CancelMobileAuthenticationButtonEnable(false);
		SGT.Main.QueryFns['Register'].ReturnMobileAuthenticationButtonEnable(false);

		location.href = "MobileAuthentication" + location.search;
	},

	// 自動登入
	autoLogin: function () {
		$.ajax({
			type: "POST",
			url: "/MVC/api/account/AutoLogin",
			async: false,
			data: "",
			dataType: "json",
			success: function (data) {
			    if (data.ResultCode == 1) {
			    	if (opener != null && typeof opener.window != 'unknown' && typeof opener != undefined) {
			            opener.window.location.reload();
			        }
			    	location.href = "/Web/Game/MiniList.aspx";
				}				
				else if (data.ResultCode == 98) {
					alert("登入資訊不正確");
				}
				else if (data.ResultCode == 99 || data.ResultCode == 12) {
				    alert("遊戲目前進行維護中，請稍後再來玩！");
					window.close();
				}
				else {
					alert(data.ResultMsg);
				}
			},
			error: function (e) {
				//alert("error:" + e.responseText);
			}
		});
	},

	// 帳號驗證
	accountValidate: function () {
		var valFlag = true;
		
		if (SGT.Main.QueryFns['Register'].MemberAccount() == "") {			
			SGT.Main.QueryFns['Register'].MemberAccountMsg("帳號不可空白");
			valFlag = false;
		}
		else if (!SGT.Main.QueryFns['Register'].MemberAccount().match(/^[0-9a-zA-Z]{6,12}$/)) {
			SGT.Main.QueryFns['Register'].MemberAccountMsg("帳號必須是 6 ~ 12 碼的英文數字組合");
			valFlag = false;
		}
		else if (!SGT.Main.QueryFns['Register'].MemberAccount().match(/(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$/)) {
			SGT.Main.QueryFns['Register'].MemberAccountMsg("帳號至少須包含一個英文字母");
			valFlag = false;
		}
		else if ((SGT.Main.QueryFns['Register'].MemberAccount().indexOf(SGT.Main.QueryFns['Register'].MemberPassword()) > -1 && SGT.Main.QueryFns['Register'].MemberPassword() != "")
				 ){//(|| SGT.Main.QueryFns['Register'].MemberAccount().indexOf(SGT.Main.QueryFns['Register'].Mobile()) > -1 && SGT.Main.QueryFns['Register'].Mobile() != "")) {
			SGT.Main.QueryFns['Register'].MemberAccountMsg("帳號中不可包含密碼或手機號碼");
			valFlag = false;
		}
		else {
			$.ajax({
				type: "POST",
				url: "/AppAjaxs/RegisterValidation.ashx",
				async: false,
				data: "ResultType=2&CheckType=1&CheckData=" + SGT.Main.QueryFns['Register'].MemberAccount(),
				success: function (data) {
				    var sucessImg = "<img src='" + SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/register/acc_icon06.png'>"
				    SGT.Main.QueryFns['Register'].MemberAccountMsg(data == "Success" ? sucessImg : data);
				
					if (data != "此帳號已有人使用") {
						valFlag = true;
					}
					else {
						valFlag = false;					
					}
				},
				error: function (e) {
					valFlag = false;
					//alert(e.responseText);
				}
			});
		}

		return valFlag;
	},

	// 密碼驗證
	passwordValidate: function () {
		var passwdBar = document.getElementById('passwdBar');
		if (passwdBar != null) {
			ResetBar();
		}

		if (SGT.Main.QueryFns['Register'].MemberPassword() == "") {
		    SGT.Main.QueryFns['Register'].MemberPasswordMsg("密碼不可空白");
			return false;
		}

		if (!SGT.Main.QueryFns['Register'].MemberPassword().match(/^[0-9a-zA-Z]{6,12}$/)) {
			SGT.Main.QueryFns['Register'].MemberPasswordMsg("密碼必須是 6 ~ 12 碼的英文數字組合");
			return false;
		}
		
		if (SGT.Main.QueryFns['Register'].MemberPassword().match(/^[0-9]{6,12}$/)) {
		    SGT.Main.QueryFns['Register'].MemberPasswordMsg("密碼至少須包含一個英文字母");
			return false;
		}

		// 驗證密碼是否含四種不同字元以上
		var CompareString = '';
		for (i = 0; i < SGT.Main.QueryFns['Register'].MemberPassword().length; i++) {
			if (CompareString.indexOf(SGT.Main.QueryFns['Register'].MemberPassword().charAt(i)) == -1) {
				CompareString += SGT.Main.QueryFns['Register'].MemberPassword().charAt(i);
			}
		}
		if (CompareString.length < 4) {
		    SGT.Main.QueryFns['Register'].MemberPasswordMsg("密碼必須包含4種(含)字元以上");
			return false;
		}

		if ((SGT.Main.QueryFns['Register'].MemberPassword().indexOf(SGT.Main.QueryFns['Register'].MemberAccount()) > -1 && SGT.Main.QueryFns['Register'].MemberAccount() != "")
			// || (SGT.Main.QueryFns['Register'].MemberPassword().indexOf(SGT.Main.QueryFns['Register'].Mobile()) > -1 && SGT.Main.QueryFns['Register'].Mobile() != "")
            ) {
		    SGT.Main.QueryFns['Register'].MemberPasswordMsg("密碼中不可包含帳號或手機號碼");
			return false;
		}
		
		var sPW = SGT.Main.QueryFns['Register'].MemberPassword().toLowerCase();
		for (i = 0; i < sPW.length; i++) {
			// 判斷是否輸入3個連續數字或字母
			var code = sPW.charCodeAt(i);
			var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
			var code2 = '' + code + (code + 1) + (code + 2);
			var code3 = '' + code + (code - 1) + (code - 2);
			if (sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
			    SGT.Main.QueryFns['Register'].MemberPasswordMsg("密碼不可為連續數字或字母");
				return false;
			}
		}

		if (passwdBar != null) {	
			var ctl = document.getElementById("password");
			CreateRatePasswdReq(ctl);
		}
		SGT.Main.QueryFns['Register'].MemberPasswordMsg('<img src="' + SGT.WebSiteInfo.Urls.CdnUrl + '/Html/Images/Layout/register/acc_icon06.png">');
		return true;
	},

	// 密碼確認驗證
	passwordConfirmValidate: function () {
		if (SGT.Main.QueryFns['Register'].PasswordConfirm() == "") {
			SGT.Main.QueryFns['Register'].PasswordConfirmMsg("確認密碼不可空白");
			return false;
		}
		
		if (SGT.Main.QueryFns['Register'].MemberPassword() != SGT.Main.QueryFns['Register'].PasswordConfirm()) {
			SGT.Main.QueryFns['Register'].PasswordConfirmMsg("兩次密碼錯誤");
			return false;
		}

		SGT.Main.QueryFns['Register'].PasswordConfirmMsg('<img src="' + SGT.WebSiteInfo.Urls.CdnUrl + '/Html/Images/Layout/register/acc_icon06.png">');
		return true;
	},	

	// 手機驗證
	mobileValidate: function () {
		var valFlag = true;

		//if (SGT.Main.QueryFns['Register'].Mobile() == "") {
		//	SGT.Main.QueryFns['Register'].MobileMsg("手機號碼不可空白");
		//	return false;
		//}

		if (SGT.Main.QueryFns['Register'].Mobile() != "") {
			if (!SGT.Main.QueryFns['Register'].Mobile().match(/^[09]{2}[0-9]{8}$/)) {
				SGT.Main.QueryFns['Register'].MobileMsg("手機號碼格式錯誤");
				valFlag = false;
			}
			else if ((SGT.Main.QueryFns['Register'].Mobile().indexOf(SGT.Main.QueryFns['Register'].MemberAccount()) > -1 && SGT.Main.QueryFns['Register'].MemberAccount() != "") ||
				(SGT.Main.QueryFns['Register'].Mobile().indexOf(SGT.Main.QueryFns['Register'].MemberPassword()) > -1 && SGT.Main.QueryFns['Register'].MemberPassword() != "")) {
				SGT.Main.QueryFns['Register'].MobileMsg("手機中不可包含密碼或手機號碼");
				valFlag = false;
			}
			else {
				$.ajax({
					type: "POST",
					url: "/AppAjaxs/RegisterValidation.ashx",
					async: false,
					data: "ResultType=2&CheckType=3&CheckData=" + SGT.Main.QueryFns['Register'].Mobile(),
					success: function (data) {
					    var sucessImg = "<img src='" + SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/register/acc_icon06.png'>"
						SGT.Main.QueryFns['Register'].MobileMsg(data == "Success" ? sucessImg : data);

						if (data.substr(0, 4) == '<img') {
						    valFlag = true;
                            // 給 Radio 預設值
						    //SGT.Main.QueryFns['Register'].RadioOptionType(SGT.Main.QueryFns['Register'].RadioOptionDefVal());
                        }
						else {
							valFlag = false;
						}
					},
					error: function (e) {
						valFlag = false;
					}
				});
			}
		}
		else {
			SGT.Main.QueryFns['Register'].MobileMsg("");
		}

		//var tmp = valFlag && SGT.Main.QueryFns['Register'].Mobile() != '';
		//SGT.Main.QueryFns['Register'].RadioOptionEnable(tmp);

		//if (tmp) {
		    
		//} else {
		    // 驗證手機失敗清空
		    //SGT.Main.QueryFns['Register'].RadioOptionType("");
		    SGT.Main.QueryFns['Register'].BingoSN("");
		    SGT.Main.QueryFns['Register'].BingoSNMsg("");
		    SGT.Main.QueryFns['Register'].IntroducerNickName("");
		    SGT.Main.QueryFns['Register'].IntroducerNickNameMsg("");
		//}
		
		return valFlag;
	},

	// Email 驗證
	emailValidate: function () {
		var valFlag = true;

		//if (SGT.Main.QueryFns['Register'].Email() == "") {
		//	SGT.Main.QueryFns['Register'].EmailMsg("Email不可空白");
		//	return false;
		//}

		if (SGT.Main.QueryFns['Register'].Email() != "") {
			if (!SGT.Main.QueryFns['Register'].Email().match(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/)) {
				SGT.Main.QueryFns['Register'].EmailMsg("電子信箱格式錯誤");
				valFlag = false;
			}
			else {
				$.ajax({
					type: "POST",
					url: "/AppAjaxs/RegisterValidation.ashx",
					async: false,
					data: "ResultType=2&CheckType=8&CheckData=" + SGT.Main.QueryFns['Register'].Email(),
					success: function (data) {
					    var sucessImg = "<img src='" + SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/register/acc_icon06.png'>"
						SGT.Main.QueryFns['Register'].EmailMsg(data == "Success" ? sucessImg : data);

						if (data != "此電子信箱已被使用") {
							valFlag = true;
						}
						else {
							valFlag = false;
						}
					},
					error: function (e) {
						valFlag = false;
					}
				});
			}			
		}
		else {
			SGT.Main.QueryFns['Register'].EmailMsg("");
		}

		return valFlag;
	},

	BingoSNValidate: function(){
	    var valFlag = true;
	    if (SGT.Main.QueryFns['Register'].BingoSN() != "") { // && SGT.Main.QueryFns['Register'].Mobile() != '') {
	        //if (SGT.Main.QueryFns['Register'].Mobile() == "") {
	        //    SGT.Main.QueryFns['Register'].BingoSNMsg("請輸入手機號碼");
	        //    valFlag = false;
	        //    return valFlag;
	        //}
	        //if (!SGT.Main.QueryFns['Register'].BingoSN().match(/^[0-9a-zA-Z]+$/)) {
	        //    SGT.Main.QueryFns['Register'].BingoSNMsg("序號錯誤，請重新輸入");
	        //    //valFlag = false;
	        //}
	        //else {
	            $.ajax({
	                type: "POST",
	                url: "/AppAjaxs/RegisterValidation.ashx",
	                async: false,
	                data: "ResultType=2&CheckType=9&CheckData=" + SGT.Main.QueryFns['Register'].BingoSN(),
	                success: function (data) {
	                    if (data != "Success") {
	                        SGT.Main.QueryFns['Register'].BingoSNMsg(data);
	                        valFlag = false;
	                    }
	                    else {
	                        var sucessImg = "<img src='" + SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/register/acc_icon06.png'>"
	                        SGT.Main.QueryFns['Register'].BingoSNMsg(data == "Success" ? sucessImg : data);
	                    }
	                },
	                error: function (e) {
	                    valFlag = false;
	                }
	            });
	        //}
	    }
	    else {
	        SGT.Main.QueryFns['Register'].BingoSNMsg("");
	    }

	    return valFlag;
	},

	IntroducerNickNameValidate: function () {
	    var valFlag = true;
	    if (SGT.Main.QueryFns['Register'].IntroducerNickName() != "") { // && SGT.Main.QueryFns['Register'].Mobile() != '') {
	        if (!SGT.Main.QueryFns['Register'].IntroducerNickName().match(/^[\u0391-\uFFE5a-zA-Z0-9]+$/)) {
	            SGT.Main.QueryFns['Register'].IntroducerNickNameMsg("此暱稱無效");
	            //valFlag = false;
	        }
	        else {
	            $.ajax({
	                type: "POST",
	                url: "/AppAjaxs/RegisterValidation.ashx",
	                async: false,
	                data: "ResultType=2&CheckType=4&CheckData=" + SGT.Main.QueryFns['Register'].IntroducerNickName(),
	                success: function (data) {
	                    var sucessImg = "<img src='" + SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/register/acc_icon06.png'>"
	                    SGT.Main.QueryFns['Register'].IntroducerNickNameMsg(data == "Success" ? sucessImg : data);
	                },
	                error: function (e) {
	                    valFlag = false;
	                }
	            });
	        }
	    }
	    else {
	        SGT.Main.QueryFns['Register'].IntroducerNickNameMsg("");
	    }

	    return valFlag;
	},

	// 同意服務條款驗證
	agreeValidate: function () {		
		if (SGT.Main.QueryFns['Register'].Agree() == false) {
			SGT.Main.QueryFns['Register'].TotalMsg("");
			SGT.Main.QueryFns['Register'].AgreeMsg("須同意服務條款");
			return false;
		}

		SGT.Main.QueryFns['Register'].AgreeMsg("");
		return true;
	},

	// 驗證碼驗證
	verificationCodeValidate: function () {
		if (SGT.Main.QueryFns['Register'].VerificationCode() == "") {
			alert("驗證碼不可空白！");
			// SGT.Main.QueryFns['Register'].VerificationCodeMsg("驗證碼不可空白！");
			return false;
		}

		return true;
	},

	// 其他驗證
	otherValidate: function () {
	    var valFlag = true;

		

		//if (SGT.Main.QueryFns['Register'].Mobile() == "") {
		//	SGT.Main.QueryFns['Register'].MobileMsg("手機也需填寫才可獲得老幣唷！");
		//}
		var bmsg = SGT.Main.QueryFns['Register'].BingoSNMsg();

		if (bmsg != "" && bmsg.substr(0, 4) != '<img' && SGT.Main.QueryFns['Register'].TotalMsg() != "*序號錯誤，確定不修改，請按【送出】進入遊戲。") {
		    SGT.Main.QueryFns['Register'].TotalMsg("*序號錯誤，確定不修改，請按【送出】進入遊戲。");
		    return false;
		}

		if (SGT.Main.QueryFns['Register'].Email() != "" && SGT.Main.QueryFns['Register'].BingoSN() != "") {
			valFlag = true;
		}
		else if ((SGT.Main.QueryFns['Register'].Email() == "" || SGT.Main.QueryFns['Register'].BingoSN() == "") && SGT.Main.QueryFns['Register'].TotalMsg() != "") {
			valFlag = true;
		}
		else {
			SGT.Main.QueryFns['Register'].TotalMsg("*確定不填寫，請按【送出】進入遊戲。");
			valFlag = false;
		}

		return valFlag;
	},

	BingoSNChange: function () {
	    SGT.Main.QueryFns['Register'].IntroducerNickName("");
	    SGT.Main.QueryFns['Register'].IntroducerNickNameMsg("");
	},

	IntroducerNickNameChange: function () {
	    SGT.Main.QueryFns['Register'].BingoSN("");
	    SGT.Main.QueryFns['Register'].BingoSNMsg("");
	}
});
