declare var $SGT;
//declare var SGT;
declare var ko;
declare var $;
declare var parseInt;

// �N��� Page ���X�����ǤJ knockout �޲z
SGT['Main'].Add('SGTPage', {});

module SGT.Pages {
    export class PageMgr {

        // Ko �� Page ���X
        static KoPageCollection = SGT['Main'].QueryFns['SGTPage'];

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // �s�W�@�� Page Instance �� PageMgr ��
        static Add(key: string, page: Page): void {
            if (KoPageCollection[key]) {
                throw 'key duplicate';
            }
            KoPageCollection[key] = page;
        }

        // ���o���w�� Page Instance
        static GetInstance(key: string): Page {
            return KoPageCollection[key];
        }
    }

    export class Page {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor(callback: () => void = null, pageSize: number = 15) {
            this.ChangeEvent = callback;
            this.PageSize(pageSize);
        }

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �ثe����
        PageIndex: (number?) => number = ko.observable(1);
        // ��������
        JumpIndex: (number?) => number = ko.observable(1);
        // �@����ܵ���
        PageSize: (number?) => number = ko.observable(15);
        // �`����
        TotalRecord: (number?) => number = ko.observable(0);

        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // �Ĥ@���ƥ�
        ChangeFirst(): void {
            if (this.PageIndex() != 1) {
                this.PageIndex(1);
                this.JumpIndex(1);
                this.ChangePage(1);
            }
        }
        // �W�@���ƥ�
        ChangePre(): void {
            if (this.PageIndex() - 1 >= 1) {
                this.PageIndex(this.PageIndex() - 1);
                this.JumpIndex(this.PageIndex());
                this.ChangePage(this.PageIndex());
            }
        }
        // �U�@���ƥ�
        ChangeNext(): void {
            var maxPage: number = Math.ceil(this.TotalRecord() / this.PageSize());
            var idx = parseInt(this.PageIndex().toString(), 10) + parseInt("1", 10);
            //console.log(typeof idx);
            //console.log(idx);
            //console.log(idx <= maxPage);
            if (idx <= maxPage) {
                this.PageIndex(idx);
                this.JumpIndex(idx);
                this.ChangePage(idx);
            } else {
                this.PageIndex(maxPage);
                this.JumpIndex(maxPage);
                this.ChangePage(maxPage);
            }
        }
        // �̫�@���ƥ�
        ChangeLast(): void {
            var maxPage: number = Math.ceil(this.TotalRecord() / this.PageSize());
            if (this.PageIndex() != maxPage) {
                this.PageIndex(maxPage);
                this.JumpIndex(maxPage);
                this.ChangePage(maxPage);
            }
        }
        // �����ƥ�
        ChangeJump(): void {
            var idx = this.JumpIndex();
            if (idx.toString() == 'NaN') return;
            if (idx == this.PageIndex()) return;
            if (idx < 1) return;
            if (idx > Math.ceil(this.TotalRecord() / this.PageSize())) return;
            this.PageIndex(idx);
            this.JumpIndex(idx);
            this.ChangePage(idx);
        }

        /// --------------------------------------
        /// private function
        /// --------------------------------------
        // �Ҧ������̫��ڰ���ʧ@��function
        private ChangePage(index: number): void {
            var maxPage: number = Math.ceil(this.TotalRecord() / this.PageSize());

            //this.PageIndex(index);
            //this.JumpIndex(index);
            //console.log(this.PageIndex());
            //console.log(this.JumpIndex());
            if (this.ChangeEvent) {
                this.ChangeEvent();
            }
        }

        // ���ѥ� Page �B�o�ƥ��A�q�� View �� CallBack ��k
        private ChangeEvent: () => void;
    }
}
