SGT['Main'].Add('SGTPage', {
});
var SGT;
(function (SGT) {
    (function (Pages) {
        var PageMgr = (function () {
            function PageMgr() { }
            PageMgr.KoPageCollection = SGT['Main'].QueryFns['SGTPage'];
            PageMgr.Add = function Add(key, page) {
                if(PageMgr.KoPageCollection[key]) {
                    throw 'key duplicate';
                }
                PageMgr.KoPageCollection[key] = page;
            };
            PageMgr.GetInstance = function GetInstance(key) {
                return PageMgr.KoPageCollection[key];
            };
            return PageMgr;
        })();
        Pages.PageMgr = PageMgr;        
        var Page = (function () {
            function Page(callback, pageSize) {
                if (typeof callback === "undefined") { callback = null; }
                if (typeof pageSize === "undefined") { pageSize = 15; }
                this.PageIndex = ko.observable(1);
                this.JumpIndex = ko.observable(1);
                this.PageSize = ko.observable(15);
                this.TotalRecord = ko.observable(0);
                this.ChangeEvent = callback;
                this.PageSize(pageSize);
            }
            Page.prototype.ChangeFirst = function () {
                if(this.PageIndex() != 1) {
                    this.PageIndex(1);
                    this.JumpIndex(1);
                    this.ChangePage(1);
                }
            };
            Page.prototype.ChangePre = function () {
                if(this.PageIndex() - 1 >= 1) {
                    this.PageIndex(this.PageIndex() - 1);
                    this.JumpIndex(this.PageIndex());
                    this.ChangePage(this.PageIndex());
                }
            };
            Page.prototype.ChangeNext = function () {
                var maxPage = Math.ceil(this.TotalRecord() / this.PageSize());
                var idx = parseInt(this.PageIndex().toString(), 10) + parseInt("1", 10);
                if(idx <= maxPage) {
                    this.PageIndex(idx);
                    this.JumpIndex(idx);
                    this.ChangePage(idx);
                } else {
                    this.PageIndex(maxPage);
                    this.JumpIndex(maxPage);
                    this.ChangePage(maxPage);
                }
            };
            Page.prototype.ChangeLast = function () {
                var maxPage = Math.ceil(this.TotalRecord() / this.PageSize());
                if(this.PageIndex() != maxPage) {
                    this.PageIndex(maxPage);
                    this.JumpIndex(maxPage);
                    this.ChangePage(maxPage);
                }
            };
            Page.prototype.ChangeJump = function () {
                var idx = this.JumpIndex();
                if(idx.toString() == 'NaN') {
                    return;
                }
                if(idx == this.PageIndex()) {
                    return;
                }
                if(idx < 1) {
                    return;
                }
                if(idx > Math.ceil(this.TotalRecord() / this.PageSize())) {
                    return;
                }
                this.PageIndex(idx);
                this.JumpIndex(idx);
                this.ChangePage(idx);
            };
            Page.prototype.ChangePage = function (index) {
                var maxPage = Math.ceil(this.TotalRecord() / this.PageSize());
                if(this.ChangeEvent) {
                    this.ChangeEvent();
                }
            };
            return Page;
        })();
        Pages.Page = Page;        
    })(SGT.Pages || (SGT.Pages = {}));
    var Pages = SGT.Pages;
})(SGT || (SGT = {}));
