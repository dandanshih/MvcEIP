var SGT;
(function (SGT) {
    (function (Pages) {
        var EnterNoviceSN = (function () {
            function EnterNoviceSN(koName) {
                if (typeof koName === "undefined") { koName = 'EnterNoviceSN'; }
                this.KoName = '';
                this.Sno = ko.observable("");
                this.KoName = koName;
            }
            EnterNoviceSN.prototype.Submit = function () {
                var self = this;
                if(self.Sno() == '') {
                    alert($SGT.Message.EnterNoviceSN.Error[0]);
                    return;
                }
                $.getJSON('//' + SGT.WebSiteInfo.Urls.DataInfoUrl + '/DataInfo/SendSNForBingo.ashx?callback=?', {
                    Data: self.Sno()
                }, function (data) {
                    if(data && data.Data && data.Data.length > 0) {
                        switch(data.Data[0].FSResult) {
                            case "0": {
                                SGT.Flash.FlashEvent.ShowLuckMoney(data.Data[0].Point);
                                SGT.Flash.FlashEvent.CloseSelf();
                                break;

                            }
                            default:
                            case "1": {
                                alert($SGT.Message.EnterNoviceSN.Error[1]);
                                break;

                            }
                            case "2": {
                                alert($SGT.Message.EnterNoviceSN.Error[2]);
                                break;

                            }
                        }
                    } else {
                        alert($SGT.Message.EnterNoviceSN.Error[1]);
                    }
                });
            };
            return EnterNoviceSN;
        })();
        Pages.EnterNoviceSN = EnterNoviceSN;        
    })(SGT.Pages || (SGT.Pages = {}));
    var Pages = SGT.Pages;

})(SGT || (SGT = {}));

