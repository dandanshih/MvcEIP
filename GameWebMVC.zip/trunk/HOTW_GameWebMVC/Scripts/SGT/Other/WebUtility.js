﻿

// 取得網址參數
function getParameter(parameterName) {
    var queryString = location.search.substring(1).toLowerCase();
    // Add "=" to the parameter name (i.e. parameterName=value)
    var parameterName = (parameterName + "=").toLowerCase();

    if (queryString.length > 0) {
        // Find the beginning of the string
        begin = queryString.indexOf(parameterName);
        // If the parameter name is not found, skip it, otherwise return the value
        if (begin != -1) {
            // Add the length (integer) to the beginning
            begin += parameterName.length;
            // Multiple parameters are separated by the "&" sign
            end = queryString.indexOf("&", begin);
            if (end == -1) {
                end = queryString.length
            }
            // Return the string
            return unescape(queryString.substring(begin, end));
        }
        // Return "null" if no parameter has been found
        return null;
    }
}

String.Format = function () {
    if (arguments.length == 0) {
        return null;
    }

    var str = arguments[0];

    for (var i = 1; i < arguments.length; i++) {

        var re = new RegExp('\\{' + (i - 1) + '\\}', 'gm');
        str = str.replace(re, arguments[i]);
    }
    return str;
}

String.prototype.format = function () {
    var formatStr = this;
    
    for (var i = 0; i < arguments.length; i++) {

        var re = new RegExp('\\{' + (i) + '\\}', 'gm');
        formatStr = formatStr.replace(re, arguments[i]);
    }
    return formatStr;
}

String.prototype.StartsWith = function (str) {
    return (this.match("^" + str) == str)
}

String.prototype.EndsWith = function (str) {
    return (this.match(str + "$") == str)
}

// 數值轉成三位一個逗點字串
Number.prototype.addCommas = function () {
    x = this.toString().split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

// 由JavaScript 傳資料給C#
function PostToIIS(RedirectUrl, params) {
    var theForm = document.forms[0];
    if (RedirectUrl.length > 0) {
        theForm.action = RedirectUrl;
    }
    for (var key in params) {
        var hiddenField = document.createElement("input");
        hiddenField.type = "hidden";
        hiddenField.name = key;
        hiddenField.value = params[key];
        theForm.appendChild(hiddenField);
    }

    theForm.submit();
}

function RsaEncrypt(encryptValue) {
    var result = "";
    n = "C61356508EB5369A8CFA3F6182550FAFBC76F0E40AA976FD878234DB19B4A7B3986091B138C204456F2AE11C73B2D3B9568112F8E9606116C9153D7DD47F505230D908FBFB2B74A4A1E067A0669010D9B405F094EA97D25E51F1596F34A00F2F5FA87061666DFE41BA2DFF5A08DCFBB9253794AB6D63A77C12E182442925AAC1";
    e = "10001";
    var rsa = new RSAKey();
    rsa.setPublic(n, e);
    var res = rsa.encrypt(encryptValue);
    return res;
}

function PopGamePage(Params) {
    if (SGT.Main.QueryFns['Member'] != undefined) {
        if (!SGT.Main.QueryFns['Member'].ShowLoginTips()) {
            return;
        }
    }
    var IsMaxGamePage = swfobject.getObjectById('hidflash').getAutoWinSize();

    var MaxWidth = screen.width - 20;
    var MaxHeight = screen.height - 100;
    var GetParams = '';
    for (var i in Params) {
        if (GetParams != '') {
            GetParams += '&';
        } else if (GetParams == '') {
            GetParams += 'FirstIn=1&'
        }
        GetParams += i + '=' + Params[i];
    }
    var strSize = '';
    if (IsMaxGamePage == 1) {
        strSize = 'height=' + MaxHeight + ', width=' + MaxWidth + ',fullscreen=yes,';
        //strSize = 'height=' + MaxHeight + ', width=' + MaxWidth + ',';
    }
    var aaaa = window.open('/Web/Game/MiniList.aspx?' + GetParams, 'newwindow', strSize + 'top=0, left=0, resizable=yes,menubar=no,status=no,scrollbars=no');
}

function PopPage(settings) {
    var _defaultSettings = {
        url: "",
        isMaxPage: 1,//swfobject.getObjectById('hidflash').getAutoWinSize(),
    };

    var _settings = $.extend(_defaultSettings, settings);

    var MaxWidth = screen.width - 20;
    var MaxHeight = screen.height - 100;

    var strSize;

    if (_settings.isMaxPage == "1") {
        strSize = 'height=' + MaxHeight + ', width=' + MaxWidth + ',fullscreen=yes,';
    }

    var aaaa = window.open(_settings.url, 'newwindow', strSize + 'top=0, left=0, resizable=yes,menubar=no,status=no,scrollbars=yes');
}

// -----檢查Flash版本-----
function FlashVersion() {
    return swfobject.hasFlashPlayerVersion('10.3');
}