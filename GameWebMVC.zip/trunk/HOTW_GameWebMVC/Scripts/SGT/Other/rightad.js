﻿// JavaScript Document
function CheckUIElements()
{
var yMenu1From, yMenu1To, yOffset, timeoutNextCheck;
var D1 = document.getElementById ('D1'), D2 = document.getElementById ('D2');
var wndWidth = parseInt(document.body.clientWidth);
yMenu1From = parseInt (D1.style.top, 10);
yMenu1To = document.documentElement.scrollTop+document.body.scrollTop + 100; /*下拉後浮水印離上方的距離*/
   if (yMenu1To <500)/*初始浮水印璃上方距離*/
     { yMenu1To =500}
	 
   if (yMenu1To >D2.offsetHeight-280)
     { yMenu1To =D2.offsetHeight-280;} 
timeoutNextCheck = 150;
if ( yMenu1From != yMenu1To ) 
{
yOffset = Math.ceil( Math.abs( yMenu1To - yMenu1From ) / 20 );
if ( yMenu1To < yMenu1From )
yOffset = -yOffset;
D1.style.top = (parseInt (D1.style.top, 10) + yOffset) + 'px';
timeoutNextCheck = 10;
}
setTimeout ("CheckUIElements()", timeoutNextCheck);
}

function MovePosition()
{
var wndWidth = parseInt(document.body.clientWidth);
var D1 = document.getElementById ('D1');
D1.style.top = (document.body.scrollTop - 1000) + 'px';/*初始浮水印滑動的速度*/
D1.style.visibility = "visible";
CheckUIElements();
return true;
}