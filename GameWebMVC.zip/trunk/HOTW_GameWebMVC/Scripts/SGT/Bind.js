﻿
$SGT.FlagsMgr = new SGT.DataInfo.FlagsDataManager();

$SGT.PageLoad.Add(function () { SGT.Main.Bind() });

$SGT.PageCompleted.Add(function () {
    var platform = "Web";
    if (typeof GetPlatform == 'function') {
        platform = GetPlatform();
    }
    $.getJSON("/Mvc/api/staticdata/Get", { Flags: $SGT.FlagsMgr.Flags, Data: "", Platform: platform }, function (data) {
        $SGT.FlagsMgr.Modify(data);
    });
});

SGT.DataInfo.GetSignalFlagData = function (type, qryData) {
    var tmp = {};
    tmp[type] = qryData;
    var platform = "Web";
    if (typeof GetPlatform == 'function') {
        platform = GetPlatform();
    }
    $.getJSON("/Mvc/api/staticdata/Get", { Flags: type, Data: JSON.stringify(tmp), Platform: platform }, function (data) {
        $SGT.FlagsMgr.ModifyOne(type, data);
    });
}