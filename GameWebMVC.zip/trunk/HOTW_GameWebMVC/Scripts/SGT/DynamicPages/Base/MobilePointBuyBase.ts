﻿//declare var SGT;
declare var $SGT;
declare var $;


module SGT.DynamicPages {

    // 記錄結構 (對應 Api 傳出結構)
    export class Base_Struct_PayRecord {
        // 儲值類型
        ProductGroup: number = 0;
        // 購買金額編號
        ValueID: number = 0;
        // 付費方式編號
        ProductID: number = 0;
        // 發票取得方式 (0:捐給創世基金會 1:索取電子發票 2:索取紙本發票)
        InvoiceType: number = 0;
        // 電子發票寄送電子信箱
        InvoiceEmail: string = "";
        // 發票收件人
        InvoiceName: string = "";
        // 發票收件地址城市編號
        InvoiceCityID: number = 0;
        // 發票收件地址鄉鎮市編號
        InvoiceZoneID: string = "";
        // 發票收件地址
        InvoiceAddress: string = "";
    }

    // 金額結構 (對應 Api 傳出結構)
    export class Base_Struct_ValueList {
        // 金額編號
        ID: number;
        // 金額
        Value: number;
        // 點數
        Point: number;
        // 包月每日贈點
        EveryDayPoint: number;
        // 包月總贈點
        TotalPoint: number;
        // 圖片src
        Img: string;
        // 圖片onmouseover
        ImgOver: string;
        // 圖片onmousedown
        ImgDown: string;
        // 付款方式編號列表 (以 "," 分隔)
        ProductList: string;
    }

    // 付費方式結構 (對應 Api 傳出結構)
    export class Base_Struct_ProductList {
        // 付費方式編號
        ID: number;
        // 付費方式名稱
        Name: string;
        // 付費方式備註(名稱後紅色字體)
        Text: string;
        // 目前狀態
        Status: string;
        // 是否維護中
        IsMaintain: bool;
        // 教學連結
        HelpUrl: string;
        // 是否顯示輸入發票資訊
        IsNeedInvoice: bool;
        // 圖片src
        Img: string;
        // 何處買連結
        ShopUrl: string;
        // 是否使用PaymentGateway
        IsPG: bool;
        // 不使用PaymentGateway轉頁網址
        Redirect: string;
    }

    // 金額、付費方式的關聯屬性結構
    export class Base_Struct_ValueProductSetting {
        // 是否顯示 ECoupon
        IsShowECoupon: bool = false;
    }

    // 縣市鄉鎮結構 (對應 Api 傳出結構)
    export class Base_Struct_CityList {
        // 縣市編號
        CityID: number;
        // 縣市名稱
        CityName: string;
        // 鄉鎮市編號列表
        // [0] ZoneID: 鄉鎮市編號
        // [1] ZoneName: 鄉鎮市名稱
        // [2] ZipCode: 鄉鎮市郵遞區號
        ZoneList: string[][];
    }

    // 鄉鎮市列表回傳結構
    export class Base_Struct_ZoneList {
        // 鄉鎮市編號
        ZoneID: string = "";
        // 鄉鎮市名稱
        ZoneName: string = "";
        // 郵遞區號
        ZipCode: string = "";
    }

    // 取得會員獲得金額點數結構 (對應 Api 傳出結構)
    export class Base_Struct_Worth {
        // 金額
        Price: number = 0;
        // 點數
        ResultPoints: number = 0;
        // 每日補點
        EveryDayPoints: number = 0;
        // 贈點
        GiftPoints: number = 0;
    }

    // 檢查功能回傳結構
    export class Base_Struct_CheckResult {
        // 是否成功
        IsSuccess: bool = false;
        // 回傳訊息
        Message: string = "";
    }

    // 檢查功能回傳結構
    export class Base_Struct_CheckValueECouponResult {
        // 是否成功
        IsSuccess: bool = false;
        // 回傳訊息
        Message: string = "";
        // 折扣金額
        ECouponValue: number = 0;
        // 付款方式列表
        ProductList: string = "";
    }

    // 確認付款結構 (對應 Model/PointBuyGoPayment 結構)
    export class Base_Struct_GoPayment {
        // 交易金額
        Price: number = 0;
        // 交易點數
        Points: number = 0;
        // 每日補點
        EveryDayPoints: number = 0;
        // 贈點
        GiftPoints: number = 0;
        // 儲值類型 (1:線上購點 2:序號儲值 3:超值包月 4:線上轉點 5:FB儲值 6:背動式儲值)
        ProductGroup: number = 0;
        // 儲值金額編號
        ValueID: number = 0;
        // 付款方式編號
        ProductID: number = 0;
        // ECoupon序號
        ECoupon: string = "";
        // 發票取得方式 (0:捐給創世基金會 1:索取電子發票 2:索取紙本發票)
        InvoiceType: number = 0;
        // 發票寄送Email
        InvoiceEmail: string = "";
        // 發票寄送人
        InvoiceName: string = "";
        // 發票寄送縣市編號
        InvoiceCityID: number = 0;
        // 發票寄送區域編號
        InvoiceZoneID: string = "";
        // 發票寄送地址
        InvoiceAddress: string = "";
        // 儲值序號
        StoreCardSN: string = "";
        // 序號驗證碼
        StoreCardPwd: string = "";
        // 平台 (1:WEB 2:大廳 3:FB 4:113轉帳 5:Mobile)
        Platinum: number = 5;
    }

    // 線上購點 Base
    export class PointBuyBase {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor() {

        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        // 儲值類型 (1:線上購點 2:序號儲值 3:超值包月 4:線上轉點 5:FB儲值 6:背動式儲值)
        private _ProductGroup: number = 0;
        // 是否正在執行中
        private _IsRun: bool = false;
        // 是否使用最後一次的操作紀錄
        private _IsLastRecord: bool = false;
        // 金額列表
        private _ValueSource: Base_Struct_ValueList[] = [];
        // 付費方式列表
        private _ProductSource: Base_Struct_ProductList[] = [];
        // 金額+付費方式 對應屬性列表
        private _ValueProductSource: number[][] = [];
        // 縣市列表
        private _CitySource: Base_Struct_CityList[] = [];
        // 使用記錄 (若無紀錄則是預設資料)
        private _PayRecord: Base_Struct_PayRecord;
        // 回傳檢查狀態碼(此欄位可以通用)
        private _ResultCode: number;

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // 初始化，取得資料來源
        public Base_Init(productGroup: number): void {
            var self = this;
            self._ProductGroup = productGroup;

            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/MobilePointBuyBase",
                data: { product: self._ProductGroup },
                async: false,
                dataType: "json",
                success: function (data) {
                    self._IsLastRecord = data.IsLastRecord;
                    self._PayRecord = data.PayRecord;
                    self._ValueSource = data.ValueSource;
                    self._ProductSource = data.ProductSource;
                    self._ValueProductSource = data.ValueProductSource;
                    self._CitySource = data.CitySource;
                    self._ResultCode = data.ResultCode;
                },
                error: function (e) {
                    alert("error:" + e.message);
                },
                complete: function () {
                }
            });
        }

        // 取得是否使用最後一次的操作紀錄
        public Base_Get_IsLastRecord(): bool {
            return this._IsLastRecord;
        }

        // 取得記錄
        public Base_Get_PayRecord(): Base_Struct_PayRecord {
            return this._PayRecord;
        }

        // 取得所有金額列表
        public Base_Get_ValueList(): Base_Struct_ValueList[] {
            return this._ValueSource;
        }

        // 取得所有付款方式
        public Base_Get_ProductAll(): Base_Struct_ProductList[] {
            return this._ProductSource;
        }

        // 取得付款方式列表
        public Base_Get_ProductList(productIdList: string): Base_Struct_ProductList[] {

            var self = this;

            // 取得付款方式編號
            var productIdArr: string[] = (productIdList) ? productIdList.split(',') : [];

            // 回傳付款方式列表
            var resultProductList: Base_Struct_ProductList[] = [];

            // 取得
            for (var i = 0, icount = productIdArr.length; i < icount; i++) {

                for (var j = 0, jcount = self._ProductSource.length; j < jcount; j++) {

                    if (productIdArr[i] == self._ProductSource[j].ID.toString()) {
                        resultProductList.push(self._ProductSource[j]);
                    }
                }
            }

            return resultProductList;
        }

        // 取得 金額+付費方式 設定參數
        public Base_Get_ValueProductSetting(valueId: number, productId: number): Base_Struct_ValueProductSetting {

            // 回傳 object 結構
            var result = new Base_Struct_ValueProductSetting();

            if (!valueId || !productId) { return result; }

            // 取得
            for (var i = 0, count = this._ValueProductSource.length; i < count; i++) {
                if (this._ValueProductSource[i][0] == valueId && this._ValueProductSource[i][1] == productId) {
                    result.IsShowECoupon = (this._ValueProductSource[i][2] == 1);
                    break;
                }
            }

            return result;
        }

        // 取得縣市列表
        public Base_Get_CityList(): Base_Struct_CityList[] {
            return this._CitySource;
        }

        // 取得鄉鎮市列表
        public Base_Get_ZoneList(cityId: number): Base_Struct_ZoneList[] {

            var self = this;

            // 回傳鄉鎮市列表
            var zoneList: Base_Struct_ZoneList[] = [];

            if (/\d+/.test(cityId.toString())) {

                var zone: string[][];

                // 取得
                for (var i = 0, icount = this._CitySource.length; i < icount; i++) {

                    if (this._CitySource[i].CityID == cityId) {
                        zone = self._CitySource[i].ZoneList;
                        break;
                    }
                }

                if (zone) {
                    for (var i = 0, icount = zone.length; i < icount; i++) {
                        zoneList.push(() => {
                            var sub = new Base_Struct_ZoneList();
                            sub.ZoneID = zone[i][0];
                            sub.ZoneName = zone[i][1];
                            sub.ZipCode = zone[i][2];
                            return sub;
                        } ());
                    }
                }
            }

            return zoneList;
        }

        // 取得會員獲得金額點數
        public Base_Get_Worth(valueId: number, productId: number, ecoupon: string = ""): Base_Struct_Worth {

            if (!valueId || !productId) { return new Base_Struct_Worth(); }

            // 回傳 object 結構
            var result: Base_Struct_Worth;

            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/GetMemberWorth",
                data: { ProductGroup: this._ProductGroup, PaymentValueID: valueId, ProductType: productId, ECouponCode: ecoupon },
                async: false,
                dataType: "json",
                success: function (data) {
                    result = data;
                },
                error: function (e) {
                    result = new Base_Struct_Worth();
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });

            return result;
        }

        // ECoupon 驗證
        public Base_Check_ECoupon(valueId: number, productId: number, ecoupon: string): Base_Struct_CheckResult {

            // 回傳 object 結構
            var result = new Base_Struct_CheckResult();

            if (!valueId || !productId) {
                return result;
            }

            if (!ecoupon || !ecoupon.replace(/^[ ]+$/, "") || !/^[0-9a-zA-Z]{0,50}$/.test(ecoupon)) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                return result;
            }

            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/AuthECoupon",
                async: false,
                data: { PaymentValueID: valueId, ProductType: productId, EcouponCode: ecoupon },
                dataType: "json",
                success: function (data) {
                    switch (data.ResultCode) {
                        case 0:     // 正常
                            result.IsSuccess = true;
                            break;
                        case 1:     // 未達指定金額
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[1];
                            break;
                        case 2:     // 此序號限本人使用
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[2];
                            break;
                        case 3:     // 此序號已過期
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[3];
                            break;
                        case 4:     // 此序號已鎖定
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[4];
                            break;
                        case 5:     // 此序號不存在
                        case 6:     // 此序號已停用
                        case 99:    // 其他錯誤
                        case -1:    // 格式錯誤
                        default:
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                            break;
                    }
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });

            return result;
        }

        // ECoupon 驗證，並取得儲值金額對應的付款方式列表
        public Base_Check_ValueECoupon(valueId: number, ecoupon: string): Base_Struct_CheckValueECouponResult {
            // 回傳 object 結構
            var result = new Base_Struct_CheckValueECouponResult();

            if (!valueId) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                return result;
            }

            if (!ecoupon || !ecoupon.replace(/^[ ]+$/, "") || !/^[0-9a-zA-Z]{0,50}$/.test(ecoupon)) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                return result;
            }

            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/AuthValueECoupon",
                async: false,
                data: { PaymentValueID: valueId, EcouponCode: ecoupon },
                dataType: "json",
                success: function (data) {
                    switch (data.ResultCode) {
                        case 0:     // 正常
                            result.IsSuccess = true;
                            result.ECouponValue = data.ECouponValue;
                            result.ProductList = data.ProductList;
                            break;
                        case 1:     // 未達指定金額
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[1];
                            break;
                        case 2:     // 此序號限本人使用
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[2];
                            break;
                        case 3:     // 此序號已過期
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[3];
                            break;
                        case 4:     // 此序號已鎖定
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[4];
                            break;
                        case 5:     // 此序號不存在
                        case 6:     // 此序號已停用
                        case 99:    // 其他錯誤
                        case -1:    // 格式錯誤
                        default:
                            result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                            break;
                    }
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });

            return result;
        }

        // 驗證Email格式
        public Base_Check_Email(email: string): Base_Struct_CheckResult {

            var result = new Base_Struct_CheckResult();

            if (!email || !email.replace(/^[ ]+$/, "")) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_Email[0];
            } else if (!/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(email) || email.length > 50) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_Email[1];
            } else {
                result.IsSuccess = true;
            }

            return result;
        }

        // 驗證發票收件人格式
        public Base_Check_InvoiceName(name: string): Base_Struct_CheckResult {

            var result = new Base_Struct_CheckResult();

            if (!name || !name.replace(/^[ ]+$/, "")) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceName[0];
            } else if (!/^[\u0391-\uFFE5a-zA-Z0-9]{1,15}$/.test(name)) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceName[1];
            } else {
                result.IsSuccess = true;
            }

            return result;
        }

        // 驗證發票地址格式
        public Base_Check_InvoiceAddress(address: string): Base_Struct_CheckResult {

            var result = new Base_Struct_CheckResult();

            if (!address || !address.replace(/^[ ]+$/, "")) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceAddress[0];
            } else if (!/^[\u0391-\uFFE5a-zA-Z0-9\-]{1,40}$/.test(address)) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceAddress[1];
            } else {
                result.IsSuccess = true;
            }

            return result;
        }

        // 驗證儲值序號
        public Base_Check_StoreCardSN(sn: string): Base_Struct_CheckResult {

            var result = new Base_Struct_CheckResult();

            if (!sn || !sn.replace(/^[ ]+$/, "")) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_StoreCardSN[0];
            } else {
                result.IsSuccess = true;
            }

            return result;
        }

        // 驗證儲值驗證碼
        public Base_Check_StoreCardPwd(pwd: string): Base_Struct_CheckResult {

            var result = new Base_Struct_CheckResult();

            if (!pwd || !pwd.replace(/^[ ]+$/, "")) {
                result.Message = $SGT.Message.PointBuyBase.Base_Check_StoreCardPwd[0];
            } else {
                result.IsSuccess = true;
            }

            return result;
        }

        // 儲存玩家紀錄
        public Base_Set_Record(data: Base_Struct_PayRecord): void {

            data.ProductGroup = this._ProductGroup;

            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/SavePayRecord",
                data: data,
                async: false,
                dataType: "json",
                success: function (data) {

                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });
        }

        // 確認付款
        public Base_Submit_GoPayment(targetPage: string, isNewWindow: bool, postData: Base_Struct_GoPayment): void {
            if (this._IsRun) {
                return;
            }

            this._IsRun = true;

            postData.ProductGroup = this._ProductGroup;

            var form = document.createElement("form");
            form["name"] = "payForm";
            form["method"] = "post";
            form["action"] = targetPage;
            form["target"] = isNewWindow ? "_blank" : "_self";

            var ele = document.createElement("input");
            ele["name"] = "data";
            ele["value"] = JSON.stringify(postData);
            ele["hidden"] = true;
            ele["type"] = 'hidden';

            form.appendChild(ele);

            document.body.appendChild(form);
            document.forms[document.forms.length - 1]["submit"]();
        }

        public Base_Get_ResultCode(): number {
            return this._ResultCode;
        }
    }
}