declare var $;
declare var $SGT;
declare var GetPlatform;

module SGT.DynamicPages {

    // �|����b��T (���� Api �ǥX���c)
    export class Base_Struct_TransferInfo {
        // �O�_�@��|��
        IsGeneralMember: bool = false;
        // �`�I��
        TotalPoint: number = 0;
        // �i���I��
        FreePoint: number = 0;
        // ���I�W��
        TransferMax: number = 0;
        // ��w�I��
        LockPoint: number = 0;
        // ��w���
        LockDate: string = "";
        //��b����O%
        Transfee: number = 0;
    }

    // ��b�ʺٰO���M�� (���� Api �ǥX���c)
    export class Base_Struct_TransferTarget {
        // �|��Key
        No: string = "";
        // �|���ʺ�
        Name: string = "";
        // �O�_�b�u
        IsOnline: bool = false;
    }

    // �|����b�������c (���� Api �ǥX���c)
    export class Base_Struct_TransferMaster {
        // ���Key
        No: string = "";
        // ����s��
        TransferNo: number = 0;
        // ���b���O�_�O�o�e��
        IsSender: bool = false;
        // ����إߤ��
        CreateDate: string = "";
        // �o�e��ʺ�
        SendName: string = "";
        // ������ʺ�
        ReceiveName: string = "";
        // ��b�I��
        Points: number = 0;
        // �ثe���A (1:�P�N�M�������s 2:�T�{�ǰe�I�ƫ��s other:��r���A)
        Status: string = "";
    }

    // �|����b�����������c (���� Api �ǥX���c)
    export class Base_Struct_TransferMasterRecord {
        // ��ƦC��
        List: Base_Struct_TransferMaster[] = [];
        // �`����
        TotalRecord: number = 0;
    }

    // �|����b�������ӵ��c (���� Api �ǥX���c)
    export class Base_Struct_TransferDetail {
        // ����إߤ��
        CreateDate: string = "";
        // ����ԲӤ��e
        Memo: string = "";
    }

    // �|���T�{��b���G�^�ǵ��c (���� Api �ǥX���c)
    export class Base_Struct_TransferConfirmResult {
        // �O�_���\
        IsSuccess: bool = false;
        // �O�_���s���o�I��
        IsRegainPoint: bool = false;
        // �T��
        Message: string = "";
    }

    // �ˬd�\��^�ǵ��c
    export class Base_Struct_CheckResult {
        // �^�ǽs�X
        Code: number = 0;
        // �^�ǰT��
        Message: string = "";
    }

    // �|���T�{��b���G�^�ǵ��c (���� Api �ǥX���c)
    export class Base_Struct_SendSMSCodeResult {
        // �^�ǽs�X
        Code: number = 0;
        // �^�ǰT��
        Message: string = "";
    }

    // �|����b Base
    export class TransferBase {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor() {
            this.Base_Get_Init();
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        // �|����b��H�ʺ٦C��
        private _TransferTargetList: Base_Struct_TransferTarget[];
        // �|����b��T
        private _TransferMemberInfo: Base_Struct_TransferInfo;

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ��l�ơA���o��ƨӷ�
        private Base_Get_Init(): void {
            var self = this;
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/GetTransferInfo",
                async: false,
                dataType: "json",
                data: { Platform: platform },
                success: function (data) {
                    self._TransferTargetList = data.TargetList;
                    self._TransferMemberInfo = data.Info;
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });
        }

        // ���o�|����b��T
        public Base_Get_Info(): Base_Struct_TransferInfo {
            return this._TransferMemberInfo;
        }

        // ���o�|����b��H�ʺ٦C��
        public Base_Get_Member(): Base_Struct_TransferTarget[] {
            return this._TransferTargetList;
        }

        // �R���|����b��H�ʺ�
        public Base_Del_Member(no: string) {

            var self = this;
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/DelTransferTarget",
                data: { No: no, Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    self.Base_Get_Init();
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });
        }

        // ���Ҽʺ�
        public Base_Check_Nick(name: string): Base_Struct_CheckResult {
            var result = new Base_Struct_CheckResult();

            if (!name || !name.replace(/^[ ]+$/, "")) {
                result.Code = 1;
                result.Message = $SGT.Message.TransferBase.Base_Check_Nick[0];
                return result;
            }

            if (name.length > 50) {
                result.Code = 2;
                result.Message = $SGT.Message.TransferBase.Base_Check_Nick[1];
                return result;
            }

            return result;
        }

        // �����I��
        public Base_Check_Point(point: number): Base_Struct_CheckResult {
            var result = new Base_Struct_CheckResult();

            if (!point || !point.toString().replace(/^[ ]+$/, "")) {
                result.Code = 1;
                result.Message = $SGT.Message.TransferBase.Base_Check_Point[0];
                return result;
            }

            if (!/^[0-9]+$/.test(point.toString())) {
                result.Code = 2;
                result.Message = $SGT.Message.TransferBase.Base_Check_Point[1];
                return result;
            }

            if (point.toString().length > 9) {
                result.Code = 3;
                result.Message = $SGT.Message.TransferBase.Base_Check_Point[2];
                return result;
            }

            return result;
        }

        // �������ҽX
        public Base_Check_VerifyCode(code: string): Base_Struct_CheckResult {
            var result = new Base_Struct_CheckResult();

            if (!code || !code.replace(/^[ ]+$/, "")) {
                result.Code = 1;
                result.Message = $SGT.Message.TransferBase.Base_Check_VerifyCode[0];
                return result;
            }

            if (code.length != 4) {
                result.Code = 2;
                result.Message = $SGT.Message.TransferBase.Base_Check_VerifyCode[0];
                return result;
            }

            return result;
        }

        // �|����b
        public Base_Submit_MemberTransfer(targetName: string, changePoints: number, isKeepName: bool, platinum: number): Base_Struct_CheckResult {
            var self = this;
            var result = new Base_Struct_CheckResult();
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/MemberTransfer",
                data: { NickNameReceive: targetName, KeepName: (isKeepName ? 1 : 0), ChangePoints: changePoints, Platinum: platinum, Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    result.Code = data.ResultCode;
                    result.Message = data.ResultMessage;
                    if (result.Code == 0) {
                        // ������T
                        self.Base_Get_Init();
                    }
                },
                error: function (e) {
                    result.Code = 999;;
                    result.Message = $SGT.Message.TransferBase.Base_Submit_MemberTransfer[0];
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });

            return result;
        }

        // ���o�|����b�O��
        public Base_Get_TransferMaster(): Base_Struct_TransferMaster[] {
            var self = this;
            var result: Base_Struct_TransferMaster[];
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/TransferMaster",
                data: { IsEnded: false, PageIndex: 1, PageSIze: 999, Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    result = data.List;
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                    result = [];
                },
                complete: function () {
                }
            });

            return result;
        }

        // ���o�|����b���v�O��
        public Base_Get_TransferMasterRecord(pageIndex: number, pageSize: number): Base_Struct_TransferMasterRecord {
            var self = this;
            var result: Base_Struct_TransferMasterRecord;
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/TransferMaster",
                data: { IsEnded: true, PageIndex: pageIndex, PageSIze: pageSize, Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    result = data;
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                    result = new Base_Struct_TransferMasterRecord();
                },
                complete: function () {
                }
            });

            return result;
        }

        // ���o�|����b���ӰO��
        public Base_Query_TransferDetail(no: string): Base_Struct_TransferDetail[] {
            var self = this;
            var result: Base_Struct_TransferDetail[];
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/TransferDetail",
                data: { No: no, Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    result = data;
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                    result = [];
                },
                complete: function () {
                }
            });

            return result;
        }

        // ������|���P�N/������b
        public Base_Submit_TransferConfirm(no: string, yn: number): Base_Struct_TransferConfirmResult {
            var self = this;
            var result: Base_Struct_TransferConfirmResult = new Base_Struct_TransferConfirmResult();
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/TransferConfirm",
                data: { No: no, YN: yn, Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    result = data;
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });

            return result;
        }

        // �o�e��|���T�{��b
        public Base_Submit_TransferVerify(no: string, verifyCode: string): Base_Struct_TransferConfirmResult {
            var self = this;
            var result: Base_Struct_TransferConfirmResult = new Base_Struct_TransferConfirmResult();
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/TransferVerify",
                data: { No: no, VerificationCode: verifyCode, Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    result = data;
                    if (result.IsSuccess) {
                        // �����ʺ٦C��
                        self.Base_Get_Init();
                    }
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });

            return result;
        }
        public Base_Submit_SendSMSCode(no: string): Base_Struct_SendSMSCodeResult {
            var self = this;
            var result: Base_Struct_SendSMSCodeResult = new Base_Struct_SendSMSCodeResult();
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/SendSMSCode",
                async: false,
                data: { No: no, Platform: platform },
                dataType: "json",
                success: function (data) {
                    //result = data;
                    //if (result.IsSuccess) {
                    //    // �����ʺ٦C��
                    //    self.Base_Get_Init();
                    //}
                    result.Code = data.ResultCode;
                    result.Message = data.ResultMsg;
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                    result.Code = 99;
                    result.Message = "�z��J�����ҽX���~�A�Э��s��J";
                },
                complete: function () {
                }
            });

            return result;
        }
        // ��l�ơA���o��ƨӷ�
        public Base_Get_Reload_Info(): void {
            var self = this;
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            $.ajax({
                type: "POST",
                url: "/MVC/api/Bank/GetTransferInfo",
                async: false,
                dataType: "json",
                data: { Platform: platform },
                success: function (data) {
                    self._TransferTargetList = data.TargetList;
                    self._TransferMemberInfo = data.Info;
                },
                error: function (e) {
                    //alert("error:" + e.responseText);
                },
                complete: function () {
                }
            });
        }
    }
}