﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Base_Struct_TransferInfo = (function () {
            function Base_Struct_TransferInfo() {
                this.IsGeneralMember = false;
                this.TotalPoint = 0;
                this.FreePoint = 0;
                this.TransferMax = 0;
                this.LockPoint = 0;
                this.LockDate = "";
                this.Transfee = 0;
            }
            return Base_Struct_TransferInfo;
        })();
        DynamicPages.Base_Struct_TransferInfo = Base_Struct_TransferInfo;        
        var Base_Struct_TransferTarget = (function () {
            function Base_Struct_TransferTarget() {
                this.No = "";
                this.Name = "";
                this.IsOnline = false;
            }
            return Base_Struct_TransferTarget;
        })();
        DynamicPages.Base_Struct_TransferTarget = Base_Struct_TransferTarget;        
        var Base_Struct_TransferMaster = (function () {
            function Base_Struct_TransferMaster() {
                this.No = "";
                this.TransferNo = 0;
                this.IsSender = false;
                this.CreateDate = "";
                this.SendName = "";
                this.ReceiveName = "";
                this.Points = 0;
                this.Status = "";
            }
            return Base_Struct_TransferMaster;
        })();
        DynamicPages.Base_Struct_TransferMaster = Base_Struct_TransferMaster;        
        var Base_Struct_TransferMasterRecord = (function () {
            function Base_Struct_TransferMasterRecord() {
                this.List = [];
                this.TotalRecord = 0;
            }
            return Base_Struct_TransferMasterRecord;
        })();
        DynamicPages.Base_Struct_TransferMasterRecord = Base_Struct_TransferMasterRecord;        
        var Base_Struct_TransferDetail = (function () {
            function Base_Struct_TransferDetail() {
                this.CreateDate = "";
                this.Memo = "";
            }
            return Base_Struct_TransferDetail;
        })();
        DynamicPages.Base_Struct_TransferDetail = Base_Struct_TransferDetail;        
        var Base_Struct_TransferConfirmResult = (function () {
            function Base_Struct_TransferConfirmResult() {
                this.IsSuccess = false;
                this.IsRegainPoint = false;
                this.Message = "";
            }
            return Base_Struct_TransferConfirmResult;
        })();
        DynamicPages.Base_Struct_TransferConfirmResult = Base_Struct_TransferConfirmResult;        
        var Base_Struct_CheckResult = (function () {
            function Base_Struct_CheckResult() {
                this.Code = 0;
                this.Message = "";
            }
            return Base_Struct_CheckResult;
        })();
        DynamicPages.Base_Struct_CheckResult = Base_Struct_CheckResult;        
        var Base_Struct_SendSMSCodeResult = (function () {
            function Base_Struct_SendSMSCodeResult() {
                this.Code = 0;
                this.Message = "";
            }
            return Base_Struct_SendSMSCodeResult;
        })();
        DynamicPages.Base_Struct_SendSMSCodeResult = Base_Struct_SendSMSCodeResult;        
        var TransferBase = (function () {
            function TransferBase() {
                this.Base_Get_Init();
            }
            TransferBase.prototype.Base_Get_Init = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/GetTransferInfo",
                    async: false,
                    dataType: "json",
                    data: {
                        Platform: platform
                    },
                    success: function (data) {
                        self._TransferTargetList = data.TargetList;
                        self._TransferMemberInfo = data.Info;
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            TransferBase.prototype.Base_Get_Info = function () {
                return this._TransferMemberInfo;
            };
            TransferBase.prototype.Base_Get_Member = function () {
                return this._TransferTargetList;
            };
            TransferBase.prototype.Base_Del_Member = function (no) {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/DelTransferTarget",
                    data: {
                        No: no,
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        self.Base_Get_Init();
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            TransferBase.prototype.Base_Check_Nick = function (name) {
                var result = new Base_Struct_CheckResult();
                if(!name || !name.replace(/^[ ]+$/, "")) {
                    result.Code = 1;
                    result.Message = $SGT.Message.TransferBase.Base_Check_Nick[0];
                    return result;
                }
                if(name.length > 50) {
                    result.Code = 2;
                    result.Message = $SGT.Message.TransferBase.Base_Check_Nick[1];
                    return result;
                }
                return result;
            };
            TransferBase.prototype.Base_Check_Point = function (point) {
                var result = new Base_Struct_CheckResult();
                if(!point || !point.toString().replace(/^[ ]+$/, "")) {
                    result.Code = 1;
                    result.Message = $SGT.Message.TransferBase.Base_Check_Point[0];
                    return result;
                }
                if(!/^[0-9]+$/.test(point.toString())) {
                    result.Code = 2;
                    result.Message = $SGT.Message.TransferBase.Base_Check_Point[1];
                    return result;
                }
                if(point.toString().length > 9) {
                    result.Code = 3;
                    result.Message = $SGT.Message.TransferBase.Base_Check_Point[2];
                    return result;
                }
                return result;
            };
            TransferBase.prototype.Base_Check_VerifyCode = function (code) {
                var result = new Base_Struct_CheckResult();
                if(!code || !code.replace(/^[ ]+$/, "")) {
                    result.Code = 1;
                    result.Message = $SGT.Message.TransferBase.Base_Check_VerifyCode[0];
                    return result;
                }
                if(code.length != 4) {
                    result.Code = 2;
                    result.Message = $SGT.Message.TransferBase.Base_Check_VerifyCode[0];
                    return result;
                }
                return result;
            };
            TransferBase.prototype.Base_Submit_MemberTransfer = function (targetName, changePoints, isKeepName, platinum) {
                var self = this;
                var result = new Base_Struct_CheckResult();
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/MemberTransfer",
                    data: {
                        NickNameReceive: targetName,
                        KeepName: (isKeepName ? 1 : 0),
                        ChangePoints: changePoints,
                        Platinum: platinum,
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result.Code = data.ResultCode;
                        result.Message = data.ResultMessage;
                        if(result.Code == 0) {
                            self.Base_Get_Init();
                        }
                    },
                    error: function (e) {
                        result.Code = 999;
                        ;
                        result.Message = $SGT.Message.TransferBase.Base_Submit_MemberTransfer[0];
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            TransferBase.prototype.Base_Get_TransferMaster = function () {
                var self = this;
                var result;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/TransferMaster",
                    data: {
                        IsEnded: false,
                        PageIndex: 1,
                        PageSIze: 999,
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result = data.List;
                    },
                    error: function (e) {
                        result = [];
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            TransferBase.prototype.Base_Get_TransferMasterRecord = function (pageIndex, pageSize) {
                var self = this;
                var result;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/TransferMaster",
                    data: {
                        IsEnded: true,
                        PageIndex: pageIndex,
                        PageSIze: pageSize,
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result = data;
                    },
                    error: function (e) {
                        result = new Base_Struct_TransferMasterRecord();
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            TransferBase.prototype.Base_Query_TransferDetail = function (no) {
                var self = this;
                var result;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/TransferDetail",
                    data: {
                        No: no,
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result = data;
                    },
                    error: function (e) {
                        result = [];
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            TransferBase.prototype.Base_Submit_TransferConfirm = function (no, yn) {
                var self = this;
                var result = new Base_Struct_TransferConfirmResult();
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/TransferConfirm",
                    data: {
                        No: no,
                        YN: yn,
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result = data;
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            TransferBase.prototype.Base_Submit_TransferVerify = function (no, verifyCode) {
                var self = this;
                var result = new Base_Struct_TransferConfirmResult();
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/TransferVerify",
                    data: {
                        No: no,
                        VerificationCode: verifyCode,
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result = data;
                        if(result.IsSuccess) {
                            self.Base_Get_Init();
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            TransferBase.prototype.Base_Submit_SendSMSCode = function (no) {
                var self = this;
                var result = new Base_Struct_SendSMSCodeResult();
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/SendSMSCode",
                    async: false,
                    data: {
                        No: no,
                        Platform: platform
                    },
                    dataType: "json",
                    success: function (data) {
                        result.Code = data.ResultCode;
                        result.Message = data.ResultMsg;
                    },
                    error: function (e) {
                        result.Code = 99;
                        result.Message = "±z¿é¤JªºÅçÃÒ½X¦³»~¡A½Ð­«·s¿é¤J";
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            TransferBase.prototype.Base_Get_Reload_Info = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/GetTransferInfo",
                    async: false,
                    dataType: "json",
                    data: {
                        Platform: platform
                    },
                    success: function (data) {
                        self._TransferTargetList = data.TargetList;
                        self._TransferMemberInfo = data.Info;
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            return TransferBase;
        })();
        DynamicPages.TransferBase = TransferBase;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
