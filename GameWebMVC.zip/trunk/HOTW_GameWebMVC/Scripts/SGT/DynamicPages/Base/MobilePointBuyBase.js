﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        // 記錄結構 (對應 Api 傳出結構)
        var Base_Struct_PayRecord = (function () {
            function Base_Struct_PayRecord() {
                // 儲值類型
                this.ProductGroup = 0;
                // 購買金額編號
                this.ValueID = 0;
                // 付費方式編號
                this.ProductID = 0;
                // 發票取得方式 (0:捐給創世基金會 1:索取電子發票 2:索取紙本發票)
                this.InvoiceType = 0;
                // 電子發票寄送電子信箱
                this.InvoiceEmail = "";
                // 發票收件人
                this.InvoiceName = "";
                // 發票收件地址城市編號
                this.InvoiceCityID = 0;
                // 發票收件地址鄉鎮市編號
                this.InvoiceZoneID = "";
                // 發票收件地址
                this.InvoiceAddress = "";
            }
            return Base_Struct_PayRecord;
        })();
        DynamicPages.Base_Struct_PayRecord = Base_Struct_PayRecord;

        // 金額結構 (對應 Api 傳出結構)
        var Base_Struct_ValueList = (function () {
            function Base_Struct_ValueList() {
            }
            return Base_Struct_ValueList;
        })();
        DynamicPages.Base_Struct_ValueList = Base_Struct_ValueList;

        // 付費方式結構 (對應 Api 傳出結構)
        var Base_Struct_ProductList = (function () {
            function Base_Struct_ProductList() {
            }
            return Base_Struct_ProductList;
        })();
        DynamicPages.Base_Struct_ProductList = Base_Struct_ProductList;

        // 金額、付費方式的關聯屬性結構
        var Base_Struct_ValueProductSetting = (function () {
            function Base_Struct_ValueProductSetting() {
                // 是否顯示 ECoupon
                this.IsShowECoupon = false;
            }
            return Base_Struct_ValueProductSetting;
        })();
        DynamicPages.Base_Struct_ValueProductSetting = Base_Struct_ValueProductSetting;

        // 縣市鄉鎮結構 (對應 Api 傳出結構)
        var Base_Struct_CityList = (function () {
            function Base_Struct_CityList() {
            }
            return Base_Struct_CityList;
        })();
        DynamicPages.Base_Struct_CityList = Base_Struct_CityList;

        // 鄉鎮市列表回傳結構
        var Base_Struct_ZoneList = (function () {
            function Base_Struct_ZoneList() {
                // 鄉鎮市編號
                this.ZoneID = "";
                // 鄉鎮市名稱
                this.ZoneName = "";
                // 郵遞區號
                this.ZipCode = "";
            }
            return Base_Struct_ZoneList;
        })();
        DynamicPages.Base_Struct_ZoneList = Base_Struct_ZoneList;

        // 取得會員獲得金額點數結構 (對應 Api 傳出結構)
        var Base_Struct_Worth = (function () {
            function Base_Struct_Worth() {
                // 金額
                this.Price = 0;
                // 點數
                this.ResultPoints = 0;
                // 每日補點
                this.EveryDayPoints = 0;
                // 贈點
                this.GiftPoints = 0;
            }
            return Base_Struct_Worth;
        })();
        DynamicPages.Base_Struct_Worth = Base_Struct_Worth;

        // 檢查功能回傳結構
        var Base_Struct_CheckResult = (function () {
            function Base_Struct_CheckResult() {
                // 是否成功
                this.IsSuccess = false;
                // 回傳訊息
                this.Message = "";
            }
            return Base_Struct_CheckResult;
        })();
        DynamicPages.Base_Struct_CheckResult = Base_Struct_CheckResult;

        // 檢查功能回傳結構
        var Base_Struct_CheckValueECouponResult = (function () {
            function Base_Struct_CheckValueECouponResult() {
                // 是否成功
                this.IsSuccess = false;
                // 回傳訊息
                this.Message = "";
                // 折扣金額
                this.ECouponValue = 0;
                // 付款方式列表
                this.ProductList = "";
            }
            return Base_Struct_CheckValueECouponResult;
        })();
        DynamicPages.Base_Struct_CheckValueECouponResult = Base_Struct_CheckValueECouponResult;

        // 確認付款結構 (對應 Model/PointBuyGoPayment 結構)
        var Base_Struct_GoPayment = (function () {
            function Base_Struct_GoPayment() {
                // 交易金額
                this.Price = 0;
                // 交易點數
                this.Points = 0;
                // 每日補點
                this.EveryDayPoints = 0;
                // 贈點
                this.GiftPoints = 0;
                // 儲值類型 (1:線上購點 2:序號儲值 3:超值包月 4:線上轉點 5:FB儲值 6:背動式儲值)
                this.ProductGroup = 0;
                // 儲值金額編號
                this.ValueID = 0;
                // 付款方式編號
                this.ProductID = 0;
                // ECoupon序號
                this.ECoupon = "";
                // 發票取得方式 (0:捐給創世基金會 1:索取電子發票 2:索取紙本發票)
                this.InvoiceType = 0;
                // 發票寄送Email
                this.InvoiceEmail = "";
                // 發票寄送人
                this.InvoiceName = "";
                // 發票寄送縣市編號
                this.InvoiceCityID = 0;
                // 發票寄送區域編號
                this.InvoiceZoneID = "";
                // 發票寄送地址
                this.InvoiceAddress = "";
                // 儲值序號
                this.StoreCardSN = "";
                // 序號驗證碼
                this.StoreCardPwd = "";
                // 平台 (1:WEB 2:大廳 3:FB 4:113轉帳 5:Mobile)
                this.Platinum = 5;
            }
            return Base_Struct_GoPayment;
        })();
        DynamicPages.Base_Struct_GoPayment = Base_Struct_GoPayment;

        // 線上購點 Base
        var PointBuyBase = (function () {
            /// --------------------------------------
            /// constructor
            /// --------------------------------------
            function PointBuyBase() {
                /// --------------------------------------
                /// preperty
                /// --------------------------------------
                // 儲值類型 (1:線上購點 2:序號儲值 3:超值包月 4:線上轉點 5:FB儲值 6:背動式儲值)
                this._ProductGroup = 0;
                // 是否正在執行中
                this._IsRun = false;
                // 是否使用最後一次的操作紀錄
                this._IsLastRecord = false;
                // 金額列表
                this._ValueSource = [];
                // 付費方式列表
                this._ProductSource = [];
                // 金額+付費方式 對應屬性列表
                this._ValueProductSource = [];
                // 縣市列表
                this._CitySource = [];
            }
            /// --------------------------------------
            /// function
            /// --------------------------------------
            // 初始化，取得資料來源
            PointBuyBase.prototype.Base_Init = function (productGroup) {
                var self = this;
                self._ProductGroup = productGroup;

                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/MobilePointBuyBase",
                    data: { product: self._ProductGroup },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        self._IsLastRecord = data.IsLastRecord;
                        self._PayRecord = data.PayRecord;
                        self._ValueSource = data.ValueSource;
                        self._ProductSource = data.ProductSource;
                        self._ValueProductSource = data.ValueProductSource;
                        self._CitySource = data.CitySource;
                        self._ResultCode = data.ResultCode;
                    },
                    error: function (e) {
                        alert("error:" + e.message);
                    },
                    complete: function () {
                    }
                });
            };

            // 取得是否使用最後一次的操作紀錄
            PointBuyBase.prototype.Base_Get_IsLastRecord = function () {
                return this._IsLastRecord;
            };

            // 取得記錄
            PointBuyBase.prototype.Base_Get_PayRecord = function () {
                return this._PayRecord;
            };

            // 取得所有金額列表
            PointBuyBase.prototype.Base_Get_ValueList = function () {
                return this._ValueSource;
            };

            // 取得所有付款方式
            PointBuyBase.prototype.Base_Get_ProductAll = function () {
                return this._ProductSource;
            };

            // 取得付款方式列表
            PointBuyBase.prototype.Base_Get_ProductList = function (productIdList) {
                var self = this;

                // 取得付款方式編號
                var productIdArr = (productIdList) ? productIdList.split(',') : [];

                // 回傳付款方式列表
                var resultProductList = [];

                for (var i = 0, icount = productIdArr.length; i < icount; i++) {
                    for (var j = 0, jcount = self._ProductSource.length; j < jcount; j++) {
                        if (productIdArr[i] == self._ProductSource[j].ID.toString()) {
                            resultProductList.push(self._ProductSource[j]);
                        }
                    }
                }

                return resultProductList;
            };

            // 取得 金額+付費方式 設定參數
            PointBuyBase.prototype.Base_Get_ValueProductSetting = function (valueId, productId) {
                // 回傳 object 結構
                var result = new Base_Struct_ValueProductSetting();

                if (!valueId || !productId) {
                    return result;
                }

                for (var i = 0, count = this._ValueProductSource.length; i < count; i++) {
                    if (this._ValueProductSource[i][0] == valueId && this._ValueProductSource[i][1] == productId) {
                        result.IsShowECoupon = (this._ValueProductSource[i][2] == 1);
                        break;
                    }
                }

                return result;
            };

            // 取得縣市列表
            PointBuyBase.prototype.Base_Get_CityList = function () {
                return this._CitySource;
            };

            // 取得鄉鎮市列表
            PointBuyBase.prototype.Base_Get_ZoneList = function (cityId) {
                var self = this;

                // 回傳鄉鎮市列表
                var zoneList = [];

                if (/\d+/.test(cityId.toString())) {
                    var zone;

                    for (var i = 0, icount = this._CitySource.length; i < icount; i++) {
                        if (this._CitySource[i].CityID == cityId) {
                            zone = self._CitySource[i].ZoneList;
                            break;
                        }
                    }

                    if (zone) {
                        for (var i = 0, icount = zone.length; i < icount; i++) {
                            zoneList.push((function () {
                                var sub = new Base_Struct_ZoneList();
                                sub.ZoneID = zone[i][0];
                                sub.ZoneName = zone[i][1];
                                sub.ZipCode = zone[i][2];
                                return sub;
                            })());
                        }
                    }
                }

                return zoneList;
            };

            // 取得會員獲得金額點數
            PointBuyBase.prototype.Base_Get_Worth = function (valueId, productId, ecoupon) {
                if (typeof ecoupon === "undefined") { ecoupon = ""; }
                if (!valueId || !productId) {
                    return new Base_Struct_Worth();
                }

                // 回傳 object 結構
                var result;

                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/GetMemberWorth",
                    data: { ProductGroup: this._ProductGroup, PaymentValueID: valueId, ProductType: productId, ECouponCode: ecoupon },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result = data;
                    },
                    error: function (e) {
                        result = new Base_Struct_Worth();
                        //alert("error:" + e.responseText);
                    },
                    complete: function () {
                    }
                });

                return result;
            };

            // ECoupon 驗證
            PointBuyBase.prototype.Base_Check_ECoupon = function (valueId, productId, ecoupon) {
                // 回傳 object 結構
                var result = new Base_Struct_CheckResult();

                if (!valueId || !productId) {
                    return result;
                }

                if (!ecoupon || !ecoupon.replace(/^[ ]+$/, "") || !/^[0-9a-zA-Z]{0,50}$/.test(ecoupon)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                    return result;
                }

                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/AuthECoupon",
                    async: false,
                    data: { PaymentValueID: valueId, ProductType: productId, EcouponCode: ecoupon },
                    dataType: "json",
                    success: function (data) {
                        switch (data.ResultCode) {
                            case 0:
                                result.IsSuccess = true;
                                break;
                            case 1:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[1];
                                break;
                            case 2:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[2];
                                break;
                            case 3:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[3];
                                break;
                            case 4:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[4];
                                break;
                            case 5:
                            case 6:
                            case 99:
                            case -1:
                            default:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                                break;
                        }
                    },
                    error: function (e) {
                        //alert("error:" + e.responseText);
                    },
                    complete: function () {
                    }
                });

                return result;
            };

            // ECoupon 驗證，並取得儲值金額對應的付款方式列表
            PointBuyBase.prototype.Base_Check_ValueECoupon = function (valueId, ecoupon) {
                // 回傳 object 結構
                var result = new Base_Struct_CheckValueECouponResult();

                if (!valueId) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                    return result;
                }

                if (!ecoupon || !ecoupon.replace(/^[ ]+$/, "") || !/^[0-9a-zA-Z]{0,50}$/.test(ecoupon)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                    return result;
                }

                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/AuthValueECoupon",
                    async: false,
                    data: { PaymentValueID: valueId, EcouponCode: ecoupon },
                    dataType: "json",
                    success: function (data) {
                        switch (data.ResultCode) {
                            case 0:
                                result.IsSuccess = true;
                                result.ECouponValue = data.ECouponValue;
                                result.ProductList = data.ProductList;
                                break;
                            case 1:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[1];
                                break;
                            case 2:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[2];
                                break;
                            case 3:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[3];
                                break;
                            case 4:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[4];
                                break;
                            case 5:
                            case 6:
                            case 99:
                            case -1:
                            default:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                                break;
                        }
                    },
                    error: function (e) {
                        //alert("error:" + e.responseText);
                    },
                    complete: function () {
                    }
                });

                return result;
            };

            // 驗證Email格式
            PointBuyBase.prototype.Base_Check_Email = function (email) {
                var result = new Base_Struct_CheckResult();

                if (!email || !email.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_Email[0];
                } else if (!/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(email) || email.length > 50) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_Email[1];
                } else {
                    result.IsSuccess = true;
                }

                return result;
            };

            // 驗證發票收件人格式
            PointBuyBase.prototype.Base_Check_InvoiceName = function (name) {
                var result = new Base_Struct_CheckResult();

                if (!name || !name.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceName[0];
                } else if (!/^[\u0391-\uFFE5a-zA-Z0-9]{1,15}$/.test(name)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceName[1];
                } else {
                    result.IsSuccess = true;
                }

                return result;
            };

            // 驗證發票地址格式
            PointBuyBase.prototype.Base_Check_InvoiceAddress = function (address) {
                var result = new Base_Struct_CheckResult();

                if (!address || !address.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceAddress[0];
                } else if (!/^[\u0391-\uFFE5a-zA-Z0-9\-]{1,40}$/.test(address)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceAddress[1];
                } else {
                    result.IsSuccess = true;
                }

                return result;
            };

            // 驗證儲值序號
            PointBuyBase.prototype.Base_Check_StoreCardSN = function (sn) {
                var result = new Base_Struct_CheckResult();

                if (!sn || !sn.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_StoreCardSN[0];
                } else {
                    result.IsSuccess = true;
                }

                return result;
            };

            // 驗證儲值驗證碼
            PointBuyBase.prototype.Base_Check_StoreCardPwd = function (pwd) {
                var result = new Base_Struct_CheckResult();

                if (!pwd || !pwd.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_StoreCardPwd[0];
                } else {
                    result.IsSuccess = true;
                }

                return result;
            };

            // 儲存玩家紀錄
            PointBuyBase.prototype.Base_Set_Record = function (data) {
                data.ProductGroup = this._ProductGroup;

                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/SavePayRecord",
                    data: data,
                    async: false,
                    dataType: "json",
                    success: function (data) {
                    },
                    error: function (e) {
                        //alert("error:" + e.responseText);
                    },
                    complete: function () {
                    }
                });
            };

            // 確認付款
            PointBuyBase.prototype.Base_Submit_GoPayment = function (targetPage, isNewWindow, postData) {
                if (this._IsRun) {
                    return;
                }

                this._IsRun = true;

                postData.ProductGroup = this._ProductGroup;

                var form = document.createElement("form");
                form["name"] = "payForm";
                form["method"] = "post";
                form["action"] = targetPage;
                form["target"] = isNewWindow ? "_blank" : "_self";

                var ele = document.createElement("input");
                ele["name"] = "data";
                ele["value"] = JSON.stringify(postData);
                ele["hidden"] = true;
                ele["type"] = 'hidden';

                form.appendChild(ele);

                document.body.appendChild(form);
                document.forms[document.forms.length - 1]["submit"]();
            };

            PointBuyBase.prototype.Base_Get_ResultCode = function () {
                return this._ResultCode;
            };
            return PointBuyBase;
        })();
        DynamicPages.PointBuyBase = PointBuyBase;
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
