var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Base_Struct_PayRecord = (function () {
            function Base_Struct_PayRecord() {
                this.ProductGroup = 0;
                this.ValueID = 0;
                this.ProductID = 0;
                this.InvoiceType = 0;
                this.InvoiceEmail = "";
                this.InvoiceName = "";
                this.InvoiceCityID = 0;
                this.InvoiceZoneID = "";
                this.InvoiceAddress = "";
            }
            return Base_Struct_PayRecord;
        })();
        DynamicPages.Base_Struct_PayRecord = Base_Struct_PayRecord;        
        var Base_Struct_ValueList = (function () {
            function Base_Struct_ValueList() { }
            return Base_Struct_ValueList;
        })();
        DynamicPages.Base_Struct_ValueList = Base_Struct_ValueList;        
        var Base_Struct_ProductList = (function () {
            function Base_Struct_ProductList() { }
            return Base_Struct_ProductList;
        })();
        DynamicPages.Base_Struct_ProductList = Base_Struct_ProductList;        
        var Base_Struct_ValueProductSetting = (function () {
            function Base_Struct_ValueProductSetting() {
                this.IsShowECoupon = false;
            }
            return Base_Struct_ValueProductSetting;
        })();
        DynamicPages.Base_Struct_ValueProductSetting = Base_Struct_ValueProductSetting;        
        var Base_Struct_CityList = (function () {
            function Base_Struct_CityList() { }
            return Base_Struct_CityList;
        })();
        DynamicPages.Base_Struct_CityList = Base_Struct_CityList;        
        var Base_Struct_ZoneList = (function () {
            function Base_Struct_ZoneList() {
                this.ZoneID = "";
                this.ZoneName = "";
                this.ZipCode = "";
            }
            return Base_Struct_ZoneList;
        })();
        DynamicPages.Base_Struct_ZoneList = Base_Struct_ZoneList;        
        var Base_Struct_Worth = (function () {
            function Base_Struct_Worth() {
                this.Price = 0;
                this.ResultPoints = 0;
                this.EveryDayPoints = 0;
                this.GiftPoints = 0;
            }
            return Base_Struct_Worth;
        })();
        DynamicPages.Base_Struct_Worth = Base_Struct_Worth;        
        var Base_Struct_CheckResult = (function () {
            function Base_Struct_CheckResult() {
                this.IsSuccess = false;
                this.Message = "";
            }
            return Base_Struct_CheckResult;
        })();
        DynamicPages.Base_Struct_CheckResult = Base_Struct_CheckResult;        
        var Base_Struct_CheckValueECouponResult = (function () {
            function Base_Struct_CheckValueECouponResult() {
                this.IsSuccess = false;
                this.Message = "";
                this.ECouponValue = 0;
                this.ProductList = "";
            }
            return Base_Struct_CheckValueECouponResult;
        })();
        DynamicPages.Base_Struct_CheckValueECouponResult = Base_Struct_CheckValueECouponResult;        
        var Base_Struct_GoPayment = (function () {
            function Base_Struct_GoPayment() {
                this.Price = 0;
                this.Points = 0;
                this.EveryDayPoints = 0;
                this.GiftPoints = 0;
                this.ProductGroup = 0;
                this.ValueID = 0;
                this.ProductID = 0;
                this.ECoupon = "";
                this.InvoiceType = 0;
                this.InvoiceEmail = "";
                this.InvoiceName = "";
                this.InvoiceCityID = 0;
                this.InvoiceZoneID = "";
                this.InvoiceAddress = "";
                this.StoreCardSN = "";
                this.StoreCardPwd = "";
                this.Platinum = 1;
            }
            return Base_Struct_GoPayment;
        })();
        DynamicPages.Base_Struct_GoPayment = Base_Struct_GoPayment;        
        var PointBuyBase = (function () {
            function PointBuyBase() {
                this._ProductGroup = 0;
                this._IsRun = false;
                this._IsLastRecord = false;
                this._ValueSource = [];
                this._ProductSource = [];
                this._ValueProductSource = [];
                this._CitySource = [];
            }
            PointBuyBase.prototype.Base_Init = function (productGroup) {
                var self = this;
                self._ProductGroup = productGroup;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/PointBuyBase",
                    data: {
                        product: self._ProductGroup
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        self._IsLastRecord = data.IsLastRecord;
                        self._PayRecord = data.PayRecord;
                        self._ValueSource = data.ValueSource;
                        self._ProductSource = data.ProductSource;
                        self._ValueProductSource = data.ValueProductSource;
                        self._CitySource = data.CitySource;
                        self._ResultCode = data.ResultCode;
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            PointBuyBase.prototype.Base_Get_IsLastRecord = function () {
                return this._IsLastRecord;
            };
            PointBuyBase.prototype.Base_Get_PayRecord = function () {
                return this._PayRecord;
            };
            PointBuyBase.prototype.Base_Get_ValueList = function () {
                return this._ValueSource;
            };
            PointBuyBase.prototype.Base_Get_ProductAll = function () {
                return this._ProductSource;
            };
            PointBuyBase.prototype.Base_Get_ProductList = function (productIdList) {
                var self = this;
                var productIdArr = (productIdList) ? productIdList.split(',') : [];
                var resultProductList = [];
                for(var i = 0, icount = productIdArr.length; i < icount; i++) {
                    for(var j = 0, jcount = self._ProductSource.length; j < jcount; j++) {
                        if(productIdArr[i] == self._ProductSource[j].ID.toString()) {
                            resultProductList.push(self._ProductSource[j]);
                        }
                    }
                }
                return resultProductList;
            };
            PointBuyBase.prototype.Base_Get_ValueProductSetting = function (valueId, productId) {
                var result = new Base_Struct_ValueProductSetting();
                if(!valueId || !productId) {
                    return result;
                }
                for(var i = 0, count = this._ValueProductSource.length; i < count; i++) {
                    if(this._ValueProductSource[i][0] == valueId && this._ValueProductSource[i][1] == productId) {
                        result.IsShowECoupon = (this._ValueProductSource[i][2] == 1);
                        break;
                    }
                }
                return result;
            };
            PointBuyBase.prototype.Base_Get_CityList = function () {
                return this._CitySource;
            };
            PointBuyBase.prototype.Base_Get_ZoneList = function (cityId) {
                var self = this;
                var zoneList = [];
                if(/\d+/.test(cityId.toString())) {
                    var zone;
                    for(var i = 0, icount = this._CitySource.length; i < icount; i++) {
                        if(this._CitySource[i].CityID == cityId) {
                            zone = self._CitySource[i].ZoneList;
                            break;
                        }
                    }
                    if(zone) {
                        for(var i = 0, icount = zone.length; i < icount; i++) {
                            zoneList.push((function () {
                                var sub = new Base_Struct_ZoneList();
                                sub.ZoneID = zone[i][0];
                                sub.ZoneName = zone[i][1];
                                sub.ZipCode = zone[i][2];
                                return sub;
                            })());
                        }
                    }
                }
                return zoneList;
            };
            PointBuyBase.prototype.Base_Get_Worth = function (valueId, productId, ecoupon) {
                if (typeof ecoupon === "undefined") { ecoupon = ""; }
                if(!valueId || !productId) {
                    return new Base_Struct_Worth();
                }
                var result;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/GetMemberWorth",
                    data: {
                        ProductGroup: this._ProductGroup,
                        PaymentValueID: valueId,
                        ProductType: productId,
                        ECouponCode: ecoupon
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        result = data;
                    },
                    error: function (e) {
                        result = new Base_Struct_Worth();
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            PointBuyBase.prototype.Base_Check_ECoupon = function (valueId, productId, ecoupon) {
                var result = new Base_Struct_CheckResult();
                if(!valueId || !productId) {
                    return result;
                }
                if(!ecoupon || !ecoupon.replace(/^[ ]+$/, "") || !/^[0-9a-zA-Z]{0,50}$/.test(ecoupon)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                    return result;
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/AuthECoupon",
                    async: false,
                    data: {
                        PaymentValueID: valueId,
                        ProductType: productId,
                        EcouponCode: ecoupon
                    },
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 0:
                                result.IsSuccess = true;
                                break;
                            case 1:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[1];
                                break;
                            case 2:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[2];
                                break;
                            case 3:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[3];
                                break;
                            case 4:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[4];
                                break;
                            case 5:
                            case 6:
                            case 99:
                            case -1:
                            default:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                                break;
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            PointBuyBase.prototype.Base_Check_ValueECoupon = function (valueId, ecoupon) {
                var result = new Base_Struct_CheckValueECouponResult();
                if(!valueId) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                    return result;
                }
                if(!ecoupon || !ecoupon.replace(/^[ ]+$/, "") || !/^[0-9a-zA-Z]{0,50}$/.test(ecoupon)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                    return result;
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/AuthValueECoupon",
                    async: false,
                    data: {
                        PaymentValueID: valueId,
                        EcouponCode: ecoupon
                    },
                    dataType: "json",
                    success: function (data) {
                        switch(data.ResultCode) {
                            case 0:
                                result.IsSuccess = true;
                                result.ECouponValue = data.ECouponValue;
                                result.ProductList = data.ProductList;
                                break;
                            case 1:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[1];
                                break;
                            case 2:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[2];
                                break;
                            case 3:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[3];
                                break;
                            case 4:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[4];
                                break;
                            case 5:
                            case 6:
                            case 99:
                            case -1:
                            default:
                                result.Message = $SGT.Message.PointBuyBase.Base_Check_ECoupon[0];
                                break;
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
                return result;
            };
            PointBuyBase.prototype.Base_Check_Email = function (email) {
                var result = new Base_Struct_CheckResult();
                if(!email || !email.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_Email[0];
                } else if(!/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(email) || email.length > 50) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_Email[1];
                } else {
                    result.IsSuccess = true;
                }
                return result;
            };
            PointBuyBase.prototype.Base_Check_InvoiceName = function (name) {
                var result = new Base_Struct_CheckResult();
                if(!name || !name.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceName[0];
                } else if(!/^[\u0391-\uFFE5a-zA-Z0-9]{1,15}$/.test(name)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceName[1];
                } else {
                    result.IsSuccess = true;
                }
                return result;
            };
            PointBuyBase.prototype.Base_Check_InvoiceAddress = function (address) {
                var result = new Base_Struct_CheckResult();
                if(!address || !address.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceAddress[0];
                } else if(!/^[\u0391-\uFFE5a-zA-Z0-9\-]{1,40}$/.test(address)) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_InvoiceAddress[1];
                } else {
                    result.IsSuccess = true;
                }
                return result;
            };
            PointBuyBase.prototype.Base_Check_StoreCardSN = function (sn) {
                var result = new Base_Struct_CheckResult();
                if(!sn || !sn.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_StoreCardSN[0];
                } else {
                    result.IsSuccess = true;
                }
                return result;
            };
            PointBuyBase.prototype.Base_Check_StoreCardPwd = function (pwd) {
                var result = new Base_Struct_CheckResult();
                if(!pwd || !pwd.replace(/^[ ]+$/, "")) {
                    result.Message = $SGT.Message.PointBuyBase.Base_Check_StoreCardPwd[0];
                } else {
                    result.IsSuccess = true;
                }
                return result;
            };
            PointBuyBase.prototype.Base_Set_Record = function (data) {
                data.ProductGroup = this._ProductGroup;
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Bank/SavePayRecord",
                    data: data,
                    async: false,
                    dataType: "json",
                    success: function (data) {
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            PointBuyBase.prototype.Base_Submit_GoPayment = function (targetPage, isNewWindow, postData) {
                if(this._IsRun) {
                    return;
                }
                this._IsRun = true;
                postData.ProductGroup = this._ProductGroup;
                var form = document.createElement("form");
                form["name"] = "payForm";
                form["method"] = "post";
                form["action"] = targetPage;
                form["target"] = isNewWindow ? "_blank" : "_self";
                var ele = document.createElement("input");
                ele["name"] = "data";
                ele["value"] = JSON.stringify(postData);
                ele["hidden"] = true;
                ele["type"] = 'hidden';
                form.appendChild(ele);
                document.body.appendChild(form);
                document.forms[document.forms.length - 1]["submit"]();
            };
            PointBuyBase.prototype.Base_Get_ResultCode = function () {
                return this._ResultCode;
            };
            return PointBuyBase;
        })();
        DynamicPages.PointBuyBase = PointBuyBase;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
