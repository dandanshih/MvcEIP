﻿declare var $SGT;
declare var ko;
declare var $;

// 類別定義
module SGT.News {

    export class GameListStruct {
        ListName: string = "";
        ListID: number = 0;
        ListEName: string = "";
        ListGroupID: number = 0;
    }

    // 最新消息 排行榜
    export class RankVIPGame {
        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        //查詢排名類別
        QryRankType = ko.observable('2');
        // 查詢幣別
        QryAreaType = ko.observable('2');
        // 查詢的每頁筆數
        QryRankNum = ko.observable('100');

        //百大富豪
        List1: Array[] = ko.observableArray([]);
        //百大勝分榜
        List2: Array[] = ko.observableArray([]);
        //電子局數
        List3: Array[] = ko.observableArray([]);
        //對戰局數
        List4: Array[] = ko.observableArray([]);
        //彩金贏分
        List5: Array[] = ko.observableArray([]);
        //電子單局贏分榜
        List6: Array[] = ko.observableArray([]);
        //柏青哥排行榜
        List7: Array[] = ko.observableArray([]);

        GameList: (input?: GameListStruct[]) => GameListStruct[] = ko.observableArray([]);

        PachinkoGameList: (input?: GameListStruct[]) => GameListStruct[] = ko.observableArray([]);

        ListID: (input?: string) => string = ko.observable("0");

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // 查詢百大富豪
        QueryTop100(qryranktype: string = this.QryRankType(),
            qryareatype: string = this.QryAreaType(),
            qryranknum: string = this.QryRankNum()) {
            // 設定排名類別
            this.QryRankType(qryranktype);
            //設定幣別
            this.QryAreaType(qryareatype);
            //查詢的每頁筆數
            this.QryRankNum(qryranknum);
            // 查詢百大富豪資料
            this.GetTop100Data();
        }

        // 查詢百大勝分榜
        QueryTotalWin(qryranktype: string = this.QryRankType(),
            qryareatype: string = this.QryAreaType(),
            qryranknum: string = this.QryRankNum()) {
            // 設定排名類別
            this.QryRankType(qryranktype);
            //設定幣別
            this.QryAreaType(qryareatype);
            //查詢的每頁筆數
            this.QryRankNum(qryranknum);
            // 查詢總贏分資料
            this.GetTotalWinData();
        }

        // 查詢電子局數
        QueryElecRound(qryranktype: string = this.QryRankType(),
            qryareatype: string = this.QryAreaType(),
            qryranknum: string = this.QryRankNum()) {
            // 設定排名類別
            this.QryRankType(qryranktype);
            //設定幣別
            this.QryAreaType(qryareatype);
            //查詢的每頁筆數
            this.QryRankNum(qryranknum);
            // 查詢電子局數資料
            this.GetElecRoundData();
        }

        // 查詢對戰局數
        QueryBattleRound(qryranktype: string = this.QryRankType(),
            qryareatype: string = this.QryAreaType(),
            qryranknum: string = this.QryRankNum()) {
            // 設定排名類別
            this.QryRankType(qryranktype);
            //設定幣別
            this.QryAreaType(qryareatype);
            //查詢的每頁筆數
            this.QryRankNum(qryranknum);
            // 查詢對戰局數資料
            this.GetBattleRoundData();
        }

        // 查詢彩金贏分
        QueryJPWin(qryranktype: string = this.QryRankType(),
            qryareatype: string = this.QryAreaType(),
            qryranknum: string = this.QryRankNum()) {
            // 設定排名類別
            this.QryRankType(qryranktype);
            //設定幣別
            this.QryAreaType(qryareatype);
            //查詢的每頁筆數
            this.QryRankNum(qryranknum);
            // 查詢彩金贏分資料
            this.GetJPWinData();
        }

        // 查詢電子單局贏分榜
        QuerySingleWin(qryranktype: string = this.QryRankType(),
            qryareatype: string = this.QryAreaType(),
            qryranknum: string = this.QryRankNum()) {
            // 設定排名類別
            this.QryRankType(qryranktype);
            //設定幣別
            this.QryAreaType(qryareatype);
            //查詢的每頁筆數
            this.QryRankNum(qryranknum);
            // 查詢單局贏分資料
            this.GetSingleWinData();
        }

        // 查詢柏青哥排行榜
        QueryPachinko(qryranktype: string = this.QryRankType(),
            qryareatype: string = this.QryAreaType(),
            qryranknum: string = this.QryRankNum()) {
            // 設定排名類別
            this.QryRankType(qryranktype);
            //設定幣別
            this.QryAreaType(qryareatype);
            //查詢的每頁筆數
            this.QryRankNum(qryranknum);
            // 查詢單局贏分資料
            this.GetPachinkoData();
        }

        // 取得百大富豪資料
        public GetTop100Data(): void {
            try {
                var obj = this;
                // 預設值
                var data =
                    {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/Top100Rank",
                    data: data,
                    async: false,
                    success: function (data) {
                        // 刪除舊資料
                        SGT['Main'].QueryFns['Top100Rank'].List1.splice(0, SGT['Main'].QueryFns['Top100Rank'].List1().length)
                        // 新增新資料
                        $.each(data.List1, function (index, obj) { SGT['Main'].QueryFns['Top100Rank'].List1.push(obj); });
                    },
                    error: function (e) {
                        //alert(e.responseText);
                    }
                });
            } catch (e) {
                //alert(e.Message);
            }
        }

        // 取得百大勝分榜資料
        public GetTotalWinData(): void {
            try {
                var obj = this;
                // 預設值
                var data =
                    {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/TotalWinRank",
                    data: data,
                    async: false,
                    success: function (data) {
                        // 刪除舊資料
                        SGT['Main'].QueryFns['TotalWinRank'].List2.splice(0, SGT['Main'].QueryFns['TotalWinRank'].List2().length)
                        // 新增新資料
                        $.each(data.List2, function (index, obj) { SGT['Main'].QueryFns['TotalWinRank'].List2.push(obj); });
                    },
                    error: function (e) {
                        //alert(e.responseText);
                    }
                });
            } catch (e) {
                //alert(e.Message);
            }
        }

        // 取得電子局數資料
        public GetElecRoundData(): void {
            try {
                var obj = this;
                // 預設值
                var data =
                    {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/ElecRoundRank",
                    data: data,
                    async: false,
                    success: function (data) {
                        // 刪除舊資料
                        SGT['Main'].QueryFns['ElecRoundRank'].List3.splice(0, SGT['Main'].QueryFns['ElecRoundRank'].List3().length)
                        // 新增新資料
                        $.each(data.List3, function (index, obj) { SGT['Main'].QueryFns['ElecRoundRank'].List3.push(obj); });
                    },
                    error: function (e) {
                        //alert(e.responseText);
                    }
                });
            } catch (e) {
                //alert(e.Message);
            }
        }

        // 取得對戰局數資料
        public GetBattleRoundData(): void {
            try {
                var obj = this;
                // 預設值
                var data =
                    {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/BattleRoundRank",
                    data: data,
                    async: false,
                    success: function (data) {
                        // 刪除舊資料
                        SGT['Main'].QueryFns['BattleRoundRank'].List4.splice(0, SGT['Main'].QueryFns['BattleRoundRank'].List4().length)
                        // 新增新資料
                        $.each(data.List4, function (index, obj) { SGT['Main'].QueryFns['BattleRoundRank'].List4.push(obj); });
                    },
                    error: function (e) {
                        //alert(e.responseText);
                    }
                });
            } catch (e) {
                //alert(e.Message);
            }
        }

        // 取得彩金贏分資料
        public GetJPWinData(): void {
            try {
                var obj = this;
                // 預設值
                var data =
                    {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/JPWinRank",
                    data: data,
                    async: false,
                    success: function (data) {
                        // 刪除舊資料
                        SGT['Main'].QueryFns['JPWinRank'].List5.splice(0, SGT['Main'].QueryFns['JPWinRank'].List5().length)
                        // 新增新資料
                        $.each(data.List5, function (index, obj) { SGT['Main'].QueryFns['JPWinRank'].List5.push(obj); });
                    },
                    error: function (e) {
                        //alert(e.responseText);
                    }
                });
            } catch (e) {
                //alert(e.Message);
            }
        }

        // 取得電子單局贏分榜資料
        public GetSingleWinData(): void {
            try {
                var obj = this;
                // 預設值
                var data =
                    {
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum(),
                        QryRankGameType: this.QryRankType()
                    };

                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/SingleWinRank",
                    data: data,
                    async: false,
                    success: function (data) {
                        // 刪除舊資料
                        SGT['Main'].QueryFns['SingleWinRank'].List6.splice(0, SGT['Main'].QueryFns['SingleWinRank'].List6().length)

                        // 新增新資料
                        $.each(data.List6, function (index, obj) { SGT['Main'].QueryFns['SingleWinRank'].List6.push(obj); });
                    },
                    error: function (e) {
                        //alert(e.responseText);
                    }
                });
            } catch (e) {
                //alert(e.Message);
            }
        }

        public GetPachinkoData(): void {
            try {
                var obj = this;
                // 預設值
                var data =
                    {
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum(),
                        QryRankGameType: this.QryRankType()
                    };

                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/PachinkoRank",
                    data: data,
                    async: false,
                    success: function (data) {
                        // 刪除舊資料
                        SGT['Main'].QueryFns['PachinkoRank'].List7.splice(0, SGT['Main'].QueryFns['PachinkoRank'].List7().length)

                        // 新增新資料
                        $.each(data.List7, function (index, obj) { SGT['Main'].QueryFns['PachinkoRank'].List7.push(obj); });
                    },
                    error: function (e) {
                        //alert(e.responseText);
                    }
                });
            } catch (e) {
                
            }
        }

        public GameListBind(): void {
            var self = this;
            $.ajax({
                type: "Post",
                url: "/Mvc/api/News/GetGameListData",
                data: "",
                async: false,
                success: function (data) {
                    self.GameList(data.Result.Data);
                },
                error: function (e) {
                }
            });
        }

        public PachinkoGameListBind(): void {
            var self = this;
            $.ajax({
                type: "Post",
                url: "/Mvc/api/News/GetPachinkoGameListData",
                data: "",
                async: false,
                success: function (data) {
                    self.PachinkoGameList(data.Result.Data);
                },
                error: function (e) {
                }
            });
        }

        public GameListEvent(): void {
            this.QuerySingleWin(this.ListID(), "2", "100");
        }

        public PachinkoGameListEvent(): void {
            this.QueryPachinko(this.ListID(), "2", "100");
        }
    }
}