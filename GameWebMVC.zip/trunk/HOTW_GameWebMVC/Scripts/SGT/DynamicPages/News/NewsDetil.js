var SGT;
(function (SGT) {
    (function (News) {
        var NewsDetil = (function () {
            function NewsDetil(id) {
                this.NewsTitle = ko.observable("");
                this.ModifiedDate = ko.observable("");
                this.NewsDesc = ko.observable("");
                this.NewsID = ko.observable(0);
                if(id == "" || id == null || isNaN(parseInt(id))) {
                    location.href = "http://" + location.hostname;
                } else {
                    var self = this;
                    self.NewsID(parseInt(id));
                    var platform = "Web";
                    if(typeof GetPlatform == "function") {
                        platform = GetPlatform();
                    }
                    $.ajax({
                        type: 'POST',
                        dataType: "json",
                        data: {
                            Platform: platform,
                            NewsID: self.NewsID()
                        },
                        url: '/MVC/api/News/NowNewsAnnouncementDetail',
                        async: false,
                        success: function (data) {
                            self.NewsTitle(data.Result.Data[0].NewsTitle);
                            self.ModifiedDate(data.Result.Data[0].ModifiedDate);
                            self.NewsDesc(data.Result.Data[0].NewsDesc);
                        },
                        error: function (ex) {
                        }
                    });
                }
            }
            return NewsDetil;
        })();
        News.NewsDetil = NewsDetil;        
    })(SGT.News || (SGT.News = {}));
    var News = SGT.News;
})(SGT || (SGT = {}));
