﻿var SGT;
(function (SGT) {
    // 類別定義
    (function (News) {
        var GameListStruct = (function () {
            function GameListStruct() {
                var ListName = ""
                var ListID = 0
                var ListEName = ""
                var ListGroupID = 0
            }
            return GameListStruct;
        })();
        News.GameListStruct = GameListStruct;

        // 最新消息 排行榜
        var RankVIPGame = (function () {
            function RankVIPGame() {
                /// --------------------------------------
                /// ko function
                /// --------------------------------------
                //查詢排名類別
                this.QryRankType = ko.observable('2');
                // 查詢幣別
                this.QryAreaType = ko.observable('2');
                // 查詢的每頁筆數
                this.QryRankNum = ko.observable('100');
                //百大富豪
                this.List1 = ko.observableArray([]);
                //百大勝分榜
                this.List2 = ko.observableArray([]);
                //電子局數
                this.List3 = ko.observableArray([]);
                //對戰局數
                this.List4 = ko.observableArray([]);
                //彩金贏分
                this.List5 = ko.observableArray([]);
                //電子單局贏分榜
                this.List6 = ko.observableArray([]);
                //柏青哥排行榜
                this.List7 = ko.observableArray([]);
                this.GameList = ko.observableArray([]);
                this.PachinkoGameList = ko.observableArray([]);
                this.ListID = ko.observable("0");
            }
            /// --------------------------------------
            /// function
            /// --------------------------------------
            // 查詢百大富豪
            RankVIPGame.prototype.QueryTop100 = function (qryranktype, qryareatype, qryranknum) {
                if (typeof qryranktype === "undefined") { qryranktype = this.QryRankType(); }
                if (typeof qryareatype === "undefined") { qryareatype = this.QryAreaType(); }
                if (typeof qryranknum === "undefined") { qryranknum = this.QryRankNum(); }
                // 設定排名類別
                this.QryRankType(qryranktype);

                //設定幣別
                this.QryAreaType(qryareatype);

                //查詢的每頁筆數
                this.QryRankNum(qryranknum);

                // 查詢百大富豪資料
                this.GetTop100Data();
            };

            // 查詢百大勝分榜
            RankVIPGame.prototype.QueryTotalWin = function (qryranktype, qryareatype, qryranknum) {
                if (typeof qryranktype === "undefined") { qryranktype = this.QryRankType(); }
                if (typeof qryareatype === "undefined") { qryareatype = this.QryAreaType(); }
                if (typeof qryranknum === "undefined") { qryranknum = this.QryRankNum(); }
                // 設定排名類別
                this.QryRankType(qryranktype);

                //設定幣別
                this.QryAreaType(qryareatype);

                //查詢的每頁筆數
                this.QryRankNum(qryranknum);

                // 查詢總贏分資料
                this.GetTotalWinData();
            };

            // 查詢電子局數
            RankVIPGame.prototype.QueryElecRound = function (qryranktype, qryareatype, qryranknum) {
                if (typeof qryranktype === "undefined") { qryranktype = this.QryRankType(); }
                if (typeof qryareatype === "undefined") { qryareatype = this.QryAreaType(); }
                if (typeof qryranknum === "undefined") { qryranknum = this.QryRankNum(); }
                // 設定排名類別
                this.QryRankType(qryranktype);

                //設定幣別
                this.QryAreaType(qryareatype);

                //查詢的每頁筆數
                this.QryRankNum(qryranknum);

                // 查詢電子局數資料
                this.GetElecRoundData();
            };

            // 查詢對戰局數
            RankVIPGame.prototype.QueryBattleRound = function (qryranktype, qryareatype, qryranknum) {
                if (typeof qryranktype === "undefined") { qryranktype = this.QryRankType(); }
                if (typeof qryareatype === "undefined") { qryareatype = this.QryAreaType(); }
                if (typeof qryranknum === "undefined") { qryranknum = this.QryRankNum(); }
                // 設定排名類別
                this.QryRankType(qryranktype);

                //設定幣別
                this.QryAreaType(qryareatype);

                //查詢的每頁筆數
                this.QryRankNum(qryranknum);

                // 查詢對戰局數資料
                this.GetBattleRoundData();
            };

            // 查詢彩金贏分
            RankVIPGame.prototype.QueryJPWin = function (qryranktype, qryareatype, qryranknum) {
                if (typeof qryranktype === "undefined") { qryranktype = this.QryRankType(); }
                if (typeof qryareatype === "undefined") { qryareatype = this.QryAreaType(); }
                if (typeof qryranknum === "undefined") { qryranknum = this.QryRankNum(); }
                // 設定排名類別
                this.QryRankType(qryranktype);

                //設定幣別
                this.QryAreaType(qryareatype);

                //查詢的每頁筆數
                this.QryRankNum(qryranknum);

                // 查詢彩金贏分資料
                this.GetJPWinData();
            };

            // 查詢電子單局贏分榜
            RankVIPGame.prototype.QuerySingleWin = function (qryranktype, qryareatype, qryranknum) {
                if (typeof qryranktype === "undefined") { qryranktype = this.QryRankType(); }
                if (typeof qryareatype === "undefined") { qryareatype = this.QryAreaType(); }
                if (typeof qryranknum === "undefined") { qryranknum = this.QryRankNum(); }
                // 設定排名類別
                this.QryRankType(qryranktype);

                //設定幣別
                this.QryAreaType(qryareatype);

                //查詢的每頁筆數
                this.QryRankNum(qryranknum);

                // 查詢單局贏分資料
                this.GetSingleWinData();
            };

            // 查詢柏青哥排行榜
            RankVIPGame.prototype.QueryPachinko = function (qryranktype, qryareatype, qryranknum) {
                if (typeof qryranktype === "undefined") { qryranktype = this.QryRankType(); }
                if (typeof qryareatype === "undefined") { qryareatype = this.QryAreaType(); }
                if (typeof qryranknum === "undefined") { qryranknum = this.QryRankNum(); }
                // 設定排名類別
                this.QryRankType(qryranktype);

                //設定幣別
                this.QryAreaType(qryareatype);

                //查詢的每頁筆數
                this.QryRankNum(qryranknum);

                // 查詢單局贏分資料
                this.GetPachinkoData();
            };

            // 取得百大富豪資料
            RankVIPGame.prototype.GetTop100Data = function () {
                try  {
                    var obj = this;

                    // 預設值
                    var data = {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/News/Top100Rank",
                        data: data,
                        async: false,
                        success: function (data) {
                            // 刪除舊資料
                            SGT['Main'].QueryFns['Top100Rank'].List1.splice(0, SGT['Main'].QueryFns['Top100Rank'].List1().length);

                            // 新增新資料
                            $.each(data.List1, function (index, obj) {
                                SGT['Main'].QueryFns['Top100Rank'].List1.push(obj);
                            });
                        },
                        error: function (e) {
                            //alert(e.responseText);
                        }
                    });
                } catch (e) {
                    //alert(e.Message);
                }
            };

            // 取得百大勝分榜資料
            RankVIPGame.prototype.GetTotalWinData = function () {
                try  {
                    var obj = this;

                    // 預設值
                    var data = {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/News/TotalWinRank",
                        data: data,
                        async: false,
                        success: function (data) {
                            // 刪除舊資料
                            SGT['Main'].QueryFns['TotalWinRank'].List2.splice(0, SGT['Main'].QueryFns['TotalWinRank'].List2().length);

                            // 新增新資料
                            $.each(data.List2, function (index, obj) {
                                SGT['Main'].QueryFns['TotalWinRank'].List2.push(obj);
                            });
                        },
                        error: function (e) {
                            //alert(e.responseText);
                        }
                    });
                } catch (e) {
                    //alert(e.Message);
                }
            };

            // 取得電子局數資料
            RankVIPGame.prototype.GetElecRoundData = function () {
                try  {
                    var obj = this;

                    // 預設值
                    var data = {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/News/ElecRoundRank",
                        data: data,
                        async: false,
                        success: function (data) {
                            // 刪除舊資料
                            SGT['Main'].QueryFns['ElecRoundRank'].List3.splice(0, SGT['Main'].QueryFns['ElecRoundRank'].List3().length);

                            // 新增新資料
                            $.each(data.List3, function (index, obj) {
                                SGT['Main'].QueryFns['ElecRoundRank'].List3.push(obj);
                            });
                        },
                        error: function (e) {
                            //alert(e.responseText);
                        }
                    });
                } catch (e) {
                    //alert(e.Message);
                }
            };

            // 取得對戰局數資料
            RankVIPGame.prototype.GetBattleRoundData = function () {
                try  {
                    var obj = this;

                    // 預設值
                    var data = {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/News/BattleRoundRank",
                        data: data,
                        async: false,
                        success: function (data) {
                            // 刪除舊資料
                            SGT['Main'].QueryFns['BattleRoundRank'].List4.splice(0, SGT['Main'].QueryFns['BattleRoundRank'].List4().length);

                            // 新增新資料
                            $.each(data.List4, function (index, obj) {
                                SGT['Main'].QueryFns['BattleRoundRank'].List4.push(obj);
                            });
                        },
                        error: function (e) {
                            //alert(e.responseText);
                        }
                    });
                } catch (e) {
                    //alert(e.Message);
                }
            };

            // 取得彩金贏分資料
            RankVIPGame.prototype.GetJPWinData = function () {
                try  {
                    var obj = this;

                    // 預設值
                    var data = {
                        QryRankType: this.QryRankType(),
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum()
                    };

                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/News/JPWinRank",
                        data: data,
                        async: false,
                        success: function (data) {
                            // 刪除舊資料
                            SGT['Main'].QueryFns['JPWinRank'].List5.splice(0, SGT['Main'].QueryFns['JPWinRank'].List5().length);

                            // 新增新資料
                            $.each(data.List5, function (index, obj) {
                                SGT['Main'].QueryFns['JPWinRank'].List5.push(obj);
                            });
                        },
                        error: function (e) {
                            //alert(e.responseText);
                        }
                    });
                } catch (e) {
                    //alert(e.Message);
                }
            };

            // 取得電子單局贏分榜資料
            RankVIPGame.prototype.GetSingleWinData = function () {
                try  {
                    var obj = this;

                    // 預設值
                    var data = {
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum(),
                        QryRankGameType: this.QryRankType()
                    };

                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/News/SingleWinRank",
                        data: data,
                        async: false,
                        success: function (data) {
                            // 刪除舊資料
                            SGT['Main'].QueryFns['SingleWinRank'].List6.splice(0, SGT['Main'].QueryFns['SingleWinRank'].List6().length);

                            // 新增新資料
                            $.each(data.List6, function (index, obj) {
                                SGT['Main'].QueryFns['SingleWinRank'].List6.push(obj);
                            });
                        },
                        error: function (e) {
                            //alert(e.responseText);
                        }
                    });
                } catch (e) {
                    //alert(e.Message);
                }
            };

            RankVIPGame.prototype.GetPachinkoData = function () {
                try  {
                    var obj = this;

                    // 預設值
                    var data = {
                        QryAreaType: this.QryAreaType(),
                        QryRankNum: this.QryRankNum(),
                        QryRankGameType: this.QryRankType()
                    };

                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/News/PachinkoRank",
                        data: data,
                        async: false,
                        success: function (data) {
                            // 刪除舊資料
                            SGT['Main'].QueryFns['PachinkoRank'].List7.splice(0, SGT['Main'].QueryFns['PachinkoRank'].List7().length);

                            // 新增新資料
                            $.each(data.List7, function (index, obj) {
                                SGT['Main'].QueryFns['PachinkoRank'].List7.push(obj);
                            });
                        },
                        error: function (e) {
                            //alert(e.responseText);
                        }
                    });
                } catch (e) {
                }
            };

            RankVIPGame.prototype.GameListBind = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/GetGameListData",
                    data: "",
                    async: false,
                    success: function (data) {
                        self.GameList(data.Result.Data);
                    },
                    error: function (e) {
                    }
                });
            };

            RankVIPGame.prototype.PachinkoGameListBind = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/News/GetPachinkoGameListData",
                    data: "",
                    async: false,
                    success: function (data) {
                        self.PachinkoGameList(data.Result.Data);
                    },
                    error: function (e) {
                    }
                });
            };

            RankVIPGame.prototype.GameListEvent = function () {
                this.QuerySingleWin(this.ListID(), "2", "100");
            };

            RankVIPGame.prototype.PachinkoGameListEvent = function () {
                this.QueryPachinko(this.ListID(), "2", "100");
            };
            return RankVIPGame;
        })();
        News.RankVIPGame = RankVIPGame;
    })(SGT.News || (SGT.News = {}));
    var News = SGT.News;
})(SGT || (SGT = {}));
