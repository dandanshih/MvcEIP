declare var $SGT;
//declare var SGT;
declare var ko;
declare var $;
declare var GetPlatform;

module SGT.News {

    export class NewsDetil {

        NewsTitle: (input?: string) => string = ko.observable("");
        ModifiedDate: (input?: string) => string = ko.observable("");
        NewsDesc: (input?: string) => string = ko.observable("");
        NewsID: (input?: number) => number = ko.observable(0);

        constructor(id: string) {
            if (id == "" || id == null || isNaN(parseInt(id))) {
                location.href = "http://" + location.hostname;
            } else {
                var self = this;
                self.NewsID(parseInt(id));
                var platform: string = "Web";
                if (typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        NewsID: self.NewsID()
                    },
                    url: '/MVC/api/News/NowNewsAnnouncementDetail',
                    async: false,
                    success: function (data) {
                        self.NewsTitle(data.Result.Data[0].NewsTitle);
                        self.ModifiedDate(data.Result.Data[0].ModifiedDate);
                        self.NewsDesc(data.Result.Data[0].NewsDesc);
                        //console.log(data.Result.Data[0].NewsTitle);

                    },
                    error: function (ex) {
                    }
                });
            }
        }
    }
}