var SGT;
(function (SGT) {
    (function (News) {
        var NewsMsg = (function () {
            function NewsMsg() {
                this.NewsTypeID = ko.observable(0);
                this.PageIndex = ko.observable(1);
                this.Keyword = ko.observable("");
                this.PageSize = ko.observable(15);
                this.TimeType = ko.observable(4);
                this.NewsData = ko.observableArray([]);
                this.TotalPage = ko.observable(0);
            }
            NewsMsg.prototype.GetNews = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        NewsTypeID: self.NewsTypeID(),
                        TimeType: self.TimeType(),
                        Keyword: self.Keyword(),
                        PageSize: self.PageSize(),
                        PageIndex: self.PageIndex()
                    },
                    url: '/MVC/api/News/NowNewsAnnouncementList',
                    async: false,
                    success: function (data) {
                        self.NewsData(data.Result.Data);
                        self.TotalPage(data.Result.TotalRecord % self.PageSize() == 0 ? Math.floor(data.Result.TotalRecord / self.PageSize()) : Math.floor(data.Result.TotalRecord / self.PageSize()) + 1);
                    },
                    error: function (ex) {
                    }
                });
                self.bindActionEffect();
            };
            NewsMsg.prototype.changePage = function (action) {
                var self = this;
                switch(action) {
                    case 1:
                        self.PageIndex(1);
                        self.GetNews();
                        self.bindActionEffect();
                        break;
                    case 2:
                        self.PageIndex(self.PageIndex() - 1);
                        self.GetNews();
                        self.bindActionEffect();
                        break;
                    case 3:
                        self.PageIndex(self.PageIndex() + 1);
                        self.GetNews();
                        self.bindActionEffect();
                        break;
                    case 4:
                        self.PageIndex(self.TotalPage());
                        self.GetNews();
                        self.bindActionEffect();
                        break;
                    case 5:
                        var goToPage = $("#pagNum").val();
                        if(!isNaN(goToPage) && goToPage <= self.TotalPage()) {
                            self.PageIndex(goToPage);
                            self.GetNews();
                            self.bindActionEffect();
                        }
                        break;
                }
            };
            NewsMsg.prototype.SearchFuc = function () {
                var self = this;
                self.TimeType($("#SearchSelect").val());
                self.Keyword($("#SearchStringg").val());
                self.GetNews();
                self.bindActionEffect();
            };
            NewsMsg.prototype.changeAction = function (ActionNum) {
                var self = this;
                self.NewsTypeID(ActionNum);
                self.GetNews();
                self.bindActionEffect();
            };
            NewsMsg.prototype.bindActionEffect = function () {
                var self = this;
                $(function () {
                    var actionArr = $('.tabs li');
                    $(actionArr).unbind('hover');
                    $.each(actionArr, function (index, value) {
                        if(index == self.NewsTypeID()) {
                            $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '_2.jpg');
                        } else {
                            $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '.jpg');
                            $(actionArr[index]).hover(function () {
                                $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '_2.jpg');
                            }, function () {
                                $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '.jpg');
                            });
                        }
                    });
                });
            };
            return NewsMsg;
        })();
        News.NewsMsg = NewsMsg;        
        var NewsData = (function () {
            function NewsData() {
                this.ImageUrl = "";
                this.ModifiedDate = "";
                this.NewsTitle = "";
            }
            return NewsData;
        })();
        News.NewsData = NewsData;        
    })(SGT.News || (SGT.News = {}));
    var News = SGT.News;
})(SGT || (SGT = {}));
