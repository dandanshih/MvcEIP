declare var $SGT;
declare var ko;
declare var $;
declare var GetPlatform;

// ���O�w�q
module SGT.News {

    export class NewsMsg {

        NewsTypeID: (input?: number) => number = ko.observable(0);
        PageIndex: (input?: number) => number = ko.observable(1);
        Keyword: (input?: string) => string = ko.observable("");
        PageSize: (input?: number) => number = ko.observable(15);
        TimeType: (input?: number) => number = ko.observable(4);
        NewsData: (input?: NewsData[]) => NewsData[] = ko.observableArray([]);
        TotalPage: (input?: number) => number = ko.observable(0);

        //�����
        public GetNews(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: {
                    Platform: platform,
                    NewsTypeID: self.NewsTypeID(),
                    TimeType: self.TimeType(),
                    Keyword: self.Keyword(),
                    PageSize: self.PageSize(),
                    PageIndex: self.PageIndex()
                },
                url: '/MVC/api/News/NowNewsAnnouncementList',
                async: false,
                success: function (data) {
                    //console.log(data.Result.Data);
                    self.NewsData(data.Result.Data);//��Ƹj�w
                    self.TotalPage(data.Result.TotalRecord % self.PageSize() == 0 ? Math.floor(data.Result.TotalRecord / self.PageSize()) : Math.floor(data.Result.TotalRecord / self.PageSize()) + 1);//���ƴ����`����              
                },
                error: function (ex) {
                }
            });
            self.bindActionEffect();
        }

        public changePage(action: number): void {
            var self = this;
            switch (action) {
                case 1:
                    self.PageIndex(1);
                    self.GetNews();
                    self.bindActionEffect();
                    break;
                case 2:
                    self.PageIndex(self.PageIndex() - 1);
                    self.GetNews();
                    self.bindActionEffect();
                    break;
                case 3:
                    self.PageIndex(self.PageIndex() + 1);
                    self.GetNews();
                    self.bindActionEffect();
                    break;
                case 4:
                    self.PageIndex(self.TotalPage());
                    self.GetNews();
                    self.bindActionEffect();
                    break;
                case 5:
                    var goToPage = $("#pagNum").val();
                    if (!isNaN(goToPage) && goToPage <= self.TotalPage()) {
                        self.PageIndex(goToPage);
                        self.GetNews();
                        self.bindActionEffect();
                    }
                    break;
            }
        }

        //�j�M
        public SearchFuc(): void {
            var self = this;
            self.TimeType($("#SearchSelect").val());
            self.Keyword($("#SearchStringg").val());
            self.GetNews();
            self.bindActionEffect();
        }

        //��Action
        public changeAction(ActionNum: number): void {
            var self = this;
            self.NewsTypeID(ActionNum);
            self.GetNews();
            self.bindActionEffect();
        }

        //Action�ĪG�]�w
        public bindActionEffect(): void {
            var self = this;
            $(function () {
                var actionArr = $('.tabs li');
                $(actionArr).unbind('hover');

                $.each(actionArr, function (index, value) {
                    if (index == self.NewsTypeID()) {
                        $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '_2.jpg');
                    } else {
                        $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '.jpg');
                        $(actionArr[index]).hover(function () {
                            $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '_2.jpg');
                        }, function () {
                            $(actionArr[index]).children('img').attr('src', SGT["WebSiteInfo"].Urls.CdnUrl + '/Html/Images/Layout/main_content/news/NewsBtn0' + (index + 1) + '.jpg');
                        });
                    }
                });
            });
        }
    }

    export class NewsData {
        NewsID: number;
        ImageUrl: string = "";
        ModifiedDate: string = "";
        NewsTitle: string = "";
    }

    // �̷s���� �Ʀ�]
    //export class RankVIPGame {
    //    /// --------------------------------------
    //    /// ko function
    //    /// --------------------------------------
    //    //�d�߱ƦW���O
    //    QryRankType = ko.observable('2');
    //    // �d�߹��O
    //    QryAreaType = ko.observable('2');
    //    // �d�ߪ��C������
    //    QryRankNum = ko.observable('100');

    //    //�ʤj�I��
    //    List1: Array[] = ko.observableArray([]);
    //    //�`Ĺ��
    //    List2: Array[] = ko.observableArray([]);
    //    //�q�l����
    //    List3: Array[] = ko.observableArray([]);
    //    //��ԧ���
    //    List4: Array[] = ko.observableArray([]);
    //    //�m��Ĺ��
    //    List5: Array[] = ko.observableArray([]);
    //    //�槽Ĺ��
    //    List6: Array[] = ko.observableArray([]);
    //    /// --------------------------------------
    //    /// function
    //    /// --------------------------------------
    //    // �d�ߦʤj�I��
    //    QueryTop100(qryranktype : string = this.QryRankType(), 
    //          qryareatype : string = this.QryAreaType(),
    //          qryranknum : string = this.QryRankNum()) {
    //        // �]�w�ƦW���O
    //        this.QryRankType(qryranktype);
    //        //�]�w���O
    //        this.QryAreaType(qryareatype);
    //        //�d�ߪ��C������
    //        this.QryRankNum(qryranknum);
    //        // �d�ߦʤj�I�����
    //        this.GetTop100Data();
    //    }

    //    // �d���`Ĺ��
    //    QueryTotalWin(qryranktype : string = this.QryRankType(), 
    //          qryareatype : string = this.QryAreaType(),
    //          qryranknum : string = this.QryRankNum()) {
    //        // �]�w�ƦW���O
    //        this.QryRankType(qryranktype);
    //        //�]�w���O
    //        this.QryAreaType(qryareatype);
    //        //�d�ߪ��C������
    //        this.QryRankNum(qryranknum);
    //        // �d���`Ĺ�����
    //        this.GetTotalWinData();
    //    }

    //    // �d�߹q�l����
    //    QueryElecRound(qryranktype : string = this.QryRankType(), 
    //          qryareatype : string = this.QryAreaType(),
    //          qryranknum : string = this.QryRankNum()) {
    //        // �]�w�ƦW���O
    //        this.QryRankType(qryranktype);
    //        //�]�w���O
    //        this.QryAreaType(qryareatype);
    //        //�d�ߪ��C������
    //        this.QryRankNum(qryranknum);
    //        // �d�߹q�l���Ƹ��
    //        this.GetElecRoundData();
    //    }

    //    // �d�߹�ԧ���
    //    QueryBattleRound(qryranktype : string = this.QryRankType(), 
    //          qryareatype : string = this.QryAreaType(),
    //          qryranknum : string = this.QryRankNum()) {
    //        // �]�w�ƦW���O
    //        this.QryRankType(qryranktype);
    //        //�]�w���O
    //        this.QryAreaType(qryareatype);
    //        //�d�ߪ��C������
    //        this.QryRankNum(qryranknum);
    //        // �d�߹�ԧ��Ƹ��
    //        this.GetBattleRoundData();
    //    }

    //    // �d�߱m��Ĺ��
    //    QueryJPWin(qryranktype : string = this.QryRankType(), 
    //          qryareatype : string = this.QryAreaType(),
    //          qryranknum : string = this.QryRankNum()) {
    //        // �]�w�ƦW���O
    //        this.QryRankType(qryranktype);
    //        //�]�w���O
    //        this.QryAreaType(qryareatype);
    //        //�d�ߪ��C������
    //        this.QryRankNum(qryranknum);
    //        // �d�߱m��Ĺ�����
    //        this.GetJPWinData();
    //    }

    //    // �d�߳槽Ĺ��
    //    QuerySingleWin(qryareatype : string = this.QryAreaType(),
    //          qryranknum : string = this.QryRankNum()) {
    //        //�]�w���O
    //        this.QryAreaType(qryareatype);
    //        //�d�ߪ��C������
    //        this.QryRankNum(qryranknum);
    //        // �d�߳槽Ĺ�����
    //        this.GetSingleWinData();
    //    }

    //    // ���o�ʤj�I�����
    //    public GetTop100Data(): void {
    //        try {
    //            var obj = this;
    //            // �w�]��
    //            var data =
    //            {
    //                QryRankType: this.QryRankType(),
    //                QryAreaType: this.QryAreaType(),
    //                QryRankNum: this.QryRankNum()
    //            };

    //            $.ajax({
    //                type: "Post",
    //                url: "/Mvc/api/News/Top100Rank",
    //                data: data,
    //                success: function (data) {
    //                    // �R���¸��
    //                    SGT['Main'].QueryFns['Top100Rank'].List1.splice(0, SGT['Main'].QueryFns['Top100Rank'].List1().length)
    //                    // �s�W�s���
    //                    $.each(data.List1, function (index, obj) { SGT['Main'].QueryFns['Top100Rank'].List1.push(obj); });
    //                },
    //                error: function (e) {
    //                     //alert(e.responseText);
    //                }
    //            });
    //        } catch (e) {
    //            //alert(e.Message);
    //        }
    //    }

    //    // ���o�`Ĺ�����
    //    public GetTotalWinData(): void {
    //        try {
    //            var obj = this;
    //            // �w�]��
    //            var data =
    //            {
    //                QryRankType: this.QryRankType(),
    //                QryAreaType: this.QryAreaType(),
    //                QryRankNum: this.QryRankNum()
    //            };

    //            $.ajax({
    //                type: "Post",
    //                url: "/Mvc/api/News/TotalWinRank",
    //                data: data,
    //                success: function (data) {
    //                    // �R���¸��
    //                    SGT['Main'].QueryFns['TotalWinRank'].List2.splice(0, SGT['Main'].QueryFns['TotalWinRank'].List2().length)
    //                    // �s�W�s���
    //                    $.each(data.List2, function (index, obj) { SGT['Main'].QueryFns['TotalWinRank'].List2.push(obj); });
    //                },
    //                error: function (e) {
    //                     //alert(e.responseText);
    //                }
    //            });
    //        } catch (e) {
    //            //alert(e.Message);
    //        }
    //    }

    //     // ���o�q�l���Ƹ��
    //    public GetElecRoundData(): void {
    //        try {
    //            var obj = this;
    //            // �w�]��
    //            var data =
    //            {
    //                QryRankType: this.QryRankType(),
    //                QryAreaType: this.QryAreaType(),
    //                QryRankNum: this.QryRankNum()
    //            };

    //            $.ajax({
    //                type: "Post",
    //                url: "/Mvc/api/News/ElecRoundRank",
    //                data: data,
    //                success: function (data) {
    //                    // �R���¸��
    //                    SGT['Main'].QueryFns['ElecRoundRank'].List3.splice(0, SGT['Main'].QueryFns['ElecRoundRank'].List3().length)
    //                    // �s�W�s���
    //                    $.each(data.List3, function (index, obj) { SGT['Main'].QueryFns['ElecRoundRank'].List3.push(obj); });
    //                },
    //                error: function (e) {
    //                     //alert(e.responseText);
    //                }
    //            });
    //        } catch (e) {
    //            //alert(e.Message);
    //        }
    //    }

    //    // ���o��ԧ��Ƹ��
    //    public GetBattleRoundData(): void {
    //        try {
    //            var obj = this;
    //            // �w�]��
    //            var data =
    //            {
    //                QryRankType: this.QryRankType(),
    //                QryAreaType: this.QryAreaType(),
    //                QryRankNum: this.QryRankNum()
    //            };

    //            $.ajax({
    //                type: "Post",
    //                url: "/Mvc/api/News/BattleRoundRank",
    //                data: data,
    //                success: function (data) {
    //                    // �R���¸��
    //                    SGT['Main'].QueryFns['BattleRoundRank'].List4.splice(0, SGT['Main'].QueryFns['BattleRoundRank'].List4().length)
    //                    // �s�W�s���
    //                    $.each(data.List4, function (index, obj) { SGT['Main'].QueryFns['BattleRoundRank'].List4.push(obj); });
    //                },
    //                error: function (e) {
    //                     //alert(e.responseText);
    //                }
    //            });
    //        } catch (e) {
    //            //alert(e.Message);
    //        }
    //    }

    //     // ���o�m��Ĺ�����
    //    public GetJPWinData(): void {
    //        try {
    //            var obj = this;
    //            // �w�]��
    //            var data =
    //            {
    //                QryRankType: this.QryRankType(),
    //                QryAreaType: this.QryAreaType(),
    //                QryRankNum: this.QryRankNum()
    //            };

    //            $.ajax({
    //                type: "Post",
    //                url: "/Mvc/api/News/JPWinRank",
    //                data: data,
    //                success: function (data) {
    //                    // �R���¸��
    //                    SGT['Main'].QueryFns['JPWinRank'].List5.splice(0, SGT['Main'].QueryFns['JPWinRank'].List5().length)
    //                    // �s�W�s���
    //                    $.each(data.List5, function (index, obj) { SGT['Main'].QueryFns['JPWinRank'].List5.push(obj); });
    //                },
    //                error: function (e) {
    //                     //alert(e.responseText);
    //                }
    //            });
    //        } catch (e) {
    //            //alert(e.Message);
    //        }
    //    }

    //    // ���o�槽Ĺ�����
    //    public GetSingleWinData(): void { 
    //        try {
    //            var obj = this;
    //            // �w�]��
    //            var data =
    //            {
    //                QryAreaType: this.QryAreaType(),
    //                QryRankNum: this.QryRankNum()
    //            };

    //            $.ajax({
    //                type: "Post",
    //                url: "/Mvc/api/News/SingleWinRank",
    //                data: data,
    //                success: function (data) {
    //                    // �R���¸��
    //                    SGT['Main'].QueryFns['SingleWinRank'].List6.splice(0, SGT['Main'].QueryFns['SingleWinRank'].List6().length)

    //                    // �s�W�s���
    //                    $.each(data.List6, function (index, obj) { SGT['Main'].QueryFns['SingleWinRank'].List6.push(obj); });
    //                },
    //                error: function (e) {
    //                     //alert(e.responseText);
    //                }
    //            });
    //        } catch (e) {
    //            //alert(e.Message);
    //        }
    //    }
    //}


}