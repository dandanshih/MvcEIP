var $PointBuy = (function () {
    function $PointBuy() { }
    $PointBuy.PageInit = function PageInit(groupType) {
        if (typeof groupType === "undefined") { groupType = 0; }
        $PointBuy._BaseInstance = new SGT.DynamicPages.PointBuyBase();
        $PointBuy._BaseInstance.Base_Init(groupType);
    };
    $PointBuy.GetRecord = function GetRecord() {
        return $PointBuy._BaseInstance.Base_Get_PayRecord();
    };
    $PointBuy.GetValue = function GetValue() {
        return $PointBuy._BaseInstance.Base_Get_ValueList();
    };
    $PointBuy.GetProduct = function GetProduct() {
        return $PointBuy._BaseInstance.Base_Get_ProductAll();
    };
    $PointBuy.QueryProduct = function QueryProduct(productList) {
        return $PointBuy._BaseInstance.Base_Get_ProductList(productList);
    };
    $PointBuy.GetCity = function GetCity() {
        return $PointBuy._BaseInstance.Base_Get_CityList();
    };
    $PointBuy.QueryZone = function QueryZone(cityId) {
        return $PointBuy._BaseInstance.Base_Get_ZoneList(cityId);
    };
    $PointBuy.QueryTransInfo = function QueryTransInfo(valueId, productId, ecoupon) {
        return $PointBuy._BaseInstance.Base_Get_Worth(valueId, productId, ecoupon);
    };
    $PointBuy.CheckECoupon = function CheckECoupon(valueId, ecoupon) {
        return $PointBuy._BaseInstance.Base_Check_ValueECoupon(valueId, ecoupon);
    };
    $PointBuy.CheckEmail = function CheckEmail(email) {
        var result = $PointBuy._BaseInstance.Base_Check_Email(email);
        return (result.IsSuccess ? "" : result.Message);
    };
    $PointBuy.CheckName = function CheckName(name) {
        var result = $PointBuy._BaseInstance.Base_Check_InvoiceName(name);
        return (result.IsSuccess ? "" : result.Message);
    };
    $PointBuy.CheckAddress = function CheckAddress(address) {
        var result = $PointBuy._BaseInstance.Base_Check_InvoiceAddress(address);
        return (result.IsSuccess ? "" : result.Message);
    };
    $PointBuy.SaveRecord = function SaveRecord(data) {
        $PointBuy._BaseInstance.Base_Set_Record(data);
    };
    return $PointBuy;
})();
