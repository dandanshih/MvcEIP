/// <reference path="../Base/TransferBase.ts" />


// �|����b
class $Transfer {
    /// --------------------------------------
    /// property
    /// --------------------------------------
    // Base ����
    private static _BaseInstance: SGT.DynamicPages.TransferBase = new SGT.DynamicPages.TransferBase();

    // ���o�|����b��T
    public static GetTransInfo(): SGT.DynamicPages.Base_Struct_TransferInfo {
        return $Transfer._BaseInstance.Base_Get_Info();
    }

    // ���o�|����b��H�ʺ٦C��
    public static GetTransTarget(): SGT.DynamicPages.Base_Struct_TransferTarget[] {
        return $Transfer._BaseInstance.Base_Get_Member();
    }

    // �R���|����b��H�ʺ٦C��
    public static DelTransTarget(no: string): void {
        $Transfer._BaseInstance.Base_Del_Member(no);
    }

    // ���o�|����b�O��
    public static GetTransferMaster(): SGT.DynamicPages.Base_Struct_TransferMaster[] {
        return $Transfer._BaseInstance.Base_Get_TransferMaster();
    }

    // �|����b
    public static MemberTrans(targetName: string, changePoints: number, isKeepName: bool, platinum: number): SGT.DynamicPages.Base_Struct_CheckResult {
        return $Transfer._BaseInstance.Base_Submit_MemberTransfer(targetName, changePoints, isKeepName, platinum);
    }

    // ������|���P�N/������b
    public static MemberConfirm(no: string, isAgree: bool): SGT.DynamicPages.Base_Struct_TransferConfirmResult {
        return $Transfer._BaseInstance.Base_Submit_TransferConfirm(no, (isAgree ? 1 : 2));
    }

    // �o�e��|���T�{��b
    public static MemberVerify(no: string, verifyCode: string): SGT.DynamicPages.Base_Struct_TransferConfirmResult {
        return $Transfer._BaseInstance.Base_Submit_TransferVerify(no, verifyCode);
    }

    public static SendSMSCode(no: string): SGT.DynamicPages.Base_Struct_SendSMSCodeResult {
        return $Transfer._BaseInstance.Base_Submit_SendSMSCode(no);
    }

    public static GetReloadTransInfo(): void {
        $Transfer._BaseInstance.Base_Get_Reload_Info();
    }
}
