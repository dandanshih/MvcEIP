/// <reference path="../Base/PointBuyBase.ts" />
    

// �u�W���I
class $PointBuy {
    /// --------------------------------------
    /// property
    /// --------------------------------------
    private static _BaseInstance: SGT.DynamicPages.PointBuyBase;

    /// --------------------------------------
    /// function
    /// --------------------------------------
    public static PageInit(groupType: number = 0): void {
        $PointBuy._BaseInstance = new SGT.DynamicPages.PointBuyBase();
        $PointBuy._BaseInstance.Base_Init(groupType);
    }

    // ���o�O��
    public static GetRecord(): SGT.DynamicPages.Base_Struct_PayRecord {
        return $PointBuy._BaseInstance.Base_Get_PayRecord();
    }

    // ���o�Ҧ����B�C��
    public static GetValue(): SGT.DynamicPages.Base_Struct_ValueList[] {
        return $PointBuy._BaseInstance.Base_Get_ValueList();
    }

    // ���o�Ҧ��I�ڤ覡�C��
    public static GetProduct(): SGT.DynamicPages.Base_Struct_ProductList[] {
        return $PointBuy._BaseInstance.Base_Get_ProductAll();
    }

    // �d�ߥI�ڤ覡�C��
    public static QueryProduct(productList: string): SGT.DynamicPages.Base_Struct_ProductList[] {
        return $PointBuy._BaseInstance.Base_Get_ProductList(productList);
    }

    // ���o�Ҧ������C��
    public static GetCity(): SGT.DynamicPages.Base_Struct_CityList[] {
        return $PointBuy._BaseInstance.Base_Get_CityList();
    }

    // �d�߰ϰ�C��
    public static QueryZone(cityId: number): SGT.DynamicPages.Base_Struct_ZoneList[] {
        return $PointBuy._BaseInstance.Base_Get_ZoneList(cityId);
    }

    // �d�ߥ���I��
    public static QueryTransInfo(valueId: number, productId: number, ecoupon: string): SGT.DynamicPages.Base_Struct_Worth {
        return $PointBuy._BaseInstance.Base_Get_Worth(valueId, productId, ecoupon);
    }

    // ���� ECoupon
    public static CheckECoupon(valueId: number, ecoupon: string): SGT.DynamicPages.Base_Struct_CheckValueECouponResult {
        return $PointBuy._BaseInstance.Base_Check_ValueECoupon(valueId, ecoupon);
    }

    // ���� Email
    public static CheckEmail(email: string): string {
        var result = $PointBuy._BaseInstance.Base_Check_Email(email);
        return (result.IsSuccess ? "" : result.Message);
    }

    // ���� �o������H
    public static CheckName(name: string): string {
        var result = $PointBuy._BaseInstance.Base_Check_InvoiceName(name);
        return (result.IsSuccess ? "" : result.Message);
    }

    // ���� �o���H�e�a�}
    public static CheckAddress(address: string): string {

        // ���Ҧa�}�榡
        var result = $PointBuy._BaseInstance.Base_Check_InvoiceAddress(address);
        return (result.IsSuccess ? "" : result.Message);
    }

    // �x�s����
    public static SaveRecord(data: SGT.DynamicPages.Base_Struct_PayRecord): void {
        $PointBuy._BaseInstance.Base_Set_Record(data);
    }
}
