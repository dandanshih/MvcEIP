var $Transfer = (function () {
    function $Transfer() { }
    $Transfer._BaseInstance = new SGT.DynamicPages.TransferBase();
    $Transfer.GetTransInfo = function GetTransInfo() {
        return $Transfer._BaseInstance.Base_Get_Info();
    };
    $Transfer.GetTransTarget = function GetTransTarget() {
        return $Transfer._BaseInstance.Base_Get_Member();
    };
    $Transfer.DelTransTarget = function DelTransTarget(no) {
        $Transfer._BaseInstance.Base_Del_Member(no);
    };
    $Transfer.GetTransferMaster = function GetTransferMaster() {
        return $Transfer._BaseInstance.Base_Get_TransferMaster();
    };
    $Transfer.MemberTrans = function MemberTrans(targetName, changePoints, isKeepName, platinum) {
        return $Transfer._BaseInstance.Base_Submit_MemberTransfer(targetName, changePoints, isKeepName, platinum);
    };
    $Transfer.MemberConfirm = function MemberConfirm(no, isAgree) {
        return $Transfer._BaseInstance.Base_Submit_TransferConfirm(no, (isAgree ? 1 : 2));
    };
    $Transfer.MemberVerify = function MemberVerify(no, verifyCode) {
        return $Transfer._BaseInstance.Base_Submit_TransferVerify(no, verifyCode);
    };
    $Transfer.SendSMSCode = function SendSMSCode(no) {
        return $Transfer._BaseInstance.Base_Submit_SendSMSCode(no);
    };
    $Transfer.GetReloadTransInfo = function GetReloadTransInfo() {
        $Transfer._BaseInstance.Base_Get_Reload_Info();
    };
    return $Transfer;
})();
