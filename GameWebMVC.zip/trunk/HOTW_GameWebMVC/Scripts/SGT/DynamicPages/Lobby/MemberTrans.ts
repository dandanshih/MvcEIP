/// <reference path="../Base/MemberTransBase.ts" />


// �|����b
class $MemberTrans {
    /// --------------------------------------
    /// property
    /// --------------------------------------
    // Base ����
    private static _BaseInstance: SGT.DynamicPages.MemberTransBase = new SGT.DynamicPages.MemberTransBase();

    // ���o�|����b��H�ʺ٦C��
    public static GetTransTarget(): SGT.DynamicPages.Base_Struct_TransTarget[] {
        return $MemberTrans._BaseInstance.Base_Get_Member();
    }

    // ���o�|����b��T
    public static GetTransInfo(): SGT.DynamicPages.Base_Struct_TransInfo {
        return $MemberTrans._BaseInstance.Base_Get_Info();
    }

    // �R���|����b��H�ʺ٦C��
    public static DelTransTarget(no: number): void {
        $MemberTrans._BaseInstance.Base_Del_Member(no);
    }

    // �|����b
    public static MemberTrans(targetName: string, changePoints: number, platinum: number): SGT.DynamicPages.Base_Struct_CheckResult {
        return $MemberTrans._BaseInstance.Base_Submit_MemberTrans(targetName, changePoints, platinum);
    }
}
