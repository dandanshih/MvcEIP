//declare var SGT;
declare var $;
declare var ko;
declare var GetPlatform;

module SGT.DynamicPages {

    // �ڪ��a�A�v
    export class PersonalGlory {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (koName: string = 'PersonalGlory', pageName: string = 'PageParial') {
            this.KoName = koName;
            this.PageName = pageName;

            var obj = this;

            // New �@�ӷs�� Page Instance�A�åB�w�q ChangeEvent �����ƥ�
            SGT["Pages"].PageMgr.Add(this.PageName, new SGT["Pages"].Page(function () {
                obj.GetData();
            }, 30));
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private PageName: string = '';
        private KoName: string = '';

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // ���X���C��
        List = ko.observableArray([]);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // �d�ߨƥ�
        Query(): void {
            // ���] PageIndex
            SGT["Pages"].PageMgr.GetInstance(this.PageName).PageIndex(1);
            // �d�߸��
            this.GetData();
        }

        // ���o���
        private GetData(): void {
            var self = this;
            var page = SGT["Pages"].PageMgr.GetInstance(this.PageName);

            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            // �w�]��
            var data =
            {
                  PageSize: page.PageSize()
                , PageIndex: page.PageIndex()
                , Platform: platform
            };

            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/personalglory",
                data: data,
                success: function (data) {
                    self.List(data.List);
                    // �]�w Page �`����
                    page.TotalRecord(data.TotalRecord);
                },
                error: function (e) {
                    // alert(e.responseText);
                }
            });
        }
    }

}