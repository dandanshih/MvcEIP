var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var ExchangeNovice = (function () {
            function ExchangeNovice(koName) {
                if (typeof koName === "undefined") { koName = 'ExchangeNovice'; }
                this.KoName = '';
                this.FBCoin = ko.observable(0);
                this.FBCoinMaxChange = ko.observable(0);
                this.FBCoinExchange = ko.observable(0);
                this.KoName = koName;
                var self = this;
                this.GetFBCoin();
            }
            ExchangeNovice.prototype.GetFBCoin = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/getfbcoin",
                    success: function (data) {
                        self.FBCoin(data.FBCoin);
                        self.FBCoinMaxChange(data.FBCoinMaxChange);
                        self.FBCoinExchange(data.FBCoinExchange);
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                    }
                });
            };
            return ExchangeNovice;
        })();
        DynamicPages.ExchangeNovice = ExchangeNovice;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;

})(SGT || (SGT = {}));

