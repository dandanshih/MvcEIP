var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var PersonalGlory = (function () {
            function PersonalGlory(koName, pageName) {
                if (typeof koName === "undefined") { koName = 'PersonalGlory'; }
                if (typeof pageName === "undefined") { pageName = 'PageParial'; }
                this.PageName = '';
                this.KoName = '';
                this.List = ko.observableArray([]);
                this.KoName = koName;
                this.PageName = pageName;
                var obj = this;
                SGT["Pages"].PageMgr.Add(this.PageName, new SGT["Pages"].Page(function () {
                    obj.GetData();
                }, 30));
            }
            PersonalGlory.prototype.Query = function () {
                SGT["Pages"].PageMgr.GetInstance(this.PageName).PageIndex(1);
                this.GetData();
            };
            PersonalGlory.prototype.GetData = function () {
                var self = this;
                var page = SGT["Pages"].PageMgr.GetInstance(this.PageName);
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                var data = {
                    PageSize: page.PageSize(),
                    PageIndex: page.PageIndex(),
                    Platform: platform
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/personalglory",
                    data: data,
                    success: function (data) {
                        self.List(data.List);
                        page.TotalRecord(data.TotalRecord);
                    },
                    error: function (e) {
                    }
                });
            };
            return PersonalGlory;
        })();
        DynamicPages.PersonalGlory = PersonalGlory;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
