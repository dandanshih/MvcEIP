﻿/// <reference path="../Member/MemberRegisterAttribute.ts" />

module SGT.DynamicPages {

    export class MemberRegisterBase {

        constructor() {

        }

        ControlList: { [key: string]: iControlAttribute; } = {};

        Add(key: string, value: iControlAttribute): void {

            this.ControlList[key] = value;
        }

        Remove(key: string): void {

            delete this.ControlList[key];
        }

        Valid(key: string): bool {
            throw "請實作Valid Method";
        }

        ValidAll(): bool {

            for (var i in this.ControlList) {
                if (!this.ControlList[i].Valid()) {
                    return this.ControlList[i].Valid();
                }
            }

            return true;
        }

        Reset(): void {
            throw "請實作Reset Method";
        }

        Register(): void {

            if (this.ValidAll()) {
                this.RunApi();
            }
        }

        RunApi(): void {
            throw "請實作RunApi Method";
        }

        Login(): void {
            $.ajax({
                type: "POST",
                url: "/MVC/api/account/AutoLogin",
                async: false,
                data: "",
                dataType: "json",
                success: function (data) {
                    if (data.ResultCode == 1) {
                        if (opener != null && typeof opener.window != 'unknown' && typeof opener != undefined) {
                            opener.window.location.reload();
                        }
                        location.href = "/Web/Game/MiniList.aspx";
                    }
                    else if (data.ResultCode == 98) {
                        alert("登入資訊不正確。");
                    }
                    else if (data.ResultCode == 99 || data.ResultCode == 12) {
                        alert("遊戲目前進行維護中，請稍後再來玩！");
                        window.close();
                    }
                    else {
                        alert(data.ResultMsg);
                    }
                },
                error: function (e) {

                },
                complete: function () {

                }
            });
        }
    }
}