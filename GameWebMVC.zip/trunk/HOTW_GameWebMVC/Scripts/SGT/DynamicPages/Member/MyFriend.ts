﻿//declare var SGT;
declare var $;
declare var ko;
declare var GetPlatform;

module SGT.DynamicPages {

    // 我的好友
    export class MyFriend {

        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor(koName: string = 'MyFriend', pageName: string = 'PageParial', pageSize: number = 30) {
            this.KoName = koName;
            this.PageName = pageName;
            this.PageSize = pageSize;

            var obj = this;

            if (pageName != '') {
                // New 一個新的 Page Instance，並且定義 ChangeEvent 換頁事件
                SGT["Pages"].PageMgr.Add(this.PageName, new SGT["Pages"].Page(function () {
                    obj.GetDataNoCache();
                }, pageSize));
                this.HasPager = true;
            }
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private PageName: string = '';
        private KoName: string = '';
        private PageSize: number = 30;
        private HasPager: bool = false;

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // 取出的列表
        List = ko.observableArray([]);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // 查詢事件
        Query(): void {
            // 重設 PageIndex

            SGT["Pages"].PageMgr.GetInstance(this.PageName).PageIndex(1);
            
            // 查詢資料
            this.GetDataNoCache();
        }



        //新增好友事件
        AddFriend(): void {
            this.addMyFriend();
        }

        // 取得資料
        private GetData(): void {
            var self = this;
            var page = SGT["Pages"].PageMgr.GetInstance(this.PageName);

            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            // 預設值
            var data =
                {
                    PageSize: (this.HasPager == false) ? 7 : page.PageSize()
                    , PageIndex:  page.PageIndex()
                    , Platform: platform
                };


            $.ajax({
                type: "POST",
                url: "/Mvc/api/member/MyFriendNoCache",
                async: false,
                dataType: "JSON",
                data: data,
                success: function (data) {
                    self.List(data.Result.List);
                    // 設定 Page 總筆數
                    page.TotalRecord(data.Result.RowCount);
                },
                error: function (e) {
                    // alert(e.responseText);
                }
            });
        }

        // 取得資料
        private GetDataNoCache(): void {
            var self = this;
            var page = SGT["Pages"].PageMgr.GetInstance(this.PageName);

            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            // 預設值
            var data =
                {
                    PageSize: (this.HasPager == false) ? 7 : page.PageSize()
                    , PageIndex:  page.PageIndex()
                    , Platform: platform
                };


            $.ajax({
                type: "POST",
                url: "/Mvc/api/member/MyFriendNoCache",
                async: false,
                dataType: "JSON",
                data: data,
                success: function (data) {
                    self.List(data.Result.List);
                    // 設定 Page 總筆數
                    page.TotalRecord(data.Result.RowCount);
                },
                error: function (e) {
                    // alert(e.responseText);
                }
            });
        }

        //新增好友
        private addMyFriend(): void {
            var self = this;
            var Result = 0;
            var friendNickName = $('#MyFriendID_text').val();

            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            if (friendNickName != '') {
                // 預設值
                var data =
                    {
                        Result: Result,
                        FriendNickName: friendNickName,
                        Platform: platform
                    };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/AddMyFriend",
                    data: data,
                    success: function (data) {
                        Result = data.result;
                        if (Result == 0) {
                            self.GetDataNoCache();
                            alert('新增好友成功!!');
                        }
                        else if (Result == 1) {
                            alert('好友暱稱不存在!!');
                        }
                        else if (Result == 2) {
                            alert('已存在好友名單!!');
                        }
                        else if (Result == 3) {
                            alert('好友已達上限，無法再新增!!');
                        }

                    },
                    error: function (e) {
                        // alert(e.responseText);
                    }

                });
            }
            else {
                alert('請輸入好友暱稱!!');
            }
        }

        //刪除好友
        private deleteMyFriend(friendNickName): void {
            if (!confirm('確定刪除好友？')) {
                return;
            }
            var self = this;
            var Result = 0;
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            // 預設值
            var data =
                {
                    Result: Result,
                    FriendNickName: friendNickName,
                    Platform: platform
                };
            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/DeleteMyFriend",
                data: data,
                success: function (data) {
                    Result = data.result;

                    if (Result == 0) {
                        self.GetDataNoCache();
                        alert('刪除好友成功!!');
                    }
                    else if (Result == 1) {
                        alert('好友暱稱不存在!!');
                    }
                    else if (Result == 2) {
                        alert('不存在好友名單!!');
                    }
                },
                error: function (e) {
                    // alert(e.responseText);
                }

            });
        }
    }

}