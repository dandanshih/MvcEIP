﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var ControlAttribute = (function () {
            function ControlAttribute(id, type, name) {
                this.ID = "";
                this.Type = "";
                this.Name = "";
                this.ErrorMsg = "";
                this.Value = "";
                this.Agree = false;
                this.ErrorMsgID = "";
                this.ID = id;
                this.Type = type;
                this.Name = name;
                this.ErrorMsgID = this.ID + "ErrorMsgID";
            }
            ControlAttribute.prototype.SelectMessage = function (input, name1, name2, name3) {
                var msg = "";
                switch(input) {
                    case 1:
                        msg = name1 + "不可空白。";
                        break;
                    case 2:
                        msg = name1 + "必須是6~12碼的英文數字組合。";
                        break;
                    case 3:
                        msg = name1 + "至少須包含一個英文字母。";
                        break;
                    case 4:
                        msg = "此" + name1 + "已被使用。";
                        break;
                    case 5:
                        msg = name1 + "必須包含4種(含)字元以上。";
                        break;
                    case 6:
                        msg = name1 + "不可為連續數字或字母。";
                        break;
                    case 7:
                        msg = "兩次密碼錯誤。";
                        break;
                    case 8:
                        msg = name1 + "格式錯誤。";
                        break;
                    case 9:
                        msg = name1 + "中不可包含" + name2 + "或" + name3 + "。";
                        break;
                    case 10:
                        msg = name1 + "重複。";
                        break;
                    case 11:
                        msg = "此" + name1 + "已被鎖定，請洽客服專員。";
                        break;
                    case 12:
                        msg = "此" + name1 + "已被申請過。";
                        break;
                    case 13:
                        msg = "此" + name1 + "無效。";
                        break;
                    case 14:
                        msg = "此" + name1 + "未通過驗證。";
                        break;
                    case 15:
                        msg = name1 + "錯誤，請重新輸入。";
                        break;
                    case 16:
                        msg = name1 + "中不可包含" + name2 + "。";
                        break;
                }
                return msg;
            };
            ControlAttribute.prototype.SetErrorMessage = function () {
                $("#" + this.ErrorMsgID).html(this.ErrorMsg);
            };
            return ControlAttribute;
        })();
        DynamicPages.ControlAttribute = ControlAttribute;        
        var AccountControl = (function () {
            function AccountControl(base) {
                this.Control = new ControlAttribute("Account", "Account", "帳號");
                this.Base = base;
            }
            AccountControl.prototype.Valid = function () {
                var self = this;
                var b = false;
                var value = $.trim(self.Control.Value);
                var errmsg = "";
                if(value == "") {
                    errmsg = self.Control.SelectMessage(1, self.Control.Name);
                } else if(!value.match(/^[0-9a-zA-Z]{6,12}$/)) {
                    errmsg = self.Control.SelectMessage(2, self.Control.Name);
                } else if(!value.match(/(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$/)) {
                    errmsg = self.Control.SelectMessage(3, self.Control.Name);
                } else if($.trim(self.Base.Password.Control.Value) != "" && value.indexOf(self.Base.Password.Control.Value) > -1) {
                    errmsg = self.Control.SelectMessage(16, self.Control.Name, self.Base.Password.Control.Name);
                } else {
                    $.ajax({
                        type: "POST",
                        async: false,
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        data: {
                            "ResultType": "2",
                            "CheckType": "1",
                            "CheckData": value
                        },
                        success: function (data) {
                            if(data == "Success") {
                                b = true;
                            } else {
                                errmsg = data;
                            }
                        },
                        error: function (e) {
                        }
                    });
                }
                self.Control.ErrorMsg = errmsg;
                self.Control.SetErrorMessage();
                return b;
            };
            AccountControl.prototype.Reset = function () {
                this.Control.Value = "";
                this.Control.ErrorMsg = "";
                this.Control.SetErrorMessage();
            };
            return AccountControl;
        })();
        DynamicPages.AccountControl = AccountControl;        
        var PasswordControl = (function () {
            function PasswordControl(base) {
                this.Control = new ControlAttribute("Password", "Password", "密碼");
                this.Base = base;
            }
            PasswordControl.prototype.Valid = function () {
                var self = this;
                var b = true;
                var value = self.Control.Value;
                var errmsg = "";
                var comparestring = "";
                var passwdBar = document.getElementById('passwdBar');
                if(passwdBar != null) {
                    ResetBar();
                }
                if($.trim(value) == "") {
                    errmsg = self.Control.SelectMessage(1, self.Control.Name);
                    b = false;
                } else if(!value.match(/^[0-9a-zA-Z]{6,12}$/)) {
                    errmsg = self.Control.SelectMessage(2, self.Control.Name);
                    b = false;
                } else if(value.match(/^[0-9]{6,12}$/)) {
                    errmsg = self.Control.SelectMessage(3, self.Control.Name);
                    b = false;
                } else if($.trim(self.Base.Account.Control.Value) != "" && value.indexOf(self.Base.Account.Control.Value) > -1) {
                    errmsg = self.Control.SelectMessage(16, self.Control.Name, self.Base.Account.Control.Name);
                    b = false;
                } else {
                    for(var i = 0; i < value.length; i++) {
                        if(comparestring.indexOf(value.charAt(i)) == -1) {
                            comparestring += value.charAt(i);
                        }
                    }
                    if(comparestring.length < 4) {
                        errmsg = self.Control.SelectMessage(5, self.Control.Name);
                        b = false;
                    } else {
                        value = value.toLowerCase();
                        for(i = 0; i < value.length; i++) {
                            var code = value.charCodeAt(i);
                            var codeDefault = '' + value.charCodeAt(i) + value.charCodeAt(i + 1) + value.charCodeAt(i + 2);
                            var code2 = '' + code + (code + 1) + (code + 2);
                            var code3 = '' + code + (code - 1) + (code - 2);
                            if(value.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                                errmsg = self.Control.SelectMessage(6, self.Control.Name);
                                b = false;
                                break;
                            }
                        }
                    }
                }
                self.Control.ErrorMsg = errmsg;
                if(passwdBar != null) {
                    var ctl = document.getElementById("Password");
                    CreateRatePasswdReq(ctl);
                }
                self.Control.SetErrorMessage();
                return b;
            };
            PasswordControl.prototype.Reset = function () {
                this.Control.Value = "";
                this.Control.ErrorMsg = "";
                this.Control.SetErrorMessage();
            };
            return PasswordControl;
        })();
        DynamicPages.PasswordControl = PasswordControl;        
        var ConfirmPasswordControl = (function () {
            function ConfirmPasswordControl(base) {
                this.Control = new ControlAttribute("ConfirmPassword", "ConfirmPassword", "確認密碼");
                this.Base = base;
            }
            ConfirmPasswordControl.prototype.Valid = function () {
                var self = this;
                var b = false;
                var value = $.trim(self.Control.Value);
                var errmsg = "";
                if(value == "") {
                    errmsg = self.Control.SelectMessage(1, self.Control.Name);
                } else if(value != self.Base.Password.Control.Value) {
                    errmsg = self.Control.SelectMessage(7, self.Control.Name);
                } else {
                    b = true;
                    errmsg = "";
                }
                self.Control.ErrorMsg = errmsg;
                self.Control.SetErrorMessage();
                return b;
            };
            ConfirmPasswordControl.prototype.Reset = function () {
                this.Control.Value = "";
                this.Control.ErrorMsg = "";
                this.Control.SetErrorMessage();
            };
            return ConfirmPasswordControl;
        })();
        DynamicPages.ConfirmPasswordControl = ConfirmPasswordControl;        
        var MobileControl = (function () {
            function MobileControl(base) {
                this.Control = new ControlAttribute("Mobile", "Mobile", "手機號碼");
                this.Base = base;
            }
            MobileControl.prototype.Valid = function () {
                var self = this;
                var b = false;
                var value = $.trim(self.Control.Value);
                var errmsg = "";
                if(value == "") {
                    errmsg = self.Control.SelectMessage(1, self.Control.Name);
                } else if(!value.match(/^[09]{2}[0-9]{8}$/)) {
                    errmsg = self.Control.SelectMessage(8, self.Control.Name);
                } else if(($.trim(self.Base.Account.Control.Value) != "" && value.indexOf(self.Base.Account.Control.Value) > -1) || ($.trim(self.Base.Password.Control.Value) != "" && value.indexOf(self.Base.Password.Control.Value) > -1)) {
                    errmsg = self.Control.SelectMessage(9, self.Control.Name, self.Base.Account.Control.Name, self.Base.Password.Control.Name);
                } else {
                    $.ajax({
                        type: "POST",
                        async: false,
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        data: {
                            "ResultType": "2",
                            "CheckType": "3",
                            "CheckData": value
                        },
                        success: function (data) {
                            if(data == "Success") {
                                b = true;
                            } else {
                                errmsg = data;
                            }
                        },
                        error: function (e) {
                        }
                    });
                }
                self.Control.ErrorMsg = errmsg;
                self.Control.SetErrorMessage();
                return b;
            };
            MobileControl.prototype.Reset = function () {
                this.Control.Value = "";
                this.Control.ErrorMsg = "";
                this.Control.SetErrorMessage();
            };
            return MobileControl;
        })();
        DynamicPages.MobileControl = MobileControl;        
        var EmailControl = (function () {
            function EmailControl(base) {
                this.Control = new ControlAttribute("Email", "Email", "電子信箱");
                this.Base = base;
            }
            EmailControl.prototype.Valid = function () {
                var self = this;
                var b = false;
                var value = self.Control.Value;
                var errmsg = "";
                if(value != "") {
                    if(!value.match(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/)) {
                        errmsg = self.Control.SelectMessage(8, self.Control.Name);
                    } else {
                        $.ajax({
                            type: "POST",
                            async: false,
                            url: "/AppAjaxs/RegisterValidation.ashx",
                            data: {
                                "ResultType": "2",
                                "CheckType": "8",
                                "CheckData": value
                            },
                            success: function (data) {
                                if(data == "Success") {
                                    b = true;
                                } else {
                                    errmsg = data;
                                }
                            },
                            error: function (e) {
                            }
                        });
                    }
                } else {
                    b = true;
                }
                self.Control.ErrorMsg = errmsg;
                self.Control.SetErrorMessage();
                return b;
            };
            EmailControl.prototype.Reset = function () {
                this.Control.Value = "";
                this.Control.ErrorMsg = "";
                this.Control.SetErrorMessage();
            };
            return EmailControl;
        })();
        DynamicPages.EmailControl = EmailControl;        
        var BingoSNControl = (function () {
            function BingoSNControl(base) {
                this.Control = new ControlAttribute("BingoSN", "BingoSN", "推薦人序號");
                this.Base = base;
            }
            BingoSNControl.prototype.Valid = function () {
                var self = this;
                var b = false;
                var value = self.Control.Value;
                var errmsg = "";
                if(value != "") {
                    $.ajax({
                        type: "POST",
                        async: false,
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        data: {
                            "ResultType": "2",
                            "CheckType": "9",
                            "CheckData": value
                        },
                        success: function (data) {
                            if(data != "Success") {
                                errmsg = self.Control.SelectMessage(15, self.Control.Name);
                            } else {
                                b = true;
                            }
                        },
                        error: function (e) {
                        }
                    });
                } else {
                    b = true;
                }
                self.Control.ErrorMsg = errmsg;
                self.Control.SetErrorMessage();
                return b;
            };
            BingoSNControl.prototype.Reset = function () {
                this.Control.Value = "";
                this.Control.ErrorMsg = "";
                this.Control.SetErrorMessage();
            };
            return BingoSNControl;
        })();
        DynamicPages.BingoSNControl = BingoSNControl;        
        var AgreeControl = (function () {
            function AgreeControl(base) {
                this.Control = new ControlAttribute("Agree", "Agree", "同意");
                this.Base = base;
            }
            AgreeControl.prototype.Valid = function () {
                var errmsg = "";
                if(!this.Control.Agree) {
                    errmsg = "須同意服務條款。";
                }
                this.Control.ErrorMsg = errmsg;
                this.Control.SetErrorMessage();
                this.Base.AgreeStatus(this.Control.Agree);
                return this.Control.Agree;
            };
            AgreeControl.prototype.Reset = function () {
                this.Control.Agree = false;
                this.Control.Value = "";
                this.Control.ErrorMsg = "";
                this.Control.SetErrorMessage();
            };
            return AgreeControl;
        })();
        DynamicPages.AgreeControl = AgreeControl;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
