﻿/// <reference path="../Member/MemberRegisterBase.ts" />

declare var ko: any;

module SGT.DynamicPages {

    export class MemberRegister extends MemberRegisterBase {

        constructor() {

            super();

        }

        Page_Initialize(): void {

            this.ControlList["Account"] = new AccountControl(this);
            this.ControlList["Password"] = new PasswordControl(this);
            this.ControlList["ConfirmPassword"] = new ConfirmPasswordControl(this);
            this.ControlList["Email"] = new EmailControl(this);
            this.ControlList["BingoSN"] = new BingoSNControl(this);
            this.ControlList["Agree"] = new AgreeControl(this);
            this.Account = this.ControlList["Account"];
            this.Password = this.ControlList["Password"];
            this.ConfirmPassword = this.ControlList["ConfirmPassword"];
            this.Email = this.ControlList["Email"];
            this.BingoSN = this.ControlList["BingoSN"];
            this.Agree = this.ControlList["Agree"];
        }

        Account: iControlAttribute = ko.observable();

        AccountStatus: (input: bool) => bool = ko.observable();

        Password: iControlAttribute = ko.observable();

        PasswordStatus: (input: bool) => bool = ko.observable();

        ConfirmPassword: iControlAttribute = ko.observable();

        ConfirmPasswordStatus: (input: bool) => bool = ko.observable();

        Email: iControlAttribute = ko.observable();

        EmailStatus: (input: bool) => bool = ko.observable();

        BingoSN: iControlAttribute = ko.observable();

        BingoSNStatus: (input: bool) => bool = ko.observable();

        Agree: iControlAttribute = ko.observable();

        AgreeStatus: (input: bool) => bool = ko.observable();

        Time = 0;

        Reset(): void {

            var passwdBar = document.getElementById('passwdBar');

            if (passwdBar != null) {
                ResetBar();
            }

            $("#Agree").attr("checked", false);
            $("input").val("");
            $("input[type=password]").blur();
            $("#PasswordErrorMsgID").val("");
            $("#ConfirmPasswordErrorMsgID").val("");

            for (var i in this.ControlList) {
                this.ControlList[i].Reset();
            }

            this.AccountStatus(null);
            this.PasswordStatus(null);
            this.ConfirmPasswordStatus(null);
            this.EmailStatus(null);
            this.BingoSNStatus(null);
            this.AgreeStatus(null);

            if (this.Time == 0) {
                this.Time++;
                this.Reset();
            } else {
                this.Time = 0;
                return;
            }
        }

        Valid(key: string): bool {

            var b = this.ControlList[key].Valid();

            switch (key) {
                case "Account": this.AccountStatus(b); break;
                case "Password": this.PasswordStatus(b); break;
                case "ConfirmPassword": this.ConfirmPasswordStatus(b); break;
                case "Email": if (b && this.Email.Control.Value == "") { this.EmailStatus(null); } else { this.EmailStatus(b); } break;
                case "BingoSN": if (b && this.BingoSN.Control.Value == "") { this.BingoSNStatus(null); } else { this.BingoSNStatus(b); } break;
                case "Agree": this.AgreeStatus(b); break;
            }

            return b;
        }

        RunApi(): void {

            var self = this;

            var registerModel = { "MemberAccount": this.Account.Control.Value, "MemberPassword": this.Password.Control.Value, "Email": this.Email.Control.Value, "BingoSN": this.BingoSN.Control.Value };

            $.ajax({
                type: "POST",
                url: "/MVC/api/account/Register",
                async: false,
                data: registerModel,
                dataType: "json",
                success: function (data) {
                    if (data.ResultCode == 0) {
                        self.Login();
                    }
                    else {
                        alert(data.ResultMsg);
                        if (data.ResultCode == 200) {
                            location.href = "/MVC";
                        }
                    }
                },
                error: function (e) {

                },
                complete: function () {

                }
            });
        }
    }
}