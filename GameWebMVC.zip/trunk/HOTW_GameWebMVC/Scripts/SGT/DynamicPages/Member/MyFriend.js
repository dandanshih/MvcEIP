﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var MyFriend = (function () {
            function MyFriend(koName, pageName, pageSize) {
                if (typeof koName === "undefined") { koName = 'MyFriend'; }
                if (typeof pageName === "undefined") { pageName = 'PageParial'; }
                if (typeof pageSize === "undefined") { pageSize = 30; }
                this.PageName = '';
                this.KoName = '';
                this.PageSize = 30;
                this.HasPager = false;
                this.List = ko.observableArray([]);
                this.KoName = koName;
                this.PageName = pageName;
                this.PageSize = pageSize;
                var obj = this;
                if(pageName != '') {
                    SGT["Pages"].PageMgr.Add(this.PageName, new SGT["Pages"].Page(function () {
                        obj.GetDataNoCache();
                    }, pageSize));
                    this.HasPager = true;
                }
            }
            MyFriend.prototype.Query = function () {
                SGT["Pages"].PageMgr.GetInstance(this.PageName).PageIndex(1);
                this.GetDataNoCache();
            };
            MyFriend.prototype.AddFriend = function () {
                this.addMyFriend();
            };
            MyFriend.prototype.GetData = function () {
                var self = this;
                var page = SGT["Pages"].PageMgr.GetInstance(this.PageName);
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                var data = {
                    PageSize: (this.HasPager == false) ? 7 : page.PageSize(),
                    PageIndex: page.PageIndex(),
                    Platform: platform
                };
                $.ajax({
                    type: "POST",
                    url: "/Mvc/api/member/MyFriendNoCache",
                    async: false,
                    dataType: "JSON",
                    data: data,
                    success: function (data) {
                        self.List(data.Result.List);
                        page.TotalRecord(data.Result.RowCount);
                    },
                    error: function (e) {
                    }
                });
            };
            MyFriend.prototype.GetDataNoCache = function () {
                var self = this;
                var page = SGT["Pages"].PageMgr.GetInstance(this.PageName);
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                var data = {
                    PageSize: (this.HasPager == false) ? 7 : page.PageSize(),
                    PageIndex: page.PageIndex(),
                    Platform: platform
                };
                $.ajax({
                    type: "POST",
                    url: "/Mvc/api/member/MyFriendNoCache",
                    async: false,
                    dataType: "JSON",
                    data: data,
                    success: function (data) {
                        self.List(data.Result.List);
                        page.TotalRecord(data.Result.RowCount);
                    },
                    error: function (e) {
                    }
                });
            };
            MyFriend.prototype.addMyFriend = function () {
                var self = this;
                var Result = 0;
                var friendNickName = $('#MyFriendID_text').val();
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                if(friendNickName != '') {
                    var data = {
                        Result: Result,
                        FriendNickName: friendNickName,
                        Platform: platform
                    };
                    $.ajax({
                        type: "Post",
                        url: "/Mvc/api/member/AddMyFriend",
                        data: data,
                        success: function (data) {
                            Result = data.result;
                            if(Result == 0) {
                                self.GetDataNoCache();
                                alert('新增好友成功!!');
                            } else if(Result == 1) {
                                alert('好友暱稱不存在!!');
                            } else if(Result == 2) {
                                alert('已存在好友名單!!');
                            } else if(Result == 3) {
                                alert('好友已達上限，無法再新增!!');
                            }
                        },
                        error: function (e) {
                        }
                    });
                } else {
                    alert('請輸入好友暱稱!!');
                }
            };
            MyFriend.prototype.deleteMyFriend = function (friendNickName) {
                if(!confirm('確定刪除好友？')) {
                    return;
                }
                var self = this;
                var Result = 0;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                var data = {
                    Result: Result,
                    FriendNickName: friendNickName,
                    Platform: platform
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/DeleteMyFriend",
                    data: data,
                    success: function (data) {
                        Result = data.result;
                        if(Result == 0) {
                            self.GetDataNoCache();
                            alert('刪除好友成功!!');
                        } else if(Result == 1) {
                            alert('好友暱稱不存在!!');
                        } else if(Result == 2) {
                            alert('不存在好友名單!!');
                        }
                    },
                    error: function (e) {
                    }
                });
            };
            return MyFriend;
        })();
        DynamicPages.MyFriend = MyFriend;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
