var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var GameRecord = (function () {
            function GameRecord() {
                this.CurrentPoint = ko.observable('0.00');
                this.ShowData = ko.observable(true);
                this.QueryData = ko.observableArray([
                    {
                        No: 1,
                        GameName: '�j�ѤG',
                        WinLose: '100',
                        GameID: 1001
                    }
                ]);
            }
            GameRecord.prototype.PopDetail = function () {
                var items = this;
                var myWindow = window.open('GameDetail.aspx?gameid=' + items['GameID'] + '&begindate={1}&enddate={2}&MemberIdentity=2', '�C������', 'width=620,height=450,scrollbars=yes,left=250,top=200');
                myWindow.focus();
            };
            GameRecord.prototype.Query = function () {
            };
            return GameRecord;
        })();
        DynamicPages.GameRecord = GameRecord;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;

})(SGT || (SGT = {}));

