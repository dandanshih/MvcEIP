var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var ForgetPassword = (function () {
            function ForgetPassword() {
                this.QueryType = ko.observable(1);
                this.SentType = ko.observable(1);
                this.InquiryAccount = ko.observable('');
                this.InquiryMobile = ko.observable('');
                this.VerifyCode = ko.observable('');
                this.ServiceTel = ko.observable('');
                this.ServiceFax = ko.observable('');
                this.VerifyCodeSrc = ko.observable('');
                this.SubmitBtnEnable = ko.observable(true);
                this.ViewEnable_Enter = ko.observable(true);
                this.ViewEnable_Finsh = ko.observable(false);
                this.ChangeVerifyCode();
            }
            ForgetPassword.prototype.ChangeVerifyCode = function () {
                this.VerifyCodeSrc('/MVC/Verify/GetVerifyCode?' + Math.random());
            };
            ForgetPassword.prototype.Clear = function () {
                this.SubmitBtnEnable(true);
                this.ViewEnable_Enter(true);
                this.ViewEnable_Finsh(false);
                this.QueryType(1);
                this.SentType(1);
                this.InquiryAccount('');
                this.InquiryMobile('');
                this.VerifyCode('');
            };
            ForgetPassword.prototype.ToEnterView = function () {
                this.ViewEnable_Enter(true);
                this.ViewEnable_Finsh(false);
            };
            ForgetPassword.prototype.ToFinshView = function () {
                this.ViewEnable_Enter(false);
                this.ViewEnable_Finsh(true);
            };
            ForgetPassword.prototype.Submit = function () {
                var obj = this;
                obj.SubmitBtnEnable(false);
                var data = {
                    QueryType: obj.QueryType(),
                    SentType: obj.SentType(),
                    InquiryAccount: obj.InquiryAccount(),
                    InquiryMobile: obj.InquiryMobile(),
                    VerifyCode: obj.VerifyCode()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/forgetPassword",
                    data: data,
                    success: function (data) {
                        obj.SubmitBtnEnable(true);
                        if(data.Code != 0) {
                            alert(data.Message);
                        } else {
                            obj.Clear();
                            obj.ServiceTel(data.CSTel);
                            obj.ServiceFax(data.CSFax);
                            obj.ToFinshView();
                        }
                    },
                    error: function (e) {
                        obj.SubmitBtnEnable(true);
                    }
                });
                this.ChangeVerifyCode();
            };
            return ForgetPassword;
        })();
        DynamicPages.ForgetPassword = ForgetPassword;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;

})(SGT || (SGT = {}));

