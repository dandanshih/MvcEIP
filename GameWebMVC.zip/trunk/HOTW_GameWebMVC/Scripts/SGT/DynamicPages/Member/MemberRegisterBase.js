﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var MemberRegisterBase = (function () {
            function MemberRegisterBase() {
                this.ControlList = {
                };
            }
            MemberRegisterBase.prototype.Add = function (key, value) {
                this.ControlList[key] = value;
            };
            MemberRegisterBase.prototype.Remove = function (key) {
                delete this.ControlList[key];
            };
            MemberRegisterBase.prototype.Valid = function (key) {
                throw "請實作Valid Method";
            };
            MemberRegisterBase.prototype.ValidAll = function () {
                for(var i in this.ControlList) {
                    if(!this.ControlList[i].Valid()) {
                        return this.ControlList[i].Valid();
                    }
                }
                return true;
            };
            MemberRegisterBase.prototype.Reset = function () {
                throw "請實作Reset Method";
            };
            MemberRegisterBase.prototype.Register = function () {
                if(this.ValidAll()) {
                    this.RunApi();
                }
            };
            MemberRegisterBase.prototype.RunApi = function () {
                throw "請實作RunApi Method";
            };
            MemberRegisterBase.prototype.Login = function () {
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/account/AutoLogin",
                    async: false,
                    data: "",
                    dataType: "json",
                    success: function (data) {
                        if(data.ResultCode == 1) {
                            if(opener != null && typeof opener.window != 'unknown' && typeof opener != undefined) {
                                opener.window.location.reload();
                            }
                            location.href = "/Web/Game/MiniList.aspx";
                        } else if(data.ResultCode == 98) {
                            alert("登入資訊不正確。");
                        } else if(data.ResultCode == 99 || data.ResultCode == 12) {
                            alert("遊戲目前進行維護中，請稍後再來玩！");
                            window.close();
                        } else {
                            alert(data.ResultMsg);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            return MemberRegisterBase;
        })();
        DynamicPages.MemberRegisterBase = MemberRegisterBase;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
