var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var GiftCenter = (function () {
            function GiftCenter(koName, pageName) {
                if (typeof koName === "undefined") { koName = 'GiftCenter'; }
                if (typeof pageName === "undefined") { pageName = 'PageParial'; }
                this.KoName = '';
                this.PageName = '';
                this.MyExchangeID = '';
                this.MyCityID = 0;
                this.MyZoneID = '';
                this.MyAddress = '';
                this.MyRealName = '';
                this.MyPhone = '';
                this.MyEmail = '';
                this.DefaultCity = {
                    CityID: 0,
                    CityName: $SGT.Message.GiftCenter.Utility[2],
                    ZoneList: []
                };
                this.DefaultZone = {
                    ZipCode: '',
                    ZoneID: '',
                    ZoneName: $SGT.Message.GiftCenter.Utility[3]
                };
                this.ViewEnable = ko.observable(true);
                this.ViewEnable_List = ko.observable(false);
                this.ViewEnable_Enter = ko.observable(false);
                this.ViewEnable_Confirm = ko.observable(false);
                this.ViewEnable_Finsh = ko.observable(false);
                this.List = ko.observableArray([]);
                this.FBCoin = ko.observable(0.0);
                this.FBCoinMaxChange = ko.observable(0.0);
                this.FBCoinExchange = ko.observable(0);
                this.CityList = ko.observableArray([]);
                this.ZoneList = ko.observableArray([]);
                this.RealName = ko.observable('');
                this.CityID = ko.observable(0);
                this.ZoneID = ko.observable('0');
                this.Address = ko.observable('');
                this.Phone = ko.observable('');
                this.Email = ko.observable('');
                this.RealNameErrorMessage = ko.observable('');
                this.AddressErrorMessage = ko.observable('');
                this.PhoneErrorMessage = ko.observable('');
                this.EmailErrorMessage = ko.observable('');
                this.FullpnoAddress = ko.observable('');
                this.KoName = koName;
                this.PageName = pageName;
                var self = this;
                SGT.Pages.PageMgr.Add(this.PageName, new SGT.Pages.Page(function () {
                    self.GetGiftReport();
                }));
                this.GetDefaultData();
            }
            GiftCenter.prototype.GetGiftReport = function (callback) {
                if (typeof callback === "undefined") { callback = null; }
                var self = this;
                var page = SGT.Pages.PageMgr.GetInstance(this.PageName);
                var data = {
                    PageSize: page.PageSize(),
                    PageIndex: page.PageIndex()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/giftcenter",
                    data: data,
                    success: function (data) {
                        SGT['Main'].QueryFns[self.KoName].List(data.List);
                        page.TotalRecord(data.TotalRecord);
                        self.FBCoin(data.FBCoin);
                        self.FBCoinMaxChange(data.FBCoinMaxChange);
                        self.FBCoinExchange(data.FBCoinExchange);
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                        if(callback) {
                            callback();
                        }
                    }
                });
            };
            GiftCenter.prototype.GetDefaultData = function () {
                var self = this;
                this.CityList.unshift(this.DefaultCity);
                this.ZoneList.unshift(this.DefaultZone);
                $.ajax({
                    type: "Get",
                    url: "/Mvc/api/other/CityData",
                    success: function (data) {
                        self.CityList(data);
                        self.CityList.unshift(self.DefaultCity);
                    },
                    error: function (e) {
                    }
                });
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/getchangememberdetail",
                    success: function (data) {
                        self.MyCityID = data.CityID;
                        self.MyZoneID = data.ZoneID;
                        self.MyAddress = data.Address;
                        self.MyRealName = data.RealName;
                        self.MyPhone = data.Phone;
                        self.MyEmail = data.Email;
                    },
                    error: function (e) {
                    }
                });
            };
            GiftCenter.prototype.ToListView = function () {
                var self = this;
                this.ViewEnable(false);
                SGT.Pages.PageMgr.GetInstance(this.PageName).PageIndex(1);
                this.GetGiftReport(function () {
                    window.location.hash = "top";
                    self.ViewEnable_List(true);
                    self.ViewEnable_Enter(false);
                    self.ViewEnable_Confirm(false);
                    self.ViewEnable_Finsh(false);
                    self.ViewEnable(true);
                });
            };
            GiftCenter.prototype.ChangeFBCoin = function () {
                var self = this;
                if(self.FBCoinMaxChange() <= 0) {
                    alert($SGT.Message.GiftCenter.Utility[0].format(self.FBCoinExchange()));
                    return;
                }
                this.ViewEnable(false);
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/changefbcoin",
                    success: function (data) {
                        if(data.Message) {
                            alert(data.Message);
                        }
                        self.GetGiftReport();
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                        self.ViewEnable(true);
                    }
                });
            };
            GiftCenter.prototype.ChangeHCoin = function (row) {
                if(!confirm($SGT.Message.GiftCenter.Utility[1])) {
                    return;
                }
                this.ViewEnable(false);
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/changehcoin",
                    data: {
                        ExchangeID: row['ExchangeID']
                    },
                    success: function (data) {
                        if(data.Message) {
                            alert(data.Message);
                        }
                        if(data.Code == 0) {
                            self.GetGiftReport();
                        }
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                        self.ViewEnable(true);
                    }
                });
            };
            GiftCenter.prototype.ToEnterView = function (row) {
                this.MyExchangeID = row['ExchangeID'];
                this.RealName(this.MyRealName);
                this.Phone(this.MyPhone);
                this.Email(this.MyEmail);
                this.CityID(this.MyCityID);
                this.ZoneID(this.MyZoneID);
                this.Address(this.MyAddress);
                window.location.hash = "top";
                this.ViewEnable_List(false);
                this.ViewEnable_Enter(true);
                this.ViewEnable_Confirm(false);
                this.ViewEnable_Finsh(false);
            };
            GiftCenter.prototype.BackEnterView = function () {
                window.location.hash = "top";
                this.ViewEnable_List(false);
                this.ViewEnable_Enter(true);
                this.ViewEnable_Confirm(false);
                this.ViewEnable_Finsh(false);
            };
            GiftCenter.prototype.SetZoneList = function () {
                var self = this;
                var cityId = this.CityID();
                $.each(this.CityList(), function (index, obj) {
                    if(obj.CityID == cityId) {
                        self.ZoneList(obj.ZoneList);
                        self.ZoneList.unshift(self.DefaultZone);
                        return false;
                    }
                });
            };
            GiftCenter.prototype.ClearEnter = function () {
                this.RealName('');
                this.CityID(0);
                this.ZoneID('');
                this.Address('');
                this.Phone('');
                this.Email('');
            };
            GiftCenter.prototype.ValidRealName = function () {
                this.RealNameErrorMessage('');
                if($.trim(this.RealName()) == '') {
                    this.RealNameErrorMessage($SGT.Message.GiftCenter.Error[0]);
                    return false;
                }
                return true;
            };
            GiftCenter.prototype.ValidAddress = function () {
                this.AddressErrorMessage('');
                if(this.ZoneID() == '') {
                    this.AddressErrorMessage($SGT.Message.GiftCenter.Error[2]);
                    return false;
                }
                if($.trim(this.Address()) == '') {
                    this.AddressErrorMessage($SGT.Message.GiftCenter.Error[3]);
                    return false;
                }
                if(!/^[\u0391-\uFFE5a-zA-Z0-9\-]{1,40}$/.test(this.Address())) {
                    this.AddressErrorMessage($SGT.Message.GiftCenter.Error[4]);
                    return false;
                }
                return true;
            };
            GiftCenter.prototype.ValidPhone = function () {
                this.PhoneErrorMessage('');
                if(this.Phone() && !/^[0-9]{0,20}$/.test(this.Phone())) {
                    this.PhoneErrorMessage($SGT.Message.GiftCenter.Error[5]);
                    return false;
                }
                return true;
            };
            GiftCenter.prototype.ValidEmail = function () {
                this.EmailErrorMessage('');
                if($.trim(this.Email()) == '') {
                    this.EmailErrorMessage($SGT.Message.GiftCenter.Error[6]);
                    return false;
                } else if(!/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(this.Email())) {
                    this.EmailErrorMessage($SGT.Message.GiftCenter.Error[7]);
                    return false;
                }
                return true;
            };
            GiftCenter.prototype.ToConfirmView = function () {
                this.ViewEnable(false);
                var successCount = 0;
                successCount += this.ValidRealName() ? 1 : 0;
                successCount += this.ValidAddress() ? 1 : 0;
                successCount += this.ValidPhone() ? 1 : 0;
                successCount += this.ValidEmail() ? 1 : 0;
                if(successCount == 4) {
                    var self = this;
                    var cityId = this.CityID();
                    var cityName = '';
                    if(cityId != 0) {
                        $.each(this.CityList(), function (index, obj) {
                            if(obj.CityID == cityId) {
                                cityName = obj.CityName;
                                return false;
                            }
                        });
                    }
                    var zoneId = this.ZoneID();
                    var zoneName = '';
                    if(zoneName != '') {
                        $.each(this.ZoneList(), function (index, obj) {
                            if(obj.ZoneID == zoneId) {
                                zoneName = obj.ZoneName;
                                return false;
                            }
                        });
                    }
                    this.FullpnoAddress(cityName + zoneName + this.Address());
                    window.location.hash = "top";
                    this.ViewEnable_List(false);
                    this.ViewEnable_Enter(false);
                    this.ViewEnable_Confirm(true);
                    this.ViewEnable_Finsh(false);
                }
                this.ViewEnable(true);
            };
            GiftCenter.prototype.ToFinshView = function () {
                window.location.hash = "top";
                this.ViewEnable(false);
                var self = this;
                var data = {
                    ExchangeID: this.MyExchangeID,
                    ZoneID: this.ZoneID(),
                    Address: this.Address(),
                    RealName: this.RealName(),
                    Phone: this.Phone(),
                    Email: this.Email()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/member/changeentitygift",
                    data: data,
                    success: function (data) {
                        if(data.Message) {
                            alert(data.Message);
                        }
                        if(data.Code == 0) {
                            window.location.hash = "top";
                            self.ViewEnable_List(false);
                            self.ViewEnable_Enter(false);
                            self.ViewEnable_Confirm(false);
                            self.ViewEnable_Finsh(true);
                        } else {
                            self.ToListView();
                        }
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                        self.ViewEnable(true);
                    }
                });
            };
            return GiftCenter;
        })();
        DynamicPages.GiftCenter = GiftCenter;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
