var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var MemberRegister = (function (_super) {
            __extends(MemberRegister, _super);
            function MemberRegister() {
                        _super.call(this);
                this.Account = ko.observable();
                this.AccountStatus = ko.observable();
                this.Password = ko.observable();
                this.PasswordStatus = ko.observable();
                this.ConfirmPassword = ko.observable();
                this.ConfirmPasswordStatus = ko.observable();
                this.Email = ko.observable();
                this.EmailStatus = ko.observable();
                this.BingoSN = ko.observable();
                this.BingoSNStatus = ko.observable();
                this.Agree = ko.observable();
                this.AgreeStatus = ko.observable();
                this.Time = 0;
            }
            MemberRegister.prototype.Page_Initialize = function () {
                this.ControlList["Account"] = new DynamicPages.AccountControl(this);
                this.ControlList["Password"] = new DynamicPages.PasswordControl(this);
                this.ControlList["ConfirmPassword"] = new DynamicPages.ConfirmPasswordControl(this);
                this.ControlList["Email"] = new DynamicPages.EmailControl(this);
                this.ControlList["BingoSN"] = new DynamicPages.BingoSNControl(this);
                this.ControlList["Agree"] = new DynamicPages.AgreeControl(this);
                this.Account = this.ControlList["Account"];
                this.Password = this.ControlList["Password"];
                this.ConfirmPassword = this.ControlList["ConfirmPassword"];
                this.Email = this.ControlList["Email"];
                this.BingoSN = this.ControlList["BingoSN"];
                this.Agree = this.ControlList["Agree"];
            };
            MemberRegister.prototype.Reset = function () {
                var passwdBar = document.getElementById('passwdBar');
                if(passwdBar != null) {
                    ResetBar();
                }
                $("#Agree").attr("checked", false);
                $("input").val("");
                $("input[type=password]").blur();
                $("#PasswordErrorMsgID").val("");
                $("#ConfirmPasswordErrorMsgID").val("");
                for(var i in this.ControlList) {
                    this.ControlList[i].Reset();
                }
                this.AccountStatus(null);
                this.PasswordStatus(null);
                this.ConfirmPasswordStatus(null);
                this.EmailStatus(null);
                this.BingoSNStatus(null);
                this.AgreeStatus(null);
                if(this.Time == 0) {
                    this.Time++;
                    this.Reset();
                } else {
                    this.Time = 0;
                    return;
                }
            };
            MemberRegister.prototype.Valid = function (key) {
                var b = this.ControlList[key].Valid();
                switch(key) {
                    case "Account":
                        this.AccountStatus(b);
                        break;
                    case "Password":
                        this.PasswordStatus(b);
                        break;
                    case "ConfirmPassword":
                        this.ConfirmPasswordStatus(b);
                        break;
                    case "Email":
                        if(b && this.Email.Control.Value == "") {
                            this.EmailStatus(null);
                        } else {
                            this.EmailStatus(b);
                        }
                        break;
                    case "BingoSN":
                        if(b && this.BingoSN.Control.Value == "") {
                            this.BingoSNStatus(null);
                        } else {
                            this.BingoSNStatus(b);
                        }
                        break;
                    case "Agree":
                        this.AgreeStatus(b);
                        break;
                }
                return b;
            };
            MemberRegister.prototype.RunApi = function () {
                var self = this;
                var registerModel = {
                    "MemberAccount": this.Account.Control.Value,
                    "MemberPassword": this.Password.Control.Value,
                    "Email": this.Email.Control.Value,
                    "BingoSN": this.BingoSN.Control.Value
                };
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/account/Register",
                    async: false,
                    data: registerModel,
                    dataType: "json",
                    success: function (data) {
                        if(data.ResultCode == 0) {
                            self.Login();
                        } else {
                            alert(data.ResultMsg);
                            if(data.ResultCode == 200) {
                                location.href = "/MVC";
                            }
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            return MemberRegister;
        })(DynamicPages.MemberRegisterBase);
        DynamicPages.MemberRegister = MemberRegister;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
