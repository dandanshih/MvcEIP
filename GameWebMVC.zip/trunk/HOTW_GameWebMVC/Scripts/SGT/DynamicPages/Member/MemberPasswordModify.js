﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Base_Struct_MemberPasswordModify = (function () {
            function Base_Struct_MemberPasswordModify() {
                this.MemberID = 0;
                this.RsaMemberID = "";
                this.MemberAccount = "";
                this.MemberPassword = "";
                this.RsaMemberPassword = "";
            }
            return Base_Struct_MemberPasswordModify;
        })();
        DynamicPages.Base_Struct_MemberPasswordModify = Base_Struct_MemberPasswordModify;

        var MemberPasswordModify = (function () {
            function MemberPasswordModify() {
                this.MemberID = ko.observable("");
                this.RsaMemberID = ko.observable("");
                this.MemberAccount = ko.observable("");
                this.MemberPasswordOld = ko.observable("");
                this.MemberPasswordNew = ko.observable("");
                this.MemberPasswordC = ko.observable("");
                this.MemberPasswordMsg1 = ko.observable("");
                this.MemberPasswordMsg2 = ko.observable("");
                this.MemberPasswordMsg3 = ko.observable("");
                this.IsShowPasswordOK1 = ko.observable(0);
                this.IsShowPasswordOK2 = ko.observable(0);
                this.IsShowPasswordOK3 = ko.observable(0);
                this.Mobile = ko.observable("");
                this.SubmitEnable = ko.observable(true);
            }
            MemberPasswordModify.prototype.PageInit = function () {
                var self = this;
                var platform = "Web";
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/MemberMobileGroupInfo",
                    data: { Platform: platform },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if (data != null) {
                            self.Mobile(data.result.Mobile);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };

            MemberPasswordModify.prototype.EditMemberPassword = function () {
                var self = this;
                self.SubmitEnable(false);
                var platform = "Web";
                if (typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                if (self.PasswordValidate1() && self.PasswordValidate2() && self.PasswordValidate3()) {
                    $.ajax({
                        type: "POST",
                        url: "/Mvc/Api/Member/MemberPasswordModify",
                        data: { Platform: platform, oldPwd: RsaEncrypt(self.MemberPasswordOld()), Pwd: RsaEncrypt(self.MemberPasswordNew()) },
                        async: false,
                        dataType: "json",
                        success: function (data) {
                            if (data != null && data.ResultCode == 1) {
                                $.ajax({
                                    type: "POST",
                                    url: "/MVC/api/account/ClearFlag",
                                    async: true,
                                    data: { "flag": 16384 },
                                    dataType: "json",
                                    success: function (data) {
                                        alert('密碼修改成功，祝您遊戲愉快！');
                                        parent["SGT"].Global.PopIframeMgr.Remove('ChangePassword');
                                        self.SubmitEnable(true);
                                    },
                                    error: function (e) {
                                        self.SubmitEnable(true);
                                    }
                                });
                            } else {
                                self.SubmitEnable(true);
                                alert(data.ResultMessage);
                            }
                        },
                        error: function (e) {
                            self.SubmitEnable(true);
                        },
                        complete: function () {
                        }
                    });
                }
            };

            MemberPasswordModify.prototype.PasswordValidate1 = function () {
                var self = this;
                if ($.trim(self.MemberPasswordOld()) == "") {
                    self.MemberPasswordMsg1("密碼不可空白");
                    self.IsShowPasswordOK1(2);
                    return false;
                } else if (!(/^[0-9a-zA-Z]{6,12}$/.test(self.MemberPasswordOld()))) {
                    self.MemberPasswordMsg1("密碼必須是 6 ~ 12 碼的英文數字組合。");
                    self.IsShowPasswordOK1(2);
                    return false;
                } else if ((/^[0-9]{6,12}$/.test(self.MemberPasswordOld()))) {
                    self.MemberPasswordMsg1("密碼至少須包含一個英文字母。");
                    self.IsShowPasswordOK1(2);
                    return false;
                } else if ((self.MemberPasswordOld().indexOf(self.MemberAccount()) > -1 && self.MemberAccount() != "")) {
                    self.MemberPasswordMsg1("密碼中不可包含帳號。");
                    self.IsShowPasswordOK1(2);
                    return false;
                }
                var b = true;

                var CompareString = '';
                for (var i = 0; i < self.MemberPasswordOld().length; i++) {
                    if (CompareString.indexOf(self.MemberPasswordOld().charAt(i)) == -1) {
                        CompareString += self.MemberPasswordOld().charAt(i);
                    }
                }
                if (CompareString.length < 4) {
                    self.MemberPasswordMsg1("密碼必須包含4種(含)字元以上。");
                    self.IsShowPasswordOK1(2);
                    b = false;
                    return b;
                } else {
                    var sPW = self.MemberPasswordOld().toLowerCase();
                    for (i = 0; i < sPW.length; i++) {
                        var code = sPW.charCodeAt(i);
                        var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
                        var code2 = '' + code + (code + 1) + (code + 2);
                        var code3 = '' + code + (code - 1) + (code - 2);
                        if (sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                            self.MemberPasswordMsg1("密碼不可為連續數字或字母。");
                            self.IsShowPasswordOK1(2);
                            b = false;
                            return b;
                        }
                    }
                }
                if (b == true) {
                    self.MemberPasswordMsg1("");
                    self.IsShowPasswordOK1(1);
                }
                return b;
            };

            MemberPasswordModify.prototype.PasswordValidate2 = function () {
                var self = this;
                var passwdBar = document.getElementById('passwdBar');
                if (passwdBar != null) {
                    ResetBar();
                }
                if ($.trim(self.MemberPasswordNew()) == "") {
                    self.MemberPasswordMsg2("密碼不可空白");
                    self.IsShowPasswordOK2(2);
                    return false;
                } else if ($.trim(self.MemberPasswordNew()) == $.trim(self.MemberPasswordOld())) {
                    self.MemberPasswordMsg2("新密碼不可與舊密碼相同");
                    self.IsShowPasswordOK2(2);
                    return false;
                } else if (!(/^[0-9a-zA-Z]{6,12}$/.test(self.MemberPasswordNew()))) {
                    self.MemberPasswordMsg2("密碼必須是 6 ~ 12 碼的英文數字組合。");
                    self.IsShowPasswordOK2(2);
                    return false;
                } else if ((/^[0-9]{6,12}$/.test(self.MemberPasswordNew()))) {
                    self.MemberPasswordMsg2("密碼至少須包含一個英文字母。");
                    self.IsShowPasswordOK2(2);
                    return false;
                } else if ((self.MemberPasswordNew().indexOf(self.MemberAccount()) > -1 && self.MemberAccount() != "") || (self.MemberPasswordNew().indexOf(self.Mobile()) > -1 && self.Mobile() != "")) {
                    self.MemberPasswordMsg2("密碼中不可包含帳號或手機號碼。");
                    self.IsShowPasswordOK2(2);
                    return false;
                }
                var b = true;

                var CompareString = '';
                for (var i = 0; i < self.MemberPasswordNew().length; i++) {
                    if (CompareString.indexOf(self.MemberPasswordNew().charAt(i)) == -1) {
                        CompareString += self.MemberPasswordNew().charAt(i);
                    }
                }
                if (CompareString.length < 4) {
                    self.MemberPasswordMsg2("密碼必須包含4種(含)字元以上。");
                    self.IsShowPasswordOK2(2);
                    b = false;
                    return b;
                } else {
                    var sPW = self.MemberPasswordNew().toLowerCase();
                    for (i = 0; i < sPW.length; i++) {
                        var code = sPW.charCodeAt(i);
                        var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
                        var code2 = '' + code + (code + 1) + (code + 2);
                        var code3 = '' + code + (code - 1) + (code - 2);
                        if (sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                            self.MemberPasswordMsg2("密碼不可為連續數字或字母。");
                            self.IsShowPasswordOK2(2);
                            b = false;
                            return b;
                        }
                    }
                }
                if (passwdBar != null && b == true) {
                    var ctl = document.getElementById("password");
                    CreateRatePasswdReq(ctl);
                }
                if (b == true) {
                    self.MemberPasswordMsg2("");
                    self.IsShowPasswordOK2(1);
                }
                return b;
            };

            MemberPasswordModify.prototype.PasswordValidate3 = function () {
                var self = this;
                if ($.trim(self.MemberPasswordC()) == "") {
                    self.MemberPasswordMsg3("確認新密碼不可空白");
                    self.IsShowPasswordOK3(2);
                    return false;
                } else if (self.MemberPasswordC() != self.MemberPasswordNew()) {
                    self.MemberPasswordMsg3("兩次新密碼錯誤");
                    self.IsShowPasswordOK3(2);
                    return false;
                } else if (self.MemberPasswordC() == self.MemberPasswordOld()) {
                    self.MemberPasswordMsg3("新密碼不可與舊密碼相同");
                    self.IsShowPasswordOK3(2);
                    return false;
                } else {
                    self.MemberPasswordMsg3("");
                    self.IsShowPasswordOK3(1);
                    return true;
                }
            };

            MemberPasswordModify.prototype.SelectMessage = function (input) {
                var msg = "";
                switch (input) {
                    case 1:
                        msg = "成功。";
                        break;
                    case 3:
                        msg = "此會員新增/合併帳號功能被停權。";
                        break;
                    case 4:
                        msg = "帳號停用中。";
                        break;
                    case 5:
                        msg = "已經通過手機驗證，無法被綁定。";
                        break;
                    case 6:
                        msg = "可加入帳號額度已滿。";
                        break;
                    case 7:
                        msg = "此帳號無法進行新增/合併帳號功能，請使用老子帳號，或聯絡客服。";
                        break;
                    case 8:
                        msg = "該帳號目前在線上，無法併入。";
                        break;
                    case 9:
                        msg = "目前本功能無法使用，如有疑問請洽客服。";
                        break;
                    case 10:
                        msg = "限普卡以上。";
                        break;
                    case 11:
                        msg = "手機驗證未通過，無法綁定帳號。";
                        break;
                    case 21:
                        msg = "主帳號不存在。";
                        break;
                    case 22:
                        msg = "主帳號未通過手機驗證。";
                        break;
                    case 23:
                        msg = "被合併的帳號不存在。";
                        break;
                    case 24:
                        msg = "被合併的帳號已經是主帳號或子帳號。";
                        break;
                    case 25:
                        msg = "不能合併自己。";
                        break;
                    case 31:
                        msg = "帳號不存在。";
                        break;
                    case 32:
                        msg = "密碼錯誤。";
                        break;
                    case 99:
                        msg = "新增/合併帳號失敗。";
                        break;
                }
                return msg;
            };
            return MemberPasswordModify;
        })();
        DynamicPages.MemberPasswordModify = MemberPasswordModify;
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
