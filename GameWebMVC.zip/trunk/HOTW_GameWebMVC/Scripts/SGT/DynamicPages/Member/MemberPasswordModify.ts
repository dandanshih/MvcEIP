﻿declare var $;
declare var ko;
declare var RsaEncrypt;
declare var ResetBar;
declare var CreateRatePasswdReq;
declare var GetPlatform;

//命名空間
module SGT.DynamicPages {

    //帳號設定明細檔
    export class Base_Struct_MemberPasswordModify {
        // 會員編號(回傳時永遠都是0)
        MemberID: number = 0;
        // 會員編號(回傳時已經加密過)
        RsaMemberID: string = "";
        // 會員帳號
        MemberAccount: string = "";
        // 會員密碼
        MemberPassword: string = "";
        // 會員密碼(回傳時已經加密過)
        RsaMemberPassword: string = "";
    }

    //帳號設定(資料繫結)
    export class MemberPasswordModify {
        // 會員編號(回傳時永遠都是0)
        MemberID: (input?: string) => string = ko.observable("");
        // 會員編號(回傳時已經加密過)
        RsaMemberID: (input?: string) => string = ko.observable("");
        // 會員帳號
        MemberAccount: (input?: string) => string = ko.observable("");
        // 舊會員密碼
        MemberPasswordOld: (input?: string) => string = ko.observable("");
        // 新會員密碼
        MemberPasswordNew: (input?: string) => string = ko.observable("");
        // 新會員確認密碼
        MemberPasswordC: (input?: string) => string = ko.observable("");
        // 舊密碼回傳錯誤訊息用
        MemberPasswordMsg1: (input?: string) => string = ko.observable("");
        // 新密碼回傳錯誤訊息用
        MemberPasswordMsg2: (input?: string) => string = ko.observable("");
        // 確認密碼回傳錯誤訊息用
        MemberPasswordMsg3: (input?: string) => string = ko.observable("");
        // 是否顯示舊密碼右邊小圖片 0:都不顯示/1:顯示OK圖片/2:顯示錯誤圖片
        IsShowPasswordOK1: (input?: number) => number = ko.observable(0);
        // 是否顯示新密碼右邊小圖片 0:都不顯示/1:顯示OK圖片/2:顯示錯誤圖片
        IsShowPasswordOK2: (input?: number) => number = ko.observable(0);
        // 是否顯示確認密碼右邊小圖片 0:都不顯示/1:顯示OK圖片/2:顯示錯誤圖片
        IsShowPasswordOK3: (input?: number) => number = ko.observable(0);
        // 會員手機號碼
        Mobile: (input?: string) => string = ko.observable("");

        SubmitEnable: (input?: boolean) => boolean = ko.observable(true);

        //頁面初始化
        public PageInit(): void {
            var self = this;
            var platform = "Web";
            $.ajax({
                type: "POST",
                url: "/MVC/api/Member/MemberMobileGroupInfo",
                data: { Platform: platform },
                async: false,
                dataType: "json",
                success: function (data) {
                    if (data != null) {
                        self.Mobile(data.result.Mobile);
                    }
                },
                error: function (e) {
                },
                complete: function () {
                }
            });
        }

        public EditMemberPassword(): void {
            var self = this;
            self.SubmitEnable(false);
            var platform = "Web";
            if (typeof GetPlatform == 'function') {
                platform = GetPlatform();
            }
            if (self.PasswordValidate1() && self.PasswordValidate2() && self.PasswordValidate3()) {
                $.ajax({
                    type: "POST",
                    url: "/Mvc/Api/Member/MemberPasswordModify",
                    data: { Platform: platform, oldPwd: RsaEncrypt(self.MemberPasswordOld()), Pwd: RsaEncrypt(self.MemberPasswordNew()) },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if (data != null && data.ResultCode == 1) {
                            $.ajax({
                                type: "POST",
                                url: "/MVC/api/account/ClearFlag",
                                async: true,
                                data: { "flag": 16384 },
                                dataType: "json",
                                success: function (data) {
                                    //parent["SGT"]["Member"].Activity = new SGT["Member"].FnActivity();

                                    //parent["SGT"]["Member"].Activity.Init(data["WebLoginEventFlag"]);
                                    alert('密碼修改成功，祝您遊戲愉快！');
                                    parent["SGT"].Global.PopIframeMgr.Remove('ChangePassword');
                                    self.SubmitEnable(true);
                                },
                                error: function (e) {
                                    self.SubmitEnable(true);
                                }
                            });

                        } else {
                            self.SubmitEnable(true);
                            alert(data.ResultMessage);
                        }
                    },
                    error: function (e) {
                        self.SubmitEnable(true);
                    },
                    complete: function () {
                    }
                });
            }
        }

        //驗證舊密碼
        public PasswordValidate1(): bool {
            var self = this;
            if ($.trim(self.MemberPasswordOld()) == "") {
                self.MemberPasswordMsg1("密碼不可空白");
                self.IsShowPasswordOK1(2);
                return false;
            } else if (!(/^[0-9a-zA-Z]{6,12}$/.test(self.MemberPasswordOld()))) {
                self.MemberPasswordMsg1("密碼必須是 6 ~ 12 碼的英文數字組合。");
                self.IsShowPasswordOK1(2);
                return false;
            } else if ((/^[0-9]{6,12}$/.test(self.MemberPasswordOld()))) {
                self.MemberPasswordMsg1("密碼至少須包含一個英文字母。");
                self.IsShowPasswordOK1(2);
                return false;
            } else if ((self.MemberPasswordOld().indexOf(self.MemberAccount()) > -1 && self.MemberAccount() != "")) {
                self.MemberPasswordMsg1("密碼中不可包含帳號。");
                self.IsShowPasswordOK1(2);
                return false;
            }
            var b = true;
            // 驗證密碼是否含四種不同字元以上
            var CompareString = '';
            for (var i = 0; i < self.MemberPasswordOld().length; i++) {
                if (CompareString.indexOf(self.MemberPasswordOld().charAt(i)) == -1) {
                    CompareString += self.MemberPasswordOld().charAt(i);
                }
            }
            if (CompareString.length < 4) {
                self.MemberPasswordMsg1("密碼必須包含4種(含)字元以上。");
                self.IsShowPasswordOK1(2);
                b = false;
                return b;
            } else {
                var sPW = self.MemberPasswordOld().toLowerCase();
                for (i = 0; i < sPW.length; i++) {
                    // 判斷是否輸入3個連續數字或字母
                    var code = sPW.charCodeAt(i);
                    var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
                    var code2 = '' + code + (code + 1) + (code + 2);
                    var code3 = '' + code + (code - 1) + (code - 2);
                    if (sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                        self.MemberPasswordMsg1("密碼不可為連續數字或字母。");
                        self.IsShowPasswordOK1(2);
                        b = false;
                        return b;
                    }
                }
            }
            if (b == true) {
                self.MemberPasswordMsg1("");
                self.IsShowPasswordOK1(1);
            }
            return b;
        }

        //驗證新密碼
        public PasswordValidate2(): bool {
            var self = this;
            var passwdBar = document.getElementById('passwdBar');
            if (passwdBar != null) {
                ResetBar();
            }
            if ($.trim(self.MemberPasswordNew()) == "") {
                self.MemberPasswordMsg2("密碼不可空白");
                self.IsShowPasswordOK2(2);
                return false;
            } else if ($.trim(self.MemberPasswordNew()) == $.trim(self.MemberPasswordOld())) {
                self.MemberPasswordMsg2("新密碼不可與舊密碼相同");
                self.IsShowPasswordOK2(2);
                return false;
            } else if (!(/^[0-9a-zA-Z]{6,12}$/.test(self.MemberPasswordNew()))) {
                self.MemberPasswordMsg2("密碼必須是 6 ~ 12 碼的英文數字組合。");
                self.IsShowPasswordOK2(2);
                return false;
            } else if ((/^[0-9]{6,12}$/.test(self.MemberPasswordNew()))) {
                self.MemberPasswordMsg2("密碼至少須包含一個英文字母。");
                self.IsShowPasswordOK2(2);
                return false;
            } else if ((self.MemberPasswordNew().indexOf(self.MemberAccount()) > -1 && self.MemberAccount() != "") ||
               (self.MemberPasswordNew().indexOf(self.Mobile()) > -1 && self.Mobile() != "")) {
                self.MemberPasswordMsg2("密碼中不可包含帳號或手機號碼。");
                self.IsShowPasswordOK2(2);
                return false;
            }
            var b = true;
            // 驗證密碼是否含四種不同字元以上
            var CompareString = '';
            for (var i = 0; i < self.MemberPasswordNew().length; i++) {
                if (CompareString.indexOf(self.MemberPasswordNew().charAt(i)) == -1) {
                    CompareString += self.MemberPasswordNew().charAt(i);
                }
            }
            if (CompareString.length < 4) {
                self.MemberPasswordMsg2("密碼必須包含4種(含)字元以上。");
                self.IsShowPasswordOK2(2);
                b = false;
                return b;
            } else {
                var sPW = self.MemberPasswordNew().toLowerCase();
                for (i = 0; i < sPW.length; i++) {
                    // 判斷是否輸入3個連續數字或字母
                    var code = sPW.charCodeAt(i);
                    var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
                    var code2 = '' + code + (code + 1) + (code + 2);
                    var code3 = '' + code + (code - 1) + (code - 2);
                    if (sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                        self.MemberPasswordMsg2("密碼不可為連續數字或字母。");
                        self.IsShowPasswordOK2(2);
                        b = false;
                        return b;
                    }
                }
            }
            if (passwdBar != null && b == true) {
                var ctl = document.getElementById("password");
                CreateRatePasswdReq(ctl);
            }
            if (b == true) {
                self.MemberPasswordMsg2("");
                self.IsShowPasswordOK2(1);
            }
            return b;
        }

        //驗證確認密碼
        public PasswordValidate3(): bool {
            var self = this;
            if ($.trim(self.MemberPasswordC()) == "") {
                self.MemberPasswordMsg3("確認新密碼不可空白");
                self.IsShowPasswordOK3(2);
                return false;
            } else if (self.MemberPasswordC() != self.MemberPasswordNew()) {
                self.MemberPasswordMsg3("兩次新密碼錯誤");
                self.IsShowPasswordOK3(2);
                return false;
            } else if (self.MemberPasswordC() == self.MemberPasswordOld()) {
                self.MemberPasswordMsg3("新密碼不可與舊密碼相同");
                self.IsShowPasswordOK3(2);
                return false;
            }
            else {
                self.MemberPasswordMsg3("");
                self.IsShowPasswordOK3(1);
                return true;
            }
        }

        //選擇回傳訊息
        public SelectMessage(input?: number): string {
            var msg = "";
            switch (input) {
                case 1: msg = "成功。"; break;
                case 3: msg = "此會員新增/合併帳號功能被停權。"; break;
                case 4: msg = "帳號停用中。"; break;
                case 5: msg = "已經通過手機驗證，無法被綁定。"; break;
                case 6: msg = "可加入帳號額度已滿。"; break;
                case 7: msg = "此帳號無法進行新增/合併帳號功能，請使用老子帳號，或聯絡客服。"; break;
                case 8: msg = "該帳號目前在線上，無法併入。"; break;
                case 9: msg = "目前本功能無法使用，如有疑問請洽客服。"; break;
                case 10: msg = "限普卡以上。"; break;
                case 11: msg = "手機驗證未通過，無法綁定帳號。"; break;
                case 21: msg = "主帳號不存在。"; break;
                case 22: msg = "主帳號未通過手機驗證。"; break;
                case 23: msg = "被合併的帳號不存在。"; break;
                case 24: msg = "被合併的帳號已經是主帳號或子帳號。"; break;
                case 25: msg = "不能合併自己。"; break;
                case 31: msg = "帳號不存在。"; break;
                case 32: msg = "密碼錯誤。"; break;
                case 99: msg = "新增/合併帳號失敗。"; break;
            }
            return msg;
        }
    }
}