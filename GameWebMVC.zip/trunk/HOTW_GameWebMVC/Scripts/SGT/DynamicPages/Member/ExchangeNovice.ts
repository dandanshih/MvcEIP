declare var SGT;
declare var $SGT;
declare var $;
declare var ko;

module SGT.DynamicPages {

    // §���I������
    export class ExchangeNovice {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (koName: string = 'ExchangeNovice') {
            this.KoName = koName;

            var self = this;

            // ���o�w�]���
            this.GetFBCoin();
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        FBCoin = ko.observable(0.00);
        FBCoinMaxChange = ko.observable(0.00);
        FBCoinExchange = ko.observable(0);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ���oFB��
        private GetFBCoin(): void {
            var self = this;

            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/getfbcoin",
                success: function (data) {
                    self.FBCoin(data.FBCoin);
                    self.FBCoinMaxChange(data.FBCoinMaxChange);
                    self.FBCoinExchange(data.FBCoinExchange);
                },
                error: function (e) {
                    // alert(e.responseText);
                },
                complete: function (data) {
                }
            });
        }
    }
}