﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Base_Struct_AccountSet_Master = (function () {
            function Base_Struct_AccountSet_Master() {
                this.List = [];
                this.Count = 0;
            }
            return Base_Struct_AccountSet_Master;
        })();
        DynamicPages.Base_Struct_AccountSet_Master = Base_Struct_AccountSet_Master;        
        var Base_Struct_AccountSet_Detail = (function () {
            function Base_Struct_AccountSet_Detail() {
                this.MemberID = 0;
                this.MemberAccount = "";
                this.VIP_Level = 0;
                this.VIP_Level_F = "";
                this.NickName = "";
                this.Point = 0;
                this.TransferCount = 0;
                this.IsPrimaryAccount = 0;
                this.IsQueryAccount = 0;
                this.RsaMemberID = "";
            }
            return Base_Struct_AccountSet_Detail;
        })();
        DynamicPages.Base_Struct_AccountSet_Detail = Base_Struct_AccountSet_Detail;        
        var AccountSet = (function () {
            function AccountSet() {
                this.MA_Record_Master = ko.observableArray([]);
                this.MA_Record_Detail = ko.observableArray([]);
                this.MobileGroupNumber = ko.observable(0);
                this.ShowAccountSettingsArea = ko.observable(0);
                this.ShowNewMergeAccountBtn = ko.observable(0);
                this.MemberAccount = ko.observable("");
                this.MemberPasswordTrue = ko.observable("");
                this.MemberPassword = ko.observable("**********");
                this.MemberPasswordC = ko.observable("**********");
                this.NickName = ko.observable("");
                this.LoginEventFlag = ko.observable(0);
                this.IsShowEditMemberNickNameBtn = ko.observable(false);
                this.IsShowEditMemberNickNameArea = ko.observable(false);
                this.CheckNickNameMsg = ko.observable("");
                this.NewNickName = ko.observable("");
                this.Mobile = ko.observable("");
                this.IsPointUp = ko.observable(false);
                this.IsTransferUp = ko.observable(false);
                this.IsShowDiv1 = ko.observable(false);
                this.IsShowDiv2 = ko.observable(false);
                this.IsShowDiv3 = ko.observable(false);
                this.NewMA = ko.observable("");
                this.NewMP = ko.observable("");
                this.NewMPC = ko.observable("");
                this.IsSubmit = ko.observable(false);
                this.MemberAccountMsg = ko.observable("");
                this.MemberPasswordMsg = ko.observable("");
                this.MemberPasswordMsg2 = ko.observable("");
                this.IsShowAccountOK = ko.observable(0);
                this.IsShowPasswordOK = ko.observable(0);
                this.IsShowPassword2OK = ko.observable(0);
                this.IsFocusAccount = ko.observable(false);
                this.IsFocus1 = ko.observable(false);
                this.IsFocus2 = ko.observable(false);
                this.Agree = ko.observable(false);
            }
            AccountSet.prototype.PageInit = function () {
                var self = this;
                self.GetMemberMobileGroupInfo();
            };
            AccountSet.prototype.GetMemberMobileGroupInfo = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/MemberMobileGroupInfo",
                    data: {
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if(data != null) {
                            self.MemberAccount(data.result.MemberAccount);
                            self.MemberPasswordTrue(data.result.MemberPassword);
                            self.NickName(data.result.NickName);
                            self.Mobile(data.result.Mobile);
                            self.LoginEventFlag(data.result.LoginEventFlag);
                            self.MobileGroupNumber(data.result.MobileGroupNumber);
                            self.ShowAccountSettingsArea(data.result.ShowAccountSettings);
                            self.ShowNewMergeAccountBtn(data.result.ShowNewMergeAccount);
                            self.GetMemberMobileGroupList();
                            self.ShowDiv(1);
                            if(data.result.LoginEventFlag > 0) {
                                if((data.result.LoginEventFlag & 4) == 4) {
                                    self.IsShowEditMemberNickNameBtn(true);
                                    self.IsShowEditMemberNickNameArea(false);
                                } else {
                                    self.IsShowEditMemberNickNameBtn(false);
                                    self.IsShowEditMemberNickNameArea(false);
                                }
                            }
                            self.MemberPassword("**********");
                            self.MemberPasswordC("**********");
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            AccountSet.prototype.GetMemberMobileGroupList = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                var result = new $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/MemberMobileGroupList",
                    data: {
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if(data != null) {
                            self.IsPointUp(false);
                            self.IsTransferUp(false);
                            self.MA_Record_Master(data.result);
                            self.MA_Record_Detail(data.result.List);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            AccountSet.prototype.CheckInsertMergerMA = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                if(!this.Agree()) {
                    self.IsSubmit(false);
                    alert("您尚未同意服務條款");
                    return;
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/MemberMobileGroupAddCheck",
                    data: {
                        Platform: platform
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if(data.result != 1) {
                            self.IsSubmit(false);
                            alert(self.SelectMessage(data.result));
                        } else {
                            self.IsSubmit(true);
                            self.CreateMember();
                        }
                    },
                    error: function (e) {
                        alert(self.SelectMessage(99));
                        self.IsSubmit(false);
                    },
                    complete: function () {
                    }
                });
            };
            AccountSet.prototype.CreateMember = function () {
                var self = this;
                if(self.AccountValidate() && self.PasswordValidate2_1() && self.PasswordValidate2_2() && self.IsSubmit()) {
                    var platform = "Web";
                    if(typeof GetPlatform == 'function') {
                        platform = GetPlatform();
                    }
                    $.ajax({
                        type: "POST",
                        url: "/MVC/api/Member/CreateMember",
                        data: {
                            Platform: platform,
                            MemberAccount: RsaEncrypt(self.NewMA()),
                            MemberPassword: RsaEncrypt(self.NewMP())
                        },
                        async: false,
                        dataType: "json",
                        success: function (data) {
                            if(data.ResultCode == 0) {
                                self.IsSubmit(true);
                                self.InsertMergerMA(1);
                            } else {
                                self.IsSubmit(false);
                                alert(data.ResultMsg);
                            }
                        },
                        error: function (e) {
                            alert(self.SelectMessage(99));
                        },
                        complete: function () {
                        }
                    });
                }
            };
            AccountSet.prototype.InsertMergerMA = function (input) {
                var self = this;
                if(input == 1) {
                    var platform = "Web";
                    if(typeof GetPlatform == 'function') {
                        platform = GetPlatform();
                    }
                    $.ajax({
                        type: "POST",
                        url: "/MVC/api/Member/MemberMobileGroupAdd",
                        data: {
                            Platform: platform,
                            MemberAccount: RsaEncrypt(self.NewMA()),
                            MemberPassword: RsaEncrypt(self.NewMP())
                        },
                        async: false,
                        dataType: "json",
                        success: function (data) {
                            if(data.result == 1) {
                                alert("新增帳號成功。");
                            } else {
                                alert(self.SelectMessage(data.result));
                            }
                        },
                        error: function (e) {
                            alert(self.SelectMessage(99));
                        },
                        complete: function () {
                        }
                    });
                } else if(input == 2) {
                    var platform = "Web";
                    if(typeof GetPlatform == 'function') {
                        platform = GetPlatform();
                    }
                    $.ajax({
                        type: "POST",
                        url: "/MVC/api/Member/MemberMobileGroupAdd",
                        data: {
                            Platform: platform,
                            MemberAccount: RsaEncrypt(self.NewMA()),
                            MemberPassword: RsaEncrypt(self.NewMP())
                        },
                        async: false,
                        dataType: "json",
                        success: function (data) {
                            if(data.result == 1) {
                                if(input == 1) {
                                    alert("新增帳號成功。");
                                } else if(input == 2) {
                                    alert("合併帳號成功。");
                                }
                                self.IsSubmit(true);
                            } else {
                                alert(self.SelectMessage(data.result));
                                self.IsSubmit(false);
                            }
                        },
                        error: function (e) {
                            alert(self.SelectMessage(99));
                        },
                        complete: function () {
                        }
                    });
                }
            };
            AccountSet.prototype.VerifyMA = function (input) {
                var self = this;
                var b = false;
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/VerifyMA",
                    data: {
                        Platform: platform,
                        index: input
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if(data.result) {
                            b = data.result;
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
                return b;
            };
            AccountSet.prototype.ShowDiv = function (WhichDiv) {
                var self = this;
                switch(WhichDiv) {
                    case 1:
                        self.IsShowDiv1(true);
                        self.IsShowDiv2(false);
                        self.IsShowDiv3(false);
                        break;
                    case 2:
                        self.IsShowDiv1(false);
                        self.IsShowDiv2(true);
                        self.IsShowDiv3(false);
                        break;
                    case 3:
                        self.IsShowDiv1(false);
                        self.IsShowDiv2(false);
                        self.IsShowDiv3(true);
                        self.NewMA("");
                        self.NewMP("");
                        break;
                    default:
                        self.IsShowDiv1(true);
                        self.IsShowDiv2(false);
                        self.IsShowDiv3(false);
                        break;
                }
            };
            AccountSet.prototype.ResetAccountSet = function () {
                var self = this;
                self.IsSubmit(false);
                self.MemberAccountMsg("");
                self.MemberPasswordMsg("");
                self.MemberPasswordMsg2("");
                self.IsShowAccountOK(0);
                self.IsShowPasswordOK(0);
                self.IsShowPassword2OK(0);
                self.IsFocusAccount(false);
                self.IsFocus1(false);
                self.IsFocus2(false);
                self.MemberPassword("**********");
                self.MemberPasswordC("**********");
            };
            AccountSet.prototype.ResetInsertMergerArea = function () {
                $("input").val("");
                $("input[type=password]").blur();
                var self = this;
                var passwdBar = document.getElementById('passwdBar');
                if(passwdBar != null) {
                    ResetBar();
                }
                self.IsSubmit(false);
                self.MemberAccountMsg("");
                self.MemberPasswordMsg("");
                self.MemberPasswordMsg2("");
                self.IsShowAccountOK(0);
                self.IsShowPasswordOK(0);
                self.IsShowPassword2OK(0);
                self.IsFocusAccount(false);
                self.IsFocus1(false);
                self.IsFocus2(false);
                self.Agree(false);
            };
            AccountSet.prototype.EditMemberData = function () {
                var self = this;
                if(self.PasswordValidate1_1() && self.PasswordValidate1_2() && self.IsSubmit()) {
                    if(self.IsShowEditMemberNickNameArea() == false) {
                        var platform = "Web";
                        if(typeof GetPlatform == 'function') {
                            platform = GetPlatform();
                        }
                        $.ajax({
                            type: "POST",
                            url: "/MVC/api/Member/EditMemberData",
                            data: {
                                Platform: platform,
                                MemberPassword: (($.trim(self.MemberPassword())).indexOf('*') > -1 ? "" : RsaEncrypt(self.MemberPassword())),
                                NickName: "",
                                MemberPasswordTrue: self.MemberPasswordTrue()
                            },
                            async: false,
                            dataType: "json",
                            success: function (data) {
                                if(data.Result1.ResultCode == 0) {
                                    alert("修改會員成功");
                                    self.PageInit();
                                    self.ResetAccountSet();
                                    self.MemberPasswordTrue(data.Result2);
                                } else {
                                    alert(data.Result1.ResultMsg);
                                }
                            },
                            error: function (e) {
                            },
                            complete: function () {
                            }
                        });
                    } else {
                        if(self.NickNameValidate()) {
                            var platform = "Web";
                            if(typeof GetPlatform == 'function') {
                                platform = GetPlatform();
                            }
                            $.ajax({
                                type: "POST",
                                url: "/MVC/api/Member/EditMemberData",
                                data: {
                                    Platform: platform,
                                    MemberPassword: (($.trim(self.MemberPassword())).indexOf('*') > -1 ? "" : RsaEncrypt(self.MemberPassword())),
                                    NickName: self.NewNickName(),
                                    MemberPasswordTrue: self.MemberPasswordTrue()
                                },
                                async: false,
                                dataType: "json",
                                success: function (data) {
                                    if(data.Result1.ResultCode == 0) {
                                        alert("修改會員成功");
                                        self.ClearFlag();
                                        self.PageInit();
                                        self.ResetAccountSet();
                                        self.MemberPasswordTrue(data.Result2);
                                    } else {
                                        alert(data.Result1.ResultMsg);
                                    }
                                },
                                error: function (e) {
                                    alert(e);
                                },
                                complete: function () {
                                }
                            });
                        }
                    }
                }
            };
            AccountSet.prototype.ClearFlag = function () {
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/ClearFlag",
                    async: false,
                    data: {
                        "flag": "",
                        Platform: platform
                    },
                    dataType: "json",
                    success: function (data) {
                    },
                    error: function (e) {
                    }
                });
            };
            AccountSet.prototype.ShowEditMemberNickNameArea = function () {
                var self = this;
                self.IsShowEditMemberNickNameArea(true);
            };
            AccountSet.prototype.PasswordValidate1_1 = function () {
                var self = this;
                var status = true;
                if($.trim(self.MemberPassword()) == "**********") {
                    self.IsSubmit(true);
                    return status;
                }
                if($.trim(self.MemberPassword()) == "") {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼不可空白");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else if(!(/^[0-9a-zA-Z]{6,12}$/.test(self.MemberPassword()))) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼必須是 6 ~ 12 碼的英文數字組合。");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else if((/^[0-9]{6,12}$/.test(self.MemberPassword()))) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼至少須包含一個英文字母。");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else if((self.MemberPassword().indexOf(self.MemberAccount()) > -1 && self.MemberAccount() != "") || (self.MemberPassword().indexOf(self.Mobile()) > -1 && self.Mobile() != "")) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼中不可包含帳號或手機號碼。");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else {
                    var CompareString = '';
                    for(var i = 0; i < self.MemberPassword().length; i++) {
                        if(CompareString.indexOf(self.MemberPassword().charAt(i)) == -1) {
                            CompareString += self.MemberPassword().charAt(i);
                        }
                    }
                    if(CompareString.length < 4) {
                        self.IsSubmit(false);
                        self.MemberPasswordMsg("密碼必須包含4種(含)字元以上。");
                        self.IsShowPasswordOK(2);
                        status = false;
                    } else {
                        var sPW = self.MemberPassword().toLowerCase();
                        for(i = 0; i < sPW.length; i++) {
                            var code = sPW.charCodeAt(i);
                            var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
                            var code2 = '' + code + (code + 1) + (code + 2);
                            var code3 = '' + code + (code - 1) + (code - 2);
                            if(sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                                self.IsSubmit(false);
                                self.MemberPasswordMsg("密碼不可為連續數字或字母。");
                                self.IsShowPasswordOK(2);
                                status = false;
                            }
                        }
                    }
                }
                if(status == true) {
                    self.IsSubmit(true);
                    self.MemberPasswordMsg("");
                    self.IsShowPasswordOK(1);
                }
                return status;
            };
            AccountSet.prototype.PasswordValidate1_2 = function () {
                var self = this;
                if(($.trim(self.MemberPasswordC()) == "**********") && (self.MemberPasswordC() == self.MemberPassword())) {
                    self.IsSubmit(true);
                    return true;
                }
                if($.trim(self.MemberPasswordC()) == "") {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg2("確認密碼不可空白");
                    self.IsShowPassword2OK(2);
                    return false;
                } else if(self.MemberPasswordC() != self.MemberPassword()) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg2("兩次密碼錯誤");
                    self.IsShowPassword2OK(2);
                    return false;
                } else {
                    self.MemberPasswordMsg2("");
                    self.IsShowPassword2OK(1);
                    self.IsSubmit(true);
                    return true;
                }
            };
            AccountSet.prototype.NickNameValidate = function () {
                var self = this;
                var status = true;
                if($.trim(self.NewNickName()) == "") {
                    self.CheckNickNameMsg("*暱稱不可空白");
                    self.IsSubmit(false);
                    status = false;
                } else if((self.NewNickName().length > 0 && self.NewNickName().indexOf(self.MemberAccount()) > -1) || (self.MemberPassword().length > 0 && self.NewNickName().indexOf(self.MemberPassword()) > -1) || (self.Mobile().length > 0 && self.NewNickName().indexOf(self.Mobile()) > -1)) {
                    self.CheckNickNameMsg("*暱稱中不可包含帳號、密碼或手機號碼");
                    self.IsSubmit(false);
                    status = false;
                } else if(!(/^[0-9a-z\u4e00-\u9fa5]{1,10}$/.test(self.NewNickName().toLowerCase()))) {
                    self.CheckNickNameMsg("*暱稱不可包含特殊字元");
                    self.IsSubmit(false);
                    status = false;
                } else {
                    $.ajax({
                        type: "POST",
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        async: false,
                        data: "CheckType=2&CheckData=" + self.NewNickName(),
                        success: function (data) {
                            if(data == "暱稱重複") {
                                self.CheckNickNameMsg("*暱稱重複");
                                self.IsSubmit(false);
                                status = false;
                            } else {
                                self.IsSubmit(true);
                                self.CheckNickNameMsg(data);
                                status = true;
                            }
                        },
                        error: function (e) {
                            self.IsSubmit(false);
                            return false;
                        }
                    });
                }
                return status;
            };
            AccountSet.prototype.AccountValidate = function () {
                var self = this;
                var status = false;
                if($.trim(self.NewMA()) == "") {
                    self.IsSubmit(false);
                    self.MemberAccountMsg("帳號不可空白");
                    self.IsShowAccountOK(2);
                } else if(!(/^[0-9a-zA-Z]{6,12}$/.test(self.NewMA()))) {
                    self.IsSubmit(false);
                    self.MemberAccountMsg("帳號必須是 6 ~ 12 碼的英文數字組合");
                    self.IsShowAccountOK(2);
                } else if(!(/(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$/.test(self.NewMA()))) {
                    self.IsSubmit(false);
                    self.MemberAccountMsg("帳號至少須包含一個英文字母");
                    self.IsShowAccountOK(2);
                } else if((self.NewMA().indexOf(self.NewMP()) > -1 && self.NewMP() != "") || (self.NewMA().indexOf(self.Mobile()) > -1 && self.Mobile() != "")) {
                    self.IsSubmit(false);
                    self.MemberAccountMsg("帳號中不可包含密碼或手機號碼");
                    self.IsShowAccountOK(2);
                } else {
                    $.ajax({
                        type: "POST",
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        async: false,
                        data: "CheckType=1&CheckData=" + self.NewMA(),
                        success: function (data) {
                            if(data != "此帳號已有人使用") {
                                self.IsSubmit(true);
                                self.MemberAccountMsg("");
                                self.IsShowAccountOK(1);
                                status = true;
                            } else {
                                self.IsSubmit(false);
                                self.MemberAccountMsg(data);
                                self.IsShowAccountOK(2);
                            }
                        },
                        error: function (e) {
                            self.IsSubmit(false);
                            self.IsShowAccountOK(2);
                        }
                    });
                }
                return status;
            };
            AccountSet.prototype.PasswordValidate2_1 = function () {
                var self = this;
                var status = true;
                var passwdBar = document.getElementById('passwdBar');
                if(passwdBar != null) {
                    ResetBar();
                }
                if($.trim(self.NewMP()) == "") {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼不可空白");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else if(!(/^[0-9a-zA-Z]{6,12}$/.test(self.NewMP()))) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼必須是 6 ~ 12 碼的英文數字組合。");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else if((/^[0-9]{6,12}$/.test(self.NewMP()))) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼至少須包含一個英文字母。");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else if((self.NewMP().indexOf(self.NewMA()) > -1 && self.NewMA() != "") || (self.NewMP().indexOf(self.Mobile()) > -1 && self.Mobile() != "")) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg("密碼中不可包含帳號或手機號碼。");
                    self.IsShowPasswordOK(2);
                    status = false;
                } else {
                    var CompareString = '';
                    for(var i = 0; i < self.NewMP().length; i++) {
                        if(CompareString.indexOf(self.NewMP().charAt(i)) == -1) {
                            CompareString += self.NewMP().charAt(i);
                        }
                    }
                    if(CompareString.length < 4) {
                        self.IsSubmit(false);
                        self.MemberPasswordMsg("密碼必須包含4種(含)字元以上。");
                        self.IsShowPasswordOK(2);
                        status = false;
                    } else {
                        var sPW = self.NewMP().toLowerCase();
                        for(i = 0; i < sPW.length; i++) {
                            var code = sPW.charCodeAt(i);
                            var codeDefault = '' + sPW.charCodeAt(i) + sPW.charCodeAt(i + 1) + sPW.charCodeAt(i + 2);
                            var code2 = '' + code + (code + 1) + (code + 2);
                            var code3 = '' + code + (code - 1) + (code - 2);
                            if(sPW.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                                self.IsSubmit(false);
                                self.MemberPasswordMsg("密碼不可為連續數字或字母。");
                                self.IsShowPasswordOK(2);
                                status = false;
                            }
                        }
                    }
                }
                if(passwdBar != null) {
                    var ctl = document.getElementById("password");
                    CreateRatePasswdReq(ctl);
                }
                if(status == true) {
                    self.IsSubmit(true);
                    self.MemberPasswordMsg("");
                    self.IsShowPasswordOK(1);
                }
                return status;
            };
            AccountSet.prototype.PasswordValidate2_2 = function () {
                var self = this;
                if($.trim(self.NewMPC()) == "") {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg2("確認密碼不可空白。");
                    self.IsShowPassword2OK(2);
                    return false;
                } else if(self.NewMPC() != self.NewMP()) {
                    self.IsSubmit(false);
                    self.MemberPasswordMsg2("兩次密碼錯誤。");
                    self.IsShowPassword2OK(2);
                    return false;
                } else {
                    self.MemberPasswordMsg2("");
                    self.IsShowPassword2OK(1);
                    self.IsSubmit(true);
                    return true;
                }
            };
            AccountSet.prototype.SelectMessage = function (input) {
                var msg = "";
                switch(input) {
                    case 1:
                        msg = "成功。";
                        break;
                    case 3:
                        msg = "此會員新增/合併帳號功能被停權。";
                        break;
                    case 4:
                        msg = "帳號停用中。";
                        break;
                    case 5:
                        msg = "已經通過手機驗證，無法被綁定。";
                        break;
                    case 6:
                        msg = "可加入帳號額度已滿。";
                        break;
                    case 7:
                        msg = "此帳號無法進行新增/合併帳號功能，請使用老子帳號，或聯絡客服。";
                        break;
                    case 8:
                        msg = "該帳號目前在線上，無法併入。";
                        break;
                    case 9:
                        msg = "目前本功能無法使用，如有疑問請洽客服。";
                        break;
                    case 10:
                        msg = "限普卡以上。";
                        break;
                    case 11:
                        msg = "手機驗證未通過，無法綁定帳號。";
                        break;
                    case 21:
                        msg = "主帳號不存在。";
                        break;
                    case 22:
                        msg = "主帳號未通過手機驗證。";
                        break;
                    case 23:
                        msg = "被合併的帳號不存在。";
                        break;
                    case 24:
                        msg = "被合併的帳號已經是主帳號或子帳號。";
                        break;
                    case 25:
                        msg = "不能合併自己。";
                        break;
                    case 31:
                        msg = "帳號不存在。";
                        break;
                    case 32:
                        msg = "密碼錯誤。";
                        break;
                    case 99:
                        msg = "新增/合併帳號失敗。";
                        break;
                }
                return msg;
            };
            AccountSet.prototype.SortRecordPointData = function () {
                var self = this;
                if(self.MA_Record_Detail().length <= 0) {
                    return;
                }
                self.IsPointUp(!self.IsPointUp());
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/MemberMobileGroupList",
                    data: {
                        Platform: platform,
                        Which: "Point",
                        UpOrDown: self.IsPointUp()
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if(data != null) {
                            self.MA_Record_Detail(data.result.List);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            AccountSet.prototype.SortRecordTransferData = function () {
                var self = this;
                if(self.MA_Record_Detail().length <= 0) {
                    return;
                }
                self.IsTransferUp(!self.IsTransferUp());
                var platform = "Web";
                if(typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: "POST",
                    url: "/MVC/api/Member/MemberMobileGroupList",
                    data: {
                        Platform: platform,
                        Which: "Transfer",
                        UpOrDown: self.IsTransferUp()
                    },
                    async: false,
                    dataType: "json",
                    success: function (data) {
                        if(data != null) {
                            self.MA_Record_Detail(data.result.List);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function () {
                    }
                });
            };
            AccountSet.prototype.CloseColorBox = function () {
                $.colorbox.close();
            };
            AccountSet.prototype.IsFocusAccountChange1 = function () {
                var self = this;
                if($.trim(self.NewMA()) == "") {
                    self.IsFocusAccount(!self.IsFocusAccount());
                    if(self.IsFocusAccount() == true) {
                        $("#account").focus();
                    }
                }
            };
            AccountSet.prototype.IsFocusChange1 = function () {
                var self = this;
                if($.trim(self.NewMP()) == "") {
                    self.IsFocus1(!self.IsFocus1());
                    if(self.IsFocus1() == true) {
                        $("#password").focus();
                    }
                }
            };
            AccountSet.prototype.IsFocusChange2 = function () {
                var self = this;
                if($.trim(self.NewMPC()) == "") {
                    self.IsFocus2(!self.IsFocus2());
                    if(self.IsFocus2() == true) {
                        $("#passwordC").focus();
                    }
                }
            };
            return AccountSet;
        })();
        DynamicPages.AccountSet = AccountSet;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
