﻿// 依照會員編號，動態繫結會員卡別資訊
SGT.Main.Add('PersonalCardAny', {
    Store: ko.observable(),
    Bet: ko.observable(),
    CurrentLevel: ko.observable(),
    NextLevel: ko.observable(),
    NextDate: ko.observable("0000/0/0"),
    NextMonth: function () {
        var month = (new Date(SGT.Main.QueryFns['PersonalCardAny'].NextDate()).getMonth() + 1) % 12;
        return month == 0 ? 12 : month;
    },
    NextDay: function () {
        return new Date(SGT.Main.QueryFns['PersonalCardAny'].NextDate()).getDate();
    },
    ConvertToCardName: function (level) {
        if (level == 1) {
            return "普卡";
        }
        else if (level == 2) {
            return "銀卡";
        }
        else if (level == 3) {
            return "金卡";
        }
        else if (level == 4) {
            return "白金卡";
        }
        else {
            return "一般";
        }

        return "";
    },
    StoreBar: function (config) {
        var percent = 0;
        var imageUrl = "";

        var DefaultConfig = {
            IsMini: true
        }
        DefaultConfig = $.extend(DefaultConfig, config);

        if (SGT.Main.QueryFns['PersonalCardAny'].Store().NowValue < SGT.Main.QueryFns['PersonalCardAny'].Store().No2Value) {
            percent = (SGT.Main.QueryFns['PersonalCardAny'].Store().NowValue - SGT.Main.QueryFns['PersonalCardAny'].Store().No1Value) / SGT.Main.QueryFns['PersonalCardAny'].Store().No2Value * 0.5 * 100;
        } else if (SGT.Main.QueryFns['PersonalCardAny'].Store().NowValue >= SGT.Main.QueryFns['PersonalCardAny'].Store().No3Value) {
            percent = 100;
        } else {
            percent = 50 + ((SGT.Main.QueryFns['PersonalCardAny'].Store().NowValue - SGT.Main.QueryFns['PersonalCardAny'].Store().No2Value) / (SGT.Main.QueryFns['PersonalCardAny'].Store().No3Value - SGT.Main.QueryFns['PersonalCardAny'].Store().No2Value) * 0.5 * 100);
        }
        var ImgFolder = DefaultConfig.IsMini ? (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/main/") : (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/content/");
        var ImgFileType = DefaultConfig.IsMini ? ".jpg" : ".png";

        if (percent <= 0) {
            imageUrl = ImgFolder + "strip00" + ImgFileType;
        }
        else if (percent <= 16) {
            imageUrl = ImgFolder + "strip01" + ImgFileType;
        }
        else if (percent <= 32) {
            imageUrl = ImgFolder + "strip02" + ImgFileType;
        }
        else if (percent < 50) {
            imageUrl = ImgFolder + "strip03" + ImgFileType;
        }
        else if (percent == 50) {
            imageUrl = ImgFolder + "strip04" + ImgFileType;
        }
        else if (percent <= 66) {
            imageUrl = ImgFolder + "strip05" + ImgFileType;
        }
        else if (percent <= 82) {
            imageUrl = ImgFolder + "strip06" + ImgFileType;
        }
        else if (percent < 100) {
            imageUrl = ImgFolder + "strip07" + ImgFileType;
        }
        else if (percent >= 100) {
            imageUrl = ImgFolder + "strip08" + ImgFileType;
        }

        return imageUrl;
    },
    BetBar: function (config) {
        var percent = 0;
        var imageUrl = "";
        var DefaultConfig = {
            IsMini: true
        }
        $.extend(DefaultConfig, config);

        if (SGT.Main.QueryFns['PersonalCardAny'].Bet().NowValue < SGT.Main.QueryFns['PersonalCardAny'].Bet().No2Value) {
            percent = (SGT.Main.QueryFns['PersonalCardAny'].Bet().NowValue - SGT.Main.QueryFns['PersonalCardAny'].Bet().No1Value) / SGT.Main.QueryFns['PersonalCardAny'].Bet().No2Value * 0.5 * 100;
        } else if (SGT.Main.QueryFns['PersonalCardAny'].Bet().NowValue >= SGT.Main.QueryFns['PersonalCardAny'].Bet().No3Value) {
            percent = 100;
        } else {
            percent = 50 + ((SGT.Main.QueryFns['PersonalCardAny'].Bet().NowValue - SGT.Main.QueryFns['PersonalCardAny'].Bet().No2Value) / (SGT.Main.QueryFns['PersonalCardAny'].Bet().No3Value - SGT.Main.QueryFns['PersonalCardAny'].Bet().No2Value) * 0.5 * 100);
        }

        var ImgFolder = DefaultConfig.IsMini ? (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/main/") : (SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/content/");
        var ImgFileType = DefaultConfig.IsMini ? ".jpg" : ".png";

        if (percent <= 0) {
            imageUrl = ImgFolder + "strip00" + ImgFileType;
        }
        else if (percent <= 16) {
            imageUrl = ImgFolder + "strip01" + ImgFileType;
        }
        else if (percent <= 32) {
            imageUrl = ImgFolder + "strip02" + ImgFileType;
        }
        else if (percent < 50) {
            imageUrl = ImgFolder + "strip03" + ImgFileType;
        }
        else if (percent == 50) {
            imageUrl = ImgFolder + "strip04" + ImgFileType;
        }
        else if (percent <= 66) {
            imageUrl = ImgFolder + "strip05" + ImgFileType;
        }
        else if (percent <= 82) {
            imageUrl = ImgFolder + "strip06" + ImgFileType;
        }
        else if (percent < 100) {
            imageUrl = ImgFolder + "strip07" + ImgFileType;
        }
        else if (percent >= 100) {
            imageUrl = ImgFolder + "strip08" + ImgFileType;
        }

        return imageUrl;
    }
});