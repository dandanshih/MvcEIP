declare var $;
declare var ko;


module SGT.DynamicPages {

    // �ѰO�K�X
    export class ForgetPassword {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () { 
            this.ChangeVerifyCode();
        }
        

        /// --------------------------------------
        /// ko
        /// --------------------------------------
        QueryType = ko.observable(1);
        SentType = ko.observable(1);
        InquiryAccount = ko.observable('');
        InquiryMobile = ko.observable('');
        VerifyCode = ko.observable('');
        ServiceTel = ko.observable('');
        ServiceFax = ko.observable('');
        VerifyCodeSrc = ko.observable('');
        SubmitBtnEnable = ko.observable(true);
        ViewEnable_Enter = ko.observable(true);
        ViewEnable_Finsh = ko.observable(false);


        /// --------------------------------------
        /// function
        /// --------------------------------------
        ChangeVerifyCode(): void {
            this.VerifyCodeSrc('/MVC/Verify/GetVerifyCode?' + Math.random());
        }

        Clear(): void {
            this.SubmitBtnEnable(true);
            this.ViewEnable_Enter(true);
            this.ViewEnable_Finsh(false);
            this.QueryType(1);
            this.SentType(1);
            this.InquiryAccount('');
            this.InquiryMobile('');
            this.VerifyCode('');
        }

        ToEnterView(): void {
            this.ViewEnable_Enter(true);
            this.ViewEnable_Finsh(false);
        }

        ToFinshView(): void {
            this.ViewEnable_Enter(false);
            this.ViewEnable_Finsh(true);
        }

        Submit(): void {
            var obj = this;

            // ��w���s(�Y�����]���s�]������w)
            obj.SubmitBtnEnable(false);
            var data = 
            {
                QueryType: obj.QueryType()
                , SentType: obj.SentType()
                , InquiryAccount: obj.InquiryAccount()
                , InquiryMobile: obj.InquiryMobile()
                , VerifyCode: obj.VerifyCode()
            };

            $.ajax({
		        type: "Post",
		        url: "/Mvc/api/member/forgetPassword",
			    data: data,
		        success: function (data) {
                    // �Ѱ���w
                    obj.SubmitBtnEnable(true);

                    if (data.Code != 0) {
                        alert(data.Message);
                    } else {
                        // �M����J���
                        obj.Clear();

                        // ��X�ȪA��T
                        obj.ServiceTel(data.CSTel);
                        obj.ServiceFax(data.CSFax);

                        // �ഫView
                        obj.ToFinshView();
                    }
		        },
		        error: function (e) {
			        // alert(e.responseText);
                    // �Ѱ���w
                    obj.SubmitBtnEnable(true);
		        }
	        });

            this.ChangeVerifyCode();
        }
    }

}
