declare var $;
declare var ko;


module SGT.DynamicPages {

    // �C���O��
    export class GameRecord {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () { 
        }

        
        /// --------------------------------------
        /// ko
        /// --------------------------------------
        CurrentPoint = ko.observable('0.00');
        ShowData = ko.observable(true);
        QueryData: Array[] = ko.observableArray([{ No: 1, GameName: '�j�ѤG', WinLose: '100', GameID: 1001 }]);
        
        /// --------------------------------------
        /// function
        /// --------------------------------------
        PopDetail(): void {
            var items = this;

            var myWindow = window.open('GameDetail.aspx?gameid=' + items['GameID'] +'&begindate={1}&enddate={2}&MemberIdentity=2','�C������','width=620,height=450,scrollbars=yes,left=250,top=200'); 
            myWindow.focus();
        }

        Query(): void {

        }

    }
}