﻿/// <reference path="../Member/MemberRegister.ts" />

declare var GetCdn: any;
declare var Format: any;
declare var $: any;
declare var ResetBar: any;
declare var CreateRatePasswdReq: any;

module SGT.DynamicPages {

    export interface iControlAttribute {

        Control: ControlAttribute;

        Valid(): bool;

        Reset(): void;
    }

    export class ControlAttribute {

        constructor(id: string, type: string, name: string) {

            this.ID = id;
            this.Type = type;
            this.Name = name;
            this.ErrorMsgID = this.ID + "ErrorMsgID";
        }

        ID: string = "";

        Type: string = "";

        Name: string = "";

        ErrorMsg: string = "";

        Value: string = "";

        Agree: bool = false;

        ErrorMsgID: string = "";

        SelectMessage(input: number, name1: string, name2?: string, name3?: string): string {

            var msg = "";

            switch (input) {
                case 1: msg = name1 + "不可空白。"; break;
                case 2: msg = name1 + "必須是6~12碼的英文數字組合。"; break;
                case 3: msg = name1 + "至少須包含一個英文字母。"; break;
                case 4: msg = "此" + name1 + "已被使用。"; break;
                case 5: msg = name1 + "必須包含4種(含)字元以上。"; break;
                case 6: msg = name1 + "不可為連續數字或字母。"; break;
                case 7: msg = "兩次密碼錯誤。"; break;
                case 8: msg = name1 + "格式錯誤。"; break;
                case 9: msg = name1 + "中不可包含" + name2 + "或" + name3 + "。"; break;
                case 10: msg = name1 + "重複。"; break;
                case 11: msg = "此" + name1 + "已被鎖定，請洽客服專員。"; break;
                case 12: msg = "此" + name1 + "已被申請過。"; break;
                case 13: msg = "此" + name1 + "無效。"; break;
                case 14: msg = "此" + name1 + "未通過驗證。"; break;
                case 15: msg = name1 + "錯誤，請重新輸入。"; break;
                case 16: msg = name1 + "中不可包含" + name2 + "。"; break;
            }

            return msg;
        }

        SetErrorMessage(): void {

            $("#" + this.ErrorMsgID).html(this.ErrorMsg);

            //document.getElementById(this.ErrorMsgID).innerHTML = this.ErrorMsg;
        }
    }

    export class AccountControl implements iControlAttribute {

        constructor(base: MemberRegister) {

            this.Base = base;
        }

        Control: ControlAttribute = new ControlAttribute("Account", "Account", "帳號");

        Base: MemberRegister;

        Valid(): bool {

            var self = this;
            var b = false;
            var value = $.trim(self.Control.Value);
            var errmsg = "";

            if (value == "") {
                errmsg = self.Control.SelectMessage(1, self.Control.Name);
            }
            else if (!value.match(/^[0-9a-zA-Z]{6,12}$/)) {
                errmsg = self.Control.SelectMessage(2, self.Control.Name);
            }
            else if (!value.match(/(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$/)) {
                errmsg = self.Control.SelectMessage(3, self.Control.Name);
            }
            else if ($.trim(self.Base.Password.Control.Value) != "" && value.indexOf(self.Base.Password.Control.Value) > -1) {
                errmsg = self.Control.SelectMessage(16, self.Control.Name, self.Base.Password.Control.Name);
            }
            else {
                $.ajax({
                    type: "POST",
                    async: false,
                    url: "/AppAjaxs/RegisterValidation.ashx",
                    data: { "ResultType": "2", "CheckType": "1", "CheckData": value },
                    success: function (data) {
                        if (data == "Success") {
                            b = true;
                        } else {
                            errmsg = data;
                        }
                    },
                    error: function (e) {

                    }
                });
            }

            self.Control.ErrorMsg = errmsg;

            self.Control.SetErrorMessage();

            return b;
        }

        Reset(): void {

            this.Control.Value = "";
            this.Control.ErrorMsg = "";
            this.Control.SetErrorMessage();
        }
    }

    export class PasswordControl implements iControlAttribute {

        constructor(base: MemberRegister) {

            this.Base = base;
        }

        Control: ControlAttribute = new ControlAttribute("Password", "Password", "密碼");

        Base: MemberRegister;

        Valid(): bool {

            var self = this;
            var b = true;
            var value = self.Control.Value;
            var errmsg = "";
            var comparestring = "";

            var passwdBar = document.getElementById('passwdBar');

            if (passwdBar != null) {
                ResetBar();
            }

            if ($.trim(value) == "") {
                errmsg = self.Control.SelectMessage(1, self.Control.Name);
                b = false;
            }
            else if (!value.match(/^[0-9a-zA-Z]{6,12}$/)) {
                errmsg = self.Control.SelectMessage(2, self.Control.Name);
                b = false;
            }
            else if (value.match(/^[0-9]{6,12}$/)) {
                errmsg = self.Control.SelectMessage(3, self.Control.Name);
                b = false;
            }
            else if ($.trim(self.Base.Account.Control.Value) != "" && value.indexOf(self.Base.Account.Control.Value) > -1) {
                errmsg = self.Control.SelectMessage(16, self.Control.Name, self.Base.Account.Control.Name);
                b = false;
            }
            else {
                for (var i = 0; i < value.length; i++) {
                    if (comparestring.indexOf(value.charAt(i)) == -1) {
                        comparestring += value.charAt(i);
                    }
                }
                if (comparestring.length < 4) {
                    errmsg = self.Control.SelectMessage(5, self.Control.Name);
                    b = false;
                } else {
                    value = value.toLowerCase();
                    for (i = 0; i < value.length; i++) {
                        var code = value.charCodeAt(i);
                        var codeDefault = '' + value.charCodeAt(i) + value.charCodeAt(i + 1) + value.charCodeAt(i + 2);
                        var code2 = '' + code + (code + 1) + (code + 2);
                        var code3 = '' + code + (code - 1) + (code - 2);
                        if (value.length - i > 2 && (codeDefault == code2 || codeDefault == code3)) {
                            errmsg = self.Control.SelectMessage(6, self.Control.Name);
                            b = false;
                            break;
                        }
                    }
                }
            }

            self.Control.ErrorMsg = errmsg;

            if (passwdBar != null) {
                var ctl = document.getElementById("Password");
                CreateRatePasswdReq(ctl);
            }

            self.Control.SetErrorMessage();

            return b;
        }

        Reset(): void {

            this.Control.Value = "";
            this.Control.ErrorMsg = "";
            this.Control.SetErrorMessage();
        }
    }

    export class ConfirmPasswordControl implements iControlAttribute {

        constructor(base: MemberRegister) {

            this.Base = base;
        }

        Control: ControlAttribute = new ControlAttribute("ConfirmPassword", "ConfirmPassword", "確認密碼");

        Base: MemberRegister;

        Valid(): bool {

            var self = this;
            var b = false;
            var value = $.trim(self.Control.Value);
            var errmsg = "";

            if (value == "") {
                errmsg = self.Control.SelectMessage(1, self.Control.Name);
            } else if (value != self.Base.Password.Control.Value) {
                errmsg = self.Control.SelectMessage(7, self.Control.Name);
            } else {
                b = true;
                errmsg = "";
            }

            self.Control.ErrorMsg = errmsg;

            self.Control.SetErrorMessage();

            return b;
        }

        Reset(): void {

            this.Control.Value = "";
            this.Control.ErrorMsg = "";
            this.Control.SetErrorMessage();
        }
    }

    export class MobileControl implements iControlAttribute {

        constructor(base: MemberRegister) {

            this.Base = base;
        }

        Control: ControlAttribute = new ControlAttribute("Mobile", "Mobile", "手機號碼");

        Base: MemberRegister;

        Valid(): bool {

            var self = this;
            var b = false;
            var value = $.trim(self.Control.Value);
            var errmsg = "";

            if (value == "") {
                errmsg = self.Control.SelectMessage(1, self.Control.Name);
            }
            else if (!value.match(/^[09]{2}[0-9]{8}$/)) {
                errmsg = self.Control.SelectMessage(8, self.Control.Name);
            }
            else if (($.trim(self.Base.Account.Control.Value) != "" && value.indexOf(self.Base.Account.Control.Value) > -1)
                || ($.trim(self.Base.Password.Control.Value) != "" && value.indexOf(self.Base.Password.Control.Value) > -1)) {
                errmsg = self.Control.SelectMessage(9, self.Control.Name, self.Base.Account.Control.Name, self.Base.Password.Control.Name);
            }
            else {
                $.ajax({
                    type: "POST",
                    async: false,
                    url: "/AppAjaxs/RegisterValidation.ashx",
                    data: { "ResultType": "2", "CheckType": "3", "CheckData": value },
                    success: function (data) {
                        if (data == "Success") {
                            b = true;
                        } else {
                            errmsg = data;
                        }
                    },
                    error: function (e) {

                    }
                });
            }

            self.Control.ErrorMsg = errmsg;

            self.Control.SetErrorMessage();

            return b;
        }

        Reset(): void {

            this.Control.Value = "";
            this.Control.ErrorMsg = "";
            this.Control.SetErrorMessage();
        }
    }

    export class EmailControl implements iControlAttribute {

        constructor(base: MemberRegister) {

            this.Base = base;
        }

        Control: ControlAttribute = new ControlAttribute("Email", "Email", "電子信箱");

        Base: MemberRegister;

        Valid(): bool {

            var self = this;
            var b = false;
            var value = self.Control.Value;
            var errmsg = "";

            if (value != "") {
                if (!value.match(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/)) {
                    errmsg = self.Control.SelectMessage(8, self.Control.Name);
                }
                else {
                    $.ajax({
                        type: "POST",
                        async: false,
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        data: { "ResultType": "2", "CheckType": "8", "CheckData": value },
                        success: function (data) {
                            if (data == "Success") {
                                b = true;
                            } else {
                                errmsg = data;
                            }
                        },
                        error: function (e) {

                        }
                    });
                }
            } else {
                b = true;
            }

            self.Control.ErrorMsg = errmsg;

            self.Control.SetErrorMessage();

            return b;
        }

        Reset(): void {

            this.Control.Value = "";
            this.Control.ErrorMsg = "";
            this.Control.SetErrorMessage();
        }
    }

    export class BingoSNControl implements iControlAttribute {

        constructor(base: MemberRegister) {

            this.Base = base;
        }

        Control: ControlAttribute = new ControlAttribute("BingoSN", "BingoSN", "推薦人序號");

        Base: MemberRegister;

        Valid(): bool {

            var self = this;
            var b = false;
            var value = self.Control.Value;
            var errmsg = "";

            if (value != "") {
                //if (!value.match(/^[0-9a-zA-Z]+$/)) {
                //    errmsg = self.Control.SelectMessage(15, self.Control.Name);
                //}
                //else {
                    $.ajax({
                        type: "POST",
                        async: false,
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        data: { "ResultType": "2", "CheckType": "9", "CheckData": value },
                        success: function (data) {
                            if (data != "Success") {
                                errmsg = self.Control.SelectMessage(15, self.Control.Name);
                            }
                            else {
                                b = true;
                            }
                        },
                        error: function (e) {

                        }
                    });
                //}
            } else {

                b = true;
            }

            self.Control.ErrorMsg = errmsg;

            self.Control.SetErrorMessage();

            return b;
        }

        Reset(): void {

            this.Control.Value = "";
            this.Control.ErrorMsg = "";
            this.Control.SetErrorMessage();
        }
    }

    export class AgreeControl implements iControlAttribute {

        constructor(base: MemberRegister) {

            this.Base = base;
        }

        Control: ControlAttribute = new ControlAttribute("Agree", "Agree", "同意");

        Base: MemberRegister;

        Valid(): bool {

            var errmsg = "";

            if (!this.Control.Agree) {

                errmsg = "須同意服務條款。";
            }

            this.Control.ErrorMsg = errmsg;

            this.Control.SetErrorMessage();

            this.Base.AgreeStatus(this.Control.Agree);

            return this.Control.Agree;
        }

        Reset(): void {

            this.Control.Agree = false;
            this.Control.Value = "";
            this.Control.ErrorMsg = "";
            this.Control.SetErrorMessage();
        }
    }
}