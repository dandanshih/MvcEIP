declare var SGT;
declare var $SGT;
declare var $;
declare var ko;

module SGT.DynamicPages {

    // �ڪ�§�����߰O��
    export class GiftCenter {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (koName: string = 'GiftCenter', pageName: string = 'PageParial') {
            this.KoName = koName;
            this.PageName = pageName;

            var self = this;

            // New �@�ӷs�� Page Instance�A�åB�w�q ChangeEvent �����ƥ�
            SGT.Pages.PageMgr.Add(this.PageName, new SGT.Pages.Page(function () {
                self.GetGiftReport();
            }));

            // ���o�w�]���
            this.GetDefaultData();
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';
        private PageName: string = '';

        // ���a��T
        private MyExchangeID: any = '';
        private MyCityID: number = 0;
        private MyZoneID: string = '';
        private MyAddress: string = '';
        private MyRealName: string = '';
        private MyPhone: string = '';
        private MyEmail: string = '';
        private DefaultCity: Object = { CityID: 0, CityName: $SGT.Message.GiftCenter.Utility[2], ZoneList: [] };
        private DefaultZone: Object = { ZipCode: '', ZoneID: '', ZoneName: $SGT.Message.GiftCenter.Utility[3] };
        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        ViewEnable = ko.observable(true);
        ViewEnable_List = ko.observable(false);
        ViewEnable_Enter = ko.observable(false);
        ViewEnable_Confirm = ko.observable(false);
        ViewEnable_Finsh = ko.observable(false);

        // ���X���C��
        List: Array[] = ko.observableArray([]);
        FBCoin = ko.observable(0.00);
        FBCoinMaxChange = ko.observable(0.00);
        FBCoinExchange = ko.observable(0);

        // �����C��
        CityList = ko.observableArray([]);
        // �m�����C��
        ZoneList = ko.observableArray([]);
        // �u��m�W
        RealName = ko.observable('');
        // �ثe��ܪ������s��
        CityID = ko.observable(0);
        // �ثe��ܪ��m�����s��
        ZoneID = ko.observable('0');
        // �a�}
        Address = ko.observable('');
        // �q��
        Phone = ko.observable('');
        // �q�l�H�c
        Email = ko.observable('');
        // �m�W���~�T��
        RealNameErrorMessage = ko.observable('');
        // �a�}���~�T��
        AddressErrorMessage = ko.observable('');
        // �q�ܿ��~�T��
        PhoneErrorMessage = ko.observable('');
        // �q�l�H�c���~�T��
        EmailErrorMessage = ko.observable('');

        // �ԲӦa�}
        FullpnoAddress = ko.observable('');

        /// --------------------------------------
        /// function(private)
        /// --------------------------------------
        // ���o§�������C��
        private GetGiftReport(callback: Function = null): void {
            var self = this;
            var page = SGT.Pages.PageMgr.GetInstance(this.PageName);

            // �w�]��
            var data =
            {
                PageSize: page.PageSize()
                , PageIndex: page.PageIndex()
            };

            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/giftcenter",
                data: data,
                success: function (data) {
                    SGT['Main'].QueryFns[self.KoName].List(data.List);

                    // �]�w Page �`����
                    page.TotalRecord(data.TotalRecord);

                    self.FBCoin(data.FBCoin);
                    self.FBCoinMaxChange(data.FBCoinMaxChange);
                    self.FBCoinExchange(data.FBCoinExchange);
                },
                error: function (e) {
                    // alert(e.responseText);
                },
                complete: function (data) {
                    if (callback) {
                        callback();
                    }
                }
            });
        }

        // ���o�����w�]���(�u���@��)
        private GetDefaultData(): void {
            var self = this;

            this.CityList.unshift(this.DefaultCity);
            this.ZoneList.unshift(this.DefaultZone);

            // ���o�����C��
            $.ajax({
                type: "Get",
                url: "/Mvc/api/other/CityData",
                success: function (data) {
                    self.CityList(data);
                    self.CityList.unshift(self.DefaultCity);
                },
                error: function (e) {
                    // alert(e.responseText);
                }
            });

            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/getchangememberdetail",
                success: function (data) {
                    self.MyCityID = data.CityID;
                    self.MyZoneID = data.ZoneID;
                    self.MyAddress = data.Address;
                    self.MyRealName = data.RealName;
                    self.MyPhone = data.Phone;
                    self.MyEmail = data.Email;
                },
                error: function (e) {
                    //alerct(e.responseText);
                }
            });
        }

        /// --------------------------------------
        /// function(public) for ListView
        /// --------------------------------------
        // �N����������§���C���e��
        ToListView(): void {
            var self = this;

            this.ViewEnable(false);

            // ���] PageIndex
            SGT.Pages.PageMgr.GetInstance(this.PageName).PageIndex(1);

            // �d�߸��
            this.GetGiftReport(function () {
                window.location.hash = "top";

                self.ViewEnable_List(true);
                self.ViewEnable_Enter(false);
                self.ViewEnable_Confirm(false);
                self.ViewEnable_Finsh(false);

                self.ViewEnable(true);
            });
        }

        // �I��FB��
        ChangeFBCoin(): void {
            var self = this;

            if (self.FBCoinMaxChange() <= 0) {
                alert($SGT.Message.GiftCenter.Utility[0].format(self.FBCoinExchange()));
                return;
            }

            this.ViewEnable(false);

            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/changefbcoin",
                success: function (data) {
                    if (data.Message) {
                        alert(data.Message);
                    }

                    self.GetGiftReport();
                },
                error: function (e) {
                    // alert(e.responseText);
                },
                complete: function (data) {
                    self.ViewEnable(true);
                }
            });
        }

        // �I���ѹ�
        ChangeHCoin(row): void {
            if (!confirm($SGT.Message.GiftCenter.Utility[1])) {
                return;
            }

            this.ViewEnable(false);
            var self = this;

            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/changehcoin",
                data: { ExchangeID: row['ExchangeID'] },
                success: function (data) {
                    if (data.Message) {
                        alert(data.Message);
                    }

                    if (data.Code == 0) {
                        self.GetGiftReport();
                    }
                },
                error: function (e) {
                    // alert(e.responseText);
                },
                complete: function (data) {
                    self.ViewEnable(true);
                }
            });
        }

        /// --------------------------------------
        /// function(public) for EnterView
        /// --------------------------------------
        // �N����������ϥΪ̿�J�e��
        ToEnterView(row): void {
            // �����n�I�����s��
            this.MyExchangeID = row['ExchangeID'];

            // ��_��l���
            this.RealName(this.MyRealName);
            this.Phone(this.MyPhone);
            this.Email(this.MyEmail);
            this.CityID(this.MyCityID);
            this.ZoneID(this.MyZoneID);
            this.Address(this.MyAddress);

            window.location.hash = "top";

            this.ViewEnable_List(false);
            this.ViewEnable_Enter(true);
            this.ViewEnable_Confirm(false);
            this.ViewEnable_Finsh(false);
        }

        // �N���������^�ϥΪ̿�J�e��
        BackEnterView(): void {
            window.location.hash = "top";

            this.ViewEnable_List(false);
            this.ViewEnable_Enter(true);
            this.ViewEnable_Confirm(false);
            this.ViewEnable_Finsh(false);
        }

        // ���o�m�����C��
        SetZoneList(): void {
            var self = this;
            var cityId = this.CityID();

            // �s�W�s���
            $.each(this.CityList(), function (index, obj) {
                if (obj.CityID == cityId) {
                    self.ZoneList(obj.ZoneList);
                    self.ZoneList.unshift(self.DefaultZone);
                    return false;
                }
            });
        }

        // �M����J��
        ClearEnter(): void {
            this.RealName('');
            this.CityID(0);
            this.ZoneID('');
            this.Address('');
            this.Phone('');
            this.Email('');
        }

        // �m�W����
        ValidRealName(): bool {
            this.RealNameErrorMessage('');

            if ($.trim(this.RealName()) == '') {
                this.RealNameErrorMessage($SGT.Message.GiftCenter.Error[0]);
                return false;
            }

            return true;
        }

        // �a�}����
        ValidAddress(): bool {
            this.AddressErrorMessage('');

            if (this.ZoneID() == '') {
                this.AddressErrorMessage($SGT.Message.GiftCenter.Error[2]);
                return false;
            }
            if ($.trim(this.Address()) == '') {
                this.AddressErrorMessage($SGT.Message.GiftCenter.Error[3]);
                return false;
            }
            if (!/^[\u0391-\uFFE5a-zA-Z0-9\-]{1,40}$/.test(this.Address())) {
                this.AddressErrorMessage($SGT.Message.GiftCenter.Error[4]);
                return false;
            }

            return true;
        }

        // �q������
        ValidPhone(): bool {
            this.PhoneErrorMessage('');

            if (this.Phone() && !/^[0-9]{0,20}$/.test(this.Phone())) {
                this.PhoneErrorMessage($SGT.Message.GiftCenter.Error[5]);
                return false;
            }

            return true;
        }

        // �q�l�H�c����
        ValidEmail(): bool {
            this.EmailErrorMessage('');

            if ($.trim(this.Email()) == '') {
                this.EmailErrorMessage($SGT.Message.GiftCenter.Error[6]);
                return false;
            }
            else if (!/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(this.Email())) {
                this.EmailErrorMessage($SGT.Message.GiftCenter.Error[7]);
                return false;
            }

            return true;
        }

        /// --------------------------------------
        /// function(public) for ConfirmView
        /// --------------------------------------
        // �N����������T�{��J�e��
        ToConfirmView(): void {
            this.ViewEnable(false);

            var successCount = 0;
            successCount += this.ValidRealName() ? 1 : 0;
            successCount += this.ValidAddress() ? 1 : 0;
            successCount += this.ValidPhone() ? 1 : 0;
            successCount += this.ValidEmail() ? 1 : 0;

            if (successCount == 4) {
                var self = this;

                // ���o��ܿ����W��
                var cityId = this.CityID();
                var cityName = '';
                if (cityId != 0) {
                    $.each(this.CityList(), function (index, obj) {
                        if (obj.CityID == cityId) {
                            cityName = obj.CityName;
                            return false;
                        }
                    });
                }

                // ���o��ܶm�����W��
                var zoneId = this.ZoneID();
                var zoneName = '';
                if (zoneName != '') {
                    $.each(this.ZoneList(), function (index, obj) {
                        if (obj.ZoneID == zoneId) {
                            zoneName = obj.ZoneName;
                            return false;
                        }
                    });
                }

                // �զ��ԲӦa�}
                this.FullpnoAddress(cityName + zoneName + this.Address());

                window.location.hash = "top";

                this.ViewEnable_List(false);
                this.ViewEnable_Enter(false);
                this.ViewEnable_Confirm(true);
                this.ViewEnable_Finsh(false);
            }

            this.ViewEnable(true);
        }

        /// --------------------------------------
        /// function(public) for FinshView
        /// --------------------------------------
        // �N���������������ഫ�e��
        ToFinshView(): void {
            window.location.hash = "top";

            this.ViewEnable(false);

            var self = this;

            var data = {
                ExchangeID: this.MyExchangeID
                , ZoneID: this.ZoneID()
                , Address: this.Address()
                , RealName: this.RealName()
                , Phone: this.Phone()
                , Email: this.Email()
            };

            $.ajax({
                type: "Post",
                url: "/Mvc/api/member/changeentitygift",
                data: data,
                success: function (data) {
                    if (data.Message) {
                        alert(data.Message);
                    }

                    if (data.Code == 0) {
                        window.location.hash = "top";

                        self.ViewEnable_List(false);
                        self.ViewEnable_Enter(false);
                        self.ViewEnable_Confirm(false);
                        self.ViewEnable_Finsh(true);
                    } else {
                        self.ToListView();
                    }
                },
                error: function (e) {
                    //alerct(e.responseText);
                },
                complete: function (data) {
                    self.ViewEnable(true);
                }
            });
        }
    }
}