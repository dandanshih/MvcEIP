var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var QADetail = (function () {
            function QADetail() {
                this.QATitle = ko.observable('');
                this.QADesc = ko.observable('');
                this.QADate = ko.observable('');
                var qaid = getParameter('qaid');
                if(qaid && qaid.match(/^[0-9]+$/)) {
                    this.GetData(qaid);
                }
            }
            QADetail.prototype.GetData = function (qaid) {
                var obj = this;
                var data = {
                    qaId: qaid
                };
                $.ajax({
                    type: "Get",
                    url: "/Mvc/api/cscenter/qadetail",
                    data: data,
                    success: function (data) {
                        obj.QATitle(data.QATitle);
                        obj.QADesc(data.QADesc);
                        obj.QADate(data.QADate);
                    },
                    error: function (e) {
                    }
                });
            };
            return QADetail;
        })();
        DynamicPages.QADetail = QADetail;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;

})(SGT || (SGT = {}));

