declare var $;
declare var ko;

module SGT.DynamicPages {
    
    // �N���^�X
    export class Bug {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () { 
        }
        
        /// --------------------------------------
        /// ko
        /// --------------------------------------
        SubmitBtnEnable = ko.observable(true);
        ViewEnable_Enter = ko.observable(true);
        ViewEnable_Confirm = ko.observable(false);
        ViewEnable_Finsh = ko.observable(false);
        BugTypeID = ko.observable(0);
        BugTitle = ko.observable('');
        BugDesc = ko.observable('');
        ContactTel = ko.observable('');
        MsgMail = ko.observable('');
        
        /// --------------------------------------
        /// function
        /// --------------------------------------
        Clear() {
            this.BugTypeID(0);
            this.BugTitle('');
            this.BugDesc('');
            this.ContactTel('');
            this.MsgMail('');
        }
        ToEnterView() {
            this.ViewEnable_Enter(true);
            this.ViewEnable_Confirm(false);
            this.ViewEnable_Finsh(false);
        }
        ToComfirmView() {
            this.ViewEnable_Enter(false);
            this.ViewEnable_Confirm(true);
            this.ViewEnable_Finsh(false);
        }
        ToFinshView() {
            this.ViewEnable_Enter(false);
            this.ViewEnable_Confirm(false);
            this.ViewEnable_Finsh(true);
        }
        Comfirm() {
            if ($('#form1').valid()) {
                this.ToComfirmView();
            }
        }
        Submit() {
            var obj = this;

            // ��w���s
            obj.SubmitBtnEnable(false);
            var data = 
            {
                BugTypeID: obj.BugTypeID()
                , BugTitle: obj.BugTitle()
                , BugDesc: obj.BugDesc()
                , ContactTel: obj.ContactTel()
                , MsgMail: obj.MsgMail()
            };

            $.ajax({
		        type: "Post",
		        url: "/Mvc/api/cscenter/bug",
			    data: data,
		        success: function (data) {
                    // �Ѱ���w
                    obj.SubmitBtnEnable(true);

                    if (data != '') {
                        alert(data);
                    } else {
                        // �M����J���
                        obj.Clear();
                        // �ഫView
                        obj.ToFinshView();
                    }
		        },
		        error: function (e) {
			        // alert(e.responseText);
                    // �Ѱ���w
                    obj.SubmitBtnEnable(true);
		        }
	        });
        }
    }
}