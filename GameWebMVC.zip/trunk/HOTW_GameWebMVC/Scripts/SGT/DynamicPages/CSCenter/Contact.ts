declare var $;
declare var ko;

module SGT.DynamicPages {
    
    // �p���ڭ�
    export class Contact {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () { 
        }
        
        /// --------------------------------------
        /// ko
        /// --------------------------------------
        SubmitBtnEnable = ko.observable(true);
        ViewEnable_Enter = ko.observable(true);
        ViewEnable_Confirm = ko.observable(false);
        ViewEnable_Finsh = ko.observable(false);
        ContactTypeID = ko.observable(0);
        ContactTitle = ko.observable('');
        ContactDesc = ko.observable('');
        UserName = ko.observable('');
        UserTel = ko.observable('');
        UserEmail = ko.observable('');
        
        /// --------------------------------------
        /// function
        /// --------------------------------------
        Clear() {
            this.ContactTypeID(0);
            this.ContactTitle('');
            this.ContactDesc('');
            this.UserName('');
            this.UserTel('');
            this.UserEmail('');
        }
        ToEnterView() {
            this.ViewEnable_Enter(true);
            this.ViewEnable_Confirm(false);
            this.ViewEnable_Finsh(false);
        }
        ToComfirmView() {
            this.ViewEnable_Enter(false);
            this.ViewEnable_Confirm(true);
            this.ViewEnable_Finsh(false);
        }
        ToFinshView() {
            this.ViewEnable_Enter(false);
            this.ViewEnable_Confirm(false);
            this.ViewEnable_Finsh(true);
        }
        Comfirm() {
            if ($('#form1').valid()) {
                this.ToComfirmView();
            }
        }
        Submit() {
            var obj = this;

            // ��w���s
            obj.SubmitBtnEnable(false);
            var data = 
            {
                ContactTypeID: obj.ContactTypeID()
                , ContactTitle: obj.ContactTitle()
                , ContactDesc: obj.ContactDesc()
                , UserName: obj.UserName()
                , UserTel: obj.UserTel()
                , UserEmail: obj.UserEmail()
            };

            $.ajax({
		        type: "Post",
		        url: "/Mvc/api/cscenter/Contact",
			    data: data,
		        success: function (data) {
                    // �Ѱ���w
                    obj.SubmitBtnEnable(true);

                    if (data != '') {
                        alert(data);
                    } else {
                        // �M����J���
                        obj.Clear();
                        // �ഫView
                        obj.ToFinshView();
                    }
		        },
		        error: function (e) {
			        // alert(e.responseText);
                    // �Ѱ���w
                    obj.SubmitBtnEnable(true);
		        }
	        });
        }
    }
}