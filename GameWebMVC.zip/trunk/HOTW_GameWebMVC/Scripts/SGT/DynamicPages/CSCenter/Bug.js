var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Bug = (function () {
            function Bug() {
                this.SubmitBtnEnable = ko.observable(true);
                this.ViewEnable_Enter = ko.observable(true);
                this.ViewEnable_Confirm = ko.observable(false);
                this.ViewEnable_Finsh = ko.observable(false);
                this.BugTypeID = ko.observable(0);
                this.BugTitle = ko.observable('');
                this.BugDesc = ko.observable('');
                this.ContactTel = ko.observable('');
                this.MsgMail = ko.observable('');
            }
            Bug.prototype.Clear = function () {
                this.BugTypeID(0);
                this.BugTitle('');
                this.BugDesc('');
                this.ContactTel('');
                this.MsgMail('');
            };
            Bug.prototype.ToEnterView = function () {
                this.ViewEnable_Enter(true);
                this.ViewEnable_Confirm(false);
                this.ViewEnable_Finsh(false);
            };
            Bug.prototype.ToComfirmView = function () {
                this.ViewEnable_Enter(false);
                this.ViewEnable_Confirm(true);
                this.ViewEnable_Finsh(false);
            };
            Bug.prototype.ToFinshView = function () {
                this.ViewEnable_Enter(false);
                this.ViewEnable_Confirm(false);
                this.ViewEnable_Finsh(true);
            };
            Bug.prototype.Comfirm = function () {
                if($('#form1').valid()) {
                    this.ToComfirmView();
                }
            };
            Bug.prototype.Submit = function () {
                var obj = this;
                obj.SubmitBtnEnable(false);
                var data = {
                    BugTypeID: obj.BugTypeID(),
                    BugTitle: obj.BugTitle(),
                    BugDesc: obj.BugDesc(),
                    ContactTel: obj.ContactTel(),
                    MsgMail: obj.MsgMail()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/cscenter/bug",
                    data: data,
                    success: function (data) {
                        obj.SubmitBtnEnable(true);
                        if(data != '') {
                            alert(data);
                        } else {
                            obj.Clear();
                            obj.ToFinshView();
                        }
                    },
                    error: function (e) {
                        obj.SubmitBtnEnable(true);
                    }
                });
            };
            return Bug;
        })();
        DynamicPages.Bug = Bug;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;

})(SGT || (SGT = {}));

