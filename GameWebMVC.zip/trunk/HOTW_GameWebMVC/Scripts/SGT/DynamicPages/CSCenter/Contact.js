var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Contact = (function () {
            function Contact() {
                this.SubmitBtnEnable = ko.observable(true);
                this.ViewEnable_Enter = ko.observable(true);
                this.ViewEnable_Confirm = ko.observable(false);
                this.ViewEnable_Finsh = ko.observable(false);
                this.ContactTypeID = ko.observable(0);
                this.ContactTitle = ko.observable('');
                this.ContactDesc = ko.observable('');
                this.UserName = ko.observable('');
                this.UserTel = ko.observable('');
                this.UserEmail = ko.observable('');
            }
            Contact.prototype.Clear = function () {
                this.ContactTypeID(0);
                this.ContactTitle('');
                this.ContactDesc('');
                this.UserName('');
                this.UserTel('');
                this.UserEmail('');
            };
            Contact.prototype.ToEnterView = function () {
                this.ViewEnable_Enter(true);
                this.ViewEnable_Confirm(false);
                this.ViewEnable_Finsh(false);
            };
            Contact.prototype.ToComfirmView = function () {
                this.ViewEnable_Enter(false);
                this.ViewEnable_Confirm(true);
                this.ViewEnable_Finsh(false);
            };
            Contact.prototype.ToFinshView = function () {
                this.ViewEnable_Enter(false);
                this.ViewEnable_Confirm(false);
                this.ViewEnable_Finsh(true);
            };
            Contact.prototype.Comfirm = function () {
                if($('#form1').valid()) {
                    this.ToComfirmView();
                }
            };
            Contact.prototype.Submit = function () {
                var obj = this;
                obj.SubmitBtnEnable(false);
                var data = {
                    ContactTypeID: obj.ContactTypeID(),
                    ContactTitle: obj.ContactTitle(),
                    ContactDesc: obj.ContactDesc(),
                    UserName: obj.UserName(),
                    UserTel: obj.UserTel(),
                    UserEmail: obj.UserEmail()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/cscenter/Contact",
                    data: data,
                    success: function (data) {
                        obj.SubmitBtnEnable(true);
                        if(data != '') {
                            alert(data);
                        } else {
                            obj.Clear();
                            obj.ToFinshView();
                        }
                    },
                    error: function (e) {
                        obj.SubmitBtnEnable(true);
                    }
                });
            };
            return Contact;
        })();
        DynamicPages.Contact = Contact;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;

})(SGT || (SGT = {}));

