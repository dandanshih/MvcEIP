declare var $;
declare var ko;
declare var getParameter;

module SGT.DynamicPages {
    
    // �`�����D����
    export class QADetail {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {
            var qaid = getParameter('qaid');
            if (qaid && qaid.match(/^[0-9]+$/)) {
                this.GetData(qaid);
            }
        }

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // ���D���D
        QATitle = ko.observable('');
        // ���D���e
        QADesc = ko.observable('');
        // ���D���
        QADate = ko.observable('');

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ���o���
        private GetData(qaid: number):void {
            var obj = this;

            // �w�]��
            var data =
            {
                qaId: qaid
            };

            $.ajax({
		        type: "Get",
		        url: "/Mvc/api/cscenter/qadetail",
		        data: data,
		        success: function (data) {

		            obj.QATitle(data.QATitle);
		            obj.QADesc(data.QADesc);
		            obj.QADate(data.QADate);
		        },
		        error: function (e) {
			        // alert(e.responseText);
		        }
	        });
        }
    }
}