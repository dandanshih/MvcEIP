var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var QA = (function () {
            function QA(koName, pageName) {
                if (typeof koName === "undefined") { koName = 'QAList'; }
                if (typeof pageName === "undefined") { pageName = 'QAPage'; }
                this.PageName = '';
                this.KoName = '';
                this.QAType = ko.observable(0);
                this.Keyword = ko.observable('');
                this.List = ko.observableArray([]);
                this.KoName = koName;
                this.PageName = pageName;
                var obj = this;
                SGT.Pages.PageMgr.Add(this.PageName, new SGT.Pages.Page(function () {
                    obj.GetData();
                }));
            }
            QA.prototype.Query = function (qaType, callback) {
                if (typeof qaType === "undefined") { qaType = this.QAType(); }
                if (typeof callback === "undefined") { callback = null; }
                this.QAType(qaType);
                SGT.Pages.PageMgr.GetInstance(this.PageName).PageIndex(1);
                this.GetData();
                if(callback) {
                    callback(qaType);
                }
            };
            QA.prototype.GetData = function () {
                var self = this;
                var page = SGT.Pages.PageMgr.GetInstance(this.PageName);
                var data = {
                    QAType: this.QAType(),
                    Keyword: this.Keyword(),
                    PageSize: page.PageSize(),
                    PageIndex: page.PageIndex()
                };
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/cscenter/qa",
                    data: data,
                    success: function (data) {
                        SGT['Main'].QueryFns[self.KoName].List.splice(0, SGT['Main'].QueryFns[self.KoName].List().length);
                        $.each(data.List, function (index, obj) {
                            SGT['Main'].QueryFns[self.KoName].List.push(obj);
                        });
                        page.TotalRecord(data.TotalRecord);
                    },
                    error: function (e) {
                    }
                });
            };
            return QA;
        })();
        DynamicPages.QA = QA;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
