/// <reference path="../../Pages/Shared/SGTPage.ts" />

declare var $;
declare var ko;

module SGT.DynamicPages {
    
    // �`�����D
    export class QA {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (koName: string = 'QAList', pageName: string = 'QAPage') {
            this.KoName = koName;
            this.PageName = pageName;
            
            var obj = this;

            // New �@�ӷs�� Page Instance�A�åB�w�q ChangeEvent �����ƥ�
            SGT.Pages.PageMgr.Add(this.PageName, new SGT.Pages.Page(function () {
                obj.GetData();
            }));
        }
        
        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private PageName: string = '';
        private KoName: string = '';

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �d�����O
        QAType = ko.observable(0);
        // �d�ߦr��
        Keyword = ko.observable('');
        // ���X�����D�C��
        List: Array[] = ko.observableArray([]);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // �d�ߨƥ�
        Query(qaType: number = this.QAType(), callback: Function = null): void {
            // �]�w�d�ߺ���
            this.QAType(qaType);
            // ���] PageIndex
            SGT.Pages.PageMgr.GetInstance(this.PageName).PageIndex(1);
            // �d�߸��
            this.GetData();

            if (callback) {
                callback(qaType);
            }
        }

        // ���o���
        private GetData(): void {
            var self = this;
            var page = SGT.Pages.PageMgr.GetInstance(this.PageName);

            // �w�]��
            var data =
            {
                QAType: this.QAType()
                , Keyword: this.Keyword()
                , PageSize: page.PageSize()
                , PageIndex: page.PageIndex()
            };

            $.ajax({
                type: "Post",
                url: "/Mvc/api/cscenter/qa",
                data: data,
                success: function (data) {
                    // �R���¸��
                    SGT['Main'].QueryFns[self.KoName].List.splice(0, SGT['Main'].QueryFns[self.KoName].List().length)

                    // �s�W�s���
                    $.each(data.List, function (index, obj) { SGT['Main'].QueryFns[self.KoName].List.push(obj); });

                    // �]�w Page �`����
                    page.TotalRecord(data.TotalRecord);
                },
                error: function (e) {
                    // alert(e.responseText);
                }
            });
        }
    }
}