﻿/// <reference path="../HotActive/Base/BaseMobileVerificationByActive.ts" />

declare var $: any;
declare var ko: any;
declare var GetPlatform;
declare var OpenLink;
declare var closecolorbox: any;
declare var closecolorboxreload: any;

module SGT.DynamicPages {
    export class MobileVerificationByActive extends BaseMobileVerificationByActive {
        //是否登入
        Action: (input?: string) => string = ko.observable("1");
        ErrerMsg: (input?: string) => string = ko.observable("");
        phoneNumber: (input?: string) => string = ko.observable("");
        phoneType: (input?: bool) => bool = ko.observable(false);
        codeString: (input?: string) => string = ko.observable("");

        constructor() {
            super();
        }

        public getLucky(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform },
                url: '/MVC/api/HotActive/CheckPlayerQualificationsByActive',
                async: false,
                success: function (data) {
                    var ResultCode = data.Result.Result;
                    var ResultSting = data.Result.ResultMsg;

                    switch (ResultCode) {
                        case -1:
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                            break;
                        case 111:
                            OpenLink('/mvc/StaticPages/web/ActionPage/ActionNoviceLucky/Iframe');
                            break;
                        case 0:
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                            break;
                        case 2:
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                            break;
                        case 1:
                            var url = '/mvc/StaticPages/' + platform + '/ActionPage/ActionNoviceLucky/PhoneCheck?index=1'
                            OpenLink(url);
                            break;
                        case 4:
                            var url = '/mvc/StaticPages/' + platform + '/ActionPage/ActionNoviceLucky/PhoneCheck?index=2'
                            OpenLink(url);
                            break;
                        default:
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                    }
                },
                error: function (ex) {
                }
            });
        }

        public checkPhone(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            self.ErrerMsg("");
            if (self.phoneNumber().length > 0) {
                if (!self.phoneNumber().match(/^[09]{2}[0-9]{8}$/)) {
                    self.phoneType(false);
                    self.ErrerMsg("手機號碼格式錯誤");
                    $("#Isok").hide();
                }
                else {
                    $("#Isok").show();

                    self.phoneType(true);
                    /*
                    $.ajax({
                        type: "POST",
                        async: false,
                        url: "/AppAjaxs/RegisterValidation.ashx",
                        data: { "ResultType": "2", "CheckType": "3", "CheckData": self.phoneNumber() },
                        success: function (data) {
                            if (data == "Success") {
                                self.phoneType(true);
                                self.ErrerMsg("手機號碼可以使用");
                            } else {
                                self.ErrerMsg("手機號碼已重複");
                            }
                        },
                        error: function (e) {
    
                        }
                    });
                    */
                }
            } else {
                $("#Isok").hide();
                self.ErrerMsg("");
            }
        }
        //送出號碼
        public sendPhone(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            if (self.phoneType() == true && self.phoneNumber().match(/^[09]{2}[0-9]{8}$/)) {
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: { Platform: platform, Mobile: self.phoneNumber() },
                    url: '/MVC/api/HotActive/SendSMSByActive',
                    async: false,
                    success: function (data) {
                        var ResultCode = data.Result.Result;
                        var ResultSting = data.Result.ResultMsg;
                        if (ResultCode == 1) {
                            $.ajax({
                                type: 'POST',
                                dataType: "json",
                                data: { Platform: platform },
                                url: '/MVC/api/HotActive/GetVerifyCodeByActive',
                                async: false,
                                success: function (data) {
                                    self.codeString(data.Result);
                                },
                                error: function (ex) {
                                    alert("err");
                                }
                            });
                            self.Action("2");
                        }
                        else {
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                        }
                    },
                    error: function (ex) {
                        alert("err");
                    }
                });
            } else if (self.phoneNumber() == "") {
                self.ErrerMsg("手機號碼不可空白");
            }


        }

        //送出號碼
        public reSendcodeString(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform },
                url: '/MVC/api/HotActive/GetVerifyCodeByActive',
                async: false,
                success: function (data) {
                    self.codeString(data.Result);
                },
                error: function (ex) {
                    alert("err");
                }
            });
        }

        //重新輸入
        public reInput(): void {
            var self = this;
            self.ErrerMsg("");
            self.phoneType(false);
            self.phoneNumber("");
            $("#Isok").hide();
        }
        //送出認證
        public sendCode(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }
            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform, VerifyCode: self.codeString() },
                url: '/MVC/api/HotActive/VerifyVerificationCodeByActive',
                async: false,
                success: function (data) {
                    var ResultCode = data.Result.Result;
                    var ResultSting = data.Result.ResultMsg;
                    if (ResultCode == 1) {
                        self.Action("4");
                    } else if (ResultCode == 6) {
                        alert(self.SwitchResultMessage(ResultCode, ResultSting));
                        self.phoneNumber("");
                        self.phoneType(false);
                        self.codeString("");
                        self.Action("1");
                    } else if (ResultCode == 111) {
                        alert(self.SwitchResultMessage(ResultCode, ResultSting));
                        closecolorboxreload();
                        closecolorbox();
                    }
                    else {
                        alert(self.SwitchResultMessage(ResultCode, ResultSting));
                    }
                },
                error: function (ex) {
                    alert("err");
                }
            });
        }

        //取消認證
        public cancel(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }


            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform },
                url: '/MVC/api/HotActive/CancelVerifyVerificationCodeByActive',
                async: false,
                success: function (data) {
                    var ResultCode = data.Result.Result;
                    var ResultSting = data.Result.ResultMsg;
                    if (ResultCode == 1) {
                        closecolorbox();
                    } else {
                        alert(self.SwitchResultMessage(ResultCode, ResultSting));
                    }
                },
                error: function (ex) {
                    alert("err");
                }
            });

        }
        //重發
        public reSend(): void {
            var self = this;
            var platform: string = "Web";
            if (typeof GetPlatform == "function") {
                platform = GetPlatform();
            }

            $.ajax({
                type: 'POST',
                dataType: "json",
                data: { Platform: platform, Mobile: self.phoneNumber() },
                url: '/MVC/api/HotActive/SendSMSByActive',
                async: false,
                success: function (data) {
                    var ResultCode = data.Result.Result;
                    var ResultSting = data.Result.ResultMsg;
                    if (ResultCode == 1) {
                        $.ajax({
                            type: 'POST',
                            dataType: "json",
                            data: { Platform: platform },
                            url: '/MVC/api/HotActive/GetVerifyCodeByActive',
                            async: false,
                            success: function (data) {
                                self.codeString(data.Result);
                                alert("驗證碼已發出，請檢查您的手機並儘速完成驗證!");
                            },
                            error: function (ex) {
                                alert("err");
                            }
                        });
                    } else {
                        alert(self.SwitchResultMessage(ResultCode, ResultSting));
                    }

                },
                error: function (ex) {
                    alert("err");
                }
            });
        }

        public back(): void {
            var self = this;
            self.Action("2");
        }

        public next(): void {
            var self = this;
            self.Action("3");
        }
    }

}