﻿var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var MobileVerificationByActive = (function (_super) {
            __extends(MobileVerificationByActive, _super);
            function MobileVerificationByActive() {
                        _super.call(this);
                this.Action = ko.observable("1");
                this.ErrerMsg = ko.observable("");
                this.phoneNumber = ko.observable("");
                this.phoneType = ko.observable(false);
                this.codeString = ko.observable("");
            }
            MobileVerificationByActive.prototype.getLucky = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform
                    },
                    url: '/MVC/api/HotActive/CheckPlayerQualificationsByActive',
                    async: false,
                    success: function (data) {
                        var ResultCode = data.Result.Result;
                        var ResultSting = data.Result.ResultMsg;
                        switch(ResultCode) {
                            case -1:
                                alert(self.SwitchResultMessage(ResultCode, ResultSting));
                                break;
                            case 111:
                                OpenLink('/mvc/StaticPages/web/ActionPage/ActionNoviceLucky/Iframe');
                                break;
                            case 0:
                                alert(self.SwitchResultMessage(ResultCode, ResultSting));
                                break;
                            case 2:
                                alert(self.SwitchResultMessage(ResultCode, ResultSting));
                                break;
                            case 1:
                                var url = '/mvc/StaticPages/' + platform + '/ActionPage/ActionNoviceLucky/PhoneCheck?index=1';
                                OpenLink(url);
                                break;
                            case 4:
                                var url = '/mvc/StaticPages/' + platform + '/ActionPage/ActionNoviceLucky/PhoneCheck?index=2';
                                OpenLink(url);
                                break;
                            default:
                                alert(self.SwitchResultMessage(ResultCode, ResultSting));
                        }
                    },
                    error: function (ex) {
                    }
                });
            };
            MobileVerificationByActive.prototype.checkPhone = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                self.ErrerMsg("");
                if(self.phoneNumber().length > 0) {
                    if(!self.phoneNumber().match(/^[09]{2}[0-9]{8}$/)) {
                        self.phoneType(false);
                        self.ErrerMsg("手機號碼格式錯誤");
                        $("#Isok").hide();
                    } else {
                        $("#Isok").show();
                        self.phoneType(true);
                    }
                } else {
                    $("#Isok").hide();
                    self.ErrerMsg("");
                }
            };
            MobileVerificationByActive.prototype.sendPhone = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                if(self.phoneType() == true && self.phoneNumber().match(/^[09]{2}[0-9]{8}$/)) {
                    $.ajax({
                        type: 'POST',
                        dataType: "json",
                        data: {
                            Platform: platform,
                            Mobile: self.phoneNumber()
                        },
                        url: '/MVC/api/HotActive/SendSMSByActive',
                        async: false,
                        success: function (data) {
                            var ResultCode = data.Result.Result;
                            var ResultSting = data.Result.ResultMsg;
                            if(ResultCode == 1) {
                                $.ajax({
                                    type: 'POST',
                                    dataType: "json",
                                    data: {
                                        Platform: platform
                                    },
                                    url: '/MVC/api/HotActive/GetVerifyCodeByActive',
                                    async: false,
                                    success: function (data) {
                                        self.codeString(data.Result);
                                    },
                                    error: function (ex) {
                                        alert("err");
                                    }
                                });
                                self.Action("2");
                            } else {
                                alert(self.SwitchResultMessage(ResultCode, ResultSting));
                            }
                        },
                        error: function (ex) {
                            alert("err");
                        }
                    });
                } else if(self.phoneNumber() == "") {
                    self.ErrerMsg("手機號碼不可空白");
                }
            };
            MobileVerificationByActive.prototype.reSendcodeString = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform
                    },
                    url: '/MVC/api/HotActive/GetVerifyCodeByActive',
                    async: false,
                    success: function (data) {
                        self.codeString(data.Result);
                    },
                    error: function (ex) {
                        alert("err");
                    }
                });
            };
            MobileVerificationByActive.prototype.reInput = function () {
                var self = this;
                self.ErrerMsg("");
                self.phoneType(false);
                self.phoneNumber("");
                $("#Isok").hide();
            };
            MobileVerificationByActive.prototype.sendCode = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        VerifyCode: self.codeString()
                    },
                    url: '/MVC/api/HotActive/VerifyVerificationCodeByActive',
                    async: false,
                    success: function (data) {
                        var ResultCode = data.Result.Result;
                        var ResultSting = data.Result.ResultMsg;
                        if(ResultCode == 1) {
                            self.Action("4");
                        } else if(ResultCode == 6) {
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                            self.phoneNumber("");
                            self.phoneType(false);
                            self.codeString("");
                            self.Action("1");
                        } else if(ResultCode == 111) {
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                            closecolorboxreload();
                            closecolorbox();
                        } else {
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                        }
                    },
                    error: function (ex) {
                        alert("err");
                    }
                });
            };
            MobileVerificationByActive.prototype.cancel = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform
                    },
                    url: '/MVC/api/HotActive/CancelVerifyVerificationCodeByActive',
                    async: false,
                    success: function (data) {
                        var ResultCode = data.Result.Result;
                        var ResultSting = data.Result.ResultMsg;
                        if(ResultCode == 1) {
                            closecolorbox();
                        } else {
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                        }
                    },
                    error: function (ex) {
                        alert("err");
                    }
                });
            };
            MobileVerificationByActive.prototype.reSend = function () {
                var self = this;
                var platform = "Web";
                if(typeof GetPlatform == "function") {
                    platform = GetPlatform();
                }
                $.ajax({
                    type: 'POST',
                    dataType: "json",
                    data: {
                        Platform: platform,
                        Mobile: self.phoneNumber()
                    },
                    url: '/MVC/api/HotActive/SendSMSByActive',
                    async: false,
                    success: function (data) {
                        var ResultCode = data.Result.Result;
                        var ResultSting = data.Result.ResultMsg;
                        if(ResultCode == 1) {
                            $.ajax({
                                type: 'POST',
                                dataType: "json",
                                data: {
                                    Platform: platform
                                },
                                url: '/MVC/api/HotActive/GetVerifyCodeByActive',
                                async: false,
                                success: function (data) {
                                    self.codeString(data.Result);
                                    alert("驗證碼已發出，請檢查您的手機並儘速完成驗證!");
                                },
                                error: function (ex) {
                                    alert("err");
                                }
                            });
                        } else {
                            alert(self.SwitchResultMessage(ResultCode, ResultSting));
                        }
                    },
                    error: function (ex) {
                        alert("err");
                    }
                });
            };
            MobileVerificationByActive.prototype.back = function () {
                var self = this;
                self.Action("2");
            };
            MobileVerificationByActive.prototype.next = function () {
                var self = this;
                self.Action("3");
            };
            return MobileVerificationByActive;
        })(DynamicPages.BaseMobileVerificationByActive);
        DynamicPages.MobileVerificationByActive = MobileVerificationByActive;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
