declare var $SGT;
declare var SGT;
declare var ko;
declare var $;

module SGT.HotActive {
    // ���w§��T���o
    export class VipMarioGift {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor(koName: string = 'VipMarioGift') {
            this.KoName = koName;

            // ���o�C��
            this.GetGiftDate();
        }
        
        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';
        // ���s�O�_�ҥΡA�d�߮ɶ��|����
        private IsQuerying: bool = false;

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �ثe�d�ߪ����
        CurrentDate = ko.observable("");
        // VIP�d�O���ʤ���C��
        DateList = ko.observableArray([]);
        // VIP�d�O��������W��
        WinnersList = ko.observableArray([]);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ���oVIP�d�O���ʤ���C�����
        private GetGiftDate(){
            var self = this;

            $.ajax({
                type: "Post",
                url: "/Mvc/api/HotActive/GetVipMarioGiftDate",
                success: function (data) {
                    self.DateList(data);
                    if (data.length > 0) {
                        self.QueryWinners(data[0]);
                    }
                },
                error: function (e) {
                    //alert(e.responseText);
                },
                complete: function (data) {
                }
            });
        }

        // �d��VIP�d�O��������W��
        QueryWinners(rcDate: string) {
            var self = this;

            if (rcDate == self.CurrentDate() || self.IsQuerying) {
                return;
            }

            self.IsQuerying = true;

            $.ajax({
                type: "Post",
                url: "/Mvc/api/HotActive/GetVipMarioGiftWinners",
                data: { DataDate: rcDate },
                success: function (data) {
                    self.CurrentDate(rcDate);
                    self.WinnersList(data);
                },
                error: function (e) {
                    //alert(e.responseText);
                },
                complete: function (data) {
                    self.IsQuerying = false;
                }
            });
        }
    }
}