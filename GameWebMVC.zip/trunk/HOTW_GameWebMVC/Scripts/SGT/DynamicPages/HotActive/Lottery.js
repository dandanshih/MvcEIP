var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Lottery = (function () {
            function Lottery() {
                this.PhaseName = '';
                this.IsWinning = ko.observable(true);
                this.LottoDate = ko.observableArray([]);
                this.LotteryInfo = ko.observable(null);
                this.LotteryList = ko.observableArray([]);
                var self = this;
                this.GetLottoDate();
            }
            Lottery.prototype.GetLottoDate = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/hotactive/LottoDate",
                    success: function (data) {
                        self.LottoDate(data);
                        var phaseName = getParameter('PhaseName');
                        if(!phaseName && self.LottoDate().length != 0) {
                            phaseName = self.LottoDate()[0].PhaseName;
                        }
                        self.PhaseName = phaseName;
                        self.GetLotteryData();
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                    }
                });
            };
            Lottery.prototype.GetLotteryData = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/hotactive/LottoLotteryData",
                    data: {
                        PhaseName: self.PhaseName
                    },
                    success: function (data) {
                        self.LotteryInfo(data.LotteryInfo);
                        self.LotteryList(data.LotteryList);
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                    }
                });
            };
            Lottery.prototype.QueryLotteryData = function (row) {
                this.PhaseName = row["PhaseName"];
                this.GetLotteryData();
            };
            return Lottery;
        })();
        DynamicPages.Lottery = Lottery;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
