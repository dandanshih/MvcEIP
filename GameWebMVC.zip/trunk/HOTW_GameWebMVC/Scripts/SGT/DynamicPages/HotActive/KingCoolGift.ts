declare var $SGT;
declare var SGT;
declare var ko;
declare var $;

module SGT.HotActive {
    // ���w§��T���o
    export class KingCoolGift {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor(koName: string = 'KingCoolGift', typeId: number = 0) {
            this.KoName = koName;
            this.TypeID = typeId;

            // ���o�C��
            this.GetDetail();
        }
        
        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private KoName: string = '';
        private TypeID: number = 0;
        private DetailSource: Object[] = [];

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �ثe�d�ߪ�GroupName
        CurrentGroupName = ko.observable("");
        // ���w§��§�����O�C��
        GroupNameList = ko.observableArray([]);
        // ���w§��§������
        WinnersList = ko.observableArray([]);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ���o���w§��§�����
        private GetDetail(){
            var self = this;

            $.ajax({
                type: "Post",
                url: "/Mvc/api/HotActive/KingCoolGiftList",
                data: { TypeID: self.TypeID },
                success: function (data) {
                    self.GroupNameList(data.Master);
                    self.DetailSource = data.Detail;
                    if (data.Master && data.Master.length > 0) {
                        self.Query(data.Master[0]);
                    }
                },
                error: function (e) {
                    //alert(e.responseText);
                },
                complete: function (data) {
                }
            });
        }

        // �d��
        Query(groupName: string) {
            var self = this;

            $.each(self.DetailSource, function (index, obj) {
                if (obj['GroupName'] == groupName) {
                    self.CurrentGroupName(obj.GroupName);
                    self.WinnersList(obj.List);
                }
            });
        }
    }
}