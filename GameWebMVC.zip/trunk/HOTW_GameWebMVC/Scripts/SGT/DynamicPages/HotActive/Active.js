var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var Active = (function () {
            function Active(platform, koName) {
                if (typeof koName === "undefined") { koName = 'Active'; }
                this.Platform = 1;
                this.KoName = '';
                this.ActiveList = ko.observableArray([]);
                this.Platform = platform;
                this.KoName = koName;
                var self = this;
                this.GetActiveList();
            }
            Active.prototype.GetActiveList = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/hotactive/Active",
                    data: {
                        Type: 2,
                        Platform: self.Platform
                    },
                    success: function (data) {
                        self.ActiveList(data);
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                    }
                });
            };
            return Active;
        })();
        DynamicPages.Active = Active;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;

})(SGT || (SGT = {}));

