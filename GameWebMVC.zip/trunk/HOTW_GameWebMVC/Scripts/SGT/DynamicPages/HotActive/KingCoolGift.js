var SGT;
(function (SGT) {
    (function (HotActive) {
        var KingCoolGift = (function () {
            function KingCoolGift(koName, typeId) {
                if (typeof koName === "undefined") { koName = 'KingCoolGift'; }
                if (typeof typeId === "undefined") { typeId = 0; }
                this.KoName = '';
                this.TypeID = 0;
                this.DetailSource = [];
                this.CurrentGroupName = ko.observable("");
                this.GroupNameList = ko.observableArray([]);
                this.WinnersList = ko.observableArray([]);
                this.KoName = koName;
                this.TypeID = typeId;
                this.GetDetail();
            }
            KingCoolGift.prototype.GetDetail = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/HotActive/KingCoolGiftList",
                    data: {
                        TypeID: self.TypeID
                    },
                    success: function (data) {
                        self.GroupNameList(data.Master);
                        self.DetailSource = data.Detail;
                        if(data.Master && data.Master.length > 0) {
                            self.Query(data.Master[0]);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                    }
                });
            };
            KingCoolGift.prototype.Query = function (groupName) {
                var self = this;
                $.each(self.DetailSource, function (index, obj) {
                    if(obj['GroupName'] == groupName) {
                        self.CurrentGroupName(obj.GroupName);
                        self.WinnersList(obj.List);
                    }
                });
            };
            return KingCoolGift;
        })();
        HotActive.KingCoolGift = KingCoolGift;        
    })(SGT.HotActive || (SGT.HotActive = {}));
    var HotActive = SGT.HotActive;
})(SGT || (SGT = {}));
