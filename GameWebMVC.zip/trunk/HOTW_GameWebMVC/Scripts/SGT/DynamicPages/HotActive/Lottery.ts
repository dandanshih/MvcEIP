declare var SGT;
declare var $SGT;
declare var $;
declare var ko;
declare var getParameter;

module SGT.DynamicPages {

    // �Ѥl�j�ֳz
    export class Lottery {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor () {
            var self = this;

            // ���o�w�]���
            this.GetLottoDate();
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        // �ثe�d�߼ֳz����
        private PhaseName: string = '';

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �O�_��ܱm�����
        IsWinning = ko.observable(true);
        // �ֳz����C��
        LottoDate = ko.observableArray([]);
        // �S�w���Ƽֳz�I����T
        LotteryInfo = ko.observable(null);
        // �S�w���Ƽֳz�o���W��
        LotteryList = ko.observableArray([]);

        /// --------------------------------------
        /// function(private)
        /// --------------------------------------
        // ���o����C��
        private GetLottoDate(): void {
            var self = this;

            $.ajax({
                type: "Post",
                url: "/Mvc/api/hotactive/LottoDate",
                success: function (data) {
                    self.LottoDate(data);

                    var phaseName = getParameter('PhaseName');
                    if (!phaseName && self.LottoDate().length != 0) {
                        phaseName = self.LottoDate()[0].PhaseName;
                    }

                    self.PhaseName = phaseName;
                    self.GetLotteryData();
                },
                error: function (e) {
                    // alert(e.responseText);
                },
                complete: function (data) {
                }
            });
        }

        // ���o�I����T�P����W��
        private GetLotteryData(): void {
            var self = this;

            $.ajax({
                type: "Post",
                url: "/Mvc/api/hotactive/LottoLotteryData",
                data: { PhaseName: self.PhaseName },
                success: function (data) {
                    self.LotteryInfo(data.LotteryInfo);
                    self.LotteryList(data.LotteryList);
                },
                error: function (e) {
                    // alert(e.responseText);
                },
                complete: function (data) {
                }
            });
        }
        
        /// --------------------------------------
        /// function(public)
        /// --------------------------------------
        // �d�߱o��������T
        QueryLotteryData(row): void {
            this.PhaseName = row["PhaseName"];
            this.GetLotteryData();
        }
    }
}