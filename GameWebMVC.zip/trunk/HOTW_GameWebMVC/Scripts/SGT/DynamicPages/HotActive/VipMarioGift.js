var SGT;
(function (SGT) {
    (function (HotActive) {
        var VipMarioGift = (function () {
            function VipMarioGift(koName) {
                if (typeof koName === "undefined") { koName = 'VipMarioGift'; }
                this.KoName = '';
                this.IsQuerying = false;
                this.CurrentDate = ko.observable("");
                this.DateList = ko.observableArray([]);
                this.WinnersList = ko.observableArray([]);
                this.KoName = koName;
                this.GetGiftDate();
            }
            VipMarioGift.prototype.GetGiftDate = function () {
                var self = this;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/HotActive/GetVipMarioGiftDate",
                    success: function (data) {
                        self.DateList(data);
                        if(data.length > 0) {
                            self.QueryWinners(data[0]);
                        }
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                    }
                });
            };
            VipMarioGift.prototype.QueryWinners = function (rcDate) {
                var self = this;
                if(rcDate == self.CurrentDate() || self.IsQuerying) {
                    return;
                }
                self.IsQuerying = true;
                $.ajax({
                    type: "Post",
                    url: "/Mvc/api/HotActive/GetVipMarioGiftWinners",
                    data: {
                        DataDate: rcDate
                    },
                    success: function (data) {
                        self.CurrentDate(rcDate);
                        self.WinnersList(data);
                    },
                    error: function (e) {
                    },
                    complete: function (data) {
                        self.IsQuerying = false;
                    }
                });
            };
            return VipMarioGift;
        })();
        HotActive.VipMarioGift = VipMarioGift;        
    })(SGT.HotActive || (SGT.HotActive = {}));
    var HotActive = SGT.HotActive;
})(SGT || (SGT = {}));
