﻿var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var BaseMobileVerificationByActive = (function () {
            function BaseMobileVerificationByActive() {
            }
            BaseMobileVerificationByActive.prototype.SwitchResultMessage = function (input, inputParam) {
                var result = "";
                switch(input) {
                    case -2:
                        result = "您的遊戲帳號不符合領獎條件，請重新確認活動方式!";
                        break;
                    case -1:
                        result = "活動已經結束!";
                        break;
                    case 0:
                        result = "手機號碼已被使用!";
                        break;
                    case 1:
                        result = "遊戲帳號符合資格!";
                        break;
                    case 2:
                        result = "您的遊戲帳號已於" + inputParam + "領取過新手福袋囉!";
                        break;
                    case 3:
                        result = "取消驗證，等候中!";
                        break;
                    case 4:
                        result = "驗證碼已發出，請檢查您的手機並儘速完成驗證!";
                        break;
                    case 5:
                        result = "驗證碼發送次數已經超過三次，無法再發送，請檢查您的手機!";
                        break;
                    case 6:
                        result = "驗證碼逾期，請重新輸入手機!";
                        break;
                    case 7:
                        result = "驗證碼錯誤!";
                        break;
                    case 9:
                        result = "發生錯誤!";
                        break;
                    case 111:
                        result = "請登入會員!";
                        break;
                    case 112:
                        result = "手機號碼輸入錯誤!";
                        break;
                    default:
                        result = "請登入會員!";
                        break;
                }
                return result;
            };
            return BaseMobileVerificationByActive;
        })();
        DynamicPages.BaseMobileVerificationByActive = BaseMobileVerificationByActive;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
