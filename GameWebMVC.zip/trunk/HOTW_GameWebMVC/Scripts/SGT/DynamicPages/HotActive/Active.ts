declare var SGT;
declare var $SGT;
declare var $;
declare var ko;

module SGT.DynamicPages {

    // �����ɨ�
    export class Active {
        /// --------------------------------------
        /// constructor
        /// --------------------------------------
        constructor (platform: number, koName: string = 'Active') {
            this.Platform = platform;
            this.KoName = koName;

            var self = this;

            // ���o�w�]���
            this.GetActiveList();
        }

        /// --------------------------------------
        /// preperty
        /// --------------------------------------
        private Platform: number = 1;
        private KoName: string = '';

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // ���ʦC��
        ActiveList = ko.observableArray([]);

        /// --------------------------------------
        /// function
        /// --------------------------------------
        // ���o���ʦC��
        private GetActiveList(): void {
            var self = this;
            $.ajax({
                type: "Post",
                url: "/Mvc/api/hotactive/Active",
                data: { Type: 2, Platform: self.Platform },
                success: function (data) {
                    self.ActiveList(data);
                },
                error: function (e) {
                    // alert(e.responseText);
                },
                complete: function (data) {
                }
            });
        }
    }
}