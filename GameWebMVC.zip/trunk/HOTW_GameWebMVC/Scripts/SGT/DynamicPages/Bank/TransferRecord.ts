/// <reference path="../Base/TransferBase.ts" />
/// <reference path="../../Pages/Shared/SGTPage.ts" />
declare var ko;

module SGT.DynamicPages {

    // ��b�O��
    export class TransferRecord extends TransferBase {

        /// --------------------------------------
        /// property
        /// --------------------------------------
        // ���x (1:WEB 2:�j�U 3:FB)
        Platinum: number = 0;
        // ���� Partial �ѧO�W��
        PageName: string = '';
        // ���� Partial Instance
        Page: SGT.Pages.Page;

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // ����C��
        TransferMasterList: (input?: Base_Struct_TransferMaster[]) => Base_Struct_TransferMaster[] = ko.observableArray([]);
        // ������ӦC��
        TransferDetailList: (input?: Base_Struct_TransferDetail[]) => Base_Struct_TransferDetail[] = ko.observableArray([]);

        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // ���o�w�]���
        public PageInit(platinum: number, pageName: string = 'TransferRecordPage'): void {
            var self = this;

            // �O����T
            this.Platinum = platinum;
            this.PageName = pageName;

            // �إ� Page�A�åB�w�q ChangeEvent �����ƥ�
            this.Page = new SGT.Pages.Page(() => { self.QueryMaster(); });
            this.Page.PageSize(10);
            SGT.Pages.PageMgr.Add(this.PageName, this.Page);

            // ���o����C��
            this.QueryMaster();
        }

        // �d�ߥ���C��
        public QueryMaster(): void {
            // �d�߸��
            var result = this.Base_Get_TransferMasterRecord(this.Page.PageIndex(), this.Page.PageSize());
            // �]�w���
            this.TransferMasterList(result.List);
            // �]�w Page �`����
            this.Page.TotalRecord(result.TotalRecord);
        }

        // ��ܩ���
        public QueryDetail(item: Base_Struct_TransferMaster): void {
            // �����Ӹ��
            this.TransferDetailList(this.Base_Query_TransferDetail(item.No));
        }
    }
}