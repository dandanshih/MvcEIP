var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var PointBuySN = (function (_super) {
            __extends(PointBuySN, _super);
            function PointBuySN() {
                _super.apply(this, arguments);

                this.ProductList = ko.observableArray([]);
                this.ProductID = ko.observable(0);
                this.StoreSN = ko.observable("");
                this.StorePwd = ko.observable("");
            }
            PointBuySN.prototype.PageInit = function () {
                this.Base_Init(2);
                this.ProductList(this.Base_Get_ProductAll());
            };
            PointBuySN.prototype.SetProduct = function (item) {
                this.ProductID(item.ID);
                this.StoreSN("");
                this.StorePwd("");
            };
            PointBuySN.prototype.GoPayment1 = function (item) {
                var info = new DynamicPages.Base_Struct_GoPayment();
                info.ProductID = item.ID;
                this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
            };
            PointBuySN.prototype.GoPayment2 = function (item) {
                var result = this.Base_Check_StoreCardSN(this.StoreSN());
                if(!result.IsSuccess) {
                    alert(result.Message);
                    return;
                }
                result = this.Base_Check_StoreCardPwd(this.StorePwd());
                if(!result.IsSuccess) {
                    alert(result.Message);
                    return;
                }
                var info = new DynamicPages.Base_Struct_GoPayment();
                info.ProductID = item.ID;
                info.StoreCardSN = this.StoreSN();
                info.StoreCardPwd = this.StorePwd();
                this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
            };
            PointBuySN.prototype.ShowMessage = function (code) {
                if(code == null) {
                    return;
                }
                switch(code) {
                    case 0:
                        break;
                    case 1:
                        alert($SGT.Message.PointBuySN.ShowMessage[1]);
                        break;
                    case 2:
                        alert($SGT.Message.PointBuySN.ShowMessage[2]);
                        break;
                    case 3:
                        alert($SGT.Message.PointBuySN.ShowMessage[3]);
                        break;
                    case -3:
                        alert($SGT.Message.PointBuySN.ShowMessage[4]);
                        break;
                    case -4:
                        alert($SGT.Message.PointBuySN.ShowMessage[0]);
                        location.href = '/Mvc/DynamicPages/Web/Bank/PointBuySN';
                        break;
                    case -1:
                    case -2:
                    case -5:
                    default:
                        alert($SGT.Message.PointBuySN.ShowMessage[0]);
                        break;
                }
            };
            return PointBuySN;
        })(DynamicPages.PointBuyBase);
        DynamicPages.PointBuySN = PointBuySN;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
