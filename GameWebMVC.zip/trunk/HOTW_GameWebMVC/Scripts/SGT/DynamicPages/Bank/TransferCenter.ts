/// <reference path="../Base/TransferBase.ts" />
declare var ko;

module SGT.DynamicPages {

    // ��b����
    export class TransferCenter extends TransferBase {

        /// --------------------------------------
        /// property
        /// --------------------------------------
        // ���x (1:WEB 2:�j�U 3:FB)
        Platinum: number = 0;
        // ���Ӫ�����ID
        DetailID: string = "";
        // �����ثe������ʺ�Key��
        NickNameNo: string = "";
        // �O���n���Ҫ����Key
        VerifyNo: string = "";
        // �O�����Ҧ��\�T���ݭn����T
        VerifyPoints: number = 0;
        VerifyReceiveName: string = "";

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �O�_�n�����b�϶�
        IsShowTransferPanel: (input?: bool) => bool = ko.observable(true);
        // �O�_�@��|��
        IsGeneralMember: (input?: bool) => bool = ko.observable(false);
        // �`�I��
        TotalPoint: (input?: number) => number = ko.observable(0);
        // �i���I��
        FreePoint: (input?: number) => number = ko.observable(0);
        // ���I�W��
        TransferMax: (input?: number) => number = ko.observable(0);
        // ��w�I��
        LockPoint: (input?: number) => number = ko.observable(0);
        // ��w���
        LockDate: (input?: string) => string = ko.observable("");
        // �|����b��H���v����
        NickRecord: (input?: Base_Struct_TransferTarget[]) => Base_Struct_TransferTarget[] = ko.observableArray([]);
        // �����ʺ�
        NickName: (input?: string) => string = ko.observable("");
        // �ǰe�I��
        Points: (input?: number) => number = ko.observable(0);
        // �O�_�n��ܧR���ʺ٫��s
        IsShowDelNickName: (input?: bool) => bool = ko.observable(false);
        // ������\�O�_�n�O���ʺ�
        IsKeepName: (input?: bool) => bool = ko.observable(true);
        // ����C��
        TransferMasterList: (input?: Base_Struct_TransferMaster[]) => Base_Struct_TransferMaster[] = ko.observableArray([]);

        // ������ӦC��
        TransferDetailList: (input?: Base_Struct_TransferDetail[]) => Base_Struct_TransferDetail[] = ko.observableArray([]);

        // �O�_�n������Ҩ����϶�
        IsShowVerifyPanel: (input?: bool) => bool = ko.observable(false);
        // ���ҽX
        VerifyCode: (input?: string) => string = ko.observable("");

        // �O�_�n�����b���\�϶�
        IsShowSuccessPanel: (input?: bool) => bool = ko.observable(false);
        // ����/�P�N ������\����
        ConfirmSuccessType: (input?: number) => number = ko.observable(0);
        // ����/�P�N ������\�T��
        ConfirmSuccessMessage: (input?: string) => string = ko.observable("");

        //��b����O%
        Transfee: (input?: number) => number = ko.observable(0);
        //�]�w����O
        SetTransfee: (input?: number) => number = ko.observable(0);

        /// --------------------------------------
        /// private function
        /// --------------------------------------
        // ������b��
        private ChangePanel_Transfer(isRebind: bool): void {

            if (isRebind) {

                // ���o��b��T
                var info = this.Base_Get_Info();
                this.IsGeneralMember(info.IsGeneralMember);
                this.TotalPoint(info.TotalPoint);
                this.FreePoint(info.FreePoint);
                this.TransferMax(info.TransferMax);
                this.LockPoint(info.LockPoint);
                this.LockDate(info.LockDate);
                this.Transfee(info.Transfee);

                // ���o���v�ʺٰO���C��
                this.NickRecord(this.Base_Get_Member());

                // ���o����C��
                this.TransferMasterList(this.Base_Get_TransferMaster());
            }

            // �M��
            this.NickName("");
            this.Points(0);
            this.SetTargetName();
            this.GetTransfee();

            // ���� Panel
            this.IsShowTransferPanel(true);
            this.IsShowVerifyPanel(false);
            this.IsShowSuccessPanel(false);
        }

        // �������Ҩ�����
        private ChangePanel_Verify(no: string, point: number, receiveName: string): void {
            this.VerifyNo = no;
            this.VerifyPoints = point;
            this.VerifyReceiveName = receiveName;
            this.VerifyCode("");
            this.IsShowTransferPanel(false);
            this.IsShowVerifyPanel(true);
            this.IsShowSuccessPanel(false);
        }

        // ����������G��
        private ChangePanel_Success(type: number, message?: string): void {
            this.ConfirmSuccessType(type);
            this.ConfirmSuccessMessage(message);
            this.IsShowTransferPanel(false);
            this.IsShowVerifyPanel(false);
            this.IsShowSuccessPanel(true);
        }

        // �]�w��w�ʺ�
        private SetTargetName(item?: Base_Struct_TransferTarget): void {
            if (item) {
                this.IsShowDelNickName(true);
                this.NickName(item.Name);
                this.NickNameNo = item.No;
            } else {
                this.IsShowDelNickName(false);
                this.NickNameNo = "";
            }
        }


        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // ���o�w�]���
        public PageInit(platinum: number, detailId: string): void {
            // �O����T
            this.Platinum = platinum;
            this.DetailID = detailId;

            // ��������b��
            this.ChangePanel_Transfer(true);
        }

        // �]�w�ʺٿ�����A
        public SetNickName(item?: Base_Struct_TransferTarget): void {
            this.SetTargetName(item);
        }

        // �R���ʺ�
        public DelNickName(): void {
            if (this.NickNameNo) {
                this.Base_Del_Member(this.NickNameNo);
                // �����ʺ٦C��
                this.NickRecord(this.Base_Get_Member());
                // �M���ʺٿ�����A
                this.SetTargetName();
            }
        }

        // �|����b
        public GoTransfer(): void {
            var result: Base_Struct_CheckResult;

            result = this.Base_Check_Nick(this.NickName());
            if (result.Code != 0) {
                alert(result.Message);
                return;
            }

            result = this.Base_Check_Point(this.Points());
            if (result.Code != 0) {
                alert(result.Message);
                return;
            }

            result = this.Base_Submit_MemberTransfer(this.NickName(), this.Points(), this.IsKeepName(), this.Platinum);
            if (result.Code == 0) {
                // ���� Panel
                this.ChangePanel_Success(0);
                // ���o��b��T
                var info = this.Base_Get_Info();
                this.IsGeneralMember(info.IsGeneralMember);
                this.TotalPoint(info.TotalPoint);
                this.FreePoint(info.FreePoint);
                this.TransferMax(info.TransferMax);
                this.LockPoint(info.LockPoint);
                this.LockDate(info.LockDate);
                // ���o����C��
                this.TransferMasterList(this.Base_Get_TransferMaster());

                setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
            } else {
                alert(result.Message);
            }
        }

        // �P�N���
        public GoTransferAgree(item: Base_Struct_TransferMaster): void {
            var result = this.Base_Submit_TransferConfirm(item.No, 1);

            if (result.IsSuccess) {
                // ���� Panel
                this.ChangePanel_Success(1);
                // �������
                this.TransferMasterList(this.Base_Get_TransferMaster());
                // �����I��
                if (result.IsRegainPoint) {
                    setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
                }
            } else {
                alert(result.Message);
            }
        }

        // �������
        public GoTransferCancel(item: Base_Struct_TransferMaster): void {
            var result = this.Base_Submit_TransferConfirm(item.No, 2);

            if (result.IsSuccess) {
                // ���� Panel
                this.ChangePanel_Success(2);
                // �������
                this.TransferMasterList(this.Base_Get_TransferMaster());
                // �����I��
                if (result.IsRegainPoint) {
                    setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
                }
            } else {
                alert(result.Message);
            }
        }

        // �e�����Ҩ�����
        public GoVerifyPanel(item: Base_Struct_TransferMaster): void {
            this.ChangePanel_Verify(item.No, item.Points, item.ReceiveName);
        }

        // �T�{���
        public GoTransferVerify(): void {

            if (!this.VerifyNo) {
                return;
            }

            var result: Base_Struct_CheckResult;

            result = this.Base_Check_VerifyCode(this.VerifyCode());
            if (result.Code != 0) {
                alert(result.Message);
                return;
            }

            var verifyResult = this.Base_Submit_TransferVerify(this.VerifyNo, this.VerifyCode());
            if (verifyResult.IsSuccess) {

                var platform = "Web";
                if (typeof GetPlatform == 'function') {
                    platform = GetPlatform();
                }
                // ���� Panel
                if (platform.toLowerCase() == 'online113') {
                    // 113���� �n��ܤ��T��
                    this.ChangePanel_Success(3, $SGT.Message.TransferCenter.GoTransferVerify[1].format(this.VerifyPoints['addCommas'](), this.VerifyReceiveName));
                } else {
                    // Web / FB ��ܤ��T��
                    this.ChangePanel_Success(3, $SGT.Message.TransferCenter.GoTransferVerify[0].format(this.VerifyPoints['addCommas'](), this.VerifyReceiveName));
                }
                // ���o���v�ʺٰO���C��
                this.NickRecord(this.Base_Get_Member());
                // �������
                this.TransferMasterList(this.Base_Get_TransferMaster());
                // �����I��
                if (verifyResult.IsRegainPoint) {
                    setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
                }
            } else {
                alert(verifyResult.Message);
            }
        }

        public SendSMSCode(): void {
            var result: Base_Struct_SendSMSCodeResult = this.Base_Submit_SendSMSCode(this.VerifyNo);
            alert(result.Message);
        }

        // ��ܩ���
        public QueryDetail(item: Base_Struct_TransferMaster): void {
            // �����Ӹ��
            this.TransferDetailList(this.Base_Query_TransferDetail(item.No));
        }

        // �e����b��
        public GoTransferPanel(): void {
            this.ChangePanel_Transfer(false);
        }

        public GetTransfee(): void {
            if (this.Points() > 0 && this.Transfee() > 0) {
                this.SetTransfee(Math.ceil(this.Points() * this.Transfee()));
            } else {
                this.SetTransfee(0);
            }
        }
    }
}