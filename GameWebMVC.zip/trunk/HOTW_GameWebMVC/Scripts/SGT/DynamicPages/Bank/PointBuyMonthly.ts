﻿/// <reference path="../Base/PointBuyBase.ts" />
declare var ko;

module SGT.DynamicPages {
    // 超值包月
    export class PointBuyMonthly extends PointBuyBase {

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // Init
        // 是否使用最後一次的操作紀錄
        IsShowLastRecordMemo: (input?: bool) => bool = ko.observable(false);
        // 金額列表
        ValueList: (input?: Base_Struct_ValueList[]) => Base_Struct_ValueList[] = ko.observableArray([]);

        // Block1
        // 是否顯示付費方式列表步驟
        IsShowBlock1: (input?: bool) => bool = ko.observable(false);
        // 購買金額編號
        ValueID: (input?: number) => number = ko.observable(0);
        // 付費方式列表
        ProductList: (input?: Base_Struct_ProductList[]) => Base_Struct_ProductList[] = ko.observableArray([]);

        // Block2
        // 是否顯示付費方式列表步驟
        IsShowBlock2: (input?: bool) => bool = ko.observable(false);
        // 付費方式編號
        ProductID: (input?: number) => number = ko.observable(0);
        // 付費方式名稱
        ProductName: (input?: string) => string = ko.observable("");
        // 付費方式是否需要輸入發票
        IsNeedInvoice: (input?: bool) => bool = ko.observable(false);
        // 交易金額
        Price: (input?: number) => number = ko.observable(0);
        // 交易點數
        Points: (input?: number) => number = ko.observable(0);
        // 每日補點
        EveryDayPoints: (input?: number) => number = ko.observable(0);
        // 贈點(目前無用)
        GiftPoints: (input?: number) => number = ko.observable(0);

        // Block3
        // 發票型式
        InvoiceType: (input?: number) => number = ko.observable(0);
        // 電子發票寄送電子信箱
        InvoiceEmail: (input?: string) => string = ko.observable("");
        // 電子發票寄送電子信箱錯誤訊息
        InvoiceEmailErrorMsg: (input?: string) => string = ko.observable("");
        // 發票收件人
        InvoiceName: (input?: string) => string = ko.observable("");
        // 發票收件人錯誤訊息
        InvoiceNameErrorMsg: (input?: string) => string = ko.observable("");
        // 發票收件地址
        InvoiceAddress: (input?: string) => string = ko.observable("");
        // 發票收件地址錯誤訊息
        InvoiceAddressErrorMsg: (input?: string) => string = ko.observable("");
        // 我同意勾選
        IsAgree: (input?: bool) => bool = ko.observable(false);
        // 我同意勾選錯誤訊息
        IsAgreeErrorMsg: (input?: string) => string = ko.observable("");
        // 縣市列表
        CityList: (input?: Base_Struct_CityList[]) => Base_Struct_CityList[] = ko.observableArray([]);
        // 鄉鎮市列表
        ZoneList: (input?: Base_Struct_ZoneList[]) => Base_Struct_ZoneList[] = ko.observableArray([]);
        // 發票收件地址城市編號
        InvoiceCityID: (input?: number) => number = ko.observable(0);
        // 發票收件地址鄉鎮市編號
        InvoiceZoneID: (input?: string) => string = ko.observable("");


        /// --------------------------------------
        /// private function
        /// --------------------------------------
        // 讀取 Block1、2 記錄
        private RecoveryRecord(): void {

            var record = this.Base_Get_PayRecord();
            var isNext = false;

            // 復原Block1 金額
            if (record.ValueID != 0) {

                // 取得該筆金額資訊
                var valueList = this.ValueList();
                var valueItem: Base_Struct_ValueList;

                for (var i = 0, count = valueList.length; i < count; i++) {
                    if (valueList[i].ID === record.ValueID) {
                        valueItem = valueList[i];
                        isNext = true;
                        break;
                    }
                }

                if (valueItem) {
                    this.SetBlock1(valueItem);
                }
            }

            // 復原Block2 付款方式
            if (isNext) {
                isNext = false;

                if (record.ProductID != 0) {

                    // 取得該筆付款方式資訊
                    var productList = this.ProductList();
                    var productItem: Base_Struct_ProductList;

                    for (var i = 0, count = productList.length; i < count; i++) {
                        if (productList[i].ID === record.ProductID) {
                            productItem = productList[i];
                            isNext = true;
                            break;
                        }
                    }

                    if (productItem) {
                        this.SetBlock2(productItem);
                    }
                }
            }
        }

        // 設定 Block1 資料
        private SetBlock1(item?: Base_Struct_ValueList): void {

            if (item) {
                this.IsShowBlock1(true);
                this.ValueID(item.ID);
                this.ProductList(this.Base_Get_ProductList(item.ProductList));
            } else {
                this.IsShowBlock1(false);
                this.ValueID(0);
                this.ProductList([]);
            }
        }

        // 設定 Block2 資料
        private SetBlock2(item?: Base_Struct_ProductList): void {
            if (item && !item.IsMaintain) {
                this.IsShowBlock2(true);
                this.ProductID(item.ID);
                this.ProductName(item.Name);
                this.IsNeedInvoice(item.IsNeedInvoice);
                this.UpdateTransInfo();
            } else {
                this.IsShowBlock2(false);
                this.ProductID(0);
                this.ProductName("");
                this.IsNeedInvoice(false);
                this.Price(0);
                this.Points(0);
                this.EveryDayPoints(0);
                this.GiftPoints(0);
            }
        }

        // 還原 Block3 預設資料
        private SetBlock3Default(): void {
            var record = this.Base_Get_PayRecord();

            this.InvoiceType(record.InvoiceType >= 0 && record.InvoiceType <= 2 ? record.InvoiceType : 0);

            this.InvoiceEmail(record.InvoiceEmail);
            this.InvoiceEmailErrorMsg("");

            this.InvoiceName(record.InvoiceName);
            this.InvoiceNameErrorMsg("");
            this.InvoiceCityID(record.InvoiceCityID);
            this.InvoiceZoneID(record.InvoiceZoneID);
            this.CityList(this.Base_Get_CityList());
            this.ZoneList(this.Base_Get_ZoneList(record.InvoiceCityID));
            this.InvoiceAddress(record.InvoiceAddress);
            this.InvoiceAddressErrorMsg("");

            this.IsAgree(false);
            this.IsAgreeErrorMsg("");
        }

        // 更新交易金額、點數
        private UpdateTransInfo(): void {
            var transInfo = this.Base_Get_Worth(this.ValueID(), this.ProductID());
            this.Price(transInfo.Price);
            this.Points(transInfo.ResultPoints);
            this.EveryDayPoints(transInfo.EveryDayPoints);
            this.GiftPoints(transInfo.GiftPoints);
        }


        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // 頁面載入初始化基本資料
        PageInit(): void {
            this.Base_Init(3);

            // 設定 Init 資料
            this.IsShowLastRecordMemo(this.Base_Get_IsLastRecord());
            this.ValueList(this.Base_Get_ValueList());

            // 清除 Block1、2 資料
            this.SetBlock1();
            this.SetBlock2();

            // 讀取 Block1、2 記錄
            this.RecoveryRecord();

            // 還原 Block3 預設資料
            this.SetBlock3Default();
        }

        // 查詢付款方式列表
        QueryProduct(item: Base_Struct_ValueList): void {

            // 取消預設選項提示
            this.IsShowLastRecordMemo(false);

            // 設定 Block1 資料
            this.SetBlock1(item);

            // 清除 Block2 資料
            this.SetBlock2();

            // 還原 Block3 預設資料
            this.SetBlock3Default();
        }

        // 查詢確認資料內容
        QueryConfirmInfo(item: Base_Struct_ProductList): void {

            // 取消預設選項提示
            this.IsShowLastRecordMemo(false);

            // 設定 Block2 資料
            this.SetBlock2(item);

            // 還原 Block3 預設資料
            this.SetBlock3Default();
        }

        // 縣市下拉選單change事件
        CityChange(): void {
            var zone = this.Base_Get_ZoneList(this.InvoiceCityID());

            // 繫結區列表
            this.ZoneList(zone);

            // 將 ZoneID 移至第一個項目
            if (zone.length > 0) {
                this.InvoiceZoneID(zone[0].ZoneID);
            }
        }

        // 驗證 Email
        CheckEmail(): bool {
            var result = this.Base_Check_Email(this.InvoiceEmail());
            this.InvoiceEmailErrorMsg(result.IsSuccess ? "" : result.Message);
            return result.IsSuccess;
        }

        // 驗證 發票收件人
        CheckName(): bool {
            var result = this.Base_Check_InvoiceName(this.InvoiceName());
            this.InvoiceNameErrorMsg(result.IsSuccess ? "" : result.Message);
            return result.IsSuccess;
        }

        // 驗證 發票寄送地址
        CheckAddress(): bool {

            // 驗證縣市選項
            if (this.InvoiceCityID() == 0) {
                this.InvoiceAddressErrorMsg($SGT.Message.PointBuyMonthly.CheckAddress[0]);
                return false;
            }

            // 驗證地址格式
            var result = this.Base_Check_InvoiceAddress(this.InvoiceAddress());
            this.InvoiceAddressErrorMsg(result.IsSuccess ? "" : result.Message);
            return result.IsSuccess;
        }

        // 驗證是否勾選我同意
        CheckAgree(): bool {
            this.IsAgreeErrorMsg(this.IsAgree() ? "" : $SGT.Message.PointBuyMonthly.CheckAgree[0]);
            return this.IsAgree();
        }

        // 確認付款
        GoPayment(): void {

            var isValid = true;

            if (!(
                (this.InvoiceType() == 0) ||
                (this.InvoiceType() == 1 && this.CheckEmail()) ||
                (this.InvoiceType() == 2 && this.CheckName() && this.CheckAddress())
                )) {
                isValid = false;
            }

            if (!this.CheckAgree()) {
                isValid = false;
            }

            if (!isValid) {
                return;
            }

            // 儲存記錄
            this.SaveRecord();

            var info = new Base_Struct_GoPayment();
            info.Price = this.Price()
            info.Points = this.Points();
            info.EveryDayPoints = this.EveryDayPoints();
            info.GiftPoints = this.GiftPoints();
            info.ValueID = this.ValueID();
            info.ProductID = this.ProductID();
            info.InvoiceType = this.InvoiceType();
            info.InvoiceEmail = this.InvoiceEmail();
            info.InvoiceName = this.InvoiceName();
            info.InvoiceCityID = this.InvoiceCityID();
            info.InvoiceZoneID = this.InvoiceZoneID();
            info.InvoiceAddress = this.InvoiceAddress();
            this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
        }

        // 儲存紀錄
        SaveRecord(): void {
            var record = new Base_Struct_PayRecord();
            record.ValueID = this.ValueID();
            record.ProductID = this.ProductID();
            record.InvoiceType = this.InvoiceType();
            record.InvoiceEmail = this.InvoiceEmail();
            record.InvoiceName = this.InvoiceName();
            record.InvoiceCityID = this.InvoiceCityID();
            record.InvoiceZoneID = this.InvoiceZoneID();
            record.InvoiceAddress = this.InvoiceAddress();

            this.Base_Set_Record(record);
        }

        // 顯示錯誤訊息
        ShowMessage(code: number): void {
            if (code == null) {
                return;
            } else {
                this.IsAgree(true);
            }

            switch (code) {
                // 成功
                case 0:
                    // 會自動導頁
                    break;
                // ValueID 或 ProductID 小於等於0
                case 1:
                    alert($SGT.Message.PointBuyMonthly.ShowMessage[1]);
                    break;
                // 交易金額或點數 小於等於0
                case 2:
                    alert($SGT.Message.PointBuyMonthly.ShowMessage[0]);
                    break;
                // 儲值超過限額
                case -3:
                    alert($SGT.Message.PointBuyMonthly.ShowMessage[2]);
                    break;
                // 購買點數及金額有誤
                case -4:
                    alert($SGT.Message.PointBuyMonthly.ShowMessage[0]);
                    location.href = '/Mvc/DynamicPages/Web/Bank/PointBuyMonthly';
                    break;
                case -1:    // 無此會員
                case -2:    // 站內訂單建立失敗
                case -5:    // 關機維護中，無法儲值
                case -6:
                    alert($SGT.Message.PointBuyMonthly.ShowMessage[3]);
                    location.href = '/Mvc/DynamicPages/Web/Bank/PointBuyMonthly';
                    break;
                default:
                    alert($SGT.Message.PointBuyMonthly.ShowMessage[0]);
                    break;
            }
        }

        NewMonthPaymentDiscountCheck(): void {
            var _ResultCode = this.Base_Get_ResultCode();
            var _ResultMsg = "";
            switch (_ResultCode) {
                case 0:
                    _ResultMsg = "此帳號符合活動條件！";
                    break;
                case 1:
                    _ResultMsg = "活動已經結束囉！";
                    break;
                case 2:
                    _ResultMsg = "此帳號不符合活動條件。原因：未通過手機驗證。";
                    break;
                case 3:
                    _ResultMsg = "此帳號不符合活動條件。原因：此帳號曾購買過包月。";
                    break;
                case 4:
                    _ResultMsg = "此帳號不符合活動條件。原因：同手機驗證之相關帳號已選購過包月。";
                    break;
                case 5:
                    _ResultMsg = "此帳號不符合活動條件。原因：您尚未具備普卡資格，請先儲值升級享有更多優惠喔！";
                    break;
                case 6:
                    _ResultMsg = "此帳號不符合活動條件。原因：您已有包月首購半價交易正在進行中！";
                    break;
                default:
                    _ResultMsg = "此帳號不符合活動條件。";
                    break;
            }

            alert(_ResultMsg);

            return;
        }
    }
}
