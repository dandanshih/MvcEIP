/// <reference path="../Base/PointBuyBase.ts" />
declare var ko;

module SGT.DynamicPages {
    // �u�W���I
    export class PointBuySN extends PointBuyBase {

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �I�O�覡�C��
        ProductList: (input?: Base_Struct_ProductList[]) => Base_Struct_ProductList[] = ko.observableArray([]);
        // �ϥΪ̿�����I�O�覡�s��
        ProductID: (input?: number) => number = ko.observable(0);
        // �ϥΪ̿�J���x�ȧǸ�
        StoreSN: (input?: string) => string = ko.observable("");
        // �ϥΪ̿�J���Ǹ����ҽX
        StorePwd: (input?: string) => string = ko.observable("");

        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // �������J��l�ư򥻸��
        PageInit(): void {
            this.Base_Init(2);
            this.ProductList(this.Base_Get_ProductAll());
        }

        // �]�w�I�ڤ覡�òM�ſ�J�Ǹ�
        SetProduct(item: Base_Struct_ProductList): void {
            this.ProductID(item.ID);
            this.StoreSN("");
            this.StorePwd("");
        }

      
        // �T�{�I�� (��¨�PG�ӵL��J�Ǹ�)
        GoPayment1(item: Base_Struct_ProductList): void {
            var info = new Base_Struct_GoPayment();
            info.ProductID = item.ID;
            this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
        }

        // �T�{�I�� (���ҧǸ��åB��PG)
        GoPayment2(item: Base_Struct_ProductList): void {

            var result = this.Base_Check_StoreCardSN(this.StoreSN());
            if (!result.IsSuccess) {
                alert(result.Message);
                return;
            }

            result = this.Base_Check_StoreCardPwd(this.StorePwd());
            if (!result.IsSuccess) {
                alert(result.Message);
                return;
            }

            var info = new Base_Struct_GoPayment();
            info.ProductID = item.ID;
            info.StoreCardSN = this.StoreSN();
            info.StoreCardPwd = this.StorePwd();
            this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
        }

        // ��ܿ��~�T��
        ShowMessage(code: number): void {

            if (code == null) {
                return;
            }

            switch (code) {
                // ���\
                case 0:
                    // �|�۰ʾɭ�
                    break;
                // ProductID �p�󵥩� 0
                case 1:
                    alert($SGT.Message.PointBuySN.ShowMessage[1]);
                    break;
                // ����J�Ǹ�
                case 2:
                    alert($SGT.Message.PointBuySN.ShowMessage[2]);
                    break;
                // ����J���ҽX
                case 3:
                    alert($SGT.Message.PointBuySN.ShowMessage[3]);
                    break;
                // �x�ȶW�L���B
                case -3:
                    alert($SGT.Message.PointBuySN.ShowMessage[4]);
                    break;
                // �ʶR�I�ƤΪ��B���~
                case -4:
                    alert($SGT.Message.PointBuySN.ShowMessage[0]);
                    location.href = '/Mvc/DynamicPages/Web/Bank/PointBuySN';
                    break;
                case -1:    // �L���|��
                case -2:    // �����q��إߥ���
                case -5:    // �������@���A�L�k�x��
                default:
                    alert($SGT.Message.PointBuySN.ShowMessage[0]);
                    break;
            }
        }
    }
}
