var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var TransferRecord = (function (_super) {
            __extends(TransferRecord, _super);
            function TransferRecord() {
                _super.apply(this, arguments);

                this.Platinum = 0;
                this.PageName = '';
                this.TransferMasterList = ko.observableArray([]);
                this.TransferDetailList = ko.observableArray([]);
            }
            TransferRecord.prototype.PageInit = function (platinum, pageName) {
                if (typeof pageName === "undefined") { pageName = 'TransferRecordPage'; }
                var self = this;
                this.Platinum = platinum;
                this.PageName = pageName;
                this.Page = new SGT.Pages.Page(function () {
                    self.QueryMaster();
                });
                this.Page.PageSize(10);
                SGT.Pages.PageMgr.Add(this.PageName, this.Page);
                this.QueryMaster();
            };
            TransferRecord.prototype.QueryMaster = function () {
                var result = this.Base_Get_TransferMasterRecord(this.Page.PageIndex(), this.Page.PageSize());
                this.TransferMasterList(result.List);
                this.Page.TotalRecord(result.TotalRecord);
            };
            TransferRecord.prototype.QueryDetail = function (item) {
                this.TransferDetailList(this.Base_Query_TransferDetail(item.No));
            };
            return TransferRecord;
        })(DynamicPages.TransferBase);
        DynamicPages.TransferRecord = TransferRecord;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
