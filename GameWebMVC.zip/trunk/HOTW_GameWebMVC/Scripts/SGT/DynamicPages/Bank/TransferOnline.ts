/// <reference path="../Base/PointBuyBase.ts" />
declare var ko;

module SGT.DynamicPages {
    // �u�W���I
    export class TransferOnline extends PointBuyBase {

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // �I�O�覡�C��
        ProductList: (input?: Base_Struct_ProductList[]) => Base_Struct_ProductList[] = ko.observableArray([]);

        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // �������J��l�ư򥻸��
        PageInit(): void {
            this.Base_Init(4);
            this.ProductList(this.Base_Get_ProductAll());
        }

        // �T�{�I��
        GoPayment(item: Base_Struct_ProductList): void {
            
            var info = new Base_Struct_GoPayment();
            info.ProductID = item.ID;
            this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
        }

        // ��ܿ��~�T��
        ShowMessage(code: number): void {

            if (code == null) {
                return;
            }

            switch (code) {
                // ���\
                case 0:
                    // �|�۰ʾɭ�
                    break;
                // ProductID �p�󵥩� 0
                case 1:
                    alert($SGT.Message.TransferOnline.ShowMessage[1]);
                    break;
                // �x�ȶW�L���B
                case -3:
                    alert($SGT.Message.TransferOnline.ShowMessage[2]);
                    break;
                // �ʶR�I�ƤΪ��B���~
                case -4:
                    alert($SGT.Message.TransferOnline.ShowMessage[0]);
                    location.href = '/Mvc/DynamicPages/Web/Bank/TransferOnline';
                    break;
                case -1:    // �L���|��
                case -2:    // �����q��إߥ���
                case -5:    // �������@���A�L�k�x��
                default:
                    alert($SGT.Message.TransferOnline.ShowMessage[0]);
                    break;
            }
        }
    }
}
