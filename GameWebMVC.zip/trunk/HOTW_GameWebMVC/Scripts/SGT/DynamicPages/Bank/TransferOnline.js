var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var TransferOnline = (function (_super) {
            __extends(TransferOnline, _super);
            function TransferOnline() {
                _super.apply(this, arguments);

                this.ProductList = ko.observableArray([]);
            }
            TransferOnline.prototype.PageInit = function () {
                this.Base_Init(4);
                this.ProductList(this.Base_Get_ProductAll());
            };
            TransferOnline.prototype.GoPayment = function (item) {
                var info = new DynamicPages.Base_Struct_GoPayment();
                info.ProductID = item.ID;
                this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
            };
            TransferOnline.prototype.ShowMessage = function (code) {
                if(code == null) {
                    return;
                }
                switch(code) {
                    case 0:
                        break;
                    case 1:
                        alert($SGT.Message.TransferOnline.ShowMessage[1]);
                        break;
                    case -3:
                        alert($SGT.Message.TransferOnline.ShowMessage[2]);
                        break;
                    case -4:
                        alert($SGT.Message.TransferOnline.ShowMessage[0]);
                        location.href = '/Mvc/DynamicPages/Web/Bank/TransferOnline';
                        break;
                    case -1:
                    case -2:
                    case -5:
                    default:
                        alert($SGT.Message.TransferOnline.ShowMessage[0]);
                        break;
                }
            };
            return TransferOnline;
        })(DynamicPages.PointBuyBase);
        DynamicPages.TransferOnline = TransferOnline;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
