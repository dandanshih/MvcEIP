﻿var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        // 線上購點
        var PointBuyOnline = (function (_super) {
            __extends(PointBuyOnline, _super);
            function PointBuyOnline() {
                _super.apply(this, arguments);
                /// --------------------------------------
                /// property
                /// --------------------------------------
                /// --------------------------------------
                /// ko function
                /// --------------------------------------
                // Init
                // 是否使用最後一次的操作紀錄
                this.IsShowLastRecordMemo = ko.observable(false);
                // 金額列表
                this.ValueList = ko.observableArray([]);
                // Block1
                // 是否顯示付費方式列表步驟
                this.IsShowBlock1 = ko.observable(false);
                // 使用者選取的金額編號
                this.ValueID = ko.observable(0);
                // 付費方式列表
                this.ProductList = ko.observableArray([]);
                // Block2
                // 是否顯示付費方式列表步驟
                this.IsShowBlock2 = ko.observable(false);
                // 使用者選取的付費方式編號
                this.ProductID = ko.observable(0);
                // 使用者選取的付費方式名稱
                this.ProductName = ko.observable("");
                // 付費方式是否需要輸入發票
                this.IsNeedInvoice = ko.observable(false);
                // 是否顯示輸入折價卷步驟
                this.IsNeedECoupon = ko.observable(false);
                // 目前交易金額
                this.Price = ko.observable(0);
                // 目前交易點數
                this.Points = ko.observable(0);
                // 目前每日補點
                this.EveryDayPoints = ko.observable(0);
                // 目前贈點(目前無用)
                this.GiftPoints = ko.observable(0);
                // Block3
                // 使用者輸入的儲值折價券序號
                this.ECoupon = ko.observable("");
                // 儲值折價券序號的錯誤訊息
                this.ECouponErrorMsg = ko.observable("");
                // 發票型式
                this.InvoiceType = ko.observable(0);
                // 電子發票寄送電子信箱
                this.InvoiceEmail = ko.observable("");
                // 電子發票寄送電子信箱錯誤訊息
                this.InvoiceEmailErrorMsg = ko.observable("");
                // 發票收件人
                this.InvoiceName = ko.observable("");
                // 發票收件人錯誤訊息
                this.InvoiceNameErrorMsg = ko.observable("");
                // 發票收件地址
                this.InvoiceAddress = ko.observable("");
                // 發票收件地址錯誤訊息
                this.InvoiceAddressErrorMsg = ko.observable("");
                // 我同意勾選
                this.IsAgree = ko.observable(false);
                // 我同意勾選錯誤訊息
                this.IsAgreeErrorMsg = ko.observable("");
                // 縣市列表
                this.CityList = ko.observableArray([]);
                // 鄉鎮市列表
                this.ZoneList = ko.observableArray([]);
                // 使用者選取的發票收件地址城市編號
                this.InvoiceCityID = ko.observable(0);
                // 使用者選取的發票收件地址鄉鎮市編號
                this.InvoiceZoneID = ko.observable("");
            }
            /// --------------------------------------
            /// private function
            /// --------------------------------------
            // 讀取 Block1、2 記錄
            PointBuyOnline.prototype.RecoveryRecord = function () {
                var record = this.Base_Get_PayRecord();
                var isNext = false;

                if (record.ValueID != 0) {
                    // 取得該筆金額資訊
                    var valueList = this.ValueList();
                    var valueItem;

                    for (var i = 0, count = valueList.length; i < count; i++) {
                        if (valueList[i].ID === record.ValueID) {
                            valueItem = valueList[i];
                            isNext = true;
                            break;
                        }
                    }

                    if (valueItem) {
                        this.SetBlock1(valueItem);
                    }
                }

                if (isNext) {
                    isNext = false;

                    if (record.ProductID != 0) {
                        // 取得該筆付款方式資訊
                        var productList = this.ProductList();
                        var productItem;

                        for (var i = 0, count = productList.length; i < count; i++) {
                            if (productList[i].ID === record.ProductID) {
                                productItem = productList[i];
                                isNext = true;
                                break;
                            }
                        }

                        if (productItem) {
                            this.SetBlock2(productItem);
                        }
                    }
                }
            };

            // 設定 Block1 資料
            PointBuyOnline.prototype.SetBlock1 = function (item) {
                if (item) {
                    this.IsShowBlock1(true);
                    this.ValueID(item.ID);
                    this.ProductList(this.Base_Get_ProductList(item.ProductList));
                } else {
                    this.IsShowBlock1(false);
                    this.ValueID(0);
                    this.ProductList([]);
                }
            };

            // 設定 Block2 資料
            PointBuyOnline.prototype.SetBlock2 = function (item) {
                if (item && !item.IsMaintain) {
                    // 設定 Block2 資料
                    var setting = this.Base_Get_ValueProductSetting(this.ValueID(), item.ID);

                    this.IsShowBlock2(true);
                    this.ProductID(item.ID);
                    this.ProductName(item.Name);
                    this.IsNeedInvoice(item.IsNeedInvoice);
                    this.IsNeedECoupon(setting.IsShowECoupon);
                    this.UpdateTransInfo();
                } else {
                    this.IsShowBlock2(false);
                    this.ProductID(0);
                    this.ProductName("");
                    this.IsNeedInvoice(false);
                    this.IsNeedECoupon(false);
                    this.Price(0);
                    this.Points(0);
                    this.EveryDayPoints(0);
                    this.GiftPoints(0);
                }
            };

            // 還原 Block3 預設資料
            PointBuyOnline.prototype.SetBlock3Default = function () {
                var record = this.Base_Get_PayRecord();

                this.ECoupon("");
                this.ECouponErrorMsg("");

                this.InvoiceType(record.InvoiceType >= 0 && record.InvoiceType <= 2 ? record.InvoiceType : 0);

                this.InvoiceEmail(record.InvoiceEmail);
                this.InvoiceEmailErrorMsg("");

                this.InvoiceName(record.InvoiceName);
                this.InvoiceNameErrorMsg("");
                this.InvoiceCityID(record.InvoiceCityID);
                this.InvoiceZoneID(record.InvoiceZoneID);
                this.CityList(this.Base_Get_CityList());
                this.ZoneList(this.Base_Get_ZoneList(record.InvoiceCityID));
                this.InvoiceAddress(record.InvoiceAddress);
                this.InvoiceAddressErrorMsg("");

                this.IsAgree(false);
                this.IsAgreeErrorMsg("");
            };

            // 更新交易金額、點數
            PointBuyOnline.prototype.UpdateTransInfo = function () {
                var transInfo = this.Base_Get_Worth(this.ValueID(), this.ProductID(), this.ECoupon());
                this.Price(transInfo.Price);
                this.Points(transInfo.ResultPoints);
                this.EveryDayPoints(transInfo.EveryDayPoints);
                this.GiftPoints(transInfo.GiftPoints);
            };

            /// --------------------------------------
            /// public function
            /// --------------------------------------
            // 頁面載入初始化基本資料
            PointBuyOnline.prototype.PageInit = function () {
                this.Base_Init(1);

                // 設定 Init 資料
                this.IsShowLastRecordMemo(this.Base_Get_IsLastRecord());
                this.ValueList(this.Base_Get_ValueList());

                // 清除 Block1、2 資料
                this.SetBlock1();
                this.SetBlock2();

                // 讀取 Block1、2 記錄
                this.RecoveryRecord();

                // 還原 Block3 預設資料
                this.SetBlock3Default();
            };

            // 查詢付款方式列表
            PointBuyOnline.prototype.QueryProduct = function (item) {
                // 取消預設選項提示
                this.IsShowLastRecordMemo(false);

                // 設定 Block1 資料
                this.SetBlock1(item);

                // 清除 Block2 資料
                this.SetBlock2();

                // 還原 Block3 預設資料
                this.SetBlock3Default();

                this.Price(item.Value);
                this.Points(item.Point);
            };

            // 查詢確認資料內容
            PointBuyOnline.prototype.QueryConfirmInfo = function (item) {
                // 取消預設選項提示
                this.IsShowLastRecordMemo(false);

                // 設定 Block2 資料
                this.SetBlock2(item);

                // 還原 Block3 預設資料
                this.SetBlock3Default();
            };

            // 縣市下拉選單change事件
            PointBuyOnline.prototype.CityChange = function () {
                var zone = this.Base_Get_ZoneList(this.InvoiceCityID());

                // 繫結區列表
                this.ZoneList(zone);

                if (zone.length > 0) {
                    this.InvoiceZoneID(zone[0].ZoneID);
                }
            };

            // 驗證 ECoupon
            PointBuyOnline.prototype.CheckECoupon = function () {
                var isSuccess = false;
                var message = "";

                if (this.ECoupon() != "") {
                    var result = this.Base_Check_ECoupon(this.ValueID(), this.ProductID(), this.ECoupon());
                    isSuccess = result.IsSuccess;
                    message = !result.IsSuccess ? result.Message : this.SuccessImg;
                } else {
                    isSuccess = true;
                    message = "";
                }

                if ((this.ECouponErrorMsg() != this.SuccessImg && message == this.SuccessImg) || (this.ECouponErrorMsg() == this.SuccessImg && message != this.SuccessImg)) {
                    // 更新交易金額資訊
                    this.UpdateTransInfo();
                }

                this.ECouponErrorMsg(message);
                return isSuccess;
            };

            // 驗證 Email
            PointBuyOnline.prototype.CheckEmail = function () {
                var result = this.Base_Check_Email(this.InvoiceEmail());
                this.InvoiceEmailErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };

            // 驗證 發票收件人
            PointBuyOnline.prototype.CheckName = function () {
                var result = this.Base_Check_InvoiceName(this.InvoiceName());
                this.InvoiceNameErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };

            // 驗證 發票寄送地址
            PointBuyOnline.prototype.CheckAddress = function () {
                if (this.InvoiceCityID() == 0) {
                    this.InvoiceAddressErrorMsg($SGT.Message.PointBuyOnline.CheckAddress[0]);
                    return false;
                }

                // 驗證地址格式
                var result = this.Base_Check_InvoiceAddress(this.InvoiceAddress());
                this.InvoiceAddressErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };

            // 驗證是否勾選我同意
            PointBuyOnline.prototype.CheckAgree = function () {
                this.IsAgreeErrorMsg(this.IsAgree() ? "" : $SGT.Message.PointBuyOnline.CheckAgree[0]);
                return this.IsAgree();
            };

            // 確認付款
            PointBuyOnline.prototype.GoPayment = function (ID) {
                
                var isValid = true;

                //if (!(
                //    (this.InvoiceType() == 0) ||
                //    (this.InvoiceType() == 1 && this.CheckEmail()) ||
                //    (this.InvoiceType() == 2 && this.CheckName() && this.CheckAddress())
                //    )) {
                //    isValid = false;
                //}
                //if (!this.CheckAgree()) {
                //    isValid = false;
                //}
                //if (!isValid) {
                //    return;
                //}
                // 儲存記錄
                this.SaveRecord();

                var info = new DynamicPages.Base_Struct_GoPayment();
                info.Price = this.Price();
                info.Points = this.Points();
                info.EveryDayPoints = this.EveryDayPoints();
                info.GiftPoints = this.GiftPoints();
                info.ValueID = this.ValueID();
                info.ProductID = ID;

                info.ECoupon = "";
                info.InvoiceType = 0;
                info.InvoiceEmail = "";
                info.InvoiceName = "";
                info.InvoiceCityID = 0;
                info.InvoiceZoneID = "";
                info.InvoiceAddress = "";
                info.ECoupon = this.ECoupon();
                info.InvoiceType = this.InvoiceType();
                info.InvoiceEmail = this.InvoiceEmail();
                info.InvoiceName = this.InvoiceName();
                info.InvoiceCityID = this.InvoiceCityID();
                info.InvoiceZoneID = this.InvoiceZoneID();
                info.InvoiceAddress = this.InvoiceAddress();
                this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
            };

            // 儲存紀錄
            PointBuyOnline.prototype.SaveRecord = function () {
                var record = new DynamicPages.Base_Struct_PayRecord();
                record.ValueID = this.ValueID();
                record.ProductID = this.ProductID();
                record.InvoiceType = this.InvoiceType();
                record.InvoiceEmail = this.InvoiceEmail();
                record.InvoiceName = this.InvoiceName();
                record.InvoiceCityID = this.InvoiceCityID();
                record.InvoiceZoneID = this.InvoiceZoneID();
                record.InvoiceAddress = this.InvoiceAddress();

                this.Base_Set_Record(record);
            };

            // 顯示錯誤訊息
            PointBuyOnline.prototype.ShowMessage = function (code) {
                if (code == null) {
                    return;
                } else {
                    this.IsAgree(true);
                }

                switch (code) {
                    case 0:
                        break;

                    case 1:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[1]);
                        break;

                    case 2:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                        break;

                    case -3:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[2]);
                        break;

                    case -4:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                        location.href = '/Mvc/DynamicPages/Web/Bank/PointBuyOnline';
                        break;
                    case -1:
                    case -2:
                    case -5:
                    default:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                        break;
                }
            };
            return PointBuyOnline;
        })(DynamicPages.PointBuyBase);
        DynamicPages.PointBuyOnline = PointBuyOnline;
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
