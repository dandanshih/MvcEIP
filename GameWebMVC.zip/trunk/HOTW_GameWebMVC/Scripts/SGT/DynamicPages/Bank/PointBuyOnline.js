var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var PointBuyOnline = (function (_super) {
            __extends(PointBuyOnline, _super);
            function PointBuyOnline() {
                _super.apply(this, arguments);

                this.SuccessImg = "<img src='" + SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/main_content/member/yes.jpg' />";
                this.IsShowLastRecordMemo = ko.observable(false);
                this.ValueList = ko.observableArray([]);
                this.IsShowBlock1 = ko.observable(false);
                this.ValueID = ko.observable(0);
                this.ProductList = ko.observableArray([]);
                this.IsShowBlock2 = ko.observable(false);
                this.ProductID = ko.observable(0);
                this.ProductName = ko.observable("");
                this.IsNeedInvoice = ko.observable(false);
                this.IsNeedECoupon = ko.observable(false);
                this.Price = ko.observable(0);
                this.Points = ko.observable(0);
                this.EveryDayPoints = ko.observable(0);
                this.GiftPoints = ko.observable(0);
                this.ECoupon = ko.observable("");
                this.ECouponErrorMsg = ko.observable("");
                this.InvoiceType = ko.observable(0);
                this.InvoiceEmail = ko.observable("");
                this.InvoiceEmailErrorMsg = ko.observable("");
                this.InvoiceName = ko.observable("");
                this.InvoiceNameErrorMsg = ko.observable("");
                this.InvoiceAddress = ko.observable("");
                this.InvoiceAddressErrorMsg = ko.observable("");
                this.IsAgree = ko.observable(false);
                this.IsAgreeErrorMsg = ko.observable("");
                this.CityList = ko.observableArray([]);
                this.ZoneList = ko.observableArray([]);
                this.InvoiceCityID = ko.observable(0);
                this.InvoiceZoneID = ko.observable("");
            }
            PointBuyOnline.prototype.RecoveryRecord = function () {
                var record = this.Base_Get_PayRecord();
                var isNext = false;
                if(record.ValueID != 0) {
                    var valueList = this.ValueList();
                    var valueItem;
                    for(var i = 0, count = valueList.length; i < count; i++) {
                        if(valueList[i].ID === record.ValueID) {
                            valueItem = valueList[i];
                            isNext = true;
                            break;
                        }
                    }
                    if(valueItem) {
                        this.SetBlock1(valueItem);
                    }
                }
                if(isNext) {
                    isNext = false;
                    if(record.ProductID != 0) {
                        var productList = this.ProductList();
                        var productItem;
                        for(var i = 0, count = productList.length; i < count; i++) {
                            if(productList[i].ID === record.ProductID) {
                                productItem = productList[i];
                                isNext = true;
                                break;
                            }
                        }
                        if(productItem) {
                            this.SetBlock2(productItem);
                        }
                    }
                }
            };
            PointBuyOnline.prototype.SetBlock1 = function (item) {
                if(item) {
                    this.IsShowBlock1(true);
                    this.ValueID(item.ID);
                    this.ProductList(this.Base_Get_ProductList(item.ProductList));
                } else {
                    this.IsShowBlock1(false);
                    this.ValueID(0);
                    this.ProductList([]);
                }
            };
            PointBuyOnline.prototype.SetBlock2 = function (item) {
                if(item && !item.IsMaintain) {
                    var setting = this.Base_Get_ValueProductSetting(this.ValueID(), item.ID);
                    this.IsShowBlock2(true);
                    this.ProductID(item.ID);
                    this.ProductName(item.Name);
                    this.IsNeedInvoice(item.IsNeedInvoice);
                    this.IsNeedECoupon(setting.IsShowECoupon);
                    this.UpdateTransInfo();
                } else {
                    this.IsShowBlock2(false);
                    this.ProductID(0);
                    this.ProductName("");
                    this.IsNeedInvoice(false);
                    this.IsNeedECoupon(false);
                    this.Price(0);
                    this.Points(0);
                    this.EveryDayPoints(0);
                    this.GiftPoints(0);
                }
            };
            PointBuyOnline.prototype.SetBlock3Default = function () {
                var record = this.Base_Get_PayRecord();
                this.ECoupon("");
                this.ECouponErrorMsg("");
                this.InvoiceType(record.InvoiceType >= 0 && record.InvoiceType <= 2 ? record.InvoiceType : 0);
                this.InvoiceEmail(record.InvoiceEmail);
                this.InvoiceEmailErrorMsg("");
                this.InvoiceName(record.InvoiceName);
                this.InvoiceNameErrorMsg("");
                this.InvoiceCityID(record.InvoiceCityID);
                this.InvoiceZoneID(record.InvoiceZoneID);
                this.CityList(this.Base_Get_CityList());
                this.ZoneList(this.Base_Get_ZoneList(record.InvoiceCityID));
                this.InvoiceAddress(record.InvoiceAddress);
                this.InvoiceAddressErrorMsg("");
                this.IsAgree(false);
                this.IsAgreeErrorMsg("");
            };
            PointBuyOnline.prototype.UpdateTransInfo = function () {
                var transInfo = this.Base_Get_Worth(this.ValueID(), this.ProductID(), this.ECoupon());
                this.Price(transInfo.Price);
                this.Points(transInfo.ResultPoints);
                this.EveryDayPoints(transInfo.EveryDayPoints);
                this.GiftPoints(transInfo.GiftPoints);
            };
            PointBuyOnline.prototype.PageInit = function () {
                this.Base_Init(1);
                this.IsShowLastRecordMemo(this.Base_Get_IsLastRecord());
                this.ValueList(this.Base_Get_ValueList());
                this.SetBlock1();
                this.SetBlock2();
                this.RecoveryRecord();
                this.SetBlock3Default();
            };
            PointBuyOnline.prototype.QueryProduct = function (item) {
                this.IsShowLastRecordMemo(false);
                this.SetBlock1(item);
                this.SetBlock2();
                this.SetBlock3Default();
            };
            PointBuyOnline.prototype.QueryConfirmInfo = function (item) {
                this.IsShowLastRecordMemo(false);
                this.SetBlock2(item);
                this.SetBlock3Default();
            };
            PointBuyOnline.prototype.CityChange = function () {
                var zone = this.Base_Get_ZoneList(this.InvoiceCityID());
                this.ZoneList(zone);
                if(zone.length > 0) {
                    this.InvoiceZoneID(zone[0].ZoneID);
                }
            };
            PointBuyOnline.prototype.CheckECoupon = function () {
                var isSuccess = false;
                var message = "";
                if(this.ECoupon() != "") {
                    var result = this.Base_Check_ECoupon(this.ValueID(), this.ProductID(), this.ECoupon());
                    isSuccess = result.IsSuccess;
                    message = !result.IsSuccess ? result.Message : this.SuccessImg;
                } else {
                    isSuccess = true;
                    message = "";
                }
                if((this.ECouponErrorMsg() != this.SuccessImg && message == this.SuccessImg) || (this.ECouponErrorMsg() == this.SuccessImg && message != this.SuccessImg)) {
                    this.UpdateTransInfo();
                }
                this.ECouponErrorMsg(message);
                return isSuccess;
            };
            PointBuyOnline.prototype.CheckEmail = function () {
                var result = this.Base_Check_Email(this.InvoiceEmail());
                this.InvoiceEmailErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };
            PointBuyOnline.prototype.CheckName = function () {
                var result = this.Base_Check_InvoiceName(this.InvoiceName());
                this.InvoiceNameErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };
            PointBuyOnline.prototype.CheckAddress = function () {
                if(this.InvoiceCityID() == 0) {
                    this.InvoiceAddressErrorMsg($SGT.Message.PointBuyOnline.CheckAddress[0]);
                    return false;
                }
                var result = this.Base_Check_InvoiceAddress(this.InvoiceAddress());
                this.InvoiceAddressErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };
            PointBuyOnline.prototype.CheckAgree = function () {
                this.IsAgreeErrorMsg(this.IsAgree() ? "" : $SGT.Message.PointBuyOnline.CheckAgree[0]);
                return this.IsAgree();
            };
            PointBuyOnline.prototype.GoPayment = function () {
                var isValid = true;
                if(!((this.InvoiceType() == 0) || (this.InvoiceType() == 1 && this.CheckEmail()) || (this.InvoiceType() == 2 && this.CheckName() && this.CheckAddress()))) {
                    isValid = false;
                }
                if(!this.CheckAgree()) {
                    isValid = false;
                }
                if(!isValid) {
                    return;
                }
                this.SaveRecord();
                var info = new DynamicPages.Base_Struct_GoPayment();
                info.Price = this.Price();
                info.Points = this.Points();
                info.EveryDayPoints = this.EveryDayPoints();
                info.GiftPoints = this.GiftPoints();
                info.ValueID = this.ValueID();
                info.ProductID = this.ProductID();
                info.ECoupon = this.ECoupon();
                info.InvoiceType = this.InvoiceType();
                info.InvoiceEmail = this.InvoiceEmail();
                info.InvoiceName = this.InvoiceName();
                info.InvoiceCityID = this.InvoiceCityID();
                info.InvoiceZoneID = this.InvoiceZoneID();
                info.InvoiceAddress = this.InvoiceAddress();
                this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
            };
            PointBuyOnline.prototype.SaveRecord = function () {
                var record = new DynamicPages.Base_Struct_PayRecord();
                record.ValueID = this.ValueID();
                record.ProductID = this.ProductID();
                record.InvoiceType = this.InvoiceType();
                record.InvoiceEmail = this.InvoiceEmail();
                record.InvoiceName = this.InvoiceName();
                record.InvoiceCityID = this.InvoiceCityID();
                record.InvoiceZoneID = this.InvoiceZoneID();
                record.InvoiceAddress = this.InvoiceAddress();
                this.Base_Set_Record(record);
            };
            PointBuyOnline.prototype.ShowMessage = function (code) {
                if(code == null) {
                    return;
                } else {
                    this.IsAgree(true);
                }
                switch(code) {
                    case 0:
                        break;
                    case 1:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[1]);
                        break;
                    case 2:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                        break;
                    case -3:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[2]);
                        break;
                    case -4:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                        location.href = '/Mvc/DynamicPages/Web/Bank/PointBuyOnline';
                        break;
                    case -1:
                    case -2:
                    case -5:
                    default:
                        alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                        break;
                }
            };
            return PointBuyOnline;
        })(DynamicPages.PointBuyBase);
        DynamicPages.PointBuyOnline = PointBuyOnline;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
