var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var TransferCenter = (function (_super) {
            __extends(TransferCenter, _super);
            function TransferCenter() {
                _super.apply(this, arguments);

                this.Platinum = 0;
                this.DetailID = "";
                this.NickNameNo = "";
                this.VerifyNo = "";
                this.VerifyPoints = 0;
                this.VerifyReceiveName = "";
                this.IsShowTransferPanel = ko.observable(true);
                this.IsGeneralMember = ko.observable(false);
                this.TotalPoint = ko.observable(0);
                this.FreePoint = ko.observable(0);
                this.TransferMax = ko.observable(0);
                this.LockPoint = ko.observable(0);
                this.LockDate = ko.observable("");
                this.NickRecord = ko.observableArray([]);
                this.NickName = ko.observable("");
                this.Points = ko.observable(0);
                this.IsShowDelNickName = ko.observable(false);
                this.IsKeepName = ko.observable(true);
                this.TransferMasterList = ko.observableArray([]);
                this.TransferDetailList = ko.observableArray([]);
                this.IsShowVerifyPanel = ko.observable(false);
                this.VerifyCode = ko.observable("");
                this.IsShowSuccessPanel = ko.observable(false);
                this.ConfirmSuccessType = ko.observable(0);
                this.ConfirmSuccessMessage = ko.observable("");
                this.Transfee = ko.observable(0);
                this.SetTransfee = ko.observable(0);
            }
            TransferCenter.prototype.ChangePanel_Transfer = function (isRebind) {
                if(isRebind) {
                    var info = this.Base_Get_Info();
                    this.IsGeneralMember(info.IsGeneralMember);
                    this.TotalPoint(info.TotalPoint);
                    this.FreePoint(info.FreePoint);
                    this.TransferMax(info.TransferMax);
                    this.LockPoint(info.LockPoint);
                    this.LockDate(info.LockDate);
                    this.Transfee(info.Transfee);
                    this.NickRecord(this.Base_Get_Member());
                    this.TransferMasterList(this.Base_Get_TransferMaster());
                }
                this.NickName("");
                this.Points(0);
                this.SetTargetName();
                this.GetTransfee();
                this.IsShowTransferPanel(true);
                this.IsShowVerifyPanel(false);
                this.IsShowSuccessPanel(false);
            };
            TransferCenter.prototype.ChangePanel_Verify = function (no, point, receiveName) {
                this.VerifyNo = no;
                this.VerifyPoints = point;
                this.VerifyReceiveName = receiveName;
                this.VerifyCode("");
                this.IsShowTransferPanel(false);
                this.IsShowVerifyPanel(true);
                this.IsShowSuccessPanel(false);
            };
            TransferCenter.prototype.ChangePanel_Success = function (type, message) {
                this.ConfirmSuccessType(type);
                this.ConfirmSuccessMessage(message);
                this.IsShowTransferPanel(false);
                this.IsShowVerifyPanel(false);
                this.IsShowSuccessPanel(true);
            };
            TransferCenter.prototype.SetTargetName = function (item) {
                if(item) {
                    this.IsShowDelNickName(true);
                    this.NickName(item.Name);
                    this.NickNameNo = item.No;
                } else {
                    this.IsShowDelNickName(false);
                    this.NickNameNo = "";
                }
            };
            TransferCenter.prototype.PageInit = function (platinum, detailId) {
                this.Platinum = platinum;
                this.DetailID = detailId;
                this.ChangePanel_Transfer(true);
            };
            TransferCenter.prototype.SetNickName = function (item) {
                this.SetTargetName(item);
            };
            TransferCenter.prototype.DelNickName = function () {
                if(this.NickNameNo) {
                    this.Base_Del_Member(this.NickNameNo);
                    this.NickRecord(this.Base_Get_Member());
                    this.SetTargetName();
                }
            };
            TransferCenter.prototype.GoTransfer = function () {
                var result;
                result = this.Base_Check_Nick(this.NickName());
                if(result.Code != 0) {
                    alert(result.Message);
                    return;
                }
                result = this.Base_Check_Point(this.Points());
                if(result.Code != 0) {
                    alert(result.Message);
                    return;
                }
                result = this.Base_Submit_MemberTransfer(this.NickName(), this.Points(), this.IsKeepName(), this.Platinum);
                if(result.Code == 0) {
                    this.ChangePanel_Success(0);
                    var info = this.Base_Get_Info();
                    this.IsGeneralMember(info.IsGeneralMember);
                    this.TotalPoint(info.TotalPoint);
                    this.FreePoint(info.FreePoint);
                    this.TransferMax(info.TransferMax);
                    this.LockPoint(info.LockPoint);
                    this.LockDate(info.LockDate);
                    this.TransferMasterList(this.Base_Get_TransferMaster());
                    setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
                } else {
                    alert(result.Message);
                }
            };
            TransferCenter.prototype.GoTransferAgree = function (item) {
                var result = this.Base_Submit_TransferConfirm(item.No, 1);
                if(result.IsSuccess) {
                    this.ChangePanel_Success(1);
                    this.TransferMasterList(this.Base_Get_TransferMaster());
                    if(result.IsRegainPoint) {
                        setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
                    }
                } else {
                    alert(result.Message);
                }
            };
            TransferCenter.prototype.GoTransferCancel = function (item) {
                var result = this.Base_Submit_TransferConfirm(item.No, 2);
                if(result.IsSuccess) {
                    this.ChangePanel_Success(2);
                    this.TransferMasterList(this.Base_Get_TransferMaster());
                    if(result.IsRegainPoint) {
                        setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
                    }
                } else {
                    alert(result.Message);
                }
            };
            TransferCenter.prototype.GoVerifyPanel = function (item) {
                this.ChangePanel_Verify(item.No, item.Points, item.ReceiveName);
            };
            TransferCenter.prototype.GoTransferVerify = function () {
                if(!this.VerifyNo) {
                    return;
                }
                var result;
                result = this.Base_Check_VerifyCode(this.VerifyCode());
                if(result.Code != 0) {
                    alert(result.Message);
                    return;
                }
                var verifyResult = this.Base_Submit_TransferVerify(this.VerifyNo, this.VerifyCode());
                if(verifyResult.IsSuccess) {
                    var platform = "Web";
                    if(typeof GetPlatform == 'function') {
                        platform = GetPlatform();
                    }
                    if(platform.toLowerCase() == 'online113') {
                        this.ChangePanel_Success(3, $SGT.Message.TransferCenter.GoTransferVerify[1].format(this.VerifyPoints['addCommas'](), this.VerifyReceiveName));
                    } else {
                        this.ChangePanel_Success(3, $SGT.Message.TransferCenter.GoTransferVerify[0].format(this.VerifyPoints['addCommas'](), this.VerifyReceiveName));
                    }
                    this.NickRecord(this.Base_Get_Member());
                    this.TransferMasterList(this.Base_Get_TransferMaster());
                    if(verifyResult.IsRegainPoint) {
                        setTimeout(SGT["Main"].QueryFns["Member"].getMemberPoint, 1000);
                    }
                } else {
                    alert(verifyResult.Message);
                }
            };
            TransferCenter.prototype.SendSMSCode = function () {
                var result = this.Base_Submit_SendSMSCode(this.VerifyNo);
                alert(result.Message);
            };
            TransferCenter.prototype.QueryDetail = function (item) {
                this.TransferDetailList(this.Base_Query_TransferDetail(item.No));
            };
            TransferCenter.prototype.GoTransferPanel = function () {
                this.ChangePanel_Transfer(false);
            };
            TransferCenter.prototype.GetTransfee = function () {
                if(this.Points() > 0 && this.Transfee() > 0) {
                    this.SetTransfee(Math.ceil(this.Points() * this.Transfee()));
                } else {
                    this.SetTransfee(0);
                }
            };
            return TransferCenter;
        })(DynamicPages.TransferBase);
        DynamicPages.TransferCenter = TransferCenter;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
