﻿var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var SGT;
(function (SGT) {
    (function (DynamicPages) {
        var PointBuyMonthly = (function (_super) {
            __extends(PointBuyMonthly, _super);
            function PointBuyMonthly() {
                _super.apply(this, arguments);

                this.IsShowLastRecordMemo = ko.observable(false);
                this.ValueList = ko.observableArray([]);
                this.IsShowBlock1 = ko.observable(false);
                this.ValueID = ko.observable(0);
                this.ProductList = ko.observableArray([]);
                this.IsShowBlock2 = ko.observable(false);
                this.ProductID = ko.observable(0);
                this.ProductName = ko.observable("");
                this.IsNeedInvoice = ko.observable(false);
                this.Price = ko.observable(0);
                this.Points = ko.observable(0);
                this.EveryDayPoints = ko.observable(0);
                this.GiftPoints = ko.observable(0);
                this.InvoiceType = ko.observable(0);
                this.InvoiceEmail = ko.observable("");
                this.InvoiceEmailErrorMsg = ko.observable("");
                this.InvoiceName = ko.observable("");
                this.InvoiceNameErrorMsg = ko.observable("");
                this.InvoiceAddress = ko.observable("");
                this.InvoiceAddressErrorMsg = ko.observable("");
                this.IsAgree = ko.observable(false);
                this.IsAgreeErrorMsg = ko.observable("");
                this.CityList = ko.observableArray([]);
                this.ZoneList = ko.observableArray([]);
                this.InvoiceCityID = ko.observable(0);
                this.InvoiceZoneID = ko.observable("");
            }
            PointBuyMonthly.prototype.RecoveryRecord = function () {
                var record = this.Base_Get_PayRecord();
                var isNext = false;
                if(record.ValueID != 0) {
                    var valueList = this.ValueList();
                    var valueItem;
                    for(var i = 0, count = valueList.length; i < count; i++) {
                        if(valueList[i].ID === record.ValueID) {
                            valueItem = valueList[i];
                            isNext = true;
                            break;
                        }
                    }
                    if(valueItem) {
                        this.SetBlock1(valueItem);
                    }
                }
                if(isNext) {
                    isNext = false;
                    if(record.ProductID != 0) {
                        var productList = this.ProductList();
                        var productItem;
                        for(var i = 0, count = productList.length; i < count; i++) {
                            if(productList[i].ID === record.ProductID) {
                                productItem = productList[i];
                                isNext = true;
                                break;
                            }
                        }
                        if(productItem) {
                            this.SetBlock2(productItem);
                        }
                    }
                }
            };
            PointBuyMonthly.prototype.SetBlock1 = function (item) {
                if(item) {
                    this.IsShowBlock1(true);
                    this.ValueID(item.ID);
                    this.ProductList(this.Base_Get_ProductList(item.ProductList));
                } else {
                    this.IsShowBlock1(false);
                    this.ValueID(0);
                    this.ProductList([]);
                }
            };
            PointBuyMonthly.prototype.SetBlock2 = function (item) {
                if(item && !item.IsMaintain) {
                    this.IsShowBlock2(true);
                    this.ProductID(item.ID);
                    this.ProductName(item.Name);
                    this.IsNeedInvoice(item.IsNeedInvoice);
                    this.UpdateTransInfo();
                } else {
                    this.IsShowBlock2(false);
                    this.ProductID(0);
                    this.ProductName("");
                    this.IsNeedInvoice(false);
                    this.Price(0);
                    this.Points(0);
                    this.EveryDayPoints(0);
                    this.GiftPoints(0);
                }
            };
            PointBuyMonthly.prototype.SetBlock3Default = function () {
                var record = this.Base_Get_PayRecord();
                this.InvoiceType(record.InvoiceType >= 0 && record.InvoiceType <= 2 ? record.InvoiceType : 0);
                this.InvoiceEmail(record.InvoiceEmail);
                this.InvoiceEmailErrorMsg("");
                this.InvoiceName(record.InvoiceName);
                this.InvoiceNameErrorMsg("");
                this.InvoiceCityID(record.InvoiceCityID);
                this.InvoiceZoneID(record.InvoiceZoneID);
                this.CityList(this.Base_Get_CityList());
                this.ZoneList(this.Base_Get_ZoneList(record.InvoiceCityID));
                this.InvoiceAddress(record.InvoiceAddress);
                this.InvoiceAddressErrorMsg("");
                this.IsAgree(false);
                this.IsAgreeErrorMsg("");
            };
            PointBuyMonthly.prototype.UpdateTransInfo = function () {
                var transInfo = this.Base_Get_Worth(this.ValueID(), this.ProductID());
                this.Price(transInfo.Price);
                this.Points(transInfo.ResultPoints);
                this.EveryDayPoints(transInfo.EveryDayPoints);
                this.GiftPoints(transInfo.GiftPoints);
            };
            PointBuyMonthly.prototype.PageInit = function () {
                this.Base_Init(3);
                this.IsShowLastRecordMemo(this.Base_Get_IsLastRecord());
                this.ValueList(this.Base_Get_ValueList());
                this.SetBlock1();
                this.SetBlock2();
                this.RecoveryRecord();
                this.SetBlock3Default();
            };
            PointBuyMonthly.prototype.QueryProduct = function (item) {
                this.IsShowLastRecordMemo(false);
                this.SetBlock1(item);
                this.SetBlock2();
                this.SetBlock3Default();
            };
            PointBuyMonthly.prototype.QueryConfirmInfo = function (item) {
                this.IsShowLastRecordMemo(false);
                this.SetBlock2(item);
                this.SetBlock3Default();
            };
            PointBuyMonthly.prototype.CityChange = function () {
                var zone = this.Base_Get_ZoneList(this.InvoiceCityID());
                this.ZoneList(zone);
                if(zone.length > 0) {
                    this.InvoiceZoneID(zone[0].ZoneID);
                }
            };
            PointBuyMonthly.prototype.CheckEmail = function () {
                var result = this.Base_Check_Email(this.InvoiceEmail());
                this.InvoiceEmailErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };
            PointBuyMonthly.prototype.CheckName = function () {
                var result = this.Base_Check_InvoiceName(this.InvoiceName());
                this.InvoiceNameErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };
            PointBuyMonthly.prototype.CheckAddress = function () {
                if(this.InvoiceCityID() == 0) {
                    this.InvoiceAddressErrorMsg($SGT.Message.PointBuyMonthly.CheckAddress[0]);
                    return false;
                }
                var result = this.Base_Check_InvoiceAddress(this.InvoiceAddress());
                this.InvoiceAddressErrorMsg(result.IsSuccess ? "" : result.Message);
                return result.IsSuccess;
            };
            PointBuyMonthly.prototype.CheckAgree = function () {
                this.IsAgreeErrorMsg(this.IsAgree() ? "" : $SGT.Message.PointBuyMonthly.CheckAgree[0]);
                return this.IsAgree();
            };
            PointBuyMonthly.prototype.GoPayment = function () {
                var isValid = true;
                if(!((this.InvoiceType() == 0) || (this.InvoiceType() == 1 && this.CheckEmail()) || (this.InvoiceType() == 2 && this.CheckName() && this.CheckAddress()))) {
                    isValid = false;
                }
                if(!this.CheckAgree()) {
                    isValid = false;
                }
                if(!isValid) {
                    return;
                }
                this.SaveRecord();
                var info = new DynamicPages.Base_Struct_GoPayment();
                info.Price = this.Price();
                info.Points = this.Points();
                info.EveryDayPoints = this.EveryDayPoints();
                info.GiftPoints = this.GiftPoints();
                info.ValueID = this.ValueID();
                info.ProductID = this.ProductID();
                info.InvoiceType = this.InvoiceType();
                info.InvoiceEmail = this.InvoiceEmail();
                info.InvoiceName = this.InvoiceName();
                info.InvoiceCityID = this.InvoiceCityID();
                info.InvoiceZoneID = this.InvoiceZoneID();
                info.InvoiceAddress = this.InvoiceAddress();
                this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
            };
            PointBuyMonthly.prototype.SaveRecord = function () {
                var record = new DynamicPages.Base_Struct_PayRecord();
                record.ValueID = this.ValueID();
                record.ProductID = this.ProductID();
                record.InvoiceType = this.InvoiceType();
                record.InvoiceEmail = this.InvoiceEmail();
                record.InvoiceName = this.InvoiceName();
                record.InvoiceCityID = this.InvoiceCityID();
                record.InvoiceZoneID = this.InvoiceZoneID();
                record.InvoiceAddress = this.InvoiceAddress();
                this.Base_Set_Record(record);
            };
            PointBuyMonthly.prototype.ShowMessage = function (code) {
                if(code == null) {
                    return;
                } else {
                    this.IsAgree(true);
                }
                switch(code) {
                    case 0:
                        break;
                    case 1:
                        alert($SGT.Message.PointBuyMonthly.ShowMessage[1]);
                        break;
                    case 2:
                        alert($SGT.Message.PointBuyMonthly.ShowMessage[0]);
                        break;
                    case -3:
                        alert($SGT.Message.PointBuyMonthly.ShowMessage[2]);
                        break;
                    case -4:
                        alert($SGT.Message.PointBuyMonthly.ShowMessage[0]);
                        location.href = '/Mvc/DynamicPages/Web/Bank/PointBuyMonthly';
                        break;
                    case -1:
                    case -2:
                    case -5:
                    case -6:
                        alert($SGT.Message.PointBuyMonthly.ShowMessage[3]);
                        location.href = '/Mvc/DynamicPages/Web/Bank/PointBuyMonthly';
                        break;
                    default:
                        alert($SGT.Message.PointBuyMonthly.ShowMessage[0]);
                        break;
                }
            };
            PointBuyMonthly.prototype.NewMonthPaymentDiscountCheck = function () {
                var _ResultCode = this.Base_Get_ResultCode();
                var _ResultMsg = "";
                switch(_ResultCode) {
                    case 0:
                        _ResultMsg = "此帳號符合活動條件！";
                        break;
                    case 1:
                        _ResultMsg = "活動已經結束囉！";
                        break;
                    case 2:
                        _ResultMsg = "此帳號不符合活動條件。原因：未通過手機驗證。";
                        break;
                    case 3:
                        _ResultMsg = "此帳號不符合活動條件。原因：此帳號曾購買過包月。";
                        break;
                    case 4:
                        _ResultMsg = "此帳號不符合活動條件。原因：同手機驗證之相關帳號已選購過包月。";
                        break;
                    case 5:
                        _ResultMsg = "此帳號不符合活動條件。原因：您尚未具備普卡資格，請先儲值升級享有更多優惠喔！";
                        break;
                    case 6:
                        _ResultMsg = "此帳號不符合活動條件。原因：您已有包月首購半價交易正在進行中！";
                        break;
                    default:
                        _ResultMsg = "此帳號不符合活動條件。";
                        break;
                }
                alert(_ResultMsg);
                return;
            };
            return PointBuyMonthly;
        })(DynamicPages.PointBuyBase);
        DynamicPages.PointBuyMonthly = PointBuyMonthly;        
    })(SGT.DynamicPages || (SGT.DynamicPages = {}));
    var DynamicPages = SGT.DynamicPages;
})(SGT || (SGT = {}));
