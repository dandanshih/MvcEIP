/// <reference path="../Base/PointBuyBase.ts" />
declare var ko;

module SGT.DynamicPages {
    // �u�W���I
    export class PointBuyOnline extends PointBuyBase {

        /// --------------------------------------
        /// property
        /// --------------------------------------
        // ���Ҧ��\�Ϥ�
        SuccessImg: string = "<img src='" + SGT.WebSiteInfo.Urls.CdnUrl + "/Html/Images/Layout/main_content/member/yes.jpg' />";

        /// --------------------------------------
        /// ko function
        /// --------------------------------------
        // Init
        // �O�_�ϥγ̫�@�����ާ@����
        IsShowLastRecordMemo: (input?: bool) => bool = ko.observable(false);
        // ���B�C��
        ValueList: (input?: Base_Struct_ValueList[]) => Base_Struct_ValueList[] = ko.observableArray([]);

        // Block1
        // �O�_��ܥI�O�覡�C���B�J
        IsShowBlock1: (input?: bool) => bool = ko.observable(false);
        // �ϥΪ̿�������B�s��
        ValueID: (input?: number) => number = ko.observable(0);
        // �I�O�覡�C��
        ProductList: (input?: Base_Struct_ProductList[]) => Base_Struct_ProductList[] = ko.observableArray([]);

        // Block2
        // �O�_��ܥI�O�覡�C���B�J
        IsShowBlock2: (input?: bool) => bool = ko.observable(false);
        // �ϥΪ̿�����I�O�覡�s��
        ProductID: (input?: number) => number = ko.observable(0);
        // �ϥΪ̿�����I�O�覡�W��
        ProductName: (input?: string) => string = ko.observable("");
        // �I�O�覡�O�_�ݭn��J�o��
        IsNeedInvoice: (input?: bool) => bool = ko.observable(false);
        // �O�_��ܿ�J������B�J
        IsNeedECoupon: (input?: bool) => bool = ko.observable(false);
        // �ثe������B
        Price: (input?: number) => number = ko.observable(0);
        // �ثe����I��
        Points: (input?: number) => number = ko.observable(0);
        // �ثe�C����I
        EveryDayPoints: (input?: number) => number = ko.observable(0);
        // �ثe���I(�ثe�L��)
        GiftPoints: (input?: number) => number = ko.observable(0);

        // Block3
        // �ϥΪ̿�J���x�ȧ����Ǹ�
        ECoupon: (input?: string) => string = ko.observable("");
        // �x�ȧ����Ǹ������~�T��
        ECouponErrorMsg: (input?: string) => string = ko.observable("");
        // �o������
        InvoiceType: (input?: number) => number = ko.observable(0);
        // �q�l�o���H�e�q�l�H�c
        InvoiceEmail: (input?: string) => string = ko.observable("");
        // �q�l�o���H�e�q�l�H�c���~�T��
        InvoiceEmailErrorMsg: (input?: string) => string = ko.observable("");
        // �o������H
        InvoiceName: (input?: string) => string = ko.observable("");
        // �o������H���~�T��
        InvoiceNameErrorMsg: (input?: string) => string = ko.observable("");
        // �o������a�}
        InvoiceAddress: (input?: string) => string = ko.observable("");
        // �o������a�}���~�T��
        InvoiceAddressErrorMsg: (input?: string) => string = ko.observable("");
        // �ڦP�N�Ŀ�
        IsAgree: (input?: bool) => bool = ko.observable(false);
        // �ڦP�N�Ŀ���~�T��
        IsAgreeErrorMsg: (input?: string) => string = ko.observable("");
        // �����C��
        CityList: (input?: Base_Struct_CityList[]) => Base_Struct_CityList[] = ko.observableArray([]);
        // �m�����C��
        ZoneList: (input?: Base_Struct_ZoneList[]) => Base_Struct_ZoneList[] = ko.observableArray([]);
        // �ϥΪ̿�����o������a�}�����s��
        InvoiceCityID: (input?: number) => number = ko.observable(0);
        // �ϥΪ̿�����o������a�}�m�����s��
        InvoiceZoneID: (input?: string) => string = ko.observable("");


        /// --------------------------------------
        /// private function
        /// --------------------------------------
        // Ū�� Block1�B2 �O��
        private RecoveryRecord(): void {

            var record = this.Base_Get_PayRecord();
            var isNext = false;

            // �_��Block1 ���B
            if (record.ValueID != 0) {

                // ���o�ӵ����B��T
                var valueList = this.ValueList();
                var valueItem: Base_Struct_ValueList;

                for (var i = 0, count = valueList.length; i < count; i++) {
                    if (valueList[i].ID === record.ValueID) {
                        valueItem = valueList[i];
                        isNext = true;
                        break;
                    }
                }

                if (valueItem) {
                    this.SetBlock1(valueItem);
                }
            }

            // �_��Block2 �I�ڤ覡
            if (isNext) {
                isNext = false;

                if (record.ProductID != 0) {

                    // ���o�ӵ��I�ڤ覡��T
                    var productList = this.ProductList();
                    var productItem: Base_Struct_ProductList;

                    for (var i = 0, count = productList.length; i < count; i++) {
                        if (productList[i].ID === record.ProductID) {
                            productItem = productList[i];
                            isNext = true;
                            break;
                        }
                    }

                    if (productItem) {
                        this.SetBlock2(productItem);
                    }
                }
            }
        }

        // �]�w Block1 ���
        private SetBlock1(item?: Base_Struct_ValueList): void {

            if (item) {
                this.IsShowBlock1(true);
                this.ValueID(item.ID);
                this.ProductList(this.Base_Get_ProductList(item.ProductList));
            } else {
                this.IsShowBlock1(false);
                this.ValueID(0);
                this.ProductList([]);
            }
        }

        // �]�w Block2 ���
        private SetBlock2(item?: Base_Struct_ProductList): void {
            if (item && !item.IsMaintain) {
                // �]�w Block2 ���
                var setting = this.Base_Get_ValueProductSetting(this.ValueID(), item.ID);

                this.IsShowBlock2(true);
                this.ProductID(item.ID);
                this.ProductName(item.Name);
                this.IsNeedInvoice(item.IsNeedInvoice);
                this.IsNeedECoupon(setting.IsShowECoupon);
                this.UpdateTransInfo();
            } else {
                this.IsShowBlock2(false);
                this.ProductID(0);
                this.ProductName("");
                this.IsNeedInvoice(false);
                this.IsNeedECoupon(false);
                this.Price(0);
                this.Points(0);
                this.EveryDayPoints(0);
                this.GiftPoints(0);
            }
        }

        // �٭� Block3 �w�]���
        private SetBlock3Default(): void {
            var record = this.Base_Get_PayRecord();

            this.ECoupon("");
            this.ECouponErrorMsg("");

            this.InvoiceType(record.InvoiceType >= 0 && record.InvoiceType <= 2 ? record.InvoiceType : 0);

            this.InvoiceEmail(record.InvoiceEmail);
            this.InvoiceEmailErrorMsg("");

            this.InvoiceName(record.InvoiceName);
            this.InvoiceNameErrorMsg("");
            this.InvoiceCityID(record.InvoiceCityID);
            this.InvoiceZoneID(record.InvoiceZoneID);
            this.CityList(this.Base_Get_CityList());
            this.ZoneList(this.Base_Get_ZoneList(record.InvoiceCityID));
            this.InvoiceAddress(record.InvoiceAddress);
            this.InvoiceAddressErrorMsg("");

            this.IsAgree(false);
            this.IsAgreeErrorMsg("");
        }

        // ��s������B�B�I��
        private UpdateTransInfo(): void {
            var transInfo = this.Base_Get_Worth(this.ValueID(), this.ProductID(), this.ECoupon());
            this.Price(transInfo.Price);
            this.Points(transInfo.ResultPoints);
            this.EveryDayPoints(transInfo.EveryDayPoints);
            this.GiftPoints(transInfo.GiftPoints);
        }


        /// --------------------------------------
        /// public function
        /// --------------------------------------
        // �������J��l�ư򥻸��
        PageInit(): void {

            this.Base_Init(1);

            // �]�w Init ���
            this.IsShowLastRecordMemo(this.Base_Get_IsLastRecord());
            this.ValueList(this.Base_Get_ValueList());

            // �M�� Block1�B2 ���
            this.SetBlock1();
            this.SetBlock2();

            // Ū�� Block1�B2 �O��
            this.RecoveryRecord();

            // �٭� Block3 �w�]���
            this.SetBlock3Default();
        }

        // �d�ߥI�ڤ覡�C��
        QueryProduct(item: Base_Struct_ValueList): void {

            // �����w�]�ﶵ����
            this.IsShowLastRecordMemo(false);

            // �]�w Block1 ���
            this.SetBlock1(item);

            // �M�� Block2 ���
            this.SetBlock2();

            // �٭� Block3 �w�]���
            this.SetBlock3Default();
        }

        // �d�߽T�{��Ƥ��e
        QueryConfirmInfo(item: Base_Struct_ProductList): void {

            // �����w�]�ﶵ����
            this.IsShowLastRecordMemo(false);

            // �]�w Block2 ���
            this.SetBlock2(item);

            // �٭� Block3 �w�]���
            this.SetBlock3Default();
        }

        // �����U�Կ��change�ƥ�
        CityChange(): void {
            var zone = this.Base_Get_ZoneList(this.InvoiceCityID());

            // ô���ϦC��
            this.ZoneList(zone);

            // �N ZoneID ���ܲĤ@�Ӷ���
            if (zone.length > 0) {
                this.InvoiceZoneID(zone[0].ZoneID);
            }
        }

        // ���� ECoupon
        CheckECoupon(): bool {

            var isSuccess = false;
            var message = "";

            if (this.ECoupon() != "") {
                var result = this.Base_Check_ECoupon(this.ValueID(), this.ProductID(), this.ECoupon());
                isSuccess = result.IsSuccess;
                message = !result.IsSuccess ? result.Message : this.SuccessImg;
            } else {
                isSuccess = true;
                message = "";
            }

            if ((this.ECouponErrorMsg() != this.SuccessImg && message == this.SuccessImg) ||
                (this.ECouponErrorMsg() == this.SuccessImg && message != this.SuccessImg)) {
                // ��s������B��T
                this.UpdateTransInfo();
            }

            this.ECouponErrorMsg(message);
            return isSuccess;
        }

        // ���� Email
        CheckEmail(): bool {
            var result = this.Base_Check_Email(this.InvoiceEmail());
            this.InvoiceEmailErrorMsg(result.IsSuccess ? "" : result.Message);
            return result.IsSuccess;
        }

        // ���� �o������H
        CheckName(): bool {
            var result = this.Base_Check_InvoiceName(this.InvoiceName());
            this.InvoiceNameErrorMsg(result.IsSuccess ? "" : result.Message);
            return result.IsSuccess;
        }

        // ���� �o���H�e�a�}
        CheckAddress(): bool {

            // ���ҿ����ﶵ
            if (this.InvoiceCityID() == 0) {
                this.InvoiceAddressErrorMsg($SGT.Message.PointBuyOnline.CheckAddress[0]);
                return false;
            }

            // ���Ҧa�}�榡
            var result = this.Base_Check_InvoiceAddress(this.InvoiceAddress());
            this.InvoiceAddressErrorMsg(result.IsSuccess ? "" : result.Message);
            return result.IsSuccess;
        }

        // ���ҬO�_�Ŀ�ڦP�N
        CheckAgree(): bool {
            this.IsAgreeErrorMsg(this.IsAgree() ? "" : $SGT.Message.PointBuyOnline.CheckAgree[0]);
            return this.IsAgree();
        }


        // �T�{�I��
        GoPayment(): void {
            
            var isValid = true;

            if (!(
                (this.InvoiceType() == 0) ||
                (this.InvoiceType() == 1 && this.CheckEmail()) ||
                (this.InvoiceType() == 2 && this.CheckName() && this.CheckAddress())
                )) {
                isValid = false;
            }

            if (!this.CheckAgree()) {
                isValid = false;
            }

            if (!isValid) {
                return;
            }

            // �x�s�O��
            this.SaveRecord();

            var info = new Base_Struct_GoPayment();
            info.Price = this.Price()
            info.Points = this.Points();
            info.EveryDayPoints = this.EveryDayPoints();
            info.GiftPoints = this.GiftPoints();
            info.ValueID = this.ValueID();
            info.ProductID = this.ProductID();
            info.ECoupon = this.ECoupon();
            info.InvoiceType = this.InvoiceType();
            info.InvoiceEmail = this.InvoiceEmail();
            info.InvoiceName = this.InvoiceName();
            info.InvoiceCityID = this.InvoiceCityID();
            info.InvoiceZoneID = this.InvoiceZoneID();
            info.InvoiceAddress = this.InvoiceAddress();
            this.Base_Submit_GoPayment("/Mvc/DynamicPages/Web/Bank/PointBuyWebRedirect", false, info);
        }

        // �x�s����
        SaveRecord(): void {
            var record = new Base_Struct_PayRecord();
            record.ValueID = this.ValueID();
            record.ProductID = this.ProductID();
            record.InvoiceType = this.InvoiceType();
            record.InvoiceEmail = this.InvoiceEmail();
            record.InvoiceName = this.InvoiceName();
            record.InvoiceCityID = this.InvoiceCityID();
            record.InvoiceZoneID = this.InvoiceZoneID();
            record.InvoiceAddress = this.InvoiceAddress();

            this.Base_Set_Record(record);
        }

        // ��ܿ��~�T��
        ShowMessage(code: number): void {
            if (code == null) {
                return;
            } else {
                this.IsAgree(true);
            }

            switch (code) {
                // ���\
                case 0:
                    // �|�۰ʾɭ�
                    break;
                // ValueID �� ProductID �p�󵥩�0
                case 1:
                    alert($SGT.Message.PointBuyOnline.ShowMessage[1]);
                    break;
                // ������B���I�� �p�󵥩�0
                case 2:
                    alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                    break;
                // �x�ȶW�L���B
                case -3:
                    alert($SGT.Message.PointBuyOnline.ShowMessage[2]);
                    break;
                // �ʶR�I�ƤΪ��B���~
                case -4:
                    alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                    location.href = '/Mvc/DynamicPages/Web/Bank/PointBuyOnline';
                    break;
                case -1:    // �L���|��
                case -2:    // �����q��إߥ���
                case -5:    // �������@���A�L�k�x��
                default:
                    alert($SGT.Message.PointBuyOnline.ShowMessage[0]);
                    break;
            }
        }
    }
}
