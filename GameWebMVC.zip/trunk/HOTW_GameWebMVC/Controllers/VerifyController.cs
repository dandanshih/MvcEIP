﻿using HOTW_GameWebMVC.AppLibs;
using System.IO;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Controllers
{
    public class VerifyController : Controller
    {
        [AcceptVerbs("Get")]
        public FileResult GetVerifyCode()
        {
            RandomCode gif = new RandomCode();                              // 初始化驗證碼生成類別
            string valid = "";                                              // 定義隨機數
            MemoryStream ms = gif.Create(out valid);                        // 獲取包括驗證碼圖片的內存流
            Session["gif"] = valid;                                         // 驗證碼儲存在 Session 中供驗證

            return File(ms.ToArray(), "image/png");
        }
    }
}
