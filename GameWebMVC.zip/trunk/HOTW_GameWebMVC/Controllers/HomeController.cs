﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GS.Web.CommunityGateway.StoreAPI;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.Attributes;
using System.Data.SqlClient;
using System.Data;
using GS.Utilities;

namespace HOTW_GameWebMVC.Controllers
{
    public class HomeController : Controller
    {
        [PreLogin]
        public ActionResult _LoginPartial()
        {
            return PartialView("~/Areas/DynamicPages/Views/Shared/_LoginPartial.cshtml");
        }

        [HttpGet]
        public ActionResult Index(string id)
        {
            // 進到官網首頁把記錄物活動進來的flag移除
            Session.Remove("NoRedirect");
            Session.Remove("IsReflesh");
            if (Session["CWLoginResultCode"] != null && Session["CWLoginResultMsg"] != null)
            {
                ViewBag.CWLoginResultCode = Session["CWLoginResultCode"];
                ViewBag.CWLoginResultMsg = Session["CWLoginResultMsg"];

                Session.Remove("CWLoginResultCode");
                Session.Remove("CWLoginResultMsg");
            }
            else
            {
                ViewBag.CWLoginResultCode = "";
                ViewBag.CWLoginResultMsg = "";
            }
            if (Session["CWReturnResultCode"] != null && Session["CWReturnResultMsg"] != null)
            {
                ViewBag.CWReturnResultCode = Session["CWReturnResultCode"];
                ViewBag.CWReturnResultMsg = Session["CWReturnResultMsg"];

                Session.Remove("CWReturnResultCode");
                Session.Remove("CWReturnResultMsg");
            }
            else
            {
                ViewBag.CWReturnResultCode = "";
                ViewBag.CWReturnResultMsg = "";
            }
            if (!string.IsNullOrEmpty(id))
            {
                long SType = 0;
                if (long.TryParse(id, out SType))
                {
                    Session["ShortcutType"] = id;
                    //if (Session["IsLogin"] != null)
                    //{
                    //	MemberEventUtility.GetShortcutGift();
                    //}
                }
            }
            return View();
        }

        public string Version()
        {
            System.Text.StringBuilder objSB = new System.Text.StringBuilder();

            objSB.AppendFormat
            (
                "HOTW_GameWebMVC Version: {0}<br />",
                System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
            );
            try
            {
                objSB.AppendFormat
                (
                    "GameWeb_Views Version: {0}<br />",
                    System.Reflection.Assembly.Load("GameWeb_Views").GetName().Version.ToString()
                );
            }
            catch (Exception ex) { }

            return objSB.ToString();
        }

        public void ad_link()
        {
            string _s = Request.QueryString["s"];

            if (string.IsNullOrEmpty(_s) || string.IsNullOrWhiteSpace(_s))
            {
                Response.Redirect("/Mvc/Home/Index", false);

                return;
            }

            if (Request.Cookies["s"] != null)
            {
                // 當來源ID 與 Cookie 資料相同時就不跑db流程
                if (_s == Request.Cookies["s"].Values["s"].ToString())
                {
                    if (!string.IsNullOrEmpty(Request.Cookies["s"].Values["u"].ToString()) && !string.IsNullOrWhiteSpace(Request.Cookies["s"].Values["u"].ToString()))
                    {
                        Response.Redirect(EncryptUtility.Decode(Request.Cookies["s"].Values["u"].ToString()), true);
                    }
                    else
                    {
                        Response.Redirect("/Mvc/Home/Index", false);
                    }

                    return;
                }
            }

            SqlParameter[] objParam = new SqlParameter[]
            {
                new SqlParameter("@ADSourceID", _s),
                new SqlParameter("@TGLink", SqlDbType.VarChar, 500)
            };

            objParam[1].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_AD_Click_Add",
                objParam
            );

            if (Request.Cookies["s"] == null)
            {
                HttpCookie cookie = new HttpCookie("s");

                cookie.Values.Add("s", _s);
                cookie.Values.Add("u", EncryptUtility.Encrypt(objParam[1].Value.ToString()));

                Response.AppendCookie(cookie);
            }

            Response.Redirect(objParam[1].Value.ToString(), true);
        }
    }
}
