﻿using GS.Web.CPA;
using HOTW_GameWebMVC.AppLibs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Controllers
{
    public class AccountController : Controller
    {
        public ActionResult Register()
        {
            return View();
        }

		public ActionResult MobileAuthentication()
		{
            if (Session["MemberID"] == null || Session["WaitMobileAuthAccount"] == null)
            {
                return Redirect("/Mvc");
            }
			return View();
		}

		public ActionResult CancelMobileAuthentication()
		{
			return View();
		}

		public ActionResult MobileAuthenticationFrequently()
		{
			return View();
		}

		public ActionResult ForgetPassword()
		{
			return View();
		}

		public ActionResult NewPasswordSend()
		{
			return View();
		}

		public ActionResult RegisterTips()
		{
			return View();
		}

		public ActionResult Service()
		{
			return View();
		}

		public ActionResult Private()
		{
			return View();
		}

		public ActionResult ErrorPage()
		{
			return View();
		}
    }
}
