﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.Controllers
{
    public class AccountChangeController : Controller
    {
        public ActionResult MobileEnter()
        {
            return View();
        }

        public ActionResult MobileAuthentication()
        {
            return View();
        }

        public ActionResult MobileAuthenticationFail()
        {
            return View();
        }

        public ActionResult MobileAuthenticationSuccess()
        {
            return View();
        }
    }
}
