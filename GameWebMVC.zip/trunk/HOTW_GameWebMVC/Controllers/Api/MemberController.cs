﻿using GameWeb_Models.Models.CSCenter;
using GameWeb_Models.Models.Gift;
using GameWeb_Models.Models.Member;
using GS.ServerCommander;
using HOTW_DataInfo.AppLibs;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using HOTW_GameWebMVC.Attributes.WebAPI;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class MemberController : ApiController
    {
        #region 忘記密碼(ForgetPassword)
        /// <summary>
        /// 忘記密碼。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState]
        public dynamic ForgetPassword(ResetPasswordInputModel input)
        {
            var Session = HttpContext.Current.Session;
            NameValueCollection postData = HttpContext.Current.Request.Form;

            // 驗證碼
            string verifyCode = string.IsNullOrEmpty(postData["VerifyCode"]) ? "" : postData["VerifyCode"];

            input.InquiryAccount = string.IsNullOrEmpty(input.InquiryAccount) ? "" : input.InquiryAccount;
            input.InquiryMobile = string.IsNullOrEmpty(input.InquiryMobile) ? "" : input.InquiryMobile;

            if (input.QueryType == 0)
            {
                return new { Code = 999, Message = "請選擇輸入帳號或暱稱" };
            }

            if (input.SentType == 0)
            {
                return new { Code = 999, Message = "請選擇收到新密碼的方式" };
            }

            if (input.QueryType == ResetPasswordQueryType.Account && input.InquiryAccount.Contains("@"))
            {
                return new { Code = 1, Message = "此帳號為其他網站介接會員，請回原網站進行密碼確認動作" };
            }

            if (!input.InquiryAccount.IsRequired())
            {
                return new { Code = 999, Message = "「帳號」、「暱稱」請擇一填寫" };
            }

            if (!input.InquiryMobile.IsRequired())
            {
                return new { Code = 999, Message = "請輸入手機號碼" };
            }

            if (!input.InquiryMobile.IsMemberMobile())
            {
                return new { Code = 999, Message = "手機號碼格式錯誤" };
            }

            if (!verifyCode.IsRequired())
            {
                return new { Code = 999, Message = "請輸入驗證碼" };
            }

            if (Session["gif"] == null || verifyCode.ToLower() != Session["gif"].ToString().ToLower())
            {
                return new { Code = 999, Message = "驗證碼錯誤" };
            }

            // 重新設定密碼
            ResetPasswordResultModel result = MemberEntities.ResetPassword(input);

            if (result == null)
            {
                return new { Code = 999, Message = "查詢失敗" };
            }

            switch (result.Result)
            {
                case 0:
                    if (input.SentType == ResetpasswordSentType.Email)
                    {
                        // 寄送Email
                        CommonUtility.SendEmail(result.Subject, result.MsgContent, result.EMail);
                    }

                    // 取出客服資訊
                    CSInfoResultModel csInfo = CSCenterEntities.CSInfo();

                    return new { Code = 0, Message = "重設成功", CSTel = csInfo.MemberCSTel, CSFax = csInfo.MemberCSFax };
                default:
                    return new { Code = 999, Message = result.ErrorMessage };
            }
        }
        #endregion

        #region 我的好友(MyFriend)
        /// <summary>
        /// 我的好友。
        /// </summary>	
        //[AcceptVerbs("POST")]
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MyFriend(MyFriendInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            TimeSpan TS = new TimeSpan(0, 0, 2);

            string CacheName = string.Format("MyFriend_{0}", context.Session.MemberID);

            List<MyFirendResulModel> myfriendModel = HttpContext.Current.Cache[CacheName] as List<MyFirendResulModel>;

            data.MemberID = (context.Session.IsLogin) ? context.Session.MemberID : 0;

            int rowCount = 0;

            //myfriendModel = MemCachedLibs.Instance.GetMemCachedData<List<MyFirendResulModel>>(CachedType.Web, CachedCommand.MemberFriendList, context.Session.MemberID.ToString());

            if (myfriendModel == null)
            {
                try
                {
                    // 取得好友清單				
                    myfriendModel = MemberEntities.MyFriend(data, out rowCount);

                    //return new
                    //{
                    //    List = myfriendModel,
                    //    RowCount = rowCount
                    //};

                    dic.Add("List", myfriendModel.Select(obj =>
                    new
                    {
                        FriendMemberID = obj.FriendMemberID,
                        LastLoginDate = obj.LastLoginDate,
                        MemberID = obj.MemberID,
                        NickName = obj.NickName,
                        OnlineStatus = obj.OnlineStatus,
                        StringLastLoginDate = obj.LastLoginDate.ToString("yyyy/MM/dd HH:mm:ss")
                    }));
                    dic.Add("RowCount", rowCount);

                    response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                    {
                        Content = new System.Net.Http.StringContent(jss.Serialize(new
                        {
                            Result = dic
                        }))
                    };

                    //MemCachedLibs.Instance.SetMemCachedData<List<MyFirendResulModel>>(CachedType.Web, CachedCommand.MemberFriendList, context.Session.MemberID.ToString(), myfriendModel, TS);

                    HttpContext.Current.Cache.Insert
                    (
                        CacheName,
                        myfriendModel,
                        null,
                        DateTime.Now.AddSeconds(30),
                        System.Web.Caching.Cache.NoSlidingExpiration,
                        System.Web.Caching.CacheItemPriority.Normal,
                        null
                    );

                    return response;
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }

            }

            //MemCachedLibs.Instance.SetMemCachedData<List<MyFirendResulModel>>(CachedType.Web, CachedCommand.MemberFriendList, context.Session.MemberID.ToString(), myfriendModel, TS);

            //return new
            //{
            //    List = myfriendModel,
            //    RowCount = rowCount
            //};

            dic.Add("List", myfriendModel);
            dic.Add("RowCount", rowCount);

            response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = dic
                }))
            };

            return response;
        }

        /// <summary>
        /// 刷新我的好友。
        /// </summary>	
        //[AcceptVerbs("POST")]
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MyFriendNoCache(MyFriendInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            TimeSpan TS = new TimeSpan(0, 0, 2);

            string CacheName = string.Format("MyFriend_{0}", context.Session.MemberID);

            List<MyFirendResulModel> myfriendModel = new List<MyFirendResulModel>();

            data.MemberID = (context.Session.IsLogin) ? context.Session.MemberID : 0;

            int rowCount = 0;

            //myfriendModel = MemCachedLibs.Instance.GetMemCachedData<List<MyFirendResulModel>>(CachedType.Web, CachedCommand.MemberFriendList, context.Session.MemberID.ToString());

            try
            {
                // 取得好友清單				
                myfriendModel = MemberEntities.MyFriend(data, out rowCount);

                //return new
                //{
                //    List = myfriendModel,
                //    RowCount = rowCount
                //};

                dic.Add("List", myfriendModel.Select(obj =>
                new
                {
                    FriendMemberID = obj.FriendMemberID,
                    LastLoginDate = obj.LastLoginDate,
                    MemberID = obj.MemberID,
                    NickName = obj.NickName,
                    OnlineStatus = obj.OnlineStatus,
                    StringLastLoginDate = obj.LastLoginDate.ToString("yyyy/MM/dd HH:mm:ss")
                }));
                dic.Add("RowCount", rowCount);

                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = dic
                    }))
                };

                //MemCachedLibs.Instance.SetMemCachedData<List<MyFirendResulModel>>(CachedType.Web, CachedCommand.MemberFriendList, context.Session.MemberID.ToString(), myfriendModel, TS);

                HttpContext.Current.Cache.Insert
                (
                    CacheName,
                    myfriendModel,
                    null,
                    DateTime.Now.AddSeconds(30),
                    System.Web.Caching.Cache.NoSlidingExpiration,
                    System.Web.Caching.CacheItemPriority.Normal,
                    null
                );

                return response;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            //MemCachedLibs.Instance.SetMemCachedData<List<MyFirendResulModel>>(CachedType.Web, CachedCommand.MemberFriendList, context.Session.MemberID.ToString(), myfriendModel, TS);

            //return new
            //{
            //    List = myfriendModel,
            //    RowCount = rowCount
            //};
        }
        #endregion

        #region 新增我的好友(AddMyFriend)
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic AddMyFriend(EditMyFriendInputModel data)
        {
            try
            {
                DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);
                data.MemberID = (context.Session.IsLogin) ? Convert.ToInt32(context.Session.MemberID) : 0;
                data.FriendNickName = System.Web.HttpContext.Current.Request.Form["FriendNickName"] as string;
                data.Result = 0;
                int result = 0;
                int addfriendresult = MemberEntities.AddMyFriend(data, out result);
                return new
                {
                    result = addfriendresult
                };
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion

        #region 刪除我的好友(DeleteMyFriend)
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic DeleteMyFriend(EditMyFriendInputModel data)
        {
            try
            {
                DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);
                data.MemberID = (context.Session.IsLogin) ? Convert.ToInt32(context.Session.MemberID) : 0;
                data.FriendNickName = System.Web.HttpContext.Current.Request.Form["FriendNickName"] as string;
                data.Result = 0;
                int result = 0;
                int deletefriendresult = MemberEntities.DeleteFriend(data, out result);
                return new
                {
                    result = deletefriendresult
                };
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion

        #region 我的榮譽史(PersonalGlory)
        /// <summary>
        /// 我的榮譽史。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic PersonalGlory(PersonalGloryInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);
            //var Session = HttpContext.Current.Session;

            data.MemberID = (context.Session.IsLogin) ? Convert.ToInt32(context.Session.MemberID) : 0;

            int totalRecord = 0;

            List<PersonalGloryResultModel> result = MemberEntities.PersonalGlory(data, out totalRecord);

            return new
            {
                List = result,
                TotalRecord = totalRecord
            };
        }
        #endregion

        #region 禮物中心紀錄(GiftCenter)
        /// <summary>
        /// 取得禮物中心列表。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GiftCenter(GiftListInputModel Input)
        {
            var Session = HttpContext.Current.Session;

            int totalRecord = 0;
            decimal fbCoin = 0;
            decimal fbCoinMaxChange = 0;
            int fbCoinExchange = 0;

            // 取得資料列表
            Input.MemberID = int.Parse(Session["MemberID"].ToString());
            List<GiftListResultModel> result = GiftEntities.GiftList(Input, out totalRecord, out fbCoin, out fbCoinMaxChange, out fbCoinExchange);

            var list = (result == null) ? null :
            (
                from i in result
                select new
                {
                    CreateDate = i.CreateDate.ToString("yyyy/MM/dd"),
                    GiftName = i.GiftName,
                    Status = i.IsSend,
                    Flag = i.ButtonStatus,
                    // 將參數加密避免直接暴露資訊
                    ExchangeID = EncryptUtility.Encrypt(string.Format("{1}{0}{2}", MvcApplication.SeparatorLevel1, i.ActID, i.Type))
                }
            );

            return new
            {
                List = list,
                TotalRecord = totalRecord,
                FBCoin = fbCoin,
                FBCoinMaxChange = fbCoinMaxChange,
                FBCoinExchange = fbCoinExchange
            };
        }

        /// <summary>
        /// 取得會員明細。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GetChangeMemberDetail()
        {
            var Session = HttpContext.Current.Session;

            MemberDetailInputModel input = new MemberDetailInputModel();
            input.MemberID = int.Parse(Session["MemberID"].ToString());

            MemberDetailResultModel result = MemberEntities.MemberDetail(input);

            return new
            {
                Phone = result.Phone,
                Email = result.Email,
                Address = result.Address,
                CityID = result.CityID,
                ZoneID = result.ZoneID
            };
        }

        /// <summary>
        /// 兌換老幣。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic ChangeHCoin()
        {
            NameValueCollection postData = HttpContext.Current.Request.Form;
            int code = 999;
            string message = "";

            // [ActID, Type]
            string exchangeID = (postData["ExchangeID"] == null) ? "" : postData["ExchangeID"];
            string[] exchangeParams = EncryptUtility.Decode(exchangeID).Split(new string[] { MvcApplication.SeparatorLevel1 }, StringSplitOptions.RemoveEmptyEntries);
            long actID = -1;
            int type = -1;

            if (exchangeParams.Length != 2 || !long.TryParse(exchangeParams[0], out actID) || !int.TryParse(exchangeParams[1], out type))
            {
                code = 999;
                message = "兌換失敗！";
            }
            else
            {
                ChangeHCoinInputModel input = new ChangeHCoinInputModel();
                input.ActID = actID;
                input.Type = type;

                ChangeHCoinResultModel result = GiftEntities.ChangeHCoin(input);

                if (result.RESULT == 0)
                {
                    if (result.EventID > 0)
                    {
                        string serverResult = FSCommander.FS_AS_CREDIT_CHANGE
                        (
                            Convert.ToInt64(result.EventID),
                            result.Target_MemberID,
                            Convert.ToInt32(result.ChangePoints),
                            result.PointType
                        );

                        if (serverResult == "0")
                        {
                            code = 0;
                            message = "";
                        }
                        else
                        {
                            code = 999;
                            message = serverResult;
                        }
                    }
                    else
                    {
                        code = 0;
                        message = "";
                    }
                }
                else
                {
                    code = 999;
                    message = result.ResultMSG;
                }
            }

            return new
            {
                Code = code,
                Message = message
            };
        }

        /// <summary>
        /// 兌換FB幣。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic ChangeFBCoin()
        {
            string gashList = "";
            ChangeFBPointInputModel input = new ChangeFBPointInputModel();
            input.MemberID = int.Parse(HttpContext.Current.Session["MemberID"].ToString());

            ChangeFBPointResultModel result = GiftEntities.ChangeFBPoint(input, out gashList);

            if (result.Result == 0)
            {
                return new { Code = 0, Message = gashList.Replace("\\r\\n", "\r\n") };
            }
            else
            {
                return new { Code = 999, Message = result.ResultMsg };
            }
        }

        /// <summary>
        /// 兌換實體禮物。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic ChangeEntityGift(ChangeEntityGiftInputModel Input)
        {
            NameValueCollection postData = HttpContext.Current.Request.Form;

            // [ActID, Type]
            string exchangeID = (postData["ExchangeID"] == null) ? "" : postData["ExchangeID"];
            string[] exchangeParams = EncryptUtility.Decode(exchangeID).Split(new string[] { MvcApplication.SeparatorLevel1 }, StringSplitOptions.RemoveEmptyEntries);
            long actID = -1;
            int type = -1;

            if (exchangeParams.Length != 2 || !long.TryParse(exchangeParams[0], out actID) || !int.TryParse(exchangeParams[1], out type))
            {
                return new { Code = 999, Message = "兌換失敗！" };
            }

            Input.ActID = actID;
            Input.Type = type;
            Input.ZoneID = string.IsNullOrEmpty(Input.ZoneID) ? "8860000001" : Input.ZoneID;
            Input.Address = string.IsNullOrEmpty(Input.Address) ? "" : Input.Address;
            Input.RealName = string.IsNullOrEmpty(Input.RealName) ? "" : Input.RealName;
            Input.Phone = string.IsNullOrEmpty(Input.Phone) ? "" : Input.Phone;
            Input.Email = string.IsNullOrEmpty(Input.Email) ? "" : Input.Email;

            if (Input.RealName == "")
            {
                return new { Code = 999, Message = "請輸入姓名" };
            }

            if (Input.Address == "")
            {
                return new { Code = 999, Message = "請輸入寄送地址" };
            }

            if (!Regex.IsMatch(Input.Address, @"^[\u0391-\uFFE5a-zA-Z0-9\-]{1,40}$"))
            {
                return new { Code = 999, Message = "寄送地址格式錯誤" };
            }

            if (!Regex.IsMatch(Input.Phone, @"^[0-9]{0,20}$"))
            {
                return new { Code = 999, Message = "聯絡電話格式錯誤" };
            }

            if (Input.Email == "")
            {
                return new { Code = 999, Message = "請輸入E-mail" };
            }

            if (!Regex.IsMatch(Input.Email, @"^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$"))
            {
                return new { Code = 999, Message = "信箱格式錯誤" };
            }

            ChangeEntityGiftResultModel result = GiftEntities.ChangeEntityGift(Input);

            if (result.Result == 0)
            {
                return new { Code = 0, Message = "" };
            }
            else
            {
                return new { Code = 999, Message = "兌換失敗！" };
            }
        }
        #endregion

        #region 禮物兌換說明(ExchangeNovice)
        /// <summary>
        /// 取得會員FB幣資訊
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GetFBCoin()
        {
            var Session = HttpContext.Current.Session;

            int totalRecord = 0;
            decimal fbCoin = 0;
            decimal fbCoinMaxChange = 0;
            int fbCoinExchange = 0;

            GiftListInputModel data = new GiftListInputModel();
            data.MemberID = int.Parse(Session["MemberID"].ToString());

            // 取得資料列表
            GiftEntities.GiftList(data, out totalRecord, out fbCoin, out fbCoinMaxChange, out fbCoinExchange);

            return new
            {
                FBCoin = fbCoin,
                FBCoinMaxChange = fbCoinMaxChange,
                FBCoinExchange = fbCoinExchange
            };
        }
        #endregion

        #region 帳號設定(AccountSet)
        /// <summary>
        /// 取得目前登入中帳號的帳號紀錄區和新增合併按鈕顯示權限
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MemberMobileGroupInfo()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

            try
            {
                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                MemberDetailInputModel input = new MemberDetailInputModel();

                input.MemberID = context.Session.MemberID;

                var output = MemberEntities.MemberMobileGroupInfo(input);

                var memberDetail = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = input.MemberID });

                if (output != null)
                {
                    return new
                   {
                       result = new
                       {
                           MobileGroupNumber = output.MobileGroupNumber,
                           ShowAccountSettings = output.ShowAccountSettings,
                           ShowNewMergeAccount = output.ShowNewMergeAccount,
                           LoginEventFlag = context.Session.LoginEventFlag,
                           MemberAccount = memberDetail.MemberAccount,
                           MemberPassword = string.IsNullOrEmpty(context.Session.MemberPassword) ? "" : CommonUtility.RSAEncrypt(context.Session.MemberPassword, RsaPrivateKey),
                           NickName = context.Session.NickName,
                           Mobile = memberDetail.Mobile
                       }
                   };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(MemberController)).Error(ex.Message, ex);
                return ex.Message;
            }
        }

        /// <summary>
        /// 取得目前登入中帳號的帳號紀錄
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MemberMobileGroupList()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

            try
            {
                List<MemberMobileGroupList> list = new List<GameWeb_Models.Models.Member.MemberMobileGroupList>();

                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                string Which = HttpContext.Current.Request.Form["Which"];

                string UpOrDown = HttpContext.Current.Request.Form["UpOrDown"];

                MemberDetailInputModel input = new MemberDetailInputModel();

                input.MemberID = context.Session.MemberID;

                var output = MemberEntities.MemberMobileGroupList(input);

                int Count = 0;

                if (output.Any())
                {
                    Count = output.Count();

                    foreach (var obj in output)
                    {
                        switch (obj.VIP_Level)
                        {
                            case 1:
                                obj.VIP_Level_F = "普卡";
                                break;
                            case 2:
                                obj.VIP_Level_F = "銀卡";
                                break;
                            case 3:
                                obj.VIP_Level_F = "金卡";
                                break;
                            case 4:
                                obj.VIP_Level_F = "白金卡";
                                break;
                            default:
                                obj.VIP_Level_F = "一般";
                                break;
                        }

                        obj.RsaMemberID = CommonUtility.RSAEncrypt(obj.MemberID.ToString(), RsaPrivateKey);

                        obj.MemberID = 0;
                    }

                    if (Which == "Point")
                    {
                        switch (UpOrDown)
                        {
                            case "true":
                                output = (from a in output
                                          orderby a.IsQueryAccount descending, a.IsPrimaryAccount descending, a.Point ascending
                                          select a).ToList();
                                break;
                            case "false":
                                output = (from a in output
                                          orderby a.IsQueryAccount descending, a.IsPrimaryAccount descending, a.Point descending
                                          select a).ToList();
                                break;
                            default:
                                break;
                        }
                    }
                    else if (Which == "Transfer")
                    {
                        switch (UpOrDown)
                        {
                            case "true":
                                output = (from a in output
                                          orderby a.IsQueryAccount descending, a.IsPrimaryAccount descending, a.TransferCount ascending
                                          select a).ToList();
                                break;
                            case "false":
                                output = (from a in output
                                          orderby a.IsQueryAccount descending, a.IsPrimaryAccount descending, a.TransferCount descending
                                          select a).ToList();
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
                        output = (from a in output
                                  orderby a.IsQueryAccount descending, a.IsPrimaryAccount descending, a.Point descending, a.TransferCount descending
                                  select a).ToList();
                    }

                    return new
                    {
                        result = new
                        {
                            List = output,
                            Count = Count
                        }
                    };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// 檢查目前登入中帳號的新增合併帳號權限
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MemberMobileGroupAddCheck()
        {
            try
            {
                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                MemberDetailInputModel input = new MemberDetailInputModel();

                input.MemberID = context.Session.MemberID;

                int output = MemberEntities.MemberMobileGroupAddCheck(input);

                return new
                {
                    result = output
                };
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// 新增帳號前先建立帳號
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic CreateMember()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

            try
            {
                string account = HttpContext.Current.Request.Form["MemberAccount"] as string;
                string pass = HttpContext.Current.Request.Form["MemberPassword"] as string;

                MemberInfo info = new MemberInfo();

                info.MemberAccount = CommonUtility.RSADecrypt(account, RsaPrivateKey);
                info.MemberPassword = CommonUtility.RSADecrypt(pass, RsaPrivateKey);

                return MemberEventUtility.WebRegister(info);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// 新增或合併帳號
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MemberMobileGroupAdd()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

            try
            {
                string account = HttpContext.Current.Request.Form["MemberAccount"] as string;
                string pass = HttpContext.Current.Request.Form["MemberPassword"] as string;

                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                MemberMobileGroupAdd input = new MemberMobileGroupAdd();

                input.MergeMemberID = context.Session.MemberID;
                input.MergeIP = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
                input.MemberAccount = CommonUtility.RSADecrypt(account, RsaPrivateKey);
                input.MemberPassword = CommonUtility.RSADecrypt(pass, RsaPrivateKey);

                int output = MemberEntities.MemberMobileGroupAdd(input);

                return new
                {
                    result = output
                };
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// 修改密碼或暱稱(只能修改一次)
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic EditMemberData()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

            try
            {
                string pass = CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberPassword"], RsaPrivateKey);
                string nickname = HttpContext.Current.Request.Form["NickName"];
                string passTrue = CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberPasswordTrue"], RsaPrivateKey);

                MemberInfo info = new MemberInfo();

                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                info.MemberID = context.Session.MemberID;
                info.MemberAccount = context.Session.MemberAccount;

                if (!string.IsNullOrEmpty(pass) && !string.IsNullOrWhiteSpace(pass)
                  && !string.IsNullOrEmpty(passTrue) && !string.IsNullOrWhiteSpace(passTrue)
                    && pass != passTrue && pass != "**********")
                {
                    info.MemberPassword = pass;
                }

                if (!string.IsNullOrEmpty(nickname) && !string.IsNullOrWhiteSpace(nickname))
                {
                    info.NickName = nickname;
                }

                MemberResultData o = MemberEventUtility.EditData(info);

                if (o.ResultCode == 0)
                {
                    if (!string.IsNullOrEmpty(pass) && !string.IsNullOrWhiteSpace(pass)
                       && !string.IsNullOrEmpty(passTrue) && !string.IsNullOrWhiteSpace(passTrue)
                       && pass != passTrue && pass != "**********")
                    {
                        context.SaveLogic += (session) =>
                        {
                            session.MemberPassword = pass;
                        };
                        context.Save();
                    }
                }

                return new
                {
                    Result1 = o,
                    Result2 = string.IsNullOrEmpty(pass) ? "" : CommonUtility.RSAEncrypt(pass, RsaPrivateKey)
                };
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// 修改暱稱後，改掉會員帳號可修改暱稱的狀態
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic ClearFlag()
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            context.SaveLogic += (session) =>
            {
                if ((session.LoginEventFlag & 4) > 0)
                {
                    session.LoginEventFlag = ActivityFlagMgr.ClearFlag(session.MemberID, 4, session.LoginEventFlag);
                }
            };
            context.Save();
            return true;
        }

        /// <summary>
        /// 驗證帶入帳號是否存在帳號紀錄群組裡面
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic VerifyMA()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

            bool b = false;

            try
            {
                List<MemberMobileGroupList> list = new List<GameWeb_Models.Models.Member.MemberMobileGroupList>();

                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                int index = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["index"], RsaPrivateKey));

                MemberDetailInputModel input = new MemberDetailInputModel();

                input.MemberID = context.Session.MemberID;

                var output = MemberEntities.MemberMobileGroupList(input);

                if (output.Any())
                {
                    var result = output.Where(a => a.MemberID == index);

                    if (result.Any())
                    {
                        b = true;
                    }
                }
                return new
                {
                    result = b
                };
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// 依照帶入的會員編號，動態撈取會員卡別資料
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic PersonalCardData()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

            try
            {
                int MemberID = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
                string CurrentLevel = string.Empty;
                string NextLevel = string.Empty;
                string NextDate = string.Empty;
                string IsNewVipLevel = string.Empty;

                List<GameWeb_Models.Models.PersonalCardModel> dataList = GameWeb_Models.Models.PersonalCardEntities.PartialGetData(MemberID, out CurrentLevel, out NextLevel, out NextDate, out IsNewVipLevel);

                return new
                {
                    DataList = dataList.Select(i => new
                    {
                        DataType = i.DataType,
                        NowValue = i.NowValue,
                        No1Level = i.No1Level,
                        No1Value = i.No1Value,
                        No2Level = i.No2Level,
                        No2Value = i.No2Value,
                        No3Level = i.No3Level,
                        No3Value = i.No3Value,
                        CardInfoTitle = i.CardInfoTitle
                    }),
                    CurrentLevel = CurrentLevel,
                    NextLevel = NextLevel,
                    NextDate = Convert.ToDateTime(NextDate).ToString("yyyy/M/d"),
                    IsNewVipLevel = IsNewVipLevel
                };
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion

        #region 強制修改會員資料(MemberPasswordModify)
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public MemberPasswordModifyResultModel MemberPasswordModify()
        {
            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";
            string oldPwd = HttpContext.Current.Request.Form["oldPwd"];
            string Pwd = HttpContext.Current.Request.Form["Pwd"];
            string de_OldPwd = CommonUtility.RSADecrypt(oldPwd, RsaPrivateKey);
            string de_Pwd = CommonUtility.RSADecrypt(Pwd, RsaPrivateKey);

            MemberPasswordModifyInputModel input = new MemberPasswordModifyInputModel()
            {
                MemberID = Convert.ToInt32(HttpContext.Current.Session["MemberID"]),
                MemberPassword = de_OldPwd,
                NewPassword = de_Pwd,
                OnlineIP = HttpContext.Current.Request.UserHostAddress
            };
            return MemberEntities.MemberPasswordModify(input);
        }
        #endregion
    }
}
