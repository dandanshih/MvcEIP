﻿using GS.Utilities;
using GS.Web.CPA;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.Models;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Http;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.Controllers.api
{
    public class AccountController : ApiController, IRequiresSessionState
    {
		[AcceptVerbs(new string[] { "Post" })]
		public dynamic Login(string account, string password, string isRemember, string code)
		{
			var Session = HttpContext.Current.Session;
			if (Session["IsLogin"] != null)
			{
				return new MemberResultData()
				{
					ResultCode = 30,
					ResultMsg = "已登入會員。"
				};
			}
			if (Request.Method == HttpMethod.Post)
			{
				account = System.Web.HttpContext.Current.Request.Form["account"] as string;
				password = System.Web.HttpContext.Current.Request.Form["password"] as string;
				isRemember = System.Web.HttpContext.Current.Request.Form["isRemember"] as string;
				code = System.Web.HttpContext.Current.Request.Form["code"] as string;
			}

			MemberResultData resultData;

			#region 驗證
			if (string.IsNullOrEmpty(code))
			{
				if (string.IsNullOrEmpty(account))
				{
					return new
					{
						ResultCode = 101,
						ResultMsg = "請輸入帳號！"
					};
				}
				else if (string.IsNullOrEmpty(password))
				{
					return new
					{
						ResultCode = 102,
						ResultMsg = "請輸入密碼！"
					};
				}
			}
			#endregion			
			string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";
			
			if (string.IsNullOrEmpty(account))
			{
				// Code解碼得到會員資料再登入
				string decodeData = EncryptUtility.Decode(code);
				string[] aryData = decodeData.Split('|');
				account = aryData[0];
				password = aryData[1];
			}
			else
			{				
				account = CommonUtility.RSADecrypt(account, RsaPrivateKey);
				password = CommonUtility.RSADecrypt(password, RsaPrivateKey);
			}
			
			// 確認登入資料是否正確
			if (string.IsNullOrEmpty(account) || string.IsNullOrEmpty(password))
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 98;
				resultData.LoginData = new GS.ServerCommander.FS_IIS_USER_LOGIN_R();
			}
			else
			{
				try
				{
					MemberInfo minfo = new MemberInfo();
					minfo.MemberAccount = string.IsNullOrEmpty(account) ? " " : account;
					minfo.MemberPassword = string.IsNullOrEmpty(password) ? " " : password;
					minfo.Mobile4Num = " ";
					minfo.Platform = "Web";
					minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
					minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;
					resultData = MemberEventUtility.Login(minfo);

					if (isRemember == "true")
					{
						resultData.Data = EncryptUtility.Encrypt(minfo.MemberAccount + "|" + minfo.MemberPassword);
					}
					else
					{
						resultData.Data = "";
					}
				}
				catch (Exception ex)
				{
					log4net.LogManager.GetLogger(typeof(AccountController)).Error("LoginFail", ex);
					resultData = new MemberResultData();
					resultData.ResultCode = 99;					
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic AutoLogin()
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["WaitMobileAuthAccount"] == null || Session["WaitMobileAuthPassword"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 99;				
			}
			else
			{
				try
				{
					MemberInfo minfo = new MemberInfo();
					minfo.MemberAccount = Session["WaitMobileAuthAccount"].ToString();
					minfo.MemberPassword = Session["WaitMobileAuthPassword"].ToString();
					minfo.Mobile4Num = " ";
					minfo.Platform = "Web";
					minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
					minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;
					resultData = MemberEventUtility.Login(minfo);
                    Session.Remove("WaitMobileAuthAccount");
                    Session.Remove("WaitMobileAuthPassword");
				}
				catch (Exception ex)
				{
					log4net.LogManager.GetLogger(typeof(AccountController)).Error("LoginFail", ex);
					resultData = new MemberResultData();
					resultData.ResultCode = 99;
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic ReLogin()
		{
			int MemberID = 0;
			MemberResultData ResultData;

			if (HttpContext.Current.Session["MemberID"] == null)
			{
				ResultData = new MemberResultData();
				ResultData.ResultCode = 99;
			}
			else
			{
				MemberID = Convert.ToInt32(HttpContext.Current.Session["MemberID"]);

				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = MemberID;
				minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.ReLogin;
				minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
				minfo.Platform = "Web";
				ResultData = MemberEventUtility.Login(minfo);
			}

			return new
			{
				ResultCode = ResultData.ResultCode,
				ResultMsg = ResultData.ResultMsg,
				Data = ResultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public MemberResultData Logout()
		{
			var Session = HttpContext.Current.Session;
			Session.Abandon();

			return null;
		}

        [AcceptVerbs(new string[] { "Post" })]
		public AccountModel Get()
        {
			var Session = HttpContext.Current.Session;			

			AccountModel accountModel = new AccountModel();
			if (Convert.ToBoolean(Session["IsLogin"]) == true)
			{
				accountModel.IsLogin = Convert.ToBoolean(Session["IsLogin"]);
				//accountModel.LoginKey = Convert.ToInt32(Session["LoginKey"]);
				//accountModel.TriDESUniID = Session["TriDESUniID"].ToString();
				//accountModel.TriDESKey = Session["TriDESKey"].ToString();
				//accountModel.LoginEventFlag = Convert.ToInt64(Session["LoginEventFlag"]);
				//accountModel.OnlineID = Convert.ToInt64(Session["OnlineID"]);
				//accountModel.MemberID = Convert.ToInt32(Session["MemberID"]);
				accountModel.MemberAccount = Session["MemberAccount"] as string;
				accountModel.MemberPassword = Session["MemberPassword"] as string;
				//accountModel.Mobile4Num = Session["MobileLast4Num"].ToString();
				//accountModel.SourceName = Session["RegisterType"].ToString();
				//accountModel.EggUrl = Session["EggUrl"].ToString();
				accountModel.Level = Convert.ToInt32(Session["Level"]);
				//accountModel.UserPhoto = Session["UserPhoto"].ToString();
				//accountModel.AllPicFilePath = Session["AllPicFilePath"].ToString();
				//accountModel.NDUrl = Session["NDUrl"].ToString();
				//accountModel.LoginReceive = Convert.ToBoolean(Session["LoginReceive"]);
				//accountModel.MemberAttribute = Convert.ToInt64(Session["MemberAttribute"]);
				accountModel.NickName = Session["NickName"] as string;
				//accountModel.DataInfoUrl = Session["DataInfoUrl"].ToString();
				accountModel.VIP_Level = Session["Vip_Level"].ToString();
			}
			else
			{
				accountModel.IsLogin = Convert.ToBoolean(Session["IsLogin"]);
				accountModel.MemberAccount = "";
				accountModel.MemberPassword = "";
				accountModel.NickName = "";
				accountModel.Level = 0;
			}			

			return accountModel;
        }

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic Register(RegisterModel registerModel)
		{
			var Session = HttpContext.Current.Session;

			//if (Session["GuestMemberID"] != null)
			//{
			//	Session.Abandon();
			//}

			if (MvcApplication.IsMaintain)
			{
				return new
				{
					ResultCode = 999,
					ResultMsg = "伺服器維護中!"
				};
			}

			MemberResultData resultData;
            try
            {
                #region 驗證
                if (!Regex.IsMatch(registerModel.MemberAccount, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
                {
                    return new
                    {
                        ResultCode = 101,
                        ResultMsg = "帳號錯誤"
                    };
                }
                else if (!Regex.IsMatch(registerModel.MemberPassword, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
                {
                    return new
                    {
                        ResultCode = 102,
                        ResultMsg = "密碼錯誤"
                    };
                }
                else if (!string.IsNullOrEmpty(registerModel.Mobile) && !Regex.IsMatch(registerModel.Mobile, @"^[09]{2}[0-9]{8}$"))
                {
                    return new
                    {
                        ResultCode = 103,
                        ResultMsg = "手機格式錯誤"
                    };
                }
                else if (!string.IsNullOrEmpty(registerModel.EMail) && !Regex.IsMatch(registerModel.EMail, @"^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$"))
                {
                    return new
                    {
                        ResultCode = 104,
                        ResultMsg = "電子信箱格式錯誤"
                    };
                }
                else if (Session["IsLogin"] != null)
                {
                    return new
                    {
                        ResultCode = 200,
                        ResultMsg = "您已經是會員"
                    };
                }
                #endregion

                MemberInfo minfo = new MemberInfo();
                minfo.MemberAccount = registerModel.MemberAccount;
                minfo.MemberPassword = registerModel.MemberPassword;
                minfo.Mobile = registerModel.Mobile;
                minfo.EMail = registerModel.EMail;
                minfo.BingoSN = registerModel.BingoSN;
                minfo.IntroducerNickName = registerModel.IntroducerNickName;

                resultData = MemberEventUtility.WebRegister(minfo);

                if (resultData.ResultCode == 0)
                {
                    Session["MemberID"] = resultData.LoginData.MemberID;
                    Session["WaitMobileAuthAccount"] = registerModel.MemberAccount;
                    Session["WaitMobileAuthPassword"] = registerModel.MemberPassword;
                    Session["WaitMobileAuthMobile"] = registerModel.Mobile;
                    Session["ConfirmRegisterTime"] = DateTime.Now;
                }
                return new
                {
                    ResultCode = resultData.ResultCode,
                    ResultMsg = resultData.ResultMsg,
                    Data = resultData.Data
                };
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(AccountController)).Error(ex);
                return null;
            }
			
		}

		[AcceptVerbs(new string[] { "Post" })]
		public MemberResultData MobileAuthentication(string verificationCode) 
		{
			if (Request.Method == HttpMethod.Post)
			{
				verificationCode = System.Web.HttpContext.Current.Request.Form["verificationCode"] as string;
			}

			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			#region 驗證
			if (string.IsNullOrEmpty(verificationCode))
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 101;
				resultData.ResultMsg = "驗證碼不可空白!";
				return resultData;
			}
			#endregion			

			if (Session["MemberID"] == null || Session["WaitMobileAuthAccount"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 99;				
			}
			else
			{
				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
				minfo.Mobile = Session["WaitMobileAuthMobile"].ToString();
				minfo.MobileVaildCode = verificationCode;
				resultData = MemberEventUtility.MobileVaild(minfo);

                // 若有 Initial 過則儲存 SessionID
                CPAHandler handler = new CPAHandler(WebConfig.CPAConnectionString);
                handler.Add(CPAType.Other, EventType.Register);
                handler.SaveData();
                handler.Clear();
			}

			return resultData;
		}

		[AcceptVerbs(new string[] { "Post" })]
		public MemberResultData ReSendVerificationCode()
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["MemberID"] == null || Session["WaitMobileAuthAccount"] == null)
			{				
				resultData = new MemberResultData();
				resultData.ResultCode = 99;				
			}
			else
			{
				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
				minfo.MemberAccount = Session["WaitMobileAuthAccount"].ToString();
				minfo.Mobile = Session["WaitMobileAuthMobile"].ToString();
				resultData = MemberEventUtility.ReSendSMS(minfo);

				if (resultData.ResultCode == 0)
				{
#if(!Online)
					string SqlCmd = "SELECT VerificationCode FROM A_Member WHERE MemberAccount = @MemberAccount";
					System.Data.SqlClient.SqlParameter param = new System.Data.SqlClient.SqlParameter("@MemberAccount", minfo.MemberAccount);
					resultData.Data = GS.Utilities.SqlHelper.ExecuteScalar
					(
						WebConfig.ConnectionString,
						System.Data.CommandType.Text,
						SqlCmd,
						param
					).ToString();
#endif
				}
			}

			return resultData;
		}

		[AcceptVerbs(new string[] { "Post" })]
		public MemberResultData CancelMobileAuthentication()
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["MemberID"] == null || Session["WaitMobileAuthMobile"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 99;
			}
			else
			{
				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = Convert.ToInt32(Session["MemberID"]);				
				minfo.Mobile = Session["WaitMobileAuthMobile"].ToString();

				resultData = MemberEventUtility.CancelMobileVaild(minfo);
			}			

			return resultData;
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic ForgetPassword(string account, string nickName, string mobile, string typeToSend, string verifyCode) 
		{
			var Session = HttpContext.Current.Session;

			if (Request.Method == HttpMethod.Post)
			{
				account = System.Web.HttpContext.Current.Request.Form["account"] as string;
				nickName = System.Web.HttpContext.Current.Request.Form["nickName"] as string;
				mobile = System.Web.HttpContext.Current.Request.Form["mobile"] as string;
				typeToSend = System.Web.HttpContext.Current.Request.Form["typeToSend"] as string;
				verifyCode = System.Web.HttpContext.Current.Request.Form["verifyCode"] as string;
			}

			#region 驗證
			if (string.IsNullOrEmpty(account) && string.IsNullOrEmpty(nickName))
			{
				return new
				{
					ResultCode = 101,
					ResultMsg = "「帳號」、「暱稱」請擇一填寫"
				};
			}

			if (string.IsNullOrEmpty(mobile))
			{
				return new
				{
					ResultCode = 102,
					ResultMsg = "請輸入手機號碼"
				};
			}

			if (typeToSend != "text" && typeToSend != "email")
			{
				return new
				{
					ResultCode = 103,
					ResultMsg = "請選擇收到新密碼的方式"
				};
			}

			if (string.IsNullOrEmpty(mobile))
			{
				return new
				{
					ResultCode = 104,
					ResultMsg = "請輸入驗證碼"
				};
			}

			if (verifyCode.ToLower() != Session["gif"].ToString().ToLower())
			{
				return new 
				{
					ResultCode = 105,
					ResultMsg = "驗證碼錯誤!"
				};
			}
			#endregion


			string newPassword = Guid.NewGuid().ToString().Replace("-", "").Substring(0, 8);
			string sendMsg = "老子有錢 通知:您的密碼已重新設定為" + newPassword;
			string userMemberID = "";
			string userMobile = "";
			string userEMail = "";

			SqlParameter[] param = 
		    {
		        new SqlParameter("@MemberAccount", account),
		        new SqlParameter("@NickName", nickName),
		        new SqlParameter("@Mobile", mobile),
		        new SqlParameter("@NewPassword", newPassword),
		        new SqlParameter("@OnlineIP", HttpContext.Current.Request.UserHostAddress),
		    };

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_A_Member_ResetPassword",
				param
			);

			int resultCode = Convert.ToInt32(ds.Tables[0].Rows[0]["Result"]);
			string resultMsg = "";

			if (resultCode == 0)
			{
				userMemberID = ds.Tables[0].Rows[0]["MemberID"].ToString();
				userMobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
				userEMail = ds.Tables[0].Rows[0]["EMail"].ToString();				
			}
			else if (resultCode == 1)
			{
				resultMsg = "您所輸入的資訊錯誤，請重新輸入";
			}
			else if (resultCode == 2)
			{
				resultMsg = "帳號目前認證中，不開放密碼查詢";
			}
			else if (resultCode == 3)
			{
				resultMsg = "此帳號為其他網站介接會員，請回原網站進行密碼確認動作";
			}

			if (resultCode == 0 && typeToSend == "text")
			{
					CommonUtility.SendSMS
					(
						userMobile,
						sendMsg,
						CommonUtility.SMSRequestTypes.ForgetPassword,
						userMemberID
					);
			}
			else if (typeToSend == "email")
			{
				if (string.IsNullOrEmpty(userEMail))
				{
					resultCode = 99;
					resultMsg = "本帳號未留下E-Mail資料，請改用手機簡訊方式取得新密碼，或與客服中心聯繫";
				}
				else
				{
					System.Net.Mail.MailMessage objMsg = new System.Net.Mail.MailMessage();
					objMsg.To.Add(userEMail);
					objMsg.Subject = "密碼重新設定通知";
					objMsg.Body = sendMsg;
					objMsg.IsBodyHtml = true;
					System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
					client.Send(objMsg);
				}
			}			

			return new
			{
				ResultCode = resultCode,
				ResultMsg = resultMsg
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic ClearFlag(string flag)
		{
			var Session = HttpContext.Current.Session;

			if (Request.Method == HttpMethod.Post)
			{
				flag = System.Web.HttpContext.Current.Request.Form["flag"] as string;
			}
			long MemberFlag = Session["WebLoginEventFlag"] == null ? 0 : Convert.ToInt64(Session["WebLoginEventFlag"]);
			if ((MemberFlag & Convert.ToInt64(flag)) > 0)
			{
				SqlParameter[] param = 
				{
					new SqlParameter("@MemberID", Convert.ToInt32(Session["MemberID"])),
					new SqlParameter("@Flag", flag)
				};

				SqlHelper.ExecuteNonQuery
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_GameWeb_ClearWebLoginEventFlag",
					param
				);
				Session["WebLoginEventFlag"] = MemberFlag ^ Convert.ToInt64(flag);
			}
            return new
            {
                WebLoginEventFlag = Convert.ToInt64(Session["WebLoginEventFlag"])
            };
		}
    }
}
