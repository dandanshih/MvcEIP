﻿// Desc : 這個檔案目前暫時使用不到

using GameWeb_Models.Models.Bank;
using GameWeb_Models.Models.Bank.Enum;
using GameWeb_Models.Models.Member;
using GameWeb_Models.Models.Other;
using GameWeb_Models.Models.Transfer;
using GS.ServerCommander;
using GS.Utilities;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using HOTW_GameWebMVC.Attributes.WebAPI;
using HOTW_GameWebMVC.Models.Bank;
using Newtonsoft.Json;
using PaymentGateway.StoreAPI;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class BankController : ApiController
    {
        #region 儲值購點
        /// <summary>
        /// 線上購點 PageLoad 載入資訊。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic PointBuyBase()
        {
            ProductGroupType groupType;

            if (!Enum.TryParse<ProductGroupType>(HttpContext.Current.Request.Form["product"], out groupType))
            {
                return "";
            }

            var Session = HttpContext.Current.Session;

            int memberId = int.Parse(Session["MemberID"].ToString());
            int vipLevel = int.Parse(Session["VIP_Level"].ToString());


            // 「儲值金額」對應「付款方式」屬性列表
            var valueProduct = BankEntities.ProductValueList(new ProductValueListInputModel() { ProductGroup = groupType, PaymentValueID = 0, MemberID = memberId, VIP_Level = vipLevel });
			

            bool isLastRecord = false;
            PayRecord payRecord = new PayRecord();
            #region 取得會員記錄 (PointBuyOnline, PointBuyMonthly)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
            {
                // 取得會員上次儲值動作資訊
                var saveSet = BankEntities.GetMemberPayRecord(new GetMemberPayRecordInputModel() { ProductGroup = groupType, MemberID = memberId });
                Dictionary<string, string> saveData = (saveSet == null) ? new Dictionary<string, string>()
                    : new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(saveSet.WorthDefaultSetting);

                // 會員個人資料
                var memberDetail = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = memberId });

                string temp = "";
                isLastRecord = saveData.TryGetValue("ProductGroup", out temp) ? (temp == ((int)groupType).ToString()) : false;
                payRecord.ProductGroup = groupType;
                payRecord.ValueID = isLastRecord && saveData.TryGetValue("ValueID", out temp) ? Convert.ToInt32(temp) : 0;
                payRecord.ProductID = (payRecord.ValueID != 0 && saveData.TryGetValue("ProductID", out temp)) ? Convert.ToInt32(temp) : 0;
                payRecord.InvoiceEmail = memberDetail.Invoice_EMail;
                payRecord.InvoiceType = memberDetail.Invoice_Type;
                payRecord.InvoiceName = memberDetail.Invoice_Recipient;
                payRecord.InvoiceCityID = memberDetail.Invoice_CityID;
                payRecord.InvoiceZoneID = memberDetail.Invoice_ZoneID;
                payRecord.InvoiceAddress = memberDetail.Invoice_Address;
            }
            #endregion

            #region 2013/12/12上線的包月500首購半價資格判斷   2013/12/26已註解，2014/01/02下線
            //int ResultCode = -1;
            //if (groupType == ProductGroupType.PointBuyMonthly)
            //{
            //    ResultCode = BankEntities.NewMonthPaymentDiscountCheck(new ProductValueListInputModel() { ProductGroup = groupType, PaymentValueID = 0, MemberID = memberId, VIP_Level = vipLevel });
            //}
            #endregion

            IEnumerable<dynamic> valueList = null;
            #region 儲值金額列表 (PointBuyOnline, PointBuyMonthly)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
            {
                //valueList = from i in BankEntities.ValueTypeList(new ValueTypeListInputModel() { CoinType = CoinType.NTD, ProductGroup = groupType, DiscountYN = (ResultCode == 0 ? 1 : 0) })
                valueList = from i in BankEntities.ValueTypeList(new ValueTypeListInputModel() { CoinType = CoinType.NTD, ProductGroup = groupType })
                            join j in valueProduct on i.PaymentValueID equals j.PaymentValueID
                            group j.ProductType.ToString() by i into k
                            select new
                            {
                                ID = k.Key.PaymentValueID,
                                Value = k.Key.Value,
                                Point = k.Key.Point,
                                EveryDayPoint = k.Key.EveryDayPoint,
                                TotalPoint = k.Key.TotalPoint,
                                Img = k.Key.ImageUrl,
                                ImgOver = k.Key.MouseOver,
                                ImgDown = k.Key.MouseDown,
                                ProductList = k.Aggregate((sum, item) => sum + "," + item)
                            };
            }
            #endregion

            IEnumerable<dynamic> productList = null;
            #region 付費方式列表 (PointBuyOnline, PointBuySN, PointBuyMonthly, PointTransfer)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuySN, ProductGroupType.PointBuyMonthly, ProductGroupType.TransferOnline }.Contains(groupType))
            {
                productList = from i in BankEntities.ProductTypeList(new ProductTypeListInputModel() { ProductGroup = groupType })
                              select new
                              {
                                  ID = i.ProductType,
                                  Name = i.ProductTypeName,
                                  Text = HttpUtility.HtmlDecode(i.Text),
                                  Status = (i.Flag == 1 ? "正常" : "維護中"),
                                  IsMaintain = (i.Flag != 1),
                                  HelpUrl = i.HelpUrl,
                                  IsNeedInvoice = i.IsNeedInvoice,
                                  Img = i.ImageUrl,
                                  ShopUrl = i.ShopUrl,
                                  IsPG = i.IsPaymentGateway,
                                  Redirect = i.Redirect
                              };
            }
            #endregion

            IEnumerable<dynamic> valueProductList = null;
            #region 金額、付費方式的關聯屬性 (PointBuyOnline)
            if (new[] { ProductGroupType.PointBuyOnline }.Contains(groupType))
            {
                valueProductList = from i in valueProduct
                                   select new int[] { i.PaymentValueID, i.ProductType, i.CanUseEcoupon };
            }
            #endregion

            IEnumerable<dynamic> cityList = null;
            #region 縣市鄉鎮列表 (PointBuyOnline, PointBuyMonthly)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
            {
                cityList = from i in OtherEntities.CityData()
                           group new { i.ZipCode, i.ZoneID, i.ZoneName } by new { i.CityID, i.CityName } into j
                           select new
                           {
                               // 縣市編號
                               CityID = j.Key.CityID,
                               // 縣市名稱
                               CityName = string.IsNullOrEmpty(j.Key.CityName) ? "請選擇縣市" : j.Key.CityName,
                               // 縣市內所屬的鄉鎮市
                               ZoneList = from x in j
                                          select new string[] 
                                          {
                                              x.ZoneID, 
                                              string.IsNullOrEmpty(x.ZoneName) ? "請選擇" : x.ZoneName, 
                                              x.ZipCode 
                                          }
                           };
            }
            #endregion

            return new
            {
                // 是否使用最後一次的操作紀錄
                IsLastRecord = isLastRecord,
                // 上次記錄結構或預設資料
                PayRecord = payRecord,
                // 儲值金額列表
                ValueSource = valueList,
                // 付費方式列表
                ProductSource = productList,
                // 金額、付費方式的關聯屬性
                ValueProductSource = valueProductList,
                // 縣市鄉鎮列表
                CitySource = cityList,
                // 回傳檢查狀態碼(此欄位可以通用)
                ResultCode = 0
            };
        }



		/// <summary>
		/// Mobile線上購點 PageLoad 載入資訊。
		/// </summary>
		[AcceptVerbs("Post")]
		[AjaxOnly]
		[CheckLoginState(true)]
		public dynamic MobilePointBuyBase()
		{

			ProductGroupType groupType;
			

			if (!Enum.TryParse<ProductGroupType>(HttpContext.Current.Request.Form["product"], out groupType))
			{
				return "";
			}

			var Session = HttpContext.Current.Session;
			log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("first");
			int memberId = int.Parse(Session["MemberID"].ToString());
			int vipLevel = int.Parse(Session["VIP_Level"].ToString());
			log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("memberId:{0}", memberId);
			log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("vipLevel:{0}", vipLevel);
			// 「儲值金額」對應「付款方式」屬性列表
			var valueProduct = BankEntities.MobileProductValueList(new ProductValueListInputModel() { ProductGroup = groupType, PaymentValueID = 0, MemberID = memberId, VIP_Level = vipLevel });
			log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("valueProduct.Count:{0}",valueProduct.Count);

			bool isLastRecord = false;
			PayRecord payRecord = new PayRecord();
			#region 取得會員記錄 (PointBuyOnline, PointBuyMonthly)
			if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
			{
				// 取得會員上次儲值動作資訊
				var saveSet = BankEntities.GetMemberPayRecord(new GetMemberPayRecordInputModel() { ProductGroup = groupType, MemberID = memberId });
				Dictionary<string, string> saveData = (saveSet == null) ? new Dictionary<string, string>()
					: new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(saveSet.WorthDefaultSetting);

				// 會員個人資料
				var memberDetail = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = memberId });

				string temp = "";
				isLastRecord = saveData.TryGetValue("ProductGroup", out temp) ? (temp == ((int)groupType).ToString()) : false;
				payRecord.ProductGroup = groupType;
				payRecord.ValueID = isLastRecord && saveData.TryGetValue("ValueID", out temp) ? Convert.ToInt32(temp) : 0;
				payRecord.ProductID = (payRecord.ValueID != 0 && saveData.TryGetValue("ProductID", out temp)) ? Convert.ToInt32(temp) : 0;
				payRecord.InvoiceEmail = memberDetail.Invoice_EMail;
				payRecord.InvoiceType = memberDetail.Invoice_Type;
				payRecord.InvoiceName = memberDetail.Invoice_Recipient;
				payRecord.InvoiceCityID = memberDetail.Invoice_CityID;
				payRecord.InvoiceZoneID = memberDetail.Invoice_ZoneID;
				payRecord.InvoiceAddress = memberDetail.Invoice_Address;
			}
			#endregion


			IEnumerable<dynamic> valueList = null;
			#region 儲值金額列表 (PointBuyOnline, PointBuyMonthly)

			if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
			{
				//valueList = from i in BankEntities.ValueTypeList(new ValueTypeListInputModel() { CoinType = CoinType.NTD, ProductGroup = groupType, DiscountYN = (ResultCode == 0 ? 1 : 0) })
				valueList = from i in BankEntities.MobileValueTypeList(new ValueTypeListInputModel() { CoinType = CoinType.NTD, ProductGroup = groupType })
							join j in valueProduct on i.PaymentValueID equals j.PaymentValueID
							group j.ProductType.ToString() by i into k
							select new
							{
								ID = k.Key.PaymentValueID,
								Value = k.Key.Value,
								Point = k.Key.Point,
								EveryDayPoint = k.Key.EveryDayPoint,
								TotalPoint = k.Key.TotalPoint,
								Img = k.Key.ImageUrl,
								ImgOver = k.Key.MouseOver,
								ImgDown = k.Key.MouseDown,
								ProductList = k.Aggregate((sum, item) => sum + "," + item)
							};
			}
			#endregion
			log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("ValueTypeListInputModel");
			IEnumerable<dynamic> productList = null;
			#region 付費方式列表 (PointBuyOnline, PointBuySN, PointBuyMonthly, PointTransfer)
			if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuySN, ProductGroupType.PointBuyMonthly, ProductGroupType.TransferOnline }.Contains(groupType))
			{
				productList = from i in BankEntities.MobileProductTypeList(new ProductTypeListInputModel() { ProductGroup = groupType })
							  select new
							  {
								  ID = i.ProductType,
								  Name = i.ProductTypeName,
								  Text = HttpUtility.HtmlDecode(i.Text),
								  Status = (i.Flag == 1 ? "正常" : "維護中"),
								  IsMaintain = (i.Flag != 1),
								  HelpUrl = i.HelpUrl,
								  IsNeedInvoice = i.IsNeedInvoice,
								  Img = i.ImageUrl,
								  ShopUrl = i.ShopUrl,
								  IsPG = i.IsPaymentGateway,
								  Redirect = i.Redirect
							  };
			}
			#endregion
			log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("ProductTypeListInputModel");
			IEnumerable<dynamic> valueProductList = null;
			#region 金額、付費方式的關聯屬性 (PointBuyOnline)
			if (new[] { ProductGroupType.PointBuyOnline }.Contains(groupType))
			{
				valueProductList = from i in valueProduct
								   select new int[] { i.PaymentValueID, i.ProductType, i.CanUseEcoupon };
			}
			#endregion

			IEnumerable<dynamic> cityList = null;
			#region 縣市鄉鎮列表 (PointBuyOnline, PointBuyMonthly)
			if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
			{
				cityList = from i in OtherEntities.CityData()
						   group new { i.ZipCode, i.ZoneID, i.ZoneName } by new { i.CityID, i.CityName } into j
						   select new
						   {
							   // 縣市編號
							   CityID = j.Key.CityID,
							   // 縣市名稱
							   CityName = string.IsNullOrEmpty(j.Key.CityName) ? "請選擇縣市" : j.Key.CityName,
							   // 縣市內所屬的鄉鎮市
							   ZoneList = from x in j
										  select new string[] 
                                          {
                                              x.ZoneID, 
                                              string.IsNullOrEmpty(x.ZoneName) ? "請選擇" : x.ZoneName, 
                                              x.ZipCode 
                                          }
						   };
			}
			#endregion
			log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("before return");

			return new
			{
				// 是否使用最後一次的操作紀錄
				IsLastRecord = isLastRecord,
				// 上次記錄結構或預設資料
				PayRecord = payRecord,
				// 儲值金額列表
				ValueSource = valueList,
				// 付費方式列表
				ProductSource = productList,
				// 金額、付費方式的關聯屬性
				ValueProductSource = valueProductList,
				// 縣市鄉鎮列表
				CitySource = cityList,
				// 回傳檢查狀態碼(此欄位可以通用)
				ResultCode = 0
			};


		}


        /// <summary>
        /// 驗證 ECoupon 正確並取得金額。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic AuthECoupon(CheckECouponInputModel data)
        {
            var Session = HttpContext.Current.Session;
            // 回傳狀態
            int resultCode = 0;
            // 此序號金額
            decimal resultValue = 0;

            data.MemberID = int.Parse(Session["MemberID"].ToString());
            data.IsReturn = 1;


            if (!data.EcouponCode.IsECoupon())
            {
                // 格式錯誤
                resultCode = -1;
                resultValue = 0;
            }
            else
            {
                // 跟DB驗證
                var checkResult = BankEntities.CheckECoupon(data);
                resultCode = checkResult.Result;
                resultValue = checkResult.VALUE;
            }

            return new
            {
                // 回傳狀態
                ResultCode = resultCode,
                // 此序號金額
                ResultValue = resultValue
            };
        }

        /// <summary>
        /// 驗證儲值金額與ECoupon對應的付款方式。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic AuthValueECoupon(CheckValueECouponInputModel data)
        {
            var Session = HttpContext.Current.Session;

            // 回傳狀態
            int resultCode = 0;
            // 此序號金額
            decimal ecouponValue = 0;
            // 回傳訊息
            string message = "";

            data.MemberID = int.Parse(Session["MemberID"].ToString());

            string productList = BankEntities.CheckValueECoupon(data, out resultCode, out ecouponValue, out message).Aggregate("", (sum, item) => (sum == "" ? "" : sum + ",") + item.ToString());

            return new
            {
                // 回傳狀態
                ResultCode = resultCode,
                // 此序號金額
                ECouponValue = ecouponValue,
                // 付款方式列表 (以 "," 分隔)
                ProductList = productList
            };
        }

        /// <summary>
        /// 儲存線上購點的會員儲值動作。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public void SavePayRecord(PayRecord data)
        {
            // 將 null 轉成空字串
            data.InvoiceEmail = string.IsNullOrEmpty(data.InvoiceEmail) ? "" : data.InvoiceEmail;
            data.InvoiceName = string.IsNullOrEmpty(data.InvoiceName) ? "" : data.InvoiceName;
            data.InvoiceZoneID = string.IsNullOrEmpty(data.InvoiceZoneID) ? "" : data.InvoiceZoneID;
            data.InvoiceAddress = string.IsNullOrEmpty(data.InvoiceAddress) ? "" : data.InvoiceAddress;

            BankEntities.SetMemberPayRecord(new SetMemberPayRecordInputModel()
            {
                ProductGroup = data.ProductGroup,
                MemberID = int.Parse(HttpContext.Current.Session["MemberID"].ToString()),
                WorthDefaultSetting = new JavaScriptSerializer().Serialize(data)
            });
        }

        /// <summary>
        /// 取得會員儲值可獲得金額點數資訊。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GetMemberWorth(GetMemberWorthInputModel data)
        {
            var Session = HttpContext.Current.Session;

            data.MemberID = int.Parse(Session["MemberID"].ToString());
            data.VIP_Level = int.Parse(Session["VIP_Level"].ToString());
            data.ECouponCode = data.ECouponCode.IsECoupon() ? data.ECouponCode : "";
            data.ProductID = data.ProductID.IsStoreValue() ? data.ProductID : "";
            data.IsReturn = 0;

            // 金額
            decimal price = 0;
            // 點數
            decimal resultPoints = 0;
            // 每日補點
            decimal everyDayPoints = 0;
            // 贈點
            decimal giftPoints = 0;

            // 取得折價後的金額資訊
            BankEntities.GetMemberWorth(data, out price, out resultPoints, out everyDayPoints, out giftPoints);

            return new
            {
                Price = price,
                ResultPoints = resultPoints,
                EveryDayPoints = everyDayPoints,
                GiftPoints = giftPoints
            };
        }
        #endregion

        #region 老幣轉帳
        /// <summary>
        /// 取得交易編號+MemberID組合加密字串。
        /// </summary>
        /// <param name="transferNo"></param>
        /// <param name="memberId"></param>
        /// <returns></returns>
        private string TransferNoEncrypt(int transferNo, int memberId)
        {
            string key = "123Gosmio1231234";
            string iv = "1231231234Gosmio";

            return CommonUtility.AESEncrypt(string.Format("{0}{1}", memberId, transferNo), key, iv);
        }

        /// <summary>
        /// 從加密字串中取得交易編號。
        /// </summary>
        /// <param name="no"></param>
        /// <param name="memberId"></param>
        /// <returns></returns>
        private int TransferNoDecrypt(string no, int memberId)
        {
            string key = "123Gosmio1231234";
            string iv = "1231231234Gosmio";
            string strMemberid = memberId.ToString();

            if (string.IsNullOrEmpty(key))
            {
                return -1;
            }

            string decKey = CommonUtility.AESDecrypt(no, key, iv);
            int transferNo = 0;

            if (!decKey.StartsWith(strMemberid) || !int.TryParse(decKey.Substring(strMemberid.Length), out transferNo))
            {
                return -1;
            }

            return transferNo;
        }

        /// <summary>
        /// 取得轉帳資訊與暱稱記錄清單。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GetTransferInfo()
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int memberId = context.Session.MemberID;
            int vipLevel = context.Session.VIP_Level;

            var result = TransferEntities.MemberTransferInfo(memberId);

            return new
            {
                Info = new
                {
                    // 是否一般會員
                    IsGeneralMember = (vipLevel == 0),
                    // 總點數
                    TotalPoint = result.TotalPoint,
                    // 可轉點數
                    FreePoint = result.FreePoint,
                    // 轉點上限
                    TransferMax = result.TransferMax,
                    // 鎖定點數
                    LockPoint = result.CreditCardLockPoint,
                    // 鎖定分鐘
                    LockDate = DateTime.Now.AddDays(-7).ToString("yyyy/MM/dd HH:mm"),// DateTime.Now.AddMinutes(-result.CreditCardLockMinute).ToString("yyyy/MM/dd HH:mm")
                    //轉帳手續費%
                    Transfee = result.Transfee
                },
                TargetList = from i in TransferEntities.GetMemberTransferTarget(memberId)
                             select new
                             {
                                 // 會員Key
                                 No = TransferNoEncrypt(i.TransToMemberID, memberId),
                                 // 會員暱稱
                                 Name = i.NickName,
                                 // 是否在線
                                 IsOnline = i.IsOnline == 1
                             }
            };
        }

        /// <summary>
        /// 刪除轉帳暱稱記錄。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public void DelTransferTarget()
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 會員編號
            int memberId = context.Session.MemberID;
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int targetMemberId = TransferNoDecrypt(no, memberId);

            if (targetMemberId != -1)
            {
                TransferEntities.DelMemberTransferTarget(new DelMemberTransferTargetInputModel()
                {
                    MemberID = context.Session.MemberID,
                    TransToMemberID = targetMemberId
                });
            }
        }

        /// <summary>
        /// 會員轉點。
        /// </summary>
        /// <returns>
        /// 0:申請成功，請等候對方確認。
        /// 1001: 請輸入轉帳對象！
        /// 1002: 請輸入轉帳點數！
        /// 1003: 單筆轉帳點數最低為老幣 2 萬點
        /// 1004: DB訊息(DB執行失敗)
        /// 1005: FS訊息(DB執行成功 + 開洗分失敗)
        /// </returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MemberTransfer(MemberTransferApplyInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int resultCode = 0;
            string resultMessage = "";

            if (string.IsNullOrEmpty(data.NickNameReceive))
            {
                resultCode = 1001;
                resultMessage = "請輸入轉帳對象！";
            }
            else if (data.ChangePoints <= 0)
            {
                resultCode = 1002;
                resultMessage = "點數必須大於0！";
            }
            else if (data.ChangePoints < 20000)
            {
                resultCode = 1003;
                resultMessage = "單筆轉帳點數最低為老幣 2 萬點！";
            }
            else
            {
                data.MemberIDSend = context.Session.MemberID;

                var result = TransferEntities.MemberTransferApply(data);

                switch (result.RESULT)
                {
                    case 0:
                        if (result.EventID != null)
                        {
                            string fsResult = FSCommander.FS_AS_CREDIT_CHANGE
                            (
                                Convert.ToInt32(result.EventID),
                                result.Target_MemberID,
                                Convert.ToDecimal(result.ChangePoints),
                                result.PointType
                            );

                            if (fsResult == "0")
                            {
								// DB執行成功 + 開洗分成功
                                resultCode = 0;

								#region 取得TransferNO
								string TransferNO = string.Empty;
								
								SqlParameter[] objParam2 = new SqlParameter[]
								{
									new SqlParameter("@MemberID_Send", data.MemberIDSend)
                                    //new SqlParameter("@KeyinoutID", result.EventID)
								};

								SqlDataReader objDtr = SqlHelper.ExecuteReader
								(
									WebConfig.ConnectionString,
									CommandType.StoredProcedure,
									"NSP_APPWeb_A_Member_GetTransferNO",
									objParam2
								);

								if (objDtr.Read())
								{
									TransferNO = objDtr["TransferNO"].ToString();
								}
								objDtr.Close();
								objDtr.Dispose();
								#endregion
                                try
                                {
                                    #region 發送訊息給發起者
                                    MessageBody sendbody = new MessageBody();
                                    sendbody.body = new MessageBody.Body();
                                    sendbody.body.jid = CommonUtility.GetJiD(result.Target_MemberID.ToString());
                                    sendbody.body.serial = TransferNO;
                                    sendbody.body.nickname = data.NickNameReceive;
                                    sendbody.body.status = "轉出老幣：";
                                    sendbody.body.status_content = data.ChangePoints.ToString();
                                    sendbody.body.step = 1;
                                    sendbody.header = new MessageBody.Header();
                                    sendbody.header.type = "COMPOSITE";
                                    sendbody.header.style = "TRANSFER_CONFIRM";

                                    string sendbodyjson = JsonConvert.SerializeObject(sendbody);
                                    IMGatewayUtility.Instance.UserTalk(context.Session.MemberID, sendbodyjson);
                                    #endregion

                                    #region 發送訊息給接收者
                                    //MessageBody sendbody = new MessageBody();
                                    sendbody.body = new MessageBody.Body();
                                    sendbody.body.jid = CommonUtility.GetJiD(data.MemberIDSend.ToString());
                                    sendbody.body.serial = TransferNO;
                                    sendbody.body.nickname = data.NickNameReceive;
                                    sendbody.body.status = "轉入老幣：";
                                    sendbody.body.status_content = data.ChangePoints.ToString();
                                    sendbody.body.step = 2;
                                    sendbody.header = new MessageBody.Header();
                                    sendbody.header.type = "COMPOSITE";
                                    sendbody.header.style = "TRANSFER_CONFIRM";

                                    sendbodyjson = JsonConvert.SerializeObject(sendbody);
                                    string sqlstr = "select Game_Branch.dbo.FN_APP_GetMemberID(@NickName)";
                                    string rid = SqlHelper.ExecuteScalar(
                                        WebConfig.ConnectionString, 
                                        CommandType.Text, 
                                        sqlstr, 
                                        new SqlParameter("@NickName", data.NickNameReceive)).ToString();
                                    IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(rid), sendbodyjson);
                                    #endregion
                                }
                                catch (Exception ex)
                                {
                                    log4net.LogManager.GetLogger(typeof(BankController)).Error(ex);
                                }
                                resultMessage = "您已成功送出轉帳訊息！";
                            }
                            else
                            {
                                // DB執行成功 + 開洗分失敗
                                resultCode = 1005;
                                resultMessage = fsResult;
                                log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("MemberTransfer::DB執行成功 + 開洗分失敗\r\nMemberIDSend={0}\r\nNickNameReceive{1}\r\nChangePoints={2}\r\nEventID={3}\r\nFSResult={4}", data.MemberIDSend, data.NickNameReceive, data.ChangePoints, result.EventID, fsResult);
                            }
                        }
                        else
                        {
                            // DB執行成功 + EventID IS NULL
                            resultCode = 0;
                            resultMessage = "您已成功送出轉帳訊息！";
                            log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("MemberTransfer::EventID IS NULL\r\nMemberIDSend={0}\r\nNickNameReceive={1}\r\nChangePoints={2}\r\n", data.MemberIDSend, data.NickNameReceive, data.ChangePoints);
                        }
                        break;
                    default:
                        // DB執行失敗
                        resultCode = 1004;
                        resultMessage = result.ResultMSG;
                        log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("MemberTransfer::DB執行失敗\r\nMemberIDSend={0}\r\nNickNameReceive={1}\r\nChangePoints={2}\r\nDBResultCode={3}\r\nDBResultMessage={4}", data.MemberIDSend, data.NickNameReceive, data.ChangePoints, result.RESULT, result.ResultMSG);
                        break;
                }
            }


            return new
            {
                ResultCode = resultCode,
                ResultMessage = resultMessage
            };
        }

        /// <summary>
        /// 取得會員轉帳紀錄。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferMaster(TransferMasterInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int totalReocrd = 0;
            data.MemberID = context.Session.MemberID;

            // 取得目前資料行的應顯示狀態 (1:同意和取消按鈕 2:確認傳送點數按鈕 other:文字狀態)
            Func<bool, int, int, string> stateAnalysis = (isSender, sendStatus, receiveStatus) =>
            {
                if (isSender)
                {
                    switch (sendStatus)
                    {
                        case 6: return "2";
                        case 9: return "取消交易";
                        case 11: return "交易成功";
                        case 28:
                        case 29: return "交易逾時";
                        case 10:
                        default: return "等待同意中";
                    }
                }
                else
                {
                    switch (receiveStatus)
                    {
                        case 10: return "1";
                        case 9: return "取消交易";
                        case 11: return "交易成功";
                        case 28:
                        case 29: return "交易逾時";
                        case 8:
                        default: return "等待傳送中";
                    }
                }
            };

            // 取得目前交易是否已完成
            Func<bool, int, int, bool> stateIsComplete = (isSender, sendStatus, receiveStatus) =>
            {
                if (isSender)
                {
                    return new int[] { 9, 11, 28, 29 }.Contains(sendStatus);
                }
                else
                {
                    return new int[] { 9, 11, 28, 29 }.Contains(receiveStatus);
                }
            };

            return new
            {
                List = from i in TransferEntities.TransferMaster(data, out totalReocrd)
                       select new
                       {
                           // 同意/取消/確認 交易的 Key (加密過)
                           No = TransferNoEncrypt(i.TransferNO, data.MemberID),
                           // 交易編號
                           TransferNo = i.TransferNO,
                           // 此帳號是否是發送方
                           IsSender = (i.MemberID == data.MemberID),
                           // 交易建立日期
                           CreateDate = i.CreateDate.ToString("yyyy/MM/dd HH:mm:ss"),
                           // 發送方暱稱
                           SendName = i.NickNameSend,
                           // 接收方暱稱
                           ReceiveName = i.NickNameReceive,
                           // 轉帳點數
                           Points = i.Points,
                           // 目前狀態 (1:同意和取消按鈕 2:確認傳送點數按鈕 other:文字狀態)
                           Status = stateAnalysis((i.MemberID == data.MemberID), i.DepositsStateA, i.DepositsStateB)
                       },
                TotalRecord = totalReocrd
            };


        }

        /// <summary>
        /// 取得會員轉帳明細紀錄(目前代交易編號就可直接查，需再加上驗證)。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferDetail()
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 會員編號
            int memberId = context.Session.MemberID;
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberId);

            if (transferNo == -1)
            {
                return new string[] { };
            }

            return from i in TransferEntities.TransferDetail(transferNo)
                   select new
                   {
                       // 交易建立日期
                       CreateDate = i.CreateDate.ToString("yyyy/MM/dd HH:mm:ss"),
                       // 交易詳細內容
                       Memo = i.TransferMEMO == null ? "" : i.TransferMEMO
                   };
        }

        /// <summary>
        /// 接收方會員同意/取消轉帳。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferConfirm(TransferConfirmInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 是否成功
            bool isSuccess = false;
            // 是否重新取得點數
            bool isRegainPoint = false;
            // 訊息
            string message = "";

            // 會員編號
            int memberId = context.Session.MemberID;
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberId);

            if (!new int[] { 1, 2 }.Contains(data.YN))
            {
                message = "請選擇交易動作";
            }
            else if (transferNo == -1)
            {
                message = "無此交易序號";
            }
            else
            {
                data.TransferNO = transferNo;
                data.MemberID2 = memberId;

                var result = TransferEntities.TransferConfirm(data);

                switch (result.RESULT)
                {
                    case 0:     // 接收方確認同意
                        message = "轉帳交易成功";
                        isSuccess = true;
                        isRegainPoint = true;
                        break;
                    case 10:
                        // 接收方拒絕，且傳送方在線上
                        // 呼叫Server 歸還點數
                        message = FSCommander.FS_AS_CREDIT_CHANGE
                        (
                            Convert.ToInt32(result.EventID),
                            Convert.ToInt32(result.Target_MemberID),
                            Convert.ToInt32(result.ChangePoints),
                            result.PointType
                        );

                        if (message == "0")
                        {
                            message = "轉帳交易取消";
                            isSuccess = true;
                        }
                        else
                        {
                            log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("TransferConfirm::FS_AS_CREDIT_CHANGE Fail\r\nEventID={0}\r\nTarget_MemberID={1}\r\nChangePoints={2}\r\n", result.EventID, result.Target_MemberID, result.ChangePoints);
                        }
                        break;
                    case 12:    // 接收方拒絕，且傳送方不在線上
                        message = "轉帳交易取消";
                        isSuccess = true;
                        break;
                    case 4:
                        message = "無此交易序號";
                        break;
                    case 2:
                    case 7:
                        message = "交易已取消";
                        break;
                    case 8:
                        message = "交易已完成";
                        break;
                    case 9:
                        message = "接收方已同意過";
                        break;
                    case 11:
                        message = "退款失敗";
                        break;
                    default:
                        message = "交易失敗";
                        break;
                }

				MessageBody sendbody = new MessageBody();


                string selfNickName = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = memberId }).NickName;
                string targetNickName = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = result.Target_MemberID ?? 0 }).NickName;

				if (data.YN == 1)
				{
					#region 發送訊息給發起者

					sendbody.body = new MessageBody.Body();
					sendbody.body.jid = CommonUtility.GetJiD(memberId.ToString()); //取得接收方JID
					sendbody.body.serial = data.TransferNO.ToString();
                    sendbody.body.nickname = selfNickName;
					sendbody.body.status = "狀態：";
					sendbody.body.status_content = "同意交易";
					sendbody.body.step = 3;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					string sendbodyjson = JsonConvert.SerializeObject(sendbody);
                    IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(result.Target_MemberID.ToString()), sendbodyjson);//發送至發送方
					#endregion
				}
				else
				{
					#region 發送訊息給接收者
					sendbody.body = new MessageBody.Body();
                    sendbody.body.jid = CommonUtility.GetJiD(memberId.ToString());//取得發起者JID
					sendbody.body.serial = data.TransferNO.ToString();
                    sendbody.body.nickname = targetNickName;
					sendbody.body.status = "狀態：";
					sendbody.body.status_content = "取消交易";
					sendbody.body.step = 4;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					string sendbodyjson = JsonConvert.SerializeObject(sendbody);
					IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(result.Target_MemberID), sendbodyjson);	//發送至接收方		
					#endregion

					#region 發送訊息給發起者
					sendbodyjson = string.Empty;
					sendbody.body = new MessageBody.Body();
					sendbody.body.jid = CommonUtility.GetJiD(result.Target_MemberID.ToString());//取得接收方JID
					sendbody.body.serial = data.TransferNO.ToString();
                    sendbody.body.nickname = targetNickName;
					sendbody.body.status = "狀態：";
					sendbody.body.status_content = "取消交易";
					sendbody.body.step = 4;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					sendbodyjson = JsonConvert.SerializeObject(sendbody);
					IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(memberId), sendbodyjson);//發送至 交易發送方
					#endregion
				}

            }

            return new
            {
                // 是否成功
                IsSuccess = isSuccess,
                // 是否重新取得點數
                IsRegainPoint = isRegainPoint,
                // 訊息
                Message = message
            };
        }

        /// <summary>
        /// 發送方會員確認轉帳。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferVerify(TransferVerifyInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 是否成功
            bool isSuccess = false;
            // 是否重新取得點數
            bool isRegainPoint = false;
            // 訊息
            string message = "";

            // 會員編號
            int memberId = context.Session.MemberID;
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberId);

            if (string.IsNullOrEmpty(data.VerificationCode))
            {
                message = "請輸驗證碼";
            }
            else if (transferNo == 0)
            {
                message = "無此交易序號";
            }
            else
            {
                data.TransferNO = transferNo;
                data.MemberID = memberId;

                var result = TransferEntities.TransferVerify(data);


                MemberDetailInputModel detailInput = new MemberDetailInputModel();

                detailInput.MemberID = result.Target_MemberID ?? 0;

                var output = MemberEntities.MemberMobileGroupInfo(detailInput);

                var memberDetail = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = detailInput.MemberID });
                string nickName = memberDetail.NickName;

                string sendbodyjson = string.Empty;
                MessageBody sendbody = new MessageBody();

                switch (result.RESULT)
                {
                    case 0:
                        message = "轉帳交易成功";
                        isSuccess = true;

                        #region 發送訊息給發起者
			            sendbody.body = new MessageBody.Body();
			            sendbody.body.jid = CommonUtility.GetJiD(result.Target_MemberID.ToString());
                        sendbody.body.serial = transferNo.ToString();
                        sendbody.body.nickname = nickName;
			            sendbody.body.status = "轉出老幣：";
                        sendbody.body.status_content = result.ChangePoints.ToString();
			            sendbody.body.step = 5;
			            sendbody.header = new MessageBody.Header();
			            sendbody.header.type = "COMPOSITE";
			            sendbody.header.style = "TRANSFER_CONFIRM";

			            sendbodyjson = JsonConvert.SerializeObject(sendbody);
			            IMGatewayUtility.Instance.UserTalk(memberId, sendbodyjson);
			            #endregion

			            #region 發送訊息給接收者
			            sendbodyjson = string.Empty;
			            sendbody.body = new MessageBody.Body();
                        sendbody.body.jid = CommonUtility.GetJiD(memberId.ToString());
                        sendbody.body.serial = transferNo.ToString();
                        sendbody.body.nickname = nickName;
			            sendbody.body.status = "轉入老幣：";
                        sendbody.body.status_content = result.ChangePoints.ToString();
			            sendbody.body.step = 5;
			            sendbody.header = new MessageBody.Header();
			            sendbody.header.type = "COMPOSITE";
			            sendbody.header.style = "TRANSFER_CONFIRM";

			            sendbodyjson = JsonConvert.SerializeObject(sendbody);
                        IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(result.Target_MemberID), sendbodyjson);
			            #endregion
                        break;
                    case 1:
                        message = "驗證失敗";
                        break;
                    case 2:
                        message = "手機驗證逾時";
                        break;
                    case 4:
                        message = "此筆交易己取消";
                        break;
                    case 5:
                        message = "此筆交易己完成";
                        break;
                    case 6:
                        message = "您輸入的驗證碼有誤，請重新輸入";
                        break;
                    case 7:
                        message = "交易序號不存在";
                        break;
                    case 8:
                        // 接收方在線上，通知Server
                        message = FSCommander.FS_AS_CREDIT_CHANGE
                        (
                            Convert.ToInt32(result.EventID),
                            Convert.ToInt32(result.Target_MemberID),
                            Convert.ToDecimal(result.ChangePoints),
                            result.PointType
                        );

                        if (message == "0")
                        {
                            message = "轉帳交易成功";
                            isSuccess = true;

                            #region 發送訊息給發起者
                            sendbody.body = new MessageBody.Body();
                            sendbody.body.jid = CommonUtility.GetJiD(result.Target_MemberID.ToString());
                            sendbody.body.serial = transferNo.ToString();
                            sendbody.body.nickname = nickName;
                            sendbody.body.status = "轉出老幣：";
                            sendbody.body.status_content = result.ChangePoints.ToString();
                            sendbody.body.step = 5;
                            sendbody.header = new MessageBody.Header();
                            sendbody.header.type = "COMPOSITE";
                            sendbody.header.style = "TRANSFER_CONFIRM";

                            sendbodyjson = JsonConvert.SerializeObject(sendbody);
                            IMGatewayUtility.Instance.UserTalk(memberId, sendbodyjson);
                            #endregion

                            #region 發送訊息給接收者
                            sendbodyjson = string.Empty;
                            sendbody.body = new MessageBody.Body();
                            sendbody.body.jid = CommonUtility.GetJiD(memberId.ToString());
                            sendbody.body.serial = transferNo.ToString();
                            sendbody.body.nickname = nickName;
                            sendbody.body.status = "轉入老幣：";
                            sendbody.body.status_content = result.ChangePoints.ToString();
                            sendbody.body.step = 5;
                            sendbody.header = new MessageBody.Header();
                            sendbody.header.type = "COMPOSITE";
                            sendbody.header.style = "TRANSFER_CONFIRM";

                            sendbodyjson = JsonConvert.SerializeObject(sendbody);
                            IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(result.Target_MemberID), sendbodyjson);
                            #endregion
                        }
                        else
                        {
                            log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("TransferVerify::FS_AS_CREDIT_CHANGE Fail\r\nEventID={0}\r\nTarget_MemberID={1}\r\nChangePoints={2}\r\n", result.EventID, result.Target_MemberID, result.ChangePoints);
                        }
                        break;
                    case 99:
                    default:
                        message = "驗證失敗";
                        break;
                }
            }

            return new
            {
                // 是否成功
                IsSuccess = isSuccess,
                // 是否重新取得點數
                IsRegainPoint = isRegainPoint,
                // 訊息
                Message = message
            };
        }

        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic SendSMSCode()
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int memberID = context.Session.MemberID;
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberID);
            return TransferEntities.SendSMSCode(new SendSMSCodeInputModel { MemberID = memberID, TransferNO = transferNo });
        }
        #endregion

        /// <summary>
        /// PaymentGateway Req103 通知更新訂單 / 交易開分
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Post")]
        public System.Net.Http.HttpResponseMessage UpdateOrder()
        {
            // 這裡用來把客戶交易結果寫入商店自己的資料庫中.
            StringBuilder sbResult = new StringBuilder();
            try
            {

                // 初始化 API
                PaymentClientMvc payingHandler = new PaymentClientMvc
                (
                    WebConfig.PaymentGatewayHost
                    , WebConfig.PaymentStoreID
                    , WebConfig.PaymentEncryptKey
                );

                // 解讀交易結果
                PayingEventArgs resultPG = payingHandler.ReceiveOrderResult();

                // 商店端自訂訂單編號
                sbResult.AppendLine("SSOrderID: " + resultPG.SSOrderID);
                // PaymentGateway端產生的訂單編號
                sbResult.AppendLine("PGOrderID: " + resultPG.PGOrderID);
                // 交易結果代碼
                sbResult.AppendLine("ResultCode: " + resultPG.ResultCode);
                // 交易失敗原因
                sbResult.AppendLine("ResultText: " + resultPG.ResultText);
                // 銀行授權識別碼
                sbResult.AppendLine("BankApproveCode: " + resultPG.BankApproveCode);
                // 銀行交易結果代碼
                sbResult.AppendLine("BankErrorCode: " + resultPG.BankErrorCode);
                // 銀行端交易失敗原因
                sbResult.AppendLine("BankErrorText: " + resultPG.BankErrorText);
                // 銀行端傳回之資訊
                sbResult.AppendLine("BankResultExtension: " + resultPG.BankResultExtension);
                // 實際使用之金流編號
                sbResult.AppendLine("CommitPaymentTypeID: " + resultPG.CommitPaymentTypeID);
                // 實際使用金額 (這欄是填寫在 FinalPrice 的地方)
                sbResult.AppendLine("CommitAmount: " + resultPG.CommitAmount);

				// 仔細的資料要去 GameWeb_Models 查
                List<UpdateOrderResultModel> resultModel = BankEntities.UpdateOrder
                (
					// 產生參數元件
                    new UpdateOrderInputModel()
                    {
                        PGOrderID = resultPG.PGOrderID,
                        SSOrderID = resultPG.SSOrderID,
                        CommitPaymentTypeID = resultPG.CommitPaymentTypeID,
                        ResultCode = resultPG.ResultCode,
                        ResultText = resultPG.ResultText,
                        CommitAmount = resultPG.CommitAmount,
                        BankApproveCode = resultPG.BankApproveCode,
                        BankErrorCode = resultPG.BankErrorCode,
                        BankErrorText = resultPG.BankErrorText,
                        BankResultExtension = resultPG.BankResultExtension
                    }
                );

				// 2014/4/15 NickShih 取得活動相關資料
				Dictionary<string, object> dictActivityInfo = GWeb.ActivityMgr.GetActivityByOrderID(resultPG.SSOrderID);
				string strMemberID = dictActivityInfo["MemberID"].ToString();
				string jsonActivityList = dictActivityInfo["ShopActivityList"].ToString();
				// 做一些相關的處理和計算
				List<Dictionary<string, object>> listFitActivity = GWeb.ActivityMgr._ProcessActivityRuler(jsonActivityList, strMemberID, resultPG.SSOrderID);
				// 更新 DB 的資料
				double dRate = 1.0f;
				foreach (Dictionary<string, object> dictFitActivity in listFitActivity)
				{
					// 取得字串型態
					string strAward = dictFitActivity["Award"].ToString();
					// 切 Token 
					if (strAward == "")
					{
						continue;
					}
					Dictionary<string, object> dictAward = Utility.TranslateRuler(strAward);
					if (dictAward.Count == 0)
					{
						continue;
					}
					if (dictAward.ContainsKey("Money") == false)
					{
						continue;
					}
					string strMoney = dictAward["Money"].ToString();
					dRate += System.Convert.ToDouble (System.Convert.ToDouble(strMoney)/100.0);
				}

				// 對於回來的結果, 每一個都使用 FSCommand 傳回去
                foreach (UpdateOrderResultModel obj in resultModel)
                {
                    if (obj.ResultCode == 0)
                    {
                        // 成功後，把錢轉點數
                        long EventID = obj.EventID;
                        int MemberIDTarget = obj.Target_MemberID;
                        int PointType = obj.PointType;
						// 取得點數
                        decimal Point = obj.ChangePoints;
						// 乘上比例
						Point = System.Convert.ToDecimal ( System.Convert.ToDouble ( Point )* dRate );
						log4net.LogManager.GetLogger(typeof(BankController)).ErrorFormat("EventID:{0}, MemberIDTarget:{1}, Point:{2}, Rate:{3}", EventID, MemberIDTarget, Point, dRate);
						// 修改 DB 資料
						GWeb.GameBranchDB.Add_A_MemberCreditChangeEvent_ChangePoints(EventID, dRate, resultPG.SSOrderID);
						// 送給 fron server
                        string ResultMsg = "";
						ResultMsg = GS.ServerCommander.FSCommander.FS_AS_CREDIT_CHANGE(EventID, MemberIDTarget, Point, PointType);
						//ResultMsg = GS.ServerCommander.FSCommander.FS_AS_CREDIT_CHANGE(EventID, MemberIDTarget, Point, PointType);
						if (ResultMsg != "0")
                        {
                            log4net.LogManager.GetLogger(typeof(BankController)).ErrorFormat
                            (
                                "UpdateOrder 執行Server開洗分失敗: ResultMsg: {0}",
                                ResultMsg
                            );
                        }
                    }
                    else
                    {
                        log4net.LogManager.GetLogger(typeof(BankController)).ErrorFormat
                        (
                            "UpdateOrder SP- NSP_GameWeb_A_UpdateOrder: 執行失敗。回傳ResultCode: {0}, ResultMsg: {1}",
                            obj.ResultCode,
                            obj.ResultMsg
                        );
                    }
                    sbResult.AppendLine("StoreDBResultCode: " + obj.ResultCode);
                    sbResult.AppendLine("StoreDBResultMsg: " + obj.ResultMsg);
                }
				
            }
            catch (Exception ex)
            {
                sbResult.AppendLine("Store Error ExceptionMessage: " + ex.Message);
                log4net.LogManager.GetLogger(typeof(BankController)).Error
                (
                    string.Format("UpdateOrder ErrorMessage:{0}", ex.Message),
                    ex
                );
            }

            return new System.Net.Http.HttpResponseMessage()
            {
                Content = new System.Net.Http.StringContent(
                    sbResult.ToString(),
                    Encoding.UTF8,
                    "text/plain"
                )
            };
        }
    }
}
