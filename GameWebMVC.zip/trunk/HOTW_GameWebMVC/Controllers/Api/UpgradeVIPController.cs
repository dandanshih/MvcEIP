﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web;
using HOTW_GameWebMVC.AppLibs;
using System.Web.Script.Serialization;
using HOTW_GameWebMVC.Models;
using GS.Web.CommunityGateway.StoreAPI;
using System.Text.RegularExpressions;

namespace HOTW_GameWebMVC.Controllers.Api
{
	public class UpgradeVIPController : ApiController
    {
		[AcceptVerbs(new string[] { "Post" })]
		public MemberResultData InputMobile(string mobile)
        {
			if (Request.Method == HttpMethod.Post)
			{
				mobile = System.Web.HttpContext.Current.Request.Form["mobile"] as string;
			}

			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			#region 驗證
			if (!string.IsNullOrEmpty(mobile) && !Regex.IsMatch(mobile, @"^[09]{2}[0-9]{8}$"))
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 101;
				resultData.ResultMsg = "手機格式錯誤";
				return resultData;
			}
			#endregion			

			if (Session["IsLogin"] == null || Session["MemberID"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 99;
			}
			else if (MemberAttribute.Current.IsHCoin)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 98;
				resultData.ResultMsg = "您已是VIP會員";
			}
			else
			{
				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
				minfo.Mobile = mobile;
				resultData = MemberEventUtility.EditData(minfo);

				if (resultData.ResultCode == 10)
				{
					Session["WaitMobileAuthAccount"] = Session["MemberAccount"].ToString();
					Session["WaitMobileAuthMobile"] = mobile;
				}
			}

			return resultData;
        }

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic LogoutWithLogin()
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["MemberAccount"] == null || Session["MemberPassword"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 98;
			}
			else
			{
				try
				{
					MemberInfo minfo = new MemberInfo();
					minfo.MemberAccount = Session["MemberAccount"].ToString();
					minfo.MemberPassword = Session["MemberPassword"].ToString();
					minfo.Mobile4Num = " ";
					minfo.Platform = "Web";
					minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
					minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;
					resultData = MemberEventUtility.LogoutWithLogin(minfo);
				}
				catch (Exception ex)
				{
					log4net.LogManager.GetLogger(typeof(AccountController)).Error("LogoutWithLoginFail", ex);
					resultData = new MemberResultData();
					resultData.ResultCode = 99;
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg
			};
		}
    }
}
