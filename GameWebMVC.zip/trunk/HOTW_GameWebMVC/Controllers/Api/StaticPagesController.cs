﻿using GS.Web.CPA;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.Models;
using System;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Http;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class StaticPagesController : ApiController
    {
        #region 共用
        /// <summary>
        /// 登出。
        /// </summary>
        [AcceptVerbs("Post")]
        public void Logout()
        {
            HttpContext.Current.Session.Abandon();
        }

        /// <summary>
        /// 手機驗證。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic MobileAuthentication()
        {
            var Session = HttpContext.Current.Session;
            var Request = HttpContext.Current.Request;

            string verificationCode = Request.Form["verificationCode"] as string;
            MemberResultData resultData = new MemberResultData();

            if (string.IsNullOrEmpty(verificationCode))
            {
                resultData.ResultCode = 101;
                resultData.ResultMsg = "驗證碼不可空白！";
            }
            else if (Session["MemberID"] == null || Session["WaitMobileAuthAccount"] == null)
            {
                resultData.ResultCode = 99;
                resultData.ResultMsg = "驗證碼逾時！";
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
                minfo.Mobile = Session["WaitMobileAuthMobile"].ToString();
                minfo.MobileVaildCode = verificationCode;
                resultData = MemberEventUtility.MobileVaild(minfo);

                // 若有 Initial 過則儲存 SessionID
                CPAHandler handler = new CPAHandler(WebConfig.CPAConnectionString);
                handler.Add(CPAType.Other, EventType.Register);
                handler.SaveData();
                handler.Clear();
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg
            };
        }

        /// <summary>
        /// 重新發送簡訊。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic ReSendVerificationCode()
        {
            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            if (Session["MemberID"] == null || Session["WaitMobileAuthAccount"] == null)
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
                minfo.MemberAccount = Session["WaitMobileAuthAccount"].ToString();
                minfo.Mobile = Session["WaitMobileAuthMobile"].ToString();
                resultData = MemberEventUtility.ReSendSMS(minfo);

                if (resultData.ResultCode == 0)
                {
#if(!Online)
                    string SqlCmd = "SELECT VerificationCode FROM A_Member WHERE MemberAccount = @MemberAccount";
                    System.Data.SqlClient.SqlParameter param = new System.Data.SqlClient.SqlParameter("@MemberAccount", minfo.MemberAccount);
                    resultData.Data = GS.Utilities.SqlHelper.ExecuteScalar
                    (
                        WebConfig.ConnectionString,
                        System.Data.CommandType.Text,
                        SqlCmd,
                        param
                    ).ToString();
#endif
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg,
                Data = resultData.Data
            };
        }

        /// <summary>
        /// 取消手機驗證。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic CancelMobileAuthentication()
        {
            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            if (Session["MemberID"] == null || Session["WaitMobileAuthMobile"] == null)
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "驗證碼逾時！";
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
                minfo.Mobile = Session["WaitMobileAuthMobile"].ToString();

                resultData = MemberEventUtility.CancelMobileVaild(minfo);
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg
            };
        }
        #endregion

        #region 活動頁會員
        /// <summary>
        /// 活動頁會員註冊(加帶AppName)。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic ActionRegister(RegisterModel registerModel)
        {
            var Session = HttpContext.Current.Session;
            string appName = ControllerContext.RouteData.Values["id"].ToString();
            MemberResultData resultData;

            #region 驗證
            if (Session["IsLogin"] != null)
            {
                return new
                {
                    ResultCode = 200,
                    ResultMsg = "您已經是會員"
                };
            }
            else if (appName == "undefined")
            {
                // 非從外部廣告連進，不合資格
                return new
                {
                    ResultCode = 300,
                    ResultMsg = ""
                };
            }
            else if (!Regex.IsMatch(registerModel.MemberAccount, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
            {
                return new
                {
                    ResultCode = 101,
                    ResultMsg = "帳號錯誤"
                };
            }
            else if (!Regex.IsMatch(registerModel.MemberPassword, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
            {
                return new
                {
                    ResultCode = 102,
                    ResultMsg = "密碼錯誤"
                };
            }
            else if (!Regex.IsMatch(registerModel.Mobile, @"^[09]{2}[0-9]{8}$"))
            {
                return new
                {
                    ResultCode = 103,
                    ResultMsg = "手機格式錯誤"
                };
            }
            #endregion

            MemberInfo minfo = new MemberInfo();
            minfo.MemberAccount = registerModel.MemberAccount;
            minfo.MemberPassword = registerModel.MemberPassword;
            minfo.Mobile = registerModel.Mobile;
            minfo.AppName = appName;

            resultData = MemberEventUtility.WebRegister(minfo);

            if (resultData.ResultCode == 0)
            {
                Session["MemberID"] = resultData.LoginData.MemberID;
                Session["WaitMobileAuthAccount"] = registerModel.MemberAccount;
                Session["WaitMobileAuthPassword"] = registerModel.MemberPassword;
                Session["WaitMobileAuthMobile"] = registerModel.Mobile;
                Session["ConfirmRegisterTime"] = DateTime.Now;
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg,
                Data = resultData.Data
            };
        }

        /// <summary>
        /// 活動頁註冊的會員登入。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic ActionLogin()
        {
            var Session = HttpContext.Current.Session;
            var Request = HttpContext.Current.Request;

            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";
            string account = Request.Form["account"] as string;
            string password = Request.Form["password"] as string;

            MemberResultData resultData = new MemberResultData();

            if (Session["IsLogin"] != null)
            {
                resultData.ResultCode = 30;
                resultData.ResultMsg = "您已登入會員。";
            }
            else if (string.IsNullOrEmpty(account))
            {
                resultData.ResultCode = 101;
                resultData.ResultMsg = "請輸入帳號！";
            }
            else if (string.IsNullOrEmpty(password))
            {
                resultData.ResultCode = 102;
                resultData.ResultMsg = "請輸入密碼！";
            }
            else
            {
                // 解密
                account = CommonUtility.RSADecrypt(account, RsaPrivateKey);
                password = CommonUtility.RSADecrypt(password, RsaPrivateKey);

                // 確認登入資料是否正確
                if (string.IsNullOrEmpty(account) || string.IsNullOrEmpty(password))
                {
                    resultData.ResultCode = 98;
                    resultData.ResultMsg = "登入資訊不正確！";
                    resultData.LoginData = new GS.ServerCommander.FS_IIS_USER_LOGIN_R();
                }
                else
                {
                    try
                    {
                        MemberInfo minfo = new MemberInfo();
                        minfo.MemberAccount = string.IsNullOrEmpty(account) ? " " : account;
                        minfo.MemberPassword = string.IsNullOrEmpty(password) ? " " : password;
                        minfo.Mobile4Num = " ";
                        minfo.Platform = "Web";
                        minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
                        minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;

                        resultData = MemberEventUtility.ActionLogin(minfo);
                    }
                    catch (Exception ex)
                    {
                        log4net.LogManager.GetLogger(typeof(AccountController)).Error("StaticPagesController::LoginFail", ex);
                        resultData.ResultCode = 99;
                        resultData.ResultMsg = "伺服器維護中！";
                    }
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg
            };
        }

        /// <summary>
        /// 活動頁註冊的會員後踢前登入。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic ActionReLogin()
        {
            var Session = HttpContext.Current.Session;
            int MemberID = 0;
            string MemberAccount = "";

            MemberResultData ResultData;

            if (Session["MemberID"] == null || Session["MemberAccount"] == null)
            {
                ResultData = new MemberResultData();
                ResultData.ResultCode = 99;
                ResultData.ResultMsg = "伺服器維護中！";
            }
            else
            {
                MemberID = Convert.ToInt32(HttpContext.Current.Session["MemberID"]);
                MemberAccount = Session["MemberAccount"].ToString();

                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = MemberID;
                minfo.MemberAccount = MemberAccount;
                minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.ReLogin;
                minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
                minfo.Platform = "Web";
                ResultData = MemberEventUtility.ActionLogin(minfo);
            }

            return new
            {
                ResultCode = ResultData.ResultCode,
                ResultMsg = ResultData.ResultMsg,
                Data = ResultData.Data
            };
        }

        /// <summary>
        /// 活動頁註冊的會員自動登入。
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Post")]
        public dynamic ActionAutoLogin()
        {
            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            if (Session["WaitMobileAuthAccount"] == null || Session["WaitMobileAuthPassword"] == null)
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "遊戲目前進行維護中，請稍後再來玩！";
            }
            else
            {
                try
                {
                    MemberInfo minfo = new MemberInfo();
                    minfo.MemberAccount = Session["WaitMobileAuthAccount"].ToString();
                    minfo.MemberPassword = Session["WaitMobileAuthPassword"].ToString();
                    minfo.Mobile4Num = " ";
                    minfo.Platform = "Web";
                    minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
                    minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;
                    resultData = MemberEventUtility.ActionLogin(minfo);
                    Session.Remove("WaitMobileAuthAccount");
                    Session.Remove("WaitMobileAuthPassword");
                }
                catch (Exception ex)
                {
                    log4net.LogManager.GetLogger(typeof(AccountController)).Error("LoginFail", ex);
                    resultData = new MemberResultData();
                    resultData.ResultCode = 99;
                    resultData.ResultMsg = "遊戲目前進行維護中，請稍後再來玩！";
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg
            };
        }

        /// <summary>
        /// 檢查目前登入的會員是否為活動頁註冊特定會員。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic CheckMember()
        {
            var Session = HttpContext.Current.Session;

            MemberResultData resultData = new MemberResultData();

            if (Session["IsLogin"] == null)
            {
                resultData.ResultCode = 99;
                resultData.ResultMsg = "請重新登入會員。";
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.MemberAccount = Session["MemberAccount"].ToString();
                resultData = MemberEventUtility.AppMemberCheck(minfo);
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg
            };
        }
        #endregion

        #region 一般會員
        /// <summary>
        /// 一般會員登入。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic Login()
        {
            var Session = HttpContext.Current.Session;
            var Request = HttpContext.Current.Request;

            string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";
            string account = Request.Form["account"] as string;
            string password = Request.Form["password"] as string;

            MemberResultData resultData = new MemberResultData();

            if (Session["IsLogin"] != null)
            {
                resultData.ResultCode = 30;
                resultData.ResultMsg = "您已登入會員。";
            }
            else if (string.IsNullOrEmpty(account))
            {
                resultData.ResultCode = 101;
                resultData.ResultMsg = "請輸入帳號！";
            }
            else if (string.IsNullOrEmpty(password))
            {
                resultData.ResultCode = 102;
                resultData.ResultMsg = "請輸入密碼！";
            }
            else
            {
                // 解密
                account = CommonUtility.RSADecrypt(account, RsaPrivateKey);
                password = CommonUtility.RSADecrypt(password, RsaPrivateKey);

                // 確認登入資料是否正確
                if (string.IsNullOrEmpty(account) || string.IsNullOrEmpty(password))
                {
                    resultData.ResultCode = 98;
                    resultData.ResultMsg = "登入資訊不正確！";
                    resultData.LoginData = new GS.ServerCommander.FS_IIS_USER_LOGIN_R();
                }
                else
                {
                    try
                    {
                        MemberInfo minfo = new MemberInfo();
                        minfo.MemberAccount = string.IsNullOrEmpty(account) ? " " : account;
                        minfo.MemberPassword = string.IsNullOrEmpty(password) ? " " : password;
                        minfo.Mobile4Num = " ";
                        minfo.Platform = "Web";
                        minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
                        minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;

                        resultData = MemberEventUtility.Login(minfo);
                    }
                    catch (Exception ex)
                    {
                        log4net.LogManager.GetLogger(typeof(AccountController)).Error("StaticPagesController::LoginFail", ex);
                        resultData.ResultCode = 99;
                        resultData.ResultMsg = "伺服器維護中！";
                    }
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg
            };
        }

        /// <summary>
        /// 一般會員後踢前登入。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic ReLogin()
        {
            var Session = HttpContext.Current.Session;
            int MemberID = 0;
            string MemberAccount = "";

            MemberResultData ResultData;

            if (Session["MemberID"] == null || Session["MemberAccount"] == null)
            {
                ResultData = new MemberResultData();
                ResultData.ResultCode = 99;
                ResultData.ResultMsg = "伺服器維護中！";
            }
            else
            {
                MemberID = Convert.ToInt32(HttpContext.Current.Session["MemberID"]);
                MemberAccount = Session["MemberAccount"].ToString();

                MemberInfo minfo = new MemberInfo();
                minfo.MemberID = MemberID;
                minfo.MemberAccount = MemberAccount;
                minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.ReLogin;
                minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
                minfo.Platform = "Web";
                ResultData = MemberEventUtility.Login(minfo);
            }

            return new
            {
                ResultCode = ResultData.ResultCode,
                ResultMsg = ResultData.ResultMsg,
                Data = ResultData.Data
            };
        }

        /// <summary>
        /// 一般會員自動登入。
        /// </summary>
        [AcceptVerbs("Post")]
        public dynamic AutoLogin()
        {
            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            if (Session["WaitMobileAuthAccount"] == null || Session["WaitMobileAuthPassword"] == null)
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "遊戲目前進行維護中，請稍後再來玩！";
            }
            else
            {
                try
                {
                    MemberInfo minfo = new MemberInfo();
                    minfo.MemberAccount = Session["WaitMobileAuthAccount"].ToString();
                    minfo.MemberPassword = Session["WaitMobileAuthPassword"].ToString();
                    minfo.Mobile4Num = " ";
                    minfo.Platform = "Web";
                    minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
                    minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;
                    resultData = MemberEventUtility.Login(minfo);
                    Session.Remove("WaitMobileAuthAccount");
                    Session.Remove("WaitMobileAuthPassword");
                }
                catch (Exception ex)
                {
                    log4net.LogManager.GetLogger(typeof(AccountController)).Error("LoginFail", ex);
                    resultData = new MemberResultData();
                    resultData.ResultCode = 99;
                    resultData.ResultMsg = "遊戲目前進行維護中，請稍後再來玩！";
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg
            };
        }
        #endregion
    }
}
