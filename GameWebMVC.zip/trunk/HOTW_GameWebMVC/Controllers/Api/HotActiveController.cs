﻿using GameWeb_Models.Models.Active;
using GameWeb_Models.Models.Gift;
using GameWeb_Models.Models.HotActive;
using GameWeb_Models.Models.Lotto;
using GS.Utilities;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using HOTW_GameWebMVC.Attributes.WebAPI;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class HotActiveController : ApiController
    {
        #region 活動賽事(Active)
        /// <summary>
        /// 取得樂透日期列表(Cache 10分)。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic Active(ActiveListInputModel Input)
        {
            var Session = HttpContext.Current.Session;
            Input.MemberID = (Session["MemberID"] != null) ? int.Parse(Session["MemberID"].ToString()) : 0;

            return from i in ActiveEntities.ActiveList(Input)
                   select new
                   {
                       Name = i.Name,
                       PicUrl = "//" + WebConfig.DataInfoUrl + i.PicUrl,
                       Target = (i.Target == 1 ? "_blank" : "_self"),
                       Link = i.Link
                   };
        }
        #endregion

        #region 老子大樂透(Lottery)
        /// <summary>
        /// 取得樂透日期列表。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic LottoDate()
        {
            LottoDateInputModel input = new LottoDateInputModel();
            input.Type = false;
            input.EventType = 0;

            return from i in LottoEntities.LottoDate(input)
                   where i.PhaseType == "0"
                   orderby i.EndDate descending
                   select new
                   {
                       // 期別
                       PhaseName = i.PhaseName,
                       // 民國日期
                       RCDate = i.EndDate.AddYears(-1911).Year.ToString() + i.EndDate.ToString("/MM/dd")
                   };
        }

        /// <summary>
        /// 查詢樂透兌獎資訊與中獎名單。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic LottoLotteryData(LotteryInfoInputModel Input)
        {
            if (string.IsNullOrEmpty(Input.PhaseName))
            {
                return "";
            }

            // 樂透開獎資訊
            LotteryInfoResultModel lotteryInfo = LottoEntities.LotteryInfo(Input);
            // 樂透得獎名單
            List<LotteryListResultModel> lotteryList = new List<LotteryListResultModel>();
            // 期數資訊
            string phaseName = "";

            if (lotteryInfo != null)
            {
                phaseName = lotteryInfo.PhaseName;

                // 有開獎資訊才讀取名單
                for (int i = 1; i <= 5; i++)
                {
                    int totalRecords = 0;
                    lotteryList.AddRange(LottoEntities.LotteryList(new LotteryListInputModel()
                    {
                        PhaseID = lotteryInfo.PhaseID,
                        PageSize = 100000,
                        PageIndex = 1,
                        RuleID = i
                    }, out totalRecords));
                }
            }

            return new
            {
                // 樂透開獎資訊
                LotteryInfo = (lotteryInfo == null) ? null : new
                {
                    PhaseName = lotteryInfo.PhaseName,
                    // 開獎號碼
                    No = string.Format("{0} {1} {2} {3} {4} {5}", lotteryInfo.No1, lotteryInfo.No2, lotteryInfo.No3, lotteryInfo.No4, lotteryInfo.No5, lotteryInfo.No6).TrimEnd(),
                    // 特別號
                    SpecialNo = lotteryInfo.SpecialNo,
                    // 民國日期
                    RCDate = lotteryInfo.EndDate.AddYears(-1911).Year.ToString() + lotteryInfo.EndDate.ToString("/MM/dd"),
                    // 是否顯示彩金欄位
                    IsWinning = (!new string[] { "100000073", "100000072", "100000071" }.Contains(phaseName))
                },
                // 樂透得獎名單
                LotteryList = from i in lotteryList
                              group i.NickName by new { i.RuleName, i.Winning } into j
                              select new
                              {
                                  // 獎項
                                  RuleName = j.Key.RuleName,
                                  // 彩金
                                  Winning = j.Key.Winning.ToString("N0"),
                                  // 暱稱列表
                                  NickName = j
                              }
            };
        }
        #endregion

        #region 尊榮卡別活動(WinnersCard)
        /// <summary>
        /// 取得VIP卡別活動日期列表(Cache 10分)。
        /// </summary>
        /// <returns>
        /// ["102/01"]
        /// </returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic GetVipMarioGiftDate()
        {
            Func<dynamic> func = () =>
            {
                // 西元轉民國
                Func<DateTime, string> ADToRC = (date) =>
                {
                    return date.AddYears(-1911).Year.ToString() + date.ToString("/MM");
                };

                return from i in GiftEntities.VipMarioGiftDate()
                       select ADToRC(DateTime.Parse(i.YearMonth));
            };

            return CacheUtility.GetCache(func, 600, "GetVipMarioGiftDate");
        }

        /// <summary>
        /// 取得VIP卡別活動獲獎名單(禮物列表 Cache 10分)。
        /// </summary>
        /// <returns>
        /// [
        ///     {"GiftName":"王品牛排餐券","IsCaption":false,"NickName":["harry","rdtest0020","00532"]},
        ///     {"GiftName":"老幣1,000~100,000點","IsCaption":true,"NickName":["因中獎玩家數多，故不一一詳列"]}
        /// ]
        /// </returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic GetVipMarioGiftWinners(VipMarioGiftWinnersInputModel Input)
        {
            // DataDate 因為在 GetVipMarioGiftDate() 是輸出為民國年/月(ex. "102/01")，因此要將其反轉
            if (Regex.IsMatch(Input.DataDate, @"^\d{3}/\d{1,2}$"))
            {
                string[] datePart = Input.DataDate.Split('/');
                Input.DataDate = string.Format("{0}/{1}/01", int.Parse(datePart[0]) + 1911, datePart[1]);

                // 禮物列表無快取時從DB取資料的動作
                Func<dynamic> giftList = () =>
                {
                    return GiftEntities.VipMarioGiftList();
                };

                // 從快取中取得禮物列表
                List<VipMarioGiftListResultModel> giftListResult = CacheUtility.GetCache(giftList, 600, "VipMarioGiftList");

                return from i in giftListResult
                       join j in GiftEntities.VipMarioGiftWinners(Input)
                           on i.GiftType equals j.GiftType
                       group j.NickName by new { i.GiftType, i.GiftName } into k
                       select new
                       {
                           GiftName = k.Key.GiftName,
                           // 禮物「老幣1,000~100,000點」是顯示「因中獎玩家數多，故不一一詳列」，因此提供此欄位給前端判斷
                           IsCaption = (k.Key.GiftType == 6),
                           NickName = k
                       };
            }

            return null;
        }
        #endregion

        #region 填Email抽大獎(WinnersEmail)、排名爭霸領現金(WinnersRankingCash)、晚點名送現金(WinnersNightCash)
        /// <summary>
        /// 取得金庫禮的禮物列表(Cache 10分)。
        /// </summary>
        /// <returns>
        /// {
        /// "Master":["102/02","101/12"],
        /// "Detail":[{
        ///             "GroupName":"102/02",
        ///             "List":[{"GiftName":"西堤餐券","NickName":["剛扣朗","好玩就好1 ","RDTest1119"]}]
        ///          },{
        ///             "GroupName":"101/12",
        ///             "List":[{"GiftName":"西堤餐券","NickName":["juju","哇叫彩色","超哥哥"]}]
        ///          }]
        /// }
        /// </returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic KingCoolGiftList(KingCoolGiftMasterInputModel data)
        {
            // 無快取時取資料的方法
            Func<dynamic> func = () =>
            {
                // 取得禮物類別列表
                var master = from i in GiftEntities.KingCoolGiftMaster(data)
                             orderby i.GroupID descending
                             select i.GroupName;

                // 取得禮物明細列表
                KingCoolGiftDetailInputModel detailInput = new KingCoolGiftDetailInputModel();
                detailInput.TypeID = data.TypeID;

                var detail = from i in GiftEntities.KingCoolGiftDetail(detailInput)
                             group new { NickName = i.NickName, GiftName = i.GiftName } by new { i.GroupName } into j
                             select new
                             {
                                 GroupName = j.Key.GroupName,
                                 List = from x in j
                                        group x.NickName by x.GiftName into y
                                        select new
                                        {
                                            GiftName = y.Key,
                                            NickName = y
                                        }
                             };

                return new
                {
                    Master = master,
                    Detail = detail
                };
            };

            return CacheUtility.GetCache(func, 600, "KingCoolGiftList_{0}", data.TypeID);
        }
        #endregion

        #region 網咖活動(2013/06/27~2013/07/18)
        //		/// <summary>
        //		/// 網咖活動-判斷權限及押分查詢
        //		/// </summary>
        //		/// <param name="input"></param>
        //		/// <returns>dynamic</returns>
        //		[AcceptVerbs("Post")]
        //		[AjaxOnly]
        //		public dynamic QueryPlayerWinLoseLog(ActionCyberCafeInputModel input)
        //		{
        //			try
        //			{
        //				DateTime Open = new DateTime(2013, 6, 27, 11, 0, 0);
        //				DateTime Close = new DateTime(2013, 7, 18, 8, 0, 0);
        //				DateTime Now = DateTime.Now;

        //				int IsOpen = 1;

        //#if(Online)
        //				if (Open < Now && Now < Close)
        //				{
        //					IsOpen = 1;
        //				}
        //				else if (Open > Now)
        //				{
        //					IsOpen = 0;
        //				}
        //				else if (Close < Now)
        //				{
        //					IsOpen = 2;
        //				}
        //#endif

        //				bool _IsWarning = true;

        //				ActionCyberCafePlayerWinLoseLogResultModel result;

        //				DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

        //				string UserIP = HttpContext.Current.Request.UserHostAddress;

        //#if(true)
        //				//第一步驟先判斷使用者端的IP是否為允許IP
        //				if (!string.IsNullOrEmpty(UserIP) && !string.IsNullOrWhiteSpace(UserIP))
        //				{
        //					_IsWarning = ActionCyberCafeEntity.ActionCyberCafeCheckIP(UserIP) == 0 ? true : false;
        //				}
        //#else
        //				_IsWarning = false;
        //#endif

        //				//第二步驟再判斷使用者是否為登入的狀態
        //				if (context.Session.MemberID <= 0)
        //				{
        //					return new
        //					{
        //						Result = new
        //						{
        //							IsOpen = IsOpen,
        //							IsWarning = _IsWarning,
        //							IsLogin = false,
        //							Data = new ActionCyberCafePlayerWinLoseLogResultModel()
        //						}
        //					};
        //				}

        //				//最後再帶入參數去取得總押分數及會員卡別等級
        //				input.MemberID = context.Session.MemberID;

        //				result = ActionCyberCafeEntity.ActionCyberCafeQueryPlayerWinLoseLog(input);

        //				result.VIP_Level = context.Session.VIP_Level;

        //				return new
        //				{
        //					Result = new
        //					{
        //						IsOpen = IsOpen,
        //						IsWarning = _IsWarning,
        //						IsLogin = true,
        //						Data = result
        //					}
        //				};
        //			}
        //			catch (Exception ex)
        //			{
        //				log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("押分查詢失敗，錯誤訊息: {0}", ex.Message);

        //				return null;
        //			}
        //			finally
        //			{

        //			}
        //		}

        //		/// <summary>
        //		/// 網咖活動-判斷權限及領取獎勵
        //		/// </summary>
        //		/// <param name="input"></param>
        //		/// <returns>dynamic</returns>
        //		[AcceptVerbs("Post")]
        //		[AjaxOnly]
        //		public dynamic PlayerGetColorEgg(ActionCyberCafeInputModel input)
        //		{
        //			try
        //			{
        //				ActionCyberCafePlayerGetColorEggResultModel result = new ActionCyberCafePlayerGetColorEggResultModel();

        //				DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

        //				string UserIP = HttpContext.Current.Request.UserHostAddress;

        //				int Which = Convert.ToInt32(HttpContext.Current.Request.Form["Which"]);

        //				//第一步驟先判斷使用者端的IP是否為允許IP
        //#if(!true)
        //				if (string.IsNullOrEmpty(UserIP) || string.IsNullOrWhiteSpace(UserIP))
        //#else
        //				if (string.IsNullOrEmpty(UserIP) || string.IsNullOrWhiteSpace(UserIP) || ActionCyberCafeEntity.ActionCyberCafeCheckIP(UserIP) == 0)
        //#endif
        //				{
        //					return new
        //					{
        //						Result = new
        //						{
        //							Data = new ActionCyberCafePlayerGetColorEggResultModel()
        //							{
        //								ResultCode = 80,
        //								ResultCodeMsg = SelectMessage(80)
        //							}
        //						}
        //					};
        //				}

        //				//第二步驟再判斷使用者是否為登入的狀態
        //				if (context.Session.MemberID <= 0)
        //				{
        //					return new
        //					{
        //						Result = new
        //						{
        //							Data = new ActionCyberCafePlayerGetColorEggResultModel()
        //							{
        //								ResultCode = 81,
        //								ResultCodeMsg = SelectMessage(81)
        //							}
        //						}
        //					};
        //				}

        //				if (Which == 3 && context.Session.VIP_Level < 1)
        //				{
        //					return new
        //					{
        //						Result = new
        //						{
        //							Data = new ActionCyberCafePlayerGetColorEggResultModel()
        //							{
        //								ResultCode = 2,
        //								ResultCodeMsg = SelectMessage(2)
        //							}
        //						}
        //					};
        //				}

        //				//最後再帶入參數去取得回傳狀態碼及訊息
        //				input.MemberID = context.Session.MemberID;
        //				//要領取哪一顆彩蛋
        //				input.Which = Which;

        //				int ItemID = (input.Which == 1 ? 2000012 : (input.Which == 2 ? 2000013 : 2000014));

        //				string Msg = (input.Which == 1 ? "一般" : (input.Which == 2 ? "黃金" : "鑽石"));

        //				result = ActionCyberCafeEntity.ActionCyberCafePlayerGetColorEgg(input);

        //				if (result.ResultCode == 1)
        //				{
        //					WebServices.Present.Present wspp = new WebServices.Present.Present();
        //					WebServices.Present.Presentreturn Presentreturn = (wspp.SendtoGiftMarketwithCondition("", ItemID, input.MemberID, 1, "網咖活動", 3, UserIP, 138, ItemID.ToString(), 1, 0, 1)).FirstOrDefault();

        //					log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("跑了WebServices.Present.Present狀態: {0}", Presentreturn.Result);

        //					if (Presentreturn.Result != 1)
        //					{
        //						result.ResultCode = 0;
        //						result.ResultCodeMsg = Presentreturn.ResultMsg;
        //					}
        //					else
        //					{
        //						result.ResultCodeMsg = string.Format(SelectMessage(1), Msg);
        //					}
        //				}
        //				else
        //				{
        //					result.ResultCodeMsg = result.ResultCodeMsg;
        //				}

        //				//回傳參數
        //				return new
        //				{
        //					Result = new
        //					{
        //						Data = result
        //					}
        //				};
        //			}
        //			catch (Exception ex)
        //			{
        //				log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("領取獎勵失敗，錯誤訊息: {0}", ex.Message);

        //				return new
        //				{
        //					Result = new
        //					{
        //						Data = new ActionCyberCafePlayerGetColorEggResultModel()
        //						{
        //							ResultCode = 99,
        //							ResultCodeMsg = SelectMessage(99)
        //						}
        //					}
        //				};
        //			}
        //			finally
        //			{

        //			}
        //		}

        //		/// <summary>
        //		/// 選擇訊息
        //		/// </summary>
        //		/// <param name="_ResultCode"></param>
        //		/// <returns>string</returns>
        //		private string SelectMessage(int _ResultCode)
        //		{
        //			string Msg = "";

        //			switch (_ResultCode)
        //			{
        //				case 0:
        //					Msg = "";
        //					break;
        //				case 1:
        //					Msg = "恭喜您獲得「{0}彩蛋」一顆，請至遊戲中《寶箱》領取。";
        //					break;
        //				case 2:
        //					Msg = "【鑽石彩蛋】需為普卡會員以上才可以領取。";
        //					break;
        //				case 3:
        //					Msg = "";
        //					break;
        //				case 4:
        //					Msg = "";
        //					break;
        //				case 5:
        //					Msg = "";
        //					break;
        //				case 6:
        //					Msg = "";
        //					break;
        //				case 7:
        //					Msg = "";
        //					break;
        //				case 8:
        //					Msg = "";
        //					break;
        //				case 9:
        //					Msg = "";
        //					break;
        //				case 10:
        //					Msg = "";
        //					break;
        //				case 80:
        //					Msg = "使用者IP不在網咖清單內！";
        //					break;
        //				case 81:
        //					Msg = "使用者未登入！";
        //					break;
        //				case 99:
        //					Msg = "操作發生錯誤，請聯絡客服！";
        //					break;
        //				default:
        //					Msg = "";
        //					break;
        //			}

        //			return Msg;
        //		}
        #endregion

        #region 七月份大型行銷活動
        /// <summary>
        /// 取得現金大獎中獎清單
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [AcceptVerbs("Post")]
        public System.Net.Http.HttpResponseMessage GetCashAwardList(ActionChargePumpInputModel input)
        {
            try
            {
                string Platform = HttpContext.Current.Request.Form["Platform"];

                DataContext context = new DataContext(Platform);

                //string EventID = HttpContext.Current.Request.Form["EventID"];

                //int PageSize = int.Parse(HttpContext.Current.Request.Form["PageSize"]);

                //int PageIndex = int.Parse(HttpContext.Current.Request.Form["PageIndex"]);

                List<ActionChargePumpResultModel1> list = new List<ActionChargePumpResultModel1>();

                SqlParameter[] objParam =
			    {
				    new SqlParameter("@EventID", "E20130718004"),
					new SqlParameter("@GiftType", "42"),
					new SqlParameter("@PageSize", 1000000),
					new SqlParameter("@PageIndex", 1),
					new SqlParameter("@TotalRecords", SqlDbType.Int)
			    };

                objParam[4].Direction = ParameterDirection.Output;

                DataTable result = SqlHelper.ExecuteDataset
                            (
                                WebConfig.ConnectionString,
                                CommandType.StoredProcedure,
                                "NSP_GameWeb_R_MemberGetCashBarCoin_Log_List",
                                objParam
                            ).Tables[0];

                foreach (DataRow row in result.Rows)
                {
                    ActionChargePumpResultModel1 o = new ActionChargePumpResultModel1();

                    o.Name = Convert.ToString(row["NickName"]);
                    o.Date = Convert.ToDateTime(row["CreateDate"]).ToString("yyyy/MM/dd");
                    o.Money = Convert.ToInt32(row["ItemValue"]);

                    list.Add(o);
                }
                JavaScriptSerializer jss = new JavaScriptSerializer();
                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = new
                        {
                            Data = list.ToArray()
                        }
                    }))
                };
                //回傳參數
                return response;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("取得現金大獎中獎清單發生了錯誤: {0}", ex.Message);
                JavaScriptSerializer jss = new JavaScriptSerializer();
                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                        {
                            Result = new
                            {
                                Data = ""
                            }
                        }
                    ))
                };
                return response;
                //return new
                //{
                //    Result = new
                //    {
                //        Data = ""
                //    }
                //};
            }
        }

        /// <summary>
        /// 取得百家、骰寶前10名清單
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic GetBefore10List(ActionChargePumpInputModel input)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

            Dictionary<string, object> objDict = new Dictionary<string, object>();

            List<ActionChargePumpResultModel2> list2 = new List<ActionChargePumpResultModel2>();

            List<ActionChargePumpResultModel2> list3 = new List<ActionChargePumpResultModel2>();

            input.EventID = HttpContext.Current.Request.Form["EventID"];
            input.PageIndex = ((HttpContext.Current.Request.Form["PageIndex"] == "" || HttpContext.Current.Request.Form["PageIndex"] == null) ? 1 : Convert.ToInt32(HttpContext.Current.Request.Form["PageIndex"]));
            input.PageSize = ((HttpContext.Current.Request.Form["PageSize"] == "" || HttpContext.Current.Request.Form["PageSize"] == null) ? 100 : Convert.ToInt32(HttpContext.Current.Request.Form["PageSize"]));
            input.RankType = ((HttpContext.Current.Request.Form["RankType"] == "" || HttpContext.Current.Request.Form["RankType"] == null) ? 5 : Convert.ToInt32(HttpContext.Current.Request.Form["RankType"]));

            SqlParameter[] param =
				{					
					new SqlParameter("@EventID",input.EventID),
					new SqlParameter("@RankType",input.RankType),
					new SqlParameter("@PageSize", input.PageSize),
					new SqlParameter("@PageIndex", input.PageIndex),
					new SqlParameter("@TotalRecords", SqlDbType.Int),
					new SqlParameter("@ResultCode", SqlDbType.SmallInt),
					new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
				};

            param[4].Direction = ParameterDirection.Output;
            param[5].Direction = ParameterDirection.Output;
            param[6].Direction = ParameterDirection.Output;

            DataSet result = SqlHelper.ExecuteDataset
                        (
                            WebConfig.ConnectionString,
                            CommandType.StoredProcedure,
                            "NSP_GameWeb_R_RankList_NewYearActivity",
                            param
                        );

            foreach (DataRow objRow in result.Tables[0].Rows)
            {
                ActionChargePumpResultModel2 o = new ActionChargePumpResultModel2();

                o.RankNo = Convert.ToInt32(objRow["RankNo"]);
                o.NickName = Convert.ToString(objRow["NickName"]);
                o.RankValue = Convert.ToDecimal(objRow["RankValue"]);

                list2.Add(o);
            }

            objDict.Add("Data1", list2);

            foreach (DataRow objRow in result.Tables[1].Rows)
            {
                ActionChargePumpResultModel2 o = new ActionChargePumpResultModel2();

                o.RankNo = Convert.ToInt32(objRow["RankNo"]);
                o.NickName = Convert.ToString(objRow["NickName"]);
                o.RankValue = Convert.ToDecimal(objRow["RankValue"]);

                list3.Add(o);
            }

            objDict.Add("Data2", list3);

            //回傳參數
            return new
            {
                Result = new
                {
                    ResultCode = int.Parse(param[5].Value.ToString()),
                    ResultData = objDict
                }
            };
        }

        /// <summary>
        /// 取得神秘加碼活動中會員資料
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic GetMemberActivityData(ActionChargePumpInputModel input)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

            DateTime dt = DateTime.Now;

            string strDT = dt.ToString("yyyy/MM/dd HH:mm");

            ActionChargePumpResultModel3 o = new ActionChargePumpResultModel3();

            SqlParameter[] param =
				{					
					new SqlParameter("@MemberID", context.Session.MemberID)
				};

            DataTable result = SqlHelper.ExecuteDataset
                        (
                            WebConfig.ConnectionString,
                            CommandType.StoredProcedure,
                            "Game_Activity.dbo.NSP_GameWeb_E20130718_VegasResult",
                            param
                        ).Tables[0];

            foreach (DataRow dr in result.Rows)
            {
                o.GoldCoin = Convert.ToInt32(dr["Coin_Total"]);
                o.VIP_Level = Convert.ToInt32(dr["VIP_Level"]);
                o.LuckyPoint = Convert.ToInt32(dr["LuckyVegas"]);
                break;
            }

            //回傳參數
            return new
            {
                Result = new
                {
                    MemberID = context.Session.MemberID,
                    DateTime = strDT,
                    IsLogin = context.Session.IsLogin,
                    Data = o
                }
            };
        }

        /// <summary>
        /// 取得百家、骰寶前10名清單網頁流程控制
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic GetBefore10ListCompetence()
        {
            try
            {
                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                List<ActionChargePumpResultModel4> list = new List<ActionChargePumpResultModel4>();

                int EventGroupID = ((HttpContext.Current.Request.Form["EventGroupID"] == "" || HttpContext.Current.Request.Form["EventGroupID"] == null) ? 1 : Convert.ToInt32(HttpContext.Current.Request.Form["EventGroupID"]));

                SqlParameter[] param =
				{					
					new SqlParameter("@EventGroupID", EventGroupID),
					new SqlParameter("@ResultEventID", SqlDbType.VarChar,20),
					new SqlParameter("@ResultCode", SqlDbType.SmallInt),
					new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
				};

                param[1].Direction = ParameterDirection.Output;
                param[2].Direction = ParameterDirection.Output;
                param[3].Direction = ParameterDirection.Output;

                DataTable result = SqlHelper.ExecuteDataset
                            (
                                WebConfig.ConnectionString,
                                CommandType.StoredProcedure,
                                "NSP_GameWeb_S_EventInfoList",
                                param
                            ).Tables[0];

                foreach (DataRow objRow in result.Rows)
                {
                    ActionChargePumpResultModel4 o = new ActionChargePumpResultModel4();

                    o.EventID = Convert.ToString(objRow["EventID"]);
                    o.EventGroupID = Convert.ToInt32(objRow["EventGroupID"]);

                    list.Add(o);
                }

                //回傳參數
                return new
                {
                    Result = new
                    {
                        ResultEventID = param[1].Value.ToString(),
                        ResultData = list
                    }
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    ErrMsg = ex.Message
                };
            }
        }
        #endregion

        #region 08/22 十點半勝分過關榜
        /// <summary>
        /// 十點半勝分過關榜
        /// </summary>
        /// <param name="Platform"></param>
        /// <param name="Type"></param>
        /// <param name="Kind"></param>
        /// <param name="PageSize"></param>
        /// <param name="PageIndex"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public System.Net.Http.HttpResponseMessage GetTenPointHalf(string Platform, Nullable<int> Type, Nullable<int> Kind, Nullable<int> PageSize, Nullable<int> PageIndex)
        {
            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : "");

                // 活動頁/大廳(0/1)
                Type = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Type"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["Type"] as string) : -1);

                // 當莊勝分榜/過關彩金榜(0/1)
                Kind = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Kind"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["Kind"] as string) : -1);

                // 單頁筆數
                PageSize = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageSize"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageSize"] as string) : 1000);

                // 頁數
                PageIndex = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageIndex"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageIndex"] as string) : 1);

                DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);

                Dictionary<string, object> result = new Dictionary<string, object>();

                List<GetTenPointHalfReturnStruct> list = new List<GetTenPointHalfReturnStruct>();

                if (Kind == 1)
                {
                    SqlParameter[] param =
					{					
						new SqlParameter("@PageSize", PageSize),
						new SqlParameter("@PageIndex", PageIndex),
						new SqlParameter("@TotalCNT", SqlDbType.Int),
						new SqlParameter("@TotalPoint", SqlDbType.Int),
						new SqlParameter("@TotalRecords", SqlDbType.Int)
					};

                    param[2].Direction = ParameterDirection.Output;
                    param[3].Direction = ParameterDirection.Output;
                    param[4].Direction = ParameterDirection.Output;

                    DataTable dt = SqlHelper.ExecuteDataset
                                (
                                    WebConfig.ConnectionString,
                                    CommandType.StoredProcedure,
                                    "Game_Activity.dbo.NSP_GameWeb_E20130822001_5Stage_Result",
                                    param
                                ).Tables[0];

                    foreach (DataRow dr in dt.Rows)
                    {
                        GetTenPointHalfReturnStruct o = new GetTenPointHalfReturnStruct();

                        o.RankNo = Convert.ToInt32(dr["SerialNo"]);
                        o.NickName = Convert.ToString(dr["MemberName"]);
                        o.RankTimes = Convert.ToDecimal(dr["TotalCNT"]);
                        o.RankValue = Convert.ToDecimal(dr["TotalPoint"]);

                        list.Add(o);
                    }
                }
                else if (Kind == 0)
                {
                    SqlParameter[] param =
					{					
						new SqlParameter("@PageSize", PageSize),
						new SqlParameter("@PageIndex", PageIndex),
						new SqlParameter("@TotalCNT", SqlDbType.Int),
						new SqlParameter("@TotalPoint", SqlDbType.Int),
						new SqlParameter("@TotalRecords", SqlDbType.Int)
					};

                    param[2].Direction = ParameterDirection.Output;
                    param[3].Direction = ParameterDirection.Output;
                    param[4].Direction = ParameterDirection.Output;

                    DataTable dt = SqlHelper.ExecuteDataset
                                (
                                    WebConfig.ConnectionString,
                                    CommandType.StoredProcedure,
                                    "Game_Activity.dbo.NSP_GameWeb_E20130822001_Banker_Result",
                                    param
                                ).Tables[0];

                    foreach (DataRow dr in dt.Rows)
                    {
                        GetTenPointHalfReturnStruct o = new GetTenPointHalfReturnStruct();

                        o.RankNo = Convert.ToInt32(dr["SerialNo"]);
                        o.NickName = Convert.ToString(dr["MemberName"]);
                        o.RankTimes = 0;
                        o.RankValue = Convert.ToDecimal(dr["TotalPoint"]);

                        list.Add(o);
                    }
                }

                result.Add("Data", list);

                if (Type == 1)
                {
                    if (!context.Session.IsLogin)
                    {
                        result.Add("CumulativeWinPoints", 0);
                        result.Add("CumulativeNumber", 0);
                    }
                    else
                    {
                        SqlParameter[] param =
						{					
							new SqlParameter("@MemberID", context.Session.MemberID),
							new SqlParameter("@TotalCNT", SqlDbType.Int),
							new SqlParameter("@TotalPoint", SqlDbType.Int)
						};

                        param[1].Direction = ParameterDirection.Output;
                        param[2].Direction = ParameterDirection.Output;

                        SqlHelper.ExecuteNonQuery
                        (
                            WebConfig.ConnectionString,
                            CommandType.StoredProcedure,
                            "Game_Activity.dbo.NSP_GameWeb_E20130822001_Member_Result",
                            param
                        );

                        result.Add("CumulativeWinPoints", Convert.ToDecimal(param[2].Value.ToString()));
                        result.Add("CumulativeNumber", Convert.ToInt32(param[1].Value.ToString()));
                    }
                }
                JavaScriptSerializer jss = new JavaScriptSerializer();
                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = result
                    }))
                };
                //回傳參數
                return response;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("十點半勝分過關榜，錯誤訊息：{0}", ex.Message);
                JavaScriptSerializer jss = new JavaScriptSerializer();
                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };
                return response;
            }

        }
        #endregion

        #region 9/5號活動上線
        /// <summary>
        /// 【2013週年慶活動】電子贏分超達人積分賽-取得電子區達人積分榜
        /// </summary>
        /// <param name="Platform"></param>
        /// <param name="EventID"></param>
        /// <param name="RankType"></param>
        /// <param name="PageSize"></param>
        /// <param name="PageIndex"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public System.Net.Http.HttpResponseMessage GetElectronicsWinPointsDarenPointsRace(string Platform, string EventID, Nullable<int> Type, Nullable<int> RankType, Nullable<int> PageSize, Nullable<int> PageIndex)
        {
            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Platform"] as string) ? (HttpContext.Current.Request.QueryString["Platform"] as string) : Platform));

                // 活動編號
                EventID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["EventID"] as string) ? (HttpContext.Current.Request.Form["EventID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["EventID"] as string) ? (HttpContext.Current.Request.QueryString["EventID"] as string) : EventID));

                // 活動頁/大廳(0/1)
                Type = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Type"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["Type"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Type"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["Type"] as string) : -1));

                // 排行榜種類  2：電子【贏分榜】
                RankType = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["RankType"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["RankType"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["RankType"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["RankType"] as string) : 2));

                // 單頁筆數
                PageSize = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageSize"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageSize"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["PageSize"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["PageSize"] as string) : 1000));

                // 頁數
                PageIndex = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageIndex"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageIndex"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["PageIndex"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["PageIndex"] as string) : 1));

                DataContext context = new DataContext(Platform);

                Dictionary<string, object> result = new Dictionary<string, object>();

                List<GetElectronicsWinPointsDarenPointsRaceStruct> list = new List<GetElectronicsWinPointsDarenPointsRaceStruct>();

                if (Type != -1)
                {
                    SqlParameter[] param =
					{					
						new SqlParameter("@EventID", EventID),
						new SqlParameter("@RankType", RankType),
						new SqlParameter("@PageSize", PageSize),
						new SqlParameter("@PageIndex", PageIndex),
						new SqlParameter("@TotalRecords", SqlDbType.Int),
						new SqlParameter("@ResultCode", SqlDbType.SmallInt),
						new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
					};

                    param[4].Direction = ParameterDirection.Output;
                    param[5].Direction = ParameterDirection.Output;
                    param[6].Direction = ParameterDirection.Output;

                    DataTable dt = SqlHelper.ExecuteDataset
                                (
                                    WebConfig.ConnectionString,
                                    CommandType.StoredProcedure,
                                    "Game_Activity.dbo.NSP_GameWeb_E20130905001_RankList",
                                    param
                                ).Tables[0];

                    foreach (DataRow dr in dt.Rows)
                    {
                        GetElectronicsWinPointsDarenPointsRaceStruct o = new GetElectronicsWinPointsDarenPointsRaceStruct();

                        //o.RowNo = Convert.ToInt32(dr["RowNo"]);
                        //o.EventID = Convert.ToString(dr["EventID"]);
                        //o.EventNo = Convert.ToInt32(dr["EventNo"]);
                        //o.RankType = Convert.ToInt32(dr["RankType"]);
                        //o.MemberID = Convert.ToInt32(dr["MemberID"]);
                        o.NickName = Convert.ToString(dr["NickName"]);
                        //o.RankValue = Convert.ToInt32(dr["RankValue"]);
                        o.RankNo = Convert.ToInt32(dr["RankNo"]);
                        o.TotalScore = Convert.ToInt32(dr["TotalScore"]);
                        o.GetJP = Convert.ToInt32(dr["GetJP"]);

                        list.Add(o);
                    }
                }

                result.Add("Data", list);

                if (Type == 1)
                {
                    if (!context.Session.IsLogin)
                    {
                        //result.Add("RankValue", 0);
                        result.Add("TotalScoreByPersonal", -1);
                        result.Add("GetJPByPersonal", -1);
                    }
                    else
                    {
                        SqlParameter[] param2 =
						{					
							new SqlParameter("@MemberID", context.Session.MemberID),
							new SqlParameter("@EventID", EventID),
							new SqlParameter("@RankType", RankType),
							new SqlParameter("@ResultCode", SqlDbType.SmallInt),
							new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
						};

                        param2[3].Direction = ParameterDirection.Output;
                        param2[4].Direction = ParameterDirection.Output;

                        DataTable dt2 = SqlHelper.ExecuteDataset
                                    (
                                        WebConfig.ConnectionString,
                                        CommandType.StoredProcedure,
                                        "Game_Activity.dbo.NSP_GameWeb_E20130905001_RankValue_GetByID",
                                        param2
                                    ).Tables[0];

                        foreach (DataRow dr in dt2.Rows)
                        {
                            //result.Add("RankValue", Convert.ToDecimal(dr["RankValue"]));
                            result.Add("TotalScoreByPersonal", Convert.ToInt32(dr["TotalScore"]));
                            result.Add("GetJPByPersonal", Convert.ToInt32(dr["GetJP"]));

                            break;
                        }
                    }
                }

                JavaScriptSerializer jss = new JavaScriptSerializer();

                jss.MaxJsonLength = int.MaxValue;

                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = result
                    }))
                };

                // 回傳參數
                return response;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("電子贏分超達人積分賽，錯誤訊息：{0}", ex.Message);

                JavaScriptSerializer jss = new JavaScriptSerializer();

                jss.MaxJsonLength = int.MaxValue;

                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }
        }

        /// <summary>
        /// 【2013週年慶活動】電子贏分超達人積分賽-取得本週個人總積分、獎金
        /// </summary>
        /// <param name="Platform"></param>
        /// <param name="EventID"></param>
        /// <param name="RankType"></param>
        /// <returns></returns>
        //[AcceptVerbs("Post", "Get")]
        //public System.Net.Http.HttpResponseMessage GetPersonalElectronicsWinPoints(string Platform, string EventID, Nullable<int> RankType)
        //{
        //	try
        //	{
        //		// 環境別
        //		Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : Platform);

        //		// 活動編號
        //		EventID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["EventID"] as string) ? (HttpContext.Current.Request.Form["EventID"] as string) : EventID);

        //		// 排行榜種類  2：電子【贏分榜】
        //		RankType = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["RankType"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["RankType"] as string) : 2);

        //		DataContext context = new DataContext(Platform);

        //		Dictionary<string, object> result = new Dictionary<string, object>();

        //		if (!context.Session.IsLogin)
        //		{
        //			result.Add("RankValue", 0);
        //			result.Add("TotalScore", 0);
        //			result.Add("GetJP", 0);
        //		}
        //		else
        //		{
        //			SqlParameter[] param =
        //			{					
        //				new SqlParameter("@MemberID", context.Session.MemberID),
        //				new SqlParameter("@EventID", EventID),
        //				new SqlParameter("@RankType",RankType ),
        //				new SqlParameter("@ResultCode", SqlDbType.SmallInt),
        //				new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
        //			};

        //			param[3].Direction = ParameterDirection.Output;
        //			param[4].Direction = ParameterDirection.Output;

        //			DataTable dt = SqlHelper.ExecuteDataset
        //						(
        //							WebConfig.ConnectionString,
        //							CommandType.StoredProcedure,
        //							"Game_Activity.dbo.NSP_GameWeb_E20130905001_RankValue_GetByID",
        //							param
        //						).Tables[0];

        //			foreach (DataRow dr in dt.Rows)
        //			{
        //				result.Add("RankValue", Convert.ToDecimal(dr["RankValue"]));
        //				result.Add("TotalScore", Convert.ToInt32(dr["TotalScore"]));
        //				result.Add("GetJP", Convert.ToInt32(dr["GetJP"]));

        //				break;
        //			}
        //		}

        //		JavaScriptSerializer jss = new JavaScriptSerializer();

        //		jss.MaxJsonLength = int.MaxValue;

        //		var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
        //		{
        //			Content = new System.Net.Http.StringContent(jss.Serialize(new
        //			{
        //				Result = result
        //			}))
        //		};

        //		// 回傳參數
        //		return response;
        //	}
        //	catch (Exception ex)
        //	{
        //		log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("電子贏分超達人積分賽，錯誤訊息：{0}", ex.Message);

        //		JavaScriptSerializer jss = new JavaScriptSerializer();

        //		jss.MaxJsonLength = int.MaxValue;

        //		var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
        //		{
        //			Content = new System.Net.Http.StringContent(jss.Serialize(new
        //			{
        //				Result = ex.Message
        //			}))
        //		};

        //		// 回傳參數
        //		return response;
        //	}
        //	finally
        //	{

        //	}
        //}

        /// <summary>
        /// 取得活動事件列表 / 回傳本週目前EventID
        /// </summary>
        /// <param name="EventGroupID"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic GetEventInfoListByEventGroupID(Nullable<int> EventGroupID)
        {
            try
            {
                // 活動事件群組代碼(3：【2013週年慶活動】電子贏分超達人積分賽排行榜)
                EventGroupID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["EventGroupID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["EventGroupID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["EventGroupID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["EventGroupID"] as string) : 3));

                Dictionary<string, object> result = new Dictionary<string, object>();

                List<ActionChargePumpResultModel4> list = new List<ActionChargePumpResultModel4>();

                SqlParameter[] param =
				{					
					new SqlParameter("@EventGroupID",EventGroupID ),
					new SqlParameter("@ResultEventID", SqlDbType.VarChar,20),
					new SqlParameter("@ResultCode", SqlDbType.SmallInt),
					new SqlParameter("@ResultDesc", SqlDbType.VarChar,50)
				};

                param[1].Direction = ParameterDirection.Output;
                param[2].Direction = ParameterDirection.Output;
                param[3].Direction = ParameterDirection.Output;

                DataTable dt = SqlHelper.ExecuteDataset
                            (
                                WebConfig.ConnectionString,
                                CommandType.StoredProcedure,
                                "Game_Activity.dbo.NSP_GameWeb_E20130905001_EventInfoList",
                                param
                            ).Tables[0];

                foreach (DataRow dr in dt.Rows)
                {
                    ActionChargePumpResultModel4 o = new ActionChargePumpResultModel4();

                    o.EventGroupID = Convert.ToInt32(dr["EventGroupID"]);
                    o.EventID = Convert.ToString(dr["EventID"]);

                    list.Add(o);
                }

                result.Add("Data", list);
                result.Add("ResultEventID", param[1].Value.ToString());
                result.Add("ResultCode", Convert.ToInt32(param[2].Value.ToString()));
                result.Add("ResultDesc", Convert.ToString(param[3].Value.ToString()));

                JavaScriptSerializer jss = new JavaScriptSerializer();

                jss.MaxJsonLength = int.MaxValue;

                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = result
                    }))
                };

                // 回傳參數
                return response;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("電子贏分超達人積分賽，錯誤訊息：{0}", ex.Message);

                JavaScriptSerializer jss = new JavaScriptSerializer();

                jss.MaxJsonLength = int.MaxValue;

                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }
        }
        #endregion

        #region 0822_新手包月福袋防堵機制-活動手機驗證(非轉帳手機驗證)
        /// <summary>
        /// 0822_新手包月福袋防堵機制-檢查玩家資格
        /// </summary>
        /// <param name="Platform"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic CheckPlayerQualificationsByActive(string Platform = "")
        {
            Dictionary<string, object> result = new Dictionary<string, object>();

            int Result = 0;

            string ResultMsg = string.Empty;

            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : Platform);

                DataContext context = new DataContext(Platform);

                if (!context.Session.IsLogin)
                {
                    Result = 111;
                    ResultMsg = "請登入會員!";
                }
                else
                {
                    SqlParameter[] param =
					{					
						new SqlParameter("@MemberID", context.Session.MemberID),
						new SqlParameter("@Result", SqlDbType.Int),
						new SqlParameter("@ResultMsg", SqlDbType.VarChar,50)
					};

                    param[1].Direction = ParameterDirection.Output;
                    param[2].Direction = ParameterDirection.Output;

                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "Game_Activity.dbo.NSP_GameWeb_E20130718006_Check",
                        param
                    );

                    Result = Convert.ToInt32(param[1].Value.ToString());
                    ResultMsg = param[2].Value.ToString();
                }

                result.Add("Result", Result);
                result.Add("ResultMsg", ResultMsg);

                //回傳參數
                return new
                {
                    Result = result
                };
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("活動手機驗證(非轉帳手機驗證)，檢查玩家資格發生錯誤：{0}", ex.Message);

                Result = 999;
                ResultMsg = "請登入會員!";

                //回傳參數
                return new
                {
                    Result = result
                };
            }
            finally
            {

            }
        }

        /// <summary>
        /// 0822_新手包月福袋防堵機制-發送驗證碼簡訊
        /// </summary>
        /// <param name="Platform"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic SendSMSByActive(string Platform = "", string Mobile = "")
        {
            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : Platform);

                // 手機號碼
                Mobile = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Mobile"] as string) ? (HttpContext.Current.Request.Form["Mobile"] as string) : Mobile);

                DataContext context = new DataContext(Platform);

                Dictionary<string, object> result = new Dictionary<string, object>();

                int Result = 0;

                string ResultMsg = string.Empty;

                if (!context.Session.IsLogin)
                {
                    Result = 111;
                    ResultMsg = "請登入會員!";
                }
                //else if (Mobile.Length != 10)
                //{
                //	Result = 112;
                //	ResultMsg = "手機號碼輸入錯誤!";
                //}
                else
                {
                    SqlParameter[] param =
					{					
						new SqlParameter("@MemberID", context.Session.MemberID),
						new SqlParameter("@Mobile", Mobile),
						new SqlParameter("@Result", SqlDbType.Int),
						new SqlParameter("@ResultMsg", SqlDbType.VarChar,50)
					};

                    param[2].Direction = ParameterDirection.Output;
                    param[3].Direction = ParameterDirection.Output;

                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "Game_Activity.dbo.NSP_GameWeb_E20130718006_SendSMS",
                        param
                    );

                    Result = Convert.ToInt32(param[2].Value.ToString());
                    ResultMsg = param[3].Value.ToString();
                }

                result.Add("Result", Result);
                result.Add("ResultMsg", ResultMsg);

                //回傳參數
                return new
                {
                    Result = result
                };
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("活動手機驗證(非轉帳手機驗證)，檢查玩家資格後發送簡訊發生錯誤：{0}", ex.Message);

                //回傳參數
                return new
                {
                    Result = ex.Message
                };
            }
            finally
            {

            }
        }

        /// <summary>
        /// 0822_新手包月福袋防堵機制-測試環境用，自動填入驗證碼
        /// </summary>
        [AcceptVerbs("Post", "Get")]
        public dynamic GetVerifyCodeByActive(string Platform = "")
        {
#if(!Online)
            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : Platform);

                DataContext context = new DataContext(Platform);

                if (!context.Session.IsLogin)
                {
                    return new { Result = "" };
                }

                string result = string.Empty;

                string query = "select * from Game_Activity.dbo.E20130718006_A_MemberNewBagInfo where MemberID=" + context.Session.MemberID;

                SqlConnection sc = new SqlConnection(WebConfig.ConnectionString);

                sc.Open();

                SqlCommand cmd = new SqlCommand(query, sc);

                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    result = sdr["VerifyCode"].ToString();
                    break;
                }

                sdr.Close();
                sc.Close();

                return new { Result = result };
            }
            catch (Exception ex)
            {
                return new { Result = "" };
            }
            finally
            {

            }
#else
           	return new { Result = ""};
#endif

        }

        /// <summary>
        /// 0822_新手包月福袋防堵機制-驗證碼驗證
        /// </summary>
        /// <param name="Platform"></param>
        /// <param name="VerifyCode"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic VerifyVerificationCodeByActive(string Platform = "", string VerifyCode = "")
        {
            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : Platform);

                // 驗證碼
                VerifyCode = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["VerifyCode"] as string) ? (HttpContext.Current.Request.Form["VerifyCode"] as string) : VerifyCode);

                DataContext context = new DataContext(Platform);

                Dictionary<string, object> result = new Dictionary<string, object>();

                int Result = 0;

                string ResultMsg = string.Empty;

                if (!context.Session.IsLogin)
                {
                    Result = 111;
                    ResultMsg = "請登入會員!";
                }
                else
                {
                    SqlParameter[] param =
					{					
						new SqlParameter("@MemberID", context.Session.MemberID),
						new SqlParameter("@VerifyCode", VerifyCode),
						new SqlParameter("@Result", SqlDbType.Int),
						new SqlParameter("@ResultMsg", SqlDbType.VarChar,50)
					};

                    param[2].Direction = ParameterDirection.Output;
                    param[3].Direction = ParameterDirection.Output;

                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "Game_Activity.dbo.NSP_GameWeb_E20130718006_Add",
                        param
                    );

                    Result = Convert.ToInt32(param[2].Value.ToString());
                    ResultMsg = param[3].Value.ToString();
                }

                result.Add("Result", Result);
                result.Add("ResultMsg", ResultMsg);

                //回傳參數
                return new
                {
                    Result = result
                };
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("活動手機驗證(非轉帳手機驗證)，驗證碼驗證發生錯誤：{0}", ex.Message);

                //回傳參數
                return new
                {
                    Result = ex.Message
                };
            }
            finally
            {

            }
        }

        /// <summary>
        /// 0822_新手包月福袋防堵機制-取消驗證碼驗證
        /// </summary>
        /// <param name="Platform"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic CancelVerifyVerificationCodeByActive(string Platform = "")
        {
            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : Platform);

                DataContext context = new DataContext(Platform);

                Dictionary<string, object> result = new Dictionary<string, object>();

                int Result = 0;

                string ResultMsg = string.Empty;

                if (!context.Session.IsLogin)
                {
                    Result = 111;
                    ResultMsg = "請登入會員!";
                }
                else
                {
                    SqlParameter[] param =
					{					
						new SqlParameter("@MemberID", context.Session.MemberID),
						new SqlParameter("@Result", SqlDbType.Int),
						new SqlParameter("@ResultMsg", SqlDbType.VarChar,50)
					};

                    param[1].Direction = ParameterDirection.Output;
                    param[2].Direction = ParameterDirection.Output;

                    SqlHelper.ExecuteNonQuery
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "Game_Activity.dbo.NSP_GameWeb_E20130718006_Cancel",
                        param
                    );

                    Result = Convert.ToInt32(param[1].Value.ToString());
                    ResultMsg = param[2].Value.ToString();
                }

                result.Add("Result", Result);
                result.Add("ResultMsg", ResultMsg);

                //回傳參數
                return new
                {
                    Result = result
                };
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("活動手機驗證(非轉帳手機驗證)，取消驗證碼驗證發生錯誤：{0}", ex.Message);

                //回傳參數
                return new
                {
                    Result = ex.Message
                };
            }
            finally
            {

            }
        }
        #endregion

        #region 2013/10/17 推筒子活動
        /// <summary>
        /// 2013/09/26 推筒子活動
        /// </summary>
        /// <param name="Platform"></param>
        /// <param name="EventID"></param>
        /// <param name="RankType"></param>
        /// <param name="PageSize"></param>
        /// <param name="PageIndex"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public System.Net.Http.HttpResponseMessage GetPushTheCaskActiveData(string Platform, string EventID, Nullable<int> Type, Nullable<int> RankType, Nullable<int> PageSize, Nullable<int> PageIndex)
        {
            try
            {
                // 環境別
                Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Platform"] as string) ? (HttpContext.Current.Request.QueryString["Platform"] as string) : Platform));

                // 活動編號
                //EventID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["EventID"] as string) ? (HttpContext.Current.Request.Form["EventID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["EventID"] as string) ? (HttpContext.Current.Request.QueryString["EventID"] as string) : EventID));

                // 活動頁/大廳(0/1)
                Type = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Type"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["Type"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Type"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["Type"] as string) : -1));

                // 排行榜種類 1 : 當莊勝分榜 / 2 : 白皮彩金榜
                RankType = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["RankType"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["RankType"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["RankType"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["RankType"] as string) : -1));

                // 單頁筆數
                PageSize = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageSize"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageSize"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["PageSize"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["PageSize"] as string) : 1000));

                // 頁數
                PageIndex = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageIndex"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageIndex"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["PageIndex"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["PageIndex"] as string) : 1));

                DataContext context = new DataContext(Platform);

                Dictionary<string, object> result = new Dictionary<string, object>();

                List<GetTenPointHalfReturnStruct> list = new List<GetTenPointHalfReturnStruct>();

                DataTable dt;

                //string CacheName = string.Format("GetPushTheCaskActiveData_{0}_{1}_{2}_{3}", Platform, EventID, Type, RankType);

                //Dictionary<string, object> resultCache = HttpContext.Current.Cache[CacheName] as Dictionary<string, object>;

                //if (resultCache != null)
                //{
                //	result = resultCache;

                //	goto returnCache;
                //}

                if (Type != -1)
                {
                    if (Type == 1)
                    {
                        SqlParameter[] param =
						{					
							new SqlParameter("@PageSize", PageSize),
							new SqlParameter("@PageIndex", PageIndex)
						};

                        dt = new DataTable();

                        //dt = SqlHelper.ExecuteDataset
                        //		   (
                        //			   WebConfig.ConnectionString,
                        //			   CommandType.StoredProcedure,
                        //			   "",
                        //			   param
                        //		   ).Tables[0];

                        if (RankType == 1)
                        {
                            dt = SqlHelper.ExecuteDataset
                            (
                                WebConfig.ConnectionString,
                                CommandType.StoredProcedure,
                                "Game_Activity.dbo.NSP_GameWeb_E20131017001_Banker_Result",
                                param
                            ).Tables[0];

                            foreach (DataRow dr in dt.Rows)
                            {
                                GetTenPointHalfReturnStruct o = new GetTenPointHalfReturnStruct();

                                o.RankNo = Convert.ToInt32(dr["SerialNo"]);
                                o.NickName = Convert.ToString(dr["MemberName"]);
                                o.RankTimes = 0;
                                o.RankValue = Convert.ToInt32(dr["TotalPoint"]);

                                list.Add(o);
                            }

                            //for (int i = 1; i <= 30; i++)
                            //{
                            //	GetTenPointHalfReturnStruct o = new GetTenPointHalfReturnStruct();

                            //	o.RankNo = i;
                            //	o.NickName = "或許這是假資料" + i;
                            //	o.RankTimes = 0;
                            //	o.RankValue = (10000 * (501 - i));

                            //	list.Add(o);
                            //}
                        }
                        else if (RankType == 2)
                        {
                            dt = SqlHelper.ExecuteDataset
                                (
                                    WebConfig.ConnectionString,
                                    CommandType.StoredProcedure,
                                    "Game_Activity.dbo.NSP_GameWeb_E20131017001_PairWB_Result",
                                    param
                                ).Tables[0];

                            foreach (DataRow dr in dt.Rows)
                            {
                                GetTenPointHalfReturnStruct o = new GetTenPointHalfReturnStruct();

                                o.RankNo = Convert.ToInt32(dr["SerialNo"]);
                                o.NickName = Convert.ToString(dr["MemberName"]);
                                o.RankTimes = Convert.ToInt32(dr["TotalCNT"]);
                                o.RankValue = Convert.ToInt32(dr["TotalPoint"]);

                                list.Add(o);
                            }

                            //for (int i = 1; i <= 1000; i++)
                            //{
                            //	GetTenPointHalfReturnStruct o = new GetTenPointHalfReturnStruct();

                            //	o.RankNo = i;
                            //	o.NickName = "或許這是假資料" + i;
                            //	o.RankTimes = (1001 - i);
                            //	o.RankValue = (10000 * (1001 - i));

                            //	list.Add(o);
                            //}
                        }

                        result.Add("Data", list);
                    }
                    else
                    {
                        List<GetPushTheCaskActiveDataStruct> list2 = new List<GetPushTheCaskActiveDataStruct>();

                        SqlParameter[] param =
						{					
							new SqlParameter("@PageSize", PageSize),
							new SqlParameter("@PageIndex", PageIndex),
						};

                        dt = new DataTable();

                        if (RankType == 1)
                        {
                            dt = SqlHelper.ExecuteDataset
                                (
                                    WebConfig.ConnectionString,
                                    CommandType.StoredProcedure,
                                    "Game_Activity.dbo.NSP_GameWeb_E20131017001_Banker_Result",
                                    param
                                ).Tables[0];

                            foreach (DataRow dr in dt.Rows)
                            {
                                GetPushTheCaskActiveDataStruct o = new GetPushTheCaskActiveDataStruct();

                                o.RankNo = Convert.ToInt32(dr["SerialNo"]);
                                o.NickName = Convert.ToString(dr["MemberName"]);
                                o.RankTimes = 0;
                                o.RankValue = Convert.ToInt32(dr["TotalPoint"]);

                                //o.RankNo2 = Convert.ToInt32(dr["SerialNo"]);
                                //o.NickName2 = Convert.ToString(dr["MemberName"]);
                                //o.RankTimes2 = 0;
                                //o.RankValue2 = Convert.ToInt32(dr["TotalPoint"]);

                                list2.Add(o);
                            }

                            //for (int i = 0; i < dt.Rows.Count; i += 2)
                            //{

                            //	GetPushTheCaskActiveDataStruct o = new GetPushTheCaskActiveDataStruct();

                            //	if (dt.Rows[i] != null)
                            //	{
                            //		o.RankNo = Convert.ToInt32(dt.Rows[i]["SerialNo"]);
                            //		o.NickName = Convert.ToString(dt.Rows[i]["MemberName"]);
                            //		o.RankTimes = 0;
                            //		o.RankValue = Convert.ToInt32(dt.Rows[i]["TotalPoint"]);
                            //	}
                            //	if (dt.Rows[i + 1] != null)
                            //	{
                            //		o.RankNo2 = Convert.ToInt32(dt.Rows[i + 1]["SerialNo"]);
                            //		o.NickName2 = Convert.ToString(dt.Rows[i + 1]["MemberName"]);
                            //		o.RankTimes2 = 0;
                            //		o.RankValue2 = Convert.ToInt32(dt.Rows[i + 1]["TotalPoint"]);
                            //	}

                            //	list2.Add(o);
                            //}

                            //for (int i = 1; i <= 30; i += 2)
                            //{

                            //	GetPushTheCaskActiveDataStruct o = new GetPushTheCaskActiveDataStruct();

                            //	o.RankNo = i;
                            //	o.NickName = "或許這是假資料" + i;
                            //	o.RankTimes = 0;
                            //	o.RankValue = (10000 * (501 - i));

                            //	o.RankNo2 = i + 1;
                            //	o.NickName2 = "或許這是假資料" + (i + 1);
                            //	o.RankTimes2 = 0;
                            //	o.RankValue2 = (10000 * (501 - (i + 1)));

                            //	list2.Add(o);
                            //}
                        }
                        else if (RankType == 2)
                        {
                            dt = SqlHelper.ExecuteDataset
                                (
                                    WebConfig.ConnectionString,
                                    CommandType.StoredProcedure,
                                    "Game_Activity.dbo.NSP_GameWeb_E20131017001_PairWB_Result",
                                    param
                                ).Tables[0];

                            foreach (DataRow dr in dt.Rows)
                            {
                                GetPushTheCaskActiveDataStruct o = new GetPushTheCaskActiveDataStruct();

                                o.RankNo = Convert.ToInt32(dr["SerialNo"]);
                                o.NickName = Convert.ToString(dr["MemberName"]);
                                o.RankTimes = Convert.ToInt32(dr["TotalCNT"]);
                                o.RankValue = Convert.ToInt32(dr["TotalPoint"]);

                                //o.RankNo2 = Convert.ToInt32(dr["SerialNo"]);
                                //o.NickName2 = Convert.ToString(dr["MemberName"]);
                                //o.RankTimes2 = Convert.ToInt32(dr["TotalCNT"]);
                                //o.RankValue2 = Convert.ToInt32(dr["TotalPoint"]);

                                list2.Add(o);
                            }

                            //for (int i = 0; i < dt.Rows.Count; i += 2)
                            //{
                            //	GetPushTheCaskActiveDataStruct o = new GetPushTheCaskActiveDataStruct();
                            //	if (dt.Rows[i] != null)
                            //	{
                            //		o.RankNo = Convert.ToInt32(dt.Rows[i]["SerialNo"]);
                            //		o.NickName = Convert.ToString(dt.Rows[i]["MemberName"]);
                            //		o.RankTimes = Convert.ToInt32(dt.Rows[i]["TotalCNT"]);
                            //		o.RankValue = Convert.ToInt32(dt.Rows[i]["TotalPoint"]);
                            //	}
                            //	if (dt.Rows[i + 1] != null)
                            //	{
                            //		o.RankNo2 = Convert.ToInt32(dt.Rows[i + 1]["SerialNo"]);
                            //		o.NickName2 = Convert.ToString(dt.Rows[i + 1]["MemberName"]);
                            //		o.RankTimes2 = Convert.ToInt32(dt.Rows[i + 1]["TotalCNT"]);
                            //		o.RankValue2 = Convert.ToInt32(dt.Rows[i + 1]["TotalPoint"]);
                            //	}

                            //	list2.Add(o);
                            //}

                            //for (int i = 1; i <= 1000; i += 2)
                            //{

                            //	GetPushTheCaskActiveDataStruct o = new GetPushTheCaskActiveDataStruct();

                            //	o.RankNo = i;
                            //	o.NickName = "或許這是假資料" + i;
                            //	o.RankTimes = 1001 - i;
                            //	o.RankValue = (10000 * (1001 - i));

                            //	o.RankNo2 = i + 1;
                            //	o.NickName2 = "或許這是假資料" + (i + 1);
                            //	o.RankTimes2 = 501 - (i + 1);
                            //	o.RankValue2 = (10000 * (501 - (i + 1)));

                            //	list2.Add(o);
                            //}
                        }
                        result.Add("Data", list2);
                    }
                }

                if (Type == 1)
                {
                    if (!context.Session.IsLogin)
                    {
                        result.Add("RankValueByPersonal", -1);
                        result.Add("RankTimesByPersonal", -1);
                    }
                    else
                    {
                        SqlParameter[] param2 =
						{					
							new SqlParameter("@MemberID", context.Session.MemberID),
							new SqlParameter("@TotalCNT", SqlDbType.Int),
							new SqlParameter("@TotalPoint", SqlDbType.Int),
						};

                        param2[1].Direction = ParameterDirection.Output;
                        param2[2].Direction = ParameterDirection.Output;

                        SqlHelper.ExecuteNonQuery
                        (
                            WebConfig.ConnectionString,
                            CommandType.StoredProcedure,
                            "Game_Activity.dbo.NSP_GameWeb_E20131017001_Member_Result",
                            param2
                        );

                        result.Add("RankValueByPersonal", Convert.ToInt32(param2[2].Value.ToString()));
                        result.Add("RankTimesByPersonal", Convert.ToInt32(param2[1].Value.ToString()));

                        //result.Add("RankValueByPersonal", 8888888);
                        //result.Add("RankTimesByPersonal", 2222);
                    }
                }

                //HttpContext.Current.Cache.Insert
                //(
                //	CacheName,
                //	result,
                //	null,
                //	DateTime.Now.AddMinutes(1),
                //	System.Web.Caching.Cache.NoSlidingExpiration,
                //	System.Web.Caching.CacheItemPriority.Normal,
                //	null
                //);

                //returnCache:

                JavaScriptSerializer jss = new JavaScriptSerializer();

                jss.MaxJsonLength = int.MaxValue;

                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = result
                    }))
                };

                // 回傳參數
                return response;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(HotActiveController)).DebugFormat("2013/09/26 推筒子活動，錯誤訊息：{0}", ex.Message);

                JavaScriptSerializer jss = new JavaScriptSerializer();

                jss.MaxJsonLength = int.MaxValue;

                var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }
        }
        #endregion

        #region 2013/10/03 餐廳賓果活動
        /// <summary>
        /// 餐廳賓果活動頁-查詢歷史紀錄
        /// </summary>
        /// <param name="Platform"></param>
        /// <param name="Type"></param>
        /// <param name="YearMonth"></param>
        /// <param name="MachineName"></param>
        /// <param name="GameID"></param>
        /// <param name="GroupID"></param>
        /// <param name="TypeID"></param>
        /// <param name="PageSize"></param>
        /// <param name="PageIndex"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic GetRestaurantBingoGameRecord(string Platform, string Type, string YearMonth, string MachineName, Nullable<int> GameID, Nullable<int> GroupID, Nullable<int> TypeID, Nullable<int> PageSize, Nullable<int> PageIndex)
        {
            Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Platform"] as string) ? (HttpContext.Current.Request.QueryString["Platform"] as string) : Platform));

            Type = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Type"] as string) ? (HttpContext.Current.Request.Form["Type"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Type"] as string) ? (HttpContext.Current.Request.QueryString["Type"] as string) : Type));

            YearMonth = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["YearMonth"] as string) ? (HttpContext.Current.Request.Form["YearMonth"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["YearMonth"] as string) ? (HttpContext.Current.Request.QueryString["YearMonth"] as string) : YearMonth));

            MachineName = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["MachineName"] as string) ? (HttpContext.Current.Request.Form["MachineName"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["MachineName"] as string) ? (HttpContext.Current.Request.QueryString["MachineName"] as string) : MachineName));

            GameID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["GameID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["GameID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["GameID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["GameID"] as string) : 1036));

            GroupID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["GroupID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["GroupID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["GroupID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["GroupID"] as string) : 4));

            TypeID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["TypeID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["TypeID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["TypeID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["TypeID"] as string) : 0));

            PageSize = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageSize"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageSize"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["PageSize"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["PageSize"] as string) : 20));

            PageIndex = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["PageIndex"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["PageIndex"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["PageIndex"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["PageIndex"] as string) : 1));

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            List<GetRestaurantBingoGameRecordStruct> list = new List<GetRestaurantBingoGameRecordStruct>();

            try
            {
                SqlParameter[] param =
				{					
					new SqlParameter("@GameID", GameID),
					new SqlParameter("@GroupID", GroupID),
					new SqlParameter("@TypeID", TypeID),
					new SqlParameter("@RoundDate", YearMonth),
					new SqlParameter("@MachineID", MachineName),
					new SqlParameter("@PageSize", PageSize),
					new SqlParameter("@PageIndex", PageIndex),
					new SqlParameter("@TotalRecords", SqlDbType.Int)
				};

                param[7].Direction = ParameterDirection.Output;

                DataTable result = SqlHelper.ExecuteDataset
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_GameWeb_G_RoundInfo_Get",
                    param
                ).Tables[0];

                foreach (DataRow dr in result.Rows)
                {
                    GetRestaurantBingoGameRecordStruct o = new GetRestaurantBingoGameRecordStruct();

                    o.MachineName = dr["MachineID"].ToString() + "號機台";
                    o.DateTime = dr["RoundCode_Date"].ToString();

                    Newtonsoft.Json.Linq.JObject restoredObject = Newtonsoft.Json.JsonConvert.DeserializeObject<Newtonsoft.Json.Linq.JObject>(dr["RoundInfo"].ToString().Trim());

                    var aaa = from a in restoredObject.Properties()
                              where a.Name == "BingoPlateID"
                              select a.Value;

                    var bbb = from a in restoredObject.Properties()
                              where a.Name == "BingoBallCount"
                              select a.Value;

                    string str = aaa.FirstOrDefault().ToString().Replace(",", "/").Replace("[", "").Replace("]", "").Replace("\r", "").Replace("\n", "").Replace(" ", "").Trim();

                    string[] str2 = str.Split('/');

                    for (int iii = 0; iii < str2.Length; iii++)
                    {
                        if (str2[iii].Length == 1)
                        {
                            str2[iii] = "0" + str2[iii];
                        }
                    }

                    o.Number = string.Join(" / ", str2);
                    o.Count = bbb.FirstOrDefault().ToString();

                    o.NickName = "";

                    list.Add(o);
                }

                dic.Add("Data", list);
                dic.Add("TotalCount", param[7].Value.ToString());

                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = dic
                    }))
                };
            }
            catch (Exception ex)
            {
                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
                   {
                       Content = new System.Net.Http.StringContent(jss.Serialize(new
                       {
                           Result = ex.Message
                       }))
                   };

                // 回傳參數
                return response;
            }
            finally
            {

            }

            // 回傳參數
            return response;
        }

        /// <summary>
        /// 餐廳賓果活動頁-下拉式選單-獲得年月
        /// </summary>
        /// <param name="GameID"></param>
        /// <param name="GroupID"></param>
        /// <param name="TypeID"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic GetRestaurantBingoGameRecordYearMonth(Nullable<int> GameID, Nullable<int> GroupID, Nullable<int> TypeID)
        {
            GameID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["GameID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["GameID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["GameID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["GameID"] as string) : 1036));

            GroupID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["GroupID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["GroupID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["GroupID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["GroupID"] as string) : 4));

            TypeID = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["TypeID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.Form["TypeID"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["TypeID"] as string) ? Convert.ToInt32(HttpContext.Current.Request.QueryString["TypeID"] as string) : 0));

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            List<DropDownListStruct> list = new List<DropDownListStruct>();

            try
            {
                DropDownListStruct o = new DropDownListStruct();

                o.Value = "-1";
                o.Text = "全部";

                list.Add(o);

                SqlParameter[] param =
				{					
					new SqlParameter("@GameID", GameID),
					new SqlParameter("@GroupID", GroupID),
					new SqlParameter("@TypeID", TypeID)
				};

                DataTable result = SqlHelper.ExecuteDataset
                            (
                                WebConfig.ConnectionString,
                                CommandType.StoredProcedure,
                                "NSP_GameWeb_G_RoundInfo_DDL_Get",
                                param
                            ).Tables[0];

                foreach (DataRow dr in result.Rows)
                {
                    o = new DropDownListStruct();

                    o.Value = dr["RoundDate"].ToString();

                    string[] RoundDate = dr["RoundDate"].ToString().Split('/');

                    if (RoundDate.Length == 2)
                    {
                        o.Text = RoundDate[0] + "年/" + RoundDate[1] + "月";
                    }
                    else
                    {
                        o.Text = dr["RoundDate"].ToString();
                    }

                    list.Add(o);
                }

                dic.Add("Data", list);

                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = dic
                    }))
                };
            }
            catch (Exception ex)
            {
                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }

            // 回傳參數
            return response;
        }

        /// <summary>
        /// 餐廳賓果活動頁-下拉式選單-獲得機台名稱
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic GetRestaurantBingoGameRecordMachineName()
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            List<DropDownListStruct> list = new List<DropDownListStruct>();

            try
            {
                DropDownListStruct o = new DropDownListStruct();

                o.Value = "-1";
                o.Text = "全部機台編號";

                list.Add(o);

                for (int i = 0; i <= 11; i++)
                {
                    o = new DropDownListStruct();

                    o.Value = i.ToString();
                    o.Text = (i + 1) + "號機台";

                    list.Add(o);
                }

                dic.Add("Data", list);

                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = dic
                    }))
                };
            }
            catch (Exception ex)
            {
                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.NotFound)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }

            // 回傳參數
            return response;
        }

        /// <summary>
        /// 餐廳賓果活動頁-揪咖送好禮
        /// </summary>
        /// <param name="Platform"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic GetRestaurantBingoIntroducerStatus(string Platform)
        {
            Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Platform"] as string) ? (HttpContext.Current.Request.QueryString["Platform"] as string) : Platform));

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            DataContext context = new DataContext(Platform);

            int ResultCode = -1;
            int SubCNT = 0;
            int VerifiedCNT = 0;
            int TotalAmount = 0;

            if (!context.Session.IsLogin)
            {
                goto OutCode;
            }

            try
            {
                SqlParameter[] param =
				{					
					new SqlParameter("@MemberID", context.Session.MemberID),
					new SqlParameter("@ResultCode", SqlDbType.Int)
				};

                param[1].Direction = ParameterDirection.Output;

                DataSet result = SqlHelper.ExecuteDataset
                            (
                                WebConfig.ConnectionString,
                                CommandType.StoredProcedure,
                                "Game_Activity.dbo.NSP_GameWeb_E20131003_IntroducerStatus_Check",
                                param
                            );

                ResultCode = Convert.ToInt32(param[1].Value.ToString());

                if (ResultCode == 0)
                {
                    foreach (DataRow dr in result.Tables[0].Rows)
                    {
                        SubCNT = Convert.ToInt32(dr["SubCNT"].ToString());

                        VerifiedCNT = Convert.ToInt32(dr["VerifiedCNT"].ToString());

                        TotalAmount = Convert.ToInt32(Convert.ToDecimal(dr["TotalAmount"].ToString()));

                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }

        OutCode:

            dic.Add("ResultCode", ResultCode);
            dic.Add("SubCNT", SubCNT);
            dic.Add("VerifiedCNT", VerifiedCNT);
            dic.Add("TotalAmount", TotalAmount);

            response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = dic
                }))
            };

            // 回傳參數
            return response;
        }

        /// <summary>
        /// 餐廳賓果活動頁-開招送分神秘加碼
        /// </summary>
        /// <param name="Platform"></param>
        /// <returns></returns>
        [AcceptVerbs("Post", "Get")]
        public dynamic GetRestaurantBingoCoinStatus(string Platform)
        {
            Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Platform"] as string) ? (HttpContext.Current.Request.QueryString["Platform"] as string) : Platform));

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            DataContext context = new DataContext(Platform);

            int ResultCode = -1;
            int GoldCoin = 0;
            int LuckyCoin = 0;

            if (!context.Session.IsLogin)
            {
                goto OutCode;
            }
            else
            {
                ResultCode = 0;
            }

            try
            {
                SqlParameter[] param =
				{					
					new SqlParameter("@MemberID", context.Session.MemberID)
				};

                DataTable result = SqlHelper.ExecuteDataset
                            (
                                WebConfig.ConnectionString,
                                CommandType.StoredProcedure,
                                "Game_Activity.dbo.NSP_GameWeb_E20131003_JungleLM",
                                param
                            ).Tables[0];

                foreach (DataRow dr in result.Rows)
                {
                    GoldCoin = Convert.ToInt32(dr["JungleLM"].ToString());
                    LuckyCoin = Convert.ToInt32(dr["Coin_Total"].ToString());

                    break;
                }
            }
            catch (Exception ex)
            {
                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }

        OutCode:

            dic.Add("ResultCode", ResultCode);
            dic.Add("GoldCoin", GoldCoin);
            dic.Add("LuckyCoin", LuckyCoin);

            response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = dic
                }))
            };

            // 回傳參數
            return response;
        }
        #endregion

        #region 2013/12/12上線的包月500首購半價資格判斷
        [AcceptVerbs("Post", "Get")]
        public dynamic NewMonthPaymentDiscountCheck(string Platform)
        {
            Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Platform"] as string) ? (HttpContext.Current.Request.QueryString["Platform"] as string) : Platform));

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            DataContext context = new DataContext(Platform);

            int ResultCode = -1;

            if (!context.Session.IsLogin)
            {
                goto OutCode;
            }

            try
            {
                ResultCode = GameWeb_Models.Models.Bank.BankEntities.NewMonthPaymentDiscountCheck(new GameWeb_Models.Models.Bank.ProductValueListInputModel() { MemberID = context.Session.MemberID });
            }
            catch (Exception ex)
            {
                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }

        OutCode:

            dic.Add("ResultCode", ResultCode);

            response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = dic
                }))
            };

            // 回傳參數
            return response;
        }
        #endregion

        #region 2014/01/23 過年活動
        [AcceptVerbs("Post", "Get")]
        public dynamic ActionChineseNewYearCheck(string Platform)
        {
            Platform = (!string.IsNullOrEmpty(HttpContext.Current.Request.Form["Platform"] as string) ? (HttpContext.Current.Request.Form["Platform"] as string) : (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["Platform"] as string) ? (HttpContext.Current.Request.QueryString["Platform"] as string) : Platform));

            Dictionary<string, object> dic = new Dictionary<string, object>();

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.MaxJsonLength = int.MaxValue;

            var response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = string.Empty
                }))
            };

            DataContext context = new DataContext(Platform);

            int ResultCode = -1;

            if (!context.Session.IsLogin)
            {
                goto OutCode;
            }

            try
            {
                SqlParameter[] param =
				{					
					new SqlParameter("@MemberID", context.Session.MemberID),
					new SqlParameter("@ResultCode", SqlDbType.Int)
				};

                param[param.Length - 1].Direction = ParameterDirection.Output;

                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "Game_Activity.dbo.NSP_GameWeb_E20140123001_CheckResult",
                    param
                );

                ResultCode = Convert.ToInt32(param[param.Length - 1].Value.ToString());
            }
            catch (Exception ex)
            {
                response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
                {
                    Content = new System.Net.Http.StringContent(jss.Serialize(new
                    {
                        Result = ex.Message
                    }))
                };

                // 回傳參數
                return response;
            }
            finally
            {

            }

        OutCode:

            dic.Add("ResultCode", ResultCode);

            response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK)
            {
                Content = new System.Net.Http.StringContent(jss.Serialize(new
                {
                    Result = dic
                }))
            };

            // 回傳參數
            return response;
        }
        #endregion
    }

    /// <summary>
    /// 十點半勝分過關榜回傳結構
    /// </summary>
    public class GetTenPointHalfReturnStruct
    {
        // 名次
        public int RankNo { get; set; }
        // 玩家暱稱
        public string NickName { get; set; }
        // 過五關次數
        public decimal RankTimes { get; set; }
        // 做莊累積勝分/目前可獲得彩金
        public decimal RankValue { get; set; }
    }

    /// <summary>
    /// 【2013週年慶活動】電子贏分超達人積分賽回傳結構
    /// </summary>
    public class GetElectronicsWinPointsDarenPointsRaceStruct
    {
        //// 編號
        //public int RowNo { get; set; }
        //// 活動事件編號
        //public string EventID { get; set; }
        //// 活動事件流水號
        //public int EventNo { get; set; }
        //// 排行榜種類  2：電子【贏分榜】
        //public int RankType { get; set; }
        //// 會員編號
        //public int MemberID { get; set; }
        // 會員暱稱
        public string NickName { get; set; }
        //// 勝分／贏分
        //public decimal RankValue { get; set; }
        // 名次
        public int RankNo { get; set; }
        // 個人總積分
        public int TotalScore { get; set; }
        // 可獲得彩金
        public int GetJP { get; set; }
    }

    /// <summary>
    /// 推筒子活動
    /// </summary>
    public class GetPushTheCaskActiveDataStruct
    {
        public int RankNo { get; set; }

        public string NickName { get; set; }

        public decimal RankTimes { get; set; }

        public decimal RankValue { get; set; }


        //public int RankNo2 { get; set; }

        //public string NickName2 { get; set; }

        //public decimal RankTimes2 { get; set; }

        //public decimal RankValue2 { get; set; }
    }

    /// <summary>
    /// 餐廳賓果活動頁會用到的傳出結構
    /// </summary>
    public class GetRestaurantBingoGameRecordStruct : IDisposable
    {
        public string MachineName { get; set; }
        public string DateTime { get; set; }
        public string Number { get; set; }
        public string Count { get; set; }
        public string NickName { get; set; }

        void IDisposable.Dispose()
        {

        }
    }

    /// <summary>
    /// 餐廳賓果活動頁會用到的下拉式選單
    /// </summary>
    public class DropDownListStruct : IDisposable
    {
        public string Text { get; set; }

        public string Value { get; set; }

        void IDisposable.Dispose()
        {

        }
    }

    /// <summary>
    /// 餐廳賓果活動頁會用到的JSON格式
    /// </summary>
    [Newtonsoft.Json.JsonObject(Newtonsoft.Json.MemberSerialization.OptOut)]
    public class RoundInfoStruct : IDisposable
    {
        public string BingoBallCount { get; set; }

        public dynamic BingoPlateID { get; set; }

        void IDisposable.Dispose()
        {

        }
    }
}
