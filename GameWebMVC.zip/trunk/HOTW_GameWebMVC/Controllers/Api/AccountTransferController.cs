﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web;
using HOTW_GameWebMVC.AppLibs;
using System.Web.Script.Serialization;
using HOTW_GameWebMVC.Models;
using GS.Web.CommunityGateway.StoreAPI;
using System.Text.RegularExpressions;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class AccountTransferController : ApiController
    {
		[AcceptVerbs(new string[] { "Post" })]
		public dynamic ATRegister(RegisterModel registerModel)
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["MemberID"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 99;
			}
			else
			{

				#region 驗證
				if (!Regex.IsMatch(registerModel.MemberAccount, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 101;
					resultData.ResultMsg = "帳號錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				else if (!Regex.IsMatch(registerModel.MemberPassword, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 102;
					resultData.ResultMsg = "密碼錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				else if (!string.IsNullOrEmpty(registerModel.Mobile) && !Regex.IsMatch(registerModel.Mobile, @"^[09]{2}[0-9]{8}$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 103;
					resultData.ResultMsg = "手機格式錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				else if (!string.IsNullOrEmpty(registerModel.EMail) && !Regex.IsMatch(registerModel.EMail, @"^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 104;
					resultData.ResultMsg = "電子信箱格式錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				#endregion

				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
				minfo.MemberAccount = registerModel.MemberAccount;
				minfo.MemberPassword = registerModel.MemberPassword;
				minfo.Mobile = registerModel.Mobile;
				minfo.EMail = registerModel.EMail;

				resultData = MemberEventUtility.ATRegister(minfo);

				if (resultData.ResultCode == 0)
				{
					Session["WaitMobileAuthAccount"] = Session["MemberAccount"].ToString();
					// Session["WaitMobileAuthPassword"] = registerModel.MemberPassword;
					Session["WaitMobileAuthMobile"] = registerModel.Mobile;
					Session["ConfirmRegisterTime"] = DateTime.Now;

					// 待轉帳號密碼
					Session["WaitTransferAccount"] = registerModel.MemberAccount;
					Session["WaitTransferPassword"] = registerModel.MemberPassword;
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic ATMobileAuthentication(string verificationCode)
		{
			if (Request.Method == HttpMethod.Post)
			{
				verificationCode = System.Web.HttpContext.Current.Request.Form["verificationCode"] as string;
			}

			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			#region 驗證
			if (string.IsNullOrEmpty(verificationCode))
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 101;
				resultData.ResultMsg = "驗證碼不可空白!";
				return new
				{
					ResultCode = resultData.ResultCode,
					ResultMsg = resultData.ResultMsg,
					Data = resultData.Data
				};
			}
			#endregion

			if (Session["MemberID"] == null || Session["WaitMobileAuthAccount"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 99;
			}
			else
			{
				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
				minfo.Mobile = Session["WaitMobileAuthMobile"].ToString();
				minfo.MobileVaildCode = verificationCode;
				minfo.IsChange = 1;
				resultData = MemberEventUtility.ATMobileVaild(minfo);
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic Login()
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["WaitTransferAccount"] == null || Session["WaitTransferPassword"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 98;
			}
			else
			{
				try
				{
					MemberInfo minfo = new MemberInfo();
					minfo.MemberAccount = Session["WaitTransferAccount"].ToString();
					minfo.MemberPassword = Session["WaitTransferPassword"].ToString();
					minfo.Mobile4Num = " ";
					minfo.Platform = "Web";
					minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
					minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;
					resultData = MemberEventUtility.Login(minfo);

					resultData.Data = HOTW_GameWebMVC.AppLibs.MemberAttribute.Current.IsHCoin.ToString().ToLower();

                    Session.Remove("WaitTransferAccount");
                    Session.Remove("WaitTransferPassword");
				}
				catch (Exception ex)
				{
					log4net.LogManager.GetLogger(typeof(AccountController)).Error("LoginFail", ex);
					resultData = new MemberResultData();
					resultData.ResultCode = 99;
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic LogoutWithLogin()
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["WaitTransferAccount"] == null || Session["WaitTransferPassword"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 98;
			}
			else
			{
				try
				{
					MemberInfo minfo = new MemberInfo();
					minfo.MemberAccount = Session["WaitTransferAccount"].ToString();
					minfo.MemberPassword = Session["WaitTransferPassword"].ToString();
					minfo.Mobile4Num = " ";
					minfo.Platform = "Web";
					minfo.ClientIP = HttpContext.Current.Request.UserHostAddress;
					minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;
					resultData = MemberEventUtility.LogoutWithLogin(minfo);

                    Session.Remove("WaitTransferAccount");
                    Session.Remove("WaitTransferPassword");
				}
				catch (Exception ex)
				{
					log4net.LogManager.GetLogger(typeof(AccountController)).Error("LogoutWithLoginFail", ex);
					resultData = new MemberResultData();
					resultData.ResultCode = 99;
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic SetKeepLoginCookie(string isRemember)
		{
			if (Request.Method == HttpMethod.Post)
			{
				isRemember = System.Web.HttpContext.Current.Request.Form["isRemember"] as string;
			}

			var Session = HttpContext.Current.Session;
			MemberResultData resultData;
			resultData = new MemberResultData();

			if (Session["MemberAccount"] == null || Session["MemberPassword"] == null)
			{
				resultData.Data = "";
				return new
				{
					ResultCode = resultData.ResultCode,
					ResultMsg = resultData.ResultMsg,
					Data = resultData.Data
				};
			}

			string memberAccount = Session["MemberAccount"] as string;
			string memberPassword = Session["MemberPassword"] as string;

			if (isRemember == "true")
			{
				resultData.Data = EncryptUtility.Encrypt(memberAccount + "|" + memberPassword);
			}
			else
			{
				resultData.Data = "";
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic ATRegisterThird(RegisterModel registerModel)
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Session["MemberID"] == null)
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 99;
			}
			else
			{
				#region 驗證
				if (!Regex.IsMatch(registerModel.MemberAccount, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 101;
					resultData.ResultMsg = "帳號錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				else if (!Regex.IsMatch(registerModel.MemberPassword, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 102;
					resultData.ResultMsg = "密碼錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				else if (!string.IsNullOrEmpty(registerModel.Mobile) && !Regex.IsMatch(registerModel.Mobile, @"^[09]{2}[0-9]{8}$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 103;
					resultData.ResultMsg = "手機格式錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				else if (!string.IsNullOrEmpty(registerModel.EMail) && !Regex.IsMatch(registerModel.EMail, @"^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$"))
				{
					resultData = new MemberResultData();
					resultData.ResultCode = 104;
					resultData.ResultMsg = "電子信箱格式錯誤";
					return new
					{
						ResultCode = resultData.ResultCode,
						ResultMsg = resultData.ResultMsg,
						Data = resultData.Data
					};
				}
				#endregion

				MemberInfo minfo = new MemberInfo();
				minfo.MemberID = Convert.ToInt32(Session["MemberID"]);
				minfo.MemberAccount = registerModel.MemberAccount;
				minfo.MemberPassword = registerModel.MemberPassword;
				minfo.Mobile = registerModel.Mobile;
				minfo.EMail = registerModel.EMail;

				resultData = MemberEventUtility.ATRegisterThird(minfo);

				if (resultData.ResultCode == 0)
				{
					// 待轉帳號密碼
					Session["WaitTransferAccount"] = registerModel.MemberAccount;
					Session["WaitTransferPassword"] = registerModel.MemberPassword;
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};		
		}

		[AcceptVerbs(new string[] { "Post" })]
		public dynamic FindAccount(string mobile)
		{
			var Session = HttpContext.Current.Session;
			MemberResultData resultData;

			if (Request.Method == HttpMethod.Post)
			{
				mobile = System.Web.HttpContext.Current.Request.Form["mobile"] as string;
			}

			if (string.IsNullOrEmpty(mobile))
			{
				resultData = new MemberResultData();
				resultData.ResultCode = 98;
				resultData.ResultMsg = "請輸入手機號碼";
			}
			else
			{
				try
				{
					MemberInfo minfo = new MemberInfo();
					minfo.Mobile = mobile;				
					resultData = MemberEventUtility.ATFindAccount(minfo);

					resultData.Data = HOTW_GameWebMVC.AppLibs.MemberAttribute.Current.IsHCoin.ToString().ToLower();
				}
				catch (Exception ex)
				{
					log4net.LogManager.GetLogger(typeof(AccountController)).Error("FindAccount", ex);
					resultData = new MemberResultData();
					resultData.ResultCode = 99;
				}
			}

			return new
			{
				ResultCode = resultData.ResultCode,
				ResultMsg = resultData.ResultMsg,
				Data = resultData.Data
			};
		}
    }
}
