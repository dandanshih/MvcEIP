﻿using GS.Web.CPA;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.Attributes.WebAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.ModelBinding;
using GameWeb_Models.Models.Advertising;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class ADController : ApiController
    {
        [AcceptVerbs("Get")]
        [AjaxOnly]
        public void UpdateCount(string AppName, string EType)
        {
            if (string.IsNullOrEmpty(AppName))
            {
                return;
            }

            EventType eType;
            if (!Enum.TryParse<EventType>(EType, out eType))
            {
                return;
            }

            CPAHandler handler = new CPAHandler(WebConfig.CPAConnectionString);
            handler.Add(CPAType.Other, eType);
            handler.Initial();
        }

		[AcceptVerbs("Get", "Post")]
		[AjaxOnly]
		public List<ADModel> GetADList(QueryADModel model)
		{
			string CacheName = string.Format("ADType_{0}_{1}_{2}", (int)model.AdFlag, model.AdPointType, model.AdPlatform);

			List<ADModel> resultData = HttpContext.Current.Cache[CacheName] as List<ADModel>;


			if (resultData == null)
			{
				resultData = AdvertisingEntities.GetADList(model);

#if(Online)
				DateTime CacheTime = DateTime.Now.AddHours(1);
#else
				DateTime CacheTime = DateTime.Now.AddMinutes(1);
#endif
				HttpContext.Current.Cache.Insert
				(
					CacheName,
					resultData,
					null,
					CacheTime,
					System.Web.Caching.Cache.NoSlidingExpiration,
					System.Web.Caching.CacheItemPriority.Normal,
					null
				);
			}
			return resultData;
		}
    }
}
