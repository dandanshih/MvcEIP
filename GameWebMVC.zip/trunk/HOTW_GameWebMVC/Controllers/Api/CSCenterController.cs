﻿using GameWeb_Models.Models.CSCenter;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.Attributes.WebAPI;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Http;
namespace HOTW_GameWebMVC.Controllers.Api
{
    public class CSCenterController : ApiController
    {





        [AcceptVerbs("Post")]
        [AjaxOnly]
        public string Contact(ContactInputModel data)
        {
            var Session = HttpContext.Current.Session;
            int memberId = (Session["MemberID"] == null) ? 0 : int.Parse(Session["MemberID"].ToString());

            // 目前前台無此修改欄位，如果前台有新增才將下面限制拿掉
            data.ContactTypeID = 1;
            data.ContactTitle = "";
            // Post 過來的欄位若無值則會為null，因此用空值取代
            data.UserName = string.IsNullOrEmpty(data.UserName) ? "" : data.UserName;
            data.UserEmail = string.IsNullOrEmpty(data.UserEmail) ? "" : data.UserEmail;
            data.ContactDesc = string.IsNullOrEmpty(data.ContactDesc) ? "" : data.ContactDesc;
            data.UserTel = string.IsNullOrEmpty(data.UserTel) ? "" : data.UserTel;

            // 驗證參數
            if (string.IsNullOrEmpty(data.UserName))
            {
                return "留言者不能空白。";
            }

            if (string.IsNullOrEmpty(data.UserEmail))
            {
                return "E-Mail不能空白。";
            }

            if (string.IsNullOrEmpty(data.ContactDesc))
            {
                return "留言內容不能空白。";
            }

            if (!string.IsNullOrEmpty(data.UserTel) && !Regex.IsMatch(data.UserTel, @"[0-9]*[1-9][0-9]*"))
            {
                return "聯絡電話輸入錯誤。";
            }

            if (!Regex.IsMatch(data.UserEmail, @"^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$"))
            {
                return "E-Mail輸入錯誤。";
            }

            if (data.ContactDesc.Length > 1000)
            {
                return "留言內容長度不能大於1000字元。";
            }

            // 將換行符號 &#13;&#10; (\r\n) 取代成 <br />
			//data.ContactDesc = HttpUtility.HtmlEncode(data.ContactDesc).Replace("\r\n", "<br />");

			data.ContactDesc = data.ContactDesc.Replace("\r\n", "<br />");
			
            // 新增一筆留言
            int result = CSCenterEntities.Contact(memberId, data);

            // 寄送 Email 到客服信箱
            string subject = HttpContext.GetGlobalResourceObject("MailResource", "Contact_Subject").ToString();
            string body = string.Format
            (
                HttpContext.GetGlobalResourceObject("MailResource", "Contact_Body").ToString(),
                data.UserName,
                data.UserTel,
                data.UserEmail,
                data.ContactDesc
            );
            CommonUtility.SendEmail(subject, body);

            return "";
        }

        [AcceptVerbs("Post")]
        [AjaxOnly]
        public dynamic QA(QAListInputModel data)
        {
            // Post 過來的欄位若無值則會為null，因此用空值取代
            data.Keyword = (data.Keyword == null) ? "" : data.Keyword;

            int totalRecord = 0;
            var query = CSCenterEntities.QAList(out totalRecord, data).Select(i => new
            {
                QAType = i.QATypeName,
                QADate = i.ModifiedDate.ToString("yyyy/MM/dd"),
                QATitle = i.QATitle,
                QALinkParam = string.Format("?qaid={0}", i.QAID)
            });

            return new
            {
                List = query,
                TotalRecord = totalRecord
            };
        }

        [AcceptVerbs("Get")]
        [AjaxOnly]
        public dynamic QADetail(int qaId)
        {
            var query = CSCenterEntities.QADetail(qaId);

            if (query != null)
            {
                return new
                {
                    QATitle = query.QATitle,
                    QADesc = query.QADesc,
                    QADate = query.ModifiedDate.ToString("yyyy/MM/dd")
                };
            }
            else
            {
                return new
                {
                    QATitle = "",
                    QADesc = "",
                    QADate = ""
                };
            }
        }

        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public string Bug(BugFeedBackInputModel data)
        {
            var Session = HttpContext.Current.Session;

            if (Session["IsLogin"] == null)
            {
                return "請登入會員。";
            }

            int memberId = int.Parse(Session["MemberID"].ToString());
            string nickName = Session["NickName"].ToString();

            // 目前前台無此修改欄位，如果前台有新增才將下面限制拿掉
            // 留言平台 75:Web 76:IPad 110:FB
            data.DictID = 75;
            data.BugTypeID = 1;
            // Post 過來的欄位若無值則會為null，因此用空值取代
            data.BugTitle = string.IsNullOrEmpty(data.BugTitle) ? "" : data.BugTitle;
            data.ContactTel = string.IsNullOrEmpty(data.ContactTel) ? "" : data.ContactTel;
            data.MsgMail = string.IsNullOrEmpty(data.MsgMail) ? "" : data.MsgMail;
            data.BugDesc = string.IsNullOrEmpty(data.BugDesc) ? "" : data.BugDesc;
            data.ContactTel = string.IsNullOrEmpty(data.ContactTel) ? "" : data.ContactTel;

            // 驗證參數
            if (string.IsNullOrEmpty(data.BugTitle))
            {
                return "留言標題不能空白。";
            }

            if (string.IsNullOrEmpty(data.ContactTel))
            {
                return "聯絡電話不能空白。";
            }

            if (string.IsNullOrEmpty(data.MsgMail))
            {
                return "E-Mail不能空白。";
            }

            if (string.IsNullOrEmpty(data.BugDesc))
            {
                return "留言內容不能空白。";
            }

            if (!Regex.IsMatch(data.ContactTel, @"[0-9]*[1-9][0-9]*"))
            {
                return "聯絡電話輸入錯誤。";
            }

            if (!Regex.IsMatch(data.MsgMail, @"^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$"))
            {
                return "E-Mail輸入錯誤。";
            }

            if (data.BugDesc.Length > 1000)
            {
                return "留言內容長度不能大於1000字元。";
            }

		


            // 將換行符號 &#13;&#10; (\r\n) 取代成 <br />
            //data.BugDesc = HttpUtility.HtmlEncode(data.BugDesc).Replace("&#13;&#10;", "<br />");

			data.BugDesc = data.BugDesc.Replace("\r\n", "<br />");

            // 新增一筆留言
            int result = CSCenterEntities.BugFeedBack(memberId, data);

            // 寄送 Email 到客服信箱
            string subject = HttpContext.GetGlobalResourceObject("MailResource", "Bug_Subject").ToString();
            string body = string.Format
            (
                HttpContext.GetGlobalResourceObject("MailResource", "Bug_Body").ToString(),
                nickName,
                data.ContactTel,
                data.MsgMail,
                data.BugTitle,
                data.BugDesc
            );
            CommonUtility.SendEmail(subject, body);

            return "";
        }
    }
}
