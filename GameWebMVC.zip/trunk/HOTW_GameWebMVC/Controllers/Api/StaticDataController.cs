﻿using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.EnumType;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class StaticDataController : ApiController
    {
        // GET api/staticdata
        [AcceptVerbs("Get", "Post")]
        //[OutputCache(Duration = 10, VaryByParam = "*", Location = OutputCacheLocation.Any)]
        public Dictionary<FlagsDataType, object> Get(string Flags, string Data, string Platform)
        {
            try
            {
                FlagsDataMgr FDMgr = new FlagsDataMgr();
                return FDMgr.ReadData(Flags, Data);
            }
            catch (System.Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(StaticDataController)).Error("GetStaticData Error: " + ex.Message, ex);
                return null;
            }
        }
    }
}
