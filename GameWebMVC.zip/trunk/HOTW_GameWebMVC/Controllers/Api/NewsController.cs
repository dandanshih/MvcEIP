﻿using GameWeb_Models.Models;
using GS.Utilities;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using HOTW_GameWebMVC.Models.News;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace HOTW_GameWebMVC.Controllers.Api
{
	public class NewsController : ApiController
	{
		[AcceptVerbs("POST")]
		public Dictionary<string, object> Top100Rank(QueryRankListModel data)
		{
			// string 資料若 Post 空值會為 null
			data.QryRankType = (data.QryRankType == null) ? "7" : data.QryRankType;
			data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
			data.QryRankNum = (data.QryRankNum == null) ? "100" : data.QryRankNum;
			//百大富豪
			var query = RankListEntities.GetData(data).Select(i => new
			{
				RowNo = i.RowNo,
				NickName = i.NickName,
				DATA = i.DATA.ToString("N0")
			});

			Dictionary<string, object> output = new Dictionary<string, object>();
			output.Add("List1", query);
			return output;
		}

		[AcceptVerbs("POST")]
		public Dictionary<string, object> TotalWinRank(QueryRankListModel data)
		{
			// string 資料若 Post 空值會為 null
			data.QryRankType = (data.QryRankType == null) ? "1" : data.QryRankType;
			data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
			data.QryRankNum = (data.QryRankNum == null) ? "50" : data.QryRankNum;
			//總贏分
			var query = RankListEntities.GetData(data).Select(i => new
			{
				RowNo = i.RowNo,
				NickName = i.NickName,
				DATA = i.DATA.ToString("N0")
			});

			Dictionary<string, object> output = new Dictionary<string, object>();
			output.Add("List2", query);
			return output;
		}

		[AcceptVerbs("POST")]
		public Dictionary<string, object> ElecRoundRank(QueryRankListModel data)
		{
			// string 資料若 Post 空值會為 null
			data.QryRankType = (data.QryRankType == null) ? "5" : data.QryRankType;
			data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
			data.QryRankNum = (data.QryRankNum == null) ? "50" : data.QryRankNum;
			//電子局數
			var query = RankListEntities.GetData(data).Select(i => new
			{
				RowNo = i.RowNo,
				NickName = i.NickName,
				DATA = i.DATA.ToString("N0")
			});

			Dictionary<string, object> output = new Dictionary<string, object>();
			output.Add("List3", query);
			return output;
		}

		[AcceptVerbs("POST")]
		public Dictionary<string, object> BattleRoundRank(QueryRankListModel data)
		{
			// string 資料若 Post 空值會為 null
			data.QryRankType = (data.QryRankType == null) ? "6" : data.QryRankType;
			data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
			data.QryRankNum = (data.QryRankNum == null) ? "50" : data.QryRankNum;
			//對戰局數
			var query = RankListEntities.GetData(data).Select(i => new
			{
				RowNo = i.RowNo,
				NickName = i.NickName,
				DATA = i.DATA.ToString("N0")
			});

			Dictionary<string, object> output = new Dictionary<string, object>();
			output.Add("List4", query);
			return output;
		}

		[AcceptVerbs("POST")]
		public Dictionary<string, object> JPWinRank(QueryRankListModel data)
		{
			// string 資料若 Post 空值會為 null
			data.QryRankType = (data.QryRankType == null) ? "7" : data.QryRankType;
			data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
			data.QryRankNum = (data.QryRankNum == null) ? "100" : data.QryRankNum;
			//彩金贏分
			var query = RankListEntities.GetData(data).Select(i => new
			{
				RowNo = i.RowNo,
				NickName = i.NickName,
				DATA = i.DATA.ToString("N0"),
				Values1 = i.Values1,
				Values2 = i.Values2
			});

			Dictionary<string, object> output = new Dictionary<string, object>();
			output.Add("List5", query);
			return output;
		}

		[AcceptVerbs("POST")]
		public Dictionary<string, object> SingleWinRank(QueryRankListModel data)
		{
			// string 資料若 Post 空值會為 null
			data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
			data.QryRankNum = (data.QryRankNum == null) ? "100" : data.QryRankNum;
			//單局贏分
			var query = RankBySingleWinEntities.GetData(int.Parse(data.QryAreaType), int.Parse(data.QryRankNum), int.Parse(data.QryRankGameType)).Select(i => new
			{
				RowNo = i.RowNo,
				NickName = i.NickName,
				GameName = i.GameName,
				JpPoint = i.RankData.ToString("N0"),
				GameID = i.GameID,
				SeatID = i.SeatID
			});

			Dictionary<string, object> output = new Dictionary<string, object>();
			output.Add("List6", query);
			return output;
		}

        [AcceptVerbs("POST")]
        public Dictionary<string, object> PachinkoRank(QueryRankListModel data)
        {
            // string 資料若 Post 空值會為 null
            data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
            data.QryRankNum = (data.QryRankNum == null) ? "100" : data.QryRankNum;
            //單局贏分
            var query = RankByPachinkoEntities.GetData(int.Parse(data.QryAreaType), int.Parse(data.QryRankNum), int.Parse(data.QryRankGameType)).Select(i => new
            {
                RowNo = i.RowNo,
                NickName = i.NickName,
                GameName = i.GameName,
                JpPoint = i.RankData.ToString("N0"),
                GameID = i.GameID,
                SeatID = i.SeatID
            });

            Dictionary<string, object> output = new Dictionary<string, object>();
            output.Add("List7", query);
            return output;
        }

		//[System.Web.Http.AcceptVerbs("POST")]
		//public Dictionary<string, object> RankVIPGame(QueryRankListModel data)
		//{
		//	// string 資料若 Post 空值會為 null
		//	data.QryRankType = (data.QryRankType == null) ? "7" : data.QryRankType;
		//	data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
		//	data.QryRankNum = (data.QryRankNum == null) ? "100" : data.QryRankNum;
		//	//Rank
		//	var query = RankListEntities.GetData(data).Select(i => new
		//	{
		//		RowNo = i.RowNo,
		//		NickName = i.NickName,
		//		DATA = i.DATA.ToString("N0"),
		//		Values1 = i.Values1,
		//		Values2 = i.Values2
		//	});

		//	Dictionary<string, object> output = new Dictionary<string, object>();
		//	output.Add("List", query);
		//	return output;
		//}

		//[System.Web.Http.AcceptVerbs("POST")]
		//public Dictionary<string, object> SingleRoundWinPoint(QueryRankListModel data)
		//{
		//	// string 資料若 Post 空值會為 null
		//	data.QryAreaType = (data.QryAreaType == null) ? "2" : data.QryAreaType;
		//	data.QryRankNum = (data.QryRankNum == null) ? "100" : data.QryRankNum;
		//	//Rank
		//	var query = RankBySingleWinEntities.GetData(int.Parse(data.QryAreaType), int.Parse(data.QryRankNum)).Select(i => new
		//	{
		//		RowNo = i.RowNo,
		//		NickName = i.NickName,
		//		GameName = i.GameName,
		//		JpPoint = i.RankData.ToString("N0"),
		//		GameID = i.GameID,
		//		GameData = i.GameData
		//	});

		//	Dictionary<string, object> output = new Dictionary<string, object>();
		//	output.Add("List2", query);
		//	return output;
		//}

		/// <summary>
		/// 專屬for Javascript使用
		/// </summary>
		/// <param name="data"></param>
		/// <returns></returns>
		[AcceptVerbs("POST")]
		public dynamic NowNewsAnnouncementList()
		{
			try
			{
				string Platform = HttpContext.Current.Request.Form["Platform"];

				DataContext context = new DataContext(Platform);

				int NewsTypeID = Convert.ToInt32(HttpContext.Current.Request.Form["NewsTypeID"]);

				string Keyword = HttpContext.Current.Request.Form["Keyword"];

				int PageIndex = Convert.ToInt32(HttpContext.Current.Request.Form["PageIndex"]);

				int PageSize = Convert.ToInt32(HttpContext.Current.Request.Form["PageSize"]);

				int TimeType = Convert.ToInt32(HttpContext.Current.Request.Form["TimeType"]);

				DateTime Now = Convert.ToDateTime(DateTime.Now.ToShortDateString() + " " + "00:00:00");

				SqlParameter[] parm = 
				{
					new SqlParameter("@NewsTypeID", NewsTypeID),
					new SqlParameter("@Keyword", Keyword),
					new SqlParameter("@DateSelectType", "0"),				
					new SqlParameter("@StartDate", DBNull.Value),
					new SqlParameter("@EndDate", DBNull.Value),
					new SqlParameter("@PageSize", PageSize),
					new SqlParameter("@PageIndex", PageIndex),
					new SqlParameter("@TotalRecord", DbType.Int32),
					new SqlParameter("@NewsPlatform", ((Platform == "Web") ? "1" : "2"))
				};

				parm[7].Direction = ParameterDirection.Output;

				switch (TimeType)
				{
					case 1:
						// 本周
						parm[3].Value = Now.AddDays(-((Convert.ToInt32(Now.DayOfWeek) + 6) % 7));
						parm[4].Value = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
						parm[2].Value = 2;
						break;
					case 2:
						// 近兩周
						parm[3].Value = Now.AddDays(-((Convert.ToInt32(Now.DayOfWeek) + 6) % 7)).AddDays(-14);
						parm[4].Value = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
						parm[2].Value = 2;
						break;
					case 3:
						// 本月
						int iDays = Now.Day - 1;
						parm[3].Value = Now.AddDays(-iDays);
						parm[4].Value = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd ") + DateTime.Now.Hour.ToString("d2") + ":59:59");
						parm[2].Value = 2;
						break;
					case 4:
					default:
						// 全部
						parm[2].Value = 0;
						break;
				}

				SqlDataReader objDtr = SqlHelper.ExecuteReader
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_GameWeb_B_News_List",
					parm
				);

				List<News> list = new List<News>();

				while (objDtr.Read())
				{
					News o = new News();

					o.ImageUrl = Convert.ToString(objDtr["ImageUrl"]);
					o.ModifiedDate = Convert.ToDateTime(objDtr["ModifiedDate"]).ToString("yyyy/MM/dd");
					o.NewsTitle = Convert.ToString(objDtr["NewsTitle"]);
					o.NewsID = Convert.ToInt32(objDtr["NewsID"].ToString());

					list.Add(o);
				}

				objDtr.Close();

				return new
				{
					Result = new
					{
						Data = list,
						TotalRecord = Convert.ToInt32(parm[7].Value.ToString())
					}
				};
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(NewsController)).DebugFormat("最新消息，消息公告發生了錯誤: {0}", ex.Message);

				return new
				{
					Result = new
					{
						Data = "",
						TotalRecord = 0
					}
				};
			}
		}

		/// <summary>
		/// 專屬for Javascript使用
		/// </summary>
		/// <param name="data"></param>
		/// <returns></returns>
		[AcceptVerbs("POST")]
		public dynamic NowNewsAnnouncementDetail()
		{
			try
			{
				string Platform = HttpContext.Current.Request.Form["Platform"];

				int NewsID = int.Parse(HttpContext.Current.Request.Form["NewsID"]);

				DataContext context = new DataContext(Platform);

				SqlParameter[] parm =
				{
					new SqlParameter("@NewsID", NewsID)
				};

				SqlDataReader objDtr = SqlHelper.ExecuteReader
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_GameWeb_B_News_Detail",
					parm
				);

				List<News> list = new List<News>();

				while (objDtr.Read())
				{
					News o = new News();

					o.NewsDesc = Convert.ToString(objDtr["NewsDesc"]).Replace("\r\n", "<br />").Replace("\n", "<br />");
					//o.NewsDesc = Convert.ToString(objDtr["NewsDesc"]);
					o.ModifiedDate = Convert.ToDateTime(objDtr["ModifiedDate"]).ToString("yyyy/MM/dd");
					o.NewsTitle = Convert.ToString(objDtr["NewsTitle"]).Replace("\r\n", "<br />").Replace("\n", "<br />"); ;

					list.Add(o);
				}

				objDtr.Close();

				return new
				{
					Result = new
					{
						Data = list
					}
				};
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(NewsController)).DebugFormat("最新消息，消息公告明細發生了錯誤: {0}", ex.Message);

				return new
				{
					Result = new
					{
						Data = ""
					}
				};
			}
		}

		/// <summary>
		/// 專屬for Javascript使用
		/// </summary>
		/// <param name="data"></param>
		/// <returns></returns>
		[AcceptVerbs("POST")]
		public dynamic GetGameListData()
		{
			try
			{
				List<RankBySingleForGameListModel> list = new List<RankBySingleForGameListModel>();

				list = RankBySingleWinEntities.GetGameListData();

				list.Insert(0, new RankBySingleForGameListModel() { ListName = "不分類", ListID = 0, ListEName = "不分類", ListGroupID = 0 });

				return new
				{
					Result = new
					{
						Data = list
					}
				};
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(NewsController)).DebugFormat("最新消息，消息公告明細發生了錯誤: {0}", ex.Message);

				return new
				{
					Result = new
					{
						Data = ""
					}
				};
			}
		}

        [AcceptVerbs("POST")]
        public dynamic GetPachinkoGameListData()
        {
            try
            {
                List<RankByPachinkoForGameListModel> list = new List<RankByPachinkoForGameListModel>();

                list = RankByPachinkoEntities.GetGameListData();

                list.Insert(0, new RankByPachinkoForGameListModel() { ListName = "不分類", ListID = 0, ListEName = "不分類", ListGroupID = 0 });

                return new
                {
                    Result = new
                    {
                        Data = list
                    }
                };
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(NewsController)).DebugFormat("最新消息，消息公告明細發生了錯誤: {0}", ex.Message);

                return new
                {
                    Result = new
                    {
                        Data = ""
                    }
                };
            }
        }
	}
}
