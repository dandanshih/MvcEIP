﻿using GameWeb_Models.Models;
using HOTW_GameWebMVC.AppLibs;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Http;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class AccountChangeController : ApiController
    {
        [AcceptVerbs("Post")]
        public dynamic EnterMobile(MemberInfo minfo)
        {
            minfo.Mobile = string.IsNullOrEmpty(minfo.Mobile) ? "" : minfo.Mobile;

            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            if (string.IsNullOrEmpty(minfo.Mobile))
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "請輸入手機驗證碼！";
            }
            else if (!Regex.IsMatch(minfo.Mobile, @"^[09]{2}[0-9]{8}$"))
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "手機格式錯誤！";
            }
            else
            {
                resultData = MemberEventUtility.ACCheckMobile(minfo);

                switch (resultData.ResultCode)
                {
                    // 成功
                    case 0:
                        Session["AccountChangeMemberID"] = resultData.Data;
                        Session["AccountChangeMobile"] = minfo.Mobile;
                        resultData.ResultMsg = "";
                        break;
                    // 此手機尚未註冊驗證
                    case 1:
                        resultData.ResultMsg = "您輸入的號碼未認證，建議您重新申請老子有錢online官方帳號！";
                        break;
                    // 此手機非錯過期帳號驗證
                    case 2:
                        resultData.ResultMsg = "您輸入的號碼不在此活動中！";
                        break;
                    // 此手機已轉換帳號完成
                    case 3:
                        resultData.ResultMsg = "您輸入的號碼不在此活動中！";
                        break;
                    // 此手機發送次數過多
                    case 4:
                        resultData.ResultMsg = "此手機發送次數過多！";
                        break;
                    default:
                        resultData.ResultMsg = "驗證碼發送發生錯誤！";
                        break;
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg,
                Data = resultData.Data
            };
        }

        [AcceptVerbs("Post")]
        public dynamic ReSendAuthCode()
        {
            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            if (Session["AccountChangeMemberID"] == null || Session["AccountChangeMobile"] == null)
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "驗證碼逾時！";
            }
            else
            {
                MemberInfo minfo = new MemberInfo();
                minfo.Mobile = Session["AccountChangeMobile"].ToString();
                resultData = MemberEventUtility.ACCheckMobile(minfo);

                switch (resultData.ResultCode)
                {
                    // 成功
                    case 0:
#if(!Online)
                        resultData.Data = GS.Utilities.SqlHelper.ExecuteScalar
                        (
                            WebConfig.ConnectionString,
                            CommandType.Text,
                            @"SELECT VerificationCode 
                                    FROM Game_Branch.dbo.A_MemberSourceChange 
                                    WHERE MemberID = @MemberID",
                            new SqlParameter("@MemberID", Session["AccountChangeMemberID"])
                        ).ToString();
#endif
                        resultData.ResultMsg = "驗證碼已發送！";
                        break;
                    // 此手機尚未註冊驗證
                    case 1:
                        resultData.ResultMsg = "驗證碼發送失敗！";
                        break;
                    // 此手機非錯過期帳號驗證
                    case 2:
                        resultData.ResultMsg = "驗證碼發送失敗！";
                        break;
                    // 此手機已轉換帳號完成
                    case 3:
                        resultData.ResultMsg = "驗證碼發送失敗！";
                        break;
                    // 此手機發送次數過多
                    case 4:
                        resultData.ResultMsg = "此手機發送次數過多！";
                        break;
                    default:
                        resultData.ResultMsg = "驗證碼發送發生錯誤！";
                        break;
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg,
                Data = resultData.Data
            };
        }

        [AcceptVerbs("Post")]
        public dynamic MobileAuthentication(MemberInfo minfo)
        {
            minfo.MobileVaildCode = string.IsNullOrEmpty(minfo.MobileVaildCode) ? "" : minfo.MobileVaildCode;

            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            if (string.IsNullOrEmpty(minfo.MobileVaildCode))
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "驗證碼不可空白！";
            }
            else if (Session["AccountChangeMemberID"] == null || Session["AccountChangeMobile"] == null)
            {
                resultData = new MemberResultData();
                resultData.ResultCode = 99;
                resultData.ResultMsg = "驗證碼逾時！";
            }
            else
            {
                minfo.MemberID = Convert.ToInt32(Session["AccountChangeMemberID"]);
                resultData = MemberEventUtility.ACCheckVerifyCode(minfo);
                if (resultData.ResultCode == 0)
                {
                    resultData.ResultMsg = "驗證碼正確！";
                }
                else
                {
                    resultData.ResultMsg = "驗證碼錯誤！";
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg,
                Data = resultData.Data
            };
        }

        [AcceptVerbs("Post")]
        public dynamic MemberTypeChange(MemberInfo minfo)
        {
            minfo.EMail = string.IsNullOrEmpty(minfo.EMail) ? "" : minfo.EMail;

            var Session = HttpContext.Current.Session;
            MemberResultData resultData;

            int resultCode = 0;
            string resultMessage = "";

            if (Session["IsLogin"] != null)
            {
                resultData = new MemberResultData() { ResultCode = 999, ResultMsg = "已登入會員！" };
            }
            else if (Session["AccountChangeMemberID"] == null || Session["AccountChangeMobile"] == null)
            {
                resultData = new MemberResultData() { ResultCode = 999, ResultMsg = "驗證碼逾時！" };
            }
            else if (!minfo.MemberAccount.IsMemberAccount(out resultCode, out resultMessage))
            {
                resultData = new MemberResultData() { ResultCode = 101, ResultMsg = resultMessage };
            }
            else if (!minfo.MemberAccount.IsIncludeString(minfo.MemberPassword, Session["AccountChangeMobile"].ToString()))
            {
                resultData = new MemberResultData() { ResultCode = 101, ResultMsg = "帳號中不可包含密碼或手機號碼！" };
            }
            else if (!minfo.MemberPassword.IsMemberPassword(out resultCode, out resultMessage))
            {
                resultData = new MemberResultData() { ResultCode = 102, ResultMsg = resultMessage };
            }
            else if (!minfo.MemberPassword.IsIncludeString(minfo.MemberAccount, Session["AccountChangeMobile"].ToString()))
            {
                resultData = new MemberResultData() { ResultCode = 102, ResultMsg = "密碼中不可包含帳號或手機號碼！" };
            }
            else if (!string.IsNullOrEmpty(minfo.EMail) && !minfo.EMail.IsMemberEmail())
            {
                resultData = new MemberResultData() { ResultCode = 104, ResultMsg = "電子信箱格式錯誤！" };
            }
            else
            {
                minfo.MemberID = Convert.ToInt32(Session["AccountChangeMemberID"]);
                resultData = MemberEventUtility.ACMemberChange(minfo);

                switch (resultData.ResultCode)
                {
                    case 0:
                        resultData.ResultMsg = "轉移帳號成功！恭喜您帳號啟用成功！請於下次登入時使用您新設定的帳號進行登入！";
                        break;
                    case 6:
                        resultData.ResultMsg = "暱稱重覆！";
                        break;
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                        resultData.ResultMsg = "您申請的帳號已經有別人使用了，請更換別的帳號！";
                        break;
                    case 31:
                        resultData.ResultMsg = "行動電話號碼重覆！";
                        break;
                    case 51:
                        resultData.ResultMsg = "電子信箱重覆！";
                        break;
                    default:
                        resultData.ResultMsg = "帳號建立時發生錯誤，請稍候再執行一次，或請洽客服中心！";
                        break;
                }
            }

            return new
            {
                ResultCode = resultData.ResultCode,
                ResultMsg = resultData.ResultMsg,
                Data = resultData.Data
            };
        }
    }
}
