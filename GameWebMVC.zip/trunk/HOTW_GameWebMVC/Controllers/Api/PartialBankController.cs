﻿using GameWeb_Models.Models.Bank;
using GameWeb_Models.Models.Bank.Enum;
using GameWeb_Models.Models.Member;
using GameWeb_Models.Models.Other;
using GameWeb_Models.Models.Transfer;
using GS.ServerCommander;
using GS.Utilities;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using HOTW_GameWebMVC.Attributes.WebAPI;
using HOTW_GameWebMVC.Models.Bank;
using Newtonsoft.Json;
using PaymentGateway.StoreAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class PartialBankController : ApiController
    {
        #region 儲值購點
        /// <summary>
        /// 線上購點 PageLoad 載入資訊。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic PointBuyBase()
        {
            ProductGroupType groupType;

            if (!Enum.TryParse<ProductGroupType>(HttpContext.Current.Request.Form["product"], out groupType))
            {
                return "";
            }

            var Session = HttpContext.Current.Session;

            int memberId = int.Parse(Session["MemberID"].ToString());
            int vipLevel = int.Parse(Session["VIP_Level"].ToString());


            // 「儲值金額」對應「付款方式」屬性列表
            var valueProduct = BankEntities.ProductValueList(new ProductValueListInputModel() { ProductGroup = groupType, PaymentValueID = 0, MemberID = memberId, VIP_Level = vipLevel });


            bool isLastRecord = false;
            PayRecord payRecord = new PayRecord();
            #region 取得會員記錄 (PointBuyOnline, PointBuyMonthly)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
            {
                // 取得會員上次儲值動作資訊
                var saveSet = BankEntities.GetMemberPayRecord(new GetMemberPayRecordInputModel() { ProductGroup = groupType, MemberID = memberId });
                Dictionary<string, string> saveData = (saveSet == null) ? new Dictionary<string, string>()
                    : new JavaScriptSerializer().Deserialize<Dictionary<string, string>>(saveSet.WorthDefaultSetting);

                // 會員個人資料
                var memberDetail = MemberEntities.MemberDetail(new MemberDetailInputModel() { MemberID = memberId });

                string temp = "";
                isLastRecord = saveData.TryGetValue("ProductGroup", out temp) ? (temp == ((int)groupType).ToString()) : false;
                payRecord.ProductGroup = groupType;
                payRecord.ValueID = isLastRecord && saveData.TryGetValue("ValueID", out temp) ? Convert.ToInt32(temp) : 0;
                payRecord.ProductID = (payRecord.ValueID != 0 && saveData.TryGetValue("ProductID", out temp)) ? Convert.ToInt32(temp) : 0;
                payRecord.InvoiceEmail = memberDetail.Invoice_EMail;
                payRecord.InvoiceType = memberDetail.Invoice_Type;
                payRecord.InvoiceName = memberDetail.Invoice_Recipient;
                payRecord.InvoiceCityID = memberDetail.Invoice_CityID;
                payRecord.InvoiceZoneID = memberDetail.Invoice_ZoneID;
                payRecord.InvoiceAddress = memberDetail.Invoice_Address;
            }
            #endregion

            IEnumerable<dynamic> valueList = null;
            #region 儲值金額列表 (PointBuyOnline, PointBuyMonthly)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
            {
                valueList = from i in BankEntities.ValueTypeList(new ValueTypeListInputModel() { CoinType = CoinType.NTD, ProductGroup = groupType })
                            join j in valueProduct on i.PaymentValueID equals j.PaymentValueID
                            group j.ProductType.ToString() by i into k
                            select new
                            {
                                ID = k.Key.PaymentValueID,
                                Value = k.Key.Value,
                                Point = k.Key.Point,
                                EveryDayPoint = k.Key.EveryDayPoint,
                                TotalPoint = k.Key.TotalPoint,
                                Img = k.Key.ImageUrl,
                                ImgOver = k.Key.MouseOver,
                                ImgDown = k.Key.MouseDown,
                                ProductList = k.Aggregate((sum, item) => sum + "," + item)
                            };
            }
            #endregion

            IEnumerable<dynamic> productList = null;
            #region 付費方式列表 (PointBuyOnline, PointBuySN, PointBuyMonthly, PointTransfer)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuySN, ProductGroupType.PointBuyMonthly, ProductGroupType.TransferOnline }.Contains(groupType))
            {
                productList = from i in BankEntities.ProductTypeList(new ProductTypeListInputModel() { ProductGroup = groupType })
                              select new
                              {
                                  ID = i.ProductType,
                                  Name = i.ProductTypeName,
                                  Text = HttpUtility.HtmlDecode(i.Text),
                                  Status = (i.Flag == 1 ? "正常" : "維護中"),
                                  IsMaintain = (i.Flag != 1),
                                  HelpUrl = i.HelpUrl,
                                  IsNeedInvoice = i.IsNeedInvoice,
                                  Img = i.ImageUrl,
                                  ShopUrl = i.ShopUrl,
                                  IsPG = i.IsPaymentGateway,
                                  Redirect = i.Redirect
                              };
            }
            #endregion

            IEnumerable<dynamic> valueProductList = null;
            #region 金額、付費方式的關聯屬性 (PointBuyOnline)
            if (new[] { ProductGroupType.PointBuyOnline }.Contains(groupType))
            {
                valueProductList = from i in valueProduct
                                   select new int[] { i.PaymentValueID, i.ProductType, i.CanUseEcoupon };
            }
            #endregion

            IEnumerable<dynamic> cityList = null;
            #region 縣市鄉鎮列表 (PointBuyOnline, PointBuyMonthly)
            if (new[] { ProductGroupType.PointBuyOnline, ProductGroupType.PointBuyMonthly }.Contains(groupType))
            {
                cityList = from i in OtherEntities.CityData()
                           group new { i.ZipCode, i.ZoneID, i.ZoneName } by new { i.CityID, i.CityName } into j
                           select new
                           {
                               // 縣市編號
                               CityID = j.Key.CityID,
                               // 縣市名稱
                               CityName = string.IsNullOrEmpty(j.Key.CityName) ? "請選擇縣市" : j.Key.CityName,
                               // 縣市內所屬的鄉鎮市
                               ZoneList = from x in j
                                          select new string[] 
                                          {
                                              x.ZoneID, 
                                              string.IsNullOrEmpty(x.ZoneName) ? "請選擇" : x.ZoneName, 
                                              x.ZipCode 
                                          }
                           };
            }
            #endregion

            return new
            {
                // 是否使用最後一次的操作紀錄
                IsLastRecord = isLastRecord,
                // 上次記錄結構或預設資料
                PayRecord = payRecord,
                // 儲值金額列表
                ValueSource = valueList,
                // 付費方式列表
                ProductSource = productList,
                // 金額、付費方式的關聯屬性
                ValueProductSource = valueProductList,
                // 縣市鄉鎮列表
                CitySource = cityList
            };
        }

        /// <summary>
        /// 驗證 ECoupon 正確並取得金額。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic AuthECoupon(CheckECouponInputModel data)
        {
            var Session = HttpContext.Current.Session;
            // 回傳狀態
            int resultCode = 0;
            // 此序號金額
            decimal resultValue = 0;

            data.MemberID = int.Parse(Session["MemberID"].ToString());
            data.IsReturn = 1;


            if (!data.EcouponCode.IsECoupon())
            {
                // 格式錯誤
                resultCode = -1;
                resultValue = 0;
            }
            else
            {
                // 跟DB驗證
                var checkResult = BankEntities.CheckECoupon(data);
                resultCode = checkResult.Result;
                resultValue = checkResult.VALUE;
            }

            return new
            {
                // 回傳狀態
                ResultCode = resultCode,
                // 此序號金額
                ResultValue = resultValue
            };
        }

        /// <summary>
        /// 驗證儲值金額與ECoupon對應的付款方式。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic AuthValueECoupon(CheckValueECouponInputModel data)
        {
            var Session = HttpContext.Current.Session;

            // 回傳狀態
            int resultCode = 0;
            // 此序號金額
            decimal ecouponValue = 0;
            // 回傳訊息
            string message = "";

            data.MemberID = int.Parse(Session["MemberID"].ToString());

            string productList = BankEntities.CheckValueECoupon(data, out resultCode, out ecouponValue, out message).Aggregate("", (sum, item) => (sum == "" ? "" : sum + ",") + item.ToString());

            return new
            {
                // 回傳狀態
                ResultCode = resultCode,
                // 此序號金額
                ECouponValue = ecouponValue,
                // 付款方式列表 (以 "," 分隔)
                ProductList = productList
            };
        }

        /// <summary>
        /// 儲存線上購點的會員儲值動作。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public void SavePayRecord(PayRecord data)
        {
            // 將 null 轉成空字串
            data.InvoiceEmail = string.IsNullOrEmpty(data.InvoiceEmail) ? "" : data.InvoiceEmail;
            data.InvoiceName = string.IsNullOrEmpty(data.InvoiceName) ? "" : data.InvoiceName;
            data.InvoiceZoneID = string.IsNullOrEmpty(data.InvoiceZoneID) ? "" : data.InvoiceZoneID;
            data.InvoiceAddress = string.IsNullOrEmpty(data.InvoiceAddress) ? "" : data.InvoiceAddress;

            BankEntities.SetMemberPayRecord(new SetMemberPayRecordInputModel()
            {
                ProductGroup = data.ProductGroup,
                MemberID = int.Parse(HttpContext.Current.Session["MemberID"].ToString()),
                WorthDefaultSetting = new JavaScriptSerializer().Serialize(data)
            });
        }

        /// <summary>
        /// 取得會員儲值可獲得金額點數資訊。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GetMemberWorth(GetMemberWorthInputModel data)
        {
            var Session = HttpContext.Current.Session;

            data.MemberID = int.Parse(Session["MemberID"].ToString());
            data.VIP_Level = int.Parse(Session["VIP_Level"].ToString());
            data.ECouponCode = data.ECouponCode.IsECoupon() ? data.ECouponCode : "";
            data.ProductID = data.ProductID.IsStoreValue() ? data.ProductID : "";
            data.IsReturn = 0;

            // 金額
            decimal price = 0;
            // 點數
            decimal resultPoints = 0;
            // 每日補點
            decimal everyDayPoints = 0;
            // 贈點
            decimal giftPoints = 0;

            // 取得折價後的金額資訊
            BankEntities.GetMemberWorth(data, out price, out resultPoints, out everyDayPoints, out giftPoints);

            return new
            {
                Price = price,
                ResultPoints = resultPoints,
                EveryDayPoints = everyDayPoints,
                GiftPoints = giftPoints
            };
        }
        #endregion

        #region 老幣轉帳
        /// <summary>
        /// 取得交易編號+MemberID組合加密字串。
        /// </summary>
        /// <param name="transferNo"></param>
        /// <param name="memberId"></param>
        /// <returns></returns>
        private string TransferNoEncrypt(int transferNo, int memberId)
        {
            string key = "123Gosmio1231234";
            string iv = "1231231234Gosmio";

            return CommonUtility.AESEncrypt(string.Format("{0}{1}", memberId, transferNo), key, iv);
        }

        /// <summary>
        /// 從加密字串中取得交易編號。
        /// </summary>
        /// <param name="no"></param>
        /// <param name="memberId"></param>
        /// <returns></returns>
        private int TransferNoDecrypt(string no, int memberId)
        {
            string key = "123Gosmio1231234";
            string iv = "1231231234Gosmio";
            string strMemberid = memberId.ToString();

            if (string.IsNullOrEmpty(key))
            {
                return -1;
            }

            string decKey = CommonUtility.AESDecrypt(no, key, iv);
            int transferNo = 0;

            if (!decKey.StartsWith(strMemberid) || !int.TryParse(decKey.Substring(strMemberid.Length), out transferNo))
            {
                return -1;
            }

            return transferNo;
        }

        private string RsaPrivateKey = "<RSAKeyValue><Modulus>xhNWUI61NpqM+j9hglUPr7x28OQKqXb9h4I02xm0p7OYYJGxOMIERW8q4RxzstO5VoES+OlgYRbJFT191H9QUjDZCPv7K3SkoeBnoGaQENm0BfCU6pfSXlHxWW80oA8vX6hwYWZt/kG6Lf9aCNz7uSU3lKttY6d8EuGCRCklqsE=</Modulus><Exponent>AQAB</Exponent><P>9ccJymemi4IFyrvQ6pPHDxFQSR94SAdiIPdYsH5jkKnOsq0J/oYZplKYqGN6cV7vQerfZIG0Tq9CPbdGqryN6Q==</P><Q>zlBiKAeAex+TS6SZ2gC7vh6f8RpSHF3OgSexub+hIA+tod7ovEJ+Qy0we/IgT6AYGBjPgthTtETl5f+WH1D3GQ==</Q><DP>eJOlYf9n3Zl0bfmmjO7jAalk0fr2b5/vrGysvinDfv1PwqjR9mSjwM1Ux4fGUkhY6OXpos1fQBsLTGvV532JwQ==</DP><DQ>xBEsVzJZ7aiiSL7S35TW1uUvxufmpMKZX7CjfA0bSObdcfnvYAopCBpH+2KtRj605yGdA5ImaikX+q4cswI08Q==</DQ><InverseQ>rjbWceA/opSH6vVyFe0pXVmkZ9inYg/Arhqz7RVtKH4sohulSYQPLacayk2YqlxKq2fRG5mGvt1k+ZHKS6KfsA==</InverseQ><D>rmngm1bOIqK8eK7OweD8yxX89ekXqlloraXtvPBJr1HpXz9q+jt9X1agP1C6YEEm9hD6D8wQXe2eauGWp0LkCa16XzlE3bGxYk/jQUq9IzvKIwRMAXLHNG+ZlJMeQ3lN/Tql7v2dyxztblmc8Qgb3sK7lBqvoQaj2AP/06pcrQE=</D></RSAKeyValue>";

        /// <summary>
        /// 依照帶入會員編號的不同，動態取得轉帳資訊與暱稱記錄清單。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GetTransferInfo()
        {
            //DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int memberId = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
            int vipLevel = Convert.ToInt32(HttpContext.Current.Request.Form["VIP_Level"]);

            var result = TransferEntities.MemberTransferInfo(memberId);

            return new
            {
                Info = new
                {
                    // 是否一般會員
                    IsGeneralMember = (vipLevel == 0),
                    // 總點數
                    TotalPoint = result.TotalPoint,
                    // 可轉點數
                    FreePoint = result.FreePoint,
                    // 轉點上限
                    TransferMax = result.TransferMax,
                    // 鎖定點數
                    LockPoint = result.CreditCardLockPoint,
                    // 鎖定分鐘
                    LockDate = DateTime.Now.AddDays(-7).ToString("yyyy/MM/dd HH:mm"),// DateTime.Now.AddMinutes(-result.CreditCardLockMinute).ToString("yyyy/MM/dd HH:mm")
                    //轉帳手續費%
                    Transfee = result.Transfee
                },
                TargetList = from i in TransferEntities.GetMemberTransferTarget(memberId)
                             select new
                             {
                                 // 會員Key
                                 No = TransferNoEncrypt(i.TransToMemberID, memberId),
                                 // 會員暱稱
                                 Name = i.NickName,
                                 // 是否在線
                                 IsOnline = i.IsOnline == 1
                             }
            };
        }

        /// <summary>
        /// 依照帶入會員編號的不同，動態刪除轉帳暱稱記錄。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public void DelTransferTarget()
        {
            //DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 會員編號
            int memberId = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int targetMemberId = TransferNoDecrypt(no, memberId);

            if (targetMemberId != -1)
            {
                TransferEntities.DelMemberTransferTarget(new DelMemberTransferTargetInputModel()
                {
                    MemberID = memberId,
                    TransToMemberID = targetMemberId
                });
            }
        }

        /// <summary>
        /// 依照帶入會員編號的不同，動態會員轉點。
        /// </summary>
        /// <returns>
        /// 0:申請成功，請等候對方確認。
        /// 1001: 請輸入轉帳對象！
        /// 1002: 請輸入轉帳點數！
        /// 1003: 單筆轉帳點數最低為老幣 2 萬點
        /// 1004: DB訊息(DB執行失敗)
        /// 1005: FS訊息(DB執行成功 + 開洗分失敗)
        /// </returns>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic MemberTransfer(MemberTransferApplyInputModel data)
        {
            //DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int resultCode = 0;
            string resultMessage = "";

            if (string.IsNullOrEmpty(data.NickNameReceive))
            {
                resultCode = 1001;
                resultMessage = "請輸入轉帳對象！";
            }
            else if (data.ChangePoints <= 0)
            {
                resultCode = 1002;
                resultMessage = "點數必須大於0！";
            }
            else if (data.ChangePoints < 20000)
            {
                resultCode = 1003;
                resultMessage = "單筆轉帳點數最低為老幣 2 萬點！";
            }
            else
            {
                data.MemberIDSend = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));

                var result = TransferEntities.MemberTransferApply(data);

                switch (result.RESULT)
                {
                    case 0:
                        if (result.EventID != null)
                        {
                            string fsResult = FSCommander.FS_AS_CREDIT_CHANGE
                            (
                                Convert.ToInt32(result.EventID),
                                result.Target_MemberID,
                                Convert.ToDecimal(result.ChangePoints),
                                result.PointType
                            );

                            if (fsResult == "0")
                            {
                                // DB執行成功 + 開洗分成功
                                resultCode = 0;
                                resultMessage = "您已成功送出轉帳訊息！";
                            }
                            else
                            {
                                // DB執行成功 + 開洗分失敗
                                resultCode = 1005;
                                resultMessage = fsResult;
                                log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("MemberTransfer::DB執行成功 + 開洗分失敗\r\nMemberIDSend={0}\r\nNickNameReceive{1}\r\nChangePoints={2}\r\nEventID={3}\r\nFSResult={4}", data.MemberIDSend, data.NickNameReceive, data.ChangePoints, result.EventID, fsResult);
                            }
                        }
                        else
                        {
                            // DB執行成功 + EventID IS NULL
                            resultCode = 0;
                            resultMessage = "您已成功送出轉帳訊息！";
                            log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("MemberTransfer::EventID IS NULL\r\nMemberIDSend={0}\r\nNickNameReceive={1}\r\nChangePoints={2}\r\n", data.MemberIDSend, data.NickNameReceive, data.ChangePoints);
                        }
                        break;
                    default:
                        // DB執行失敗
                        resultCode = 1004;
                        resultMessage = result.ResultMSG;
                        log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("MemberTransfer::DB執行失敗\r\nMemberIDSend={0}\r\nNickNameReceive={1}\r\nChangePoints={2}\r\nDBResultCode={3}\r\nDBResultMessage={4}", data.MemberIDSend, data.NickNameReceive, data.ChangePoints, result.RESULT, result.ResultMSG);
                        break;
                }
            }


            return new
            {
                ResultCode = resultCode,
                ResultMessage = resultMessage
            };
        }

        /// <summary>
        /// 依照帶入會員編號的不同，動態取得會員轉帳紀錄。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferMaster(TransferMasterInputModel data)
        {
            //DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int totalReocrd = 0;
            data.MemberID = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));

            // 取得目前資料行的應顯示狀態 (1:同意和取消按鈕 2:確認傳送點數按鈕 other:文字狀態)
            Func<bool, int, int, string> stateAnalysis = (isSender, sendStatus, receiveStatus) =>
            {
                if (isSender)
                {
                    switch (sendStatus)
                    {
                        case 6: return "2";
                        case 9: return "取消交易";
                        case 11: return "交易成功";
                        case 28:
                        case 29: return "交易逾時";
                        case 10:
                        default: return "等待同意中";
                    }
                }
                else
                {
                    switch (receiveStatus)
                    {
                        case 10: return "1";
                        case 9: return "取消交易";
                        case 11: return "交易成功";
                        case 28:
                        case 29: return "交易逾時";
                        case 8:
                        default: return "等待傳送中";
                    }
                }
            };

            // 取得目前交易是否已完成
            Func<bool, int, int, bool> stateIsComplete = (isSender, sendStatus, receiveStatus) =>
            {
                if (isSender)
                {
                    return new int[] { 9, 11, 28, 29 }.Contains(sendStatus);
                }
                else
                {
                    return new int[] { 9, 11, 28, 29 }.Contains(receiveStatus);
                }
            };

            return new
            {
                List = from i in TransferEntities.TransferMaster(data, out totalReocrd)
                       select new
                       {
                           // 同意/取消/確認 交易的 Key (加密過)
                           No = TransferNoEncrypt(i.TransferNO, data.MemberID),
                           // 交易編號
                           TransferNo = i.TransferNO,
                           // 此帳號是否是發送方
                           IsSender = (i.MemberID == data.MemberID),
                           // 交易建立日期
                           CreateDate = i.CreateDate.ToString("yyyy/MM/dd HH:mm:ss"),
                           // 發送方暱稱
                           SendName = i.NickNameSend,
                           // 接收方暱稱
                           ReceiveName = i.NickNameReceive,
                           // 轉帳點數
                           Points = i.Points,
                           // 目前狀態 (1:同意和取消按鈕 2:確認傳送點數按鈕 other:文字狀態)
                           Status = stateAnalysis((i.MemberID == data.MemberID), i.DepositsStateA, i.DepositsStateB)
                       },
                TotalRecord = totalReocrd
            };


        }

        /// <summary>
        /// 依照帶入會員編號的不同，動態取得會員轉帳明細紀錄(目前代交易編號就可直接查，需再加上驗證)。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferDetail()
        {
            //DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 會員編號
            int memberId = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberId);

            if (transferNo == -1)
            {
                return new string[] { };
            }

            return from i in TransferEntities.TransferDetail(transferNo)
                   select new
                   {
                       // 交易建立日期
                       CreateDate = i.CreateDate.ToString("yyyy/MM/dd HH:mm:ss"),
                       // 交易詳細內容
                       Memo = i.TransferMEMO == null ? "" : i.TransferMEMO
                   };
        }

        /// <summary>
        /// 接收方會員同意/取消轉帳，需帶入會員編號來做解碼。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferConfirm(TransferConfirmInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 是否成功
            bool isSuccess = false;
            // 是否重新取得點數
            bool isRegainPoint = false;
            // 訊息
            string message = "";

            // 會員編號
            int memberId = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberId);

            if (!new int[] { 1, 2 }.Contains(data.YN))
            {
                message = "請選擇交易動作";
            }
            else if (transferNo == -1)
            {
                message = "無此交易序號";
            }
            else
            {
                data.TransferNO = transferNo;
                data.MemberID2 = context.Session.MemberID;

                var result = TransferEntities.PartialTransferConfirm(data);

                switch (result.RESULT)
                {
                    case 0:     // 接收方確認同意
                        message = "轉帳交易成功";
                        isSuccess = true;
                        isRegainPoint = true;
                        break;
                    case 10:
                        // 接收方拒絕，且傳送方在線上
                        // 呼叫Server 歸還點數
                        message = FSCommander.FS_AS_CREDIT_CHANGE
                        (
                            Convert.ToInt32(result.EventID),
                            Convert.ToInt32(result.Target_MemberID),
                            Convert.ToInt32(result.ChangePoints),
                            result.PointType
                        );

                        if (message == "0")
                        {
                            message = "轉帳交易取消";
                            isSuccess = true;
                        }
                        else
                        {
                            log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("TransferConfirm::FS_AS_CREDIT_CHANGE Fail\r\nEventID={0}\r\nTarget_MemberID={1}\r\nChangePoints={2}\r\n", result.EventID, result.Target_MemberID, result.ChangePoints);
                        }
                        break;
                    case 12:    // 接收方拒絕，且傳送方不在線上
                        message = "轉帳交易取消";
                        isSuccess = true;
                        break;
                    case 4:
                        message = "無此交易序號";
                        break;
                    case 2:
                    case 7:
                        message = "交易已取消";
                        break;
                    case 8:
                        message = "交易已完成";
                        break;
                    case 9:
                        message = "接收方已同意過";
                        break;
                    case 11:
                        message = "退款失敗";
                        break;
                    default:
                        message = "交易失敗";
                        break;
                }

				MessageBody sendbody = new MessageBody();

				//string sqlstr = "select Game_Branch.dbo.FN_APP_GetMemberID(N'" + data. + "')";
				string rid = data.MemberID2.ToString();//SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.Text, sqlstr).ToString();
				if (data.YN == 1)
				{
					#region 發送訊息給發起者

					sendbody.body = new MessageBody.Body();
					sendbody.body.jid = CommonUtility.GetJiD(result.Target_MemberID.ToString()); //取得接收方JID
					sendbody.body.serial = data.TransferNO.ToString();
					sendbody.body.nickname = result.Target_MemberID.ToString();
					sendbody.body.status = "狀態：";
					sendbody.body.status_content = "同意交易";
					sendbody.body.step = 3;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					string sendbodyjson = JsonConvert.SerializeObject(sendbody);
					IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(rid), sendbodyjson);//發送至發送方
					#endregion
				}
				else
				{
					#region 發送訊息給接收者
					sendbody.body = new MessageBody.Body();
					sendbody.body.jid = CommonUtility.GetJiD(rid);//取得發起者JID
					sendbody.body.serial = data.TransferNO.ToString();
					sendbody.body.nickname = data.MemberID2.ToString();
					sendbody.body.status = "狀態：";
					sendbody.body.status_content = "取消交易";
					sendbody.body.step = 4;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					string sendbodyjson = JsonConvert.SerializeObject(sendbody);
					IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(result.Target_MemberID), sendbodyjson);	//發送至接收方		
					#endregion

					#region 發送訊息給發起者
					sendbodyjson = string.Empty;
					sendbody.body = new MessageBody.Body();
					sendbody.body.jid = CommonUtility.GetJiD(result.Target_MemberID.ToString());//取得接收方JID
					sendbody.body.serial = data.TransferNO.ToString();
					sendbody.body.nickname = data.MemberID2.ToString();
					sendbody.body.status = "狀態：";
					sendbody.body.status_content = "取消交易";
					sendbody.body.step = 4;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					sendbodyjson = JsonConvert.SerializeObject(sendbody);
					IMGatewayUtility.Instance.UserTalk(Convert.ToInt32(rid), sendbodyjson);//發送至 交易發送方
					#endregion
				}

            }

            return new
            {
                // 是否成功
                IsSuccess = isSuccess,
                // 是否重新取得點數
                IsRegainPoint = isRegainPoint,
                // 訊息
                Message = message
            };
        }

        /// <summary>
        /// 發送方會員確認轉帳，需帶入會員編號來做解碼。
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic TransferVerify(TransferVerifyInputModel data)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            // 是否成功
            bool isSuccess = false;
            // 是否重新取得點數
            bool isRegainPoint = false;
            // 訊息
            string message = "";

            // 會員編號
            int memberId = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberId);

            if (string.IsNullOrEmpty(data.VerificationCode))
            {
                message = "請輸驗證碼";
            }
            else if (transferNo == 0)
            {
                message = "無此交易序號";
            }
            else
            {
                data.TransferNO = transferNo;
                data.MemberID = context.Session.MemberID;

                var result = TransferEntities.PartialTransferVerify(data);

                switch (result.RESULT)
                {
                    case 0:
                        message = "轉帳交易成功";
                        isSuccess = true;
                        break;
                    case 1:
                        message = "驗證失敗";
                        break;
                    case 2:
                        message = "手機驗證逾時";
                        break;
                    case 4:
                        message = "此筆交易己取消";
                        break;
                    case 5:
                        message = "此筆交易己完成";
                        break;
                    case 6:
                        message = "您輸入的驗證碼有誤，請重新輸入";
                        break;
                    case 7:
                        message = "交易序號不存在";
                        break;
                    case 8:
                        // 接收方在線上，通知Server
                        message = FSCommander.FS_AS_CREDIT_CHANGE
                        (
                            Convert.ToInt32(result.EventID),
                            Convert.ToInt32(result.Target_MemberID),
                            Convert.ToDecimal(result.ChangePoints),
                            result.PointType
                        );

                        if (message == "0")
                        {
                            message = "轉帳交易成功";
                            isSuccess = true;
                        }
                        else
                        {
                            log4net.LogManager.GetLogger(typeof(BankController)).DebugFormat("TransferVerify::FS_AS_CREDIT_CHANGE Fail\r\nEventID={0}\r\nTarget_MemberID={1}\r\nChangePoints={2}\r\n", result.EventID, result.Target_MemberID, result.ChangePoints);
                        }
                        break;
                    case 99:
                    default:
                        message = "驗證失敗";
                        break;
                }
				if (isSuccess)
				{

					MessageBody sendbody = new MessageBody();
					string sendbodyjson = string.Empty;
					//string sqlstr = "select Game_Branch.dbo.FN_APP_GetMemberID(N'" + base.InputData.NicknameReceive + "')";
					//string rid = SqlHelper.ExecuteScalar(WebConfig.ConnectionString, CommandType.Text, sqlstr).ToString();
					#region 發送訊息給發起者
					sendbody.body = new MessageBody.Body();
					sendbody.body.jid = CommonUtility.GetJiD(data.MemberID.ToString());
					sendbody.body.serial = data.TransferNO.ToString();
					sendbody.body.nickname = "";
					sendbody.body.status = "轉出老幣：";
					sendbody.body.status_content = "";
					sendbody.body.step = 5;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					sendbodyjson = JsonConvert.SerializeObject(sendbody);
					IMGatewayUtility.Instance.UserTalk(data.MemberID, sendbodyjson);
					#endregion

					#region 發送訊息給接收者
					sendbodyjson = string.Empty;
					sendbody.body = new MessageBody.Body();
					sendbody.body.jid = CommonUtility.GetJiD(data.MemberID.ToString());
					sendbody.body.serial = data.TransferNO.ToString();
					sendbody.body.nickname = data.MemberID.ToString();
					sendbody.body.status = "轉入老幣：";
					sendbody.body.status_content ="";
					sendbody.body.step = 5;
					sendbody.header = new MessageBody.Header();
					sendbody.header.type = "COMPOSITE";
					sendbody.header.style = "TRANSFER_CONFIRM";

					sendbodyjson = JsonConvert.SerializeObject(sendbody);
					IMGatewayUtility.Instance.UserTalk(data.MemberID, sendbodyjson);
					#endregion

				}
            }

            return new
            {
                // 是否成功
                IsSuccess = isSuccess,
                // 是否重新取得點數
                IsRegainPoint = isRegainPoint,
                // 訊息
                Message = message
            };
        }

        /// <summary>
        /// 發送驗證碼簡訊
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic SendSMSCode()
        {
            //DataContext context = new DataContext(HttpContext.Current.Request.Form["Platform"]);
            int memberID = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberID);
            return TransferEntities.SendSMSCode(new SendSMSCodeInputModel { MemberID = memberID, TransferNO = transferNo });
        }

        /// <summary>
        /// RD環境測試用，自動填入驗證碼
        /// </summary>
        [AcceptVerbs("Post")]
        [AjaxOnly]
        [CheckLoginState(true)]
        public dynamic GetVerifyCode()
        {
#if(!Online)
            // 會員編號
            int memberId = Convert.ToInt32(CommonUtility.RSADecrypt(HttpContext.Current.Request.Form["MemberID"], RsaPrivateKey));
            // 交易編號(加密過)
            string no = HttpContext.Current.Request.Form["No"];
            // 交易編號(解密過)
            int transferNo = TransferNoDecrypt(no, memberId);

            try
            {
                System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[]
				{
					new System.Data.SqlClient.SqlParameter("@MemberID", memberId),
					new System.Data.SqlClient.SqlParameter("@TransferNO", transferNo)
				};

                System.Data.SqlClient.SqlDataReader objDr = GS.Utilities.SqlHelper.ExecuteReader
                (
                    WebConfig.ConnectionString,
                    System.Data.CommandType.StoredProcedure,
                    "NSP_GameWeb_A_Member_TrandeVerify_VerificationCode_Get",
                    param
                );

                while (objDr.Read())
                {
                    return new { result = objDr["VerificationCode"].ToString() };
                }
            }
            catch
            {
                return "";
            }
            return new { result = "" };
#else
            return "";
#endif

        }
        #endregion

        /// <summary>
        /// PaymentGateway Req103 通知更新訂單 / 交易開分
        /// </summary>
        /// <returns></returns>
        [AcceptVerbs("Post")]
        public System.Net.Http.HttpResponseMessage UpdateOrder()
        {
            // 這裡用來把客戶交易結果寫入商店自己的資料庫中.
            StringBuilder sbResult = new StringBuilder();
            try
            {

                // 初始化 API
                PaymentClientMvc payingHandler = new PaymentClientMvc
                (
                    WebConfig.PaymentGatewayHost
                    , WebConfig.PaymentStoreID
                    , WebConfig.PaymentEncryptKey
                );

                // 解讀交易結果
                PayingEventArgs resultPG = payingHandler.ReceiveOrderResult();


                // 商店端自訂訂單編號
                sbResult.AppendLine("SSOrderID: " + resultPG.SSOrderID);
                // PaymentGateway端產生的訂單編號
                sbResult.AppendLine("PGOrderID: " + resultPG.PGOrderID);
                // 交易結果代碼
                sbResult.AppendLine("ResultCode: " + resultPG.ResultCode);
                // 交易失敗原因
                sbResult.AppendLine("ResultText: " + resultPG.ResultText);
                // 銀行授權識別碼
                sbResult.AppendLine("BankApproveCode: " + resultPG.BankApproveCode);
                // 銀行交易結果代碼
                sbResult.AppendLine("BankErrorCode: " + resultPG.BankErrorCode);
                // 銀行端交易失敗原因
                sbResult.AppendLine("BankErrorText: " + resultPG.BankErrorText);
                // 銀行端傳回之資訊
                sbResult.AppendLine("BankResultExtension: " + resultPG.BankResultExtension);
                // 實際使用之金流編號
                sbResult.AppendLine("CommitPaymentTypeID: " + resultPG.CommitPaymentTypeID);
                // 實際使用金額
                sbResult.AppendLine("CommitAmount: " + resultPG.CommitAmount);

                List<UpdateOrderResultModel> resultModel = BankEntities.UpdateOrder
                (
                    new UpdateOrderInputModel()
                    {
                        PGOrderID = resultPG.PGOrderID,
                        SSOrderID = resultPG.SSOrderID,
                        CommitPaymentTypeID = resultPG.CommitPaymentTypeID,
                        ResultCode = resultPG.ResultCode,
                        ResultText = resultPG.ResultText,
                        CommitAmount = resultPG.CommitAmount,
                        BankApproveCode = resultPG.BankApproveCode,
                        BankErrorCode = resultPG.BankErrorCode,
                        BankErrorText = resultPG.BankErrorText,
                        BankResultExtension = resultPG.BankResultExtension
                    }
                );
                foreach (UpdateOrderResultModel obj in resultModel)
                {
                    if (obj.ResultCode == 0)
                    {
                        // 成功後，把錢轉點數
                        long EventID = obj.EventID;
                        int MemberIDTarget = obj.Target_MemberID;
                        int PointType = obj.PointType;
                        decimal Point = obj.ChangePoints;
                        string ResultMsg = GS.ServerCommander.FSCommander.FS_AS_CREDIT_CHANGE(EventID, MemberIDTarget, Point, PointType);
                        if (ResultMsg != "0")
                        {
                            log4net.LogManager.GetLogger(typeof(BankController)).ErrorFormat
                            (
                                "UpdateOrder 執行Server開洗分失敗: ResultMsg: {0}",
                                ResultMsg
                            );
                        }
                    }
                    else
                    {
                        log4net.LogManager.GetLogger(typeof(BankController)).ErrorFormat
                        (
                            "UpdateOrder SP- NSP_GameWeb_A_UpdateOrder: 執行失敗。回傳ResultCode: {0}, ResultMsg: {1}",
                            obj.ResultCode,
                            obj.ResultMsg
                        );
                    }
                    sbResult.AppendLine("StoreDBResultCode: " + obj.ResultCode);
                    sbResult.AppendLine("StoreDBResultMsg: " + obj.ResultMsg);
                }
            }
            catch (Exception ex)
            {
                sbResult.AppendLine("Store Error ExceptionMessage: " + ex.Message);
                log4net.LogManager.GetLogger(typeof(BankController)).Error
                (
                    string.Format("UpdateOrder ErrorMessage:{0}", ex.Message),
                    ex
                );
            }

            return new System.Net.Http.HttpResponseMessage()
            {
                Content = new System.Net.Http.StringContent(
                    sbResult.ToString(),
                    Encoding.UTF8,
                    "text/plain"
                )
            };
        }
    }
}
