﻿using GameWeb_Models.Models.Other;
using HOTW_GameWebMVC.Attributes.WebAPI;
using System.Linq;
using System.Web.Http;

namespace HOTW_GameWebMVC.Controllers.Api
{
    public class OtherController : ApiController
    {
        [AcceptVerbs("Get")]
        [AjaxOnly]
        public dynamic CityData()
        {
            return from i in OtherEntities.CityData()
                   where i.CityID != 0
                   orderby i.SortNo ascending
                   group new { i.ZipCode, i.ZoneID, i.ZoneName } by new { i.CityID, i.CityName } into j
                   select new
                   {
                       // 縣市編號
                       CityID = j.Key.CityID,
                       // 縣市名稱
                       CityName = j.Key.CityName,
                       // 縣市內所屬的鄉鎮市
                       ZoneList = j
                   };
        }

        [HttpGet]
        public string UpdateCommand(string CmdID)
        {
            if (!string.IsNullOrEmpty(CmdID))
            {
                switch (CmdID)
                {
                    case "101":
                        HOTW_GameWebMVC.MvcApplication.ReadIsMaintain();
                        break;
                }
            }
            return "";
        }
    }
}
