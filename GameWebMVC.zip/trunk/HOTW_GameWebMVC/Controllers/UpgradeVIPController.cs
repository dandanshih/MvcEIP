﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Controllers
{
    public class UpgradeVIPController : Controller
    {

        public ActionResult InputMobile()
        {
            return View();
        }

		public ActionResult MobileAuthentication()
		{
			return View();
		}

		public ActionResult CancelMobileAuthentication()
		{
			return View();
		}

		public ActionResult MobileAuthenticationFrequently()
		{
			return View();
		}
    }
}
