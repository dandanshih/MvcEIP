﻿using GS.Web.CommunityGateway.StoreAPI;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.Attributes;
using System;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Controllers
{
    public class CWLoginController : Controller
    {
		private string GetCWType(CommunityType cType)
		{
			switch (cType)
			{
				case CommunityType.Facebook:
					return "@fb";
				case CommunityType.GameBase:
					return "@gamebase";
				case CommunityType.Google:
					return "@google";
				case CommunityType.MSN:
					return "@msn";
				case CommunityType.Plurk:
					return "@plurk";
				case CommunityType.Twitter:
					return "@twitter";
				case CommunityType.Weibo:
					return "@weibo";
				case CommunityType.Yahoo:
					return "@yahoo";
				case CommunityType.Gogobox:
					return "@gogobox";
				case CommunityType.iPart:
					return "@ipart";
				case CommunityType.Yam:
					return "@yam";
				case CommunityType.YahooOfficial:
					return "@yahoo";
				case CommunityType.Play168:
					return "@play168";
				case CommunityType.GameCard:
					return "@gamecard";
				//case CommunityType.Wayi:
				//    return "@wayi";
				case CommunityType.Yahoo_Community_Game:
					return "@yahoocwgame";
				case CommunityType.DynaStar:
					return "@dynastar";
				default:
					return "";
			}
		}

        //
        // GET: /CWLogin/
		public ActionResult Index()
        {			
            return View();
        }

		[HttpPost]
		[CheckLoginState]
		public ContentResult Index(string submitButton, string redirectID)
		{
			CommunityClient cc = new CommunityClient
			(
				WebConfig.CommunityStoreID,
				WebConfig.CommunityStoreKey,
				WebConfig.CommunityHost,
				true
			);

            // 將參數設定初始化
            CWLoginParamsMgt.Clear();

			if (!string.IsNullOrEmpty(redirectID))
			{
				switch (redirectID)
				{
					case "1":
						CWLoginParamsMgt.RedirectPage = "/Web/Game/MiniList.aspx";
						break;
				}
			}

			ContentResult result = new ContentResult();
			CommunityType cType = (CommunityType)Enum.Parse(typeof(CommunityType), submitButton);
			result.Content = cc.GetInitialJsCmd(cType, CommunityEventType.Login);
			result.ContentType = "text/html";

			return result;
		}

        /// <summary>
        /// 活動頁專用的社群介接入口
        /// </summary>
        /// <param name="submitButton"></param>
        [AcceptVerbs("Post")]
        [CheckLoginState]
        public ContentResult ActionCommunityLogin(string submitButton)
        {
            CommunityClient cc = new CommunityClient
            (
                WebConfig.CommunityStoreID,
                WebConfig.CommunityStoreKey,
                WebConfig.CommunityHost,
                true
            );

            // 設定導回的活動頁
            CWLoginParamsMgt.Clear();
            CWLoginParamsMgt.RedirectPage = Request.UrlReferrer.ToString();

            ContentResult result = new ContentResult();
            CommunityType cType = (CommunityType)Enum.Parse(typeof(CommunityType), submitButton);
            result.Content = cc.GetInitialJsCmd(cType, CommunityEventType.Login);
            result.ContentType = "text/html";

            return result;
        }

		[AcceptVerbs(HttpVerbs.Post)]
        public ActionResult FinalLogin()
        {
            // 要導回的活動頁
            string cwActionNextPage = CWLoginParamsMgt.RedirectPage;
            // 清除所有參數
            CWLoginParamsMgt.Clear();

			if (Session["IsLogin"] != null && Session["PGOrderID"] == null)
			{
				return Redirect("/Mvc");
			}

			CommunityClient cc = new CommunityClient
			(
				WebConfig.CommunityStoreID,
				WebConfig.CommunityStoreKey,
				WebConfig.CommunityHost,
				true
			);
			
			CommunityInfo info = cc.Final();
			// 社群登入 (0: 成功, 其他: 失敗)
			if (info.ResultCode != 0)
			{
				log4net.LogManager.GetLogger(typeof(CWLoginController)).DebugFormat("社群登入失敗，錯誤代碼: {0}，錯誤訊息: {1}", info.ResultCode, info.ResultText);
				info.ResultText = "登入失敗！";
				if (Session["CWNextPage"] != null)
				{
					string NextPage = Session["CWNextPage"].ToString();
					Session.Remove("CWNextPage");
					Session["CWReturnResultCode"] = info.ResultCode;
					Session["CWReturnResultMsg"] = info.ResultText;
					return Redirect(NextPage);
				}
				else
				{
					Session["CWReturnResultCode"] = info.ResultCode;
					Session["CWReturnResultMsg"] = info.ResultText;
					return Redirect("/MVC");
					//ScriptManager.RegisterStartupScript(Page, GetType(), "alertErr", "alert('" + info.ResultText + "'); location.href='/Index.aspx';", true);
				}
			}
			if (Session["IsGoAD"] != null)
			{
				Session["CWUserInfo"] = info;
				string NextPage = Session["CWNextPage"].ToString();
				Session.Remove("CWNextPage");
				return Redirect(NextPage);
			}
			
			string CWSourceName = GetCWType(info.CType);
			MemberInfo minfo = new MemberInfo
			{
				MemberAccount = string.Format("{0}{1}", info.UserID, CWSourceName),
				SourceName = CWSourceName.Replace("@", ""),
				Platform = "Web",
				ClientIP = Request.UserHostAddress,
				FSLoginType = LoginType.Community
			};

			if (Session["IsLogin"] != null && Session["PGOrderID"] != null)
			{
				string account = string.Format("{0}{1}", info.UserID, CWSourceName);
				if (Session["MemberAccount"].ToString() != account)
				{
					return Redirect("/Mvc");
				}
			}
			MemberResultData rData = MemberEventUtility.CWLogin(minfo);

			if (rData.ResultCode == 1)
			{
				if (Session["PGOrderID"] != null)
				{
					return Redirect("/Web/MyCard/Req101.aspx");
				}
			}
			else if (rData.ResultCode >= 995 && rData.ResultCode <= 1000) 
			{
				if (minfo.MemberID != 0)
				{
					// 帳號轉移需要用到會員編號及帳號(強制期以後會需要)
					if (Session["IsLogin"] != null)
					{
						log4net.LogManager.GetLogger(typeof(CWLoginController)).Error("會員已登入並覆蓋掉玩家資訊。");
					}
					Session["MemberID"] = minfo.MemberID;
					Session["MemberAccount"] = minfo.MemberAccount;
				}
				Session["CWLoginResultCode"] = rData.ResultCode;
				Session["CWLoginResultMsg"] = rData.ResultMsg;
			}
			else
			{
				Session["CWLoginResultCode"] = rData.ResultCode;
				Session["CWLoginResultMsg"] = rData.ResultMsg;
			}

            if (cwActionNextPage != null)
            {
                return Redirect(cwActionNextPage);
            }

			return Redirect("/Mvc");
		}
    }
}
