﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Controllers
{
    public class AccountTransferController : Controller
    {

        public ActionResult VIPRegister()
        {
            return View();
        }

		public ActionResult Register()
		{
			return View();
		}

		public ActionResult MobileAuthentication()
		{
			return View();
		}

		public ActionResult MobileAuthenticationFrequently()
		{
			return View();
		}

		public ActionResult MobileAuthenticationSuccess()
		{
			return View();
		}

		public ActionResult MobileAuthenticationFail()
		{
			return View();
		}

		public ActionResult FindAccount()
		{
			return View();
		}

		public ActionResult TransferFinish()
		{
			return View();
		}

		public ActionResult Login()
		{
			return View();
		}

		
    }
}
