﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HOTW_GameWebMVC.EnumType
{
	[Flags]
	public enum FlagsDataType
	{
		/// <summary>
		/// 最新消息。
		/// </summary>
		News = 1,
		/// <summary>
		/// 彩金贏分排行榜。
		/// </summary>
		RankByJp = 2,
		/// <summary>
		/// 百大富豪排行榜。
		/// </summary>
		RankByMoney = 4,
		/// <summary>
		/// 單局贏分排行榜。
		/// </summary>
		RankBySingleWin = 8,
		/// <summary>
		/// 總贏分排行榜。
		/// </summary>
		RankByTotalWin = 16,
		/// <summary>
		/// 遊戲列表
		/// </summary>
		Games = 32,
		/// <summary>
		/// 我的專屬消息
		/// </summary>
		PersonalNews = 64,
		/// <summary>
		/// 我的榮譽史
		/// </summary>
		PersonalGlory = 128,
		/// <summary>
		/// 卡別資訊
		/// </summary>
		PersonalCard = 256,
		/// <summary>
		/// 會員資訊
		/// </summary>
		MemberData = 512,
		/// <summary>
		/// 最新排行榜
		/// </summary>
		RankVIPGame = 2048,
		/// <summary>
		/// 我的好友
		/// </summary>
		MyFriend = 4098,
        /// <summary>
        /// 柏青哥排行榜
        /// </summary>
        RankByPachinko = 8196
	}
}