﻿
namespace HOTW_GameWebMVC.AppLibs
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;
	using System.Web;

	/// <summary>
	/// MessageBody 訊息內容
	/// </summary>
	public class MessageBody
	{
		/// <summary>
		/// Gets or sets 標頭
		/// </summary>
		public Header header { get; set; }


		/// <summary>
		/// Gets or sets 資料
		/// </summary>
		public Body body { get; set; }

		/// <summary>
		/// MessageBody header
		/// </summary>
		public class Header
		{
			/// <summary>
			/// Gets or sets 訊息type
			/// </summary>
			public string type { get; set; }

			/// <summary>
			/// Gets or sets 訊息style
			/// </summary>
			public string style { get; set; }
		}

		/// <summary>
		/// MessageBody Body
		/// </summary>
		public class Body
		{
			/// <summary>
			/// Jid 發送方Jid
			/// </summary>
			public string jid { get; set; }

			/// <summary>
			/// 轉帳序號
			/// </summary>
			public string serial { get; set; }

			/// <summary>
			/// 發送方暱稱
			/// </summary>
			public string nickname { get; set; }

			/// <summary>
			/// 流程狀態(中文顯示)
			/// </summary>
			public string status { get; set; }

			/// <summary>
			/// 流程狀態
			/// </summary>
			public string status_content { get; set; }

			/// <summary>
			/// 步驟
			/// </summary>
			public int step { get; set; }
		}

		#region mark
		///// <summary>
		///// MessageBody _data
		///// </summary>
		//public class _data
		//{
		//	/// <summary>
		//	/// Gets or sets 使用者編號
		//	/// </summary>
		//	public long MemberId { get; set; }

		//	/// <summary>
		//	/// Gets or sets 使用者暱稱
		//	/// </summary>
		//	public string NickName { get; set; }

		//	/// <summary>
		//	/// Gets or sets 卡別
		//	/// </summary>
		//	public int CardType { get; set; }

		//	/// <summary>
		//	/// Gets or sets 諮詢編號
		//	/// </summary>
		//	public long ConsultationId { get; set; }

		//	/// <summary>
		//	/// Gets or sets 諮詢狀態
		//	/// </summary>
		//	public int State { get; set; }

		//	/// <summary>
		//	/// Gets or sets 訊息
		//	/// </summary>
		//	public string Msg { get; set; }

		//	/// <summary>
		//	/// Gets or sets 訊息發話者
		//	/// </summary>
		//	public string SpeakersJid { get; set; }

		//	/// <summary>
		//	/// Gets or sets 日期時間
		//	/// </summary>
		//	public string Datetime { get; set; }

		//	/// <summary>
		//	/// Gets or sets 訊息狀態
		//	/// </summary>
		//	public string MsgState { get; set; }

		//	/// <summary>
		//	/// Gets or sets 來源Jid
		//	/// </summary>
		//	public string SourceJid { get; set; }

		//	/// <summary>
		//	/// Gets or sets 目標Jid
		//	/// </summary>
		//	public string TargetJid { get; set; }
		//}
		#endregion

		



	}

	/// <summary>
	/// ChatType
	/// </summary>
	public enum ChatType
	{
		/// <summary>
		/// 錯誤
		/// </summary>
		ERROR,

		/// <summary>
		/// 系統訊息 & 時間戳記
		/// </summary>
		SYSTEM,

		/// <summary>
		/// 複合訊息
		/// </summary>
		COMPOSITE,

		/// <summary>
		/// 對方發言
		/// </summary>
		OTHER_SPEAK,

		/// <summary>
		/// 自己發言
		/// </summary>
		MY_SPEAK,
	}

	/// <summary>
	/// ChatStyle
	/// </summary>
	public enum ChatStyle
	{
		/// <summary>
		/// 文字 (含表情符號)
		/// </summary>
		TEXT,

		/// <summary>
		/// 動態貼圖
		/// </summary>
		GIF,

		/// <summary>
		/// 圖片
		/// </summary>
		PICTURE,

		/// <summary>
		/// 語音
		/// </summary>
		VOICE,

		/// <summary>
		/// 客服廣告
		/// </summary>
		CS_ADVERTISE,

		/// <summary>
		/// 轉帳
		/// </summary>
		TRANSFER_CONFIRM,
	}
}