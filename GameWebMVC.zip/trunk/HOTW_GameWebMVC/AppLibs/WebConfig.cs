﻿using System.Configuration;
using System.Web;

namespace HOTW_GameWebMVC.AppLibs
{
	public static class WebConfig
	{
		// 連線字串
		public static string ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
		public static string WorthConnectionString = ConfigurationManager.ConnectionStrings["WorthConnectionString"].ConnectionString;
		public static string SMSConnectionString = ConfigurationManager.ConnectionStrings["SMSDBConnectionString"].ConnectionString;
		public static string CPAConnectionString = ConfigurationManager.ConnectionStrings["CPAConnectionString"].ConnectionString;
		public static string ASPStateConnectionString = ConfigurationManager.ConnectionStrings["ASPStateConnectionString"].ConnectionString;
		public static string SysConnectionString = ConfigurationManager.ConnectionStrings["SysConnectionString"].ConnectionString;
		public static string IMConnectionString = ConfigurationManager.ConnectionStrings["IMConnectionString"].ConnectionString;

		// 環境別
        public static string Platform = ConfigurationManager.AppSettings["Platform"];
		public static string CSEmail = ConfigurationManager.AppSettings["CSEmail"].ToString();
		public static string FBDomain = ConfigurationManager.AppSettings["FBDomain"].ToString();
		public static string Domain = ConfigurationManager.AppSettings["Domain"].ToString();
		public static string MGTDomain = ConfigurationManager.AppSettings["MGTDomain"].ToString();
        public static string LogWebDomain = ConfigurationManager.AppSettings["LogWebDomain"].ToString();
		public static string IMGatewayUrl = ConfigurationManager.AppSettings["IMGatewayUrl"].ToString();
		public static string IMServer2Url = ConfigurationManager.AppSettings["IMServer2Url"].ToString();

        // public static string LoHOTW_GameWebMVCDomain = ConfigurationManager.AppSettings["LoHOTW_GameWebMVCDomain"].ToString();
		public static string CdnURL 
		{ 
			get 
			{
				//string protocol = "http";
				//if (HttpContext.Current.Request.Url.Port == int.Parse(ConfigurationManager.AppSettings["SSLPort"].ToString()))
				//{
				//	protocol = "https";
				//}
				//return protocol + "://" + ConfigurationManager.AppSettings["CdnURL"].ToString() + (string.IsNullOrEmpty(ConfigurationManager.AppSettings["DateCode"]) ? "" : ("/" + ConfigurationManager.AppSettings["DateCode"])); 
				return "//" + ConfigurationManager.AppSettings["CdnURL"].ToString() + (string.IsNullOrEmpty(ConfigurationManager.AppSettings["DateCode"]) ? "" : ("/" + ConfigurationManager.AppSettings["DateCode"])); 
			} 
		}
		public static string DataInfoUrl = ConfigurationManager.AppSettings["DataInfoUrl"].ToString();
		public static string Activity = ConfigurationManager.AppSettings["Activity"].ToString();
		public static string CookieDomain = ConfigurationManager.AppSettings["CookieDomain"].ToString();
		public static string AppID = ConfigurationManager.AppSettings["AppID"].ToString();
		public static string IndexPage = ConfigurationManager.AppSettings["IndexPage"].ToString();
		public static string LoginURL = ConfigurationManager.AppSettings["LoginURL"];
		public static string DateCode = ConfigurationManager.AppSettings["DateCode"];

		// FaceBook
		public static string FBAppID = ConfigurationManager.AppSettings["FBAppID"];
		public static string FBAppSecret = ConfigurationManager.AppSettings["FBAppSecret"];
		public static string FBAppCanvasPage = ConfigurationManager.AppSettings["FBAppCanvasPage"];
		public static string FBPerms = ConfigurationManager.AppSettings["FBPerms"].ToString();

		// Payment Gateway
		public static string PaymentGatewayHost = ConfigurationManager.AppSettings["Payment_PaymentGatewayHost"].ToString();
		public static string PaymentStoreID = ConfigurationManager.AppSettings["Payment_StoreID"].ToString();
		public static string PaymentEncryptKey = ConfigurationManager.AppSettings["Payment_EncryptKey"].ToString();
		public static string PaymentOrderReportUrl = ConfigurationManager.AppSettings["Payment_OrderReportUrl"].ToString();
		public static string PaymentOrderFinalUrl = ConfigurationManager.AppSettings["Payment_OrderFinalUrl"].ToString();
		public static string PaymentOrderRecordedUrl = ConfigurationManager.AppSettings["Payment_OrderRecordedUrl"];
		//public static string PaymentOrderFinalforMobile = ConfigurationManager.AppSettings["Payment_OrderFinalMobileUrl"].ToString();

		// CommunityGateway
		public static string CommunityHost = ConfigurationManager.AppSettings["CommunityHost"];
		public static string CommunityStoreID = ConfigurationManager.AppSettings["CommunityStoreID"];
		public static string CommunityStoreKey = ConfigurationManager.AppSettings["CommunityStoreKey"];

		public static string MemCachedPlatformID = ConfigurationManager.AppSettings["MemCachedPlatformID"];

        // 113 平台
        public static string Online113_Key = ConfigurationManager.AppSettings["Online113_Key"];
        public static string Online113_AllowIPs = ConfigurationManager.AppSettings["Online113_AllowIPs"];
		public static string Online113_User_AllowIPs = ConfigurationManager.AppSettings["Online113_User_AllowIPs"];
	}
}