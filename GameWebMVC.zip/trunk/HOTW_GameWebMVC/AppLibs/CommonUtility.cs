﻿using GS.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
	public class CommonUtility : IRequiresSessionState
	{
		#region public
		/// <summary>
		/// RSA 加密。
		/// </summary>
		/// <param name="data">要加密的資料。</param>
		/// <param name="key">公鑰 xml 字串。</param>
		/// <returns></returns>
		public static string RSAEncrypt(string data, string xmlString)
		{
			string result = "";

			RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(1024);

			rsa.FromXmlString(xmlString);
			byte[] aryData = Encoding.ASCII.GetBytes(data);
			byte[] aryResult = rsa.Encrypt(aryData, false);
			result = BitConverter.ToString(aryResult).Replace("-", "");

			return result;
		}

		/// <summary>    
		/// RSA 解密。
		/// </summary>    
		/// <span name="hexString"></span>加密後 Hex String。</param>    
		/// <span name="xmlString"></span>私鑰 xml 字串。</param>    
		/// <returns></returns>    
		public static string RSADecrypt(string hexString, string xmlString)
		{
			try
			{
				RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(1024);
				rsa.FromXmlString(xmlString);
				byte[] s = new byte[hexString.Length / 2];
				int j = 0;
				for (int i = 0; i < hexString.Length / 2; i++)
				{
					s[i] = Byte.Parse(hexString[j].ToString() + hexString[j + 1].ToString(), System.Globalization.NumberStyles.HexNumber);
					j += 2;
				}
				return Encoding.ASCII.GetString(rsa.Decrypt(s, false));
			}
			catch
			{
				return "";
			}
		}

		/// <summary>        
		/// AES 加密。       
		/// </summary>        
		/// <param name="text">要加密的字串。</param>        
		/// <param name="key">加密的 Key。</param>        
		/// <param name="iv">加密的 IV。</param>        
		/// <returns></returns>        
		public static string AESEncrypt(string text, string key, string iv)
		{
			RijndaelManaged aes = new RijndaelManaged();
			aes.KeySize = 128;
			aes.BlockSize = 128;
			byte[] bData = UTF8Encoding.UTF8.GetBytes(text);
			aes.Key = UTF8Encoding.UTF8.GetBytes(key);
			aes.IV = UTF8Encoding.UTF8.GetBytes(iv);
			aes.Mode = CipherMode.CBC;
			aes.Padding = PaddingMode.PKCS7;

			ICryptoTransform iCryptoTransform = aes.CreateEncryptor();
			byte[] bResult = iCryptoTransform.TransformFinalBlock(bData, 0, bData.Length);

			//return Convert.ToBase64String(bResult);		// 回傳 base64
			return ByteToHex(bResult);				// 回傳 16 進制
		}

		/// <summary>        
		/// AES 解密。
		/// </summary>        
		/// <param name="text"></param>        
		/// <param name="key"></param>        
		/// <param name="iv"></param>        
		/// <returns></returns>        
		public static string AESDecrypt(string text, string key, string iv)
		{
			RijndaelManaged aes = new RijndaelManaged();
			aes.KeySize = 128;
			aes.BlockSize = 128;
			// byte[] bData = Convert.FromBase64String(text);	   // base64 解密
			byte[] bData = HexToByte(text);                  // 16 進制轉 byte
			aes.Key = UTF8Encoding.UTF8.GetBytes(key);
			aes.IV = UTF8Encoding.UTF8.GetBytes(iv);
			aes.Mode = CipherMode.CBC;
			aes.Padding = PaddingMode.PKCS7;

			ICryptoTransform iCryptoTransform = aes.CreateDecryptor();
			byte[] bResult = iCryptoTransform.TransformFinalBlock(bData, 0, bData.Length);
			return Encoding.UTF8.GetString(bResult);
		}

		/// <summary>        
		/// 隨機產生密鑰。        
		/// </summary>        
		/// <returns></returns>        
		public static string GeneralKey(int n)
		{
			char[] arrChar = new char[]{           
				'a','b','d','c','e','f','g','h','i','j','k','l','m','n','p','r','q','s','t','u','v','w','z','y','x',           
				'0','1','2','3','4','5','6','7','8','9',           
				'A','B','C','D','E','F','G','H','I','J','K','L','M','N','Q','P','R','T','S','V','U','W','X','Y','Z'          
			};

            // 產生隨機種子
            byte[] bytes = new byte[4];
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(bytes);
            int randomSeed = BitConverter.ToInt32(bytes, 0);

			StringBuilder num = new StringBuilder();
            Random rnd = new Random(randomSeed);
			for (int i = 0; i < n; i++)
			{
				num.Append(arrChar[rnd.Next(0, arrChar.Length)].ToString());
			}

			return num.ToString();
		}

		// 16 進制轉 byte
		public static byte[] HexToByte(string data)
		{
			data = data.Replace(" ", "");

			byte[] comBuffer = new byte[data.Length / 2];

			for (int i = 0; i < data.Length; i += 2)
				comBuffer[i / 2] = (byte)Convert.ToByte(data.Substring(i, 2), 16);

			return comBuffer;
		}

		// byte 轉 16 進制。
		public static string ByteToHex(byte[] comByte)
		{
			StringBuilder builder = new StringBuilder(comByte.Length * 3);

			foreach (byte data in comByte)
				builder.Append(Convert.ToString(data, 16).PadLeft(2, '0').PadRight(3, ' '));

			return builder.ToString().ToUpper().Replace(" ", "");
		}

		/// <summary>
		/// Post。
		/// </summary>
		/// <param name="url">網址。</param>
		/// <param name="postData">Post 資料。(Example：dataA=1&dataB=2)</param>
		/// <returns></returns>
		public static string Post(string url, string postData)
		{
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
			byte[] bytesData = System.Text.Encoding.UTF8.GetBytes(postData);
			req.Method = "POST";
			req.ContentType = "application/x-www-form-urlencoded";
			req.ContentLength = bytesData.Length;

			using (Stream stream = req.GetRequestStream())	// 取得資料流
			{
				stream.Write(bytesData, 0, bytesData.Length);	// 送出資料流 
				stream.Close();
			}

			// 取得回傳的資料
			HttpWebResponse res = (HttpWebResponse)req.GetResponse();
			StreamReader sr = new StreamReader(res.GetResponseStream(), System.Text.Encoding.UTF8);
			string result = sr.ReadToEnd();
			sr.Close();
			res.Close();

			return result;
		}

		/// <summary>
		/// Post。
		/// </summary>
		/// <param name="url">網址。</param>
		/// <param name="postData">Post 資料。(Example：dataA=1&dataB=2)</param>
		/// <returns></returns>
		public static string Post(string url, string postData, string contentType = "")
		{
			HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
			byte[] bytesData = System.Text.Encoding.UTF8.GetBytes(postData);
			req.Method = "POST";
			req.ContentType = string.IsNullOrEmpty(contentType) ? "application/x-www-form-urlencoded" : contentType;
			req.ContentLength = bytesData.Length;

			using (Stream stream = req.GetRequestStream())	// 取得資料流
			{
				stream.Write(bytesData, 0, bytesData.Length);	// 送出資料流 
				stream.Close();
			}
			string result = "";
			// 取得回傳的資料
			using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
			{
				StreamReader sr = new StreamReader(res.GetResponseStream(), System.Text.Encoding.UTF8);
				result = sr.ReadToEnd();
				sr.Close();
				res.Close();
			}
			return result;
		}

		public static TResult JsonPost<TResult>(string url, object data)
		{
			var jss = new System.Web.Script.Serialization.JavaScriptSerializer();
			string postData = jss.Serialize(data);
			string result = Post(url, postData, "application/json");
			return jss.Deserialize<TResult>(result);
		}

		/// <summary>
		/// 簡訊發送的性質種類
		/// </summary>
		public enum SMSRequestTypes
		{
			/// <summary>
			/// 用來測試簡訊功能
			/// </summary>
			Test = 0,
			/// <summary>
			/// 新申請會員帳號的手機驗證
			/// </summary>
			NewMemberAuth = 1,
			/// <summary>
			/// 忘記密碼, 傳送新密碼
			/// </summary>
			ForgetPassword = 2,
			/// <summary>
			/// 轉帳交易
			/// </summary>
			PointTransfer = 3,
			/// <summary>
			/// 重新認證
			/// </summary>
			MemberReAUTH = 4,
			/// <summary>
			/// 系統警告
			/// </summary>
			SysAlert = 99
		}

		/// <summary>
		/// 立即發送簡訊
		/// </summary>
		/// <param name="destAddr">目的號碼</param>
		/// <param name="msgContent">簡訊內容</param>
		/// <param name="requestType">簡訊種類</param>
		/// <param name="requestID">此則簡訊的關聯編號，用來記載為其他相關聯應用的編號</param>
		public static void SendSMS(string destAddr, string msgContent, SMSRequestTypes requestType, string requestID)
		{

#if (Online || Debug)
			string strSMSServer_MsgID = "";

			SqlParameter[] param = 
			{
				new SqlParameter("@APPID", "SH095_ONLINE"),
				new SqlParameter("@DestAddr", destAddr),
				new SqlParameter("@MsgContent", msgContent),
				new SqlParameter("@RequestType", requestType.ToString()),
				new SqlParameter("@RequestID", requestID),
				new SqlParameter("@RequestIP", HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]),
				new SqlParameter("@SMSServer_MsgID", SqlDbType.UniqueIdentifier)
			};

			param[6].Direction = ParameterDirection.Output;

			SqlHelper.ExecuteNonQuery
			(
				WebConfig.SMSConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_S_SMSRequest_New",
				param
			);

			strSMSServer_MsgID = param[6].Value.ToString();
#endif
		}

        /// <summary>
        /// 發 Emaiil。
        /// </summary>
        /// <param name="subject">主旨</param>
        /// <param name="body">內容</param>
        /// <param name="address">接收的 Email 信箱，不帶值則通知客服</param>
        public static void SendEmail(string subject, string body, string address = null)
        {
            address = (address == null) ? WebConfig.CSEmail : address;

            MailMessage objMsg = new MailMessage();
            objMsg.To.Add(address);
            objMsg.Subject = subject;
            objMsg.Body = body;
            objMsg.IsBodyHtml = true;
            SmtpClient client = new SmtpClient();
            client.Send(objMsg);
        }

		/// <summary> 產生Jid
		/// </summary>
		/// <param name="memberId"></param>
		/// <returns></returns>
		public static string GetJiD(string memberId)
		{
			return string.Format
			(
				"{0}@{1}",
				memberId,
				WebConfig.IMServer2Url
			);
		}
		#endregion
	}
}