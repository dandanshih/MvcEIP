﻿using System;
using System.Web;
using System.Web.Mvc;
using HOTW_GameWebMVC.AppLibs;

namespace HOTW_GameWebMVC
{
    public class DynamicController : Controller, ISGTPage
    {
        public string Platform
        {
            get
            {
                return ControllerContext.RouteData.Values["area"].ToString();
            }
        }

        protected override ViewResult View(string viewName, string masterName, object model)
        {
            object area = ControllerContext.RouteData.Values["area"];
            object action = ControllerContext.RouteData.Values["action"].ToString();

            if (string.IsNullOrEmpty(viewName) && area != null)
            {
                viewName = string.Format("{0}/{1}", area, action);
            }

            return base.View(viewName, masterName, model);
        }
    }
}
