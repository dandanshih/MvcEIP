﻿using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using SGT.Web.Session.HOTW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

public static class SGTHtmlHelper
{
    public static MvcHtmlString SGTPage(this HtmlHelper helper, string KoName)
    {
        return helper.Partial("~/Views/Shared/_SGTPage.cshtml", KoName);
    }

    public static MvcHtmlString MenuPartial(this HtmlHelper helper, string partialViewName, params int[] args)
    {
        return helper.Partial(partialViewName, args);
    }

    public static SessionData Session(this HtmlHelper helper, string Platform)
    {
        SGTHttpContext context = SGTHttpContext.Current(Platform);
        return context.Session;
    }
}