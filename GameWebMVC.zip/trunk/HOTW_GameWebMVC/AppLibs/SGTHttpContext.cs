﻿using HOTW_GameWebMVC.AppLibs.DataHelper;
using SGT.Web.Session.HOTW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
    public interface ISGTPage
    {
        string Platform { get; }
    }

    public class SGTHttpContext : IRequiresSessionState
    {
        #region Properties
        private MemCachedContext d_context
        {
            get
            {
                return HttpContext.Current.Items["CurrentContext"] as MemCachedContext;
            }
            set
            {
                HttpContext.Current.Items["CurrentContext"] = value;
            }
        }

        private SessionData sessionData
        {
            get
            {
                return HttpContext.Current.Items["CurrentSession"] as SessionData;
            }
            set
            {
                HttpContext.Current.Items["CurrentSession"] = value;
            }
        }

        private string platform { get; set; }
        #endregion

        public static SGTHttpContext Current(string Platform)
        {
            return new SGTHttpContext(Platform);
        }

        private SGTHttpContext(string Platform)
        {
            this.platform = Platform;
            if (sessionData == null)
            {
                if (Platform == "Online113")
                {
                    string key = string.Format
                    (
                        "{0}_{1}_{2}_{3}",
                        Platform,
                        HttpContext.Current.Session.SessionID,
                        "MemberInfo",
                        WebConfig.Platform
                    );
                    this.d_context = new MemCachedContext(key);
                    this.sessionData = d_context.Session;
                    if (this.sessionData == null)
                    {
                        this.sessionData = new SessionData() { IsLogin = false };
                    }
                }
                else
                {
                    HttpContext context = HttpContext.Current;
                    if (context.Session["IsLogin"] == null)
                    {
                        this.sessionData = new SessionData() { IsLogin = false };
                    }
                    else
                    {
                        var currentSession = new SessionData();

                        currentSession.LoginKey = Convert.ToInt32(context.Session["LoginKey"]);
                        currentSession.TriDESUniID = context.Session["TriDESUniID"].ToString();
                        currentSession.TriDESKey = context.Session["TriDESKey"].ToString();
                        currentSession.LoginEventFlag = Convert.ToInt64(context.Session["ActivityMask"]);
                        currentSession.OnlineID = Convert.ToInt64(context.Session["OnlineID"]);
                        currentSession.IsLogin = true;
                        currentSession.MemberID = Convert.ToInt32(context.Session["MemberID"]);
                        currentSession.MemberAccount = context.Session["MemberAccount"].ToString();
                        currentSession.MemberPassword = context.Session["MemberPassword"] == null ? string.Empty : context.Session["MemberPassword"].ToString();
                        currentSession.MobileLast4Num = context.Session["MobileLast4Num"] == null ? string.Empty : context.Session["MobileLast4Num"].ToString();
                        currentSession.SourceName = context.Session["RegisterType"] == null ? string.Empty : context.Session["RegisterType"].ToString();
                        currentSession.EggUrl = context.Session["EggUrl"].ToString();
                        currentSession.Level = Convert.ToInt32(context.Session["Level"]);
                        currentSession.UserPhoto = context.Session["UserPhoto"].ToString();
                        currentSession.AllPicFilePath = context.Session["AllPicFilePath"].ToString();
                        currentSession.MemberAttribute = Convert.ToInt64(context.Session["MemberAttribute"]);
                        currentSession.NickName = context.Session["NickName"].ToString();
                        currentSession.DataInfoUrl = context.Session["DataInfoUrl"].ToString();
                        currentSession.MemberUIFlag = Convert.ToInt64(context.Session["MemberUIFlag"]);
                        currentSession.VIP_Level = Convert.ToInt32(context.Session["VIP_Level"]);
                        currentSession.WebLoginEventFlag = Convert.ToInt64(context.Session["WebLoginEventFlag"]);

                        currentSession.OtherData = (Dictionary<string, object>)context.Session["OtherData"];

                        this.sessionData = currentSession;
                    }
                }
            }
        }

        public SessionData Session
        {
            get
            {
                return this.sessionData;
            }
        }

        public void Save()
        {
            string Platform = this.platform;
            if (Platform == "Online113")
            {
                this.d_context.Save();
            }
            else
            {
                var currentSession = this.sessionData;
                var context = HttpContext.Current;
                //context.Session["LoginKey"] = CurrentSession.LoginKey;
                //context.Session["TriDESUniID"] = CurrentSession.TriDESUniID;
                //context.Session["TriDESKey"] = CurrentSession.TriDESKey;
                context.Session["ActivityMask"] = currentSession.LoginEventFlag;
                //context.Session["OnlineID"] = CurrentSession.OnlineID;
                //context.Session["MemberID"] = CurrentSession.MemberID;
                //context.Session["MemberAccount"] = CurrentSession.MemberAccount;
                //context.Session["MemberPassword"] = CurrentSession.MemberPassword;
                //context.Session["MobileLast4Num"] = CurrentSession.MobileLast4Num;
                //context.Session["RegisterType"] = CurrentSession.SourceName;
                context.Session["EggUrl"] = currentSession.EggUrl;
                context.Session["Level"] = currentSession.Level;
                context.Session["UserPhoto"] = currentSession.UserPhoto;
                context.Session["AllPicFilePath"] = currentSession.AllPicFilePath;
                context.Session["MemberAttribute"] = currentSession.MemberAttribute;
                context.Session["NickName"] = currentSession.NickName;
                //context.Session["DataInfoUrl"] = CurrentSession.DataInfoUrl;
                context.Session["MemberUIFlag"] = currentSession.MemberUIFlag;
                context.Session["VIP_Level"] = currentSession.VIP_Level;
                context.Session["WebLoginEventFlag"] = currentSession.WebLoginEventFlag;

                context.Session["OtherData"] = currentSession.OtherData;
            }
        }
    }
}
