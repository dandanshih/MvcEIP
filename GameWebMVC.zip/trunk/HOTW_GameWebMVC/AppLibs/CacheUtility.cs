﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HOTW_GameWebMVC.AppLibs
{
    public class CacheUtility
    {
        public static dynamic GetCache(Func<dynamic> func, string keyFormat, params object[] args)
        {
            return GetCache(func, 3, keyFormat, args);
        }

        public static dynamic GetCache(Func<dynamic> func, int cacheSeconds, string keyFormat, params object[] args)
        {
            string cacheName = string.Format(keyFormat, args);
            dynamic cacheData = HttpContext.Current.Cache[cacheName];
            
            if (cacheData == null)
            {
                cacheData = func();

                // 加入快取
                HttpContext.Current.Cache.Insert
                (
                    cacheName,
                    cacheData,
                    null,
                    DateTime.Now.AddSeconds(cacheSeconds),
                    System.Web.Caching.Cache.NoSlidingExpiration,
                    System.Web.Caching.CacheItemPriority.Normal,
                    null
                );
            }

            return cacheData;
        }
    }
}