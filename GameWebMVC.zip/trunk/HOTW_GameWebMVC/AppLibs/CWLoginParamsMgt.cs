﻿using System.Web;

namespace HOTW_GameWebMVC.AppLibs
{
    public class CWLoginParamsMgt
    {
        /// <summary>
        /// 登入後要轉至的活動頁。
        /// </summary>
        public static string RedirectPage
        {
            get { return HttpContext.Current.Session["RedirectActionPage"] != null ? HttpContext.Current.Session["RedirectActionPage"].ToString() : null; }
            set
            {
                if (value != null)
                {
                    HttpContext.Current.Session["RedirectActionPage"] = value;
                }
                else
                {
                    HttpContext.Current.Session.Remove("RedirectActionPage");
                }
            }
        }

        /// <summary>
        /// 初始化(全清空)。
        /// </summary>
        public static void Clear()
        {
            CWLoginParamsMgt.RedirectPage = null;
        }
    }
}