﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
	public enum EnumMemberAttribute
	{
		/// <summary>
		/// 1: 測試工具
		/// (身分)
		/// </summary>
		MEM_ATTR_IS_TESTER   = 1,

		/// <summary>
		/// 2: 可產生帳務
		/// (遊戲: 是否寫 MemberWinlose)
		/// </summary>
		MEM_ATTR_HAS_ACCOUNT  = 2,
								   
		/// <summary>
		/// 4: 可開桌
		/// (遊戲: 入桌判斷)
		/// </summary>
		MEM_ATTR_ALLOW_OPEN_TABLE = 4,
									   
		/// <summary>
		/// 8: 免費玩家帳號
		/// (遊戲: 特殊判斷)
		/// </summary>
		MEM_ATTR_IS_GUEST = 8,
							   
		/// <summary>
		/// 16: 可列入報表
		/// (DB 用)
		/// </summary>
		MEM_ATTR_ADD_IN_REPORT  = 16,
									  
		/// <summary>
		/// 32: VIP
		/// (身分)
		/// </summary>
		MEM_ATTR_IS_VIP = 32,
							  
		/// <summary>
		/// 64: 可加入排行榜
		/// (DB 用)
		/// </summary>
		MEM_ATTR_ADD_IN_RANK = 64,
								   
		/// <summary>
		/// 128: 可轉帳
		/// (DB 用)
		/// </summary>
		MEM_ATTR_ALLOW_TRANSPOINT = 128,

		/// <summary>
		/// 256: 可登遊戲
		/// (AS 用)
		/// </summary>
		MEM_ATTR_ALLOW_JOIN_GAME = 256,
										
		/// <summary>
		/// 1024: 可拉彩金
		/// (遊戲: 是否需要做彩金判斷)
		/// </summary>
		MEM_ATTR_ALLOW_GET_JP = 1024,
		
		/// <summary>
		/// 32768: 使用Ｕ幣
		/// (遊戲: 使用點數種類判斷)
		/// </summary>
		MEM_ATTR_USING_UPOINT = 32768,
									   
		/// <summary>
		/// 65536: 使用Ｈ幣
		/// (遊戲: 使用點數種類判斷)
		/// </summary>
		MEM_ATTR_USING_HPOINT = 65536,

		/// <summary>
		/// 131072: 會員需要重新認証
		/// </summary>
		MEM_ATTR_RE_CERTIFICATION = 131072,

		/// <summary>
		/// 262144: 永久停權
		/// </summary>
		MEM_ATTR_STOP_THE_RIGHT = 262144,

		/// <summary>
		/// 524288: 停權
		/// </summary>
		MEM_ATTR_PAUSE = 524288,

		/// <summary>
		/// 1048576: 密碼錯誤六次鎖定
		/// </summary>
		MEM_ATTR_PASSWORD_IS_INCORRECT_LOCKING = 1048576,

		/// <summary>
		/// 2097152: 網咖老闆
		/// </summary>
        MEM_ATTR_NET_CAFE_BOSS = 2097152,

        /// <summary>
        /// 8388608: 會員是否有五代紅利的功能(1/17 後註冊會員無五代紅利功能)
        /// </summary>
        MEM_ATTR_ALLOW_MEMBERBONUS = 8388608,

        /// <summary>
        /// 33554432: 是否為主帳號
        /// </summary>
        MEM_ATTR_IS_MOBILE_PRIMARY = 33554432,

        /// <summary>
        /// 67108864: 是否為子帳號
        /// </summary>
        MEM_ATTR_IS_MOBILE_SUB = 67108864
	}

	public class MemberAttribute : IRequiresSessionState
	{
		#region Private Properties
		private long _MemberFlag { get; set; }
		#endregion

		#region 建構式
		public static MemberAttribute Current 
		{
			get
			{
				return new MemberAttribute();
			}
		}
		
		private MemberAttribute()
		{
			if (HttpContext.Current.Session["MemberAttribute"] == null)
			{
				_MemberFlag = 0;
				return;
			}
			_MemberFlag = Convert.ToInt64(HttpContext.Current.Session["MemberAttribute"]);
		}

        public MemberAttribute(long memberAttribute)
        {
            _MemberFlag = memberAttribute;
        }
		#endregion

		#region Public Properties
		/// <summary>
		/// 遊戲幣別
		/// <para>1: 爽幣</para>
		/// <para>2: 老幣</para>
		/// <para>4: 體驗區</para>
		/// </summary>
		public int PointType
		{
			get
			{
				return IsHCoin ? 2 : IsUCoin ? 1 : 4;
			}
		}

		/// <summary>
        /// 是否為測試工具
        /// <para>列舉: MEM_ATTR_IS_TESTER</para>
		/// </summary>
		public bool IsTester
		{
			get
			{
				return (_MemberFlag & (long)EnumMemberAttribute.MEM_ATTR_IS_TESTER) > 0;
			}
		}

		/// <summary>
        /// 是否為體驗會員
        /// <para>列舉: MEM_ATTR_IS_GUEST</para>
		/// </summary>
		public bool IsGuest
		{
			get
			{
				return (_MemberFlag & (long)EnumMemberAttribute.MEM_ATTR_IS_GUEST) > 0;
			}
		}

		/// <summary>
        /// 是否為老幣會員
        /// <para>列舉: MEM_ATTR_USING_HPOINT</para>
		/// </summary>
		public bool IsHCoin
		{
			get
			{
				return (_MemberFlag & (long)EnumMemberAttribute.MEM_ATTR_USING_HPOINT) > 0;
			}
		}

		/// <summary>
        /// 是否為一般會員
        /// <para>列舉: MEM_ATTR_USING_UPOINT</para>
		/// </summary>
		public bool IsUCoin
		{
			get
			{
				return !IsHCoin && (_MemberFlag & (long)EnumMemberAttribute.MEM_ATTR_USING_UPOINT) > 0;
			}
		}

        /// <summary>
        /// 是否允許使用紅利
        /// <para>列舉: MEM_ATTR_ALLOW_MEMBERBONUS</para>
        /// </summary>
        public bool IsAllowMemberBonus
        {
            get
            {
                return (_MemberFlag & (long)EnumMemberAttribute.MEM_ATTR_ALLOW_MEMBERBONUS) > 0;
            }
        }

        /// <summary>
        /// 是否為主帳號
        /// <para>列舉: MEM_ATTR_IS_MOBILE_PRIMARY</para>
        /// </summary>
        public bool IsPrimary
        {
            get
            {
                return (_MemberFlag & (long)EnumMemberAttribute.MEM_ATTR_IS_MOBILE_PRIMARY) > 0;
            }
        }

        /// <summary>
        /// 是否為子帳號
        /// <para>列舉: MEM_ATTR_IS_MOBILE_SUB</para>
        /// </summary>
        public bool IsSecondary
        {
            get
            {
                return (_MemberFlag & (long)EnumMemberAttribute.MEM_ATTR_IS_MOBILE_SUB) > 0;
            }
        }
		#endregion
	}
}