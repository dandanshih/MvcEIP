﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace HOTW_GameWebMVC.AppLibs
{
    public class IMGatewayUtility
    {
        readonly string gatewayUrl = WebConfig.IMGatewayUrl;

        readonly string imUrl = WebConfig.IMServer2Url;

        private IMGatewayUtility() { }

        private string emptyGatewayUrlMsg = "error_emptygatewayurl";

        public static IMGatewayUtility Instance { get { return new IMGatewayUtility(); } }

        public struct ResultStruct
        {
            public string Result { get; set; }

            public string Jid { get; set; }
        }

        public struct MsgResultStruct
        {
            public string Result { get; set; }
        }

        #region Add User
        /// <summary>
        /// 新增IM 會員
        /// </summary>
        /// <param name="imAccount">IM 登入帳號(同MemberID)</param>
        /// <param name="imPassword">IM 登入密碼</param>
        /// <returns></returns>
        public ResultStruct UserAdd(string imAccount, string imPassword)
        {
            string apiUrl = "/Api/User/UserAdd";
            if (string.IsNullOrEmpty(gatewayUrl))
            {
                return new ResultStruct() { Result = this.emptyGatewayUrlMsg, Jid = string.Empty };
            }
            return CommonUtility.JsonPost<ResultStruct>
            (
                gatewayUrl + apiUrl,
                new { User = new { Server = imUrl, Account = imAccount, Password = imPassword } }
            );
        }
        #endregion

        #region Delete User
        /// <summary>
        /// 刪除IM 會員
        /// </summary>
        /// <param name="imAccount">IM 登入帳號(同MemberID)</param>
        /// <returns></returns>
        public ResultStruct UserDelete(string imAccount)
        {
            string apiUrl = "/Api/User/UserDelete";
            if (string.IsNullOrEmpty(gatewayUrl))
            {
                return new ResultStruct() { Result = this.emptyGatewayUrlMsg, Jid = string.Empty };
            }
            return CommonUtility.JsonPost<ResultStruct>
            (
                gatewayUrl + apiUrl,
                new { User = new { Server = imUrl, Account = imAccount } }
            );
        }
        #endregion

        #region Change User Password
        /// <summary>
        /// 更新IM 會員密碼
        /// </summary>
        /// <param name="imAccount">IM 登入帳號(同MemberID)</param>
        /// <param name="imPassword">新的IM 登入密碼</param>
        /// <returns></returns>
        public ResultStruct UserUpdate(string imAccount, string imPassword)
        {
            string apiUrl = "/Api/User/UserChangePWD";
            if (string.IsNullOrEmpty(gatewayUrl))
            {
                return new ResultStruct() { Result = this.emptyGatewayUrlMsg, Jid = string.Empty };
            }
            return CommonUtility.JsonPost<ResultStruct>
            (
                gatewayUrl + apiUrl,
                new { User = new { Server = imUrl, Account = imAccount, Password = imPassword } }
            );
        }
        #endregion

        #region Add/Update ChatRoom
        /// <summary>
        /// 建立 聊天室 房間
        /// </summary>
        /// <param name="ownerJid">建立會員 Jid</param>
        /// <param name="roomId">房間編號</param>
        /// <param name="roomName">房間名稱</param>
        /// <param name="isPublic">是否公開</param>
        /// <returns></returns>
        public ResultStruct ChatroomCreateOrUpdate(string ownerJid, string roomId, string roomName, int isPublic, int isKeepOffline)
        {
            string apiUrl = "/Api/ChatRoom/ChatroomCreate";
            if (string.IsNullOrEmpty(gatewayUrl))
            {
                return new ResultStruct() { Result = this.emptyGatewayUrlMsg, Jid = string.Empty };
            }
            return CommonUtility.JsonPost<ResultStruct>
            (
                gatewayUrl + apiUrl,
                new
                {
                    Room = new
                    {
                        Server = imUrl,
                        OwnerJID = ownerJid,
                        RoomID = roomId,
                        RoomName = roomName,
                        IsPublic = isPublic,
                        IsKeepOffline = isKeepOffline
                    }
                }
            );
        }
        #endregion

        #region Delete ChatRoom
        /// <summary>
        /// 刪除 聊天室 房間
        /// </summary>
        /// <param name="roomId">聊天室編號</param>
        /// <returns></returns>
        public ResultStruct ChatroomDelete(string roomId)
        {
            string apiUrl = "/Api/ChatRoom/ChatRoomDelete";
            if (string.IsNullOrEmpty(gatewayUrl))
            {
                return new ResultStruct() { Result = this.emptyGatewayUrlMsg, Jid = string.Empty };
            }
            return CommonUtility.JsonPost<ResultStruct>
            (
                gatewayUrl + apiUrl,
                new
                {
                    Room = new
                    {
                        Server = imUrl,
                        RoomID = roomId
                    }
                }
            );
        }
        #endregion

        #region Send Message To User
        public MsgResultStruct UserTalk(int account, string talkMessage)
        {
            string apiUrl = "/Api/User/UserTalk";
            log4net.LogManager.GetLogger(typeof(IMGatewayUtility)).DebugFormat("talkMessage: {0}", talkMessage);
            dynamic obj = new object[]
			{
				new { User = new { Server = imUrl ,Account=account ,TalkMessage=talkMessage} }
			};
            if (string.IsNullOrEmpty(gatewayUrl))
            {
                return new MsgResultStruct() { Result = this.emptyGatewayUrlMsg };
            }
            return CommonUtility.JsonPost<MsgResultStruct>
            (
                gatewayUrl + apiUrl,
                obj
            );
        }
        #endregion
    }
}