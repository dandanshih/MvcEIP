﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Security.Cryptography;

namespace HOTW_GameWebMVC.AppLibs
{
	public class EncryptUtility
	{
		private static string EncryKey = "abcdefg123456789";

		public static string Encrypt(string plainText)
		{
			byte[] keyArray = UTF8Encoding.UTF8.GetBytes(EncryKey);
			byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(plainText);

			RijndaelManaged rDel = new RijndaelManaged();
			rDel.Key = keyArray;
			rDel.Mode = CipherMode.ECB;
			rDel.Padding = PaddingMode.PKCS7;

			ICryptoTransform cTransform = rDel.CreateEncryptor();
			byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

			return Convert.ToBase64String(resultArray, 0, resultArray.Length);
		}

		public static string Decode(string cipherText)
		{
			byte[] keyArray = UTF8Encoding.UTF8.GetBytes(EncryKey);
			byte[] toEncryptArray = Convert.FromBase64String(cipherText);

			RijndaelManaged rDel = new RijndaelManaged();
			rDel.Key = keyArray;
			rDel.Mode = CipherMode.ECB;
			rDel.Padding = PaddingMode.PKCS7;

			ICryptoTransform cTransform = rDel.CreateDecryptor();
			byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

			return UTF8Encoding.UTF8.GetString(resultArray);
		}
	}
}