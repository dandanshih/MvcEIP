﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC
{
    public class CommunityController : Controller
    {
        protected string Platform
        {
            get
            {
                return RouteData.Values["platform"].ToString();
            }
        }

        protected override IAsyncResult BeginExecute(System.Web.Routing.RequestContext requestContext, AsyncCallback callback, object state)
        {
            if (requestContext.RouteData.Values["platform"].ToString() != "Online113")
            {
                requestContext.RouteData.Values["platform"] = "Online113";
            }
            return base.BeginExecute(requestContext, callback, state);
        }
    }
}
