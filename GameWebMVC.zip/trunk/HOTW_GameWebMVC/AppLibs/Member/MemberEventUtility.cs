﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HOTW_GameWebMVC.AppLibs
{
	public static class MemberEventUtility
	{
		#region Public Method
		/// <summary>
		/// 會員登入 + 設定Session
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>登入回傳值</returns>
		public static MemberResultData Login(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberLoginInitial());
			data.SetComponent(new SetMemberSession());
			data.SetComponent(new GetShortcutGift());
			data.SetComponent(new IMRegister());
			return data.MemberOperation();
		}

		/// <summary>
		/// 會員登出
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>登入回傳值</returns>
		public static MemberResultData Logout(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberLogout());

			return data.MemberOperation();
		}

		/// <summary>
		/// FrontServer 會員登出
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>登入回傳值</returns>
		public static MemberResultData FSLogout(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberFSLogout());

			return data.MemberOperation();
		}

		/// <summary>
		/// 會員登出 + 會員登入 + 設定Session
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>登入回傳值</returns>
		public static MemberResultData LogoutWithLogin(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberFSLogout());
			data.SetComponent(new MemberLoginInitial());			
			data.SetComponent(new SetMemberSession());
			
			return data.MemberOperation();
		}

		/// <summary>
		/// 會員註冊 + 會員登入 + 設定Session
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>登入回傳值</returns>
		public static MemberResultData Register(MemberInfo minfo)
		{
			
			UserMemberData data = new MemberDecorator();
			if (!string.IsNullOrEmpty(minfo.Mobile))
			{
				minfo.Mobile4Num = minfo.Mobile.Substring(minfo.Mobile.Length - 4);
			}
			else
			{
				minfo.Mobile4Num = " ";
			}
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberRegister());
			data.SetComponent(new RegistedADReport());
			data.SetComponent(new MemberLoginInitial());			
			data.SetComponent(new SetMemberSession());
			data.SetComponent(new IMRegister());

			return data.MemberOperation();
		}

		/// <summary>
		/// 會員註冊
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>回傳值</returns>
		public static MemberResultData WebRegister(MemberInfo minfo)
		{

			UserMemberData data = new MemberDecorator();
			if (!string.IsNullOrEmpty(minfo.Mobile))
			{
				minfo.Mobile4Num = minfo.Mobile.Substring(minfo.Mobile.Length - 4);
			}
			else
			{
				minfo.Mobile4Num = " ";
			}
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberRegister());
			data.SetComponent(new MemberAddBingoSN());
			data.SetComponent(new RegistedADReport());			

			return data.MemberOperation();
		}

		public static MemberResultData FBRegister(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberRegister());
			data.SetComponent(new RegistedADReport());
			return data.MemberOperation();
		}

		/// <summary>
		/// 帳號檢查 + 會員註冊 + 會員登入
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>登入回傳值</returns>
		public static MemberResultData CWLogin(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberExistCheck());
			MemberResultData rData = data.MemberOperation();

			if (rData.ResultCode == 1)
			{
				return MemberEventUtility.Login(minfo);
			}			
			else if (rData.ResultCode == 3)
			{
				rData = MemberEventUtility.Login(minfo);

				if (rData.ResultCode == 1)
				{
					rData.ResultCode = 996;
					rData.ResultMsg = "介接帳號宣傳期！";					
				}
				
				return rData;
			}
			else if (rData.ResultCode == 4)
			{				
				rData.ResultCode = 997;
				rData.ResultMsg = "介接帳號強制期！";
				rData.IsNext = false;
				return rData;
			}
			else if (rData.ResultCode == 5)
			{
				rData.ResultCode = 998;
				rData.ResultMsg = "介接帳號錯過期！";
				rData.IsNext = false;
				return rData;
			}
			else if (rData.ResultCode == 6)
			{
				rData.ResultCode = 999;
				rData.ResultMsg = "已轉換帳號！";
				rData.IsNext = false;
				return rData;
			}
			else if (rData.ResultCode == 7)
			{
				rData.ResultCode = 1000;
				rData.ResultMsg = "未註冊但已過強制期！";
				rData.IsNext = false;
				return rData;
			}
			else
			{

				//rData.ResultCode = 995;
				//rData.ResultMsg = "帳號不存在！";
				//rData.IsNext = false;
				//return rData;
				return MemberEventUtility.Register(minfo);
			}
		}

		/// <summary>
		/// 帳號檢查
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>登入回傳值</returns>
		public static MemberResultData ExistCheck(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberExistCheck());
			MemberResultData rData = data.MemberOperation();
			return rData;
		}

		/// <summary>
		/// 修改會員資料
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>狀態回傳值
		/// <para>0: 成功</para>
		/// <para>10: 成功且手機簡訊已發送 (需續做手機驗證)</para>
		/// <para>Other: 參照ResultMsg</para>
		/// </returns>
		public static MemberResultData EditData(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new EditMemberData());
			return data.MemberOperation();
		}

		/// <summary>
		/// 手機驗證碼驗證 + 會員登出
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>狀態回傳值</returns>
		public static MemberResultData MobileVaild(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberMobileVaild());
			data.SetComponent(new GetVipUpgradeGift());
			//data.SetComponent(new MemberLogout());
			return data.MemberOperation();
		}

		/// <summary>
		/// 重新寄送驗證簡訊
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>狀態回傳值
		/// <para>0: 成功</para>
		/// <para>1: 失敗</para>
		/// </returns>
		public static MemberResultData ReSendSMS(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new ReSendSMSCode());
			return data.MemberOperation();
		}

		/// <summary>
		/// 取消手機驗證
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>狀態回傳值
		/// <para>1: 成功</para>
		/// <para>0: 失敗</para>
		/// </returns>
		public static MemberResultData CancelMobileVaild(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new MemberCancelVaild());
			return data.MemberOperation();
		}

		public static MemberResultData GetShortcutGift()
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(null);
			data.SetComponent(new GetShortcutGift());
			return data.MemberOperation();
		}

		/// <summary>
		/// 社群帳號轉移新帳號
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>回傳值</returns>
		public static MemberResultData ATRegister(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			if (!string.IsNullOrEmpty(minfo.Mobile))
			{
				minfo.Mobile4Num = minfo.Mobile.Substring(minfo.Mobile.Length - 4);
			}
			else
			{
				minfo.Mobile4Num = " ";
			}
			data.SetMemberInfo(minfo);
			data.SetComponent(new ATMemberRegister());			
			if (string.IsNullOrEmpty(minfo.Mobile))
			{
				data.SetComponent(new ATGetGift());
			}
			return data.MemberOperation();
		}

		/// <summary>
		/// 帳號轉移手機驗證碼驗證
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>狀態回傳值</returns>
		public static MemberResultData ATMobileVaild(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new ATMemberMobileVaild());
			data.SetComponent(new GetVipUpgradeGift());			
			return data.MemberOperation();
		}

		/// <summary>
		/// 社群帳號轉移新帳號(錯過期)
		/// </summary>
		/// <param name="minfo">會員資訊</param>
		/// <returns>回傳值</returns>
		public static MemberResultData ATRegisterThird(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();			
			data.SetMemberInfo(minfo);
			data.SetComponent(new ATMemberRegister());
			data.SetComponent(new RegistedADReport());
			data.SetComponent(new MemberLoginInitial());
			data.SetComponent(new SetMemberSession());
			return data.MemberOperation();
		}

		public static MemberResultData ATFindAccount(MemberInfo minfo)
		{
			UserMemberData data = new MemberDecorator();
			data.SetMemberInfo(minfo);
			data.SetComponent(new ATFindMemberAccount());
			return data.MemberOperation();
		}

        public static MemberResultData ACCheckMobile(MemberInfo minfo)
        {
            UserMemberData data = new MemberDecorator();
            data.SetMemberInfo(minfo);
            data.SetComponent(new ACCheckMobile());
            return data.MemberOperation();
        }

        public static MemberResultData ACCheckVerifyCode(MemberInfo minfo)
        {
            UserMemberData data = new MemberDecorator();
            data.SetMemberInfo(minfo);
            data.SetComponent(new ACCheckVerifyCode());
            return data.MemberOperation();
        }

        public static MemberResultData ACMemberChange(MemberInfo minfo)
        {
            UserMemberData data = new MemberDecorator();
            data.SetMemberInfo(minfo);
            data.SetComponent(new ATMemberRegister());
            return data.MemberOperation();
        }

        /// <summary>
        /// 活動頁會員登入 + 設定Session
        /// </summary>
        /// <param name="minfo">會員資訊</param>
        /// <returns>登入回傳值</returns>
        public static MemberResultData ActionLogin(MemberInfo minfo)
        {
            UserMemberData data = new MemberDecorator();
            data.SetMemberInfo(minfo);
            data.SetComponent(new AppMemberCheck());
            data.SetComponent(new MemberLoginInitial());
            data.SetComponent(new SetMemberSession());
            data.SetComponent(new GetShortcutGift());
            return data.MemberOperation();
        }

        /// <summary>
        /// 檢查會員身份是否為活動頁註冊的特定會員
        /// </summary>
        /// <param name="minfo">會員資訊</param>
        /// <returns>登入回傳值</returns>
        public static MemberResultData AppMemberCheck(MemberInfo minfo)
        {
            UserMemberData data = new MemberDecorator();
            data.SetMemberInfo(minfo);
            data.SetComponent(new AppMemberCheck());
            return data.MemberOperation();
        }
		#endregion
	}
}