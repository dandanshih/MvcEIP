﻿//-----------------------------------------------------------------------
// <copyright file="MemberCheckInfo.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs.Member
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.SessionState;

    /// <summary>
    /// 檢查會員資訊
    /// </summary>
    public class MemberCheckInfo : IRequiresSessionState
    {
        #region 內部使用變數
        /// <summary>
        /// 會員Flag資訊
        /// </summary>
        private MemberAttribute mattr;

        /// <summary>
        /// 會員資料
        /// </summary>
        private SGTHttpContext context;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="MemberCheckInfo" /> class.
        /// </summary>
        /// <param name="platform">平台名稱</param>
        private MemberCheckInfo(string platform)
        {
            this.context = SGTHttpContext.Current(platform);
            this.mattr = new MemberAttribute(this.context.Session.MemberAttribute);
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets a value indicating whether: 僅一般會員
        /// </summary>
        public bool IsOnlyLevel0
        {
            get
            {
                return this.IsLevel0 && !this.mattr.IsSecondary;
            }
        }

        /// <summary>
        /// Gets a value indicating whether: 一般 + 子帳號 會員
        /// </summary>
        public bool IsLevel0AndSecondary
        {
            get
            {
                return this.IsLevel0 && this.mattr.IsSecondary;
            }
        }

        /// <summary>
        /// Gets a value indicating whether: 僅普卡 會員
        /// </summary>
        public bool IsOnlyLevel1
        {
            get
            {
                return this.IsLevel1 && !this.mattr.IsHCoin && !this.mattr.IsPrimary && !this.mattr.IsSecondary;
            }
        }

        /// <summary>
        /// Gets a value indicating whether: 普卡 + 手機驗證 + 主帳號 會員
        /// </summary>
        public bool IsLevel1AndParimary
        {
            get
            {
                return this.IsLevel1 && this.mattr.IsHCoin && this.mattr.IsPrimary && !this.mattr.IsSecondary;
            }
        }

        /// <summary>
        /// Gets a value indicating whether: 普卡 + 手機驗證 會員
        /// </summary>
        public bool IsLevel1AndMobile
        {
            get
            {
                return this.IsLevel1 && this.mattr.IsHCoin && !this.mattr.IsPrimary && !this.mattr.IsSecondary;
            }
        }

        /// <summary>
        /// Gets a value indicating whether: 普卡 + 子帳號 會員
        /// </summary>
        public bool IsLevel1AndSecondary
        {
            get
            {
                return this.IsLevel1 && this.mattr.IsHCoin && !this.mattr.IsPrimary && this.mattr.IsSecondary;
            }
        }

        /// <summary>
        /// Gets: 會員允許Flag
        /// <para>1:  僅一般會員</para>
        /// <para>2:  一般 + 子帳號 會員</para>
        /// <para>4:  僅普卡會員</para>
        /// <para>8:  普卡 + 子帳號 會員</para>
        /// <para>16: 普卡 + 手機驗證 會員</para>
        /// <para>32: 普卡 + 手機驗證 + 主帳號 會員</para>
        /// </summary>
        public long PermissionFlagID
        {
            get
            {
                if (this.IsOnlyLevel0)
                {
                    return 1;
                }

                if (this.IsLevel0AndSecondary)
                {
                    return 2;
                }

                if (this.IsOnlyLevel1)
                {
                    return 4;
                }

                if (this.IsLevel1AndSecondary)
                {
                    return 8;
                }

                if (this.IsLevel1AndMobile)
                {
                    return 16;
                }

                if (this.IsLevel1AndParimary)
                {
                    return 32;
                }

                return 0;
            }
        }

        /// <summary>
        /// Gets a value indicating whether: 是否為一般會員
        /// </summary>
        private bool IsLevel0
        {
            get
            {
                return this.context.Session.IsLogin && this.context.Session.VIP_Level == 0;
            }
        }

        /// <summary>
        /// Gets a value indicating whether: 是否為普卡會員以上
        /// </summary>
        private bool IsLevel1
        {
            get
            {
				return this.context.Session.IsLogin && this.context.Session.VIP_Level > 0;
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// New 出建構式
        /// </summary>
        /// <param name="platform">平台名稱</param>
        /// <returns>回傳資料</returns>
        public static MemberCheckInfo Current(string platform)
        {
            return new MemberCheckInfo(platform);
        }
        #endregion
    }
}