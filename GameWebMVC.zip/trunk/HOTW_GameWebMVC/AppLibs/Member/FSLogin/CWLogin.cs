﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GS.ServerCommander;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// CWLogin 的摘要描述
	/// </summary>
	public class CWLogin : IMemberLogin, IRequiresSessionState
	{
		#region IMemberLogin成員
		public FS_IIS_USER_LOGIN_R MemberLogin(MemberInfo _minfo)
		{
			string WID = (new Random().Next(0, 99).ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"));

			log4net.LogManager.GetLogger(typeof(CWLogin)).DebugFormat("CWLogin: {0}", WID);

			return FSCommander.FS_AS_IIS_LOGIN_BY_UNITED
			(
				_minfo.MemberAccount,
				_minfo.ClientIP,
				_minfo.Platform,
				HttpContext.Current.Session.SessionID,
				WID
			);
		}
		#endregion
	}
}