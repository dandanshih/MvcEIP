﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using GS.ServerCommander;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// WebReLogin 的摘要描述
	/// </summary>
	public class WebReLogin : IMemberLogin, IRequiresSessionState
	{
		#region IMemberLogin成員
		public FS_IIS_USER_LOGIN_R MemberLogin(MemberInfo _minfo)
		{
			string WID = (new Random().Next(0, 99).ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"));

			log4net.LogManager.GetLogger(typeof(WebReLogin)).DebugFormat("WebReLogin: {0}", WID);

			return FSCommander.FS_AS_USER_RELOGIN
			(
				_minfo.MemberID.ToString(),
				_minfo.ClientIP,
				_minfo.Platform,
				HttpContext.Current.Session.SessionID,
				WID
			);
		}
		#endregion
	}
}