﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GS.ServerCommander;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// IMemberLogin 的摘要描述
	/// </summary>
	public interface IMemberLogin
	{
		FS_IIS_USER_LOGIN_R MemberLogin(MemberInfo _minfo);
	}
}