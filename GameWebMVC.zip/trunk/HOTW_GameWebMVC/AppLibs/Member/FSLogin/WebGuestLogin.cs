﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using GS.ServerCommander;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// WebGuestLogin 的摘要描述
	/// </summary>
	public class WebGuestLogin : IMemberLogin, IRequiresSessionState
	{
		#region IMemberLogin成員
		public FS_IIS_USER_LOGIN_R MemberLogin(MemberInfo _minfo)
		{
			return FSCommander.FS_AS_IIS_LOGIN_BY_GUEST
			(
				HttpContext.Current.Session.SessionID,
				_minfo.ExperienceWID,
				_minfo.ClientIP
			);
		}
		#endregion
	}
}