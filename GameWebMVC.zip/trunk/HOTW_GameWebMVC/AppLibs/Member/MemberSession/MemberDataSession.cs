﻿//-----------------------------------------------------------------------
// <copyright file="MemberDataSession.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.SessionState;
    using GS.ServerCommander;
    using SGT.Web.Session.HOTW;
    using HOTW_GameWebMVC.AppLibs.DataHelper;
    using GameWeb_Models.Models.Sessions;

    /// <summary>
    /// MemberDataSession Class
    /// </summary>
    public class MemberDataSession : IMemberSession, IRequiresSessionState
    {
        #region Properties
		private HttpContext context { get; set; }

		private MemberInfo minfo { get; set; }

		private FS_IIS_USER_LOGIN_R LoginData { get; set; }
		#endregion

		#region Constructor
        public MemberDataSession(MemberInfo _minfo, FS_IIS_USER_LOGIN_R _LoginData)
		{
			this.context = HttpContext.Current;
			this.minfo = _minfo;
			this.LoginData = _LoginData;
		}
		#endregion

        public void SetMemberSession()
        {
            string sid = string.Format
            (
                "{0}_{1}_{2}_{3}",
                minfo.Platform,
                minfo.SessionID,
                "MemberInfo",
                WebConfig.Platform
            );

            DataContext context = new DataContext(minfo.Platform);
            //MemCachedContext context = new MemCachedContext(sid);
            //if (context.Session != null)
            //{
            //    // 如果Session 有資料 先砍掉
            //    SessionsEntities.DeleteSession(new DeleteSessionInputModel { SessionID = sid, LockCookie = -1 });
            //}
            
            if (context.Session == null)
            {
                context.Session = new SessionData();
            }

            context.Session.IsLogin = true;
            context.Session.LoginKey = LoginData.LoginKey;
            context.Session.TriDESUniID = LoginData.TriDESUniID;
            context.Session.TriDESKey = LoginData.TriDESKey;
            context.Session.LoginEventFlag = LoginData.LoginEventFlag;
            context.Session.OnlineID = LoginData.OnlineID;
            context.Session.MemberID = LoginData.MemberID;
            context.Session.MemberAccount = minfo.MemberAccount;
            context.Session.MemberPassword = minfo.MemberPassword;
            context.Session.MobileLast4Num = minfo.Mobile;
            context.Session.SourceName = minfo.SourceName;
            context.Session.EggUrl = LoginData.EggUrl;
            context.Session.Level = LoginData.Level;
            context.Session.UserPhoto = LoginData.UserPhoto;
            context.Session.AllPicFilePath = LoginData.AllPicFilePath;
            context.Session.MemberAttribute = LoginData.MemberAttribute;
            context.Session.NickName = LoginData.NickName;
            context.Session.DataInfoUrl = LoginData.DataInfoURL;
            context.Session.MemberUIFlag = LoginData.MemberUIFlag;
            context.Session.VIP_Level = LoginData.VIP_Level;
            context.Session.WebLoginEventFlag = LoginData.WebLoginEventFlag;
            context.Session.OtherData = new Dictionary<string, object>();
            
            context.Save();
        }
    }
}