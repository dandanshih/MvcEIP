﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HOTW_GameWebMVC.AppLibs
{
	public interface IMemberSession
	{
		void SetMemberSession();
	}
}