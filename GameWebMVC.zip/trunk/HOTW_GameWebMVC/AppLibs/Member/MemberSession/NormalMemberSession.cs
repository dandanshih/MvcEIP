﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;
using GS.ServerCommander;
using GS.Utilities;

namespace HOTW_GameWebMVC.AppLibs
{
	public class NormalMemberSession : IMemberSession, IRequiresSessionState
	{
		#region Properties
		private HttpContext context { get; set; }

		private MemberInfo minfo { get; set; }

		private FS_IIS_USER_LOGIN_R LoginData { get; set; }
		#endregion

		#region Constructor
		public NormalMemberSession(MemberInfo _minfo, FS_IIS_USER_LOGIN_R _LoginData)
		{
			this.context = HttpContext.Current;
			this.minfo = _minfo;
			this.LoginData = _LoginData;
		}
		#endregion

		#region IMemberSession成員
		public void SetMemberSession()
		{
			// 清掉訪客會員編號
			if (context.Session["GuestMemberID"] != null)
			{
				context.Session.Remove("GuestMemberID");
			}

			// 清掉訪客的線上編號
			if (context.Session["GuestOnlineID"] != null)
			{
				context.Session.Remove("GuestOnlineID");
			}
			
			// 登入後隨機產生的登入碼
			context.Session["LoginKey"] = LoginData.LoginKey;
			// 通訊加密編號
			context.Session["TriDESUniID"] = LoginData.TriDESUniID;
			// 通訊加密金鑰
			context.Session["TriDESKey"] = LoginData.TriDESKey;
			// 登入遊戲事件(活動)紀錄Flag
			context.Session["ActivityMask"] = LoginData.LoginEventFlag;
			// 辨識連線的唯一識別碼
			context.Session["OnlineID"] = LoginData.OnlineID;
			// 登入標記
			context.Session["IsLogin"] = true;
			// 最後動作時間
			context.Session["LastAction"] = DateTime.Now;
			// 會員編號
			context.Session["MemberID"] = LoginData.MemberID;
			// 會員帳號
			context.Session["MemberAccount"] = minfo.MemberAccount;
			// 會員密碼
			context.Session["MemberPassword"] = minfo.MemberPassword;
			// 手機後四碼
			context.Session["MobileLast4Num"] = minfo.Mobile;
			// 註冊類別
			context.Session["RegisterType"] = minfo.SourceName;
			// 蛋蛋檔名
			context.Session["EggUrl"] = LoginData.EggUrl;
			// 會員等級
			context.Session["Level"] = LoginData.Level;
			// 大頭照檔名
			context.Session["UserPhoto"] = LoginData.UserPhoto;
			// 網址
			context.Session["AllPicFilePath"] = LoginData.AllPicFilePath;
			// 衛星點網址
			context.Session["NDUrl"] = WebConfig.Domain;
			// 活動跳框判斷
			context.Session["LoginReceive"] = false;
			// 會員權限
			context.Session["MemberAttribute"] = LoginData.MemberAttribute;
			// 暱稱
			context.Session["NickName"] = LoginData.NickName;
			// 衛星DataInfo
			context.Session["DataInfoUrl"] = LoginData.DataInfoURL;
			// 會員操作介面 (0: 簡易, 1: 進階)
			context.Session["MemberUIFlag"] = LoginData.MemberUIFlag;
			// 會員等級星等
			context.Session["VIP_Level"] = LoginData.VIP_Level;
			// Web 使用之登入遊戲事件(活動)紀錄Flag
			context.Session["WebLoginEventFlag"] = LoginData.WebLoginEventFlag;
		}
		#endregion
	}
}