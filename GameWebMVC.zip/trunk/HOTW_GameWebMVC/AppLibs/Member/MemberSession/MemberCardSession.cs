﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;
using GS.ServerCommander;
using GS.Utilities;


namespace HOTW_GameWebMVC.AppLibs
{
	public class MemberCardSession: IMemberSession, IRequiresSessionState
	{
		#region Properties
		private HttpContext context { get; set; }

		private MemberInfo minfo { get; set; }

		private FS_IIS_USER_LOGIN_R LoginData { get; set; }
		#endregion

		#region Constructor
		public MemberCardSession(MemberInfo _minfo, FS_IIS_USER_LOGIN_R _LoginData)
		{
			this.context = HttpContext.Current;
			this.minfo = _minfo;
			this.LoginData = _LoginData;
		}
		#endregion

		#region IMemberSession成員
		public void SetMemberSession()
		{
			SqlDataReader objDtr = SqlHelper.ExecuteReader
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_A_GetUserData",
				new SqlParameter("@MemberAccount", minfo.MemberAccount)
			);

			if (objDtr.Read())
			{
				// 會員帳號
				context.Session["MemberAccount"] = minfo.MemberAccount;
				// 手機
				context.Session["Mobile"] = objDtr["Mobile"].ToString();

				context.Session["NDUrl"] = WebConfig.Domain;
			}

			objDtr.Close();
		}
		#endregion
	}
}