﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;
using GS.ServerCommander;
using GS.Utilities;

namespace HOTW_GameWebMVC.AppLibs
{
	public class GuestMemberSession: IMemberSession, IRequiresSessionState
	{
		#region Properties
		private HttpContext context { get; set; }

		private MemberInfo minfo { get; set; }

		private FS_IIS_USER_LOGIN_R LoginData { get; set; }
		#endregion

		#region Constructor
		public GuestMemberSession(MemberInfo _minfo, FS_IIS_USER_LOGIN_R _LoginData)
		{
			this.context = HttpContext.Current;
			this.minfo = _minfo;
			this.LoginData = _LoginData;
		}
		#endregion

		#region IMemberSession成員
		public void SetMemberSession()
		{
			// 先清除Session剔除會員
			if (context.Session["GuestMemberID"] != null)
			{
				context.Session.Abandon();
			}
			// 登入後隨機產生的登入碼
			context.Session["LoginKey"] = LoginData.LoginKey;
			// 通訊加密編號
			context.Session["TriDESUniID"] = LoginData.TriDESUniID;
			// 通訊加密金鑰
			context.Session["TriDESKey"] = LoginData.TriDESKey;
			// 登入遊戲事件(活動)紀錄Flag
			context.Session["ActivityMask"] = LoginData.LoginEventFlag;
			// 辨識連線的唯一識別碼 (體驗會員)
			context.Session["GuestOnlineID"] = LoginData.OnlineID;
			// 最後動作時間
			context.Session["LastAction"] = DateTime.Now;
			// 體驗區會員編號
			context.Session["GuestMemberID"] = LoginData.MemberID;
			// 註冊類別
			context.Session["RegisterType"] = minfo.SourceName;
			// 蛋蛋檔名
			context.Session["EggUrl"] = LoginData.EggUrl;
			// 會員等級
			context.Session["Level"] = LoginData.Level;
			// 大頭照檔名
			context.Session["UserPhoto"] = LoginData.UserPhoto;
			// 網址
			context.Session["AllPicFilePath"] = LoginData.AllPicFilePath;
			// 衛星點網址
			context.Session["NDUrl"] = WebConfig.Domain;
			// 暱稱
			context.Session["NickName"] = "free";
			// 會員權限識別
			context.Session["MemberAttribute"] = LoginData.MemberAttribute;
			// 會員等級星等
			context.Session["VIP_Level"] = LoginData.VIP_Level;
		}
		#endregion
	}
}