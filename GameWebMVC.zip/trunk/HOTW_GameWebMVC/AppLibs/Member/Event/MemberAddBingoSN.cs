﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using HOTW_GameWebMVC.AppLibs;

namespace HOTW_GameWebMVC.AppLibs
{
	public class MemberAddBingoSN : MemberDecorator
	{
		public override MemberResultData MemberOperation()
		{
			if (!string.IsNullOrEmpty(minfo.BingoSN))
			{
				SqlParameter[] objParam = new SqlParameter[]
				{
					new SqlParameter("@MemberID", ResultData.LoginData.MemberID),
					new SqlParameter("@IntroducerName", minfo.BingoSN)
				};
				SqlHelper.ExecuteNonQuery
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_GameWeb_IntroducerNickNameAdd",
					objParam
				);
			}
			return ResultData;
		}
	}
}