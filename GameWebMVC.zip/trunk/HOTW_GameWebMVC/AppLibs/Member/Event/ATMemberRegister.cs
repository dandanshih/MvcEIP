﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using GS.Utilities;
using System.Data;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// 社群帳號轉移新帳號
	/// </summary>
	public class ATMemberRegister : MemberDecorator
	{
		#region Properties
		private HttpContext context { get; set; }
		#endregion

		#region Constructor
		public ATMemberRegister()
		{
			this.context = HttpContext.Current;
		}
		#endregion

		#region MemberDecorator成員
		public override MemberResultData MemberOperation()
		{

			MemberResultData ResultData = new MemberResultData();
			SqlParameter[] param =
			{
				new SqlParameter("@MemberID", minfo.MemberID),
			    new SqlParameter("@MemberAccount", minfo.MemberAccount),
			    new SqlParameter("@MemberPassword", minfo.MemberPassword),
			    new SqlParameter("@Mobile", string.IsNullOrEmpty(minfo.Mobile) ? "" : minfo.Mobile),
				new SqlParameter("@Email", minfo.EMail)
			};

			SqlDataReader objDtr = SqlHelper.ExecuteReader
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_A_MemberSourceUpdate",
				param
			);
			int result = 0;

			if (objDtr.Read())
			{
				ResultData.LoginData = new GS.ServerCommander.FS_IIS_USER_LOGIN_R();
				ResultData.LoginData.MemberID = int.Parse(objDtr["MemberID"].ToString());
				ResultData.ResultCode = int.Parse(objDtr["Result"].ToString());
				result = ResultData.ResultCode;
			}
			objDtr.Close();
			ResultData.IsNext = false;
			switch (result)
			{
				case 0:
					ResultData.IsNext = true;
					break;
				case 6:
					ResultData.ResultMsg = "暱稱重覆";
					break;
				case 11:
				case 12:
					ResultData.ResultMsg = "您申請的帳號已經有別人使用了，請更換別的帳號";
					break;
				case 13:
					ResultData.ResultMsg = "您申請的帳號正在等待帳號驗證中，請更換別的帳號，或稍候再試試看";
					break;
				case 14:
					ResultData.ResultMsg = "此帳號已註冊，尚未進行認證";
					break;
				case 31:
					ResultData.ResultMsg = "行動電話號碼重覆";
					break;
                case 51:
					ResultData.ResultMsg = "電子信箱重覆";
					break;
				default:
					ResultData.ResultMsg = "帳號建立時發生錯誤，請稍候再執行一次，或請洽客服中心";
					break;
			}
			return ResultData;
		}
		#endregion
	}
}