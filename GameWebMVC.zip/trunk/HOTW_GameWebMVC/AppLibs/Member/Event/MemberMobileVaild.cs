﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// 會員手機驗證
	/// </summary>
	public class MemberMobileVaild : MemberDecorator
	{
		public override MemberResultData MemberOperation()
		{
			MemberResultData ResultData = new MemberResultData();
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@MemberID", minfo.MemberID),
				new SqlParameter("@Mobile", minfo.Mobile),
				new SqlParameter("@VerificationCode", minfo.MobileVaildCode)
			};
			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_MemberMobileVerificationCheck",
				param
			);
			if (objDr.Read())
			{
				ResultData.ResultCode = Convert.ToInt32(objDr["Result"]);
				if (ResultData.ResultCode == 0)
				{
					ResultData.ResultMsg = "驗證碼正確! 恭喜您帳號啟用成功!";
				}
				else if (ResultData.ResultCode == 3)
				{
					ResultData.ResultMsg = "因您超過限定時間尚未完成手機驗證，請於五分鐘後重新註冊。";
					ResultData.IsNext = false;
				}
                else if (ResultData.ResultCode == 6)
                {
                    ResultData.ResultMsg = "您已完成驗證。";
                    ResultData.IsNext = false;
                }
                else if (ResultData.ResultCode == 7)
                {
                    ResultData.ResultMsg = "請升級普卡會員。";
                    ResultData.IsNext = false;
                }
                else if (ResultData.ResultCode == 2)
                {
                    ResultData.ResultMsg = "因您超過限定時間尚未完成手機驗證，請點選「沒有收到驗證碼，按我再發一次。」完成驗證。";
                    ResultData.IsNext = false;
                }
                else
                {
                    ResultData.ResultMsg = "驗證碼錯誤!";
                    ResultData.IsNext = false;
                }
			}
			objDr.Close();
			//0成功1失敗
			return ResultData;
		}
	}
}