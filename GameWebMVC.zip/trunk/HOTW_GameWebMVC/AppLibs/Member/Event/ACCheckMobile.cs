﻿using GS.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;

namespace HOTW_GameWebMVC.AppLibs
{
    public class ACCheckMobile : MemberDecorator
    {
        public override MemberResultData MemberOperation()
        {
            MemberResultData ResultData = new MemberResultData();
            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_A_MemberSourceMobileCheck",
                new SqlParameter("@Mobile", minfo.Mobile)
            );
            ResultData.ResultCode = 0;
            ResultData.IsNext = true;
            while (objDr.Read())
            {
                ResultData.ResultCode = Convert.ToInt32(objDr["Result"]);
                ResultData.Data = objDr["MemberID"].ToString();
            }
            objDr.Close();
            return ResultData;
        }
    }
}