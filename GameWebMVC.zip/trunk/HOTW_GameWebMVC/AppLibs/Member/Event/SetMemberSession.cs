﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using GS.ServerCommander;
using System.Data.SqlClient;
using System.Data;
using GS.Utilities;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// 設定會員資訊至Session
	/// </summary>
	public class SetMemberSession : MemberDecorator, IRequiresSessionState
	{
		#region Properties
		private HttpContext context { get; set; }
		#endregion

		#region Constructor
		public SetMemberSession()
		{
			this.context = HttpContext.Current;
		}
		#endregion

		#region MemberDecorator成員
		public override MemberResultData MemberOperation()
		{
			FS_IIS_USER_LOGIN_R LoginData = ResultData.LoginData;
			IMemberSession IMS;
			if (minfo.FSLoginType == LoginType.Guest)
			{
				IMS = new GuestMemberSession(minfo, ResultData.LoginData);
			}
			else
			{
				switch (ResultData.ResultCode)
				{
					// 一般會員
					default:
					case 1:
                        if (minfo.SourceName == "Online113")
                        {
                            IMS = new MemberDataSession(minfo, ResultData.LoginData);
                        }
                        else
                        {
                            IMS = new NormalMemberSession(minfo, ResultData.LoginData);
                        }
						break;
					// 會員卡會員
					case 21:
						IMS = new MemberCardSession(minfo, ResultData.LoginData);
						break;
				}
			}
			IMS.SetMemberSession();
			return ResultData;
		}
		#endregion
	}
}