﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// 用手機找帳號
	/// </summary>
	public class ATFindMemberAccount : MemberDecorator
	{
		public override MemberResultData MemberOperation()
		{
			MemberResultData ResultData = new MemberResultData();
			SqlParameter[] param = new SqlParameter[]
			{				
				new SqlParameter("@Mobile", minfo.Mobile),			
			};
			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_MemberMobileVerificationCheck",
				param
			);
			if (objDr.Read())
			{
				ResultData.ResultCode = Convert.ToInt32(objDr["Result"]);
				if (ResultData.ResultCode == 0)
				{
					ResultData.ResultMsg = "找到帳號!";
				}
				else if (ResultData.ResultCode == 1)
				{
					ResultData.ResultMsg = "您輸入的號碼不在此活動中。";
					ResultData.IsNext = false;
				}
                else if (ResultData.ResultCode == 7)
                {
                    ResultData.ResultMsg = "請升級普卡會員。";
                    ResultData.IsNext = false;
                }
				else
				{					
					ResultData.IsNext = false;
				}
			}
			objDr.Close();
			//0成功1失敗
			return ResultData;
		}
	}
}