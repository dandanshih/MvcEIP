﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GS.ServerCommander;

namespace HOTW_GameWebMVC.AppLibs
{
	public class GetVipUpgradeGift : MemberDecorator
	{
		public override  MemberResultData MemberOperation()
		{
			MemberResultData ResultData = new MemberResultData();
			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_GetUpgradeVIPGift",
				new SqlParameter("@MemberID", minfo.MemberID),
				new SqlParameter("@IsChange", minfo.IsChange)
			);
			ResultData.ResultCode = 0;
			ResultData.IsNext = true;
			while (objDr.Read())
			{
				long KeyInOutID = Convert.ToInt64(objDr["EventID"]);
				decimal Points = Convert.ToDecimal(objDr["ChangePoints"]);
				int PointType = Convert.ToInt32(objDr["PointType"]);
				string fsResult = FSCommander.FS_AS_CREDIT_CHANGE(KeyInOutID, minfo.MemberID, Points, PointType);
				if (fsResult != "0")
				{
					ResultData.ResultCode = Convert.ToInt32(fsResult);
					ResultData.IsNext = false;
				}
				System.Threading.Thread.Sleep(200);
			}
			objDr.Close();
			return ResultData;
		}
	}
}