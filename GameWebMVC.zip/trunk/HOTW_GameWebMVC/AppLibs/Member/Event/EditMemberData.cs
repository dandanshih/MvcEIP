﻿using GS.Utilities;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// 修改會員資料
	/// </summary>
	public class EditMemberData : MemberDecorator
	{
		#region MemberDecorator成員
		public override MemberResultData MemberOperation()
		{
            MemberResultData ResultData = new MemberResultData();

            if (!string.IsNullOrEmpty(minfo.NickName) && !Regex.IsMatch(minfo.NickName, @"^[0-9a-zA-Z\u4e00-\u9fa5]{1,10}$"))
            {
                ResultData.ResultCode = 999;
                ResultData.IsNext = false;
                ResultData.ResultMsg = "暱稱不可包含特殊字元";
                return ResultData;
            }

			SqlParameter[] param =
			{
				new SqlParameter("@MemberID", minfo.MemberID),
				new SqlParameter("@MemberPassword", minfo.MemberPassword),
				new SqlParameter("@Email", minfo.EMail),
				new SqlParameter("@RealName", minfo.RealName),
				new SqlParameter("@NickName", minfo.NickName),
				new SqlParameter("@Phone", minfo.Phone),
				new SqlParameter("@Mobile", minfo.Mobile),
				new SqlParameter("@ZoneID", minfo.ZoneID),
				new SqlParameter("@Address", minfo.Address),
				new SqlParameter("@OnlineIP", minfo.ClientIP),
				new SqlParameter("@Invoice_Type", minfo.InvoiceType == -999 ? (object)DBNull.Value : minfo.InvoiceType),
				new SqlParameter("@Invoice_ZoneID", minfo.Invoice_ZoneID),
				new SqlParameter("@Invoice_Address", minfo.Invoice_Address),
				new SqlParameter("@Invoice_Recipient", minfo.Invoice_Recipient),
				new SqlParameter("@Birthday", minfo.Birthday)
			};

			ResultData.ResultCode = Convert.ToInt32
			(
				SqlHelper.ExecuteScalar
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_GameWeb_A_Member_Edit",
					param
				)
			);
			ResultData.IsNext = false;
			switch (ResultData.ResultCode)
			{
				// 修改會員成功
				case 0:
				// 發送手機驗證碼，開始進行VIP升級
				case 10:
					ResultData.IsNext = true;
					break;
				case 1:
					ResultData.ResultMsg = "設定異常";
					break;
				case 3:
					ResultData.ResultMsg = "介紹人不存在";
					break;
				case 4:
					ResultData.ResultMsg = "介紹人不可填自己";
					break;
				case 5:
					ResultData.ResultMsg = "介紹人不為老幣會員";
					break;
				case 6:
					ResultData.ResultMsg = "介紹人停權中";
					break;
				case 7:
					ResultData.ResultMsg = "手機號碼重覆！";
					break;
				case 8:
					ResultData.ResultMsg = "因驗證碼輸入錯誤或發送驗證碼次數頻繁，此功能暫時無法使用。先去玩遊戲！1小時後『升級VIP』，完成驗證領禮物喔！";
					// ResultData.ResultMsg = "由於發送驗證碼次數頻繁，此功能暫時無法使用，\\n請您與客服中心聯絡。";
					break;
				case 9:
					ResultData.ResultMsg = "你剛剛取消驗證，先玩遊戲，1小時後再來升級VIP！";
					break;
				case 12:
					ResultData.ResultMsg = "暱稱僅能設定一次。";
					break;
				case 21:
					ResultData.ResultMsg = "找不到此會員";
					break;
				case 22:
					ResultData.ResultMsg = "介紹人無法修改";
					break;
				case 23:
					ResultData.ResultMsg = "介紹人不能是自已";
					break;
				case 24:
					ResultData.ResultMsg = "介紹人不存在，請檢查介紹人的暱稱是否有誤";
					break;
				case 25:
					ResultData.ResultMsg = "介紹人不為老幣會員";
					break;
				case 26:
					ResultData.ResultMsg = "介紹人停權中";
					break;
				case 33:
					ResultData.ResultMsg = "電子信箱重覆";
					break;
			}
			return ResultData;
		}
		#endregion
	}
}