﻿//-----------------------------------------------------------------------
// <copyright file="GetDefaultNickName.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs.Member.Event
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    /// <summary>
    /// GetDefaultNickName Class
    /// </summary>
    public class GetDefaultNickName : MemberDecorator
    {
        public override MemberResultData MemberOperation()
        {
            return base.MemberOperation();
        }
    }
}