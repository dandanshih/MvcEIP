﻿using System;

namespace HOTW_GameWebMVC.AppLibs
{
	public enum LoginType
	{
		Community,
		Web,
		Guest,
		ReLogin
	}

	[Serializable]
	public class MemberInfo
	{
		/// <summary>
		/// 要登入之方式
		/// </summary>
		public LoginType FSLoginType { get; set; }

		/// <summary>
		/// 會員編號
		/// </summary>
		public int MemberID { get; set; }

		/// <summary>
		/// 會員帳號
		/// </summary>
		public string MemberAccount { get; set; }

		/// <summary>
		/// 會員密碼
		/// </summary>
		public string MemberPassword { get; set; }

		/// <summary>
		/// 會員姓名
		/// </summary>
		public string RealName { get; set; }
		
		/// <summary>
		/// 會員暱稱
		/// </summary>
		public string NickName { get; set; }

		/// <summary>
		/// 電話
		/// </summary>
		public string Phone { get; set; }

		/// <summary>
		/// 會員手機
		/// </summary>
		public string Mobile { get; set; }

		/// <summary>
		/// 會員手機末四碼
		/// </summary>
		public string Mobile4Num { get; set; }

		/// <summary>
		/// 是否需社群拆帳
		/// </summary>
		public bool IsAmortization { get; set; }

		/// <summary>
		/// <para>0: 一般</para>
		/// <para>64:大秘寶</para>
		/// <para>128:大秘寶</para>
		/// </summary>
		public int AddFlag { get; set; }

		/// <summary>
		/// 選取之Game促小姐編號
		/// </summary>
		public int GameGirlID { get; set; }

		/// <summary>
		/// 登入之Game促小姐編號
		/// </summary>
		public int LoginGameGirlID { get; set; }

		/// <summary>
		/// Game促小姐登入時間
		/// </summary>
		public DateTime GameGirlLoginDate { get; set; }

		/// <summary>
		/// FB 應用程式代號
		/// </summary>
		public string AppName{ get; set; }

		/// <summary>
		/// 社群來源
		/// <para>Web: 老子有錢</para>
		/// <para>其他: 各社群帳號@後字串</para>
		/// </summary>
		public string SourceName { get; set; }

		/// <summary>
		/// 體驗區會員編號
		/// </summary>
		public int GuestMemberID { get; set; }

		/// <summary>
		/// 體驗區之遊戲輸贏分編號
		/// </summary>
		public string ExperienceWID { get; set; }

		/// <summary>
		/// 會員所在IP
		/// </summary>
		public string ClientIP { get; set; }

		/// <summary>
		/// 會員所在平台  Web、FB、IPad
		/// </summary>
		public string Platform { get; set; }

		/// <summary>
		/// 電子郵件
		/// </summary>
		public string EMail { get; set; }

		/// <summary>
		/// 鄉鎮編號
		/// </summary>
		public string ZoneID { get; set; }

		/// <summary>
		/// 住址
		/// </summary>
		public string Address { get; set; }

		/// <summary>
		/// 預設收取發票類別
		/// <para>-999: 不設定</para>
		/// </summary>
		public int InvoiceType = -999;

		/// <summary>
		/// 發票收件人
		/// </summary>
		public string Invoice_Recipient { get; set; }

		/// <summary>
		/// 發票收件鄉鎮編號
		/// </summary>
		public string Invoice_ZoneID { get; set; }

		/// <summary>
		/// 發票收件住址
		/// </summary>
		public string Invoice_Address { get; set; }

		/// <summary>
		/// 手機簡訊驗證碼
		/// </summary>
		public string MobileVaildCode { get; set; }

		/// <summary>
		/// 生日
		/// </summary>
		public string Birthday { get; set; }

		/// <summary>
		/// 註冊的活動的ID (1: 產包)
		/// </summary>
		public long CreateFlagID { get; set; }

		/// <summary>
		/// 註冊的活動的序號
		/// </summary>
		public string CreateHashCode { get; set; }

		// 是否轉移帳號
		public int IsChange { get; set; }

		public string BingoSN { get; set; }

        /// <summary>
        /// 介紹人暱稱。
        /// </summary>
        public string IntroducerNickName { get; set; }

        /// <summary>
        /// IIS SessionID 做 MemCached 主索引
        /// </summary>
        public string SessionID { get; set; }
	
	}
}