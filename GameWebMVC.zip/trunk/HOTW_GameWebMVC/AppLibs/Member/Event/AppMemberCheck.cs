﻿using GS.Utilities;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
    /// AppMemberCheck 的摘要描述
	/// </summary>
	public class AppMemberCheck : MemberDecorator, IRequiresSessionState
	{
		#region Properties
		private HttpContext context { get; set; }
		#endregion

		#region Constructor
        public AppMemberCheck()
		{
			this.context = HttpContext.Current;
		}
		#endregion

		#region MemberDecorator成員
		public override MemberResultData MemberOperation()
		{
            MemberResultData ResultData = new MemberResultData();

            SqlParameter[] param = 
            { 
                new SqlParameter("@MemberID", minfo.MemberID),
                new SqlParameter("@MemberAccount", string.IsNullOrEmpty(minfo.MemberAccount) ? "" : minfo.MemberAccount)
            };

            ResultData.ResultCode = int.Parse(SqlHelper.ExecuteScalar
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_A_AppMemberCheck",
                param
            ).ToString());

            ResultData.IsNext = false;

            switch(ResultData.ResultCode)
            {
                // 驗證成功_未審核
                case 1:
                // 驗證成功_已審核
                case 2:
                    ResultData.ResultCode += 1000;
                    ResultData.IsNext = true;
                    break;
                // 手機未驗證
                case 3:
                    ResultData.ResultCode += 1000;
                    ResultData.ResultMsg = "手機尚未通過驗證，請立即登入遊戲進行線上驗證通過。\n方可使用本功能。";
                    break;
                // 非會員
                case 0:
                default:
                    ResultData.ResultCode = 1000;
                    ResultData.ResultMsg = "您的身份不符合活動資格！";
                    break;
            }

            return ResultData;
		}
		#endregion
	}
}