﻿using GS.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace HOTW_GameWebMVC.AppLibs
{
    public class ACCheckVerifyCode : MemberDecorator
    {
        public override MemberResultData MemberOperation()
        {
            MemberResultData ResultData = new MemberResultData();
            SqlDataReader objDr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_A_MemberSourceVerifyCodeCheck",
                new SqlParameter("@MemberID", minfo.MemberID),
                new SqlParameter("@VerifyCode", minfo.MobileVaildCode)
            );
            ResultData.ResultCode = 0;
            ResultData.IsNext = true;
            while (objDr.Read())
            {
                ResultData.ResultCode = Convert.ToInt32(objDr["Result"]);
                ResultData.Data = objDr["MemberID"].ToString();
            }
            objDr.Close();
            return ResultData;
        }
    }
}