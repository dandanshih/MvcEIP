﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using GS.Utilities;
using System.Data;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// 重新寄送驗證簡訊
	/// </summary>
	public class ReSendSMSCode : MemberDecorator
	{
		public override MemberResultData MemberOperation()
		{
			MemberResultData ResultData = new MemberResultData();
			try
			{
				SqlParameter[] param = new SqlParameter[]
				{
					new SqlParameter("@Result", SqlDbType.Int),
					new SqlParameter("@MemberID", minfo.MemberID),
					new SqlParameter("@MemberAccount", minfo.MemberAccount),
					new SqlParameter("@Mobile", minfo.Mobile)
				};
				param[0].Direction = ParameterDirection.Output;
				SqlHelper.ExecuteNonQuery
				(
					WebConfig.ConnectionString,
					CommandType.StoredProcedure,
					"NSP_GameWeb_A_Member_NewReSMS",
					param
				);
				ResultData.ResultCode = Convert.ToInt32(param[0].Value);
				ResultData.IsNext = false;
				switch (ResultData.ResultCode)
				{
					case 0:
						ResultData.ResultMsg = "簡訊已送出，請注意您的手機並請儘速啟用帳號！";
						ResultData.IsNext = true;
						break;
					case 1:
						ResultData.ResultMsg = "帳號不存在！";
						break;
					case 2:
						ResultData.ResultMsg = "因驗證碼輸入錯誤或發送驗證碼次數頻繁，此功能暫時無法使用。先去玩遊戲！1小時後『升級VIP』，完成驗證領禮物喔！";
						// ResultData.ResultMsg = "由於發送驗證碼次數頻繁，此功能暫時無法使用，請您與客服中心聯絡。";
						break;
					case 3:
						ResultData.ResultMsg = "手機目前鎖定中！";
						break;
                    case 4:
                        ResultData.ResultMsg = "您已完成驗證。";
                        break;
					default:
						ResultData.ResultMsg = "發送失敗！";
						break;
				}
			}
			catch (Exception ex)
			{
				ResultData.ResultCode = 999;
				ResultData.ResultMsg = ex.Message;
				ResultData.IsNext = false;
			}
			return ResultData;
		}
	}
}