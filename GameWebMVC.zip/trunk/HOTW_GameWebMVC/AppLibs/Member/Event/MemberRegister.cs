﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using GS.Utilities;
using System.Data;

namespace HOTW_GameWebMVC.AppLibs
{
    /// <summary>
    /// 註冊會員
    /// </summary>
    public class MemberRegister : MemberDecorator
    {
        #region Properties
        private HttpContext context { get; set; }
        #endregion

        #region Constructor
        public MemberRegister()
        {
            this.context = HttpContext.Current;
        }
        #endregion

        #region MemberDecorator成員
        public override MemberResultData MemberOperation()
        {
            //log4net.LogManager.GetLogger(typeof(MemberRegister)).InfoFormat(" ADSourceID => {0} ", (this.context.Request.Cookies["s"] != null ? this.context.Request.Cookies["s"].Values["s"].ToString() : "0"));
            MemberResultData ResultData = new MemberResultData();
            SqlParameter[] param =
			{
			    new SqlParameter("@MemberAccount", minfo.MemberAccount),
			    new SqlParameter("@MemberPassword", minfo.MemberPassword),
			    new SqlParameter("@NickName", minfo.NickName),
			    new SqlParameter("@Mobile", string.IsNullOrEmpty(minfo.Mobile) ? " " : minfo.Mobile),
				new SqlParameter("@Email", minfo.EMail),
			    new SqlParameter("@Invoice_Type", "0"),
				// 選取的GameGirlID
				new SqlParameter("@GameGirlID", minfo.GameGirlID),
				// 登入的GameGirlID
				new SqlParameter("@LoginGameGirlID", minfo.LoginGameGirlID),
				new SqlParameter("@GameGirlLoginDate", minfo.GameGirlLoginDate == DateTime.MinValue ? (object)DBNull.Value : minfo.GameGirlLoginDate),
				new SqlParameter("@SourceName", minfo.SourceName),
				new SqlParameter("@GuestMemberID", minfo.GuestMemberID),
				new SqlParameter("@ExperienceWID", minfo.ExperienceWID),
				new SqlParameter("@AppName", minfo.AppName),
				new SqlParameter("@AddFlag", minfo.AddFlag),
				new SqlParameter("@IsAmortization", minfo.IsAmortization),
				new SqlParameter("@MemberNewFlagID", minfo.CreateFlagID),
				new SqlParameter("@MemberNewHashCode", minfo.CreateHashCode),
				new SqlParameter("@IntroducerNickName", minfo.IntroducerNickName),
                new SqlParameter("@OnlineIP", string.IsNullOrEmpty(minfo.ClientIP) ? HttpContext.Current.Request.UserHostAddress : minfo.ClientIP),
                new SqlParameter("@ADSourceID", (this.context.Request.Cookies["s"] != null ? this.context.Request.Cookies["s"].Values["s"].ToString() : "0"))
			};

            SqlDataReader objDtr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_CreateMember",
                param
            );
            //log4net.LogManager.GetLogger(typeof(MemberRegister)).InfoFormat(" 跑完 NSP_GameWeb_CreateMember ");
            int result = 0;

            if (objDtr.Read())
            {
                ResultData.LoginData = new GS.ServerCommander.FS_IIS_USER_LOGIN_R();
                ResultData.LoginData.MemberID = int.Parse(objDtr["MemberID"].ToString());
                ResultData.ResultCode = int.Parse(objDtr["Result"].ToString());
                result = ResultData.ResultCode;
            }
            objDtr.Close();
            ResultData.IsNext = false;
            //log4net.LogManager.GetLogger(typeof(MemberRegister)).InfoFormat(" result => {0} ", result);
            switch (result)
            {
                case 0:
                    ResultData.IsNext = true;
                    break;
                case 3:
                    ResultData.ResultMsg = "介紹人不存在";
                    break;
                case 4:
                    ResultData.ResultMsg = "介紹人不可填自己";
                    break;
                case 6:
                    ResultData.ResultMsg = "暱稱重覆";
                    break;
                case 11:
                case 12:
                    ResultData.ResultMsg = "您申請的帳號已經有別人使用了，請更換別的帳號";
                    break;
                case 13:
                    ResultData.ResultMsg = "您申請的帳號正在等待帳號驗證中，請更換別的帳號，或稍候再試試看";
                    break;
                case 14:
                    ResultData.ResultMsg = "此帳號已註冊，尚未進行認證";
                    break;
                case 21:
                    ResultData.ResultMsg = "無效的推薦碼";
                    break;
                case 22:
                    ResultData.ResultMsg = "介紹人無法修改";
                    break;
                case 23:
                    ResultData.ResultMsg = "介紹人不能是自已";
                    break;
                case 24:
                    ResultData.ResultMsg = "介紹人不存在，請檢查介紹人的暱稱是否有誤";
                    break;
                case 25:
                    ResultData.ResultMsg = "介紹人不為老幣會員或未完成認證";
                    break;
                case 26:
                    ResultData.ResultMsg = "介紹人停權中";
                    break;
                case 31:
                    ResultData.ResultMsg = "行動電話號碼重覆";
                    break;
                case 32:
                    ResultData.ResultMsg = "電子信箱重覆";
                    break;
                default:
                    ResultData.ResultMsg = "帳號建立時發生錯誤，請稍候再執行一次，或請洽客服中心";
                    break;
            }
            return ResultData;
        }
        #endregion
    }
}