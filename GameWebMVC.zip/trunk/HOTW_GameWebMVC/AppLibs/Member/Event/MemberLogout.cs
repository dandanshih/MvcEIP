﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
	public class MemberLogout : MemberDecorator, IRequiresSessionState
	{
		#region Properties
		private HttpContext context { get; set; }
		#endregion

		#region Constructor
		public MemberLogout()
		{
			this.context = HttpContext.Current;
		}
		#endregion


		public override MemberResultData MemberOperation()
		{
			if (context.Session["MemberID"] != null || context.Session["GuestMemberID"] != null)
			{
				context.Session.Abandon();
			}
			return base.MemberOperation();
		}
	}
}