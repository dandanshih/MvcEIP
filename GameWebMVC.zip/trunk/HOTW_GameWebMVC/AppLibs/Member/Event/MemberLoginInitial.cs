﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GS.ServerCommander;
using System.Web.SessionState;
using HOTW_GameWebMVC.AppLibs.DataHelper;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// SelfMember 的摘要描述
	/// </summary>
	public class MemberLoginInitial : MemberDecorator, IRequiresSessionState
	{
		#region Properties
		private HttpContext context { get; set; }
		#endregion

		#region Constructor
		public MemberLoginInitial()
		{
			this.context = HttpContext.Current;
		}
		#endregion

		#region MemberDecorator成員
		public override MemberResultData MemberOperation()
		{
			IMemberLogin mlogin;
            DataContext d_context = new DataContext(minfo.Platform);
			switch (minfo.FSLoginType)
			{
				case LoginType.Community:
					mlogin = new CWLogin();
					break;
				case LoginType.Guest:
					mlogin = new WebGuestLogin();
					break;
				case LoginType.ReLogin:
                    if (string.IsNullOrEmpty(minfo.MemberAccount))
					{
                        minfo.MemberAccount = d_context.Session.MemberAccount;
					}
					mlogin = new WebReLogin();
					break;
				default:
				case LoginType.Web:
					mlogin = new WebLogin();
					break;
			}
			FS_IIS_USER_LOGIN_R LoginData = mlogin.MemberLogin(minfo);
			MemberResultData ResultData = new MemberResultData();
			ResultData.LoginData = LoginData;
			ResultData.ResultCode = Convert.ToInt32(LoginData.State);
			ResultData.IsNext = false;
			switch (LoginData.State.ToString())
			{
				case "0":
				case "20":
					ResultData.ResultMsg = "登入失敗!";
					break;
				case "1":	// 登入成功
					ResultData.ResultMsg = "登入成功";
					ResultData.IsNext = true;
					break;
				case "10":	// 手機驗證未通過 (爽幣視同通過)
					ResultData.ResultMsg = "手機驗證未通過";
					break;
				case "2":
					ResultData.ResultMsg = "帳號不存在!";
					break;
				case "3":
					ResultData.ResultMsg = "密碼輸入錯誤已超過六次！若有任何疑問，請洽客服。";
					break;
				case "7":
					ResultData.ResultMsg = "帳號目前還在線上，請５分鐘後再行登入。";
					minfo.FSLoginType = LoginType.ReLogin;
					minfo.MemberID = Convert.ToInt32(LoginData.MemberID);
					ResultData = this.MemberOperation();
					if (ResultData.ResultCode == 1)
					{
						ResultData.IsNext = true;
					}
					break;
				case "19":
					// 重覆登入，玩家在遊戲中
					ResultData.ResultMsg = "此帳號尚有遊戲進行或託管中，您確定要繼續登入，並結束進行中的遊戲嗎?";
                    
                    if (d_context.Session == null)
                    {
                        d_context.Session = new SGT.Web.Session.HOTW.SessionData() { IsLogin = false };
                    }
                    d_context.Session.MemberID = LoginData.MemberID;
                    d_context.Session.MemberAccount = minfo.MemberAccount;
                    
                    d_context.Save();
					break;
				case "8":
					ResultData.ResultMsg = "帳號鎖定中!";
					break;
				case "9":
					ResultData.ResultMsg = "密碼錯誤 " + LoginData.LoginKey + " 次!";
					break;
				case "11":
					ResultData.ResultMsg = "帳號停用中!";
					break;
				case "12":
					ResultData.ResultMsg = "伺服器維護中!";
					break;
				case "13":
					ResultData.ResultMsg = "帳號停用 " + LoginData.LoginKey + " 天!";
					break;
				case "14":
					ResultData.ResultMsg = "通訊鎖未解鎖!";
					break;
				case "15":
					// 贈點
					ResultData.ResultMsg = "請重新認證!";
					break;
				case "16":
					// 不贈點
					ResultData.ResultMsg = "請重新認證!";
					break;
				case "17":
					ResultData.ResultMsg = "伺服器滿載中，請稍後再登入或註冊。";
					break;
				case "18":
					ResultData.ResultMsg = "特殊升級VIP流程中";
					break;
				case "21":
					ResultData.ResultMsg = "請至 www.08Online.com.tw 的\"立即玩\" 開通您的帳號！";
					ResultData.IsNext = true;
					break;
				case "22":
					ResultData.ResultMsg = "此會員卡已開通，請使用新帳號密碼登入。\\n若有任何問題，請洽客服中心04-22368000為您服務！";
					break;
                case "23":
                    ResultData.ResultMsg = "因您太久未登入遊戲，帳號已暫時鎖定，欲開啟帳號請洽客服04-2236-8000為您開通";
                    break;
				default:
					ResultData.ResultMsg = "伺服器維護中!";
					break;
			}
			return ResultData;
		}
		#endregion
	}
}