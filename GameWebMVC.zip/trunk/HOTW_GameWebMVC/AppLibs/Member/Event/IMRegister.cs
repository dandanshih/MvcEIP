﻿using GS.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
	public class IMRegister : MemberDecorator,IRequiresSessionState
	{
		const long checkflag = 0;

		public override MemberResultData MemberOperation()
		{
			try
			{
				int accountstate= base.ResultData.LoginData.State;
				#region 驗證 是否已註冊過
				///跟DB 要pw
				int Result = 0;
				string IMPassword = string.Empty;
				SqlParameter[] objParam = new SqlParameter[]
				{				
					new SqlParameter("@MemberID", base.ResultData.LoginData.MemberID)					
				};

				SqlDataReader objread = SqlHelper.ExecuteReader
				(
				   WebConfig.IMConnectionString,
				   CommandType.StoredProcedure,
				   "NSP_APPWeb_A_Member_APPIMInfo_Get",				   
				   objParam
				);

				if (objread.Read())
				{
					Result = int.TryParse(objread["Status"].ToString(), out Result) ? Result : 0;
					IMPassword = objread["IMPassword"].ToString();
				}
				objread.Close();
				#region ///未註冊
				if (Result == 0)
				{

					
					IMPassword = Guid.NewGuid().ToString().Replace("-", "").Substring(0, 12);

					log4net.LogManager.GetLogger(typeof(IMRegister)).DebugFormat("註冊IM帳號: {0}, 密碼: {1}", base.ResultData.LoginData.MemberID.ToString(), IMPassword);

					IMGatewayUtility.ResultStruct resultData = IMGatewayUtility.Instance.UserAdd(base.ResultData.LoginData.MemberID.ToString(), IMPassword);

					///註冊失敗
					if (resultData.Result != "success")
					{
						log4net.LogManager.GetLogger(typeof(IMRegister)).DebugFormat("註冊IM帳號密碼失敗, 結果: {0}", resultData.Result);
                        HttpContext.Current.Session["IMPassword"] = string.Empty;
                        HttpContext.Current.Session["AccountState"] = base.ResultData.LoginData.State;
					}
					///註冊成功將密碼寫入DB
					else
					{
						/// insert pw to db
						SqlParameter[] objParams = new SqlParameter[]
						{							
							new SqlParameter("@MemberID", base.ResultData.LoginData.MemberID),
							new SqlParameter("@IMPassword",IMPassword)
						};

						SqlDataReader objReadset = SqlHelper.ExecuteReader
						(
						   WebConfig.IMConnectionString,
						   CommandType.StoredProcedure,
						   "NSP_APPWeb_A_Member_APPIMInfo_Set",
						   objParams
						);
						if (objReadset.Read())
						{
							Result = int.TryParse(objReadset["ResultCode"].ToString(), out Result) ? Result : 0;
						}
						objReadset.Close();
						if (Result == 1)
						{
							HttpContext.Current.Session["IMPassword"] = IMPassword;
							HttpContext.Current.Session["AccountState"] = base.ResultData.LoginData.State;
						}
						else
						{
							log4net.LogManager.GetLogger(typeof(IMRegister)).DebugFormat("寫入IM帳號密碼失敗, 結果: {0}", Result);
                            HttpContext.Current.Session["IMPassword"] = string.Empty;
                            HttpContext.Current.Session["AccountState"] = base.ResultData.LoginData.State;
						}
					}

				}
				#endregion

				#region///已註冊
				else
				{					
					HttpContext.Current.Session["IMPassword"] = IMPassword;
					HttpContext.Current.Session["AccountState"] = base.ResultData.LoginData.State;
				}
				#endregion

				#endregion

				//string postData = string.Format
				//(
				//    "SHID={0}&Account={1}&Password={2}",
				//    "095",
				//    minfo.MemberAccount,
				//    minfo.MemberPassword
				//);
				//				string postData = string.Format
				//				(
				//					@"
				//<User>
				//    <server>{0}</server>
				//    <shid>{1}</shid>
				//    <account>{2}</account>
				//    <password>{3}</password>
				//</User>",
				//					WebConfig.IMServer2Url,
				//					"08online",
				//					minfo.MemberAccount,
				//					minfo.MemberPassword
				//				);
				//				string result = CommonUtility.Post("http://10.9.11.96:8080/api/user/useradd", postData, "application/xml");
				//				log4net.LogManager.GetLogger(typeof(IMRegister)).DebugFormat("註冊IM帳號密碼, 結果: {0}", result);
			}
			catch (Exception ex)
			{
				log4net.LogManager.GetLogger(typeof(IMRegister)).Error("註冊IM 會員發生錯誤!", ex);
			}
			return base.MemberOperation();
		}
	}
}