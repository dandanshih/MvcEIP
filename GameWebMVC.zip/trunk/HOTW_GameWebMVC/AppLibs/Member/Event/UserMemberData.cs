﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GS.ServerCommander;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// UserMemberData 的摘要描述
	/// </summary>
	public abstract class UserMemberData
	{
		/// <summary>
		/// 會員資訊
		/// </summary>
		protected MemberInfo minfo { get; set; }

		/// <summary>
		/// 上次執行結果
		/// </summary>
		protected MemberResultData ResultData { get; set; }

		/// <summary>
		/// 設定要執行之操作
		/// </summary>
		/// <param name="_MemberData"></param>
		public void SetComponent(UserMemberData _MemberData)
		{
			if (ResultData != null)
			{
				if (!ResultData.IsNext) return;
			}
			if (_MemberData != null)
			{
				_MemberData.SetMemberInfo(minfo);
				_MemberData.ResultData = ResultData;
				ResultData = _MemberData.MemberOperation();
			}
		}

		/// <summary>
		/// 設定會員資訊
		/// </summary>
		/// <param name="minfo"></param>
		public virtual void SetMemberInfo(MemberInfo minfo)
		{
			if (minfo != null)
			{
				this.minfo = minfo;
			}
		}

		/// <summary>
		/// 會員各個操作
		/// </summary>
		/// <returns></returns>
		public abstract MemberResultData MemberOperation();
	}

	public class MemberDecorator : UserMemberData
	{
		public override MemberResultData MemberOperation()
		{
			return ResultData;
		}
	}

	public class MemberResultData
	{
		/// <summary>
		/// 是否繼續執行
		/// </summary>
		public bool IsNext = true;

		public int ResultCode { get; set; }

		public string ResultMsg { get; set; }

		public string Data { get; set; }

		public FS_IIS_USER_LOGIN_R LoginData { get; set; }
	}
}