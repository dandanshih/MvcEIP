﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GS.Web.CommunityGateway.StoreAPI;

namespace HOTW_GameWebMVC.AppLibs
{
	public class RegistedADReport: MemberDecorator
	{
		public override MemberResultData MemberOperation()
		{
			switch (minfo.SourceName)
			{
				case "ipart":
					CommunityClient cc = new CommunityClient
					(
						HOTW_GameWebMVC.AppLibs.WebConfig.CommunityStoreID,
						HOTW_GameWebMVC.AppLibs.WebConfig.CommunityStoreKey,
						HOTW_GameWebMVC.AppLibs.WebConfig.CommunityHost
					);
					cc.UserID = minfo.MemberAccount.Replace("@ipart", "");
					cc.Initial(CommunityType.iPart, CommunityEventType.Register);
					break;
				default:
					break;
			}
			return ResultData;
		}
	}
}