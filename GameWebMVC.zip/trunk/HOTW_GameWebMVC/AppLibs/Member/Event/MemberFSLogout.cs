﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using GS.ServerCommander;
using HOTW_GameWebMVC.AppLibs.DataHelper;

namespace HOTW_GameWebMVC.AppLibs
{
	public class MemberFSLogout : MemberDecorator, IRequiresSessionState
	{
		private HttpContext context { get; set; }

		public MemberFSLogout()
		{
			this.context = HttpContext.Current;
		}

		public override MemberResultData MemberOperation()
		{
			int MemberID = 0;
			string OnlineID = string.Empty;

            if (minfo.SourceName == "Online113")
            {
                try
                {
                    string sid = string.Format
                    (
                        "{0}_{1}_{2}_{3}",
                        minfo.Platform,
                        minfo.SessionID,
                        "MemberInfo",
                        WebConfig.Platform
                    );

					DataContext d_context = new DataContext(sid);
                    MemberID = d_context.Session.MemberID;
                    OnlineID = d_context.Session.OnlineID.ToString();
                    if (MemberID > 0 && !string.IsNullOrEmpty(OnlineID))
                    {
                        FSCommander.FS_AS_USER_LOGOUT(MemberID.ToString(), OnlineID);
                        //context.Session.Clear();
                        System.Threading.Thread.Sleep(5);
                    }
                    
                }
                catch (Exception ex)
                {
                    log4net.LogManager.GetLogger(typeof(MemberFSLogout)).Error("113會員登出FS失敗!", ex);
                }
            }
            else
            {
                if (context.Session["GuestMemberID"] != null)
                {
                    MemberID = Convert.ToInt32(context.Session["GuestMemberID"]);
                    OnlineID = context.Session["GuestOnlineID"] == null ? string.Empty : context.Session["GuestOnlineID"].ToString();
                    //return base.MemberOperation();
                }
                else if (context.Session["MemberID"] != null)
                {
                    MemberID = Convert.ToInt32(context.Session["MemberID"]);
                    OnlineID = context.Session["OnlineID"] == null ? string.Empty : context.Session["OnlineID"].ToString();
                }

                if (MemberID > 0 && !string.IsNullOrEmpty(OnlineID))
                {
                    FSCommander.FS_AS_USER_LOGOUT(MemberID.ToString(), OnlineID);
                    context.Session.Clear();
					System.Threading.Thread.Sleep(5);
                }
            }
			return base.MemberOperation();
		}
	}
}