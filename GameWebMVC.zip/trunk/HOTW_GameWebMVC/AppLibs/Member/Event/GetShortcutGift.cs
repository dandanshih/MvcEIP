﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;
using GS.ServerCommander;

namespace HOTW_GameWebMVC.AppLibs
{
	public class GetShortcutGift : MemberDecorator, IRequiresSessionState
	{
		private const long FavoriteFlag = 134217728;

		private const long ShortcutFlag = 268435456;

		public override MemberResultData MemberOperation()
		{
			//HttpSessionState Session = HttpContext.Current.Session;
			//MemberResultData ResultData = base.ResultData;
			//// 未從捷徑入口進入或未登入會員
			//if (Session["ShortcutType"] == null || Session["IsLogin"] == null)
			//{
			//	return ResultData;
			//}

			//long MemberEventFlag = Convert.ToInt64(Session["ActivityMask"]);
			//// ShortcutType: 1 => 書籤 / 我的最愛, 2 => 老子捷徑檔
			//int ShortcutType = Convert.ToInt32(Session["ShortcutType"]);
			//long UseFlag = ShortcutType == 1 ? FavoriteFlag : ShortcutFlag;

			//if ((MemberEventFlag & UseFlag) != UseFlag)
			//{
			//	return ResultData;
			//}
			//SqlParameter[] objParam = new SqlParameter[]
			//{
			//	new SqlParameter("@IsClear", SqlDbType.Bit),
			//	new SqlParameter("@MemberID", Session["MemberID"]),
			//	new SqlParameter("@LoginEventFlag", UseFlag)
			//};
			//objParam[0].Direction = ParameterDirection.Output;
			//try
			//{
			//	SqlDataReader objSdr = SqlHelper.ExecuteReader
			//	(
			//		WebConfig.ConnectionString,
			//		CommandType.StoredProcedure,
			//		"NSP_GameWeb_SystemPresentGift",
			//		objParam
			//	);
			//	using (objSdr)
			//	{
			//		while (objSdr.Read())
			//		{
			//			long KeyInOutID = Convert.ToInt64(objSdr["EventID"]);
			//			decimal Points = Convert.ToDecimal(objSdr["ChangePoints"]);
			//			int PointType = Convert.ToInt32(objSdr["PointType"]);
			//			int MemberID = Convert.ToInt32(objSdr["Target_MemberID"]);
			//			string fsResult = FSCommander.FS_AS_CREDIT_CHANGE(KeyInOutID, MemberID, Points, PointType);
			//		}
			//		objSdr.Close();
			//	}
			//	if (Convert.ToBoolean(objParam[0].Value))
			//	{
			//		Session["ActivityMask"] = MemberEventFlag ^ UseFlag;
			//		Session.Remove("ShortcutType");
			//	}
			//}
			//catch (Exception ex)
			//{
			//	log4net.LogManager.GetLogger(typeof(GetShortcutGift)).Error(ex);
			//}
			//return ResultData;

			return base.ResultData;
		}
	}
}