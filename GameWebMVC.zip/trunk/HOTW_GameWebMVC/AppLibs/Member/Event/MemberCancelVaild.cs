﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using GS.Utilities;

namespace HOTW_GameWebMVC.AppLibs
{
	public class MemberCancelVaild : MemberDecorator
	{
		#region MemberDecorator成員
		public override MemberResultData MemberOperation()
		{
			MemberResultData ResultData = new MemberResultData();
			SqlParameter[] param = new SqlParameter[]
			{
				new SqlParameter("@MemberID", minfo.MemberID),
				new SqlParameter("@Mobile", minfo.Mobile),
				new SqlParameter("@IsReturn", "1")
			};
			SqlDataReader objDr = SqlHelper.ExecuteReader
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_GameWeb_MemberCancelMobileCertification",
				param
			);
			objDr.Read();
			ResultData.ResultCode = Convert.ToInt32(objDr["Result"]);
            ResultData.ResultMsg = ResultData.ResultCode == 0 ? "取消成功！" : "取消失敗！";
			ResultData.IsNext = ResultData.ResultCode == 0;
			objDr.Close();
			return ResultData;
		}
		#endregion
	}
}