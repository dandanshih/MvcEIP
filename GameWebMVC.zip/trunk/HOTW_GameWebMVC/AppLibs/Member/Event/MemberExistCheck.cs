﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using GS.Utilities;
using System.Data;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.AppLibs
{
	/// <summary>
	/// 檢查會員帳號是否存在
	/// </summary>
	public class MemberExistCheck : MemberDecorator, IRequiresSessionState
	{
		#region MemberDecorator成員
		public override MemberResultData MemberOperation()
		{
			MemberResultData ResultData = new MemberResultData();
			SqlParameter[] param =
            {
                new SqlParameter("@MemberAccount", minfo.MemberAccount),
				new SqlParameter("@ResultCode", DbType.Int32)
            };

			param[1].Direction = ParameterDirection.Output;

			DataSet ds = SqlHelper.ExecuteDataset
			(
				WebConfig.ConnectionString,
				CommandType.StoredProcedure,
				"NSP_CW_A_Member_NewCheck",
				param
			);

			ResultData.ResultCode = Convert.ToInt32(param[1].Value);
			if (ResultData.ResultCode != 1)
			{
				ResultData.IsNext = false;
			}
			if (Convert.ToInt32(ds.Tables[0].Rows[0]["MemberID"]) != 0 && minfo.SourceName.ToLower() != "online113")
			{
				minfo.MemberID = Convert.ToInt32(ds.Tables[0].Rows[0]["MemberID"]);				
				HttpContext.Current.Session["MemberAttribute"] = ds.Tables[0].Rows[0]["MemberFlag"].ToString();

                if (System.Configuration.ConfigurationManager.AppSettings["IsLogMemberAttribute"].ToString().Equals("1"))
                {
                    log4net.LogManager.GetLogger(typeof(MemberExistCheck)).DebugFormat("MemberExistCheck ===> MemberOperation ===> MemberID:{0}, MemberAttribute:{1}", minfo.MemberID, HttpContext.Current.Session["MemberAttribute"]);
                }
			}
			
			return ResultData;
		}
		#endregion
	}
}