﻿using System.ComponentModel;
using System.Text;

namespace HOTW_GameWebMVC.AppLibs.Payment
{
    public class PaymentInfo
    {
        /// <summary>
        /// 會員編號。
        /// </summary>
        public int MemberID { get; set; }

        /// <summary>
        /// 會員帳號。
        /// </summary>
        public string MemberAccount { get; set; }

        /// <summary>
        /// 交易金額。
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// 實得點數。
        /// </summary>
        public decimal Point { get; set; }

        /// <summary>
        /// ECoupon 序號。
        /// </summary>
        public string EcouponCode { get; set; }

        /// <summary>
        /// 儲值群組種類 (1:線上購點 2:序號儲值 3:超值包月 4:線上轉點 5:FB儲值 6:背動式儲值)。
        /// </summary>
        public int ProductGroup { get; set; }

        /// <summary>
        /// 付款方式編號。
        /// </summary>
        public int ProductType { get; set; }

        /// <summary>
        /// 儲值金額編號。
        /// </summary>
        public int PaymentValueID { get; set; }

        /// <summary>
        /// 儲值卡用。
        /// </summary>
        public string ProductID { get; set; }

        /// <summary>
        /// 是否驗證點數(目前只有線上購點有優惠需要作驗證)。
        /// </summary>
        public bool IsCheck { get; set; }

        /// <summary>
        /// 客戶EMail。
        /// </summary>
        public string CustEmail { get; set; }

        /// <summary>
        /// 客戶發票取得方式 (0:捐給創世基金會 1:索取電子發票 2:索取紙本發票)。
        /// </summary>
        public int CustInvoiceType { get; set; }

        /// <summary>
        /// 客戶真實姓名。
        /// </summary>
        public string CustName { get; set; }

        /// <summary>
        /// 客戶鄉鎮編號。
        /// </summary>
        public string CustZoneID { get; set; }

        /// <summary>
        /// 客戶寄送發票住址。
        /// </summary>
        public string CustAddress { get; set; }

        /// <summary>
        /// IPad 所需之產品編號。
        /// </summary>
        public string AppProductID { get; set; }

        /// <summary>
        /// PaymentGateway 需要之RequestType。
        /// </summary>
        public int RequestType = 0;

        /// <summary>
        /// 是否為儲值卡 (0:線上購點 1:儲值卡)
        /// </summary>
        public int IsStoredValue = 0;

        /// <summary>
        /// 是否非同步建立PG訂單。
        /// </summary>
        public bool IsAsync { get; set; }

        /// <summary>
        /// 銀行訂單編號。
        /// </summary>
        public string BankOrderID { get; set; }

        /// <summary>
        /// PaymentGateway 訂單編號。
        /// </summary>
        public string PGOrderID { get; set; }

        /// <summary>
        /// 交易結束顯示結果頁。
        /// </summary>
        public string OrderFinalUrl { get; set; }

        /// <summary>
        /// 交易結束顯示結果頁後面帶Get參數。
        /// </summary>
        public string OrderFinalUrlQueryString { get; set; }

        /// <summary>
        /// 給 PG 的產品名稱。
        /// </summary>
        public string PaymentGatewayProductID { get; set; }

        /// <summary>
        /// 給 PG 所需之擴充資訊。
        /// </summary>
        public string PaymentGatewayExtension { get; set; }

        /// <summary>
        /// 來源平台。
        /// </summary>
        public int Platinum { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("MemberID=" + MemberID);
            sb.AppendLine("MemberAccount=" + MemberAccount);
            sb.AppendLine("Amount=" + Amount);
            sb.AppendLine("Point=" + Point);
            sb.AppendLine("EcouponCode=" + EcouponCode);
            sb.AppendLine("ProductGroup=" + ProductGroup);
            sb.AppendLine("ProductType=" + ProductType);
            sb.AppendLine("PaymentValueID=" + PaymentValueID);
            sb.AppendLine("ProductID=" + ProductID);
            sb.AppendLine("IsCheck=" + IsCheck);
            sb.AppendLine("CustEmail=" + CustEmail);
            sb.AppendLine("CustInvoiceType=" + CustInvoiceType);
            sb.AppendLine("CustName=" + CustName);
            sb.AppendLine("CustZoneID=" + CustZoneID);
            sb.AppendLine("CustAddress=" + CustAddress);
            sb.AppendLine("AppProductID=" + AppProductID);
            sb.AppendLine("RequestType=" + RequestType);
            sb.AppendLine("IsStoredValue=" + IsStoredValue);
            sb.AppendLine("IsAsync=" + IsAsync);
            sb.AppendLine("BankOrderID=" + BankOrderID);
            sb.AppendLine("PGOrderID=" + PGOrderID);
            sb.AppendLine("OrderFinalUrl=" + OrderFinalUrl);
            sb.AppendLine("OrderFinalUrlQueryString=" + OrderFinalUrlQueryString);
            sb.AppendLine("PaymentGatewayProductID=" + PaymentGatewayProductID);
            sb.AppendLine("PaymentGatewayExtension=" + PaymentGatewayExtension);
            sb.AppendLine("PGOrderID=" + PGOrderID);

            return base.ToString();
        }
    }
}