﻿//-- 通用類 --//
using System;
using System.Collections.Generic;
//-- 動態取得屬性 --//
using System.Linq;
// 網頁類, 系統操作
using System.IO;
//-- 網頁類使用 --//
using System.Net;
using System.Text;

public partial class Utility
{
	#region DB 的時間轉換

	// 把 C# 的時間轉為 DB 的時間格式
	public static string ChangeDateTimeToDBTime(System.DateTime datetime)
	{
		return datetime.ToString("yyyy-MM-dd hh:mm:ss");
	}

	// 把 DB 的字串時間格式轉為 C# 的 DateTime
	public static System.DateTime ChangeDBTimeToDateTime(string strDBTime)
	{
		return System.Convert.ToDateTime(strDBTime);
	}

	#endregion
	
	#region  檔案系統類的操作

	// Check the File Exits
	public static bool IsFileExist(string strFilename)
	{
		return System.IO.File.Exists(strFilename);
	}

	// 建立目錄
	public static bool MakeDir(string DirPath)
	{
		if (Directory.Exists(DirPath) == true)
			return true;
		DirectoryInfo DirInfo = Directory.CreateDirectory(DirPath);
		return true;
	}

	// 寫入檔案
    public static void WriteFile(string strFilename, string Data)
	{
        FileStream file = new FileStream(strFilename, FileMode.Append);
		StreamWriter sw = new StreamWriter(file);
		sw.WriteLine(Data);
		sw.Close();
		file.Close();
	}

    // 清除檔案內容
    public static void ResetFile(string strFilename)
    {
        FileStream file = new FileStream(strFilename, FileMode.Create);
        file.Close();
    }

    // 利用系統開檔
    public static void SystemOpenFile(string strFilename)
    {
        System.Diagnostics.Process.Start(strFilename);
    }

	#endregion

	#region 網頁類的操作

	// 從網頁抓取資料
	public static string HttpGet(string strURL, string strEncode = "big5")
	{
		// 產生連線
		WebRequest WebConnect = WebRequest.Create(strURL);
		// 取得資料
		Stream objStream = WebConnect.GetResponse().GetResponseStream();
		System.Text.Encoding encode = System.Text.Encoding.GetEncoding(strEncode);
		// 讀出資料
		StreamReader objReader = new StreamReader(objStream, encode);
		// 記下結果
		string strOut = objReader.ReadToEnd();
		// 清除資料
		objReader.Dispose();
		objStream.Dispose();
		WebConnect = null;
		// 傳回結果
		return strOut;
	}

    // 更新次數
    static int m_UpdateTime = 300;
    public static void HttpToFile(string strURL, string strFilename, bool IsOverWrite=true)
    {
        if (IsOverWrite == false)
        {
            if (IsFileExist(strFilename) == true)
                return;
        }
        // 休息一下
        System.Threading.Thread.Sleep(m_UpdateTime);
        // Get from http
        string strData = HttpGet(strURL);
        // write it to the file
        WriteFile(strFilename, strData);
	}

	#endregion
}
