﻿// Author : dandanshih

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Security;
using System.Reflection;

namespace GWeb
{
	#region PaymentGatewayDB
	public class PaymentGatewayDB
	{
		private static MSSQL _instance = null;
		public static MSSQL DB
		{
			get
			{
				if (_instance == null)
					_instance = new MSSQL("10.9.11.2", "51098", "PaymentGateway", "sa", "sqlgosmio2749");
				return _instance;
			}
		}
	}
	#endregion

	#region GameActivityDB
	public class GameActivityDB
	{
		private static MSSQL _instance = null;
		public static MSSQL DB
		{
			get
			{
				if (_instance == null)
					_instance = new MSSQL("db.08online.rd1.sgt", "51095", "Game_Activity", "sa", "sqlgosmio2749");
				return _instance;
			}
		}
	}
	#endregion

	#region GameWorthDB
	public class GameWorthDB
	{
		private static MSSQL _instance = null;
		public static MSSQL DB
		{
			get
			{
				if (_instance == null)
					_instance = new MSSQL("db.08online.rd1.sgt", "51095", "Game_Worth", "sa", "sqlgosmio2749");
				return _instance;
			}
		}
	}
	#endregion

	#region GameBranchDB
	public class GameBranchDB
	{
		private static MSSQL _instance = null;
		public static MSSQL DB
		{
			get
			{
				if (_instance == null)
					_instance = new MSSQL("db.08online.rd1.sgt", "51095", "Game_Branch", "sa", "sqlgosmio2749");
				return _instance;
			}
		}

		// 修改開分資料
		public static void Add_A_MemberCreditChangeEvent_ChangePoints(long iKey, double dRate, string strOrderID)
		{
			string strCommand = string.Format("update A_MemberCreditChangeEvent set ChangePoints = ChangePoints * {0} where RowID = {1}", dRate, iKey);
			DB.DB_SendCommand(strCommand);
			strCommand = string.Format("update A_MemberOrder set FinalPoints = FinalPoints * {0} where OrderID='{1}'", dRate, strOrderID);
			GameWorthDB.DB.DB_SendCommand(strCommand);
		}
	}
	#endregion

	#region 活動的判定 API
	public class S_ActivityUtility
	{
		// 檢查活動時間看看對不對
		public static bool CheckActivityTime(Dictionary<string, object> dictActivityInfo)
		{
			// 欄位不對不做處理
			if (dictActivityInfo.ContainsKey("IntervalTime") == false)
				return false;
			// 取得時間限制字串
			string strTimeInfo = dictActivityInfo["IntervalTime"].ToString();
			// 做時間字串的切割和取得
			if (strTimeInfo == "")
				return true;
			// problem : 目前沒有寫定規則
			// 回傳回結果
			return true;
		}

		// 檢查一些 PaymentGateway 相關的
		public static bool CheckGroupRuler(Dictionary<string, object> dictActivity, string strAccountName)
		{
			// 先解開參數
			if (dictActivity.ContainsKey("PlayerRuler") == false)
				return false;
			string strRuler = dictActivity["PlayerRuler"].ToString();
			Dictionary<string, object> dictRuler = Utility.TranslateRuler(strRuler);

			// 判定參數
			if (dictRuler.ContainsKey("GroupID") == false)
			{
				// 沒有限制表示每一個人都可以參加這個活動
				return true;
			}
			// 切出活動群組
			List<string> listGroup = Utility.TranslateCondition(dictRuler["GroupID"].ToString());
			// 抓取玩家群組
			List<List<object>> listDBResult = null;
			string strCommand = "";
			strCommand = string.Format("select GroupID from S_Activity_Group where CustPID='{0}'", strAccountName);
			listDBResult = PaymentGatewayDB.DB.DB_SendQueryCommand(strCommand);
			for (int Index = 0; Index < listDBResult.Count; Index++)
			{
				string strGroupID = listDBResult[Index][0].ToString();
				// 如果有在群組中就回傳可以
				if (listGroup.Contains(strGroupID))
					return true;
			}
			// 就不在活動中
			return false;
		}

		// 取得期間的消費
		public static double GetTotalMoneyInPeriod(string strMemberID, object oStartTime, object oEndTime)
		{
			System.DateTime StartTime = System.Convert.ToDateTime(oStartTime);
			System.DateTime EndTime = System.Convert.ToDateTime(oEndTime);
			//Dictionary<string, object> dictMemberInfo = GetMemberInfoByMember(strMemberID);
			//int iMemberID = System.Convert.ToInt32(dictMemberInfo["MemberID"].ToString());
			string strCommand = string.Format("select sum(FinalPrice) from A_MemberOrder where MemberID = {0} and LastModifyDate > '{1}' and LastModifyDate < '{2}'", strMemberID, Utility.ChangeDateTimeToDBTime(StartTime), Utility.ChangeDateTimeToDBTime(EndTime));
			List<List<object>> listDBResult = GameWorthDB.DB.DB_SendQueryCommand(strCommand);
			if (listDBResult[0][0] == "")
				return 0;
			else
				return System.Convert.ToDouble(listDBResult[0][0]);
		}

		// 利用 MemberAccount or MemberID 去取得一些資料
		public static Dictionary<string, object> GetMemberInfoByMember(object Account)
		{
			string strCondition = "";
			if (Account.GetType() == typeof(int))
			{
				strCondition = string.Format("MemberID = {0}", Account);
			}
			else
			{
				strCondition = string.Format("MemberAccount = '{0}'", Account);
			}
			Dictionary<string, object> dictResult = new Dictionary<string, object>();
			string strCommand = string.Format("select MemberID, MemberAccount, CreateDate, LastLoginDate, LastLoginIP, VIP_Level from A_Member where {0}", strCondition);
			List<List<object>> listDBResult = GameBranchDB.DB.DB_SendQueryCommand(strCommand);
			if (listDBResult.Count != 1)
				return dictResult;
			dictResult["MemberID"] = listDBResult[0][0];
			dictResult["MemberAccount"] = listDBResult[0][1];
			dictResult["CreateDate"] = Utility.ChangeDateTimeToDBTime (System.Convert.ToDateTime(listDBResult[0][2]));
			dictResult["LastLoginDate"] = listDBResult[0][3];
			dictResult["LastLoginIP"] = listDBResult[0][4];
			dictResult["VIP_Level"] = listDBResult[0][5];
			return dictResult;
		}

		// 檢查參加次數
		public static bool CheckCanJoinActivity(string strActivityKey, int ActivityID, string strMemberID)
		{
			// 如果是單筆, 就超過就給
			if (strActivityKey == "SingleMoneyMax")
			{
				return true;
			}
			// 如果是單筆在區間, 也是都給
			else if (strActivityKey == "SingleMoney")
			{
				return true;
			}
			// 如果是滿額送就是只有一次
			else if (strActivityKey == "TotalMoney")
			{
				string strCommand = string.Format("select count(*) from S_Shop_Activity_Record where MemberID = '{0}' and ActivityID = {1} and Flag = 1", strMemberID, ActivityID);
				List<List<object>> listDBResult = GameActivityDB.DB.DB_SendQueryCommand(strCommand);
				int iNumber = System.Convert.ToInt32(listDBResult[0][0]);
				if (iNumber > 0)
					return false;
				return true;
			}
			// 沒有就回傳不行
			return false;
		}

	}
	#endregion


	[System.Web.Script.Services.ScriptService]
	public partial class ActivityMgr
	{
		// 建構子的處理
		public ActivityMgr()
		{
		}

		#region PaymentGetway取得活動

		public static string PaymentGateway_GetActivity(string SSID, string strCustPID, string Amount)
		{
			List<Dictionary<string, object>> listResult = new List<Dictionary<string, object>>();
			// 變數相關的宣告
			string strCommand = string.Format("");
			List<List<object>> listDBResult = null;
			// 取得所有的活動 (己判定了時間區段, SSID)
			strCommand = string.Format("select ActivityID, Name, StartTime, EndTime, IntervalTime, PlayerRuler, Award from S_Activity where (StartTime < '{0}' and EndTime > '{0}') and (SSID='' or SSID='{1}')", System.DateTime.Now.ToString("yyyy-MM-dd"), SSID);
			listDBResult = PaymentGatewayDB.DB.DB_SendQueryCommand(strCommand);
			// 一個活動一個活動加進來
			for (int IRow = 0; IRow < listDBResult.Count; IRow++)
			{
				List<object> listRow = listDBResult[IRow];
				// 取得活動相關資料
				Dictionary<string, object> dictResult = new Dictionary<string, object>();
				dictResult["ActivityID"] = listRow[0];
				dictResult["Name"] = listRow[1];
				dictResult["StartTime"] = Utility.ChangeDateTimeToDBTime (System.Convert.ToDateTime(listRow[2]));
				dictResult["EndTime"] = Utility.ChangeDateTimeToDBTime(System.Convert.ToDateTime(listRow[3]));
				dictResult["IntervalTime"] = listRow[4];
				dictResult["PlayerRuler"] = listRow[5];
				dictResult["Award"] = listRow[6];
				dictResult["Amount"] = Amount;
				// 檢查 Group
				if (S_ActivityUtility.CheckGroupRuler(dictResult, strCustPID) == false)
					continue;
				// 把活動加進來
				listResult.Add(dictResult);
			}
			return Json.Serialize(listResult);
		}

		#endregion

		#region StoreAPI 處理活動的規則
		// 寫 Log
		static void _WriteShopActivityLog(Dictionary<string, object> dictActivity, string strMemberID, int iResult, string strMsg, string strOrderID)
		{
			string strCommand = "";
			strCommand = string.Format("insert into S_Shop_Activity_Record (ActivityID, RecordDate, Flag, Result, OtherInfo, MemberID, OrderID) values ({0}, '{1}', {5}, '{2}', '{3}', '{4}', '{6}')", dictActivity["ActivityID"].ToString(), System.DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"), strMsg, Json.Serialize(dictActivity), strMemberID, iResult, strOrderID);
			log4net.LogManager.GetLogger(typeof(ActivityMgr)).Error(strCommand); 
			GameActivityDB.DB.DB_SendCommand(strCommand);
		}

		// 處理活動規則
		public static List<Dictionary<string, object>> _ProcessActivityRuler(string strJson, string strMemberID, string strOrderID)
		{
			List<Dictionary<string, object>> listFitActivity = new List<Dictionary<string, object>>();
			string strResult = "";
			List<object> listActivity = Json.Deserialize(strJson) as List<object>;
			// 每一條規則都去看和去處理
			foreach (object oActivity in listActivity)
			{
				Dictionary<string, object> dictActivity = oActivity as Dictionary<string, object>;
				strResult += "[Process Activity]" + dictActivity["ActivityID"].ToString();
				// 沒有規則就不能處理
				if (dictActivity.ContainsKey("PlayerRuler") == false)
				{
					strResult += "no PlayerRuler !!";
					_WriteShopActivityLog(dictActivity, strMemberID, 0, "no PlayerRuler", strOrderID);
					continue;
				}
				// 沒有金額也不能處理
				if (dictActivity.ContainsKey("Amount") == false)
				{
					strResult += "no Amount !!";
					_WriteShopActivityLog(dictActivity, strMemberID, 0, "no Amount", strOrderID);
					continue;
				}
				int iAmount = System.Convert.ToInt32(dictActivity["Amount"]);
				int iActivityID = System.Convert.ToInt32(dictActivity["ActivityID"]);
				// 取得和轉換規則
				string strRuler = dictActivity["PlayerRuler"].ToString();
				Dictionary<string, object> dictRuler = Utility.TranslateRuler(strRuler);
				// 一個一個處理規則
				// 單次儲值超過指定值
				string strMsg = "";
				int iResult = 1;
				if (dictRuler.ContainsKey("SingleMoneyMax") == true)
				{
					int iMoney = System.Convert.ToInt32(dictRuler["SingleMoneyMax"]);
					if (iAmount >= iMoney)
					{
						// 檢查活動是否可以重覆參加
						if (S_ActivityUtility.CheckCanJoinActivity("SingleMoneyMax", iActivityID, strMemberID) == false)
						{
							_WriteShopActivityLog(dictActivity, strMemberID, 0, "[CheckCanJoinActivity Failure] !!", strOrderID);
							continue;
						}
						listFitActivity.Add(dictActivity);
						//strResult += Send_Gift(dictActivity);
					}
					else
					{
						strMsg = string.Format("SingleMoneyMax Failure : {0} is not over {1}", iAmount, iMoney);
						iResult = 0;
					}
					_WriteShopActivityLog(dictActivity, strMemberID, iResult, strMsg, strOrderID);
				}
				// 單次儲值在 (Min, Max) 之間
				else if (dictRuler.ContainsKey("SingleMoney") == true)
				{
					List<string> listMoney = Utility.TranslateCondition(dictRuler["SingleMoney"]);
					int iMinMoney = System.Convert.ToInt32(listMoney[0]);
					int iMaxMoney = System.Convert.ToInt32(listMoney[1]);
					if (iAmount >= iMinMoney && iAmount <= iMaxMoney)
					{
						// 檢查活動是否可以重覆參加
						if (S_ActivityUtility.CheckCanJoinActivity("SingleMoney", iActivityID, strMemberID) == false)
						{
							_WriteShopActivityLog(dictActivity, strMemberID, 0, "[CheckCanJoinActivity Failure] !!", strOrderID);
							continue;
						}
						//strResult += Send_Gift(dictActivity);
						listFitActivity.Add(dictActivity);
					}
					else
					{
						strMsg = string.Format("SingleMoney Failure : {0} is not between {1} and {2}", iAmount, iMinMoney, iMaxMoney);
						iResult = 0;
					}
					_WriteShopActivityLog(dictActivity, strMemberID, iResult, strMsg, strOrderID);
				}
				// 滿額
				else if (dictRuler.ContainsKey("TotalMoney") == true)
				{
					int iMoney = System.Convert.ToInt32(dictRuler["TotalMoney"]);
					double dTotal = S_ActivityUtility.GetTotalMoneyInPeriod(strMemberID, dictActivity["StartTime"], dictActivity["EndTime"]);
					if (dTotal >= iMoney)
					{
						// 檢查活動是否可以重覆參加
						if (S_ActivityUtility.CheckCanJoinActivity("TotalMoney", iActivityID, strMemberID) == false)
						{
							_WriteShopActivityLog(dictActivity, strMemberID, 0, "[CheckCanJoinActivity Failure] !!", strOrderID);
							continue;
						}
						//strResult += Send_Gift(dictActivity);
						listFitActivity.Add(dictActivity);
					}
					else
					{
						strMsg = string.Format("TotalMoney Failure : {0} is not over {1}", iAmount, iMoney);
						iResult = 0;
					}
					_WriteShopActivityLog(dictActivity, strMemberID, iResult, strMsg, strOrderID);
				}
				else
				{
					strResult += "no Ruler!!";
					_WriteShopActivityLog(dictActivity, strMemberID, 0, "No Ruler!!", strOrderID);
				}
			}
			//return strResult;
			return listFitActivity;
		}

		#endregion

		#region Store 去寫入和取得暫時存放在 DB 的活動資料
		// 寫訂單的功能 : 從101 取得資料時, 暫時先寫入 DB
		public static string WriteActivityToDB(string OrderID, string Information)
		{
			Information = Utility.TranslateDBString(Information);
			string strCommand = string.Format("update A_MemberOrder set ShopActivityList = '{0}' where OrderID = '{1}'", Information, OrderID);
			GameWorthDB.DB.DB_SendCommand(strCommand);
			return "[_WriteActivityToDB] " + strCommand;
		}

		// 103 回來時, 從DB 去取得活動資料
		public static Dictionary<string, object> GetActivityByOrderID(string OrderID)
		{
			Dictionary<string, object> dictResult = new Dictionary<string, object>();
			string strCommand = "";
			List<List<object>> listDBResult = null;
			// 利用訂單從 Db 取得資料
			strCommand = string.Format("select MemberID, PaymentType, FinalPrice, IsCancel, ShopActivityList from A_MemberOrder where OrderID = '{0}'", OrderID);
			listDBResult = GWeb.GameWorthDB.DB.DB_SendQueryCommand(strCommand);
			if (listDBResult.Count != 1)
				return dictResult;
			dictResult["MemberID"] = listDBResult[0][0];
			dictResult["PaymentType"] = listDBResult[0][1];
			dictResult["FinalPrice"] = listDBResult[0][2];
			dictResult["IsCancel"] = listDBResult[0][3];
			dictResult["ShopActivityList"] = listDBResult[0][4];
			dictResult["OrderID"] = OrderID;
			return dictResult;
		}

		#endregion

	}
}