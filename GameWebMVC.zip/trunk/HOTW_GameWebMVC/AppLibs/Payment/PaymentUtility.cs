﻿using GS.Utilities;
using PaymentGateway.StoreAPI;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace HOTW_GameWebMVC.AppLibs.Payment
{
    public class PaymentUtility
    {
        private PaymentClientMvc pmc = null;

        /// <summary>
        /// 跑 PaymentGateway 流程。
        /// </summary>
        /// <param name="info"></param>
        /// <returns>
        /// ResultCode: 回傳狀態
        ///      0: 成功
        ///     -1: 無此會員
        ///     -2: 站內訂單建立失敗
        ///     -3: 儲值超過限額
        ///     -4: 購買點數及金額有誤
        ///     -5: 關機維護中，無法儲值。
        /// ResultMessage: 回傳訊息
        /// ResultView: 回傳狀態為0 會輸出 PaymentGateway View 提供轉頁
        /// </returns>
        public PaymentResult GoPaymentGateway(PaymentInfo info)
        {
            PaymentResult result = new PaymentResult();

            info.MemberAccount = string.IsNullOrEmpty(info.MemberAccount) ? "" : info.MemberAccount.Trim();
            info.EcouponCode = string.IsNullOrEmpty(info.EcouponCode) ? "" : info.EcouponCode.Trim();
            info.ProductID = string.IsNullOrEmpty(info.ProductID) ? "" : info.ProductID.Trim();
            info.CustEmail = string.IsNullOrEmpty(info.CustEmail) ? "" : info.CustEmail.Trim();
            info.CustName = string.IsNullOrEmpty(info.CustName) ? "" : info.CustName.Trim();
            info.CustZoneID = string.IsNullOrEmpty(info.CustZoneID) ? "" : info.CustZoneID.Trim();
            info.CustAddress = string.IsNullOrEmpty(info.CustAddress) ? "" : info.CustAddress.Trim();
            info.AppProductID = string.IsNullOrEmpty(info.AppProductID) ? "" : info.AppProductID.Trim();
            info.BankOrderID = string.IsNullOrEmpty(info.BankOrderID) ? "" : info.BankOrderID.Trim();
            info.PGOrderID = string.IsNullOrEmpty(info.PGOrderID) ? "" : info.PGOrderID.Trim();
			if (info.Platinum == 5)
			{
				info.OrderFinalUrl =  "/Mvc/DynamicPages/MobileApp/Bank/PaymentFinsh";
			}
			else
			{
				info.OrderFinalUrl = string.IsNullOrEmpty(info.OrderFinalUrl) ? "" : info.OrderFinalUrl.Trim();
			}
            info.OrderFinalUrlQueryString = string.IsNullOrEmpty(info.OrderFinalUrlQueryString) ? "" : info.OrderFinalUrlQueryString.Trim();
            info.PaymentGatewayProductID = string.IsNullOrEmpty(info.PaymentGatewayProductID) ? "" : info.PaymentGatewayProductID.Trim();
            info.PaymentGatewayExtension = string.IsNullOrEmpty(info.PaymentGatewayExtension) ? "" : info.PaymentGatewayExtension.Trim();

            // 先向DB要商店端訂單編號及客戶資料
            SqlParameter[] param = 
			{
				new SqlParameter("@MemberID", info.MemberID),
				new SqlParameter("@MemberAccount", info.MemberAccount),
                // 交易內容參數
				new SqlParameter("@Amount", info.Amount),
				new SqlParameter("@Point", info.Point),
				new SqlParameter("@ECouponCode", (info.EcouponCode != null) ? info.EcouponCode : ""),
                // 儲值方式參數
				new SqlParameter("@ProductGroup", info.ProductGroup.ToString()),
				new SqlParameter("@ProductType", info.ProductType.ToString()),
                new SqlParameter("@PaymentValueID", info.PaymentValueID.ToString()),
				new SqlParameter("@ProductID", info.ProductID),
				new SqlParameter("@IsCheck", info.IsCheck ? "1" : "0"),
                // 發票記錄參數
				new SqlParameter("@EMail", info.CustEmail),
				new SqlParameter("@InvoiceType", info.CustInvoiceType.ToString()),
				new SqlParameter("@MemberName", info.CustName),
				new SqlParameter("@Invoice_ZoneID", info.CustZoneID),
				new SqlParameter("@Invoice_Address", info.CustAddress),

				new SqlParameter("@AppProductID", info.AppProductID),
				new SqlParameter("@OrderExtension", info.PaymentGatewayExtension),

				new SqlParameter("@Platinum", info.Platinum)
			};

            using (SqlDataReader sdr = SqlHelper.ExecuteReader
            (
                WebConfig.ConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_A_CreateWorthOrder",
                param
            ))
            {
                if (sdr.Read())
                {
                    switch (sdr["ResultCode"].ToString())
                    {
                        case "0":
                            pmc = new PaymentClientMvc
                            (
                                WebConfig.PaymentGatewayHost
                                , WebConfig.PaymentStoreID
                                , WebConfig.PaymentEncryptKey
                            );

                            pmc.BeforePaying += new BeforePayingHandler(payingHandler_BeforePaying);

                            pmc.NickName = sdr["NickName"].ToString();
                            pmc.IsInvoiceType = info.CustInvoiceType.ToString();
                            pmc.CustPID = info.MemberAccount;
                            pmc.CustName = info.CustName;
                            pmc.CustEMail = info.CustEmail;
                            pmc.CustHomeTel = sdr["Phone"].ToString();
                            pmc.CustMobileTel = sdr["Mobile"].ToString();
                            pmc.CustAddress = sdr["Address"].ToString();

                            if (info.RequestType != 0)
                            {
                                pmc.RequestType = info.RequestType;
                            }

                            if (!string.IsNullOrEmpty(info.PGOrderID))
                            {
                                pmc.PGOrderID = info.PGOrderID;
                            }

                            pmc.Amount = info.Amount;
                            pmc.StoreOrderID = sdr["OrderID"].ToString();
                            pmc.PaymentTypeID = int.Parse(sdr["PaymentTypeID"].ToString());
                            if (sdr["PaymentGatewayExtension"] != null && !string.IsNullOrEmpty(sdr["PaymentGatewayExtension"].ToString()))
                            {
                                pmc.OrderExtension = sdr["PaymentGatewayExtension"].ToString();
                            }
                            else
                            {
                                pmc.OrderExtension = info.PaymentGatewayExtension;
                            }

                            pmc.ProductName = sdr["ProductName"].ToString();
                            if (sdr["PaymentGatewayProductID"] != null && !string.IsNullOrEmpty(sdr["PaymentGatewayProductID"].ToString()))
                            {
                                pmc.ProductID = sdr["PaymentGatewayProductID"].ToString();
                            }
                            else
                            {
                                pmc.ProductID = info.PaymentGatewayProductID;
                            }
                            pmc.CurrencyType = Convert.ToInt32(sdr["CoinType"]);

                            pmc.IsAsync = info.IsAsync;

                            pmc.BankOrderID = info.BankOrderID;

                            pmc.OrderReportUrl = WebConfig.PaymentOrderReportUrl;

                            pmc.OrderFinalUrl = (info.OrderFinalUrl != "")
                                ? "http://" + WebConfig.Domain + info.OrderFinalUrl : WebConfig.PaymentOrderFinalUrl;
                            pmc.OrderFinalUrl += "/" + HttpUtility.UrlEncode(HttpUtility.UrlEncode(info.OrderFinalUrlQueryString));

                            pmc.OrderRecordedUrl = WebConfig.PaymentOrderRecordedUrl;

#if (!Online)
                            pmc.IsTestOrder = true;
#else
							    pmc.IsTestOrder = false;
#endif

                            // 傳送訂單資料給PaymentGateway
                            result.View = pmc.SendOrderRequest();
                            break;
                        default:
                            log4net.LogManager.GetLogger(typeof(PaymentUtility)).DebugFormat("CreateWorthOrder 失敗::{0}\r\n{1}\r\n{2}", sdr["ResultCode"], sdr["ResultMsg"], info.ToString());
                            result.Code = int.Parse(sdr["ResultCode"].ToString());
                            result.Message = sdr["ResultMsg"].ToString();
                            break;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// PaymentGateway 初步驗證。
        /// </summary>
        private void payingHandler_BeforePaying(object sender, PayingEventArgs e)
        {
			log4net.LogManager.GetLogger(typeof(PaymentUtility)).DebugFormat("[NickShih] payingHandler_BeforePaying");
            if (e.ResultCode == 0)
            {
                // 要求成功.
                // 這裡用來把 StoreAPI 所得到的訂單編號回填到自己商店端的資料庫中, 以利後續商店自己的訂單處理
                // 處理完畢之後, 不要執行任何 Response.End() 之類中斷 HTTP 傳輸的指令, 因為 StoreAPI 還要繼續執行.
                Console.WriteLine("交易獲淮! PaymentGateway訂單編號: " + e.PGOrderID);
				// 把一些活動資料寫到 DB 去
				Console.WriteLine(e.ActivityListJson);
				GWeb.ActivityMgr.WriteActivityToDB(e.SSOrderID, e.ActivityListJson);
				log4net.LogManager.GetLogger(typeof(PaymentUtility)).DebugFormat("[NickShih] OrderID:{0}, Json:{1}", e.SSOrderID, e.ActivityListJson);
			}
            else
            {
                // 回傳碼如果不是 0, 代表有問題, 可以印出錯誤代碼在畫面上給 User 看, 而錯誤訊息最好不要直接給 User 看, 
                // 而是固定傳回某幾種代表性的錯誤訊息即可. 
                // 處理完畢之後可以執行 Response.End() 之類的指令, 因為錯誤所以 StoreAPI 不會再往下執行了. 
                try
                {
                    SqlParameter[] param = 
					{
						// PaymentGateway端產生的訂單編號
						new SqlParameter("@PGOrderID", (e.PGOrderID != null && e.PGOrderID != "") ? e.PGOrderID : "")
						// 商店端自訂訂單編號
						, new SqlParameter("@OrderID", e.SSOrderID)
						// 交易結果代碼
						, new SqlParameter("@OrderStatus", e.ResultCode)
						// 交易失敗原因
						, new SqlParameter("@Text", (e.ResultText!=null && e.ResultText != "") ? e.ResultText : "")
						// 實際付款金額
						, new SqlParameter("@Amount", e.CommitAmount) //(e.CommitAmount != null) ? e.CommitAmount : 0)
					};

                    SqlDataReader sdr = SqlHelper.ExecuteReader
                    (
                        WebConfig.ConnectionString,
                        CommandType.StoredProcedure,
                        "NSP_GameWeb_A_UpdateOrder",
                        param
                    );

                    //if (sdr.Read())
                    //{
                    //    if (sdr["ResultCode"].ToString() == "0")
                    //    {
                    //        // 成功後，把錢轉點數
                    //    }
                    //}

                    sdr.Close();
                }
                catch (Exception ex)
                {
                    log4net.LogManager.GetLogger("OrderLog").Debug("PaymentClient BeforePaying(): ExceptionMessage=" + ex.Message);
                }

                string sJScript = "alert('交易取消!\\r\\n" + e.ResultText + "');";
				
				// 寫入沒有活動
				GWeb.ActivityMgr.WriteActivityToDB(e.SSOrderID, "{}");
				log4net.LogManager.GetLogger(typeof(PaymentUtility)).DebugFormat("[NickShih] OrderID:{0}, Json:{1}", e.SSOrderID, "{}");
			}
        }
    }
}