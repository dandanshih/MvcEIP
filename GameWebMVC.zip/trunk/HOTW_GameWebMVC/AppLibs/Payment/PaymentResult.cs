﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.AppLibs.Payment
{
    public class PaymentResult
    {
        /// <summary>
        /// 回傳狀態。
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// 回傳訊息。
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 回傳要顯示的 ContentView。
        /// </summary>
        public ContentResult View { get; set; }
    }
}