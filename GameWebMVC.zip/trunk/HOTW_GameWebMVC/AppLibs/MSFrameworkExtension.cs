﻿using System;
using System.Text.RegularExpressions;
using System.Linq;

namespace HOTW_GameWebMVC
{
    public static class MSFrameworkExtension
    {
        #region 通用
        /// <summary>
        /// 是否有值(非Null或空字串)。
        /// </summary>
        public static bool IsRequired(this string val)
        {
            return (!string.IsNullOrEmpty(val) && val.TrimEnd() != "");
        }

        /// <summary>
        /// 是否為純數字的組合(無限制長度)。
        /// </summary>
        public static bool IsNumber(this string val)
        {
            return (!string.IsNullOrEmpty(val) && Regex.IsMatch(val, @"^\d+$"));
        }

        /// <summary>
        /// 驗證字串中是否含其他字串。
        /// </summary>
        /// <param name="matchStr">比對字串</param>
        /// <returns></returns>
        public static bool IsIncludeString(this string str, params string[] matchStr)
        {
            foreach (string s in matchStr)
            {
                if (!string.IsNullOrEmpty(s) && str.IndexOf(s) > -1)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 檢查目前IP是否為允許IP
        /// <para>Localhost預設允許</para>
        /// </summary>
        /// <param name="AllowIPs">允許IP列表</param>
        /// <returns>true: 允許IP, flase: 不允許IP</returns>
        public static bool IsAllowIP(this string AllowIPs)
        {
            string connIP = System.Web.HttpContext.Current.Request.UserHostAddress;
			return IsAllowIP(AllowIPs, connIP);
        }

		/// <summary>
		/// 檢查參數userIP是否為允許IP
		/// <para>Localhost預設允許</para>
		/// </summary>
		/// <param name="AllowIPs">允許IP列表</param>
		/// /// <param name="userIP">來源IP</param>
		/// <returns>true: 允許IP, flase: 不允許IP</returns>
		public static bool IsAllowIP(this string AllowIPs, string userIP)
		{
			string[] arr_allowIPs = AllowIPs.Split(new string[1] { ";" }, System.StringSplitOptions.RemoveEmptyEntries);
			string connIP = userIP;
			if (System.Web.HttpContext.Current.Request.IsLocal)
			{
				return true;
			}
			if (arr_allowIPs.Contains(connIP))
			{
				return true;
			}
			foreach (string allowIP in arr_allowIPs)
			{
				if (allowIP.Contains('/'))
				{
					string[] parts = allowIP.Split('/');
					int baseAddress = BitConverter.ToInt32(System.Net.IPAddress.Parse(parts[0]).GetAddressBytes(), 0);
					int address = BitConverter.ToInt32(System.Net.IPAddress.Parse(connIP).GetAddressBytes(), 0);
					int mask = System.Net.IPAddress.HostToNetworkOrder(-1 << (32 - int.Parse(parts[1])));
					if ((baseAddress & mask) == (address & mask))
					{
						return true;
					}
				}
			}
			return false;
		}
        #endregion

        #region 會員資料驗證
        /// <summary>
        /// 是否為正確的會員帳號格式。
        /// </summary>
        /// <param name="resultCode">
        /// 0: 此帳號可使用！
        /// 1: 帳號不可空白！
        /// 2: 帳號必須是 6 ~ 12 碼的英文數字組合！
        /// 3: 帳號至少須包含一個英文字母！
        /// </param>
        /// <param name="resultMessage"></param>
        public static bool IsMemberAccount(this string account, out int resultCode, out string resultMessage)
        {
            if (string.IsNullOrEmpty(account))
            {
                resultCode = 1;
                resultMessage = "帳號不可空白！";
                return false;
            }

            if (!Regex.IsMatch(account, @"^[0-9a-zA-Z]{6,12}$"))
            {
                resultCode = 2;
                resultMessage = "帳號必須是 6 ~ 12 碼的英文數字組合！";
                return false;
            }

            if (!Regex.IsMatch(account, @"(?!^[0-9]*$)^([a-zA-Z0-9]{6,12})$"))
            {
                resultCode = 3;
                resultMessage = "帳號至少須包含一個英文字母！";
                return false;
            }

            resultCode = 0;
            resultMessage = "此帳號可使用！";
            return true;
        }

        /// <summary>
        /// 驗證是否為正確的會員密碼格式。
        /// </summary>
        /// <param name="resultCode">
        /// 0: 此密碼可使用！
        /// 1: 密碼不可空白！
        /// 2: 密碼必須是 6 ~ 12 碼的英文數字組合！
        /// 3: 密碼至少須包含一個英文字母！
        /// 4: 密碼不可為連續數字或字母！
        /// 5: 密碼必須包含4種(含)字元以上！
        /// </param>
        /// <param name="resultMessage"></param>
        public static bool IsMemberPassword(this string password, out int resultCode, out string resultMessage)
        {
            if (string.IsNullOrEmpty(password))
            {
                resultCode = 1;
                resultMessage = "密碼不可空白！";
                return false;
            }

            if (!Regex.IsMatch(password, @"^[0-9a-zA-Z]{6,12}$"))
            {
                resultCode = 2;
                resultMessage = "密碼必須是 6 ~ 12 碼的英文數字組合！";
                return false;
            }

            if (Regex.IsMatch(password, @"^[0-9]{6,12}$"))
            {
                resultCode = 3;
                resultMessage = "密碼至少須包含一個英文字母！";
                return false;
            }

            string chars = "";
            string lowerPwd = password.ToLower();
            for (int i = 0; i < password.Length; i++)
            {
                // 把不同的文字加進暫存變數, 等下要判斷有幾種字元 
                if (chars.IndexOf(password[i]) == -1)
                {
                    chars += password[i].ToString();
                }

                int code = lowerPwd[i];
                // 如果往後的 3 個字元都是連續字元(例如 123、abc、321、cba、..), 就傳出錯誤
                if (lowerPwd.Length - i > 2 &&
                        (
                            lowerPwd.Substring(i, 3) == (Convert.ToChar(code).ToString()
                                                        + Convert.ToChar(code + 1).ToString()
                                                        + Convert.ToChar(code + 2).ToString())
                            ||
                            lowerPwd.Substring(i, 3) == (Convert.ToChar(code).ToString()
                                                        + Convert.ToChar(code - 1).ToString()
                                                        + Convert.ToChar(code - 2).ToString())
                        )
                    )
                {
                    resultCode = 4;
                    resultMessage = "密碼不可為連續數字或字母！";
                    return false;
                }
            }

            if (chars.Length < 4)
            {
                resultCode = 5;
                resultMessage = "密碼必須包含4種(含)字元以上！";
                return false;
            }

            resultCode = 0;
            resultMessage = "此密碼可使用！";
            return true;
        }

        /// <summary>
        /// 是否為正確的會員Email格式(長度限制50以內)。
        /// </summary>
        public static bool IsMemberEmail(this string val)
        {
            return (val.IsRequired() && Regex.IsMatch(val, @"^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$") && val.Length <= 50);
        }

        /// <summary>
        /// 是否為正確的會員手機格式。
        /// </summary>
        public static bool IsMemberMobile(this string val)
        {
            return (val.IsRequired() && Regex.IsMatch(val, @"^09[\d]{8}$"));
        }

        /// <summary>
        /// 驗證是否為正確的地址格式(長度限制40以內)。
        /// </summary>
        /// <param name="resultCode">
        /// 0: 此地址可使用！
        /// 1: 請輸入地址！
        /// 2: 地址格式錯誤！
        /// </param>
        /// <param name="resultMessage"></param>
        public static bool IsMemberAddress(this string address, out int resultCode, out string resultMessage)
        {
            if (!address.IsRequired())
            {
                resultCode = 1;
                resultMessage = "請輸入地址！";
                return false;
            }
            else if (!Regex.IsMatch(address, @"^[\u0391-\uFFE5a-zA-Z0-9\-]{1,40}$"))
            {
                resultCode = 2;
                resultMessage = "地址格式錯誤！";
                return false;
            }
            else
            {
                resultCode = 0;
                resultMessage = "此地址可使用！";
                return true;
            }
        }

        /// <summary>
        /// 驗證是否為正確的發票收件人格式(長度限制15以內)。
        /// </summary>
        /// <param name="resultCode">
        /// 0: 此發票收件人可使用！
        /// 1: 請輸入收件人！
        /// 2: 發票收件人格式錯誤！
        /// </param>
        /// <param name="resultMessage"></param>
        public static bool IsInvoiceName(this string name, out int resultCode, out string resultMessage)
        {
            if (!name.IsRequired())
            {
                resultCode = 1;
                resultMessage = "請輸入收件人！";
                return false;
            }
            else if (!Regex.IsMatch(name, @"^[\u0391-\uFFE5a-zA-Z0-9]{0,15}$"))
            {
                resultCode = 2;
                resultMessage = "發票收件人格式錯誤！";
                return false;
            }
            else
            {
                resultCode = 0;
                resultMessage = "此發票收件人可使用！";
                return true;
            }
        }
        #endregion

        #region 其它資料驗證
        /// <summary>
        /// 是否為正確的ECoupon序號(長度限制50以內)。
        /// </summary>
        public static bool IsECoupon(this string ecoupon)
        {
            return (ecoupon.IsRequired() && Regex.IsMatch(ecoupon, @"^[0-9a-zA-Z]{0,50}$"));
        }

        /// <summary>
        /// 是否為正確的儲值卡格式(長度限制50以內)。
        /// </summary>
        public static bool IsStoreValue(this string val)
        {
            return (val.IsRequired() && Regex.IsMatch(val, @"^[0-9a-zA-Z]{0,50}$"));
        }
        #endregion
    }
}