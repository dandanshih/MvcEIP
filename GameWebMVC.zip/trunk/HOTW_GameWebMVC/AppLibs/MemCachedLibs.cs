﻿//-----------------------------------------------------------------------
// <copyright file="Class1.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_DataInfo.AppLibs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using SGT.CachedSQLCommander;
    using System.Runtime.InteropServices;
	using HOTW_DataInfo.AppLibs;
	using HOTW_GameWebMVC.AppLibs;

    /// <summary>
    /// MemCachedLibs Class
    /// </summary>
    public class MemCachedLibs
    {
        private string GetHeaderKey(CachedType ctype, CachedCommand cmd, string key)
        {
            string memKey = string.Format
            (
                "{0}&{1}{2}&{3}",
                // 網站識別碼
				WebConfig.MemCachedPlatformID,
                // 存取資訊種類
                ((int)ctype).ToString("D2"),
                // 封包編號
                ((int)cmd).ToString("D7"),
                // 實際索引值
                key
            );
            return memKey;
        }

        public static MemCachedLibs Instance
        {
            get
            {
                return new MemCachedLibs();
            }
        }

        public TData GetMemCachedData<TData>(CachedCommand cmd, string key)
        {
            return this.GetMemCachedData<TData>(CachedType.Server, cmd, key);
        }

        public TData GetMemCachedData<TData>(CachedType ctype, CachedCommand cmd, string key)
        {
            Cached_ServerStruct<TData> cached = new Cached_ServerStruct<TData>();
            return cached.GetData(this.GetHeaderKey(ctype, cmd, key));
            //return (TData)new Cached_Serializable<object>().GetData("Online113_1ac4lqsdcuk4le1wq0wlgkot_MemberInfo_RD1");
        }

        public bool SetMemCachedData<TData>(CachedCommand cmd, string key, TData data)
        {
            return this.SetMemCachedData<TData>(CachedType.Server, cmd, key, data);
        }

        public bool SetMemCachedData<TData>(CachedType ctype, CachedCommand cmd, string key, TData data)
        {
            Cached_ServerStruct<TData> cached = new Cached_ServerStruct<TData>();
            return cached.SetData(this.GetHeaderKey(ctype, cmd, key), data);
        }

		public bool SetMemCachedData<TData>(CachedType ctype, CachedCommand cmd, string key, TData data,TimeSpan ts)
		{
			Cached_Serializable<TData> cached = new Cached_Serializable<TData>();
			return cached.SetData(this.GetHeaderKey(ctype, cmd, key), data,ts);
		}
    }

    public enum CachedType
    {
        Server = 1,
        Web = 2
    }

    public enum CachedCommand
    {
        PlayerPoint = 1001,
		MemberFriendList = 2001
    }

    #region Structs
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 4)]
    public class DS_MC_PLAYER_POINT_S
    {
        /// <summary>
        /// 玩家點數
        /// </summary>
        public double Point;

        /// <summary>
        /// 玩家Ｕ幣
        /// </summary>
        public double UPoint;

        /// <summary>
        /// 玩家真人幸運金
        /// </summary>
        public double RGameLM;

        /// <summary>
        /// 玩家電子幸運金
        /// </summary>
        public double EGameLM;

        /// <summary>
        /// 玩家對戰幸運金
        /// </summary>
        public double MGameLM;
    }
    #endregion
}