﻿//-----------------------------------------------------------------------
// <copyright file="MemCachedContext.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs.DataHelper
{
    using SGT.Web.Session.HOTW;
    using SGT.Web.SessionBase;
    using System.Web;
    using System.Web.SessionState;

    
    /// <summary>
    /// Class1 Class
    /// </summary>
    public class MemCachedContext : DataContextBase<SessionData>, IRequiresSessionState
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MemCachedContext"/> class.
        /// <para>需帶入SessionID，讓一開始就有資料</para>
        /// </summary>
        /// <param name="sessionID">網站SessionID</param>
        public MemCachedContext(string sessionID)
            : base(sessionID)
        {
        }

        /// <summary>
        /// Gets: 單體模式
        /// </summary>
        public static MemCachedContext Current
        {
            get
            {
                HttpContext context = HttpContext.Current;
                string platform = context.Request.RequestContext.RouteData.Values["platform"].ToString();
                string sessionID = context.Request.Cookies["SGTSessionID"] == null ? context.Session.SessionID : context.Request.Cookies["SGTSessionID"].Value;
                // 目前只有113，所以只先驗證113
                if (platform != "Online113")
                {
                    platform = "Online113";
                }
                string key = string.Format
                (
                    "{0}_{1}_{2}_{3}",
                    platform,
                    sessionID,
                    "MemberInfo",
                    WebConfig.Platform
                );
                return new MemCachedContext(key);
            }
        }

        /// <summary>
        /// 給建構式用的儲存媒介
        /// </summary>
        protected override ISavePlatform SavePlatform
        {
            get
            {
                return new SavePlatform_MemCached();
            }
        }
    }
}