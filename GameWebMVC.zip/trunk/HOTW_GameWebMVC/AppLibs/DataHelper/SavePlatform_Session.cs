﻿//-----------------------------------------------------------------------
// <copyright file="SavePlatform_Session.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs.DataHelper
{
    using SGT.Web.Session.HOTW;
    using SGT.Web.SessionBase;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.SessionState;

    /// <summary>
    /// SavePlatform_Session Class
    /// </summary>
    public class SavePlatform_Session : ISavePlatform, IRequiresSessionState
    {
        public object Get(string key)
        {
            HttpContext context = HttpContext.Current;
            SessionData sessionData;
            if (context.Session["IsLogin"] == null)
            {
                sessionData = new SessionData();
                sessionData.IsLogin = false;
                if (context.Session["MemberID"] != null)
                {
                    sessionData.MemberID = Convert.ToInt32(context.Session["MemberID"]);
                }
                if (context.Session["MemberAccount"] != null)
                {
                    sessionData.MemberAccount = context.Session["MemberAccount"].ToString();
                }
            }
            else
            {
                var currentSession = new SessionData();

                currentSession.LoginKey = Convert.ToInt32(context.Session["LoginKey"]);
                currentSession.TriDESUniID = context.Session["TriDESUniID"].ToString();
                currentSession.TriDESKey = context.Session["TriDESKey"].ToString();
                currentSession.LoginEventFlag = Convert.ToInt64(context.Session["ActivityMask"]);
                currentSession.OnlineID = Convert.ToInt64(context.Session["OnlineID"]);
                currentSession.IsLogin = true;
                currentSession.MemberID = Convert.ToInt32(context.Session["MemberID"]);
                currentSession.MemberAccount = context.Session["MemberAccount"].ToString();
                currentSession.MemberPassword = context.Session["MemberPassword"] == null ? string.Empty : context.Session["MemberPassword"].ToString();
                currentSession.MobileLast4Num = context.Session["MobileLast4Num"] == null ? string.Empty : context.Session["MobileLast4Num"].ToString();
                currentSession.SourceName = context.Session["RegisterType"] == null ? string.Empty : context.Session["RegisterType"].ToString();
                currentSession.EggUrl = context.Session["EggUrl"].ToString();
                currentSession.Level = Convert.ToInt32(context.Session["Level"]);
                currentSession.UserPhoto = context.Session["UserPhoto"].ToString();
                currentSession.AllPicFilePath = context.Session["AllPicFilePath"].ToString();
                currentSession.MemberAttribute = Convert.ToInt64(context.Session["MemberAttribute"]);
                currentSession.NickName = context.Session["NickName"].ToString();
                currentSession.DataInfoUrl = context.Session["DataInfoUrl"].ToString();
                currentSession.MemberUIFlag = Convert.ToInt64(context.Session["MemberUIFlag"]);
                currentSession.VIP_Level = Convert.ToInt32(context.Session["VIP_Level"]);
                currentSession.WebLoginEventFlag = Convert.ToInt64(context.Session["WebLoginEventFlag"]);

                currentSession.OtherData = (Dictionary<string, object>)context.Session["OtherData"];
                if (currentSession.OtherData == null)
                {
                    currentSession.OtherData = new Dictionary<string, object>();
                }
                sessionData = currentSession;
            }
            return sessionData;
        }

        public bool Remove(string key)
        {
            HttpContext.Current.Session.Abandon();
            return true;
        }

        public bool Set(string key, object data)
        {
            try
            {
                var sessionData = data as SessionData;

                var currentSession = sessionData;
                var context = HttpContext.Current;
                //context.Session["LoginKey"] = CurrentSession.LoginKey;
                //context.Session["TriDESUniID"] = CurrentSession.TriDESUniID;
                //context.Session["TriDESKey"] = CurrentSession.TriDESKey;
                if (context.Session["ActivityMask"] != null)
                {
                    context.Session["ActivityMask"] = currentSession.LoginEventFlag;
                }
                //context.Session["OnlineID"] = CurrentSession.OnlineID;
                
                context.Session["MemberID"] = currentSession.MemberID;
               
                context.Session["MemberAccount"] = currentSession.MemberAccount;

				if (context.Session["EggUrl"] != null)
				{
					context.Session["MemberPassword"] = currentSession.MemberPassword;
				}
                //context.Session["MobileLast4Num"] = CurrentSession.MobileLast4Num;
                //context.Session["RegisterType"] = CurrentSession.SourceName;
                if (context.Session["EggUrl"] != null)
                {
                    context.Session["EggUrl"] = currentSession.EggUrl;
                }
                if (context.Session["Level"] != null)
                {
                    context.Session["Level"] = currentSession.Level;
                }
                if (context.Session["UserPhoto"] != null)
                {
                    context.Session["UserPhoto"] = currentSession.UserPhoto;
                }
                if (context.Session["AllPicFilePath"] != null)
                {
                    context.Session["AllPicFilePath"] = currentSession.AllPicFilePath;
                }
                if (context.Session["MemberAttribute"] != null)
                {
                    context.Session["MemberAttribute"] = currentSession.MemberAttribute;
                }
                if (context.Session["NickName"] != null)
                {
                    context.Session["NickName"] = currentSession.NickName;
                }
                //context.Session["DataInfoUrl"] = CurrentSession.DataInfoUrl;
                if (context.Session["MemberUIFlag"] != null)
                {
                    context.Session["MemberUIFlag"] = currentSession.MemberUIFlag;
                }
                if (context.Session["VIP_Level"] != null)
                {
                    context.Session["VIP_Level"] = currentSession.VIP_Level;
                }
                if (context.Session["WebLoginEventFlag"] != null)
                {
                    context.Session["WebLoginEventFlag"] = currentSession.WebLoginEventFlag;
                }
                context.Session["OtherData"] = currentSession.OtherData;
                
                return true;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(SavePlatform_Session)).Error(ex);
                return false;
            }
        }
    }
}