﻿//-----------------------------------------------------------------------
// <copyright file="DataContext.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs.DataHelper
{
    using SGT.Web.Session.HOTW;
    using SGT.Web.SessionBase;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;


    public class DataContext
    {
        private string platform;

        private DataContextBase<SessionData> Context
        {
            get
            {
                return HttpContext.Current.Items["CurrentContext"] as DataContextBase<SessionData>;
            }
            set
            {
                HttpContext.Current.Items["CurrentContext"] = value;
            }
        }

        public SessionData Session
        {
            get
            {
                return this.Context.Session;
            }
            set
            {
                this.Context.Session = value;
            }
        }

        public DataContext(string Platform)
        {
            this.platform = Platform;
            // 如果 DataContextBase 已經有值，代表這次Request已經有先取到
            if (this.Context != null)
            {
                return;
            }
            if (this.platform.ToLower() == "online113")
            {
                HttpContext httpContext = HttpContext.Current;
                this.platform = "Online113";
                string sessionID = httpContext.Request.Cookies["SGTSessionID"] == null ? httpContext.Session.SessionID : httpContext.Request.Cookies["SGTSessionID"].Value;
                string key = string.Format
                (
                    "{0}_{1}_{2}_{3}", 
                    this.platform,
                    sessionID,
                    "MemberInfo",
                    WebConfig.Platform
                ); this.Context = new MemCachedContext(key);
            }
            else
            {
                this.Context = new SessionContext();
            }
        }

        public Action<SessionData> SaveLogic
        {
            get
            {
                return HttpContext.Current.Items["SaveLogic"] as Action<SessionData>;
            }
            set
            {
                HttpContext.Current.Items["SaveLogic"] = value;
            }
        }

        public void Save()
        {
            bool isFirst = true;
            if (SaveLogic != null)
            {
                while (isFirst || !this.Context.Save())
                {
                    this.Context.Reload();
                    SaveLogic(this.Context.Session);
                    isFirst = false;
                }
                this.SaveLogic = null;
            }
            else
            {
                this.Context.Save();
            }
        }
    }
}