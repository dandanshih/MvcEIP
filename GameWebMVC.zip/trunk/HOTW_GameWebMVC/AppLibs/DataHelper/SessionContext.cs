﻿//-----------------------------------------------------------------------
// <copyright file="SessionContext.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs.DataHelper
{
    using SGT.Web.Session.HOTW;
    using SGT.Web.SessionBase;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.SessionState;

    /// <summary>
    /// SessionContext Class
    /// </summary>
    public class SessionContext : DataContextBase<SessionData>, IRequiresSessionState
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SessionContext"/> class.
        /// </summary>
        public SessionContext()
            : base("")
        {
        }

        public static SessionContext Current
        {
            get
            {
                return new SessionContext();
            }
        }

        protected override ISavePlatform SavePlatform
        {
            get { return new SavePlatform_Session(); }
        }
    }
}