﻿//-----------------------------------------------------------------------
// <copyright file="SavePlatform_MemCached.cs" company="SGT">
//    Copyright © 2013 SPLENDOR GAME TECHNOLOGY CO.,LTD all rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace HOTW_GameWebMVC.AppLibs.DataHelper
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using SGT.Web.SessionBase;
    using SGT.CachedSQLCommander;
    using Enyim.Caching;
    using GameWeb_Models.Models.Sessions;

    /// <summary>
    /// SavePlatform_MemCached Class
    /// </summary>
    public class SavePlatform_MemCached : CachedReader, ISavePlatform
    {
        private ulong CasID;

        public object Get(string key)
        {
            MemObject m_obj = this.GetCASData(key);
            if (m_obj == null)
            {
                return null;
            }
            CasID = m_obj.cas;
            return m_obj.obj;
        }

        public bool Remove(string key)
        {
            MemcachedClient m_client = MemCached.Instance;
            return m_client.Remove(key);
        }

        public bool Set(string key, object data)
        {
            try
            {
                bool result = this.SetCASData
                (
                    key,
                    new MemObject
                    {
                        cas = this.CasID,
                        obj = data
                    }
                );
                return result;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(SavePlatform_MemCached)).Error("SetCasData Exception!! ex: " + ex.Message, ex);
                return false;
            }
        }

        public override byte[] GetRealData(string key)
        {
            byte[] data;
            DateTime lockDate;
            int lockCookie;
            bool locked;
            try
            {
                SessionsEntities.GetSessionData(new GetSessionDataInputModel { SessionID = key }, out data, out locked, out lockDate, out lockCookie);
                return data;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(SavePlatform_MemCached)).Error("執行 getData('" + key + "') 發生錯誤: " + ex.Message, ex);
                return null;
            }
        }

        public override bool SetRealData(string key, byte[] data)
        {
            try
            {
                byte[] sessData;
                bool locked;
                DateTime lockDate;
                int lockCookie;
                bool result = SessionsEntities.GetSessionData(new GetSessionDataInputModel { SessionID = key }, out sessData, out locked, out lockDate, out lockCookie);
				if (!result)
                {
                    SessionsEntities.InsertSession(new InsertSessionInputModel { SessionID = key, ShortData = data, TimeOut = 10 });
                }
                else
                {
                    SessionsEntities.UpdateSession
                    (
                        new UpdateSessionInputModel
                        {
                            SessionID = key,
                            LockCookie = lockCookie,
                            ShortData = data,
                            TimeOut = 10
                        }
                    );
                }
                return true;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(typeof(SavePlatform_MemCached)).Error("執行 setData('" + key + "', '" + data + "') 發生錯誤: " + ex.Message, ex);
                return false;
            }
        }
    }
}