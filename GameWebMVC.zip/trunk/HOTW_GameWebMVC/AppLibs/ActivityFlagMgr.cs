﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.SessionState;
using GS.Utilities;

namespace HOTW_GameWebMVC.AppLibs
{
	public class ActivityFlagMgr : IRequiresSessionState
	{
		public static bool RemoveFlag(int MemberID, long Flag)
		{
			HttpContext context = HttpContext.Current;
			bool Result = true;
			long NowFlag = Convert.ToInt64(context.Session["ActivityMask"]);
			if ((NowFlag & Flag) > 0)
			{
				SqlParameter[] param = new SqlParameter[]
				{
					new SqlParameter("@MemberID", MemberID),
					new SqlParameter("@Flag", Flag)
				};
				try
				{
					SqlHelper.ExecuteNonQuery
					(
						WebConfig.ConnectionString,
						CommandType.StoredProcedure,
						"NSP_GameWeb_G_EraseLoginEventFlag",
						param
					);
					context.Session["ActivityMask"] = (NowFlag ^ Flag);
				}
				catch
				{
					Result = false;
				}
			}
			return Result;
		}

        public static long ClearFlag(int MemberID, long Flag, long UserFlag)
        {
            HttpContext context = HttpContext.Current;
           
            if ((UserFlag & Flag) > 0)
            {
                SqlParameter[] param = new SqlParameter[]
				{
					new SqlParameter("@MemberID", MemberID),
					new SqlParameter("@Flag", Flag)
				};
                
                SqlHelper.ExecuteNonQuery
                (
                    WebConfig.ConnectionString,
                    CommandType.StoredProcedure,
                    "NSP_GameWeb_G_EraseLoginEventFlag",
                    param
                );
                return (UserFlag ^ Flag);
            }
            return UserFlag;
        }
	}
}