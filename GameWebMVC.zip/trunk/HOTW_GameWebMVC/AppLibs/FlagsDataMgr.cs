﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HOTW_GameWebMVC.EnumType;
using HOTW_GameWebMVC.FlagsData;
using SGT.Mvc;

namespace HOTW_GameWebMVC.AppLibs
{
	public class FlagsDataMgr
	{
		private FlagsDataTemplate<FlagsDataType> DataHandler;

		public FlagsDataMgr()
		{
			DataHandler = new FlagsDataTemplate<FlagsDataType>();

			DataHandler.RegisterType(FlagsDataType.News, new NewsData());

            DataHandler.RegisterType(FlagsDataType.RankByJp, new RankByJpData());

            DataHandler.RegisterType(FlagsDataType.RankByMoney, new RankByMoneyData());

            DataHandler.RegisterType(FlagsDataType.RankBySingleWin, new RankBySingleWinData());

            DataHandler.RegisterType(FlagsDataType.RankByPachinko, new RankByPachinkoData());

            DataHandler.RegisterType(FlagsDataType.RankByTotalWin, new RankByTotalWinData());

			DataHandler.RegisterType(FlagsDataType.Games, new GamesData());

			DataHandler.RegisterType(FlagsDataType.PersonalNews, new PersonalNewsData());

			DataHandler.RegisterType(FlagsDataType.PersonalGlory, new PersonalGloryData());

			DataHandler.RegisterType(FlagsDataType.MyFriend, new MyFriendData());

			DataHandler.RegisterType(FlagsDataType.PersonalCard, new PersonalCardData());

            DataHandler.RegisterType(FlagsDataType.MemberData, new MemberData());

            DataHandler.RegisterType(FlagsDataType.RankVIPGame, new RankVIPGameData());
		}

		public Dictionary<FlagsDataType, object> ReadData(string fdType, string jsonData)
		{
			return DataHandler.ExcuteData(fdType, jsonData);
		}
	}
}