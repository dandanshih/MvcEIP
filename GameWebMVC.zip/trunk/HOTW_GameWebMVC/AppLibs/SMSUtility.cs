﻿using GS.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace HOTW_GameWebMVC.AppLibs
{
    public static class SMSUtility
    {
        /// <summary>
        /// 簡訊發送的性質種類
        /// </summary>
        public enum SMSRequestTypes
        {
            /// <summary>
            /// 用來測試簡訊功能
            /// </summary>
            Test = 0,
            /// <summary>
            /// 新申請會員帳號的手機驗證
            /// </summary>
            NewMemberAuth = 1,
            /// <summary>
            /// 忘記密碼, 傳送新密碼
            /// </summary>
            ForgetPassword = 2,
            /// <summary>
            /// 轉帳交易
            /// </summary>
            PointTransfer = 3,
            /// <summary>
            /// 重新認證
            /// </summary>
            MemberReAUTH = 4,
            /// <summary>
            /// 系統警告
            /// </summary>
            SysAlert = 99
        }

        /// <summary>
        /// 立即發送簡訊
        /// </summary>
        /// <param name="destAddr">目的號碼</param>
        /// <param name="msgContent">簡訊內容</param>
        /// <param name="requestType">簡訊種類</param>
        /// <param name="requestID">此則簡訊的關聯編號，用來記載為其他相關聯應用的編號</param>
        public static void SendSMS(string destAddr, string msgContent, SMSRequestTypes requestType, string requestID)
        {

#if (Online)
            string strSMSServer_MsgID = "";
            
            SqlParameter[] param = 
			{
				new SqlParameter("@APPID", GS.ServerCommander.FSCommander.SHID),
				new SqlParameter("@DestAddr", destAddr),
				new SqlParameter("@MsgContent", msgContent),
				new SqlParameter("@RequestType", requestType.ToString()),
				new SqlParameter("@RequestID", requestID),
				new SqlParameter("@RequestIP", HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]),
				new SqlParameter("@SMSServer_MsgID", SqlDbType.UniqueIdentifier)
			};

            param[6].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery
            (
                WebConfig.SMSConnectionString,
                CommandType.StoredProcedure,
                "NSP_GameWeb_S_SMSRequest_New",
                param
            );

            strSMSServer_MsgID = param[6].Value.ToString();
#endif
        }
    }
}