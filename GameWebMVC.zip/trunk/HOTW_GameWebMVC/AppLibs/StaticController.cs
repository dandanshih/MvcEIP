﻿using System.Web.Mvc;

namespace HOTW_GameWebMVC.AppLibs
{
    public class StaticController : Controller
    {
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            object area = ControllerContext.RouteData.Values["area"];
            object id = ControllerContext.RouteData.Values["id"].ToString();
            object id2 = ControllerContext.RouteData.Values["id2"];

            string viewName = "";

            if (string.IsNullOrEmpty(viewName) && area != null)
            {
                if (id2 == null)
                {
                    viewName = string.Format("{0}/{1}", area, id);
                }
                else
                {
                    viewName = string.Format("{0}/{1}/{2}", area, id, id2);
                }
            }

            if (ViewEngines.Engines.FindView(ControllerContext, viewName, null).View == null)
            {
                filterContext.Result = new RedirectResult("/");
            }
            else
            {
                filterContext.Result = View(viewName);
            }

            base.OnActionExecuting(filterContext);
        }
    }
}