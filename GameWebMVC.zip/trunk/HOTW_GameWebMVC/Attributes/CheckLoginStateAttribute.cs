﻿using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.Attributes
{
	public class CheckLoginStateAttribute : ActionFilterAttribute, IRequiresSessionState
	{
        private bool _isLogin;

        /// <summary>
        /// 建構式
        /// </summary>
        public CheckLoginStateAttribute()
        {
        }

        /// <summary>
        /// 建構式
        /// </summary>
        /// <param name="IsLogin">是否驗證為登入狀態</param>
        public CheckLoginStateAttribute(bool IsLogin)
        {
            this._isLogin = IsLogin;
        }

		public override void OnActionExecuting(ActionExecutingContext filterContext)
		{
            if (filterContext.Controller is ISGTPage)
            {
                ISGTPage page = filterContext.Controller as ISGTPage;
                DataContext context = new DataContext(page.Platform);
                if (_isLogin && !context.Session.IsLogin)
                {
                    filterContext.Result = new RedirectResult("/Mvc");
                }

                if (!_isLogin && context.Session.IsLogin)
                {
                    filterContext.Result = new RedirectResult("/Mvc");
                }
            }
            else
            {
                var Session = HttpContext.Current.Session;

                if (_isLogin && Session["IsLogin"] == null)
                {
                    filterContext.Result = new RedirectResult("/Mvc");
                }

                if (!_isLogin && Session["IsLogin"] != null)
                {
                    filterContext.Result = new RedirectResult("/Mvc");
                }
            }
            base.OnActionExecuting(filterContext);
        }
	}
}