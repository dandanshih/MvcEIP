﻿using HOTW_GameWebMVC.AppLibs;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http.Filters;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.Attributes.WebAPI
{
    public class AjaxOnlyAttribute : ActionFilterAttribute, IRequiresSessionState
    {
        public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            var request = actionContext.Request;
            var headers = request.Headers;

            if (!headers.Contains("X-Requested-With") || headers.GetValues("X-Requested-With").FirstOrDefault() != "XMLHttpRequest")
            {
                actionContext.Response = request.CreateResponse(HttpStatusCode.NotFound);
            }

            //if (headers.Referrer.Host != WebConfig.Domain || headers.Referrer.Port != 80)
            //{
            //    actionContext.Response = request.CreateResponse(HttpStatusCode.NotFound);
            //}

            base.OnActionExecuting(actionContext);
        }
    }
}