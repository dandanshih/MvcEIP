﻿using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;
using System.Web.SessionState;

namespace HOTW_GameWebMVC.Attributes.WebAPI
{
    public class CheckLoginStateAttribute : ActionFilterAttribute, IRequiresSessionState
    {
        private bool _isLogin;

        /// <summary>
        /// 建構式
        /// </summary>
        public CheckLoginStateAttribute()
        {
        }

        /// <summary>
        /// 建構式
        /// </summary>
        /// <param name="IsLogin">是否驗證為登入狀態</param>
        public CheckLoginStateAttribute(bool IsLogin)
        {
            this._isLogin = IsLogin;
        }

        public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            string Platform = string.IsNullOrEmpty(HttpContext.Current.Request.Params["Platform"]) ? "Web" : HttpContext.Current.Request.Params["Platform"];

            DataContext context = new DataContext(Platform);

            var Session = HttpContext.Current.Session;
            var Request = actionContext.Request;

            if (_isLogin && !context.Session.IsLogin)
            {
                actionContext.Response = Request.CreateResponse(HttpStatusCode.NotFound);
            }

            if (!_isLogin && context.Session.IsLogin)
            {
                actionContext.Response = Request.CreateResponse(HttpStatusCode.NotFound);
            }

            base.OnActionExecuting(actionContext);
        }
    }
}