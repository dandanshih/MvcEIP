﻿using HOTW_GameWebMVC.AppLibs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Attributes
{
	public class PreLoginAttribute : ActionFilterAttribute
	{
		public override void OnActionExecuting(ActionExecutingContext filterContext)
		{
			base.OnActionExecuting(filterContext);

			if (MvcApplication.IsMaintain)
			{
				return;
			}
			var Session = filterContext.HttpContext.Session;
			var Request = filterContext.HttpContext.Request;

			if (Session["IsLogin"] != null)
			{
				return;
			}

			// 讀取 Cookie 保持登入狀態 資料
			string code = (Request.Cookies["keepOnline"] != null) ? HttpUtility.UrlDecode(Request.Cookies["keepOnline"].Value) : "";

			if (string.IsNullOrEmpty(code))
			{
				return;
			}

			// Code解碼得到會員資料再登入
			string[] aryData = EncryptUtility.Decode(code).Split('|');
			string account = aryData[0];
			string password = aryData[1];

            #region 需求修改-前台保持登入狀態有勾選時，不自動幫玩家登入，改為將帳號帶入帳號輸入框
            Session["keepOnline"] = account;
            Session["IsRemember"] = ((!string.IsNullOrEmpty(account) && !string.IsNullOrWhiteSpace(account)) ? "true" : "false");
            return;
            #endregion

            // 確認登入資料是否正確
			if (!string.IsNullOrEmpty(account) && !string.IsNullOrEmpty(password))
			{
				try
				{
					MemberInfo minfo = new MemberInfo();
					minfo.MemberAccount = string.IsNullOrEmpty(account) ? " " : account;
					minfo.MemberPassword = string.IsNullOrEmpty(password) ? " " : password;
					minfo.Mobile4Num = " ";
					minfo.Platform = "Web";
					minfo.ClientIP = Request.UserHostAddress;
					minfo.FSLoginType = HOTW_GameWebMVC.AppLibs.LoginType.Web;

					var resultData = MemberEventUtility.Login(minfo);
                    if (resultData.IsNext)
                    {
                        filterContext.HttpContext.Response.Redirect(filterContext.HttpContext.Request.Url.ToString());
                    }
                    //filterContext.Result = new RedirectResult(filterContext.HttpContext.Request.Url.ToString());
				}
				catch (Exception ex)
				{
					log4net.LogManager.GetLogger(typeof(DynamicController)).Error("LoginFail", ex);
				}
			}
		}
	}
}