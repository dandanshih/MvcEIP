﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HOTW_GameWebMVC.Attributes
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, Inherited = true, AllowMultiple = true)]
	public class LogAttribute : FilterAttribute, IExceptionFilter
	{
		public void OnException(ExceptionContext filterContext)
		{
			if (filterContext != null && filterContext.Exception != null)
			{
				string controller = filterContext.RouteData.Values["controller"].ToString();
				string action = filterContext.RouteData.Values["action"].ToString();
				string loggerName = string.Format("{0}Controller.{1}", controller, action);

				log4net.LogManager.GetLogger(loggerName).Error(filterContext.Exception);
			}
		}
	}
}