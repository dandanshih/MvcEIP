﻿using System.Web;
using System.Web.Optimization;
using SGT.Mvc.Razor;

namespace HOTW_GameWebMVC
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui*",
                        "~/Scripts/jquery-ui-timepicker-addon.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"
            ));

            // 所有頁面必載腳本
            bundles.Add(new ScriptBundle("~/bundles/lib").Include(
                        "~/Scripts/jquery-1.*",
                        "~/Scripts/jquery.menu.*",
						"~/Scripts/knockout*",
                        "~/Scripts/jquery.placeholder.js",
						"~/Scripts/jquery.cookie.js",
						"~/Scripts/jquery.cycle.all.js",
                        "~/Scripts/SGT/NameSpace.js",
						"~/Scripts/SGT/Other/swfobject.js",
                        "~/Scripts/SGT/Flash/LoadSwf.js",
                        "~/Scripts/SGT/Global/Messages.js",
                        "~/Scripts/SGT/DataInfo/FlagsDataQuery.js",
                        "~/Scripts/SGT/Global/Cycle.js",
                        "~/Scripts/SGT/Global/Side.js",
                        "~/Scripts/SGT/Global/StaticData.js",
                        "~/Scripts/SGT/Global/ADManagement.js"
			));

            // Web Layout 共用
            bundles.Add(new ScriptBundle("~/bundles/sgt").Include(
                        "~/Scripts/SGT/Other/WebUtility.js",
                        "~/Scripts/SGT/Other/rsa.js",
						"~/Scripts/SGT/Member/Info.js",
						"~/Scripts/SGT/Member/Login.js",
						"~/Scripts/SGT/Member/AccountTransfer.js",
                        "~/Scripts/SGT/Member/AccountChange.js",
                        "~/Scripts/SGT/Bind.js",
						"~/Scripts/SGT/Global/PopIframe.js",
                        "~/Scripts/SGT/Member/FnActivity.js",
                        "~/Scripts/SGT/Pages/Shared/SGTPage.js"
            ));

            // UpgradeVIP 流程
            bundles.Add(new ScriptBundle("~/bundles/sgtupgradevip").Include(
                        "~/Scripts/SGT/Other/WebUtility.js",
                        "~/Scripts/SGT/Member/UpgradeVIP.js",
                        "~/Scripts/SGT/Bind.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/sgtwebutility").Include(
                        "~/Scripts/SGT/Other/WebUtility.js",
                        "~/Scripts/SGT/Bind.js"
            ));

            // 新手註冊流程
            bundles.Add(new ScriptBundle("~/bundles/sgtregister").Include(
                        "~/Scripts/SGT/Other/WebUtility.js",
                        "~/Scripts/SGT/Pages/Account/Register.js",
                        "~/Scripts/SGT/Member/CheckPassword.js",
                        "~/Scripts/SGT/Bind.js"
            ));

            // 界接帳號轉換流程
            bundles.Add(new ScriptBundle("~/bundles/sgtaccounttransfer").Include(
                        "~/Scripts/SGT/Other/WebUtility.js",
                        "~/Scripts/SGT/Member/AccountTransfer.js",
                        "~/Scripts/SGT/Member/CheckPassword.js",
                        "~/Scripts/SGT/Bind.js"
            ));

            // 界接帳號錯過期流程
            bundles.Add(new ScriptBundle("~/bundles/sgtaccountchange").Include(
                        "~/Scripts/SGT/Other/WebUtility.js",
                        "~/Scripts/SGT/Member/AccountChange.js",
                        "~/Scripts/SGT/Member/CheckPassword.js",
                        "~/Scripts/SGT/Bind.js"
            ));

            bundles.Add(new RazorScriptBundle("~/bundles/razor").Include(
                        "~/Scripts/SGT/WebSiteInfo/Razor.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/community").Include(
                        "~/Scripts/Facebook/FacebookBase.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/fb").Include(
                        "~/Scripts/Facebook/Facebook.js",
                        "~/Scripts/Facebook/FacebookBase.js",
                        "~/Scripts/Facebook/FBCommon.js"
            ));

            // 首頁
            bundles.Add(new ScriptBundle("~/bundles/index").Include(
                        "~/Scripts/SGT/Pages/Home/DataQuery.js"
            ));

            // Views/FlashSinglePopup 共用
            bundles.Add(new ScriptBundle("~/bundles/sgtflashsinglepopup").Include(
                        "~/Scripts/SGT/Flash/FlashEvent.js",
                        "~/Scripts/SGT/Pages/FlashSinglePopup/EnterNoviceSN.js",
                        "~/Scripts/SGT/Bind.js"
            ));

            // 大廳 (因為目前大廳只有載這個，所以連一些共用的也都塞在這)
            bundles.Add(new ScriptBundle("~/bundles/lobby").Include(
                        "~/Scripts/SGT/Global/Messages.js",
                        "~/Scripts/SGT/DynamicPages/Base/PointBuyBase.js",
                        "~/Scripts/SGT/DynamicPages/Base/TransferBase.js",
                        "~/Scripts/SGT/DynamicPages/Lobby/PointBuy.js",
                        "~/Scripts/SGT/DynamicPages/Lobby/Transfer.js"
            ));

            // 113 UpgradeVIP 流程
            bundles.Add(new ScriptBundle("~/bundles/113upgradevip").Include(
                        "~/Scripts/SGT/Online113/UpgradeVIP.js"
            ));

            // 活動頁(會員登入功能)
            bundles.Add(new ScriptBundle("~/bundles/StaticPages/MemberLogin").Include(
                        "~/Scripts/SGT/Other/rsa.js",
                        "~/Scripts/SGT/StaticPages/ActionPage/MemberLogin.js"
            ));

			// 新手註冊流程
			bundles.Add(new ScriptBundle("~/bundles/sgtmemberregister").Include(
						"~/Scripts/SGT/Other/WebUtility.js",
						"~/Scripts/SGT/Member/CheckPassword.js",
						"~/Scripts/SGT/Bind.js"
			));
        }
    }
}