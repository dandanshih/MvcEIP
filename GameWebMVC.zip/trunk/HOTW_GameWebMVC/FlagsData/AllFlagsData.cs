﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GameWeb_Models;
using GameWeb_Models.Models;
using SGT.Mvc.Attributes;
using System.Web.SessionState;
using SGT.Mvc.Interfaces;
using GameWeb_Models.Models.Member;
using GameWeb_Models.Models.Other;
using HOTW_GameWebMVC.AppLibs;
using HOTW_GameWebMVC.AppLibs.DataHelper;

namespace HOTW_GameWebMVC.FlagsData
{
	[SGTCache(CacheName="NewsData", CacheTime = 30)]
	public class NewsData : IFlagData
	{
		public object Excute(object inputData)
		{
			int totalRecord = 0;
			return NewsEntities.GetData(out totalRecord, 0, 0, null, null, "", 7, 1, 1).Select(i => new
            {
                NewsID = i.NewsID,
                NewsTypeID = i.NewsTypeID,
                ModifiedDate = i.ModifiedDate.ToString("yyyy/MM/dd"),
                NewsTitle = i.NewsTitle
            });
		}
	}

	[SGTCache(CacheName = "RankByJpData", CacheTime = 30)]
    public class RankByJpData : IFlagData
	{
		public object Excute(object inputData)
		{
            return RankEntities.GetData(7, 2, 15).Select(i => new
            {
                RowNo = i.RowNo,
                NickName = i.NickName,
                GameName = i.Values1,
                JpPoint = i.DATA.ToString("N0")
            });
        }
	}

	[SGTCache(CacheName = "RankByMoneyData", CacheTime = 30)]
    public class RankByMoneyData : IFlagData
    {
		public object Excute(object inputData)
        {
            return RankEntities.GetData(2, 2, 15).Select(i => new
            {
                RowNo = i.RowNo,
                NickName = i.NickName,
                Point = i.DATA.ToString("N0")
            });
        }
    }

	[SGTCache(CacheName = "RankBySingleWinData", CacheTime = 30)]
    public class RankBySingleWinData : IFlagData
    {
		public object Excute(object inputData)
        {
            return RankBySingleWinEntities.GetData(2, 15, 0).Select(i => new
            {
                RowNo = i.RowNo,
                NickName = i.NickName,
                GameName = i.GameName,
                JpPoint = i.RankData.ToString("N0"),
                GameID = i.GameID,
                SeatID = i.SeatID.ToString("N0")
            });
        }
    }

    [SGTCache(CacheName = "RankByPachinkoData", CacheTime = 30)]
    public class RankByPachinkoData : IFlagData
    {
        public object Excute(object inputData)
        {
            return RankByPachinkoEntities.GetData(2, 15, 0).Select(i => new
            {
                RowNo = i.RowNo,
                NickName = i.NickName,
                GameName = i.GameName,
                JpPoint = i.RankData.ToString("N0"),
                GameID = i.GameID,
                SeatID = i.SeatID.ToString("N0")
            });
        }
    }

	[SGTCache(CacheName = "RankByTotalWinData", CacheTime = 30)]
    public class RankByTotalWinData : IFlagData
    {
		public object Excute(object inputData)
        {
            return RankEntities.GetData(1, 2, 15).Select(i => new
            {
                RowNo = i.RowNo,
                NickName = i.NickName,
                TotalWin = i.DATA.ToString("N0")
            });
        }
    }

	[SGTCache(CacheName = "GamesData", CacheTime = 30)]
	[CacheParam(ParamKey = "MemberID", ParamType = CacheParamType.Session)]
	[CacheParam(ParamKey = "2", ParamType = CacheParamType.None)]
	public class GamesData : IFlagData
	{
		public object Excute(object inputData)
		{
			HttpContext context = HttpContext.Current;
			int MemberID = 0;
			int PointType = 0;
			if (context.Session["IsLogin"] != null)
			{
				if (int.Parse(context.Session["VIP_Level"].ToString()) == 0)
				{
					MemberID = Convert.ToInt32(context.Session["MemberID"]);
					PointType = 1;
				}else{
					MemberID = Convert.ToInt32(context.Session["MemberID"]);
					PointType = 2;
				}
			}
			else
			{
				PointType = 0;
			}
			return GamesEntities.GetData(MemberID, PointType);
		}
	}

	public class PersonalNewsData : IFlagData
	{
		public object Excute(object inputData)
		{
			HttpContext context = HttpContext.Current;
			int MemberID = 0;			
			if (context.Session["IsLogin"] != null)
			{
				MemberID = Convert.ToInt32(context.Session["MemberID"]);
			}
            else
            {
                return new object[0];
            }

			return PersonalNewsEntities.GetData(MemberID).Select(i => new
			{
				RowNo = i.RowNo,
				MessageData = i.MessageData				
			});
		}
	}

	public class MyFriendData : IFlagData
	{
		public object Excute(object inputData)
		{
			DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);
			int RowCount = 0;
			MyFriendInputModel input = new MyFriendInputModel();
			//input.PageIndex = 1;
			//input.PageSize = 6;
			input.MemberID = context.Session.MemberID;

			return MemberEntities.MyFriend(input, out RowCount).Select(i => new
			{
				MemberID = i.MemberID,
				FriendMemberID = i.FriendMemberID,
				NickName = i.NickName
			});
		}
	}


    public class PersonalGloryData : IFlagData
    {
        public object Excute(object inputData)
        {
            DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);
            int TotalRecord = 0;

            PersonalGloryInputModel input = new PersonalGloryInputModel();
            input.PageIndex = 1;
            input.PageSize = 6;
            input.MemberID = context.Session.MemberID;

            return MemberEntities.PersonalGlory(input, out TotalRecord).Select(i => new
            {
                RowNo = i.RowNo,
                EventDate = Convert.ToDateTime(i.EventDate).ToString("yyyy/MM/dd"),
                EventDec = i.EventDec
            });
        }
    }

	public class PersonalCardData : IFlagData
	{
		public object Excute(object inputData)
		{
            DataContext context = new DataContext(HttpContext.Current.Request.Params["Platform"]);
			int MemberID = 0;
			string CurrentLevel = string.Empty;
			string NextLevel = string.Empty;
			string NextDate = string.Empty;
            if (context.Session.IsLogin)
            {
                MemberID = Convert.ToInt32(context.Session.MemberID);
            }
            else
            {
                return null;
            }
			List<PersonalCardModel> dataList = PersonalCardEntities.GetData(MemberID, out CurrentLevel, out NextLevel, out NextDate);
			return new
			{
				DataList = dataList.Select(i => new
				{
					DataType = i.DataType,
					NowValue = i.NowValue,
					No1Level = i.No1Level,
					No1Value = i.No1Value,
					No2Level = i.No2Level,
					No2Value = i.No2Value,
					No3Level = i.No3Level,
					No3Value = i.No3Value,
					CardInfoTitle = i.CardInfoTitle
				}),
				CurrentLevel = CurrentLevel,
				NextLevel = NextLevel,
				NextDate = Convert.ToDateTime(NextDate).ToString("yyyy/M/d")
			};
		}
	}

	public class MemberData : IFlagData, IRequiresSessionState
	{
		public object Excute(object inputData)
		{
			var Session = HttpContext.Current.Session;

			return new
			{
                WebLoginEventFlag = Session["WebLoginEventFlag"] == null ? 0 : Convert.ToInt64(Session["WebLoginEventFlag"])
			};
		}
    }

    //取得最新排行榜=>百大富豪
    [SGTCache(CacheName = "RankVIPGameData", CacheTime = 30)]
    public class RankVIPGameData : IFlagData
    {
        public object Excute(object inputData)
        {
            return RankEntities.GetData(2, 2, 100).Select(i => new
            {
                RowNo = i.RowNo,
                NickName = i.NickName,
                DATA = i.DATA.ToString("N0")
            });
        }
    }
}