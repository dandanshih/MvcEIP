﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.SessionState;
using HOTW_GameWebMVC.AppLibs;

namespace HOTW_GameWebMVC
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public const string SeparatorLevel1 = "#@$";
        public const string SeparatorLevel2 = "$#%";
        public const string SeparatorLevel3 = "%$^";
        public const string SeparatorLevel4 = "^%&";

		public static bool IsMaintain { get; set; }

		public static void ReadIsMaintain()
		{
			using (SqlConnection conn = new SqlConnection(WebConfig.SysConnectionString))
			{
				conn.Open();
				SqlCommand objCmd = new SqlCommand();
				objCmd.Connection = conn;
				objCmd.CommandText = "NSP_GameWeb_S_SqlDependencyByDowntimeStatus";
				objCmd.CommandType = System.Data.CommandType.StoredProcedure;
				using (objCmd)
				{
					IsMaintain = Convert.ToInt32(objCmd.ExecuteScalar()) == 1;
				}
			}
		}

        protected void Application_Start()
        {
			log4net.LogManager.GetLogger(typeof(MvcApplication)).Debug("Application_Start");
            AreaRegistration.RegisterAllAreas();

            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
			// 加入 DB 監控
			ReadIsMaintain();
        }

		protected void Application_End()
		{
			log4net.LogManager.GetLogger(typeof(MvcApplication)).Debug("Application_End");
		}

		// 要加上下面兩段 function 才可以在 apiController 裡面使用 Session!!!
		protected void Application_PostAuthorizeRequest()
		{
			if (IsWebApiRequest())
			{
				HttpContext.Current.SetSessionStateBehavior(SessionStateBehavior.Required);
			}
		}

		private static bool IsWebApiRequest()
		{
			return HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.ToLower().StartsWith("~/api");
		}

		protected void Application_Error(object sender, EventArgs e)
		{
			Exception ex = Server.GetLastError();
			log4net.LogManager.GetLogger(typeof(MvcApplication)).Error("Application_Error", ex);
		}
    }
}